var Hermes = (function () {
  'use strict';
  var __defProp = Object.defineProperty;
  var __defNormalProp = (obj, key, value) =>
    key in obj
      ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value })
      : (obj[key] = value);
  var __publicField = (obj, key, value) => __defNormalProp(obj, typeof key !== 'symbol' ? key + '' : key, value);

  const config = {
    apiBaseUrl: 'https://partners.api.vio.com/v1',
    trackingUrl: 'https://fe-evas.fih.io/browser-extension/event',
    remoteConfigUrl: 'https://www.vio.com/js/browser-extension/remote-config/v1/config.json',
    apiKey: '',
    // This is provided by the developers who use the SDK
    trackingKey: String('kk0dwmry7acfeh6af97vw8wroo80texx'),
    // This is our internal event tracking key, bundled as plain text
    version: '1.0.3',
    options: {
      debug: false,
      verboseLogging: false,
      language: 'en-US',
      fetcher: (...args) => fetch(...args),
      // Use the global fetch function by default
    },
    update(newConfig) {
      Object.assign(this, newConfig);
    },
  };
  const COMMON_STYLES = 'padding: 2px 12px; border-radius: 50px;';
  const STYLES = {
    info: `background: rgba(120, 120, 120, 0.5); color: white; ${COMMON_STYLES}`,
    success: `background: lime; color: black; ${COMMON_STYLES}`,
    warning: `background: black; color: orange; font-weight: bold; ${COMMON_STYLES}`,
    error: `background: red; color: black; font-weight: bold; ${COMMON_STYLES}`,
    selector: `background: blue; color: white; font-weight: bold; ${COMMON_STYLES}`,
    api: ` background: linear-gradient(to right, #f857a6, #ff5858); color: white; font-weight: bold; ${COMMON_STYLES}`,
  };
  const LOG_PREFIX = {
    info: '%c[Hermes SDK] [INFO] 📣',
    success: '%c[Hermes SDK] [SUCCESS] ✅',
    warning: '%c[Hermes SDK] [WARN] 💥',
    error: '%c[Hermes SDK] [ERROR] ❌',
    selector: '%c[Hermes SDK] [SELECTOR] 🔍',
    api: '%c[Hermes SDK] [API] 📡',
  };
  const styledLogger = (type, ...messages) => {
    const cssStyle = STYLES[type] || '';
    if (type === 'error') {
      const error = new Error();
      const stack = error.stack?.split('\n').slice(2).join('\n');
      console.groupCollapsed(LOG_PREFIX[type], cssStyle, ...messages);
      console.error('↳ Stack trace:\n' + stack);
      console.groupEnd();
      return;
    }
    if (type === 'warning') {
      console.warn(LOG_PREFIX[type], cssStyle, ...messages);
      return;
    }
    console.log(LOG_PREFIX[type], cssStyle, ...messages);
  };
  const logger = {
    info(...messages) {
      if (config.options.debug) {
        styledLogger('info', ...messages);
      }
    },
    warn(...messages) {
      if (config.options.debug) {
        styledLogger('warning', ...messages);
      }
    },
    selector(...messages) {
      if (config.options.debug && config.options.verboseLogging) {
        styledLogger('selector', ...messages);
      }
    },
    success(...messages) {
      if (config.options.debug) {
        styledLogger('success', ...messages);
      }
    },
    api(...messages) {
      if (config.options.debug) {
        styledLogger('api', ...messages);
      }
    },
    error(...messages) {
      if (config.options.debug) {
        styledLogger('error', ...messages);
      }
    },
  };
  const DEFAULT_SELECTOR_TIMEOUT = 3e3;
  const showNotImplementedMessageAsync = async functionName => {
    logger.warn(
      `Function ${functionName} is not implemented yet.
If it is called, you probably should implement it.`,
    );
    return Promise.resolve(null);
  };
  const cacheRemoteConfig = async config2 => {
    try {
      const stringifiedConfig = JSON.stringify(config2);
      await chrome.storage.local.set({
        [REMOTE_CONFIG_STORAGE_KEY]: stringifiedConfig,
        [REMOTE_CONFIG_TIMESTAMP_STORAGE_KEY]: String(Date.now()),
      });
      logger.info('[REMOTE CONFIG] Successfully cached remote config in local storage');
    } catch (error) {
      logger.error('[REMOTE CONFIG] Error while caching remote config', error);
    }
  };
  const fetchRemoteConfigFromServer = async () => {
    try {
      logger.api('[REMOTE CONFIG] Fetching live remote config from server', config.remoteConfigUrl);
      const response = await config.options.fetcher(config.remoteConfigUrl, {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json',
        },
      });
      if (!response.ok) {
        logger.error('[REMOTE CONFIG] Failed to fetch remote config', response);
        throw new Error(`Failed to fetch remote config: ${response.statusText}`);
      }
      const json = await response.json();
      logger.info('[REMOTE CONFIG] Successfully fetched remote config from server');
      return json;
    } catch (error) {
      logger.error('[REMOTE CONFIG] Error while fetching remote config', error);
      throw error;
    }
  };
  const getCachedConfig = async () => {
    try {
      logger.info('[REMOTE CONFIG] Checking for cached config in local storage');
      const localStorageResult = await chrome.storage.local.get([REMOTE_CONFIG_STORAGE_KEY]);
      const cachedConfigRaw = localStorageResult[REMOTE_CONFIG_STORAGE_KEY];
      if (typeof cachedConfigRaw === 'string') {
        logger.info('[REMOTE CONFIG] Cached config found in local storage, using it instead of fetching from server');
        const parsedCachedConfig = JSON.parse(cachedConfigRaw);
        if (Boolean(parsedCachedConfig) && typeof parsedCachedConfig === 'object') {
          return parsedCachedConfig;
        }
      }
      logger.info('[REMOTE CONFIG] No cached config found in local storage, fetching fresh from server');
      return null;
    } catch (error) {
      logger.error('[REMOTE CONFIG] Error while getting cached config', error);
      return null;
    }
  };
  const getCachedConfigTimestamp = async () => {
    const localStorageResult = await chrome.storage.local.get([REMOTE_CONFIG_TIMESTAMP_STORAGE_KEY]);
    const cachedTimestamp = localStorageResult[REMOTE_CONFIG_TIMESTAMP_STORAGE_KEY];
    if (cachedTimestamp) {
      logger.info('[REMOTE CONFIG] Cached remote config timestamp found in local storage');
      return Number(cachedTimestamp);
    }
    logger.info('[REMOTE CONFIG] No cached remote config timestamp found in local storage');
    return null;
  };
  const getTimeSinceEpoch = timestamp => {
    const now = Date.now();
    const age = now - timestamp;
    return age;
  };
  const getIsCacheFresh = async () => {
    const cacheTimestamp = await getCachedConfigTimestamp();
    if (!cacheTimestamp || isNaN(cacheTimestamp)) {
      logger.error('[REMOTE CONFIG] Cache is not fresh');
      return false;
    }
    const age = getTimeSinceEpoch(cacheTimestamp);
    const isCacheFresh = age < REMOTE_CONFIG_CACHE_TTL;
    logger.info(`[REMOTE CONFIG] Cache is ${isCacheFresh ? 'fresh' : 'stale'} (age: ${age}ms)`);
    return isCacheFresh;
  };
  const REMOTE_CONFIG_BRAND_KEY = '3';
  let SELECTORS;
  let REMOTE_CONFIG;
  const REMOTE_CONFIG_STORAGE_KEY = 'hermes-sdk-remote-config';
  const REMOTE_CONFIG_TIMESTAMP_STORAGE_KEY = 'hermes-sdk-remote-config-timestamp';
  const REMOTE_CONFIG_CACHE_TTL = 1e3 * 60 * 10;
  const initializeRemoteConfig = async () => {
    const cacheIsFresh = await getIsCacheFresh();
    if (cacheIsFresh) {
      const cachedConfig = await getCachedConfig();
      if (cachedConfig) {
        SELECTORS = cachedConfig.selectors;
        REMOTE_CONFIG = cachedConfig;
        return;
      }
    }
    const liveConfig = await fetchRemoteConfigFromServer();
    SELECTORS = liveConfig.selectors;
    REMOTE_CONFIG = liveConfig;
    await cacheRemoteConfig(liveConfig);
  };
  const API_BASE_URL = config.apiBaseUrl;
  const requestCache = /* @__PURE__ */ new Map();
  async function hashString(str) {
    const encoder = new TextEncoder();
    const data = encoder.encode(str);
    const hashBuffer = await crypto.subtle.digest('SHA-256', data);
    const hashArray = Array.from(new Uint8Array(hashBuffer));
    const hashHex = hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
    return hashHex;
  }
  async function generateRequestKey(method, endpoint, body) {
    const bodyString = JSON.stringify(body);
    const bodyHash = await hashString(bodyString);
    return `${method}:${endpoint}:${bodyHash}`;
  }
  async function fetcher(method, endpoint, body) {
    const requestKey = await generateRequestKey(method, endpoint, body);
    if (requestCache.has(requestKey)) {
      const cachedEntry = requestCache.get(requestKey);
      if ('response' in cachedEntry && cachedEntry.response !== void 0) {
        logger.api(`${method} ${API_BASE_URL + endpoint} (FROM CACHE)`, cachedEntry.response);
        return cachedEntry.response;
      }
      logger.api(`${method} ${API_BASE_URL + endpoint} (WAITING FOR IN-FLIGHT REQUEST)`);
      return cachedEntry.promise;
    }
    logger.api(`${method} ${API_BASE_URL + endpoint} (NEW REQUEST)`, body);
    const fetchPromise = (async () => {
      try {
        const response = await config.options.fetcher(API_BASE_URL + endpoint, {
          method,
          headers: {
            'Content-Type': 'application/json',
            'X-Partner-Key': config.apiKey,
          },
          body: JSON.stringify(body),
        });
        const data = await response.json();
        logger.api(`${method} ${API_BASE_URL + endpoint}`, data);
        const cachedEntry = requestCache.get(requestKey);
        if (cachedEntry) {
          cachedEntry.response = data;
        }
        return data;
      } catch (error) {
        const errorResponse = { error: 'API ERROR' };
        logger.error('Error while fetching data: ', error);
        const cachedEntry = requestCache.get(requestKey);
        if (cachedEntry) {
          cachedEntry.response = errorResponse;
        }
        return errorResponse;
      }
    })();
    requestCache.set(requestKey, {
      promise: fetchPromise,
    });
    return fetchPromise;
  }
  const searchAPI = {
    search: offerData => fetcher('POST', '/search', offerData),
  };
  const SUPPORTED_LANGUAGES = [
    'ar',
    'bg',
    'ca',
    'cs',
    'cz',
    'da',
    'de',
    'el',
    'en',
    'en-GB',
    'es',
    'et',
    'fi',
    'fr',
    'he',
    'hr',
    'hu',
    'id',
    'is',
    'it',
    'iw',
    'ja',
    'ko',
    'lt',
    'lv',
    'ms',
    'nl',
    'no',
    'nb',
    'nn',
    'pl',
    'pt',
    'pt-BR',
    'ro',
    'ru',
    'sk',
    'sl',
    'sr',
    'sv',
    'th',
    'tl',
    'tr',
    'uk',
    'vi',
    'zh',
    'zh-CN',
    'zh-TW',
    'zh-HK',
  ];
  const DEFAULT_LANGUAGE = 'en';
  const isSupportedLanguage = language => SUPPORTED_LANGUAGES.includes(language);
  const getSupportedLanguageCode = language => {
    if (isSupportedLanguage(language)) {
      return language;
    }
    const shortLanguageCode = language?.split('-')[0];
    if (isSupportedLanguage(shortLanguageCode)) {
      return shortLanguageCode;
    }
    return DEFAULT_LANGUAGE;
  };
  const byteToHex = [];
  for (let i = 0; i < 256; ++i) {
    byteToHex.push((i + 256).toString(16).slice(1));
  }
  function unsafeStringify(arr2, offset = 0) {
    return (
      byteToHex[arr2[offset + 0]] +
      byteToHex[arr2[offset + 1]] +
      byteToHex[arr2[offset + 2]] +
      byteToHex[arr2[offset + 3]] +
      '-' +
      byteToHex[arr2[offset + 4]] +
      byteToHex[arr2[offset + 5]] +
      '-' +
      byteToHex[arr2[offset + 6]] +
      byteToHex[arr2[offset + 7]] +
      '-' +
      byteToHex[arr2[offset + 8]] +
      byteToHex[arr2[offset + 9]] +
      '-' +
      byteToHex[arr2[offset + 10]] +
      byteToHex[arr2[offset + 11]] +
      byteToHex[arr2[offset + 12]] +
      byteToHex[arr2[offset + 13]] +
      byteToHex[arr2[offset + 14]] +
      byteToHex[arr2[offset + 15]]
    ).toLowerCase();
  }
  let getRandomValues;
  const rnds8 = new Uint8Array(16);
  function rng() {
    if (!getRandomValues) {
      if (typeof crypto === 'undefined' || !crypto.getRandomValues) {
        throw new Error(
          'crypto.getRandomValues() not supported. See https://github.com/uuidjs/uuid#getrandomvalues-not-supported',
        );
      }
      getRandomValues = crypto.getRandomValues.bind(crypto);
    }
    return getRandomValues(rnds8);
  }
  const randomUUID = typeof crypto !== 'undefined' && crypto.randomUUID && crypto.randomUUID.bind(crypto);
  const native = { randomUUID };
  function v4(options2, buf, offset) {
    if (native.randomUUID && true && !options2) {
      return native.randomUUID();
    }
    options2 = options2 || {};
    const rnds = options2.random ?? options2.rng?.() ?? rng();
    if (rnds.length < 16) {
      throw new Error('Random bytes length must be >= 16');
    }
    rnds[6] = (rnds[6] & 15) | 64;
    rnds[8] = (rnds[8] & 63) | 128;
    return unsafeStringify(rnds);
  }
  const generateAnonymousId = () => v4();
  const persistAnonymousId = async anonymousId => {
    await chrome.storage.sync.set({ anonymousId });
  };
  const getOrGenerateAnonymousId = async () => {
    const { anonymousId } = await chrome.storage.sync.get('anonymousId');
    if (!anonymousId) {
      const newAnonymousId = generateAnonymousId();
      void persistAnonymousId(newAnonymousId);
      return newAnonymousId;
    }
    return anonymousId;
  };
  var TrackingCategory = /* @__PURE__ */ (TrackingCategory2 => {
    TrackingCategory2['System'] = 'System';
    TrackingCategory2['User'] = 'User';
    return TrackingCategory2;
  })(TrackingCategory || {});
  var TrackingEntity = /* @__PURE__ */ (TrackingEntity2 => {
    TrackingEntity2['InlineButton'] = 'InlineButton';
    TrackingEntity2['TargetedPage'] = 'TargetedPage';
    TrackingEntity2['Popup'] = 'Popup';
    return TrackingEntity2;
  })(TrackingEntity || {});
  var TrackingAction = /* @__PURE__ */ (TrackingAction2 => {
    TrackingAction2['Displayed'] = 'Displayed';
    TrackingAction2['Viewed'] = 'Viewed';
    return TrackingAction2;
  })(TrackingAction || {});
  const IMPRESSION_TIMEOUT = 1e3;
  const IMPRESSION_THRESHOLD = 1;
  const elementStateMap = /* @__PURE__ */ new WeakMap();
  const impressionObserver = new IntersectionObserver(
    (entries, observer) => {
      entries.forEach(entry => {
        const element = entry.target;
        const state = elementStateMap.get(element);
        if (!state) {
          return;
        }
        if (entry.isIntersecting) {
          const timeoutId = setTimeout(() => {
            state.callback();
            elementStateMap.delete(element);
            observer.unobserve(element);
          }, IMPRESSION_TIMEOUT);
          state.timeoutId = timeoutId;
        } else {
          if (state.timeoutId) {
            clearTimeout(state.timeoutId);
            state.timeoutId = void 0;
          }
        }
      });
    },
    { threshold: IMPRESSION_THRESHOLD },
  );
  const observeImpression = (element, callback) => {
    elementStateMap.set(element, { callback });
    impressionObserver.observe(element);
  };
  class TrackingService {
    constructor() {
      __publicField(this, 'anonymousId', '');
      __publicField(this, 'affiliateName', 'karmanow');
      __publicField(this, 'sdkVersion', '1.0.3');
      __publicField(this, 'pageContext', {
        pageUrl: '',
        pagePath: '',
        pageDomain: '',
        pageType: '',
      });
      __publicField(this, 'searchContext', {
        checkIn: '',
        checkOut: '',
        rooms: '',
        numberOfAdults: 0,
        numberOfChildren: 0,
        query: {},
      });
    }
    async init() {
      this.anonymousId = await getOrGenerateAnonymousId();
    }
    getAnonymousId() {
      return this.anonymousId;
    }
    addToPageContext(pageContext) {
      this.pageContext = {
        ...this.pageContext,
        ...pageContext,
      };
    }
    addToSearchContext(searchContext) {
      this.searchContext = {
        ...this.searchContext,
        ...searchContext,
      };
    }
    async track(eventProperties) {
      const name = [eventProperties.category, eventProperties.entity, eventProperties.action].filter(Boolean).join('_');
      return config.options.fetcher(config.trackingUrl, {
        headers: {
          accept: '*/*',
          'content-type': 'application/json',
          'x-api-key': config.trackingKey,
        },
        method: 'POST',
        body: JSON.stringify({
          properties: {
            ...eventProperties,
            anonymousId: this.anonymousId,
            name,
          },
        }),
      });
    }
    async trackPageDisplayed(isEnabled, isEnabledByUser) {
      return this.track({
        category: TrackingCategory.System,
        entity: TrackingEntity.TargetedPage,
        action: TrackingAction.Displayed,
        analyticsContext: {
          pageContext: this.pageContext,
        },
        payload: {
          anonymousId: this.anonymousId,
          affiliateName: this.affiliateName,
          isEnabled,
          sdkVersion: this.sdkVersion,
          isEnabledByUser,
        },
      });
    }
    async trackInlineButtonViewed({ offerContext, hotelContext }) {
      return this.track({
        category: TrackingCategory.User,
        entity: TrackingEntity.InlineButton,
        action: TrackingAction.Viewed,
        analyticsContext: {
          pageContext: this.pageContext,
          searchContext: this.searchContext,
          hotelContext,
          offerContext,
        },
        payload: {
          anonymousId: this.anonymousId,
          affiliateName: this.affiliateName,
          sdkVersion: this.sdkVersion,
        },
      });
    }
    async trackPopupDisplayed(hotelContext) {
      return this.track({
        category: TrackingCategory.System,
        entity: TrackingEntity.Popup,
        action: TrackingAction.Displayed,
        analyticsContext: {
          pageContext: this.pageContext,
          searchContext: this.searchContext,
          hotelContext,
        },
        payload: {
          anonymousId: this.anonymousId,
          affiliateName: this.affiliateName,
          sdkVersion: this.sdkVersion,
        },
      });
    }
  }
  const tracking = new TrackingService();
  const getCurrentEnv = () => {
    switch (true) {
      case false:
        return 'dev';
      case false:
        return 'demo';
      default:
        return 'prod';
    }
  };
  const getHighOrderDomainFromHostname = hostname => {
    const subdomains = hostname.split('.');
    return subdomains[subdomains.length - 2] + '.' + subdomains[subdomains.length - 1];
  };
  const getCurrentDomainFromLocation = () => {
    const hostname = window.location.hostname;
    return getHighOrderDomainFromHostname(hostname);
  };
  const getFormattedPlatformName = ({ currentDomain }) => {
    const platform = Object.values(REMOTE_CONFIG.domains).find(domain => domain.domains.includes(currentDomain));
    if (!platform) {
      return currentDomain.charAt(0).toUpperCase() + currentDomain.slice(1);
    }
    return platform.label;
  };
  const getCurrentPlatformNameFromLocation = () => {
    const currentDomain = getCurrentDomainFromLocation();
    return getFormattedPlatformName({ currentDomain });
  };
  const DEFAULT_CHILD_AGE = 8;
  const OPTIMIZE_ROOMS_LIMIT = 4;
  const getUnifiedChildrenAges = (children, childrenAges) => {
    if (childrenAges?.length !== void 0 && childrenAges.length === children) {
      logger.info('Using children array from site data for room configuration:', childrenAges);
      return childrenAges;
    } else {
      logger.info(
        `Using fallback method for children calculation. Default age for every child: ${DEFAULT_CHILD_AGE} Number of children: ${children}`,
      );
      return Array(children).fill(DEFAULT_CHILD_AGE);
    }
  };
  const getAveragedRoomsConfiguration = ({ adults, children, childrenAges, rooms }) => {
    const unifiedChildrenAges = getUnifiedChildrenAges(children, childrenAges);
    if (rooms === 1) {
      return `${adults}${unifiedChildrenAges.length > 0 ? `:${unifiedChildrenAges.join(',')}` : ''}`;
    }
    const roomsConfigurations = [];
    const averageAdultsPerRoom = Math.round(adults / rooms);
    const averageChildrenPerRoom = Math.round(unifiedChildrenAges.length / rooms);
    for (let i = 0; i < rooms; i++) {
      if (i === rooms - 1) {
        const room2 = `${adults - averageAdultsPerRoom * (rooms - 1)}`;
        roomsConfigurations.push(room2);
        break;
      }
      const room = `${averageAdultsPerRoom}`;
      roomsConfigurations.push(room);
    }
    for (let i = 0; i < roomsConfigurations.length; i++) {
      if (unifiedChildrenAges.length === 0) {
        break;
      }
      if (i === roomsConfigurations.length - 1) {
        const lastChildrenAges = unifiedChildrenAges.slice(i * averageChildrenPerRoom).join(',');
        roomsConfigurations[i] += lastChildrenAges ? `:${lastChildrenAges}` : '';
        break;
      }
      const childrenAges2 = unifiedChildrenAges
        .slice(i * averageChildrenPerRoom, (i + 1) * averageChildrenPerRoom)
        .join(',');
      roomsConfigurations[i] += childrenAges2 ? `:${childrenAges2}` : '';
    }
    return roomsConfigurations.join('|');
  };
  const getOptimizedRoomsConfiguration = ({ adults, children, childrenAges }) => {
    const adultsCount = adults?.toString();
    let roomConfiguration = adultsCount;
    const childrenCount = Number(children);
    const childrenAgesArray = getUnifiedChildrenAges(childrenCount, childrenAges);
    const childrenAgesString = childrenAgesArray.join(',');
    if (childrenAgesString.length > 0) {
      roomConfiguration = `${roomConfiguration}:${childrenAgesString}`;
    }
    return roomConfiguration;
  };
  const ELEMENTS_ATTRIBUTES = {
    BADGE_ID: 'data-badge-id',
  };
  const openPopup = hotelContext => {
    const popup = document.getElementById('hermes-popup');
    if (!popup) {
      logger.error('Popup not found');
      return;
    }
    popup.classList.add('hermes-popup-visible');
    void tracking.trackPopupDisplayed(hotelContext || {});
  };
  const bestPrice$1 = 'Best price';
  const bestPriceOnPlatform$1 = 'Best price on {platform}';
  const betterDeal$1 = 'Better deal';
  const checkingDeals$1 = 'Checking deals';
  const compareBestPrices$1 = 'Compare best prices';
  const exclTaxAndFees$1 = 'excl tax & fees';
  const inclFees$1 = 'incl fees';
  const inclTaxAndFees$1 = 'incl tax & fees';
  const night$1 = 'night';
  const off$1 = 'Off';
  const on$1 = 'On';
  const onCurrentPlatform$1 = 'On {platform}';
  const roomCount$1 = '{count} x {roomName}';
  const roomPrice$1 = 'room price';
  const roomsAndNightsAndGuests$1 =
    '{nights, plural, one {1 night} other {# nights}} · {rooms, plural, one {1 room} other {# rooms}} · {guests, plural, one {1 guest} other {# guests}}';
  const toggleExtension$1 = 'Toggle extension';
  const total$1 = 'total';
  const viewDeal$1 = 'View Deal';
  const withoutTaxAndFees$1 = 'without tax & fees';
  const youCanSavePerNight$1 = 'You can save <span class="hermes-popup-discount">{price}</span> / night!';
  const youCanSaveTitle$1 = 'You can save <span class="hermes-popup-discount">{price}!</span>';
  const youCanSaveTotal$1 = 'You can save <span class="hermes-popup-discount">{price}</span>';
  const youveGotTheBestPrice$1 = `You've got <span class="hermes-popup-discount">the best price!</span>`;
  const enUS = {
    bestPrice: bestPrice$1,
    bestPriceOnPlatform: bestPriceOnPlatform$1,
    betterDeal: betterDeal$1,
    checkingDeals: checkingDeals$1,
    compareBestPrices: compareBestPrices$1,
    exclTaxAndFees: exclTaxAndFees$1,
    inclFees: inclFees$1,
    inclTaxAndFees: inclTaxAndFees$1,
    night: night$1,
    off: off$1,
    on: on$1,
    onCurrentPlatform: onCurrentPlatform$1,
    roomCount: roomCount$1,
    roomPrice: roomPrice$1,
    roomsAndNightsAndGuests: roomsAndNightsAndGuests$1,
    toggleExtension: toggleExtension$1,
    total: total$1,
    viewDeal: viewDeal$1,
    withoutTaxAndFees: withoutTaxAndFees$1,
    youCanSavePerNight: youCanSavePerNight$1,
    youCanSaveTitle: youCanSaveTitle$1,
    youCanSaveTotal: youCanSaveTotal$1,
    youveGotTheBestPrice: youveGotTheBestPrice$1,
  };
  const __vite_glob_0_0 = /* @__PURE__ */ Object.freeze(
    /* @__PURE__ */ Object.defineProperty(
      {
        __proto__: null,
        bestPrice: bestPrice$1,
        bestPriceOnPlatform: bestPriceOnPlatform$1,
        betterDeal: betterDeal$1,
        checkingDeals: checkingDeals$1,
        compareBestPrices: compareBestPrices$1,
        default: enUS,
        exclTaxAndFees: exclTaxAndFees$1,
        inclFees: inclFees$1,
        inclTaxAndFees: inclTaxAndFees$1,
        night: night$1,
        off: off$1,
        on: on$1,
        onCurrentPlatform: onCurrentPlatform$1,
        roomCount: roomCount$1,
        roomPrice: roomPrice$1,
        roomsAndNightsAndGuests: roomsAndNightsAndGuests$1,
        toggleExtension: toggleExtension$1,
        total: total$1,
        viewDeal: viewDeal$1,
        withoutTaxAndFees: withoutTaxAndFees$1,
        youCanSavePerNight: youCanSavePerNight$1,
        youCanSaveTitle: youCanSaveTitle$1,
        youCanSaveTotal: youCanSaveTotal$1,
        youveGotTheBestPrice: youveGotTheBestPrice$1,
      },
      Symbol.toStringTag,
      { value: 'Module' },
    ),
  );
  const bestPrice = 'Meilleur prix';
  const bestPriceOnPlatform = 'Meilleur prix sur {platform}';
  const betterDeal = 'Meilleure offre';
  const checkingDeals = 'Recherche des offres';
  const compareBestPrices = 'Comparez les meilleurs prix';
  const exclTaxAndFees = 'hors taxes et frais';
  const inclFees = 'frais inclus';
  const inclTaxAndFees = 'taxes et frais inclus';
  const night = 'nuit';
  const off = 'Off';
  const on = 'On';
  const onCurrentPlatform = 'Sur {platform}';
  const roomCount = '{count} x {roomName}';
  const roomPrice = 'prix de la chambre';
  const roomsAndNightsAndGuests =
    '{nights,plural,one{1 nuit} other{# nuits} many{# de nuits}} · {rooms,plural,one{1 chambre} other{# chambres} many{# de chambres}} · {guests,plural,one{1 voyageur} other{# voyageurs} many{# de voyageurs}}';
  const toggleExtension = "Activer l'extension";
  const total = 'total';
  const viewDeal = "Voir l'offre";
  const withoutTaxAndFees = 'taxes et frais non inclus';
  const youCanSavePerNight = 'Vous pouvez économiser <span class="hermes-popup-discount">{price}</span> / nuit !';
  const youCanSaveTitle = 'Vous pouvez économiser <span class="hermes-popup-discount">{price} !</span>';
  const youCanSaveTotal = 'Vous pouvez économiser <span class="hermes-popup-discount">{price}</span>';
  const youveGotTheBestPrice = 'Vous bénéficiez <span class="hermes-popup-discount">du meilleur prix !</span>';
  const frFR = {
    bestPrice,
    bestPriceOnPlatform,
    betterDeal,
    checkingDeals,
    compareBestPrices,
    exclTaxAndFees,
    inclFees,
    inclTaxAndFees,
    night,
    off,
    on,
    onCurrentPlatform,
    roomCount,
    roomPrice,
    roomsAndNightsAndGuests,
    toggleExtension,
    total,
    viewDeal,
    withoutTaxAndFees,
    youCanSavePerNight,
    youCanSaveTitle,
    youCanSaveTotal,
    youveGotTheBestPrice,
  };
  const __vite_glob_0_1 = /* @__PURE__ */ Object.freeze(
    /* @__PURE__ */ Object.defineProperty(
      {
        __proto__: null,
        bestPrice,
        bestPriceOnPlatform,
        betterDeal,
        checkingDeals,
        compareBestPrices,
        default: frFR,
        exclTaxAndFees,
        inclFees,
        inclTaxAndFees,
        night,
        off,
        on,
        onCurrentPlatform,
        roomCount,
        roomPrice,
        roomsAndNightsAndGuests,
        toggleExtension,
        total,
        viewDeal,
        withoutTaxAndFees,
        youCanSavePerNight,
        youCanSaveTitle,
        youCanSaveTotal,
        youveGotTheBestPrice,
      },
      Symbol.toStringTag,
      { value: 'Module' },
    ),
  );
  const isString = obj => typeof obj === 'string';
  const defer = () => {
    let res;
    let rej;
    const promise = new Promise((resolve, reject) => {
      res = resolve;
      rej = reject;
    });
    promise.resolve = res;
    promise.reject = rej;
    return promise;
  };
  const makeString = object => {
    if (object == null) return '';
    return '' + object;
  };
  const copy = (a, s, t) => {
    a.forEach(m => {
      if (s[m]) t[m] = s[m];
    });
  };
  const lastOfPathSeparatorRegExp = /###/g;
  const cleanKey = key => (key && key.indexOf('###') > -1 ? key.replace(lastOfPathSeparatorRegExp, '.') : key);
  const canNotTraverseDeeper = object => !object || isString(object);
  const getLastOfPath$1 = (object, path, Empty) => {
    const stack = !isString(path) ? path : path.split('.');
    let stackIndex = 0;
    while (stackIndex < stack.length - 1) {
      if (canNotTraverseDeeper(object)) return {};
      const key = cleanKey(stack[stackIndex]);
      if (!object[key] && Empty) object[key] = new Empty();
      if (Object.prototype.hasOwnProperty.call(object, key)) {
        object = object[key];
      } else {
        object = {};
      }
      ++stackIndex;
    }
    if (canNotTraverseDeeper(object)) return {};
    return {
      obj: object,
      k: cleanKey(stack[stackIndex]),
    };
  };
  const setPath$1 = (object, path, newValue) => {
    const { obj, k } = getLastOfPath$1(object, path, Object);
    if (obj !== void 0 || path.length === 1) {
      obj[k] = newValue;
      return;
    }
    let e = path[path.length - 1];
    let p = path.slice(0, path.length - 1);
    let last = getLastOfPath$1(object, p, Object);
    while (last.obj === void 0 && p.length) {
      e = `${p[p.length - 1]}.${e}`;
      p = p.slice(0, p.length - 1);
      last = getLastOfPath$1(object, p, Object);
      if (last?.obj && typeof last.obj[`${last.k}.${e}`] !== 'undefined') {
        last.obj = void 0;
      }
    }
    last.obj[`${last.k}.${e}`] = newValue;
  };
  const pushPath = (object, path, newValue, concat) => {
    const { obj, k } = getLastOfPath$1(object, path, Object);
    obj[k] = obj[k] || [];
    obj[k].push(newValue);
  };
  const getPath$1 = (object, path) => {
    const { obj, k } = getLastOfPath$1(object, path);
    if (!obj) return void 0;
    if (!Object.prototype.hasOwnProperty.call(obj, k)) return void 0;
    return obj[k];
  };
  const getPathWithDefaults = (data, defaultData, key) => {
    const value = getPath$1(data, key);
    if (value !== void 0) {
      return value;
    }
    return getPath$1(defaultData, key);
  };
  const deepExtend = (target, source, overwrite) => {
    for (const prop in source) {
      if (prop !== '__proto__' && prop !== 'constructor') {
        if (prop in target) {
          if (
            isString(target[prop]) ||
            target[prop] instanceof String ||
            isString(source[prop]) ||
            source[prop] instanceof String
          ) {
            if (overwrite) target[prop] = source[prop];
          } else {
            deepExtend(target[prop], source[prop], overwrite);
          }
        } else {
          target[prop] = source[prop];
        }
      }
    }
    return target;
  };
  const regexEscape = str => str.replace(/[\-\[\]\/\{\}\(\)\*\+\?\.\\\^\$\|]/g, '\\$&');
  var _entityMap = {
    '&': '&amp;',
    '<': '&lt;',
    '>': '&gt;',
    '"': '&quot;',
    "'": '&#39;',
    '/': '&#x2F;',
  };
  const escape = data => {
    if (isString(data)) {
      return data.replace(/[&<>"'\/]/g, s => _entityMap[s]);
    }
    return data;
  };
  class RegExpCache {
    constructor(capacity) {
      this.capacity = capacity;
      this.regExpMap = /* @__PURE__ */ new Map();
      this.regExpQueue = [];
    }
    getRegExp(pattern) {
      const regExpFromCache = this.regExpMap.get(pattern);
      if (regExpFromCache !== void 0) {
        return regExpFromCache;
      }
      const regExpNew = new RegExp(pattern);
      if (this.regExpQueue.length === this.capacity) {
        this.regExpMap.delete(this.regExpQueue.shift());
      }
      this.regExpMap.set(pattern, regExpNew);
      this.regExpQueue.push(pattern);
      return regExpNew;
    }
  }
  const chars = [' ', ',', '?', '!', ';'];
  const looksLikeObjectPathRegExpCache = new RegExpCache(20);
  const looksLikeObjectPath = (key, nsSeparator, keySeparator) => {
    nsSeparator = nsSeparator || '';
    keySeparator = keySeparator || '';
    const possibleChars = chars.filter(c => nsSeparator.indexOf(c) < 0 && keySeparator.indexOf(c) < 0);
    if (possibleChars.length === 0) return true;
    const r = looksLikeObjectPathRegExpCache.getRegExp(
      `(${possibleChars.map(c => (c === '?' ? '\\?' : c)).join('|')})`,
    );
    let matched = !r.test(key);
    if (!matched) {
      const ki = key.indexOf(keySeparator);
      if (ki > 0 && !r.test(key.substring(0, ki))) {
        matched = true;
      }
    }
    return matched;
  };
  const deepFind = (obj, path, keySeparator = '.') => {
    if (!obj) return void 0;
    if (obj[path]) {
      if (!Object.prototype.hasOwnProperty.call(obj, path)) return void 0;
      return obj[path];
    }
    const tokens = path.split(keySeparator);
    let current = obj;
    for (let i = 0; i < tokens.length; ) {
      if (!current || typeof current !== 'object') {
        return void 0;
      }
      let next;
      let nextPath = '';
      for (let j = i; j < tokens.length; ++j) {
        if (j !== i) {
          nextPath += keySeparator;
        }
        nextPath += tokens[j];
        next = current[nextPath];
        if (next !== void 0) {
          if (['string', 'number', 'boolean'].indexOf(typeof next) > -1 && j < tokens.length - 1) {
            continue;
          }
          i += j - i + 1;
          break;
        }
      }
      current = next;
    }
    return current;
  };
  const getCleanedCode = code => code?.replace('_', '-');
  const consoleLogger = {
    type: 'logger',
    log(args) {
      this.output('log', args);
    },
    warn(args) {
      this.output('warn', args);
    },
    error(args) {
      this.output('error', args);
    },
    output(type, args) {
      console?.[type]?.apply?.(console, args);
    },
  };
  class Logger {
    constructor(concreteLogger, options2 = {}) {
      this.init(concreteLogger, options2);
    }
    init(concreteLogger, options2 = {}) {
      this.prefix = options2.prefix || 'i18next:';
      this.logger = concreteLogger || consoleLogger;
      this.options = options2;
      this.debug = options2.debug;
    }
    log(...args) {
      return this.forward(args, 'log', '', true);
    }
    warn(...args) {
      return this.forward(args, 'warn', '', true);
    }
    error(...args) {
      return this.forward(args, 'error', '');
    }
    deprecate(...args) {
      return this.forward(args, 'warn', 'WARNING DEPRECATED: ', true);
    }
    forward(args, lvl, prefix, debugOnly) {
      if (debugOnly && !this.debug) return null;
      if (isString(args[0])) args[0] = `${prefix}${this.prefix} ${args[0]}`;
      return this.logger[lvl](args);
    }
    create(moduleName) {
      return new Logger(this.logger, {
        ...{
          prefix: `${this.prefix}:${moduleName}:`,
        },
        ...this.options,
      });
    }
    clone(options2) {
      options2 = options2 || this.options;
      options2.prefix = options2.prefix || this.prefix;
      return new Logger(this.logger, options2);
    }
  }
  var baseLogger = new Logger();
  class EventEmitter {
    constructor() {
      this.observers = {};
    }
    on(events, listener) {
      events.split(' ').forEach(event => {
        if (!this.observers[event]) this.observers[event] = /* @__PURE__ */ new Map();
        const numListeners = this.observers[event].get(listener) || 0;
        this.observers[event].set(listener, numListeners + 1);
      });
      return this;
    }
    off(event, listener) {
      if (!this.observers[event]) return;
      if (!listener) {
        delete this.observers[event];
        return;
      }
      this.observers[event].delete(listener);
    }
    emit(event, ...args) {
      if (this.observers[event]) {
        const cloned = Array.from(this.observers[event].entries());
        cloned.forEach(([observer, numTimesAdded]) => {
          for (let i = 0; i < numTimesAdded; i++) {
            observer(...args);
          }
        });
      }
      if (this.observers['*']) {
        const cloned = Array.from(this.observers['*'].entries());
        cloned.forEach(([observer, numTimesAdded]) => {
          for (let i = 0; i < numTimesAdded; i++) {
            observer.apply(observer, [event, ...args]);
          }
        });
      }
    }
  }
  class ResourceStore extends EventEmitter {
    constructor(
      data,
      options2 = {
        ns: ['translation'],
        defaultNS: 'translation',
      },
    ) {
      super();
      this.data = data || {};
      this.options = options2;
      if (this.options.keySeparator === void 0) {
        this.options.keySeparator = '.';
      }
      if (this.options.ignoreJSONStructure === void 0) {
        this.options.ignoreJSONStructure = true;
      }
    }
    addNamespaces(ns) {
      if (this.options.ns.indexOf(ns) < 0) {
        this.options.ns.push(ns);
      }
    }
    removeNamespaces(ns) {
      const index = this.options.ns.indexOf(ns);
      if (index > -1) {
        this.options.ns.splice(index, 1);
      }
    }
    getResource(lng, ns, key, options2 = {}) {
      const keySeparator = options2.keySeparator !== void 0 ? options2.keySeparator : this.options.keySeparator;
      const ignoreJSONStructure =
        options2.ignoreJSONStructure !== void 0 ? options2.ignoreJSONStructure : this.options.ignoreJSONStructure;
      let path;
      if (lng.indexOf('.') > -1) {
        path = lng.split('.');
      } else {
        path = [lng, ns];
        if (key) {
          if (Array.isArray(key)) {
            path.push(...key);
          } else if (isString(key) && keySeparator) {
            path.push(...key.split(keySeparator));
          } else {
            path.push(key);
          }
        }
      }
      const result = getPath$1(this.data, path);
      if (!result && !ns && !key && lng.indexOf('.') > -1) {
        lng = path[0];
        ns = path[1];
        key = path.slice(2).join('.');
      }
      if (result || !ignoreJSONStructure || !isString(key)) return result;
      return deepFind(this.data?.[lng]?.[ns], key, keySeparator);
    }
    addResource(
      lng,
      ns,
      key,
      value,
      options2 = {
        silent: false,
      },
    ) {
      const keySeparator = options2.keySeparator !== void 0 ? options2.keySeparator : this.options.keySeparator;
      let path = [lng, ns];
      if (key) path = path.concat(keySeparator ? key.split(keySeparator) : key);
      if (lng.indexOf('.') > -1) {
        path = lng.split('.');
        value = ns;
        ns = path[1];
      }
      this.addNamespaces(ns);
      setPath$1(this.data, path, value);
      if (!options2.silent) this.emit('added', lng, ns, key, value);
    }
    addResources(
      lng,
      ns,
      resources,
      options2 = {
        silent: false,
      },
    ) {
      for (const m in resources) {
        if (isString(resources[m]) || Array.isArray(resources[m]))
          this.addResource(lng, ns, m, resources[m], {
            silent: true,
          });
      }
      if (!options2.silent) this.emit('added', lng, ns, resources);
    }
    addResourceBundle(
      lng,
      ns,
      resources,
      deep,
      overwrite,
      options2 = {
        silent: false,
        skipCopy: false,
      },
    ) {
      let path = [lng, ns];
      if (lng.indexOf('.') > -1) {
        path = lng.split('.');
        deep = resources;
        resources = ns;
        ns = path[1];
      }
      this.addNamespaces(ns);
      let pack = getPath$1(this.data, path) || {};
      if (!options2.skipCopy) resources = JSON.parse(JSON.stringify(resources));
      if (deep) {
        deepExtend(pack, resources, overwrite);
      } else {
        pack = {
          ...pack,
          ...resources,
        };
      }
      setPath$1(this.data, path, pack);
      if (!options2.silent) this.emit('added', lng, ns, resources);
    }
    removeResourceBundle(lng, ns) {
      if (this.hasResourceBundle(lng, ns)) {
        delete this.data[lng][ns];
      }
      this.removeNamespaces(ns);
      this.emit('removed', lng, ns);
    }
    hasResourceBundle(lng, ns) {
      return this.getResource(lng, ns) !== void 0;
    }
    getResourceBundle(lng, ns) {
      if (!ns) ns = this.options.defaultNS;
      return this.getResource(lng, ns);
    }
    getDataByLanguage(lng) {
      return this.data[lng];
    }
    hasLanguageSomeTranslations(lng) {
      const data = this.getDataByLanguage(lng);
      const n = (data && Object.keys(data)) || [];
      return !!n.find(v => data[v] && Object.keys(data[v]).length > 0);
    }
    toJSON() {
      return this.data;
    }
  }
  var postProcessor = {
    processors: {},
    addPostProcessor(module) {
      this.processors[module.name] = module;
    },
    handle(processors, value, key, options2, translator) {
      processors.forEach(processor => {
        value = this.processors[processor]?.process(value, key, options2, translator) ?? value;
      });
      return value;
    },
  };
  const checkedLoadedFor = {};
  const shouldHandleAsObject = res => !isString(res) && typeof res !== 'boolean' && typeof res !== 'number';
  class Translator extends EventEmitter {
    constructor(services, options2 = {}) {
      super();
      copy(
        ['resourceStore', 'languageUtils', 'pluralResolver', 'interpolator', 'backendConnector', 'i18nFormat', 'utils'],
        services,
        this,
      );
      this.options = options2;
      if (this.options.keySeparator === void 0) {
        this.options.keySeparator = '.';
      }
      this.logger = baseLogger.create('translator');
    }
    changeLanguage(lng) {
      if (lng) this.language = lng;
    }
    exists(
      key,
      o = {
        interpolation: {},
      },
    ) {
      const opt = {
        ...o,
      };
      if (key == null) return false;
      const resolved = this.resolve(key, opt);
      return resolved?.res !== void 0;
    }
    extractFromKey(key, opt) {
      let nsSeparator = opt.nsSeparator !== void 0 ? opt.nsSeparator : this.options.nsSeparator;
      if (nsSeparator === void 0) nsSeparator = ':';
      const keySeparator = opt.keySeparator !== void 0 ? opt.keySeparator : this.options.keySeparator;
      let namespaces = opt.ns || this.options.defaultNS || [];
      const wouldCheckForNsInKey = nsSeparator && key.indexOf(nsSeparator) > -1;
      const seemsNaturalLanguage =
        !this.options.userDefinedKeySeparator &&
        !opt.keySeparator &&
        !this.options.userDefinedNsSeparator &&
        !opt.nsSeparator &&
        !looksLikeObjectPath(key, nsSeparator, keySeparator);
      if (wouldCheckForNsInKey && !seemsNaturalLanguage) {
        const m = key.match(this.interpolator.nestingRegexp);
        if (m && m.length > 0) {
          return {
            key,
            namespaces: isString(namespaces) ? [namespaces] : namespaces,
          };
        }
        const parts = key.split(nsSeparator);
        if (nsSeparator !== keySeparator || (nsSeparator === keySeparator && this.options.ns.indexOf(parts[0]) > -1))
          namespaces = parts.shift();
        key = parts.join(keySeparator);
      }
      return {
        key,
        namespaces: isString(namespaces) ? [namespaces] : namespaces,
      };
    }
    translate(keys, o, lastKey) {
      let opt =
        typeof o === 'object'
          ? {
              ...o,
            }
          : o;
      if (typeof opt !== 'object' && this.options.overloadTranslationOptionHandler) {
        opt = this.options.overloadTranslationOptionHandler(arguments);
      }
      if (typeof options === 'object')
        opt = {
          ...opt,
        };
      if (!opt) opt = {};
      if (keys == null) return '';
      if (!Array.isArray(keys)) keys = [String(keys)];
      const returnDetails = opt.returnDetails !== void 0 ? opt.returnDetails : this.options.returnDetails;
      const keySeparator = opt.keySeparator !== void 0 ? opt.keySeparator : this.options.keySeparator;
      const { key, namespaces } = this.extractFromKey(keys[keys.length - 1], opt);
      const namespace = namespaces[namespaces.length - 1];
      let nsSeparator = opt.nsSeparator !== void 0 ? opt.nsSeparator : this.options.nsSeparator;
      if (nsSeparator === void 0) nsSeparator = ':';
      const lng = opt.lng || this.language;
      const appendNamespaceToCIMode = opt.appendNamespaceToCIMode || this.options.appendNamespaceToCIMode;
      if (lng?.toLowerCase() === 'cimode') {
        if (appendNamespaceToCIMode) {
          if (returnDetails) {
            return {
              res: `${namespace}${nsSeparator}${key}`,
              usedKey: key,
              exactUsedKey: key,
              usedLng: lng,
              usedNS: namespace,
              usedParams: this.getUsedParamsDetails(opt),
            };
          }
          return `${namespace}${nsSeparator}${key}`;
        }
        if (returnDetails) {
          return {
            res: key,
            usedKey: key,
            exactUsedKey: key,
            usedLng: lng,
            usedNS: namespace,
            usedParams: this.getUsedParamsDetails(opt),
          };
        }
        return key;
      }
      const resolved = this.resolve(keys, opt);
      let res = resolved?.res;
      const resUsedKey = resolved?.usedKey || key;
      const resExactUsedKey = resolved?.exactUsedKey || key;
      const noObject = ['[object Number]', '[object Function]', '[object RegExp]'];
      const joinArrays = opt.joinArrays !== void 0 ? opt.joinArrays : this.options.joinArrays;
      const handleAsObjectInI18nFormat = !this.i18nFormat || this.i18nFormat.handleAsObject;
      const needsPluralHandling = opt.count !== void 0 && !isString(opt.count);
      const hasDefaultValue = Translator.hasDefaultValue(opt);
      const defaultValueSuffix = needsPluralHandling ? this.pluralResolver.getSuffix(lng, opt.count, opt) : '';
      const defaultValueSuffixOrdinalFallback =
        opt.ordinal && needsPluralHandling
          ? this.pluralResolver.getSuffix(lng, opt.count, {
              ordinal: false,
            })
          : '';
      const needsZeroSuffixLookup = needsPluralHandling && !opt.ordinal && opt.count === 0;
      const defaultValue =
        (needsZeroSuffixLookup && opt[`defaultValue${this.options.pluralSeparator}zero`]) ||
        opt[`defaultValue${defaultValueSuffix}`] ||
        opt[`defaultValue${defaultValueSuffixOrdinalFallback}`] ||
        opt.defaultValue;
      let resForObjHndl = res;
      if (handleAsObjectInI18nFormat && !res && hasDefaultValue) {
        resForObjHndl = defaultValue;
      }
      const handleAsObject = shouldHandleAsObject(resForObjHndl);
      const resType = Object.prototype.toString.apply(resForObjHndl);
      if (
        handleAsObjectInI18nFormat &&
        resForObjHndl &&
        handleAsObject &&
        noObject.indexOf(resType) < 0 &&
        !(isString(joinArrays) && Array.isArray(resForObjHndl))
      ) {
        if (!opt.returnObjects && !this.options.returnObjects) {
          if (!this.options.returnedObjectHandler) {
            this.logger.warn('accessing an object - but returnObjects options is not enabled!');
          }
          const r = this.options.returnedObjectHandler
            ? this.options.returnedObjectHandler(resUsedKey, resForObjHndl, {
                ...opt,
                ns: namespaces,
              })
            : `key '${key} (${this.language})' returned an object instead of string.`;
          if (returnDetails) {
            resolved.res = r;
            resolved.usedParams = this.getUsedParamsDetails(opt);
            return resolved;
          }
          return r;
        }
        if (keySeparator) {
          const resTypeIsArray = Array.isArray(resForObjHndl);
          const copy2 = resTypeIsArray ? [] : {};
          const newKeyToUse = resTypeIsArray ? resExactUsedKey : resUsedKey;
          for (const m in resForObjHndl) {
            if (Object.prototype.hasOwnProperty.call(resForObjHndl, m)) {
              const deepKey = `${newKeyToUse}${keySeparator}${m}`;
              if (hasDefaultValue && !res) {
                copy2[m] = this.translate(deepKey, {
                  ...opt,
                  defaultValue: shouldHandleAsObject(defaultValue) ? defaultValue[m] : void 0,
                  ...{
                    joinArrays: false,
                    ns: namespaces,
                  },
                });
              } else {
                copy2[m] = this.translate(deepKey, {
                  ...opt,
                  ...{
                    joinArrays: false,
                    ns: namespaces,
                  },
                });
              }
              if (copy2[m] === deepKey) copy2[m] = resForObjHndl[m];
            }
          }
          res = copy2;
        }
      } else if (handleAsObjectInI18nFormat && isString(joinArrays) && Array.isArray(res)) {
        res = res.join(joinArrays);
        if (res) res = this.extendTranslation(res, keys, opt, lastKey);
      } else {
        let usedDefault = false;
        let usedKey = false;
        if (!this.isValidLookup(res) && hasDefaultValue) {
          usedDefault = true;
          res = defaultValue;
        }
        if (!this.isValidLookup(res)) {
          usedKey = true;
          res = key;
        }
        const missingKeyNoValueFallbackToKey =
          opt.missingKeyNoValueFallbackToKey || this.options.missingKeyNoValueFallbackToKey;
        const resForMissing = missingKeyNoValueFallbackToKey && usedKey ? void 0 : res;
        const updateMissing = hasDefaultValue && defaultValue !== res && this.options.updateMissing;
        if (usedKey || usedDefault || updateMissing) {
          this.logger.log(
            updateMissing ? 'updateKey' : 'missingKey',
            lng,
            namespace,
            key,
            updateMissing ? defaultValue : res,
          );
          if (keySeparator) {
            const fk = this.resolve(key, {
              ...opt,
              keySeparator: false,
            });
            if (fk && fk.res)
              this.logger.warn(
                'Seems the loaded translations were in flat JSON format instead of nested. Either set keySeparator: false on init or make sure your translations are published in nested format.',
              );
          }
          let lngs = [];
          const fallbackLngs = this.languageUtils.getFallbackCodes(this.options.fallbackLng, opt.lng || this.language);
          if (this.options.saveMissingTo === 'fallback' && fallbackLngs && fallbackLngs[0]) {
            for (let i = 0; i < fallbackLngs.length; i++) {
              lngs.push(fallbackLngs[i]);
            }
          } else if (this.options.saveMissingTo === 'all') {
            lngs = this.languageUtils.toResolveHierarchy(opt.lng || this.language);
          } else {
            lngs.push(opt.lng || this.language);
          }
          const send = (l, k, specificDefaultValue) => {
            const defaultForMissing =
              hasDefaultValue && specificDefaultValue !== res ? specificDefaultValue : resForMissing;
            if (this.options.missingKeyHandler) {
              this.options.missingKeyHandler(l, namespace, k, defaultForMissing, updateMissing, opt);
            } else if (this.backendConnector?.saveMissing) {
              this.backendConnector.saveMissing(l, namespace, k, defaultForMissing, updateMissing, opt);
            }
            this.emit('missingKey', l, namespace, k, res);
          };
          if (this.options.saveMissing) {
            if (this.options.saveMissingPlurals && needsPluralHandling) {
              lngs.forEach(language => {
                const suffixes = this.pluralResolver.getSuffixes(language, opt);
                if (
                  needsZeroSuffixLookup &&
                  opt[`defaultValue${this.options.pluralSeparator}zero`] &&
                  suffixes.indexOf(`${this.options.pluralSeparator}zero`) < 0
                ) {
                  suffixes.push(`${this.options.pluralSeparator}zero`);
                }
                suffixes.forEach(suffix => {
                  send([language], key + suffix, opt[`defaultValue${suffix}`] || defaultValue);
                });
              });
            } else {
              send(lngs, key, defaultValue);
            }
          }
        }
        res = this.extendTranslation(res, keys, opt, resolved, lastKey);
        if (usedKey && res === key && this.options.appendNamespaceToMissingKey) {
          res = `${namespace}${nsSeparator}${key}`;
        }
        if ((usedKey || usedDefault) && this.options.parseMissingKeyHandler) {
          res = this.options.parseMissingKeyHandler(
            this.options.appendNamespaceToMissingKey ? `${namespace}${nsSeparator}${key}` : key,
            usedDefault ? res : void 0,
            opt,
          );
        }
      }
      if (returnDetails) {
        resolved.res = res;
        resolved.usedParams = this.getUsedParamsDetails(opt);
        return resolved;
      }
      return res;
    }
    extendTranslation(res, key, opt, resolved, lastKey) {
      if (this.i18nFormat?.parse) {
        res = this.i18nFormat.parse(
          res,
          {
            ...this.options.interpolation.defaultVariables,
            ...opt,
          },
          opt.lng || this.language || resolved.usedLng,
          resolved.usedNS,
          resolved.usedKey,
          {
            resolved,
          },
        );
      } else if (!opt.skipInterpolation) {
        if (opt.interpolation)
          this.interpolator.init({
            ...opt,
            ...{
              interpolation: {
                ...this.options.interpolation,
                ...opt.interpolation,
              },
            },
          });
        const skipOnVariables =
          isString(res) &&
          (opt?.interpolation?.skipOnVariables !== void 0
            ? opt.interpolation.skipOnVariables
            : this.options.interpolation.skipOnVariables);
        let nestBef;
        if (skipOnVariables) {
          const nb = res.match(this.interpolator.nestingRegexp);
          nestBef = nb && nb.length;
        }
        let data = opt.replace && !isString(opt.replace) ? opt.replace : opt;
        if (this.options.interpolation.defaultVariables)
          data = {
            ...this.options.interpolation.defaultVariables,
            ...data,
          };
        res = this.interpolator.interpolate(res, data, opt.lng || this.language || resolved.usedLng, opt);
        if (skipOnVariables) {
          const na = res.match(this.interpolator.nestingRegexp);
          const nestAft = na && na.length;
          if (nestBef < nestAft) opt.nest = false;
        }
        if (!opt.lng && resolved && resolved.res) opt.lng = this.language || resolved.usedLng;
        if (opt.nest !== false)
          res = this.interpolator.nest(
            res,
            (...args) => {
              if (lastKey?.[0] === args[0] && !opt.context) {
                this.logger.warn(`It seems you are nesting recursively key: ${args[0]} in key: ${key[0]}`);
                return null;
              }
              return this.translate(...args, key);
            },
            opt,
          );
        if (opt.interpolation) this.interpolator.reset();
      }
      const postProcess = opt.postProcess || this.options.postProcess;
      const postProcessorNames = isString(postProcess) ? [postProcess] : postProcess;
      if (res != null && postProcessorNames?.length && opt.applyPostProcessor !== false) {
        res = postProcessor.handle(
          postProcessorNames,
          res,
          key,
          this.options && this.options.postProcessPassResolved
            ? {
                i18nResolved: {
                  ...resolved,
                  usedParams: this.getUsedParamsDetails(opt),
                },
                ...opt,
              }
            : opt,
          this,
        );
      }
      return res;
    }
    resolve(keys, opt = {}) {
      let found;
      let usedKey;
      let exactUsedKey;
      let usedLng;
      let usedNS;
      if (isString(keys)) keys = [keys];
      keys.forEach(k => {
        if (this.isValidLookup(found)) return;
        const extracted = this.extractFromKey(k, opt);
        const key = extracted.key;
        usedKey = key;
        let namespaces = extracted.namespaces;
        if (this.options.fallbackNS) namespaces = namespaces.concat(this.options.fallbackNS);
        const needsPluralHandling = opt.count !== void 0 && !isString(opt.count);
        const needsZeroSuffixLookup = needsPluralHandling && !opt.ordinal && opt.count === 0;
        const needsContextHandling =
          opt.context !== void 0 && (isString(opt.context) || typeof opt.context === 'number') && opt.context !== '';
        const codes = opt.lngs
          ? opt.lngs
          : this.languageUtils.toResolveHierarchy(opt.lng || this.language, opt.fallbackLng);
        namespaces.forEach(ns => {
          if (this.isValidLookup(found)) return;
          usedNS = ns;
          if (
            !checkedLoadedFor[`${codes[0]}-${ns}`] &&
            this.utils?.hasLoadedNamespace &&
            !this.utils?.hasLoadedNamespace(usedNS)
          ) {
            checkedLoadedFor[`${codes[0]}-${ns}`] = true;
            this.logger.warn(
              `key "${usedKey}" for languages "${codes.join(
                ', ',
              )}" won't get resolved as namespace "${usedNS}" was not yet loaded`,
              'This means something IS WRONG in your setup. You access the t function before i18next.init / i18next.loadNamespace / i18next.changeLanguage was done. Wait for the callback or Promise to resolve before accessing it!!!',
            );
          }
          codes.forEach(code => {
            if (this.isValidLookup(found)) return;
            usedLng = code;
            const finalKeys = [key];
            if (this.i18nFormat?.addLookupKeys) {
              this.i18nFormat.addLookupKeys(finalKeys, key, code, ns, opt);
            } else {
              let pluralSuffix;
              if (needsPluralHandling) pluralSuffix = this.pluralResolver.getSuffix(code, opt.count, opt);
              const zeroSuffix = `${this.options.pluralSeparator}zero`;
              const ordinalPrefix = `${this.options.pluralSeparator}ordinal${this.options.pluralSeparator}`;
              if (needsPluralHandling) {
                finalKeys.push(key + pluralSuffix);
                if (opt.ordinal && pluralSuffix.indexOf(ordinalPrefix) === 0) {
                  finalKeys.push(key + pluralSuffix.replace(ordinalPrefix, this.options.pluralSeparator));
                }
                if (needsZeroSuffixLookup) {
                  finalKeys.push(key + zeroSuffix);
                }
              }
              if (needsContextHandling) {
                const contextKey = `${key}${this.options.contextSeparator}${opt.context}`;
                finalKeys.push(contextKey);
                if (needsPluralHandling) {
                  finalKeys.push(contextKey + pluralSuffix);
                  if (opt.ordinal && pluralSuffix.indexOf(ordinalPrefix) === 0) {
                    finalKeys.push(contextKey + pluralSuffix.replace(ordinalPrefix, this.options.pluralSeparator));
                  }
                  if (needsZeroSuffixLookup) {
                    finalKeys.push(contextKey + zeroSuffix);
                  }
                }
              }
            }
            let possibleKey;
            while ((possibleKey = finalKeys.pop())) {
              if (!this.isValidLookup(found)) {
                exactUsedKey = possibleKey;
                found = this.getResource(code, ns, possibleKey, opt);
              }
            }
          });
        });
      });
      return {
        res: found,
        usedKey,
        exactUsedKey,
        usedLng,
        usedNS,
      };
    }
    isValidLookup(res) {
      return (
        res !== void 0 &&
        !(!this.options.returnNull && res === null) &&
        !(!this.options.returnEmptyString && res === '')
      );
    }
    getResource(code, ns, key, options2 = {}) {
      if (this.i18nFormat?.getResource) return this.i18nFormat.getResource(code, ns, key, options2);
      return this.resourceStore.getResource(code, ns, key, options2);
    }
    getUsedParamsDetails(options2 = {}) {
      const optionsKeys = [
        'defaultValue',
        'ordinal',
        'context',
        'replace',
        'lng',
        'lngs',
        'fallbackLng',
        'ns',
        'keySeparator',
        'nsSeparator',
        'returnObjects',
        'returnDetails',
        'joinArrays',
        'postProcess',
        'interpolation',
      ];
      const useOptionsReplaceForData = options2.replace && !isString(options2.replace);
      let data = useOptionsReplaceForData ? options2.replace : options2;
      if (useOptionsReplaceForData && typeof options2.count !== 'undefined') {
        data.count = options2.count;
      }
      if (this.options.interpolation.defaultVariables) {
        data = {
          ...this.options.interpolation.defaultVariables,
          ...data,
        };
      }
      if (!useOptionsReplaceForData) {
        data = {
          ...data,
        };
        for (const key of optionsKeys) {
          delete data[key];
        }
      }
      return data;
    }
    static hasDefaultValue(options2) {
      const prefix = 'defaultValue';
      for (const option in options2) {
        if (
          Object.prototype.hasOwnProperty.call(options2, option) &&
          prefix === option.substring(0, prefix.length) &&
          void 0 !== options2[option]
        ) {
          return true;
        }
      }
      return false;
    }
  }
  class LanguageUtil {
    constructor(options2) {
      this.options = options2;
      this.supportedLngs = this.options.supportedLngs || false;
      this.logger = baseLogger.create('languageUtils');
    }
    getScriptPartFromCode(code) {
      code = getCleanedCode(code);
      if (!code || code.indexOf('-') < 0) return null;
      const p = code.split('-');
      if (p.length === 2) return null;
      p.pop();
      if (p[p.length - 1].toLowerCase() === 'x') return null;
      return this.formatLanguageCode(p.join('-'));
    }
    getLanguagePartFromCode(code) {
      code = getCleanedCode(code);
      if (!code || code.indexOf('-') < 0) return code;
      const p = code.split('-');
      return this.formatLanguageCode(p[0]);
    }
    formatLanguageCode(code) {
      if (isString(code) && code.indexOf('-') > -1) {
        let formattedCode;
        try {
          formattedCode = Intl.getCanonicalLocales(code)[0];
        } catch (e) {}
        if (formattedCode && this.options.lowerCaseLng) {
          formattedCode = formattedCode.toLowerCase();
        }
        if (formattedCode) return formattedCode;
        if (this.options.lowerCaseLng) {
          return code.toLowerCase();
        }
        return code;
      }
      return this.options.cleanCode || this.options.lowerCaseLng ? code.toLowerCase() : code;
    }
    isSupportedCode(code) {
      if (this.options.load === 'languageOnly' || this.options.nonExplicitSupportedLngs) {
        code = this.getLanguagePartFromCode(code);
      }
      return !this.supportedLngs || !this.supportedLngs.length || this.supportedLngs.indexOf(code) > -1;
    }
    getBestMatchFromCodes(codes) {
      if (!codes) return null;
      let found;
      codes.forEach(code => {
        if (found) return;
        const cleanedLng = this.formatLanguageCode(code);
        if (!this.options.supportedLngs || this.isSupportedCode(cleanedLng)) found = cleanedLng;
      });
      if (!found && this.options.supportedLngs) {
        codes.forEach(code => {
          if (found) return;
          const lngScOnly = this.getScriptPartFromCode(code);
          if (this.isSupportedCode(lngScOnly)) return (found = lngScOnly);
          const lngOnly = this.getLanguagePartFromCode(code);
          if (this.isSupportedCode(lngOnly)) return (found = lngOnly);
          found = this.options.supportedLngs.find(supportedLng => {
            if (supportedLng === lngOnly) return supportedLng;
            if (supportedLng.indexOf('-') < 0 && lngOnly.indexOf('-') < 0) return;
            if (
              supportedLng.indexOf('-') > 0 &&
              lngOnly.indexOf('-') < 0 &&
              supportedLng.substring(0, supportedLng.indexOf('-')) === lngOnly
            )
              return supportedLng;
            if (supportedLng.indexOf(lngOnly) === 0 && lngOnly.length > 1) return supportedLng;
          });
        });
      }
      if (!found) found = this.getFallbackCodes(this.options.fallbackLng)[0];
      return found;
    }
    getFallbackCodes(fallbacks, code) {
      if (!fallbacks) return [];
      if (typeof fallbacks === 'function') fallbacks = fallbacks(code);
      if (isString(fallbacks)) fallbacks = [fallbacks];
      if (Array.isArray(fallbacks)) return fallbacks;
      if (!code) return fallbacks.default || [];
      let found = fallbacks[code];
      if (!found) found = fallbacks[this.getScriptPartFromCode(code)];
      if (!found) found = fallbacks[this.formatLanguageCode(code)];
      if (!found) found = fallbacks[this.getLanguagePartFromCode(code)];
      if (!found) found = fallbacks.default;
      return found || [];
    }
    toResolveHierarchy(code, fallbackCode) {
      const fallbackCodes = this.getFallbackCodes(
        (fallbackCode === false ? [] : fallbackCode) || this.options.fallbackLng || [],
        code,
      );
      const codes = [];
      const addCode = c => {
        if (!c) return;
        if (this.isSupportedCode(c)) {
          codes.push(c);
        } else {
          this.logger.warn(`rejecting language code not found in supportedLngs: ${c}`);
        }
      };
      if (isString(code) && (code.indexOf('-') > -1 || code.indexOf('_') > -1)) {
        if (this.options.load !== 'languageOnly') addCode(this.formatLanguageCode(code));
        if (this.options.load !== 'languageOnly' && this.options.load !== 'currentOnly')
          addCode(this.getScriptPartFromCode(code));
        if (this.options.load !== 'currentOnly') addCode(this.getLanguagePartFromCode(code));
      } else if (isString(code)) {
        addCode(this.formatLanguageCode(code));
      }
      fallbackCodes.forEach(fc => {
        if (codes.indexOf(fc) < 0) addCode(this.formatLanguageCode(fc));
      });
      return codes;
    }
  }
  const suffixesOrder = {
    zero: 0,
    one: 1,
    two: 2,
    few: 3,
    many: 4,
    other: 5,
  };
  const dummyRule = {
    select: count => (count === 1 ? 'one' : 'other'),
    resolvedOptions: () => ({
      pluralCategories: ['one', 'other'],
    }),
  };
  class PluralResolver {
    constructor(languageUtils, options2 = {}) {
      this.languageUtils = languageUtils;
      this.options = options2;
      this.logger = baseLogger.create('pluralResolver');
      this.pluralRulesCache = {};
    }
    addRule(lng, obj) {
      this.rules[lng] = obj;
    }
    clearCache() {
      this.pluralRulesCache = {};
    }
    getRule(code, options2 = {}) {
      const cleanedCode = getCleanedCode(code === 'dev' ? 'en' : code);
      const type = options2.ordinal ? 'ordinal' : 'cardinal';
      const cacheKey = JSON.stringify({
        cleanedCode,
        type,
      });
      if (cacheKey in this.pluralRulesCache) {
        return this.pluralRulesCache[cacheKey];
      }
      let rule;
      try {
        rule = new Intl.PluralRules(cleanedCode, {
          type,
        });
      } catch (err) {
        if (!Intl) {
          this.logger.error('No Intl support, please use an Intl polyfill!');
          return dummyRule;
        }
        if (!code.match(/-|_/)) return dummyRule;
        const lngPart = this.languageUtils.getLanguagePartFromCode(code);
        rule = this.getRule(lngPart, options2);
      }
      this.pluralRulesCache[cacheKey] = rule;
      return rule;
    }
    needsPlural(code, options2 = {}) {
      let rule = this.getRule(code, options2);
      if (!rule) rule = this.getRule('dev', options2);
      return rule?.resolvedOptions().pluralCategories.length > 1;
    }
    getPluralFormsOfKey(code, key, options2 = {}) {
      return this.getSuffixes(code, options2).map(suffix => `${key}${suffix}`);
    }
    getSuffixes(code, options2 = {}) {
      let rule = this.getRule(code, options2);
      if (!rule) rule = this.getRule('dev', options2);
      if (!rule) return [];
      return rule
        .resolvedOptions()
        .pluralCategories.sort(
          (pluralCategory1, pluralCategory2) => suffixesOrder[pluralCategory1] - suffixesOrder[pluralCategory2],
        )
        .map(
          pluralCategory =>
            `${this.options.prepend}${options2.ordinal ? `ordinal${this.options.prepend}` : ''}${pluralCategory}`,
        );
    }
    getSuffix(code, count, options2 = {}) {
      const rule = this.getRule(code, options2);
      if (rule) {
        return `${this.options.prepend}${options2.ordinal ? `ordinal${this.options.prepend}` : ''}${rule.select(
          count,
        )}`;
      }
      this.logger.warn(`no plural rule found for: ${code}`);
      return this.getSuffix('dev', count, options2);
    }
  }
  const deepFindWithDefaults = (data, defaultData, key, keySeparator = '.', ignoreJSONStructure = true) => {
    let path = getPathWithDefaults(data, defaultData, key);
    if (!path && ignoreJSONStructure && isString(key)) {
      path = deepFind(data, key, keySeparator);
      if (path === void 0) path = deepFind(defaultData, key, keySeparator);
    }
    return path;
  };
  const regexSafe = val => val.replace(/\$/g, '$$$$');
  class Interpolator {
    constructor(options2 = {}) {
      this.logger = baseLogger.create('interpolator');
      this.options = options2;
      this.format = options2?.interpolation?.format || (value => value);
      this.init(options2);
    }
    init(options2 = {}) {
      if (!options2.interpolation)
        options2.interpolation = {
          escapeValue: true,
        };
      const {
        escape: escape$1,
        escapeValue,
        useRawValueToEscape,
        prefix,
        prefixEscaped,
        suffix,
        suffixEscaped,
        formatSeparator,
        unescapeSuffix,
        unescapePrefix,
        nestingPrefix,
        nestingPrefixEscaped,
        nestingSuffix,
        nestingSuffixEscaped,
        nestingOptionsSeparator,
        maxReplaces,
        alwaysFormat,
      } = options2.interpolation;
      this.escape = escape$1 !== void 0 ? escape$1 : escape;
      this.escapeValue = escapeValue !== void 0 ? escapeValue : true;
      this.useRawValueToEscape = useRawValueToEscape !== void 0 ? useRawValueToEscape : false;
      this.prefix = prefix ? regexEscape(prefix) : prefixEscaped || '{{';
      this.suffix = suffix ? regexEscape(suffix) : suffixEscaped || '}}';
      this.formatSeparator = formatSeparator || ',';
      this.unescapePrefix = unescapeSuffix ? '' : unescapePrefix || '-';
      this.unescapeSuffix = this.unescapePrefix ? '' : unescapeSuffix || '';
      this.nestingPrefix = nestingPrefix ? regexEscape(nestingPrefix) : nestingPrefixEscaped || regexEscape('$t(');
      this.nestingSuffix = nestingSuffix ? regexEscape(nestingSuffix) : nestingSuffixEscaped || regexEscape(')');
      this.nestingOptionsSeparator = nestingOptionsSeparator || ',';
      this.maxReplaces = maxReplaces || 1e3;
      this.alwaysFormat = alwaysFormat !== void 0 ? alwaysFormat : false;
      this.resetRegExp();
    }
    reset() {
      if (this.options) this.init(this.options);
    }
    resetRegExp() {
      const getOrResetRegExp = (existingRegExp, pattern) => {
        if (existingRegExp?.source === pattern) {
          existingRegExp.lastIndex = 0;
          return existingRegExp;
        }
        return new RegExp(pattern, 'g');
      };
      this.regexp = getOrResetRegExp(this.regexp, `${this.prefix}(.+?)${this.suffix}`);
      this.regexpUnescape = getOrResetRegExp(
        this.regexpUnescape,
        `${this.prefix}${this.unescapePrefix}(.+?)${this.unescapeSuffix}${this.suffix}`,
      );
      this.nestingRegexp = getOrResetRegExp(this.nestingRegexp, `${this.nestingPrefix}(.+?)${this.nestingSuffix}`);
    }
    interpolate(str, data, lng, options2) {
      let match;
      let value;
      let replaces;
      const defaultData =
        (this.options && this.options.interpolation && this.options.interpolation.defaultVariables) || {};
      const handleFormat = key => {
        if (key.indexOf(this.formatSeparator) < 0) {
          const path = deepFindWithDefaults(
            data,
            defaultData,
            key,
            this.options.keySeparator,
            this.options.ignoreJSONStructure,
          );
          return this.alwaysFormat
            ? this.format(path, void 0, lng, {
                ...options2,
                ...data,
                interpolationkey: key,
              })
            : path;
        }
        const p = key.split(this.formatSeparator);
        const k = p.shift().trim();
        const f = p.join(this.formatSeparator).trim();
        return this.format(
          deepFindWithDefaults(data, defaultData, k, this.options.keySeparator, this.options.ignoreJSONStructure),
          f,
          lng,
          {
            ...options2,
            ...data,
            interpolationkey: k,
          },
        );
      };
      this.resetRegExp();
      const missingInterpolationHandler =
        options2?.missingInterpolationHandler || this.options.missingInterpolationHandler;
      const skipOnVariables =
        options2?.interpolation?.skipOnVariables !== void 0
          ? options2.interpolation.skipOnVariables
          : this.options.interpolation.skipOnVariables;
      const todos = [
        {
          regex: this.regexpUnescape,
          safeValue: val => regexSafe(val),
        },
        {
          regex: this.regexp,
          safeValue: val => (this.escapeValue ? regexSafe(this.escape(val)) : regexSafe(val)),
        },
      ];
      todos.forEach(todo => {
        replaces = 0;
        while ((match = todo.regex.exec(str))) {
          const matchedVar = match[1].trim();
          value = handleFormat(matchedVar);
          if (value === void 0) {
            if (typeof missingInterpolationHandler === 'function') {
              const temp = missingInterpolationHandler(str, match, options2);
              value = isString(temp) ? temp : '';
            } else if (options2 && Object.prototype.hasOwnProperty.call(options2, matchedVar)) {
              value = '';
            } else if (skipOnVariables) {
              value = match[0];
              continue;
            } else {
              this.logger.warn(`missed to pass in variable ${matchedVar} for interpolating ${str}`);
              value = '';
            }
          } else if (!isString(value) && !this.useRawValueToEscape) {
            value = makeString(value);
          }
          const safeValue = todo.safeValue(value);
          str = str.replace(match[0], safeValue);
          if (skipOnVariables) {
            todo.regex.lastIndex += value.length;
            todo.regex.lastIndex -= match[0].length;
          } else {
            todo.regex.lastIndex = 0;
          }
          replaces++;
          if (replaces >= this.maxReplaces) {
            break;
          }
        }
      });
      return str;
    }
    nest(str, fc, options2 = {}) {
      let match;
      let value;
      let clonedOptions;
      const handleHasOptions = (key, inheritedOptions) => {
        const sep = this.nestingOptionsSeparator;
        if (key.indexOf(sep) < 0) return key;
        const c = key.split(new RegExp(`${sep}[ ]*{`));
        let optionsString = `{${c[1]}`;
        key = c[0];
        optionsString = this.interpolate(optionsString, clonedOptions);
        const matchedSingleQuotes = optionsString.match(/'/g);
        const matchedDoubleQuotes = optionsString.match(/"/g);
        if (
          ((matchedSingleQuotes?.length ?? 0) % 2 === 0 && !matchedDoubleQuotes) ||
          matchedDoubleQuotes.length % 2 !== 0
        ) {
          optionsString = optionsString.replace(/'/g, '"');
        }
        try {
          clonedOptions = JSON.parse(optionsString);
          if (inheritedOptions)
            clonedOptions = {
              ...inheritedOptions,
              ...clonedOptions,
            };
        } catch (e) {
          this.logger.warn(`failed parsing options string in nesting for key ${key}`, e);
          return `${key}${sep}${optionsString}`;
        }
        if (clonedOptions.defaultValue && clonedOptions.defaultValue.indexOf(this.prefix) > -1)
          delete clonedOptions.defaultValue;
        return key;
      };
      while ((match = this.nestingRegexp.exec(str))) {
        let formatters = [];
        clonedOptions = {
          ...options2,
        };
        clonedOptions =
          clonedOptions.replace && !isString(clonedOptions.replace) ? clonedOptions.replace : clonedOptions;
        clonedOptions.applyPostProcessor = false;
        delete clonedOptions.defaultValue;
        let doReduce = false;
        if (match[0].indexOf(this.formatSeparator) !== -1 && !/{.*}/.test(match[1])) {
          const r = match[1].split(this.formatSeparator).map(elem => elem.trim());
          match[1] = r.shift();
          formatters = r;
          doReduce = true;
        }
        value = fc(handleHasOptions.call(this, match[1].trim(), clonedOptions), clonedOptions);
        if (value && match[0] === str && !isString(value)) return value;
        if (!isString(value)) value = makeString(value);
        if (!value) {
          this.logger.warn(`missed to resolve ${match[1]} for nesting ${str}`);
          value = '';
        }
        if (doReduce) {
          value = formatters.reduce(
            (v, f) =>
              this.format(v, f, options2.lng, {
                ...options2,
                interpolationkey: match[1].trim(),
              }),
            value.trim(),
          );
        }
        str = str.replace(match[0], value);
        this.regexp.lastIndex = 0;
      }
      return str;
    }
  }
  const parseFormatStr = formatStr => {
    let formatName = formatStr.toLowerCase().trim();
    const formatOptions = {};
    if (formatStr.indexOf('(') > -1) {
      const p = formatStr.split('(');
      formatName = p[0].toLowerCase().trim();
      const optStr = p[1].substring(0, p[1].length - 1);
      if (formatName === 'currency' && optStr.indexOf(':') < 0) {
        if (!formatOptions.currency) formatOptions.currency = optStr.trim();
      } else if (formatName === 'relativetime' && optStr.indexOf(':') < 0) {
        if (!formatOptions.range) formatOptions.range = optStr.trim();
      } else {
        const opts = optStr.split(';');
        opts.forEach(opt => {
          if (opt) {
            const [key, ...rest] = opt.split(':');
            const val = rest
              .join(':')
              .trim()
              .replace(/^'+|'+$/g, '');
            const trimmedKey = key.trim();
            if (!formatOptions[trimmedKey]) formatOptions[trimmedKey] = val;
            if (val === 'false') formatOptions[trimmedKey] = false;
            if (val === 'true') formatOptions[trimmedKey] = true;
            if (!isNaN(val)) formatOptions[trimmedKey] = parseInt(val, 10);
          }
        });
      }
    }
    return {
      formatName,
      formatOptions,
    };
  };
  const createCachedFormatter = fn => {
    const cache = {};
    return (v, l, o) => {
      let optForCache = o;
      if (o && o.interpolationkey && o.formatParams && o.formatParams[o.interpolationkey] && o[o.interpolationkey]) {
        optForCache = {
          ...optForCache,
          [o.interpolationkey]: void 0,
        };
      }
      const key = l + JSON.stringify(optForCache);
      let frm = cache[key];
      if (!frm) {
        frm = fn(getCleanedCode(l), o);
        cache[key] = frm;
      }
      return frm(v);
    };
  };
  const createNonCachedFormatter = fn => (v, l, o) => fn(getCleanedCode(l), o)(v);
  class Formatter {
    constructor(options2 = {}) {
      this.logger = baseLogger.create('formatter');
      this.options = options2;
      this.init(options2);
    }
    init(
      services,
      options2 = {
        interpolation: {},
      },
    ) {
      this.formatSeparator = options2.interpolation.formatSeparator || ',';
      const cf = options2.cacheInBuiltFormats ? createCachedFormatter : createNonCachedFormatter;
      this.formats = {
        number: cf((lng, opt) => {
          const formatter = new Intl.NumberFormat(lng, {
            ...opt,
          });
          return val => formatter.format(val);
        }),
        currency: cf((lng, opt) => {
          const formatter = new Intl.NumberFormat(lng, {
            ...opt,
            style: 'currency',
          });
          return val => formatter.format(val);
        }),
        datetime: cf((lng, opt) => {
          const formatter = new Intl.DateTimeFormat(lng, {
            ...opt,
          });
          return val => formatter.format(val);
        }),
        relativetime: cf((lng, opt) => {
          const formatter = new Intl.RelativeTimeFormat(lng, {
            ...opt,
          });
          return val => formatter.format(val, opt.range || 'day');
        }),
        list: cf((lng, opt) => {
          const formatter = new Intl.ListFormat(lng, {
            ...opt,
          });
          return val => formatter.format(val);
        }),
      };
    }
    add(name, fc) {
      this.formats[name.toLowerCase().trim()] = fc;
    }
    addCached(name, fc) {
      this.formats[name.toLowerCase().trim()] = createCachedFormatter(fc);
    }
    format(value, format, lng, options2 = {}) {
      const formats = format.split(this.formatSeparator);
      if (
        formats.length > 1 &&
        formats[0].indexOf('(') > 1 &&
        formats[0].indexOf(')') < 0 &&
        formats.find(f => f.indexOf(')') > -1)
      ) {
        const lastIndex = formats.findIndex(f => f.indexOf(')') > -1);
        formats[0] = [formats[0], ...formats.splice(1, lastIndex)].join(this.formatSeparator);
      }
      const result = formats.reduce((mem, f) => {
        const { formatName, formatOptions } = parseFormatStr(f);
        if (this.formats[formatName]) {
          let formatted = mem;
          try {
            const valOptions = options2?.formatParams?.[options2.interpolationkey] || {};
            const l = valOptions.locale || valOptions.lng || options2.locale || options2.lng || lng;
            formatted = this.formats[formatName](mem, l, {
              ...formatOptions,
              ...options2,
              ...valOptions,
            });
          } catch (error) {
            this.logger.warn(error);
          }
          return formatted;
        } else {
          this.logger.warn(`there was no format function for ${formatName}`);
        }
        return mem;
      }, value);
      return result;
    }
  }
  const removePending = (q, name) => {
    if (q.pending[name] !== void 0) {
      delete q.pending[name];
      q.pendingCount--;
    }
  };
  class Connector extends EventEmitter {
    constructor(backend, store, services, options2 = {}) {
      super();
      this.backend = backend;
      this.store = store;
      this.services = services;
      this.languageUtils = services.languageUtils;
      this.options = options2;
      this.logger = baseLogger.create('backendConnector');
      this.waitingReads = [];
      this.maxParallelReads = options2.maxParallelReads || 10;
      this.readingCalls = 0;
      this.maxRetries = options2.maxRetries >= 0 ? options2.maxRetries : 5;
      this.retryTimeout = options2.retryTimeout >= 1 ? options2.retryTimeout : 350;
      this.state = {};
      this.queue = [];
      this.backend?.init?.(services, options2.backend, options2);
    }
    queueLoad(languages, namespaces, options2, callback) {
      const toLoad = {};
      const pending = {};
      const toLoadLanguages = {};
      const toLoadNamespaces = {};
      languages.forEach(lng => {
        let hasAllNamespaces = true;
        namespaces.forEach(ns => {
          const name = `${lng}|${ns}`;
          if (!options2.reload && this.store.hasResourceBundle(lng, ns)) {
            this.state[name] = 2;
          } else if (this.state[name] < 0);
          else if (this.state[name] === 1) {
            if (pending[name] === void 0) pending[name] = true;
          } else {
            this.state[name] = 1;
            hasAllNamespaces = false;
            if (pending[name] === void 0) pending[name] = true;
            if (toLoad[name] === void 0) toLoad[name] = true;
            if (toLoadNamespaces[ns] === void 0) toLoadNamespaces[ns] = true;
          }
        });
        if (!hasAllNamespaces) toLoadLanguages[lng] = true;
      });
      if (Object.keys(toLoad).length || Object.keys(pending).length) {
        this.queue.push({
          pending,
          pendingCount: Object.keys(pending).length,
          loaded: {},
          errors: [],
          callback,
        });
      }
      return {
        toLoad: Object.keys(toLoad),
        pending: Object.keys(pending),
        toLoadLanguages: Object.keys(toLoadLanguages),
        toLoadNamespaces: Object.keys(toLoadNamespaces),
      };
    }
    loaded(name, err, data) {
      const s = name.split('|');
      const lng = s[0];
      const ns = s[1];
      if (err) this.emit('failedLoading', lng, ns, err);
      if (!err && data) {
        this.store.addResourceBundle(lng, ns, data, void 0, void 0, {
          skipCopy: true,
        });
      }
      this.state[name] = err ? -1 : 2;
      if (err && data) this.state[name] = 0;
      const loaded = {};
      this.queue.forEach(q => {
        pushPath(q.loaded, [lng], ns);
        removePending(q, name);
        if (err) q.errors.push(err);
        if (q.pendingCount === 0 && !q.done) {
          Object.keys(q.loaded).forEach(l => {
            if (!loaded[l]) loaded[l] = {};
            const loadedKeys = q.loaded[l];
            if (loadedKeys.length) {
              loadedKeys.forEach(n => {
                if (loaded[l][n] === void 0) loaded[l][n] = true;
              });
            }
          });
          q.done = true;
          if (q.errors.length) {
            q.callback(q.errors);
          } else {
            q.callback();
          }
        }
      });
      this.emit('loaded', loaded);
      this.queue = this.queue.filter(q => !q.done);
    }
    read(lng, ns, fcName, tried = 0, wait = this.retryTimeout, callback) {
      if (!lng.length) return callback(null, {});
      if (this.readingCalls >= this.maxParallelReads) {
        this.waitingReads.push({
          lng,
          ns,
          fcName,
          tried,
          wait,
          callback,
        });
        return;
      }
      this.readingCalls++;
      const resolver = (err, data) => {
        this.readingCalls--;
        if (this.waitingReads.length > 0) {
          const next = this.waitingReads.shift();
          this.read(next.lng, next.ns, next.fcName, next.tried, next.wait, next.callback);
        }
        if (err && data && tried < this.maxRetries) {
          setTimeout(() => {
            this.read.call(this, lng, ns, fcName, tried + 1, wait * 2, callback);
          }, wait);
          return;
        }
        callback(err, data);
      };
      const fc = this.backend[fcName].bind(this.backend);
      if (fc.length === 2) {
        try {
          const r = fc(lng, ns);
          if (r && typeof r.then === 'function') {
            r.then(data => resolver(null, data)).catch(resolver);
          } else {
            resolver(null, r);
          }
        } catch (err) {
          resolver(err);
        }
        return;
      }
      return fc(lng, ns, resolver);
    }
    prepareLoading(languages, namespaces, options2 = {}, callback) {
      if (!this.backend) {
        this.logger.warn('No backend was added via i18next.use. Will not load resources.');
        return callback && callback();
      }
      if (isString(languages)) languages = this.languageUtils.toResolveHierarchy(languages);
      if (isString(namespaces)) namespaces = [namespaces];
      const toLoad = this.queueLoad(languages, namespaces, options2, callback);
      if (!toLoad.toLoad.length) {
        if (!toLoad.pending.length) callback();
        return null;
      }
      toLoad.toLoad.forEach(name => {
        this.loadOne(name);
      });
    }
    load(languages, namespaces, callback) {
      this.prepareLoading(languages, namespaces, {}, callback);
    }
    reload(languages, namespaces, callback) {
      this.prepareLoading(
        languages,
        namespaces,
        {
          reload: true,
        },
        callback,
      );
    }
    loadOne(name, prefix = '') {
      const s = name.split('|');
      const lng = s[0];
      const ns = s[1];
      this.read(lng, ns, 'read', void 0, void 0, (err, data) => {
        if (err) this.logger.warn(`${prefix}loading namespace ${ns} for language ${lng} failed`, err);
        if (!err && data) this.logger.log(`${prefix}loaded namespace ${ns} for language ${lng}`, data);
        this.loaded(name, err, data);
      });
    }
    saveMissing(languages, namespace, key, fallbackValue, isUpdate, options2 = {}, clb = () => {}) {
      if (this.services?.utils?.hasLoadedNamespace && !this.services?.utils?.hasLoadedNamespace(namespace)) {
        this.logger.warn(
          `did not save key "${key}" as the namespace "${namespace}" was not yet loaded`,
          'This means something IS WRONG in your setup. You access the t function before i18next.init / i18next.loadNamespace / i18next.changeLanguage was done. Wait for the callback or Promise to resolve before accessing it!!!',
        );
        return;
      }
      if (key === void 0 || key === null || key === '') return;
      if (this.backend?.create) {
        const opts = {
          ...options2,
          isUpdate,
        };
        const fc = this.backend.create.bind(this.backend);
        if (fc.length < 6) {
          try {
            let r;
            if (fc.length === 5) {
              r = fc(languages, namespace, key, fallbackValue, opts);
            } else {
              r = fc(languages, namespace, key, fallbackValue);
            }
            if (r && typeof r.then === 'function') {
              r.then(data => clb(null, data)).catch(clb);
            } else {
              clb(null, r);
            }
          } catch (err) {
            clb(err);
          }
        } else {
          fc(languages, namespace, key, fallbackValue, clb, opts);
        }
      }
      if (!languages || !languages[0]) return;
      this.store.addResource(languages[0], namespace, key, fallbackValue);
    }
  }
  const get$1 = () => ({
    debug: false,
    initAsync: true,
    ns: ['translation'],
    defaultNS: ['translation'],
    fallbackLng: ['dev'],
    fallbackNS: false,
    supportedLngs: false,
    nonExplicitSupportedLngs: false,
    load: 'all',
    preload: false,
    simplifyPluralSuffix: true,
    keySeparator: '.',
    nsSeparator: ':',
    pluralSeparator: '_',
    contextSeparator: '_',
    partialBundledLanguages: false,
    saveMissing: false,
    updateMissing: false,
    saveMissingTo: 'fallback',
    saveMissingPlurals: true,
    missingKeyHandler: false,
    missingInterpolationHandler: false,
    postProcess: false,
    postProcessPassResolved: false,
    returnNull: false,
    returnEmptyString: true,
    returnObjects: false,
    joinArrays: false,
    returnedObjectHandler: false,
    parseMissingKeyHandler: false,
    appendNamespaceToMissingKey: false,
    appendNamespaceToCIMode: false,
    overloadTranslationOptionHandler: args => {
      let ret = {};
      if (typeof args[1] === 'object') ret = args[1];
      if (isString(args[1])) ret.defaultValue = args[1];
      if (isString(args[2])) ret.tDescription = args[2];
      if (typeof args[2] === 'object' || typeof args[3] === 'object') {
        const options2 = args[3] || args[2];
        Object.keys(options2).forEach(key => {
          ret[key] = options2[key];
        });
      }
      return ret;
    },
    interpolation: {
      escapeValue: true,
      format: value => value,
      prefix: '{{',
      suffix: '}}',
      formatSeparator: ',',
      unescapePrefix: '-',
      nestingPrefix: '$t(',
      nestingSuffix: ')',
      nestingOptionsSeparator: ',',
      maxReplaces: 1e3,
      skipOnVariables: true,
    },
    cacheInBuiltFormats: true,
  });
  const transformOptions = options2 => {
    if (isString(options2.ns)) options2.ns = [options2.ns];
    if (isString(options2.fallbackLng)) options2.fallbackLng = [options2.fallbackLng];
    if (isString(options2.fallbackNS)) options2.fallbackNS = [options2.fallbackNS];
    if (options2.supportedLngs?.indexOf?.('cimode') < 0) {
      options2.supportedLngs = options2.supportedLngs.concat(['cimode']);
    }
    if (typeof options2.initImmediate === 'boolean') options2.initAsync = options2.initImmediate;
    return options2;
  };
  const noop = () => {};
  const bindMemberFunctions = inst => {
    const mems = Object.getOwnPropertyNames(Object.getPrototypeOf(inst));
    mems.forEach(mem => {
      if (typeof inst[mem] === 'function') {
        inst[mem] = inst[mem].bind(inst);
      }
    });
  };
  class I18n extends EventEmitter {
    constructor(options2 = {}, callback) {
      super();
      this.options = transformOptions(options2);
      this.services = {};
      this.logger = baseLogger;
      this.modules = {
        external: [],
      };
      bindMemberFunctions(this);
      if (callback && !this.isInitialized && !options2.isClone) {
        if (!this.options.initAsync) {
          this.init(options2, callback);
          return this;
        }
        setTimeout(() => {
          this.init(options2, callback);
        }, 0);
      }
    }
    init(options2 = {}, callback) {
      this.isInitializing = true;
      if (typeof options2 === 'function') {
        callback = options2;
        options2 = {};
      }
      if (options2.defaultNS == null && options2.ns) {
        if (isString(options2.ns)) {
          options2.defaultNS = options2.ns;
        } else if (options2.ns.indexOf('translation') < 0) {
          options2.defaultNS = options2.ns[0];
        }
      }
      const defOpts = get$1();
      this.options = {
        ...defOpts,
        ...this.options,
        ...transformOptions(options2),
      };
      this.options.interpolation = {
        ...defOpts.interpolation,
        ...this.options.interpolation,
      };
      if (options2.keySeparator !== void 0) {
        this.options.userDefinedKeySeparator = options2.keySeparator;
      }
      if (options2.nsSeparator !== void 0) {
        this.options.userDefinedNsSeparator = options2.nsSeparator;
      }
      const createClassOnDemand = ClassOrObject => {
        if (!ClassOrObject) return null;
        if (typeof ClassOrObject === 'function') return new ClassOrObject();
        return ClassOrObject;
      };
      if (!this.options.isClone) {
        if (this.modules.logger) {
          baseLogger.init(createClassOnDemand(this.modules.logger), this.options);
        } else {
          baseLogger.init(null, this.options);
        }
        let formatter;
        if (this.modules.formatter) {
          formatter = this.modules.formatter;
        } else {
          formatter = Formatter;
        }
        const lu = new LanguageUtil(this.options);
        this.store = new ResourceStore(this.options.resources, this.options);
        const s = this.services;
        s.logger = baseLogger;
        s.resourceStore = this.store;
        s.languageUtils = lu;
        s.pluralResolver = new PluralResolver(lu, {
          prepend: this.options.pluralSeparator,
          simplifyPluralSuffix: this.options.simplifyPluralSuffix,
        });
        if (
          formatter &&
          (!this.options.interpolation.format || this.options.interpolation.format === defOpts.interpolation.format)
        ) {
          s.formatter = createClassOnDemand(formatter);
          s.formatter.init(s, this.options);
          this.options.interpolation.format = s.formatter.format.bind(s.formatter);
        }
        s.interpolator = new Interpolator(this.options);
        s.utils = {
          hasLoadedNamespace: this.hasLoadedNamespace.bind(this),
        };
        s.backendConnector = new Connector(createClassOnDemand(this.modules.backend), s.resourceStore, s, this.options);
        s.backendConnector.on('*', (event, ...args) => {
          this.emit(event, ...args);
        });
        if (this.modules.languageDetector) {
          s.languageDetector = createClassOnDemand(this.modules.languageDetector);
          if (s.languageDetector.init) s.languageDetector.init(s, this.options.detection, this.options);
        }
        if (this.modules.i18nFormat) {
          s.i18nFormat = createClassOnDemand(this.modules.i18nFormat);
          if (s.i18nFormat.init) s.i18nFormat.init(this);
        }
        this.translator = new Translator(this.services, this.options);
        this.translator.on('*', (event, ...args) => {
          this.emit(event, ...args);
        });
        this.modules.external.forEach(m => {
          if (m.init) m.init(this);
        });
      }
      this.format = this.options.interpolation.format;
      if (!callback) callback = noop;
      if (this.options.fallbackLng && !this.services.languageDetector && !this.options.lng) {
        const codes = this.services.languageUtils.getFallbackCodes(this.options.fallbackLng);
        if (codes.length > 0 && codes[0] !== 'dev') this.options.lng = codes[0];
      }
      if (!this.services.languageDetector && !this.options.lng) {
        this.logger.warn('init: no languageDetector is used and no lng is defined');
      }
      const storeApi = ['getResource', 'hasResourceBundle', 'getResourceBundle', 'getDataByLanguage'];
      storeApi.forEach(fcName => {
        this[fcName] = (...args) => this.store[fcName](...args);
      });
      const storeApiChained = ['addResource', 'addResources', 'addResourceBundle', 'removeResourceBundle'];
      storeApiChained.forEach(fcName => {
        this[fcName] = (...args) => {
          this.store[fcName](...args);
          return this;
        };
      });
      const deferred = defer();
      const load = () => {
        const finish = (err, t) => {
          this.isInitializing = false;
          if (this.isInitialized && !this.initializedStoreOnce)
            this.logger.warn('init: i18next is already initialized. You should call init just once!');
          this.isInitialized = true;
          if (!this.options.isClone) this.logger.log('initialized', this.options);
          this.emit('initialized', this.options);
          deferred.resolve(t);
          callback(err, t);
        };
        if (this.languages && !this.isInitialized) return finish(null, this.t.bind(this));
        this.changeLanguage(this.options.lng, finish);
      };
      if (this.options.resources || !this.options.initAsync) {
        load();
      } else {
        setTimeout(load, 0);
      }
      return deferred;
    }
    loadResources(language, callback = noop) {
      let usedCallback = callback;
      const usedLng = isString(language) ? language : this.language;
      if (typeof language === 'function') usedCallback = language;
      if (!this.options.resources || this.options.partialBundledLanguages) {
        if (usedLng?.toLowerCase() === 'cimode' && (!this.options.preload || this.options.preload.length === 0))
          return usedCallback();
        const toLoad = [];
        const append = lng => {
          if (!lng) return;
          if (lng === 'cimode') return;
          const lngs = this.services.languageUtils.toResolveHierarchy(lng);
          lngs.forEach(l => {
            if (l === 'cimode') return;
            if (toLoad.indexOf(l) < 0) toLoad.push(l);
          });
        };
        if (!usedLng) {
          const fallbacks = this.services.languageUtils.getFallbackCodes(this.options.fallbackLng);
          fallbacks.forEach(l => append(l));
        } else {
          append(usedLng);
        }
        this.options.preload?.forEach?.(l => append(l));
        this.services.backendConnector.load(toLoad, this.options.ns, e => {
          if (!e && !this.resolvedLanguage && this.language) this.setResolvedLanguage(this.language);
          usedCallback(e);
        });
      } else {
        usedCallback(null);
      }
    }
    reloadResources(lngs, ns, callback) {
      const deferred = defer();
      if (typeof lngs === 'function') {
        callback = lngs;
        lngs = void 0;
      }
      if (typeof ns === 'function') {
        callback = ns;
        ns = void 0;
      }
      if (!lngs) lngs = this.languages;
      if (!ns) ns = this.options.ns;
      if (!callback) callback = noop;
      this.services.backendConnector.reload(lngs, ns, err => {
        deferred.resolve();
        callback(err);
      });
      return deferred;
    }
    use(module) {
      if (!module)
        throw new Error(
          'You are passing an undefined module! Please check the object you are passing to i18next.use()',
        );
      if (!module.type)
        throw new Error('You are passing a wrong module! Please check the object you are passing to i18next.use()');
      if (module.type === 'backend') {
        this.modules.backend = module;
      }
      if (module.type === 'logger' || (module.log && module.warn && module.error)) {
        this.modules.logger = module;
      }
      if (module.type === 'languageDetector') {
        this.modules.languageDetector = module;
      }
      if (module.type === 'i18nFormat') {
        this.modules.i18nFormat = module;
      }
      if (module.type === 'postProcessor') {
        postProcessor.addPostProcessor(module);
      }
      if (module.type === 'formatter') {
        this.modules.formatter = module;
      }
      if (module.type === '3rdParty') {
        this.modules.external.push(module);
      }
      return this;
    }
    setResolvedLanguage(l) {
      if (!l || !this.languages) return;
      if (['cimode', 'dev'].indexOf(l) > -1) return;
      for (let li = 0; li < this.languages.length; li++) {
        const lngInLngs = this.languages[li];
        if (['cimode', 'dev'].indexOf(lngInLngs) > -1) continue;
        if (this.store.hasLanguageSomeTranslations(lngInLngs)) {
          this.resolvedLanguage = lngInLngs;
          break;
        }
      }
      if (!this.resolvedLanguage && this.languages.indexOf(l) < 0 && this.store.hasLanguageSomeTranslations(l)) {
        this.resolvedLanguage = l;
        this.languages.unshift(l);
      }
    }
    changeLanguage(lng, callback) {
      this.isLanguageChangingTo = lng;
      const deferred = defer();
      this.emit('languageChanging', lng);
      const setLngProps = l => {
        this.language = l;
        this.languages = this.services.languageUtils.toResolveHierarchy(l);
        this.resolvedLanguage = void 0;
        this.setResolvedLanguage(l);
      };
      const done = (err, l) => {
        if (l) {
          if (this.isLanguageChangingTo === lng) {
            setLngProps(l);
            this.translator.changeLanguage(l);
            this.isLanguageChangingTo = void 0;
            this.emit('languageChanged', l);
            this.logger.log('languageChanged', l);
          }
        } else {
          this.isLanguageChangingTo = void 0;
        }
        deferred.resolve((...args) => this.t(...args));
        if (callback) callback(err, (...args) => this.t(...args));
      };
      const setLng = lngs => {
        if (!lng && !lngs && this.services.languageDetector) lngs = [];
        const fl = isString(lngs) ? lngs : lngs && lngs[0];
        const l = this.store.hasLanguageSomeTranslations(fl)
          ? fl
          : this.services.languageUtils.getBestMatchFromCodes(isString(lngs) ? [lngs] : lngs);
        if (l) {
          if (!this.language) {
            setLngProps(l);
          }
          if (!this.translator.language) this.translator.changeLanguage(l);
          this.services.languageDetector?.cacheUserLanguage?.(l);
        }
        this.loadResources(l, err => {
          done(err, l);
        });
      };
      if (!lng && this.services.languageDetector && !this.services.languageDetector.async) {
        setLng(this.services.languageDetector.detect());
      } else if (!lng && this.services.languageDetector && this.services.languageDetector.async) {
        if (this.services.languageDetector.detect.length === 0) {
          this.services.languageDetector.detect().then(setLng);
        } else {
          this.services.languageDetector.detect(setLng);
        }
      } else {
        setLng(lng);
      }
      return deferred;
    }
    getFixedT(lng, ns, keyPrefix) {
      const fixedT = (key, opts, ...rest) => {
        let o;
        if (typeof opts !== 'object') {
          o = this.options.overloadTranslationOptionHandler([key, opts].concat(rest));
        } else {
          o = {
            ...opts,
          };
        }
        o.lng = o.lng || fixedT.lng;
        o.lngs = o.lngs || fixedT.lngs;
        o.ns = o.ns || fixedT.ns;
        if (o.keyPrefix !== '') o.keyPrefix = o.keyPrefix || keyPrefix || fixedT.keyPrefix;
        const keySeparator = this.options.keySeparator || '.';
        let resultKey;
        if (o.keyPrefix && Array.isArray(key)) {
          resultKey = key.map(k => `${o.keyPrefix}${keySeparator}${k}`);
        } else {
          resultKey = o.keyPrefix ? `${o.keyPrefix}${keySeparator}${key}` : key;
        }
        return this.t(resultKey, o);
      };
      if (isString(lng)) {
        fixedT.lng = lng;
      } else {
        fixedT.lngs = lng;
      }
      fixedT.ns = ns;
      fixedT.keyPrefix = keyPrefix;
      return fixedT;
    }
    t(...args) {
      return this.translator?.translate(...args);
    }
    exists(...args) {
      return this.translator?.exists(...args);
    }
    setDefaultNamespace(ns) {
      this.options.defaultNS = ns;
    }
    hasLoadedNamespace(ns, options2 = {}) {
      if (!this.isInitialized) {
        this.logger.warn('hasLoadedNamespace: i18next was not initialized', this.languages);
        return false;
      }
      if (!this.languages || !this.languages.length) {
        this.logger.warn('hasLoadedNamespace: i18n.languages were undefined or empty', this.languages);
        return false;
      }
      const lng = options2.lng || this.resolvedLanguage || this.languages[0];
      const fallbackLng = this.options ? this.options.fallbackLng : false;
      const lastLng = this.languages[this.languages.length - 1];
      if (lng.toLowerCase() === 'cimode') return true;
      const loadNotPending = (l, n) => {
        const loadState = this.services.backendConnector.state[`${l}|${n}`];
        return loadState === -1 || loadState === 0 || loadState === 2;
      };
      if (options2.precheck) {
        const preResult = options2.precheck(this, loadNotPending);
        if (preResult !== void 0) return preResult;
      }
      if (this.hasResourceBundle(lng, ns)) return true;
      if (!this.services.backendConnector.backend || (this.options.resources && !this.options.partialBundledLanguages))
        return true;
      if (loadNotPending(lng, ns) && (!fallbackLng || loadNotPending(lastLng, ns))) return true;
      return false;
    }
    loadNamespaces(ns, callback) {
      const deferred = defer();
      if (!this.options.ns) {
        if (callback) callback();
        return Promise.resolve();
      }
      if (isString(ns)) ns = [ns];
      ns.forEach(n => {
        if (this.options.ns.indexOf(n) < 0) this.options.ns.push(n);
      });
      this.loadResources(err => {
        deferred.resolve();
        if (callback) callback(err);
      });
      return deferred;
    }
    loadLanguages(lngs, callback) {
      const deferred = defer();
      if (isString(lngs)) lngs = [lngs];
      const preloaded = this.options.preload || [];
      const newLngs = lngs.filter(
        lng => preloaded.indexOf(lng) < 0 && this.services.languageUtils.isSupportedCode(lng),
      );
      if (!newLngs.length) {
        if (callback) callback();
        return Promise.resolve();
      }
      this.options.preload = preloaded.concat(newLngs);
      this.loadResources(err => {
        deferred.resolve();
        if (callback) callback(err);
      });
      return deferred;
    }
    dir(lng) {
      if (!lng) lng = this.resolvedLanguage || (this.languages?.length > 0 ? this.languages[0] : this.language);
      if (!lng) return 'rtl';
      const rtlLngs = [
        'ar',
        'shu',
        'sqr',
        'ssh',
        'xaa',
        'yhd',
        'yud',
        'aao',
        'abh',
        'abv',
        'acm',
        'acq',
        'acw',
        'acx',
        'acy',
        'adf',
        'ads',
        'aeb',
        'aec',
        'afb',
        'ajp',
        'apc',
        'apd',
        'arb',
        'arq',
        'ars',
        'ary',
        'arz',
        'auz',
        'avl',
        'ayh',
        'ayl',
        'ayn',
        'ayp',
        'bbz',
        'pga',
        'he',
        'iw',
        'ps',
        'pbt',
        'pbu',
        'pst',
        'prp',
        'prd',
        'ug',
        'ur',
        'ydd',
        'yds',
        'yih',
        'ji',
        'yi',
        'hbo',
        'men',
        'xmn',
        'fa',
        'jpr',
        'peo',
        'pes',
        'prs',
        'dv',
        'sam',
        'ckb',
      ];
      const languageUtils = this.services?.languageUtils || new LanguageUtil(get$1());
      return rtlLngs.indexOf(languageUtils.getLanguagePartFromCode(lng)) > -1 || lng.toLowerCase().indexOf('-arab') > 1
        ? 'rtl'
        : 'ltr';
    }
    static createInstance(options2 = {}, callback) {
      return new I18n(options2, callback);
    }
    cloneInstance(options2 = {}, callback = noop) {
      const forkResourceStore = options2.forkResourceStore;
      if (forkResourceStore) delete options2.forkResourceStore;
      const mergedOptions = {
        ...this.options,
        ...options2,
        ...{
          isClone: true,
        },
      };
      const clone = new I18n(mergedOptions);
      if (options2.debug !== void 0 || options2.prefix !== void 0) {
        clone.logger = clone.logger.clone(options2);
      }
      const membersToCopy = ['store', 'services', 'language'];
      membersToCopy.forEach(m => {
        clone[m] = this[m];
      });
      clone.services = {
        ...this.services,
      };
      clone.services.utils = {
        hasLoadedNamespace: clone.hasLoadedNamespace.bind(clone),
      };
      if (forkResourceStore) {
        const clonedData = Object.keys(this.store.data).reduce((prev, l) => {
          prev[l] = {
            ...this.store.data[l],
          };
          prev[l] = Object.keys(prev[l]).reduce((acc, n) => {
            acc[n] = {
              ...prev[l][n],
            };
            return acc;
          }, prev[l]);
          return prev;
        }, {});
        clone.store = new ResourceStore(clonedData, mergedOptions);
        clone.services.resourceStore = clone.store;
      }
      clone.translator = new Translator(clone.services, mergedOptions);
      clone.translator.on('*', (event, ...args) => {
        clone.emit(event, ...args);
      });
      clone.init(mergedOptions, callback);
      clone.translator.options = mergedOptions;
      clone.translator.backendConnector.services.utils = {
        hasLoadedNamespace: clone.hasLoadedNamespace.bind(clone),
      };
      return clone;
    }
    toJSON() {
      return {
        options: this.options,
        store: this.store,
        language: this.language,
        languages: this.languages,
        resolvedLanguage: this.resolvedLanguage,
      };
    }
  }
  const instance = I18n.createInstance();
  instance.createInstance = I18n.createInstance;
  instance.createInstance;
  instance.dir;
  instance.init;
  instance.loadResources;
  instance.reloadResources;
  instance.use;
  instance.changeLanguage;
  instance.getFixedT;
  instance.t;
  instance.exists;
  instance.setDefaultNamespace;
  instance.hasLoadedNamespace;
  instance.loadNamespaces;
  instance.loadLanguages;
  function getLastOfPath(object, path, Empty) {
    function cleanKey2(key2) {
      return key2 && key2.indexOf('###') > -1 ? key2.replace(/###/g, '.') : key2;
    }
    function canNotTraverseDeeper2() {
      return !object || typeof object === 'string';
    }
    var stack = typeof path !== 'string' ? [].concat(path) : path.split('.');
    while (stack.length > 1) {
      if (canNotTraverseDeeper2()) return {};
      var key = cleanKey2(stack.shift());
      if (!object[key] && Empty) object[key] = new Empty();
      object = object[key];
    }
    if (canNotTraverseDeeper2()) return {};
    return {
      obj: object,
      k: cleanKey2(stack.shift()),
    };
  }
  function setPath(object, path, newValue) {
    var _getLastOfPath = getLastOfPath(object, path, Object),
      obj = _getLastOfPath.obj,
      k = _getLastOfPath.k;
    obj[k] = newValue;
  }
  function getPath(object, path) {
    var _getLastOfPath3 = getLastOfPath(object, path),
      obj = _getLastOfPath3.obj,
      k = _getLastOfPath3.k;
    if (!obj) return void 0;
    return obj[k];
  }
  var arr = [];
  var each = arr.forEach;
  var slice = arr.slice;
  function defaults(obj) {
    each.call(slice.call(arguments, 1), function (source) {
      if (source) {
        for (var prop in source) {
          if (obj[prop] === void 0) obj[prop] = source[prop];
        }
      }
    });
    return obj;
  }
  var extendStatics = function (d, b) {
    extendStatics =
      Object.setPrototypeOf ||
      ({ __proto__: [] } instanceof Array &&
        function (d2, b2) {
          d2.__proto__ = b2;
        }) ||
      function (d2, b2) {
        for (var p in b2) if (Object.prototype.hasOwnProperty.call(b2, p)) d2[p] = b2[p];
      };
    return extendStatics(d, b);
  };
  function __extends(d, b) {
    if (typeof b !== 'function' && b !== null)
      throw new TypeError('Class extends value ' + String(b) + ' is not a constructor or null');
    extendStatics(d, b);
    function __() {
      this.constructor = d;
    }
    d.prototype = b === null ? Object.create(b) : ((__.prototype = b.prototype), new __());
  }
  var __assign = function () {
    __assign =
      Object.assign ||
      function __assign2(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
  function __rest(s, e) {
    var t = {};
    for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0) t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === 'function')
      for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
        if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i])) t[p[i]] = s[p[i]];
      }
    return t;
  }
  function __spreadArray(to, from, pack) {
    if (pack || arguments.length === 2)
      for (var i = 0, l = from.length, ar; i < l; i++) {
        if (ar || !(i in from)) {
          if (!ar) ar = Array.prototype.slice.call(from, 0, i);
          ar[i] = from[i];
        }
      }
    return to.concat(ar || Array.prototype.slice.call(from));
  }
  typeof SuppressedError === 'function'
    ? SuppressedError
    : function (error, suppressed, message) {
        var e = new Error(message);
        return (e.name = 'SuppressedError'), (e.error = error), (e.suppressed = suppressed), e;
      };
  function memoize(fn, options2) {
    var cache = options2 && options2.cache ? options2.cache : cacheDefault;
    var serializer = options2 && options2.serializer ? options2.serializer : serializerDefault;
    var strategy = options2 && options2.strategy ? options2.strategy : strategyDefault;
    return strategy(fn, {
      cache,
      serializer,
    });
  }
  function isPrimitive(value) {
    return value == null || typeof value === 'number' || typeof value === 'boolean';
  }
  function monadic(fn, cache, serializer, arg) {
    var cacheKey = isPrimitive(arg) ? arg : serializer(arg);
    var computedValue = cache.get(cacheKey);
    if (typeof computedValue === 'undefined') {
      computedValue = fn.call(this, arg);
      cache.set(cacheKey, computedValue);
    }
    return computedValue;
  }
  function variadic(fn, cache, serializer) {
    var args = Array.prototype.slice.call(arguments, 3);
    var cacheKey = serializer(args);
    var computedValue = cache.get(cacheKey);
    if (typeof computedValue === 'undefined') {
      computedValue = fn.apply(this, args);
      cache.set(cacheKey, computedValue);
    }
    return computedValue;
  }
  function assemble(fn, context, strategy, cache, serialize) {
    return strategy.bind(context, fn, cache, serialize);
  }
  function strategyDefault(fn, options2) {
    var strategy = fn.length === 1 ? monadic : variadic;
    return assemble(fn, this, strategy, options2.cache.create(), options2.serializer);
  }
  function strategyVariadic(fn, options2) {
    return assemble(fn, this, variadic, options2.cache.create(), options2.serializer);
  }
  var serializerDefault = function () {
    return JSON.stringify(arguments);
  };
  var ObjectWithoutPrototypeCache =
    /** @class */
    (function () {
      function ObjectWithoutPrototypeCache2() {
        this.cache = /* @__PURE__ */ Object.create(null);
      }
      ObjectWithoutPrototypeCache2.prototype.get = function (key) {
        return this.cache[key];
      };
      ObjectWithoutPrototypeCache2.prototype.set = function (key, value) {
        this.cache[key] = value;
      };
      return ObjectWithoutPrototypeCache2;
    })();
  var cacheDefault = {
    create: function create() {
      return new ObjectWithoutPrototypeCache();
    },
  };
  var strategies = {
    variadic: strategyVariadic,
  };
  var ErrorKind;
  (function (ErrorKind2) {
    ErrorKind2[(ErrorKind2['EXPECT_ARGUMENT_CLOSING_BRACE'] = 1)] = 'EXPECT_ARGUMENT_CLOSING_BRACE';
    ErrorKind2[(ErrorKind2['EMPTY_ARGUMENT'] = 2)] = 'EMPTY_ARGUMENT';
    ErrorKind2[(ErrorKind2['MALFORMED_ARGUMENT'] = 3)] = 'MALFORMED_ARGUMENT';
    ErrorKind2[(ErrorKind2['EXPECT_ARGUMENT_TYPE'] = 4)] = 'EXPECT_ARGUMENT_TYPE';
    ErrorKind2[(ErrorKind2['INVALID_ARGUMENT_TYPE'] = 5)] = 'INVALID_ARGUMENT_TYPE';
    ErrorKind2[(ErrorKind2['EXPECT_ARGUMENT_STYLE'] = 6)] = 'EXPECT_ARGUMENT_STYLE';
    ErrorKind2[(ErrorKind2['INVALID_NUMBER_SKELETON'] = 7)] = 'INVALID_NUMBER_SKELETON';
    ErrorKind2[(ErrorKind2['INVALID_DATE_TIME_SKELETON'] = 8)] = 'INVALID_DATE_TIME_SKELETON';
    ErrorKind2[(ErrorKind2['EXPECT_NUMBER_SKELETON'] = 9)] = 'EXPECT_NUMBER_SKELETON';
    ErrorKind2[(ErrorKind2['EXPECT_DATE_TIME_SKELETON'] = 10)] = 'EXPECT_DATE_TIME_SKELETON';
    ErrorKind2[(ErrorKind2['UNCLOSED_QUOTE_IN_ARGUMENT_STYLE'] = 11)] = 'UNCLOSED_QUOTE_IN_ARGUMENT_STYLE';
    ErrorKind2[(ErrorKind2['EXPECT_SELECT_ARGUMENT_OPTIONS'] = 12)] = 'EXPECT_SELECT_ARGUMENT_OPTIONS';
    ErrorKind2[(ErrorKind2['EXPECT_PLURAL_ARGUMENT_OFFSET_VALUE'] = 13)] = 'EXPECT_PLURAL_ARGUMENT_OFFSET_VALUE';
    ErrorKind2[(ErrorKind2['INVALID_PLURAL_ARGUMENT_OFFSET_VALUE'] = 14)] = 'INVALID_PLURAL_ARGUMENT_OFFSET_VALUE';
    ErrorKind2[(ErrorKind2['EXPECT_SELECT_ARGUMENT_SELECTOR'] = 15)] = 'EXPECT_SELECT_ARGUMENT_SELECTOR';
    ErrorKind2[(ErrorKind2['EXPECT_PLURAL_ARGUMENT_SELECTOR'] = 16)] = 'EXPECT_PLURAL_ARGUMENT_SELECTOR';
    ErrorKind2[(ErrorKind2['EXPECT_SELECT_ARGUMENT_SELECTOR_FRAGMENT'] = 17)] =
      'EXPECT_SELECT_ARGUMENT_SELECTOR_FRAGMENT';
    ErrorKind2[(ErrorKind2['EXPECT_PLURAL_ARGUMENT_SELECTOR_FRAGMENT'] = 18)] =
      'EXPECT_PLURAL_ARGUMENT_SELECTOR_FRAGMENT';
    ErrorKind2[(ErrorKind2['INVALID_PLURAL_ARGUMENT_SELECTOR'] = 19)] = 'INVALID_PLURAL_ARGUMENT_SELECTOR';
    ErrorKind2[(ErrorKind2['DUPLICATE_PLURAL_ARGUMENT_SELECTOR'] = 20)] = 'DUPLICATE_PLURAL_ARGUMENT_SELECTOR';
    ErrorKind2[(ErrorKind2['DUPLICATE_SELECT_ARGUMENT_SELECTOR'] = 21)] = 'DUPLICATE_SELECT_ARGUMENT_SELECTOR';
    ErrorKind2[(ErrorKind2['MISSING_OTHER_CLAUSE'] = 22)] = 'MISSING_OTHER_CLAUSE';
    ErrorKind2[(ErrorKind2['INVALID_TAG'] = 23)] = 'INVALID_TAG';
    ErrorKind2[(ErrorKind2['INVALID_TAG_NAME'] = 25)] = 'INVALID_TAG_NAME';
    ErrorKind2[(ErrorKind2['UNMATCHED_CLOSING_TAG'] = 26)] = 'UNMATCHED_CLOSING_TAG';
    ErrorKind2[(ErrorKind2['UNCLOSED_TAG'] = 27)] = 'UNCLOSED_TAG';
  })(ErrorKind || (ErrorKind = {}));
  var TYPE;
  (function (TYPE2) {
    TYPE2[(TYPE2['literal'] = 0)] = 'literal';
    TYPE2[(TYPE2['argument'] = 1)] = 'argument';
    TYPE2[(TYPE2['number'] = 2)] = 'number';
    TYPE2[(TYPE2['date'] = 3)] = 'date';
    TYPE2[(TYPE2['time'] = 4)] = 'time';
    TYPE2[(TYPE2['select'] = 5)] = 'select';
    TYPE2[(TYPE2['plural'] = 6)] = 'plural';
    TYPE2[(TYPE2['pound'] = 7)] = 'pound';
    TYPE2[(TYPE2['tag'] = 8)] = 'tag';
  })(TYPE || (TYPE = {}));
  var SKELETON_TYPE;
  (function (SKELETON_TYPE2) {
    SKELETON_TYPE2[(SKELETON_TYPE2['number'] = 0)] = 'number';
    SKELETON_TYPE2[(SKELETON_TYPE2['dateTime'] = 1)] = 'dateTime';
  })(SKELETON_TYPE || (SKELETON_TYPE = {}));
  function isLiteralElement(el) {
    return el.type === TYPE.literal;
  }
  function isArgumentElement(el) {
    return el.type === TYPE.argument;
  }
  function isNumberElement(el) {
    return el.type === TYPE.number;
  }
  function isDateElement(el) {
    return el.type === TYPE.date;
  }
  function isTimeElement(el) {
    return el.type === TYPE.time;
  }
  function isSelectElement(el) {
    return el.type === TYPE.select;
  }
  function isPluralElement(el) {
    return el.type === TYPE.plural;
  }
  function isPoundElement(el) {
    return el.type === TYPE.pound;
  }
  function isTagElement(el) {
    return el.type === TYPE.tag;
  }
  function isNumberSkeleton(el) {
    return !!(el && typeof el === 'object' && el.type === SKELETON_TYPE.number);
  }
  function isDateTimeSkeleton(el) {
    return !!(el && typeof el === 'object' && el.type === SKELETON_TYPE.dateTime);
  }
  var SPACE_SEPARATOR_REGEX = /[ \xA0\u1680\u2000-\u200A\u202F\u205F\u3000]/;
  var DATE_TIME_REGEX =
    /(?:[Eec]{1,6}|G{1,5}|[Qq]{1,5}|(?:[yYur]+|U{1,5})|[ML]{1,5}|d{1,2}|D{1,3}|F{1}|[abB]{1,5}|[hkHK]{1,2}|w{1,2}|W{1}|m{1,2}|s{1,2}|[zZOvVxX]{1,4})(?=([^']*'[^']*')*[^']*$)/g;
  function parseDateTimeSkeleton(skeleton) {
    var result = {};
    skeleton.replace(DATE_TIME_REGEX, function (match) {
      var len = match.length;
      switch (match[0]) {
        // Era
        case 'G':
          result.era = len === 4 ? 'long' : len === 5 ? 'narrow' : 'short';
          break;
        // Year
        case 'y':
          result.year = len === 2 ? '2-digit' : 'numeric';
          break;
        case 'Y':
        case 'u':
        case 'U':
        case 'r':
          throw new RangeError('`Y/u/U/r` (year) patterns are not supported, use `y` instead');
        // Quarter
        case 'q':
        case 'Q':
          throw new RangeError('`q/Q` (quarter) patterns are not supported');
        // Month
        case 'M':
        case 'L':
          result.month = ['numeric', '2-digit', 'short', 'long', 'narrow'][len - 1];
          break;
        // Week
        case 'w':
        case 'W':
          throw new RangeError('`w/W` (week) patterns are not supported');
        case 'd':
          result.day = ['numeric', '2-digit'][len - 1];
          break;
        case 'D':
        case 'F':
        case 'g':
          throw new RangeError('`D/F/g` (day) patterns are not supported, use `d` instead');
        // Weekday
        case 'E':
          result.weekday = len === 4 ? 'long' : len === 5 ? 'narrow' : 'short';
          break;
        case 'e':
          if (len < 4) {
            throw new RangeError('`e..eee` (weekday) patterns are not supported');
          }
          result.weekday = ['short', 'long', 'narrow', 'short'][len - 4];
          break;
        case 'c':
          if (len < 4) {
            throw new RangeError('`c..ccc` (weekday) patterns are not supported');
          }
          result.weekday = ['short', 'long', 'narrow', 'short'][len - 4];
          break;
        // Period
        case 'a':
          result.hour12 = true;
          break;
        case 'b':
        // am, pm, noon, midnight
        case 'B':
          throw new RangeError('`b/B` (period) patterns are not supported, use `a` instead');
        // Hour
        case 'h':
          result.hourCycle = 'h12';
          result.hour = ['numeric', '2-digit'][len - 1];
          break;
        case 'H':
          result.hourCycle = 'h23';
          result.hour = ['numeric', '2-digit'][len - 1];
          break;
        case 'K':
          result.hourCycle = 'h11';
          result.hour = ['numeric', '2-digit'][len - 1];
          break;
        case 'k':
          result.hourCycle = 'h24';
          result.hour = ['numeric', '2-digit'][len - 1];
          break;
        case 'j':
        case 'J':
        case 'C':
          throw new RangeError('`j/J/C` (hour) patterns are not supported, use `h/H/K/k` instead');
        // Minute
        case 'm':
          result.minute = ['numeric', '2-digit'][len - 1];
          break;
        // Second
        case 's':
          result.second = ['numeric', '2-digit'][len - 1];
          break;
        case 'S':
        case 'A':
          throw new RangeError('`S/A` (second) patterns are not supported, use `s` instead');
        // Zone
        case 'z':
          result.timeZoneName = len < 4 ? 'short' : 'long';
          break;
        case 'Z':
        // 1..3, 4, 5: The ISO8601 varios formats
        case 'O':
        // 1, 4: milliseconds in day short, long
        case 'v':
        // 1, 4: generic non-location format
        case 'V':
        // 1, 2, 3, 4: time zone ID or city
        case 'X':
        // 1, 2, 3, 4: The ISO8601 varios formats
        case 'x':
          throw new RangeError('`Z/O/v/V/X/x` (timeZone) patterns are not supported, use `z` instead');
      }
      return '';
    });
    return result;
  }
  var WHITE_SPACE_REGEX = /[\t-\r \x85\u200E\u200F\u2028\u2029]/i;
  function parseNumberSkeletonFromString(skeleton) {
    if (skeleton.length === 0) {
      throw new Error('Number skeleton cannot be empty');
    }
    var stringTokens = skeleton.split(WHITE_SPACE_REGEX).filter(function (x) {
      return x.length > 0;
    });
    var tokens = [];
    for (var _i = 0, stringTokens_1 = stringTokens; _i < stringTokens_1.length; _i++) {
      var stringToken = stringTokens_1[_i];
      var stemAndOptions = stringToken.split('/');
      if (stemAndOptions.length === 0) {
        throw new Error('Invalid number skeleton');
      }
      var stem = stemAndOptions[0],
        options2 = stemAndOptions.slice(1);
      for (var _a2 = 0, options_1 = options2; _a2 < options_1.length; _a2++) {
        var option = options_1[_a2];
        if (option.length === 0) {
          throw new Error('Invalid number skeleton');
        }
      }
      tokens.push({ stem, options: options2 });
    }
    return tokens;
  }
  function icuUnitToEcma(unit) {
    return unit.replace(/^(.*?)-/, '');
  }
  var FRACTION_PRECISION_REGEX = /^\.(?:(0+)(\*)?|(#+)|(0+)(#+))$/g;
  var SIGNIFICANT_PRECISION_REGEX = /^(@+)?(\+|#+)?[rs]?$/g;
  var INTEGER_WIDTH_REGEX = /(\*)(0+)|(#+)(0+)|(0+)/g;
  var CONCISE_INTEGER_WIDTH_REGEX = /^(0+)$/;
  function parseSignificantPrecision(str) {
    var result = {};
    if (str[str.length - 1] === 'r') {
      result.roundingPriority = 'morePrecision';
    } else if (str[str.length - 1] === 's') {
      result.roundingPriority = 'lessPrecision';
    }
    str.replace(SIGNIFICANT_PRECISION_REGEX, function (_, g1, g2) {
      if (typeof g2 !== 'string') {
        result.minimumSignificantDigits = g1.length;
        result.maximumSignificantDigits = g1.length;
      } else if (g2 === '+') {
        result.minimumSignificantDigits = g1.length;
      } else if (g1[0] === '#') {
        result.maximumSignificantDigits = g1.length;
      } else {
        result.minimumSignificantDigits = g1.length;
        result.maximumSignificantDigits = g1.length + (typeof g2 === 'string' ? g2.length : 0);
      }
      return '';
    });
    return result;
  }
  function parseSign(str) {
    switch (str) {
      case 'sign-auto':
        return {
          signDisplay: 'auto',
        };
      case 'sign-accounting':
      case '()':
        return {
          currencySign: 'accounting',
        };
      case 'sign-always':
      case '+!':
        return {
          signDisplay: 'always',
        };
      case 'sign-accounting-always':
      case '()!':
        return {
          signDisplay: 'always',
          currencySign: 'accounting',
        };
      case 'sign-except-zero':
      case '+?':
        return {
          signDisplay: 'exceptZero',
        };
      case 'sign-accounting-except-zero':
      case '()?':
        return {
          signDisplay: 'exceptZero',
          currencySign: 'accounting',
        };
      case 'sign-never':
      case '+_':
        return {
          signDisplay: 'never',
        };
    }
  }
  function parseConciseScientificAndEngineeringStem(stem) {
    var result;
    if (stem[0] === 'E' && stem[1] === 'E') {
      result = {
        notation: 'engineering',
      };
      stem = stem.slice(2);
    } else if (stem[0] === 'E') {
      result = {
        notation: 'scientific',
      };
      stem = stem.slice(1);
    }
    if (result) {
      var signDisplay = stem.slice(0, 2);
      if (signDisplay === '+!') {
        result.signDisplay = 'always';
        stem = stem.slice(2);
      } else if (signDisplay === '+?') {
        result.signDisplay = 'exceptZero';
        stem = stem.slice(2);
      }
      if (!CONCISE_INTEGER_WIDTH_REGEX.test(stem)) {
        throw new Error('Malformed concise eng/scientific notation');
      }
      result.minimumIntegerDigits = stem.length;
    }
    return result;
  }
  function parseNotationOptions(opt) {
    var result = {};
    var signOpts = parseSign(opt);
    if (signOpts) {
      return signOpts;
    }
    return result;
  }
  function parseNumberSkeleton(tokens) {
    var result = {};
    for (var _i = 0, tokens_1 = tokens; _i < tokens_1.length; _i++) {
      var token = tokens_1[_i];
      switch (token.stem) {
        case 'percent':
        case '%':
          result.style = 'percent';
          continue;
        case '%x100':
          result.style = 'percent';
          result.scale = 100;
          continue;
        case 'currency':
          result.style = 'currency';
          result.currency = token.options[0];
          continue;
        case 'group-off':
        case ',_':
          result.useGrouping = false;
          continue;
        case 'precision-integer':
        case '.':
          result.maximumFractionDigits = 0;
          continue;
        case 'measure-unit':
        case 'unit':
          result.style = 'unit';
          result.unit = icuUnitToEcma(token.options[0]);
          continue;
        case 'compact-short':
        case 'K':
          result.notation = 'compact';
          result.compactDisplay = 'short';
          continue;
        case 'compact-long':
        case 'KK':
          result.notation = 'compact';
          result.compactDisplay = 'long';
          continue;
        case 'scientific':
          result = __assign(
            __assign(__assign({}, result), { notation: 'scientific' }),
            token.options.reduce(function (all, opt2) {
              return __assign(__assign({}, all), parseNotationOptions(opt2));
            }, {}),
          );
          continue;
        case 'engineering':
          result = __assign(
            __assign(__assign({}, result), { notation: 'engineering' }),
            token.options.reduce(function (all, opt2) {
              return __assign(__assign({}, all), parseNotationOptions(opt2));
            }, {}),
          );
          continue;
        case 'notation-simple':
          result.notation = 'standard';
          continue;
        // https://github.com/unicode-org/icu/blob/master/icu4c/source/i18n/unicode/unumberformatter.h
        case 'unit-width-narrow':
          result.currencyDisplay = 'narrowSymbol';
          result.unitDisplay = 'narrow';
          continue;
        case 'unit-width-short':
          result.currencyDisplay = 'code';
          result.unitDisplay = 'short';
          continue;
        case 'unit-width-full-name':
          result.currencyDisplay = 'name';
          result.unitDisplay = 'long';
          continue;
        case 'unit-width-iso-code':
          result.currencyDisplay = 'symbol';
          continue;
        case 'scale':
          result.scale = parseFloat(token.options[0]);
          continue;
        case 'rounding-mode-floor':
          result.roundingMode = 'floor';
          continue;
        case 'rounding-mode-ceiling':
          result.roundingMode = 'ceil';
          continue;
        case 'rounding-mode-down':
          result.roundingMode = 'trunc';
          continue;
        case 'rounding-mode-up':
          result.roundingMode = 'expand';
          continue;
        case 'rounding-mode-half-even':
          result.roundingMode = 'halfEven';
          continue;
        case 'rounding-mode-half-down':
          result.roundingMode = 'halfTrunc';
          continue;
        case 'rounding-mode-half-up':
          result.roundingMode = 'halfExpand';
          continue;
        // https://unicode-org.github.io/icu/userguide/format_parse/numbers/skeletons.html#integer-width
        case 'integer-width':
          if (token.options.length > 1) {
            throw new RangeError('integer-width stems only accept a single optional option');
          }
          token.options[0].replace(INTEGER_WIDTH_REGEX, function (_, g1, g2, g3, g4, g5) {
            if (g1) {
              result.minimumIntegerDigits = g2.length;
            } else if (g3 && g4) {
              throw new Error('We currently do not support maximum integer digits');
            } else if (g5) {
              throw new Error('We currently do not support exact integer digits');
            }
            return '';
          });
          continue;
      }
      if (CONCISE_INTEGER_WIDTH_REGEX.test(token.stem)) {
        result.minimumIntegerDigits = token.stem.length;
        continue;
      }
      if (FRACTION_PRECISION_REGEX.test(token.stem)) {
        if (token.options.length > 1) {
          throw new RangeError('Fraction-precision stems only accept a single optional option');
        }
        token.stem.replace(FRACTION_PRECISION_REGEX, function (_, g1, g2, g3, g4, g5) {
          if (g2 === '*') {
            result.minimumFractionDigits = g1.length;
          } else if (g3 && g3[0] === '#') {
            result.maximumFractionDigits = g3.length;
          } else if (g4 && g5) {
            result.minimumFractionDigits = g4.length;
            result.maximumFractionDigits = g4.length + g5.length;
          } else {
            result.minimumFractionDigits = g1.length;
            result.maximumFractionDigits = g1.length;
          }
          return '';
        });
        var opt = token.options[0];
        if (opt === 'w') {
          result = __assign(__assign({}, result), { trailingZeroDisplay: 'stripIfInteger' });
        } else if (opt) {
          result = __assign(__assign({}, result), parseSignificantPrecision(opt));
        }
        continue;
      }
      if (SIGNIFICANT_PRECISION_REGEX.test(token.stem)) {
        result = __assign(__assign({}, result), parseSignificantPrecision(token.stem));
        continue;
      }
      var signOpts = parseSign(token.stem);
      if (signOpts) {
        result = __assign(__assign({}, result), signOpts);
      }
      var conciseScientificAndEngineeringOpts = parseConciseScientificAndEngineeringStem(token.stem);
      if (conciseScientificAndEngineeringOpts) {
        result = __assign(__assign({}, result), conciseScientificAndEngineeringOpts);
      }
    }
    return result;
  }
  var timeData = {
    '001': ['H', 'h'],
    419: ['h', 'H', 'hB', 'hb'],
    AC: ['H', 'h', 'hb', 'hB'],
    AD: ['H', 'hB'],
    AE: ['h', 'hB', 'hb', 'H'],
    AF: ['H', 'hb', 'hB', 'h'],
    AG: ['h', 'hb', 'H', 'hB'],
    AI: ['H', 'h', 'hb', 'hB'],
    AL: ['h', 'H', 'hB'],
    AM: ['H', 'hB'],
    AO: ['H', 'hB'],
    AR: ['h', 'H', 'hB', 'hb'],
    AS: ['h', 'H'],
    AT: ['H', 'hB'],
    AU: ['h', 'hb', 'H', 'hB'],
    AW: ['H', 'hB'],
    AX: ['H'],
    AZ: ['H', 'hB', 'h'],
    BA: ['H', 'hB', 'h'],
    BB: ['h', 'hb', 'H', 'hB'],
    BD: ['h', 'hB', 'H'],
    BE: ['H', 'hB'],
    BF: ['H', 'hB'],
    BG: ['H', 'hB', 'h'],
    BH: ['h', 'hB', 'hb', 'H'],
    BI: ['H', 'h'],
    BJ: ['H', 'hB'],
    BL: ['H', 'hB'],
    BM: ['h', 'hb', 'H', 'hB'],
    BN: ['hb', 'hB', 'h', 'H'],
    BO: ['h', 'H', 'hB', 'hb'],
    BQ: ['H'],
    BR: ['H', 'hB'],
    BS: ['h', 'hb', 'H', 'hB'],
    BT: ['h', 'H'],
    BW: ['H', 'h', 'hb', 'hB'],
    BY: ['H', 'h'],
    BZ: ['H', 'h', 'hb', 'hB'],
    CA: ['h', 'hb', 'H', 'hB'],
    CC: ['H', 'h', 'hb', 'hB'],
    CD: ['hB', 'H'],
    CF: ['H', 'h', 'hB'],
    CG: ['H', 'hB'],
    CH: ['H', 'hB', 'h'],
    CI: ['H', 'hB'],
    CK: ['H', 'h', 'hb', 'hB'],
    CL: ['h', 'H', 'hB', 'hb'],
    CM: ['H', 'h', 'hB'],
    CN: ['H', 'hB', 'hb', 'h'],
    CO: ['h', 'H', 'hB', 'hb'],
    CP: ['H'],
    CR: ['h', 'H', 'hB', 'hb'],
    CU: ['h', 'H', 'hB', 'hb'],
    CV: ['H', 'hB'],
    CW: ['H', 'hB'],
    CX: ['H', 'h', 'hb', 'hB'],
    CY: ['h', 'H', 'hb', 'hB'],
    CZ: ['H'],
    DE: ['H', 'hB'],
    DG: ['H', 'h', 'hb', 'hB'],
    DJ: ['h', 'H'],
    DK: ['H'],
    DM: ['h', 'hb', 'H', 'hB'],
    DO: ['h', 'H', 'hB', 'hb'],
    DZ: ['h', 'hB', 'hb', 'H'],
    EA: ['H', 'h', 'hB', 'hb'],
    EC: ['h', 'H', 'hB', 'hb'],
    EE: ['H', 'hB'],
    EG: ['h', 'hB', 'hb', 'H'],
    EH: ['h', 'hB', 'hb', 'H'],
    ER: ['h', 'H'],
    ES: ['H', 'hB', 'h', 'hb'],
    ET: ['hB', 'hb', 'h', 'H'],
    FI: ['H'],
    FJ: ['h', 'hb', 'H', 'hB'],
    FK: ['H', 'h', 'hb', 'hB'],
    FM: ['h', 'hb', 'H', 'hB'],
    FO: ['H', 'h'],
    FR: ['H', 'hB'],
    GA: ['H', 'hB'],
    GB: ['H', 'h', 'hb', 'hB'],
    GD: ['h', 'hb', 'H', 'hB'],
    GE: ['H', 'hB', 'h'],
    GF: ['H', 'hB'],
    GG: ['H', 'h', 'hb', 'hB'],
    GH: ['h', 'H'],
    GI: ['H', 'h', 'hb', 'hB'],
    GL: ['H', 'h'],
    GM: ['h', 'hb', 'H', 'hB'],
    GN: ['H', 'hB'],
    GP: ['H', 'hB'],
    GQ: ['H', 'hB', 'h', 'hb'],
    GR: ['h', 'H', 'hb', 'hB'],
    GT: ['h', 'H', 'hB', 'hb'],
    GU: ['h', 'hb', 'H', 'hB'],
    GW: ['H', 'hB'],
    GY: ['h', 'hb', 'H', 'hB'],
    HK: ['h', 'hB', 'hb', 'H'],
    HN: ['h', 'H', 'hB', 'hb'],
    HR: ['H', 'hB'],
    HU: ['H', 'h'],
    IC: ['H', 'h', 'hB', 'hb'],
    ID: ['H'],
    IE: ['H', 'h', 'hb', 'hB'],
    IL: ['H', 'hB'],
    IM: ['H', 'h', 'hb', 'hB'],
    IN: ['h', 'H'],
    IO: ['H', 'h', 'hb', 'hB'],
    IQ: ['h', 'hB', 'hb', 'H'],
    IR: ['hB', 'H'],
    IS: ['H'],
    IT: ['H', 'hB'],
    JE: ['H', 'h', 'hb', 'hB'],
    JM: ['h', 'hb', 'H', 'hB'],
    JO: ['h', 'hB', 'hb', 'H'],
    JP: ['H', 'K', 'h'],
    KE: ['hB', 'hb', 'H', 'h'],
    KG: ['H', 'h', 'hB', 'hb'],
    KH: ['hB', 'h', 'H', 'hb'],
    KI: ['h', 'hb', 'H', 'hB'],
    KM: ['H', 'h', 'hB', 'hb'],
    KN: ['h', 'hb', 'H', 'hB'],
    KP: ['h', 'H', 'hB', 'hb'],
    KR: ['h', 'H', 'hB', 'hb'],
    KW: ['h', 'hB', 'hb', 'H'],
    KY: ['h', 'hb', 'H', 'hB'],
    KZ: ['H', 'hB'],
    LA: ['H', 'hb', 'hB', 'h'],
    LB: ['h', 'hB', 'hb', 'H'],
    LC: ['h', 'hb', 'H', 'hB'],
    LI: ['H', 'hB', 'h'],
    LK: ['H', 'h', 'hB', 'hb'],
    LR: ['h', 'hb', 'H', 'hB'],
    LS: ['h', 'H'],
    LT: ['H', 'h', 'hb', 'hB'],
    LU: ['H', 'h', 'hB'],
    LV: ['H', 'hB', 'hb', 'h'],
    LY: ['h', 'hB', 'hb', 'H'],
    MA: ['H', 'h', 'hB', 'hb'],
    MC: ['H', 'hB'],
    MD: ['H', 'hB'],
    ME: ['H', 'hB', 'h'],
    MF: ['H', 'hB'],
    MG: ['H', 'h'],
    MH: ['h', 'hb', 'H', 'hB'],
    MK: ['H', 'h', 'hb', 'hB'],
    ML: ['H'],
    MM: ['hB', 'hb', 'H', 'h'],
    MN: ['H', 'h', 'hb', 'hB'],
    MO: ['h', 'hB', 'hb', 'H'],
    MP: ['h', 'hb', 'H', 'hB'],
    MQ: ['H', 'hB'],
    MR: ['h', 'hB', 'hb', 'H'],
    MS: ['H', 'h', 'hb', 'hB'],
    MT: ['H', 'h'],
    MU: ['H', 'h'],
    MV: ['H', 'h'],
    MW: ['h', 'hb', 'H', 'hB'],
    MX: ['h', 'H', 'hB', 'hb'],
    MY: ['hb', 'hB', 'h', 'H'],
    MZ: ['H', 'hB'],
    NA: ['h', 'H', 'hB', 'hb'],
    NC: ['H', 'hB'],
    NE: ['H'],
    NF: ['H', 'h', 'hb', 'hB'],
    NG: ['H', 'h', 'hb', 'hB'],
    NI: ['h', 'H', 'hB', 'hb'],
    NL: ['H', 'hB'],
    NO: ['H', 'h'],
    NP: ['H', 'h', 'hB'],
    NR: ['H', 'h', 'hb', 'hB'],
    NU: ['H', 'h', 'hb', 'hB'],
    NZ: ['h', 'hb', 'H', 'hB'],
    OM: ['h', 'hB', 'hb', 'H'],
    PA: ['h', 'H', 'hB', 'hb'],
    PE: ['h', 'H', 'hB', 'hb'],
    PF: ['H', 'h', 'hB'],
    PG: ['h', 'H'],
    PH: ['h', 'hB', 'hb', 'H'],
    PK: ['h', 'hB', 'H'],
    PL: ['H', 'h'],
    PM: ['H', 'hB'],
    PN: ['H', 'h', 'hb', 'hB'],
    PR: ['h', 'H', 'hB', 'hb'],
    PS: ['h', 'hB', 'hb', 'H'],
    PT: ['H', 'hB'],
    PW: ['h', 'H'],
    PY: ['h', 'H', 'hB', 'hb'],
    QA: ['h', 'hB', 'hb', 'H'],
    RE: ['H', 'hB'],
    RO: ['H', 'hB'],
    RS: ['H', 'hB', 'h'],
    RU: ['H'],
    RW: ['H', 'h'],
    SA: ['h', 'hB', 'hb', 'H'],
    SB: ['h', 'hb', 'H', 'hB'],
    SC: ['H', 'h', 'hB'],
    SD: ['h', 'hB', 'hb', 'H'],
    SE: ['H'],
    SG: ['h', 'hb', 'H', 'hB'],
    SH: ['H', 'h', 'hb', 'hB'],
    SI: ['H', 'hB'],
    SJ: ['H'],
    SK: ['H'],
    SL: ['h', 'hb', 'H', 'hB'],
    SM: ['H', 'h', 'hB'],
    SN: ['H', 'h', 'hB'],
    SO: ['h', 'H'],
    SR: ['H', 'hB'],
    SS: ['h', 'hb', 'H', 'hB'],
    ST: ['H', 'hB'],
    SV: ['h', 'H', 'hB', 'hb'],
    SX: ['H', 'h', 'hb', 'hB'],
    SY: ['h', 'hB', 'hb', 'H'],
    SZ: ['h', 'hb', 'H', 'hB'],
    TA: ['H', 'h', 'hb', 'hB'],
    TC: ['h', 'hb', 'H', 'hB'],
    TD: ['h', 'H', 'hB'],
    TF: ['H', 'h', 'hB'],
    TG: ['H', 'hB'],
    TH: ['H', 'h'],
    TJ: ['H', 'h'],
    TL: ['H', 'hB', 'hb', 'h'],
    TM: ['H', 'h'],
    TN: ['h', 'hB', 'hb', 'H'],
    TO: ['h', 'H'],
    TR: ['H', 'hB'],
    TT: ['h', 'hb', 'H', 'hB'],
    TW: ['hB', 'hb', 'h', 'H'],
    TZ: ['hB', 'hb', 'H', 'h'],
    UA: ['H', 'hB', 'h'],
    UG: ['hB', 'hb', 'H', 'h'],
    UM: ['h', 'hb', 'H', 'hB'],
    US: ['h', 'hb', 'H', 'hB'],
    UY: ['h', 'H', 'hB', 'hb'],
    UZ: ['H', 'hB', 'h'],
    VA: ['H', 'h', 'hB'],
    VC: ['h', 'hb', 'H', 'hB'],
    VE: ['h', 'H', 'hB', 'hb'],
    VG: ['h', 'hb', 'H', 'hB'],
    VI: ['h', 'hb', 'H', 'hB'],
    VN: ['H', 'h'],
    VU: ['h', 'H'],
    WF: ['H', 'hB'],
    WS: ['h', 'H'],
    XK: ['H', 'hB', 'h'],
    YE: ['h', 'hB', 'hb', 'H'],
    YT: ['H', 'hB'],
    ZA: ['H', 'h', 'hb', 'hB'],
    ZM: ['h', 'hb', 'H', 'hB'],
    ZW: ['H', 'h'],
    'af-ZA': ['H', 'h', 'hB', 'hb'],
    'ar-001': ['h', 'hB', 'hb', 'H'],
    'ca-ES': ['H', 'h', 'hB'],
    'en-001': ['h', 'hb', 'H', 'hB'],
    'en-HK': ['h', 'hb', 'H', 'hB'],
    'en-IL': ['H', 'h', 'hb', 'hB'],
    'en-MY': ['h', 'hb', 'H', 'hB'],
    'es-BR': ['H', 'h', 'hB', 'hb'],
    'es-ES': ['H', 'h', 'hB', 'hb'],
    'es-GQ': ['H', 'h', 'hB', 'hb'],
    'fr-CA': ['H', 'h', 'hB'],
    'gl-ES': ['H', 'h', 'hB'],
    'gu-IN': ['hB', 'hb', 'h', 'H'],
    'hi-IN': ['hB', 'h', 'H'],
    'it-CH': ['H', 'h', 'hB'],
    'it-IT': ['H', 'h', 'hB'],
    'kn-IN': ['hB', 'h', 'H'],
    'ml-IN': ['hB', 'h', 'H'],
    'mr-IN': ['hB', 'hb', 'h', 'H'],
    'pa-IN': ['hB', 'hb', 'h', 'H'],
    'ta-IN': ['hB', 'h', 'hb', 'H'],
    'te-IN': ['hB', 'h', 'H'],
    'zu-ZA': ['H', 'hB', 'hb', 'h'],
  };
  function getBestPattern(skeleton, locale) {
    var skeletonCopy = '';
    for (var patternPos = 0; patternPos < skeleton.length; patternPos++) {
      var patternChar = skeleton.charAt(patternPos);
      if (patternChar === 'j') {
        var extraLength = 0;
        while (patternPos + 1 < skeleton.length && skeleton.charAt(patternPos + 1) === patternChar) {
          extraLength++;
          patternPos++;
        }
        var hourLen = 1 + (extraLength & 1);
        var dayPeriodLen = extraLength < 2 ? 1 : 3 + (extraLength >> 1);
        var dayPeriodChar = 'a';
        var hourChar = getDefaultHourSymbolFromLocale(locale);
        if (hourChar == 'H' || hourChar == 'k') {
          dayPeriodLen = 0;
        }
        while (dayPeriodLen-- > 0) {
          skeletonCopy += dayPeriodChar;
        }
        while (hourLen-- > 0) {
          skeletonCopy = hourChar + skeletonCopy;
        }
      } else if (patternChar === 'J') {
        skeletonCopy += 'H';
      } else {
        skeletonCopy += patternChar;
      }
    }
    return skeletonCopy;
  }
  function getDefaultHourSymbolFromLocale(locale) {
    var hourCycle = locale.hourCycle;
    if (
      hourCycle === void 0 && // @ts-ignore hourCycle(s) is not identified yet
      locale.hourCycles && // @ts-ignore
      locale.hourCycles.length
    ) {
      hourCycle = locale.hourCycles[0];
    }
    if (hourCycle) {
      switch (hourCycle) {
        case 'h24':
          return 'k';
        case 'h23':
          return 'H';
        case 'h12':
          return 'h';
        case 'h11':
          return 'K';
        default:
          throw new Error('Invalid hourCycle');
      }
    }
    var languageTag = locale.language;
    var regionTag;
    if (languageTag !== 'root') {
      regionTag = locale.maximize().region;
    }
    var hourCycles =
      timeData[regionTag || ''] ||
      timeData[languageTag || ''] ||
      timeData[''.concat(languageTag, '-001')] ||
      timeData['001'];
    return hourCycles[0];
  }
  var _a;
  var SPACE_SEPARATOR_START_REGEX = new RegExp('^'.concat(SPACE_SEPARATOR_REGEX.source, '*'));
  var SPACE_SEPARATOR_END_REGEX = new RegExp(''.concat(SPACE_SEPARATOR_REGEX.source, '*$'));
  function createLocation(start, end) {
    return { start, end };
  }
  var hasNativeStartsWith = !!String.prototype.startsWith && '_a'.startsWith('a', 1);
  var hasNativeFromCodePoint = !!String.fromCodePoint;
  var hasNativeFromEntries = !!Object.fromEntries;
  var hasNativeCodePointAt = !!String.prototype.codePointAt;
  var hasTrimStart = !!String.prototype.trimStart;
  var hasTrimEnd = !!String.prototype.trimEnd;
  var hasNativeIsSafeInteger = !!Number.isSafeInteger;
  var isSafeInteger = hasNativeIsSafeInteger
    ? Number.isSafeInteger
    : function (n) {
        return typeof n === 'number' && isFinite(n) && Math.floor(n) === n && Math.abs(n) <= 9007199254740991;
      };
  var REGEX_SUPPORTS_U_AND_Y = true;
  try {
    var re = RE('([^\\p{White_Space}\\p{Pattern_Syntax}]*)', 'yu');
    REGEX_SUPPORTS_U_AND_Y = ((_a = re.exec('a')) === null || _a === void 0 ? void 0 : _a[0]) === 'a';
  } catch (_) {
    REGEX_SUPPORTS_U_AND_Y = false;
  }
  var startsWith = hasNativeStartsWith
    ? // Native
      function startsWith2(s, search, position) {
        return s.startsWith(search, position);
      }
    : // For IE11
      function startsWith2(s, search, position) {
        return s.slice(position, position + search.length) === search;
      };
  var fromCodePoint = hasNativeFromCodePoint
    ? String.fromCodePoint
    : // IE11
      function fromCodePoint2() {
        var codePoints = [];
        for (var _i = 0; _i < arguments.length; _i++) {
          codePoints[_i] = arguments[_i];
        }
        var elements = '';
        var length = codePoints.length;
        var i = 0;
        var code;
        while (length > i) {
          code = codePoints[i++];
          if (code > 1114111) throw RangeError(code + ' is not a valid code point');
          elements +=
            code < 65536
              ? String.fromCharCode(code)
              : String.fromCharCode(((code -= 65536) >> 10) + 55296, (code % 1024) + 56320);
        }
        return elements;
      };
  var fromEntries =
    // native
    hasNativeFromEntries
      ? Object.fromEntries
      : // Ponyfill
        function fromEntries2(entries) {
          var obj = {};
          for (var _i = 0, entries_1 = entries; _i < entries_1.length; _i++) {
            var _a2 = entries_1[_i],
              k = _a2[0],
              v = _a2[1];
            obj[k] = v;
          }
          return obj;
        };
  var codePointAt = hasNativeCodePointAt
    ? // Native
      function codePointAt2(s, index) {
        return s.codePointAt(index);
      }
    : // IE 11
      function codePointAt2(s, index) {
        var size = s.length;
        if (index < 0 || index >= size) {
          return void 0;
        }
        var first = s.charCodeAt(index);
        var second;
        return first < 55296 ||
          first > 56319 ||
          index + 1 === size ||
          (second = s.charCodeAt(index + 1)) < 56320 ||
          second > 57343
          ? first
          : ((first - 55296) << 10) + (second - 56320) + 65536;
      };
  var trimStart = hasTrimStart
    ? // Native
      function trimStart2(s) {
        return s.trimStart();
      }
    : // Ponyfill
      function trimStart2(s) {
        return s.replace(SPACE_SEPARATOR_START_REGEX, '');
      };
  var trimEnd = hasTrimEnd
    ? // Native
      function trimEnd2(s) {
        return s.trimEnd();
      }
    : // Ponyfill
      function trimEnd2(s) {
        return s.replace(SPACE_SEPARATOR_END_REGEX, '');
      };
  function RE(s, flag) {
    return new RegExp(s, flag);
  }
  var matchIdentifierAtIndex;
  if (REGEX_SUPPORTS_U_AND_Y) {
    var IDENTIFIER_PREFIX_RE_1 = RE('([^\\p{White_Space}\\p{Pattern_Syntax}]*)', 'yu');
    matchIdentifierAtIndex = function matchIdentifierAtIndex2(s, index) {
      var _a2;
      IDENTIFIER_PREFIX_RE_1.lastIndex = index;
      var match = IDENTIFIER_PREFIX_RE_1.exec(s);
      return (_a2 = match[1]) !== null && _a2 !== void 0 ? _a2 : '';
    };
  } else {
    matchIdentifierAtIndex = function matchIdentifierAtIndex2(s, index) {
      var match = [];
      while (true) {
        var c = codePointAt(s, index);
        if (c === void 0 || _isWhiteSpace(c) || _isPatternSyntax(c)) {
          break;
        }
        match.push(c);
        index += c >= 65536 ? 2 : 1;
      }
      return fromCodePoint.apply(void 0, match);
    };
  }
  var Parser =
    /** @class */
    (function () {
      function Parser2(message, options2) {
        if (options2 === void 0) {
          options2 = {};
        }
        this.message = message;
        this.position = { offset: 0, line: 1, column: 1 };
        this.ignoreTag = !!options2.ignoreTag;
        this.locale = options2.locale;
        this.requiresOtherClause = !!options2.requiresOtherClause;
        this.shouldParseSkeletons = !!options2.shouldParseSkeletons;
      }
      Parser2.prototype.parse = function () {
        if (this.offset() !== 0) {
          throw Error('parser can only be used once');
        }
        return this.parseMessage(0, '', false);
      };
      Parser2.prototype.parseMessage = function (nestingLevel, parentArgType, expectingCloseTag) {
        var elements = [];
        while (!this.isEOF()) {
          var char = this.char();
          if (char === 123) {
            var result = this.parseArgument(nestingLevel, expectingCloseTag);
            if (result.err) {
              return result;
            }
            elements.push(result.val);
          } else if (char === 125 && nestingLevel > 0) {
            break;
          } else if (char === 35 && (parentArgType === 'plural' || parentArgType === 'selectordinal')) {
            var position = this.clonePosition();
            this.bump();
            elements.push({
              type: TYPE.pound,
              location: createLocation(position, this.clonePosition()),
            });
          } else if (char === 60 && !this.ignoreTag && this.peek() === 47) {
            if (expectingCloseTag) {
              break;
            } else {
              return this.error(
                ErrorKind.UNMATCHED_CLOSING_TAG,
                createLocation(this.clonePosition(), this.clonePosition()),
              );
            }
          } else if (char === 60 && !this.ignoreTag && _isAlpha(this.peek() || 0)) {
            var result = this.parseTag(nestingLevel, parentArgType);
            if (result.err) {
              return result;
            }
            elements.push(result.val);
          } else {
            var result = this.parseLiteral(nestingLevel, parentArgType);
            if (result.err) {
              return result;
            }
            elements.push(result.val);
          }
        }
        return { val: elements, err: null };
      };
      Parser2.prototype.parseTag = function (nestingLevel, parentArgType) {
        var startPosition = this.clonePosition();
        this.bump();
        var tagName = this.parseTagName();
        this.bumpSpace();
        if (this.bumpIf('/>')) {
          return {
            val: {
              type: TYPE.literal,
              value: '<'.concat(tagName, '/>'),
              location: createLocation(startPosition, this.clonePosition()),
            },
            err: null,
          };
        } else if (this.bumpIf('>')) {
          var childrenResult = this.parseMessage(nestingLevel + 1, parentArgType, true);
          if (childrenResult.err) {
            return childrenResult;
          }
          var children = childrenResult.val;
          var endTagStartPosition = this.clonePosition();
          if (this.bumpIf('</')) {
            if (this.isEOF() || !_isAlpha(this.char())) {
              return this.error(ErrorKind.INVALID_TAG, createLocation(endTagStartPosition, this.clonePosition()));
            }
            var closingTagNameStartPosition = this.clonePosition();
            var closingTagName = this.parseTagName();
            if (tagName !== closingTagName) {
              return this.error(
                ErrorKind.UNMATCHED_CLOSING_TAG,
                createLocation(closingTagNameStartPosition, this.clonePosition()),
              );
            }
            this.bumpSpace();
            if (!this.bumpIf('>')) {
              return this.error(ErrorKind.INVALID_TAG, createLocation(endTagStartPosition, this.clonePosition()));
            }
            return {
              val: {
                type: TYPE.tag,
                value: tagName,
                children,
                location: createLocation(startPosition, this.clonePosition()),
              },
              err: null,
            };
          } else {
            return this.error(ErrorKind.UNCLOSED_TAG, createLocation(startPosition, this.clonePosition()));
          }
        } else {
          return this.error(ErrorKind.INVALID_TAG, createLocation(startPosition, this.clonePosition()));
        }
      };
      Parser2.prototype.parseTagName = function () {
        var startOffset = this.offset();
        this.bump();
        while (!this.isEOF() && _isPotentialElementNameChar(this.char())) {
          this.bump();
        }
        return this.message.slice(startOffset, this.offset());
      };
      Parser2.prototype.parseLiteral = function (nestingLevel, parentArgType) {
        var start = this.clonePosition();
        var value = '';
        while (true) {
          var parseQuoteResult = this.tryParseQuote(parentArgType);
          if (parseQuoteResult) {
            value += parseQuoteResult;
            continue;
          }
          var parseUnquotedResult = this.tryParseUnquoted(nestingLevel, parentArgType);
          if (parseUnquotedResult) {
            value += parseUnquotedResult;
            continue;
          }
          var parseLeftAngleResult = this.tryParseLeftAngleBracket();
          if (parseLeftAngleResult) {
            value += parseLeftAngleResult;
            continue;
          }
          break;
        }
        var location2 = createLocation(start, this.clonePosition());
        return {
          val: { type: TYPE.literal, value, location: location2 },
          err: null,
        };
      };
      Parser2.prototype.tryParseLeftAngleBracket = function () {
        if (
          !this.isEOF() &&
          this.char() === 60 &&
          (this.ignoreTag || // If at the opening tag or closing tag position, bail.
            !_isAlphaOrSlash(this.peek() || 0))
        ) {
          this.bump();
          return '<';
        }
        return null;
      };
      Parser2.prototype.tryParseQuote = function (parentArgType) {
        if (this.isEOF() || this.char() !== 39) {
          return null;
        }
        switch (this.peek()) {
          case 39:
            this.bump();
            this.bump();
            return "'";
          // '{', '<', '>', '}'
          case 123:
          case 60:
          case 62:
          case 125:
            break;
          case 35:
            if (parentArgType === 'plural' || parentArgType === 'selectordinal') {
              break;
            }
            return null;
          default:
            return null;
        }
        this.bump();
        var codePoints = [this.char()];
        this.bump();
        while (!this.isEOF()) {
          var ch = this.char();
          if (ch === 39) {
            if (this.peek() === 39) {
              codePoints.push(39);
              this.bump();
            } else {
              this.bump();
              break;
            }
          } else {
            codePoints.push(ch);
          }
          this.bump();
        }
        return fromCodePoint.apply(void 0, codePoints);
      };
      Parser2.prototype.tryParseUnquoted = function (nestingLevel, parentArgType) {
        if (this.isEOF()) {
          return null;
        }
        var ch = this.char();
        if (
          ch === 60 ||
          ch === 123 ||
          (ch === 35 && (parentArgType === 'plural' || parentArgType === 'selectordinal')) ||
          (ch === 125 && nestingLevel > 0)
        ) {
          return null;
        } else {
          this.bump();
          return fromCodePoint(ch);
        }
      };
      Parser2.prototype.parseArgument = function (nestingLevel, expectingCloseTag) {
        var openingBracePosition = this.clonePosition();
        this.bump();
        this.bumpSpace();
        if (this.isEOF()) {
          return this.error(
            ErrorKind.EXPECT_ARGUMENT_CLOSING_BRACE,
            createLocation(openingBracePosition, this.clonePosition()),
          );
        }
        if (this.char() === 125) {
          this.bump();
          return this.error(ErrorKind.EMPTY_ARGUMENT, createLocation(openingBracePosition, this.clonePosition()));
        }
        var value = this.parseIdentifierIfPossible().value;
        if (!value) {
          return this.error(ErrorKind.MALFORMED_ARGUMENT, createLocation(openingBracePosition, this.clonePosition()));
        }
        this.bumpSpace();
        if (this.isEOF()) {
          return this.error(
            ErrorKind.EXPECT_ARGUMENT_CLOSING_BRACE,
            createLocation(openingBracePosition, this.clonePosition()),
          );
        }
        switch (this.char()) {
          // Simple argument: `{name}`
          case 125: {
            this.bump();
            return {
              val: {
                type: TYPE.argument,
                // value does not include the opening and closing braces.
                value,
                location: createLocation(openingBracePosition, this.clonePosition()),
              },
              err: null,
            };
          }
          // Argument with options: `{name, format, ...}`
          case 44: {
            this.bump();
            this.bumpSpace();
            if (this.isEOF()) {
              return this.error(
                ErrorKind.EXPECT_ARGUMENT_CLOSING_BRACE,
                createLocation(openingBracePosition, this.clonePosition()),
              );
            }
            return this.parseArgumentOptions(nestingLevel, expectingCloseTag, value, openingBracePosition);
          }
          default:
            return this.error(ErrorKind.MALFORMED_ARGUMENT, createLocation(openingBracePosition, this.clonePosition()));
        }
      };
      Parser2.prototype.parseIdentifierIfPossible = function () {
        var startingPosition = this.clonePosition();
        var startOffset = this.offset();
        var value = matchIdentifierAtIndex(this.message, startOffset);
        var endOffset = startOffset + value.length;
        this.bumpTo(endOffset);
        var endPosition = this.clonePosition();
        var location2 = createLocation(startingPosition, endPosition);
        return { value, location: location2 };
      };
      Parser2.prototype.parseArgumentOptions = function (nestingLevel, expectingCloseTag, value, openingBracePosition) {
        var _a2;
        var typeStartPosition = this.clonePosition();
        var argType = this.parseIdentifierIfPossible().value;
        var typeEndPosition = this.clonePosition();
        switch (argType) {
          case '':
            return this.error(ErrorKind.EXPECT_ARGUMENT_TYPE, createLocation(typeStartPosition, typeEndPosition));
          case 'number':
          case 'date':
          case 'time': {
            this.bumpSpace();
            var styleAndLocation = null;
            if (this.bumpIf(',')) {
              this.bumpSpace();
              var styleStartPosition = this.clonePosition();
              var result = this.parseSimpleArgStyleIfPossible();
              if (result.err) {
                return result;
              }
              var style = trimEnd(result.val);
              if (style.length === 0) {
                return this.error(
                  ErrorKind.EXPECT_ARGUMENT_STYLE,
                  createLocation(this.clonePosition(), this.clonePosition()),
                );
              }
              var styleLocation = createLocation(styleStartPosition, this.clonePosition());
              styleAndLocation = { style, styleLocation };
            }
            var argCloseResult = this.tryParseArgumentClose(openingBracePosition);
            if (argCloseResult.err) {
              return argCloseResult;
            }
            var location_1 = createLocation(openingBracePosition, this.clonePosition());
            if (
              styleAndLocation &&
              startsWith(
                styleAndLocation === null || styleAndLocation === void 0 ? void 0 : styleAndLocation.style,
                '::',
                0,
              )
            ) {
              var skeleton = trimStart(styleAndLocation.style.slice(2));
              if (argType === 'number') {
                var result = this.parseNumberSkeletonFromString(skeleton, styleAndLocation.styleLocation);
                if (result.err) {
                  return result;
                }
                return {
                  val: { type: TYPE.number, value, location: location_1, style: result.val },
                  err: null,
                };
              } else {
                if (skeleton.length === 0) {
                  return this.error(ErrorKind.EXPECT_DATE_TIME_SKELETON, location_1);
                }
                var dateTimePattern = skeleton;
                if (this.locale) {
                  dateTimePattern = getBestPattern(skeleton, this.locale);
                }
                var style = {
                  type: SKELETON_TYPE.dateTime,
                  pattern: dateTimePattern,
                  location: styleAndLocation.styleLocation,
                  parsedOptions: this.shouldParseSkeletons ? parseDateTimeSkeleton(dateTimePattern) : {},
                };
                var type = argType === 'date' ? TYPE.date : TYPE.time;
                return {
                  val: { type, value, location: location_1, style },
                  err: null,
                };
              }
            }
            return {
              val: {
                type: argType === 'number' ? TYPE.number : argType === 'date' ? TYPE.date : TYPE.time,
                value,
                location: location_1,
                style:
                  (_a2 = styleAndLocation === null || styleAndLocation === void 0 ? void 0 : styleAndLocation.style) !==
                    null && _a2 !== void 0
                    ? _a2
                    : null,
              },
              err: null,
            };
          }
          case 'plural':
          case 'selectordinal':
          case 'select': {
            var typeEndPosition_1 = this.clonePosition();
            this.bumpSpace();
            if (!this.bumpIf(',')) {
              return this.error(
                ErrorKind.EXPECT_SELECT_ARGUMENT_OPTIONS,
                createLocation(typeEndPosition_1, __assign({}, typeEndPosition_1)),
              );
            }
            this.bumpSpace();
            var identifierAndLocation = this.parseIdentifierIfPossible();
            var pluralOffset = 0;
            if (argType !== 'select' && identifierAndLocation.value === 'offset') {
              if (!this.bumpIf(':')) {
                return this.error(
                  ErrorKind.EXPECT_PLURAL_ARGUMENT_OFFSET_VALUE,
                  createLocation(this.clonePosition(), this.clonePosition()),
                );
              }
              this.bumpSpace();
              var result = this.tryParseDecimalInteger(
                ErrorKind.EXPECT_PLURAL_ARGUMENT_OFFSET_VALUE,
                ErrorKind.INVALID_PLURAL_ARGUMENT_OFFSET_VALUE,
              );
              if (result.err) {
                return result;
              }
              this.bumpSpace();
              identifierAndLocation = this.parseIdentifierIfPossible();
              pluralOffset = result.val;
            }
            var optionsResult = this.tryParsePluralOrSelectOptions(
              nestingLevel,
              argType,
              expectingCloseTag,
              identifierAndLocation,
            );
            if (optionsResult.err) {
              return optionsResult;
            }
            var argCloseResult = this.tryParseArgumentClose(openingBracePosition);
            if (argCloseResult.err) {
              return argCloseResult;
            }
            var location_2 = createLocation(openingBracePosition, this.clonePosition());
            if (argType === 'select') {
              return {
                val: {
                  type: TYPE.select,
                  value,
                  options: fromEntries(optionsResult.val),
                  location: location_2,
                },
                err: null,
              };
            } else {
              return {
                val: {
                  type: TYPE.plural,
                  value,
                  options: fromEntries(optionsResult.val),
                  offset: pluralOffset,
                  pluralType: argType === 'plural' ? 'cardinal' : 'ordinal',
                  location: location_2,
                },
                err: null,
              };
            }
          }
          default:
            return this.error(ErrorKind.INVALID_ARGUMENT_TYPE, createLocation(typeStartPosition, typeEndPosition));
        }
      };
      Parser2.prototype.tryParseArgumentClose = function (openingBracePosition) {
        if (this.isEOF() || this.char() !== 125) {
          return this.error(
            ErrorKind.EXPECT_ARGUMENT_CLOSING_BRACE,
            createLocation(openingBracePosition, this.clonePosition()),
          );
        }
        this.bump();
        return { val: true, err: null };
      };
      Parser2.prototype.parseSimpleArgStyleIfPossible = function () {
        var nestedBraces = 0;
        var startPosition = this.clonePosition();
        while (!this.isEOF()) {
          var ch = this.char();
          switch (ch) {
            case 39: {
              this.bump();
              var apostrophePosition = this.clonePosition();
              if (!this.bumpUntil("'")) {
                return this.error(
                  ErrorKind.UNCLOSED_QUOTE_IN_ARGUMENT_STYLE,
                  createLocation(apostrophePosition, this.clonePosition()),
                );
              }
              this.bump();
              break;
            }
            case 123: {
              nestedBraces += 1;
              this.bump();
              break;
            }
            case 125: {
              if (nestedBraces > 0) {
                nestedBraces -= 1;
              } else {
                return {
                  val: this.message.slice(startPosition.offset, this.offset()),
                  err: null,
                };
              }
              break;
            }
            default:
              this.bump();
              break;
          }
        }
        return {
          val: this.message.slice(startPosition.offset, this.offset()),
          err: null,
        };
      };
      Parser2.prototype.parseNumberSkeletonFromString = function (skeleton, location2) {
        var tokens = [];
        try {
          tokens = parseNumberSkeletonFromString(skeleton);
        } catch (e) {
          return this.error(ErrorKind.INVALID_NUMBER_SKELETON, location2);
        }
        return {
          val: {
            type: SKELETON_TYPE.number,
            tokens,
            location: location2,
            parsedOptions: this.shouldParseSkeletons ? parseNumberSkeleton(tokens) : {},
          },
          err: null,
        };
      };
      Parser2.prototype.tryParsePluralOrSelectOptions = function (
        nestingLevel,
        parentArgType,
        expectCloseTag,
        parsedFirstIdentifier,
      ) {
        var _a2;
        var hasOtherClause = false;
        var options2 = [];
        var parsedSelectors = /* @__PURE__ */ new Set();
        var selector = parsedFirstIdentifier.value,
          selectorLocation = parsedFirstIdentifier.location;
        while (true) {
          if (selector.length === 0) {
            var startPosition = this.clonePosition();
            if (parentArgType !== 'select' && this.bumpIf('=')) {
              var result = this.tryParseDecimalInteger(
                ErrorKind.EXPECT_PLURAL_ARGUMENT_SELECTOR,
                ErrorKind.INVALID_PLURAL_ARGUMENT_SELECTOR,
              );
              if (result.err) {
                return result;
              }
              selectorLocation = createLocation(startPosition, this.clonePosition());
              selector = this.message.slice(startPosition.offset, this.offset());
            } else {
              break;
            }
          }
          if (parsedSelectors.has(selector)) {
            return this.error(
              parentArgType === 'select'
                ? ErrorKind.DUPLICATE_SELECT_ARGUMENT_SELECTOR
                : ErrorKind.DUPLICATE_PLURAL_ARGUMENT_SELECTOR,
              selectorLocation,
            );
          }
          if (selector === 'other') {
            hasOtherClause = true;
          }
          this.bumpSpace();
          var openingBracePosition = this.clonePosition();
          if (!this.bumpIf('{')) {
            return this.error(
              parentArgType === 'select'
                ? ErrorKind.EXPECT_SELECT_ARGUMENT_SELECTOR_FRAGMENT
                : ErrorKind.EXPECT_PLURAL_ARGUMENT_SELECTOR_FRAGMENT,
              createLocation(this.clonePosition(), this.clonePosition()),
            );
          }
          var fragmentResult = this.parseMessage(nestingLevel + 1, parentArgType, expectCloseTag);
          if (fragmentResult.err) {
            return fragmentResult;
          }
          var argCloseResult = this.tryParseArgumentClose(openingBracePosition);
          if (argCloseResult.err) {
            return argCloseResult;
          }
          options2.push([
            selector,
            {
              value: fragmentResult.val,
              location: createLocation(openingBracePosition, this.clonePosition()),
            },
          ]);
          parsedSelectors.add(selector);
          this.bumpSpace();
          (_a2 = this.parseIdentifierIfPossible()), (selector = _a2.value), (selectorLocation = _a2.location);
        }
        if (options2.length === 0) {
          return this.error(
            parentArgType === 'select'
              ? ErrorKind.EXPECT_SELECT_ARGUMENT_SELECTOR
              : ErrorKind.EXPECT_PLURAL_ARGUMENT_SELECTOR,
            createLocation(this.clonePosition(), this.clonePosition()),
          );
        }
        if (this.requiresOtherClause && !hasOtherClause) {
          return this.error(ErrorKind.MISSING_OTHER_CLAUSE, createLocation(this.clonePosition(), this.clonePosition()));
        }
        return { val: options2, err: null };
      };
      Parser2.prototype.tryParseDecimalInteger = function (expectNumberError, invalidNumberError) {
        var sign = 1;
        var startingPosition = this.clonePosition();
        if (this.bumpIf('+'));
        else if (this.bumpIf('-')) {
          sign = -1;
        }
        var hasDigits = false;
        var decimal = 0;
        while (!this.isEOF()) {
          var ch = this.char();
          if (ch >= 48 && ch <= 57) {
            hasDigits = true;
            decimal = decimal * 10 + (ch - 48);
            this.bump();
          } else {
            break;
          }
        }
        var location2 = createLocation(startingPosition, this.clonePosition());
        if (!hasDigits) {
          return this.error(expectNumberError, location2);
        }
        decimal *= sign;
        if (!isSafeInteger(decimal)) {
          return this.error(invalidNumberError, location2);
        }
        return { val: decimal, err: null };
      };
      Parser2.prototype.offset = function () {
        return this.position.offset;
      };
      Parser2.prototype.isEOF = function () {
        return this.offset() === this.message.length;
      };
      Parser2.prototype.clonePosition = function () {
        return {
          offset: this.position.offset,
          line: this.position.line,
          column: this.position.column,
        };
      };
      Parser2.prototype.char = function () {
        var offset = this.position.offset;
        if (offset >= this.message.length) {
          throw Error('out of bound');
        }
        var code = codePointAt(this.message, offset);
        if (code === void 0) {
          throw Error('Offset '.concat(offset, ' is at invalid UTF-16 code unit boundary'));
        }
        return code;
      };
      Parser2.prototype.error = function (kind, location2) {
        return {
          val: null,
          err: {
            kind,
            message: this.message,
            location: location2,
          },
        };
      };
      Parser2.prototype.bump = function () {
        if (this.isEOF()) {
          return;
        }
        var code = this.char();
        if (code === 10) {
          this.position.line += 1;
          this.position.column = 1;
          this.position.offset += 1;
        } else {
          this.position.column += 1;
          this.position.offset += code < 65536 ? 1 : 2;
        }
      };
      Parser2.prototype.bumpIf = function (prefix) {
        if (startsWith(this.message, prefix, this.offset())) {
          for (var i = 0; i < prefix.length; i++) {
            this.bump();
          }
          return true;
        }
        return false;
      };
      Parser2.prototype.bumpUntil = function (pattern) {
        var currentOffset = this.offset();
        var index = this.message.indexOf(pattern, currentOffset);
        if (index >= 0) {
          this.bumpTo(index);
          return true;
        } else {
          this.bumpTo(this.message.length);
          return false;
        }
      };
      Parser2.prototype.bumpTo = function (targetOffset) {
        if (this.offset() > targetOffset) {
          throw Error(
            'targetOffset '
              .concat(targetOffset, ' must be greater than or equal to the current offset ')
              .concat(this.offset()),
          );
        }
        targetOffset = Math.min(targetOffset, this.message.length);
        while (true) {
          var offset = this.offset();
          if (offset === targetOffset) {
            break;
          }
          if (offset > targetOffset) {
            throw Error('targetOffset '.concat(targetOffset, ' is at invalid UTF-16 code unit boundary'));
          }
          this.bump();
          if (this.isEOF()) {
            break;
          }
        }
      };
      Parser2.prototype.bumpSpace = function () {
        while (!this.isEOF() && _isWhiteSpace(this.char())) {
          this.bump();
        }
      };
      Parser2.prototype.peek = function () {
        if (this.isEOF()) {
          return null;
        }
        var code = this.char();
        var offset = this.offset();
        var nextCode = this.message.charCodeAt(offset + (code >= 65536 ? 2 : 1));
        return nextCode !== null && nextCode !== void 0 ? nextCode : null;
      };
      return Parser2;
    })();
  function _isAlpha(codepoint) {
    return (codepoint >= 97 && codepoint <= 122) || (codepoint >= 65 && codepoint <= 90);
  }
  function _isAlphaOrSlash(codepoint) {
    return _isAlpha(codepoint) || codepoint === 47;
  }
  function _isPotentialElementNameChar(c) {
    return (
      c === 45 ||
      c === 46 ||
      (c >= 48 && c <= 57) ||
      c === 95 ||
      (c >= 97 && c <= 122) ||
      (c >= 65 && c <= 90) ||
      c == 183 ||
      (c >= 192 && c <= 214) ||
      (c >= 216 && c <= 246) ||
      (c >= 248 && c <= 893) ||
      (c >= 895 && c <= 8191) ||
      (c >= 8204 && c <= 8205) ||
      (c >= 8255 && c <= 8256) ||
      (c >= 8304 && c <= 8591) ||
      (c >= 11264 && c <= 12271) ||
      (c >= 12289 && c <= 55295) ||
      (c >= 63744 && c <= 64975) ||
      (c >= 65008 && c <= 65533) ||
      (c >= 65536 && c <= 983039)
    );
  }
  function _isWhiteSpace(c) {
    return (c >= 9 && c <= 13) || c === 32 || c === 133 || (c >= 8206 && c <= 8207) || c === 8232 || c === 8233;
  }
  function _isPatternSyntax(c) {
    return (
      (c >= 33 && c <= 35) ||
      c === 36 ||
      (c >= 37 && c <= 39) ||
      c === 40 ||
      c === 41 ||
      c === 42 ||
      c === 43 ||
      c === 44 ||
      c === 45 ||
      (c >= 46 && c <= 47) ||
      (c >= 58 && c <= 59) ||
      (c >= 60 && c <= 62) ||
      (c >= 63 && c <= 64) ||
      c === 91 ||
      c === 92 ||
      c === 93 ||
      c === 94 ||
      c === 96 ||
      c === 123 ||
      c === 124 ||
      c === 125 ||
      c === 126 ||
      c === 161 ||
      (c >= 162 && c <= 165) ||
      c === 166 ||
      c === 167 ||
      c === 169 ||
      c === 171 ||
      c === 172 ||
      c === 174 ||
      c === 176 ||
      c === 177 ||
      c === 182 ||
      c === 187 ||
      c === 191 ||
      c === 215 ||
      c === 247 ||
      (c >= 8208 && c <= 8213) ||
      (c >= 8214 && c <= 8215) ||
      c === 8216 ||
      c === 8217 ||
      c === 8218 ||
      (c >= 8219 && c <= 8220) ||
      c === 8221 ||
      c === 8222 ||
      c === 8223 ||
      (c >= 8224 && c <= 8231) ||
      (c >= 8240 && c <= 8248) ||
      c === 8249 ||
      c === 8250 ||
      (c >= 8251 && c <= 8254) ||
      (c >= 8257 && c <= 8259) ||
      c === 8260 ||
      c === 8261 ||
      c === 8262 ||
      (c >= 8263 && c <= 8273) ||
      c === 8274 ||
      c === 8275 ||
      (c >= 8277 && c <= 8286) ||
      (c >= 8592 && c <= 8596) ||
      (c >= 8597 && c <= 8601) ||
      (c >= 8602 && c <= 8603) ||
      (c >= 8604 && c <= 8607) ||
      c === 8608 ||
      (c >= 8609 && c <= 8610) ||
      c === 8611 ||
      (c >= 8612 && c <= 8613) ||
      c === 8614 ||
      (c >= 8615 && c <= 8621) ||
      c === 8622 ||
      (c >= 8623 && c <= 8653) ||
      (c >= 8654 && c <= 8655) ||
      (c >= 8656 && c <= 8657) ||
      c === 8658 ||
      c === 8659 ||
      c === 8660 ||
      (c >= 8661 && c <= 8691) ||
      (c >= 8692 && c <= 8959) ||
      (c >= 8960 && c <= 8967) ||
      c === 8968 ||
      c === 8969 ||
      c === 8970 ||
      c === 8971 ||
      (c >= 8972 && c <= 8991) ||
      (c >= 8992 && c <= 8993) ||
      (c >= 8994 && c <= 9e3) ||
      c === 9001 ||
      c === 9002 ||
      (c >= 9003 && c <= 9083) ||
      c === 9084 ||
      (c >= 9085 && c <= 9114) ||
      (c >= 9115 && c <= 9139) ||
      (c >= 9140 && c <= 9179) ||
      (c >= 9180 && c <= 9185) ||
      (c >= 9186 && c <= 9254) ||
      (c >= 9255 && c <= 9279) ||
      (c >= 9280 && c <= 9290) ||
      (c >= 9291 && c <= 9311) ||
      (c >= 9472 && c <= 9654) ||
      c === 9655 ||
      (c >= 9656 && c <= 9664) ||
      c === 9665 ||
      (c >= 9666 && c <= 9719) ||
      (c >= 9720 && c <= 9727) ||
      (c >= 9728 && c <= 9838) ||
      c === 9839 ||
      (c >= 9840 && c <= 10087) ||
      c === 10088 ||
      c === 10089 ||
      c === 10090 ||
      c === 10091 ||
      c === 10092 ||
      c === 10093 ||
      c === 10094 ||
      c === 10095 ||
      c === 10096 ||
      c === 10097 ||
      c === 10098 ||
      c === 10099 ||
      c === 10100 ||
      c === 10101 ||
      (c >= 10132 && c <= 10175) ||
      (c >= 10176 && c <= 10180) ||
      c === 10181 ||
      c === 10182 ||
      (c >= 10183 && c <= 10213) ||
      c === 10214 ||
      c === 10215 ||
      c === 10216 ||
      c === 10217 ||
      c === 10218 ||
      c === 10219 ||
      c === 10220 ||
      c === 10221 ||
      c === 10222 ||
      c === 10223 ||
      (c >= 10224 && c <= 10239) ||
      (c >= 10240 && c <= 10495) ||
      (c >= 10496 && c <= 10626) ||
      c === 10627 ||
      c === 10628 ||
      c === 10629 ||
      c === 10630 ||
      c === 10631 ||
      c === 10632 ||
      c === 10633 ||
      c === 10634 ||
      c === 10635 ||
      c === 10636 ||
      c === 10637 ||
      c === 10638 ||
      c === 10639 ||
      c === 10640 ||
      c === 10641 ||
      c === 10642 ||
      c === 10643 ||
      c === 10644 ||
      c === 10645 ||
      c === 10646 ||
      c === 10647 ||
      c === 10648 ||
      (c >= 10649 && c <= 10711) ||
      c === 10712 ||
      c === 10713 ||
      c === 10714 ||
      c === 10715 ||
      (c >= 10716 && c <= 10747) ||
      c === 10748 ||
      c === 10749 ||
      (c >= 10750 && c <= 11007) ||
      (c >= 11008 && c <= 11055) ||
      (c >= 11056 && c <= 11076) ||
      (c >= 11077 && c <= 11078) ||
      (c >= 11079 && c <= 11084) ||
      (c >= 11085 && c <= 11123) ||
      (c >= 11124 && c <= 11125) ||
      (c >= 11126 && c <= 11157) ||
      c === 11158 ||
      (c >= 11159 && c <= 11263) ||
      (c >= 11776 && c <= 11777) ||
      c === 11778 ||
      c === 11779 ||
      c === 11780 ||
      c === 11781 ||
      (c >= 11782 && c <= 11784) ||
      c === 11785 ||
      c === 11786 ||
      c === 11787 ||
      c === 11788 ||
      c === 11789 ||
      (c >= 11790 && c <= 11798) ||
      c === 11799 ||
      (c >= 11800 && c <= 11801) ||
      c === 11802 ||
      c === 11803 ||
      c === 11804 ||
      c === 11805 ||
      (c >= 11806 && c <= 11807) ||
      c === 11808 ||
      c === 11809 ||
      c === 11810 ||
      c === 11811 ||
      c === 11812 ||
      c === 11813 ||
      c === 11814 ||
      c === 11815 ||
      c === 11816 ||
      c === 11817 ||
      (c >= 11818 && c <= 11822) ||
      c === 11823 ||
      (c >= 11824 && c <= 11833) ||
      (c >= 11834 && c <= 11835) ||
      (c >= 11836 && c <= 11839) ||
      c === 11840 ||
      c === 11841 ||
      c === 11842 ||
      (c >= 11843 && c <= 11855) ||
      (c >= 11856 && c <= 11857) ||
      c === 11858 ||
      (c >= 11859 && c <= 11903) ||
      (c >= 12289 && c <= 12291) ||
      c === 12296 ||
      c === 12297 ||
      c === 12298 ||
      c === 12299 ||
      c === 12300 ||
      c === 12301 ||
      c === 12302 ||
      c === 12303 ||
      c === 12304 ||
      c === 12305 ||
      (c >= 12306 && c <= 12307) ||
      c === 12308 ||
      c === 12309 ||
      c === 12310 ||
      c === 12311 ||
      c === 12312 ||
      c === 12313 ||
      c === 12314 ||
      c === 12315 ||
      c === 12316 ||
      c === 12317 ||
      (c >= 12318 && c <= 12319) ||
      c === 12320 ||
      c === 12336 ||
      c === 64830 ||
      c === 64831 ||
      (c >= 65093 && c <= 65094)
    );
  }
  function pruneLocation(els) {
    els.forEach(function (el) {
      delete el.location;
      if (isSelectElement(el) || isPluralElement(el)) {
        for (var k in el.options) {
          delete el.options[k].location;
          pruneLocation(el.options[k].value);
        }
      } else if (isNumberElement(el) && isNumberSkeleton(el.style)) {
        delete el.style.location;
      } else if ((isDateElement(el) || isTimeElement(el)) && isDateTimeSkeleton(el.style)) {
        delete el.style.location;
      } else if (isTagElement(el)) {
        pruneLocation(el.children);
      }
    });
  }
  function parse(message, opts) {
    if (opts === void 0) {
      opts = {};
    }
    opts = __assign({ shouldParseSkeletons: true, requiresOtherClause: true }, opts);
    var result = new Parser(message, opts).parse();
    if (result.err) {
      var error = SyntaxError(ErrorKind[result.err.kind]);
      error.location = result.err.location;
      error.originalMessage = result.err.message;
      throw error;
    }
    if (!(opts === null || opts === void 0 ? void 0 : opts.captureLocation)) {
      pruneLocation(result.val);
    }
    return result.val;
  }
  var ErrorCode;
  (function (ErrorCode2) {
    ErrorCode2['MISSING_VALUE'] = 'MISSING_VALUE';
    ErrorCode2['INVALID_VALUE'] = 'INVALID_VALUE';
    ErrorCode2['MISSING_INTL_API'] = 'MISSING_INTL_API';
  })(ErrorCode || (ErrorCode = {}));
  var FormatError =
    /** @class */
    (function (_super) {
      __extends(FormatError2, _super);
      function FormatError2(msg, code, originalMessage) {
        var _this = _super.call(this, msg) || this;
        _this.code = code;
        _this.originalMessage = originalMessage;
        return _this;
      }
      FormatError2.prototype.toString = function () {
        return '[formatjs Error: '.concat(this.code, '] ').concat(this.message);
      };
      return FormatError2;
    })(Error);
  var InvalidValueError =
    /** @class */
    (function (_super) {
      __extends(InvalidValueError2, _super);
      function InvalidValueError2(variableId, value, options2, originalMessage) {
        return (
          _super.call(
            this,
            'Invalid values for "'
              .concat(variableId, '": "')
              .concat(value, '". Options are "')
              .concat(Object.keys(options2).join('", "'), '"'),
            ErrorCode.INVALID_VALUE,
            originalMessage,
          ) || this
        );
      }
      return InvalidValueError2;
    })(FormatError);
  var InvalidValueTypeError =
    /** @class */
    (function (_super) {
      __extends(InvalidValueTypeError2, _super);
      function InvalidValueTypeError2(value, type, originalMessage) {
        return (
          _super.call(
            this,
            'Value for "'.concat(value, '" must be of type ').concat(type),
            ErrorCode.INVALID_VALUE,
            originalMessage,
          ) || this
        );
      }
      return InvalidValueTypeError2;
    })(FormatError);
  var MissingValueError =
    /** @class */
    (function (_super) {
      __extends(MissingValueError2, _super);
      function MissingValueError2(variableId, originalMessage) {
        return (
          _super.call(
            this,
            'The intl string context variable "'
              .concat(variableId, '" was not provided to the string "')
              .concat(originalMessage, '"'),
            ErrorCode.MISSING_VALUE,
            originalMessage,
          ) || this
        );
      }
      return MissingValueError2;
    })(FormatError);
  var PART_TYPE;
  (function (PART_TYPE2) {
    PART_TYPE2[(PART_TYPE2['literal'] = 0)] = 'literal';
    PART_TYPE2[(PART_TYPE2['object'] = 1)] = 'object';
  })(PART_TYPE || (PART_TYPE = {}));
  function mergeLiteral(parts) {
    if (parts.length < 2) {
      return parts;
    }
    return parts.reduce(function (all, part) {
      var lastPart = all[all.length - 1];
      if (!lastPart || lastPart.type !== PART_TYPE.literal || part.type !== PART_TYPE.literal) {
        all.push(part);
      } else {
        lastPart.value += part.value;
      }
      return all;
    }, []);
  }
  function isFormatXMLElementFn(el) {
    return typeof el === 'function';
  }
  function formatToParts(els, locales, formatters, formats, values, currentPluralValue, originalMessage) {
    if (els.length === 1 && isLiteralElement(els[0])) {
      return [
        {
          type: PART_TYPE.literal,
          value: els[0].value,
        },
      ];
    }
    var result = [];
    for (var _i = 0, els_1 = els; _i < els_1.length; _i++) {
      var el = els_1[_i];
      if (isLiteralElement(el)) {
        result.push({
          type: PART_TYPE.literal,
          value: el.value,
        });
        continue;
      }
      if (isPoundElement(el)) {
        if (typeof currentPluralValue === 'number') {
          result.push({
            type: PART_TYPE.literal,
            value: formatters.getNumberFormat(locales).format(currentPluralValue),
          });
        }
        continue;
      }
      var varName = el.value;
      if (!(values && varName in values)) {
        throw new MissingValueError(varName, originalMessage);
      }
      var value = values[varName];
      if (isArgumentElement(el)) {
        if (!value || typeof value === 'string' || typeof value === 'number') {
          value = typeof value === 'string' || typeof value === 'number' ? String(value) : '';
        }
        result.push({
          type: typeof value === 'string' ? PART_TYPE.literal : PART_TYPE.object,
          value,
        });
        continue;
      }
      if (isDateElement(el)) {
        var style =
          typeof el.style === 'string'
            ? formats.date[el.style]
            : isDateTimeSkeleton(el.style)
            ? el.style.parsedOptions
            : void 0;
        result.push({
          type: PART_TYPE.literal,
          value: formatters.getDateTimeFormat(locales, style).format(value),
        });
        continue;
      }
      if (isTimeElement(el)) {
        var style =
          typeof el.style === 'string'
            ? formats.time[el.style]
            : isDateTimeSkeleton(el.style)
            ? el.style.parsedOptions
            : formats.time.medium;
        result.push({
          type: PART_TYPE.literal,
          value: formatters.getDateTimeFormat(locales, style).format(value),
        });
        continue;
      }
      if (isNumberElement(el)) {
        var style =
          typeof el.style === 'string'
            ? formats.number[el.style]
            : isNumberSkeleton(el.style)
            ? el.style.parsedOptions
            : void 0;
        if (style && style.scale) {
          value = value * (style.scale || 1);
        }
        result.push({
          type: PART_TYPE.literal,
          value: formatters.getNumberFormat(locales, style).format(value),
        });
        continue;
      }
      if (isTagElement(el)) {
        var children = el.children,
          value_1 = el.value;
        var formatFn = values[value_1];
        if (!isFormatXMLElementFn(formatFn)) {
          throw new InvalidValueTypeError(value_1, 'function', originalMessage);
        }
        var parts = formatToParts(children, locales, formatters, formats, values, currentPluralValue);
        var chunks = formatFn(
          parts.map(function (p) {
            return p.value;
          }),
        );
        if (!Array.isArray(chunks)) {
          chunks = [chunks];
        }
        result.push.apply(
          result,
          chunks.map(function (c) {
            return {
              type: typeof c === 'string' ? PART_TYPE.literal : PART_TYPE.object,
              value: c,
            };
          }),
        );
      }
      if (isSelectElement(el)) {
        var opt = el.options[value] || el.options.other;
        if (!opt) {
          throw new InvalidValueError(el.value, value, Object.keys(el.options), originalMessage);
        }
        result.push.apply(result, formatToParts(opt.value, locales, formatters, formats, values));
        continue;
      }
      if (isPluralElement(el)) {
        var opt = el.options['='.concat(value)];
        if (!opt) {
          if (!Intl.PluralRules) {
            throw new FormatError(
              'Intl.PluralRules is not available in this environment.\nTry polyfilling it using "@formatjs/intl-pluralrules"\n',
              ErrorCode.MISSING_INTL_API,
              originalMessage,
            );
          }
          var rule = formatters.getPluralRules(locales, { type: el.pluralType }).select(value - (el.offset || 0));
          opt = el.options[rule] || el.options.other;
        }
        if (!opt) {
          throw new InvalidValueError(el.value, value, Object.keys(el.options), originalMessage);
        }
        result.push.apply(
          result,
          formatToParts(opt.value, locales, formatters, formats, values, value - (el.offset || 0)),
        );
        continue;
      }
    }
    return mergeLiteral(result);
  }
  function mergeConfig(c1, c2) {
    if (!c2) {
      return c1;
    }
    return __assign(
      __assign(__assign({}, c1 || {}), c2 || {}),
      Object.keys(c1).reduce(function (all, k) {
        all[k] = __assign(__assign({}, c1[k]), c2[k] || {});
        return all;
      }, {}),
    );
  }
  function mergeConfigs(defaultConfig, configs) {
    if (!configs) {
      return defaultConfig;
    }
    return Object.keys(defaultConfig).reduce(function (all, k) {
      all[k] = mergeConfig(defaultConfig[k], configs[k]);
      return all;
    }, __assign({}, defaultConfig));
  }
  function createFastMemoizeCache(store) {
    return {
      create: function () {
        return {
          get: function (key) {
            return store[key];
          },
          set: function (key, value) {
            store[key] = value;
          },
        };
      },
    };
  }
  function createDefaultFormatters(cache) {
    if (cache === void 0) {
      cache = {
        number: {},
        dateTime: {},
        pluralRules: {},
      };
    }
    return {
      getNumberFormat: memoize(
        function () {
          var _a2;
          var args = [];
          for (var _i = 0; _i < arguments.length; _i++) {
            args[_i] = arguments[_i];
          }
          return new ((_a2 = Intl.NumberFormat).bind.apply(_a2, __spreadArray([void 0], args, false)))();
        },
        {
          cache: createFastMemoizeCache(cache.number),
          strategy: strategies.variadic,
        },
      ),
      getDateTimeFormat: memoize(
        function () {
          var _a2;
          var args = [];
          for (var _i = 0; _i < arguments.length; _i++) {
            args[_i] = arguments[_i];
          }
          return new ((_a2 = Intl.DateTimeFormat).bind.apply(_a2, __spreadArray([void 0], args, false)))();
        },
        {
          cache: createFastMemoizeCache(cache.dateTime),
          strategy: strategies.variadic,
        },
      ),
      getPluralRules: memoize(
        function () {
          var _a2;
          var args = [];
          for (var _i = 0; _i < arguments.length; _i++) {
            args[_i] = arguments[_i];
          }
          return new ((_a2 = Intl.PluralRules).bind.apply(_a2, __spreadArray([void 0], args, false)))();
        },
        {
          cache: createFastMemoizeCache(cache.pluralRules),
          strategy: strategies.variadic,
        },
      ),
    };
  }
  var IntlMessageFormat =
    /** @class */
    (function () {
      function IntlMessageFormat2(message, locales, overrideFormats, opts) {
        if (locales === void 0) {
          locales = IntlMessageFormat2.defaultLocale;
        }
        var _this = this;
        this.formatterCache = {
          number: {},
          dateTime: {},
          pluralRules: {},
        };
        this.format = function (values) {
          var parts = _this.formatToParts(values);
          if (parts.length === 1) {
            return parts[0].value;
          }
          var result = parts.reduce(function (all, part) {
            if (!all.length || part.type !== PART_TYPE.literal || typeof all[all.length - 1] !== 'string') {
              all.push(part.value);
            } else {
              all[all.length - 1] += part.value;
            }
            return all;
          }, []);
          if (result.length <= 1) {
            return result[0] || '';
          }
          return result;
        };
        this.formatToParts = function (values) {
          return formatToParts(
            _this.ast,
            _this.locales,
            _this.formatters,
            _this.formats,
            values,
            void 0,
            _this.message,
          );
        };
        this.resolvedOptions = function () {
          var _a3;
          return {
            locale:
              ((_a3 = _this.resolvedLocale) === null || _a3 === void 0 ? void 0 : _a3.toString()) ||
              Intl.NumberFormat.supportedLocalesOf(_this.locales)[0],
          };
        };
        this.getAst = function () {
          return _this.ast;
        };
        this.locales = locales;
        this.resolvedLocale = IntlMessageFormat2.resolveLocale(locales);
        if (typeof message === 'string') {
          this.message = message;
          if (!IntlMessageFormat2.__parse) {
            throw new TypeError('IntlMessageFormat.__parse must be set to process `message` of type `string`');
          }
          var _a2 = opts || {};
          _a2.formatters;
          var parseOpts = __rest(_a2, ['formatters']);
          this.ast = IntlMessageFormat2.__parse(
            message,
            __assign(__assign({}, parseOpts), { locale: this.resolvedLocale }),
          );
        } else {
          this.ast = message;
        }
        if (!Array.isArray(this.ast)) {
          throw new TypeError('A message must be provided as a String or AST.');
        }
        this.formats = mergeConfigs(IntlMessageFormat2.formats, overrideFormats);
        this.formatters = (opts && opts.formatters) || createDefaultFormatters(this.formatterCache);
      }
      Object.defineProperty(IntlMessageFormat2, 'defaultLocale', {
        get: function () {
          if (!IntlMessageFormat2.memoizedDefaultLocale) {
            IntlMessageFormat2.memoizedDefaultLocale = new Intl.NumberFormat().resolvedOptions().locale;
          }
          return IntlMessageFormat2.memoizedDefaultLocale;
        },
        enumerable: false,
        configurable: true,
      });
      IntlMessageFormat2.memoizedDefaultLocale = null;
      IntlMessageFormat2.resolveLocale = function (locales) {
        if (typeof Intl.Locale === 'undefined') {
          return;
        }
        var supportedLocales = Intl.NumberFormat.supportedLocalesOf(locales);
        if (supportedLocales.length > 0) {
          return new Intl.Locale(supportedLocales[0]);
        }
        return new Intl.Locale(typeof locales === 'string' ? locales : locales[0]);
      };
      IntlMessageFormat2.__parse = parse;
      IntlMessageFormat2.formats = {
        number: {
          integer: {
            maximumFractionDigits: 0,
          },
          currency: {
            style: 'currency',
          },
          percent: {
            style: 'percent',
          },
        },
        date: {
          short: {
            month: 'numeric',
            day: 'numeric',
            year: '2-digit',
          },
          medium: {
            month: 'short',
            day: 'numeric',
            year: 'numeric',
          },
          long: {
            month: 'long',
            day: 'numeric',
            year: 'numeric',
          },
          full: {
            weekday: 'long',
            month: 'long',
            day: 'numeric',
            year: 'numeric',
          },
        },
        time: {
          short: {
            hour: 'numeric',
            minute: 'numeric',
          },
          medium: {
            hour: 'numeric',
            minute: 'numeric',
            second: 'numeric',
          },
          long: {
            hour: 'numeric',
            minute: 'numeric',
            second: 'numeric',
            timeZoneName: 'short',
          },
          full: {
            hour: 'numeric',
            minute: 'numeric',
            second: 'numeric',
            timeZoneName: 'short',
          },
        },
      };
      return IntlMessageFormat2;
    })();
  function ownKeys(object, enumerableOnly) {
    var keys = Object.keys(object);
    if (Object.getOwnPropertySymbols) {
      var symbols = Object.getOwnPropertySymbols(object);
      if (enumerableOnly)
        symbols = symbols.filter(function (sym) {
          return Object.getOwnPropertyDescriptor(object, sym).enumerable;
        });
      keys.push.apply(keys, symbols);
    }
    return keys;
  }
  function _objectSpread(target) {
    for (var i = 1; i < arguments.length; i++) {
      var source = arguments[i] != null ? arguments[i] : {};
      if (i % 2) {
        ownKeys(Object(source), true).forEach(function (key) {
          _defineProperty(target, key, source[key]);
        });
      } else if (Object.getOwnPropertyDescriptors) {
        Object.defineProperties(target, Object.getOwnPropertyDescriptors(source));
      } else {
        ownKeys(Object(source)).forEach(function (key) {
          Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key));
        });
      }
    }
    return target;
  }
  function _defineProperty(obj, key, value) {
    if (key in obj) {
      Object.defineProperty(obj, key, { value, enumerable: true, configurable: true, writable: true });
    } else {
      obj[key] = value;
    }
    return obj;
  }
  function _classCallCheck(instance2, Constructor) {
    if (!(instance2 instanceof Constructor)) {
      throw new TypeError('Cannot call a class as a function');
    }
  }
  function _defineProperties(target, props) {
    for (var i = 0; i < props.length; i++) {
      var descriptor = props[i];
      descriptor.enumerable = descriptor.enumerable || false;
      descriptor.configurable = true;
      if ('value' in descriptor) descriptor.writable = true;
      Object.defineProperty(target, descriptor.key, descriptor);
    }
  }
  function _createClass(Constructor, protoProps, staticProps) {
    if (protoProps) _defineProperties(Constructor.prototype, protoProps);
    return Constructor;
  }
  function getDefaults() {
    return {
      memoize: true,
      memoizeFallback: false,
      bindI18n: '',
      bindI18nStore: '',
      parseErrorHandler: function parseErrorHandler(err, key, res, options2) {
        return res;
      },
      parseLngForICU: function parseLngForICU(lng) {
        return lng;
      },
    };
  }
  var ICU = /* @__PURE__ */ (function () {
    function ICU2(options2) {
      _classCallCheck(this, ICU2);
      this.type = 'i18nFormat';
      this.mem = {};
      this.init(null, options2);
    }
    _createClass(ICU2, [
      {
        key: 'init',
        value: function init(i18next, options2) {
          var _this = this;
          var i18nextOptions = (i18next && i18next.options && i18next.options.i18nFormat) || {};
          this.options = defaults(i18nextOptions, options2, this.options || {}, getDefaults());
          this.formats = this.options.formats;
          if (i18next) {
            var _this$options = this.options,
              bindI18n = _this$options.bindI18n,
              bindI18nStore = _this$options.bindI18nStore,
              memoize2 = _this$options.memoize;
            i18next.IntlMessageFormat = IntlMessageFormat;
            i18next.ICU = this;
            if (memoize2) {
              if (bindI18n) {
                i18next.on(bindI18n, function () {
                  return _this.clearCache();
                });
              }
              if (bindI18nStore) {
                i18next.store.on(bindI18nStore, function () {
                  return _this.clearCache();
                });
              }
            }
          }
        },
      },
      {
        key: 'addUserDefinedFormats',
        value: function addUserDefinedFormats(formats) {
          this.formats = this.formats ? _objectSpread(_objectSpread({}, this.formats), formats) : formats;
        },
      },
      {
        key: 'parse',
        value: function parse2(res, options2, lng, ns, key, info) {
          var hadSuccessfulLookup = info && info.resolved && info.resolved.res;
          var memKey = this.options.memoize && ''.concat(lng, '.').concat(ns, '.').concat(key.replace(/\./g, '###'));
          var fc;
          if (this.options.memoize) {
            fc = getPath(this.mem, memKey);
          }
          try {
            if (!fc) {
              var transformedLng = this.options.parseLngForICU(lng);
              fc = new IntlMessageFormat(res, transformedLng, this.formats, {
                ignoreTag: true,
              });
              if (this.options.memoize && (this.options.memoizeFallback || !info || hadSuccessfulLookup))
                setPath(this.mem, memKey, fc);
            }
            return fc.format(options2);
          } catch (err) {
            return this.options.parseErrorHandler(err, key, res, options2);
          }
        },
      },
      {
        key: 'addLookupKeys',
        value: function addLookupKeys(finalKeys, _key, _code, _ns, _options) {
          return finalKeys;
        },
      },
      {
        key: 'clearCache',
        value: function clearCache() {
          this.mem = {};
        },
      },
    ]);
    return ICU2;
  })();
  ICU.type = 'i18nFormat';
  const DEFAULT_LOCALE = 'en-US';
  const LOCALE_CONFIG = [
    { locale: 'en-US', code: 'en', direction: 'ltr' },
    { locale: 'fr-FR', code: 'fr', direction: 'ltr' },
  ];
  const DATE_FORMAT_OPTIONS = {
    short: {
      weekday: 'short',
      month: 'short',
      day: '2-digit',
    },
  };
  const formatDate = (date, options2 = DATE_FORMAT_OPTIONS.short) => {
    const locale = instance.language;
    if (typeof date === 'string') {
      date = new Date(date);
    }
    try {
      return new Intl.DateTimeFormat(locale, options2).format(date);
    } catch (error) {
      logger.error(`Error formatting date for locale ${locale}:`, error);
      return date.toDateString();
    }
  };
  const formatMessage = (key, defaultMessage, options2) => {
    if (!instance.isInitialized) {
      return defaultMessage;
    }
    return instance.t(key, defaultMessage, options2);
  };
  const formatPrice = (price, currency) => {
    const locale = instance.language;
    try {
      const formatter = new Intl.NumberFormat(locale, {
        style: 'currency',
        currency,
        maximumFractionDigits: 0,
      });
      return formatter.format(price);
    } catch (error) {
      logger.error(`Error formatting price for locale ${locale}:`, error);
      return `${price.toFixed(0).toLocaleString()} ${currency}`;
    }
  };
  const translationModules = /* @__PURE__ */ Object.assign({
    './translations/en-US.json': __vite_glob_0_0,
    './translations/fr-FR.json': __vite_glob_0_1,
  });
  const availableTranslations = Object.entries(translationModules).reduce((acc, [path, module]) => {
    const languageCode = path.match(/\/([^/]+)\.json$/)?.[1];
    if (languageCode) {
      acc[languageCode] = module.default;
    }
    return acc;
  }, {});
  const getSupportedLocale = language => {
    const configFromLanguage = LOCALE_CONFIG.find(config2 => config2.code === language);
    if (configFromLanguage) {
      return configFromLanguage.locale;
    }
    const shortLanguage = language.split('-')[0];
    const configFromShortLanguage = LOCALE_CONFIG.find(config2 => config2.code === shortLanguage);
    if (configFromShortLanguage) {
      return configFromShortLanguage.locale;
    }
    logger.warn(`Language (${language}) not supported, using default (${DEFAULT_LOCALE})`);
    return DEFAULT_LOCALE;
  };
  const initializeI18n = async language => {
    const supportedLanguage = getSupportedLocale(language ?? DEFAULT_LOCALE);
    await instance.use(ICU).init({
      lng: supportedLanguage,
      debug: false,
      resources: {
        [DEFAULT_LOCALE]: {
          translation: availableTranslations[DEFAULT_LOCALE],
        },
        [supportedLanguage]: {
          translation: availableTranslations[supportedLanguage],
        },
      },
      interpolation: {
        escapeValue: false,
      },
      fallbackLng: DEFAULT_LOCALE,
    });
  };
  const daysBetween = (date1, date2) => {
    const d1 = new Date(date1).getTime();
    const d2 = new Date(date2).getTime();
    const diffTime = Math.abs(d2 - d1);
    return Math.ceil(diffTime / (1e3 * 60 * 60 * 24));
  };
  const arrowRightSvg =
    '<svg viewBox="0 0 17 16" fill="none" xmlns="http://www.w3.org/2000/svg" class="hermes-icon-arrowRight">\n  <path fill-rule="evenodd" clip-rule="evenodd"\n    d="M5.48844 4.22215C5.2497 4.00048 5.23588 3.62724 5.45756 3.38851C5.67924 3.14978 6.05247 3.13596 6.2912 3.35763L10.8252 7.56775C10.9454 7.67937 11.0137 7.83599 11.0137 8.00001C11.0137 8.16404 10.9454 8.32066 10.8252 8.43227L6.2912 12.6424C6.05247 12.8641 5.67924 12.8502 5.45756 12.6115C5.23588 12.3728 5.2497 11.9995 5.48844 11.7779L9.5569 8.00001L5.48844 4.22215Z" />\n</svg>';
  const getDealUrl = url => {
    return url;
  };
  const createCompareBestPricesSection = ({ priceDifference, bookingPrice, offers, currency }) => {
    const compareBestPricesContainer = document.createElement('div');
    compareBestPricesContainer.classList.add('hermes-popup-compareBestPricesContainer');
    const bookingPriceFormatted = formatPrice(bookingPrice, currency);
    const compareBestPricesHeading = document.createElement('h4');
    compareBestPricesHeading.classList.add('hermes-popup-compareBestPricesHeading');
    compareBestPricesHeading.textContent = formatMessage('compareBestPrices', 'Compare best prices');
    compareBestPricesContainer.appendChild(compareBestPricesHeading);
    const bestPrices = document.createElement('div');
    bestPrices.classList.add('hermes-popup-bestPrices');
    offers.forEach((offer, index) => {
      const priceWithCurrency = formatPrice(offer.displayPrice, currency);
      const bestPriceLink = document.createElement('a');
      bestPriceLink.href = getDealUrl(offer.url);
      bestPriceLink.target = '_blank';
      bestPriceLink.classList.add('hermes-popup-bestPrice');
      const providerLogo = document.createElement('img');
      providerLogo.src = offer.provider.logoUrl;
      providerLogo.alt = offer.provider.name;
      providerLogo.classList.add('hermes-popup-providerLogo');
      const content = document.createElement('div');
      content.classList.add('hermes-popup-content');
      const priceContainer = document.createElement('div');
      priceContainer.classList.add('hermes-popup-priceContainer');
      if (index === 0 && priceDifference > 0) {
        const bookingPriceSpan = document.createElement('span');
        bookingPriceSpan.classList.add('hermes-popup-bookingPrice');
        bookingPriceSpan.textContent = bookingPriceFormatted;
        priceContainer.appendChild(bookingPriceSpan);
        bestPriceLink.classList.add('hermes-popup-betterDeal');
      }
      const priceSpan = document.createElement('span');
      priceSpan.classList.add('hermes-popup-price');
      priceSpan.textContent = priceWithCurrency;
      priceContainer.appendChild(priceSpan);
      const arrowIcon = document.createElement('span');
      arrowIcon.classList.add('hermes-popup-arrowIcon');
      arrowIcon.innerHTML = arrowRightSvg;
      content.appendChild(priceContainer);
      content.appendChild(arrowIcon);
      bestPriceLink.appendChild(providerLogo);
      bestPriceLink.appendChild(content);
      bestPrices.appendChild(bestPriceLink);
    });
    compareBestPricesContainer.appendChild(bestPrices);
    return compareBestPricesContainer;
  };
  const closePopup = () => {
    const popup = document.getElementById('hermes-popup');
    if (!popup) {
      return;
    }
    popup.classList.remove('hermes-popup-visible');
  };
  const closePluginSvg =
    '<svg class="closePlugin" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">\n<path fill-rule="evenodd" clip-rule="evenodd" d="M15.7803 5.28033C16.0732 4.98744 16.0732 4.51256 15.7803 4.21967C15.4874 3.92678 15.0126 3.92678 14.7197 4.21967L10 8.93934L5.28033 4.21967C4.98744 3.92678 4.51256 3.92678 4.21967 4.21967C3.92678 4.51256 3.92678 4.98744 4.21967 5.28033L8.93934 10L4.21967 14.7197C3.92678 15.0126 3.92678 15.4874 4.21967 15.7803C4.51256 16.0732 4.98744 16.0732 5.28033 15.7803L10 11.0607L14.7197 15.7803C15.0126 16.0732 15.4874 16.0732 15.7803 15.7803C16.0732 15.4874 16.0732 15.0126 15.7803 14.7197L11.0607 10L15.7803 5.28033Z" fill="black"/>\n</svg>\n';
  const karmanowIconSvg =
    '<svg class="hermes-brand-logo hermes-karmanow-icon" width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">\n  <g clip-path="url(#clip0_36397_73747)">\n    <rect width="24" height="24" rx="2" fill="#1b1c1d"/>\n    <path fill-rule="evenodd" clip-rule="evenodd" d="M4.97173 4.97148C4.80347 5.13973 4.8003 5.25691 4.80082 11.3358C4.80107 15.22 4.83339 17.6442 4.88739 17.8387C5.17401 18.8706 6.2859 19.4322 7.3455 19.0801C7.77947 18.936 8.09781 18.6383 10.4101 16.2135L11.0914 15.4992L11.2597 15.7425C11.5784 16.2029 12.9011 17.4565 13.4146 17.7849C14.7441 18.6349 16.1637 19.0721 17.9208 19.1726C19.2285 19.2474 19.2003 19.2861 19.2003 17.4192C19.2003 15.6262 19.2108 15.647 18.2737 15.5688C16.9994 15.4626 15.8225 14.9551 15.0324 14.1714C14.6138 13.7561 14.0601 12.9339 14.0582 12.7248C14.0578 12.6756 15.139 11.5482 16.4609 10.2194C19.0047 7.66248 19.1949 7.41656 19.1984 6.67968C19.2009 6.16548 18.828 5.42311 18.4374 5.16425C17.837 4.76653 17.0495 4.71125 16.4346 5.02368C16.2822 5.10108 14.4603 6.85556 12.386 8.92239L8.61459 12.6804L8.57173 8.86179C8.53067 5.20728 8.52176 5.03808 8.3625 4.92168C8.23359 4.82748 7.85233 4.80005 6.66964 4.80005C5.25741 4.80005 5.1303 4.81291 4.97173 4.97148Z" fill="#E9ff77"/>\n  </g>\n</svg>\n';
  const karmanowLogoSvg =
    '<svg class="hermes-karmanow" color="#1b1c1d" width="90" viewBox="0 0 150 33" xmlns="http://www.w3.org/2000/svg" fill="none"\n  class="BaseIconstyles__BaseIconRoot-sc-1uucpm5-0 cTIvMR">\n  <path\n    d="M0 30.1795V1.90339C0 1.16572 0.491259 0.674462 1.22892 0.674462H6.7614C7.49907 0.674462 7.99033 1.16572 7.99033 1.90339V15.795L18.0712 1.41058C18.3781 0.919317 18.8709 0.672913 19.3621 0.672913H26.0631C26.8008 0.672913 27.354 1.59499 26.8008 2.33266L15.7358 17.7616C17.0267 21.5119 20.9614 24.0318 25.7563 24.0318H25.8182C26.5559 24.0318 27.0472 24.523 27.0472 25.2607V30.1779C27.0472 30.9156 26.5559 31.4069 25.8182 31.4069H25.0806C17.2731 31.4069 11.3734 27.6566 7.99188 21.264V30.1779C7.99188 30.9156 7.50062 31.4069 6.76295 31.4069H1.23047C0.492809 31.41 0 30.9172 0 30.1795Z"\n    fill="currentColor"></path>\n  <path\n    d="M48.5705 30.1791V28.7658C46.6644 30.8563 43.7757 32.0233 40.0254 32.0233C33.4484 32.0233 29.5137 27.9041 29.5137 22.1872C29.5137 16.8392 33.4484 12.9664 39.841 12.9664H47.3401C48.0777 12.9664 48.569 12.4752 48.569 11.7375C48.569 9.21768 46.4784 7.43396 43.6517 7.43396C41.1319 7.43396 39.4721 8.66288 38.6725 10.7534C38.4881 11.2447 38.0573 11.5531 37.3816 11.5531H31.9715C31.1114 11.5531 30.5582 10.9999 30.6806 10.1398C31.5407 4.60728 36.2131 0.0588684 43.6502 0.0588684C51.5801 0.0588684 56.5593 4.91567 56.5593 11.7375V30.1791C56.5593 30.9168 56.0681 31.408 55.3304 31.408H49.7979C49.0633 31.4096 48.5705 30.9168 48.5705 30.1791ZM41.9935 25.2619C46.3575 25.2619 48.5705 22.8025 48.5705 19.4225V18.8073H41.1319C38.9809 18.8073 37.5056 20.0982 37.5056 21.9424C37.5071 23.8485 38.9204 25.2619 41.9935 25.2619Z"\n    fill="currentColor"></path>\n  <path\n    d="M61.1758 30.1797V12.8461C61.1758 5.40745 65.8482 0.674622 73.4697 0.674622H73.7765C74.5142 0.674622 75.0054 1.16588 75.0054 1.90355V7.12919C75.0054 7.86685 74.5142 8.35811 73.7765 8.35811C71.0723 8.35811 69.1661 10.1403 69.1661 13.4598V30.1797C69.1661 30.9173 68.6749 31.4086 67.9372 31.4086H62.4047C61.667 31.4101 61.1758 30.9173 61.1758 30.1797Z"\n    fill="currentColor"></path>\n  <path\n    d="M77.1582 30.1791V12.2303C77.1582 4.7917 81.8306 0.0588684 89.4521 0.0588684C93.2628 0.0588684 96.2755 1.16536 98.366 3.25593C100.457 1.16536 103.468 0.0588684 107.28 0.0588684C114.903 0.0588684 119.574 4.7917 119.574 12.2303V30.1791C119.574 30.9168 119.083 31.408 118.345 31.408H112.812C112.075 31.408 111.584 30.9168 111.584 30.1791V12.8456C111.584 9.52608 109.677 7.7439 106.973 7.7439C104.269 7.7439 102.363 9.52608 102.363 12.8456V30.1807C102.363 30.9183 101.871 31.4096 101.134 31.4096H95.6013C94.8637 31.4096 94.3724 30.9183 94.3724 30.1807V12.8456C94.3724 9.52608 92.4663 7.7439 89.762 7.7439C87.0578 7.7439 85.1516 9.52608 85.1516 12.8456V30.1807C85.1516 30.9183 84.6604 31.4096 83.9227 31.4096H78.3902C77.6495 31.4096 77.1582 30.9168 77.1582 30.1791Z"\n    fill="currentColor"></path>\n  <path\n    d="M142.008 30.1791V28.7658C140.102 30.8563 137.213 32.0233 133.463 32.0233C126.886 32.0233 122.951 27.9041 122.951 22.1872C122.951 16.8392 126.886 12.9664 133.278 12.9664H140.778C141.515 12.9664 142.006 12.4752 142.006 11.7375C142.006 9.21768 139.916 7.43396 137.089 7.43396C134.569 7.43396 132.91 8.66288 132.11 10.7534C131.926 11.2447 131.495 11.5531 130.819 11.5531H125.412C124.552 11.5531 123.999 10.9999 124.121 10.1398C124.981 4.60728 129.654 0.0588684 137.091 0.0588684C145.021 0.0588684 150 4.91567 150 11.7375V30.1791C150 30.9168 149.509 31.408 148.771 31.408H143.238C142.501 31.4096 142.008 30.9168 142.008 30.1791ZM135.431 25.2619C139.795 25.2619 142.008 22.8025 142.008 19.4225V18.8073H134.569C132.418 18.8073 130.943 20.0982 130.943 21.9424C130.943 23.8485 132.358 25.2619 135.431 25.2619Z"\n    fill="currentColor"></path>\n</svg>';
  const commonVars = {
    // Logo
    logo: '#0F0E0F',
    logoShimmer: '#0F0E0F',
    logoInactiveContent: '#a29e99',
    // Injected Buttons
    buttonGap: '2px',
    buttonBackground: '#FFFFFFF2',
    buttonInactiveBackground: '#FFFFFFF2',
    buttonHoverBackground: '#F8F8F8F2',
    buttonBorder: '#B8B3AD',
    buttonHoverBorder: '#76726E',
    buttonText: '#0F0E0F',
    buttonPrice: '#0F0E0F',
    buttonLoadingText: '#A29E99',
    buttonLoadingTextShimmer: '#000000',
    buttonDotsBackground: '#D2D2D2F2',
    buttonDots: '#696663',
    buttonGlowGradient: 'linear-gradient(95deg, rgba(82, 91, 233, 0.9) 9%, rgba(255, 51, 102, 0.9) 77%)',
    // Popup
    popupTextAccent: '#0F0E0F',
    popupButtonBackground: '#0F0E0F',
    popupButtonText: '#FFFFFF',
    popupBorder: '#B8B3AD',
    // Offer
    offerBetterDealBackground: '#F5F5F5',
    // Toggle
    toggleContent: '#0F0E0F',
    toggleOnBackground: '#FFFFFF',
    toggleHandleBorder: '#B8B3AD',
    toggleOffContent: '#4b5563',
    toggleHandleBackground: '#ffffff',
    toggleOffBackground: '#E5E7EB',
    // Badge
    badgeContent: '#0F0E0F',
    badgeBackground: '#B8B3AD',
    // Floating Container
    floatingContainerDivider: '#76726E4D',
    // Shadow
    shadow: '#29272426',
  };
  const karmanowVars = {
    // Extend default theme
    ...commonVars,
    // Logo
    logo: '#1b1c1d',
    logoShimmer: '#1b1c1d',
    logoInactiveContent: '#FFFFFF',
    // Injected Buttons
    buttonBackground: '#FFFFFFF2',
    buttonInactiveBackground: '#FFFFFFF2',
    buttonHoverBackground: '#F8F8F8F2',
    buttonBorder: '#B8B3AD',
    buttonHoverBorder: '#76726E',
    buttonText: '#1b1c1d',
    buttonPrice: '#8D62BF',
    buttonDotsBackground: '#FFFFFF00',
    buttonDots: '#1b1c1d',
    // Popup
    popupTextAccent: '#8D62BF',
    popupButtonBackground: '#1b1c1d',
    popupButtonText: '#E8FF77',
    popupBorder: '#E5E7EB',
    // Toggle
    toggleContent: '#8D62BF',
    toggleOnBackground: '#e4d6f4',
    toggleHandleBorder: '#d3b6ef',
    // Badge
    badgeContent: '#8D62BF',
    badgeBackground: '#d3b6ef',
  };
  let logo;
  let buttonIcon;
  let variables;
  {
    logo = karmanowLogoSvg;
    buttonIcon = karmanowIconSvg;
    variables = karmanowVars;
  }
  const theme = {
    logo,
    buttonIcon,
    variables,
  };
  const createHeader = () => {
    const header = document.createElement('div');
    header.classList.add('hermes-popup-header');
    header.innerHTML = theme.logo;
    const closeButton = document.createElement('button');
    closeButton.classList.add('hermes-popup-closeButton');
    closeButton.innerHTML = closePluginSvg;
    closeButton.addEventListener('click', () => {
      closePopup();
    });
    header.appendChild(closeButton);
    return header;
  };
  const createHeadingPrice = ({ priceDifference, currency, priceDisplayStrategy, isBestOffer }) => {
    const headingPrice = document.createElement('h2');
    headingPrice.classList.add('hermes-popup-headingPrice');
    if (!isBestOffer) {
      headingPrice.innerHTML = formatMessage(
        'youveGotTheBestPrice',
        `You've got <span class="hermes-popup-discount">the best price!</span>`,
      );
    } else {
      const price = formatPrice(priceDifference, currency);
      switch (priceDisplayStrategy) {
        case 'BASE_WITH_CHARGES_ON_SIDE':
          headingPrice.innerHTML +=
            formatMessage('youCanSaveTotal', 'You can save <span class="hermes-popup-discount">{price}</span>', {
              price,
            }) + `<span class="hermes-popup-tax">&nbsp;/&nbsp;${formatMessage('total', 'total')}</span>`;
          break;
        case 'BASE_PER_NIGHT':
          headingPrice.innerHTML += formatMessage(
            'youCanSavePerNight',
            'You can save <span class="hermes-popup-discount">{price}</span> / night!',
            { price },
          );
          break;
        default:
          headingPrice.innerHTML = formatMessage(
            'youCanSaveTitle',
            'You can save <span class="hermes-popup-discount">{price}!</span>',
            { price },
          );
      }
    }
    return headingPrice;
  };
  const starSvg =
    '<svg class="hermes-popup-star" viewBox="0 0 12 12" fill="none" xmlns="http://www.w3.org/2000/svg">\n  <path\n    d="M5.40721 1.5803C5.6533 1.07349 6.34662 1.07349 6.59271 1.5803L7.58311 3.61995C7.67973 3.81895 7.86209 3.95729 8.07323 3.99174L10.2373 4.34481C10.775 4.43255 10.9893 5.12097 10.6036 5.52193L9.05167 7.13558C8.90028 7.29301 8.83057 7.51686 8.86446 7.73717L9.21156 9.995C9.29776 10.556 8.73686 10.9815 8.25246 10.7225L6.30288 9.68014C6.11268 9.57843 5.88724 9.57843 5.69704 9.68014L3.74747 10.7225C3.26305 10.9815 2.70213 10.556 2.78838 9.995L3.13547 7.73717C3.16933 7.51686 3.09967 7.29301 2.94825 7.13558L1.39626 5.52193C1.01063 5.12097 1.22488 4.43255 1.7626 4.34481L3.92668 3.99174C4.13781 3.95729 4.32021 3.81895 4.41683 3.61995L5.40721 1.5803Z"\n    fill="#7F8490" />\n</svg>';
  const createHotelSection = ({ img, stars, checkIn, checkOut, hotelName }) => {
    const hotelContainer = document.createElement('div');
    hotelContainer.classList.add('hermes-popup-hotelContainer');
    const hotelImg = document.createElement('img');
    hotelImg.classList.add('hermes-popup-hotelImg');
    hotelImg.src = img;
    const hotelInfo = document.createElement('div');
    hotelInfo.classList.add('hermes-popup-hotelInfo');
    const starsContainer = document.createElement('div');
    starsContainer.classList.add('hermes-popup-starsContainer');
    starsContainer.innerHTML = new Array(stars).fill(starSvg).join('');
    const hotelNameHeading = document.createElement('h3');
    hotelNameHeading.classList.add('hermes-popup-hotelName');
    hotelNameHeading.textContent = hotelName;
    const checkInFormatted = formatDate(checkIn);
    const checkOutFormatted = formatDate(checkOut);
    const dates = document.createElement('div');
    dates.classList.add('hermes-popup-dates');
    dates.textContent = `${checkInFormatted} - ${checkOutFormatted}`;
    hotelContainer.appendChild(hotelImg);
    hotelInfo.appendChild(starsContainer);
    hotelInfo.appendChild(hotelNameHeading);
    hotelInfo.appendChild(dates);
    hotelContainer.appendChild(hotelInfo);
    return hotelContainer;
  };
  const CHARGES_INCLUDED_PRICE_DISPLAY_STRATEGIES = ['ALL_INCLUSIVE', 'ALL_IN_DAILY', 'ALL_IN_TOTAL_STAY'];
  const PRICE_PER_NIGHT_PRICE_DISPLAY_STRATEGIES = ['BASE_PER_NIGHT'];
  const createBestPriceSection = ({ currency, price, charges, noBetterPriceAvailable, priceDisplayStrategy }) => {
    const priceFormatted = formatPrice(price, currency);
    const isChargesIncluded = CHARGES_INCLUDED_PRICE_DISPLAY_STRATEGIES.includes(priceDisplayStrategy);
    const isPricePerNight = PRICE_PER_NIGHT_PRICE_DISPLAY_STRATEGIES.includes(priceDisplayStrategy);
    const popupContainer = document.createElement('div');
    popupContainer.classList.add('hermes-popup-hermesContainer');
    if (noBetterPriceAvailable) {
      popupContainer.classList.add('hermes-popup-noBetterPriceAvailable');
    }
    const currentPlatform = window.location.hostname.replace('www.', '');
    const bestPriceText = document.createElement('span');
    bestPriceText.classList.add('hermes-popup-bestPriceText');
    if (noBetterPriceAvailable) {
      bestPriceText.textContent = formatMessage('bestPriceOnPlatform', 'Best price on {platform}', {
        platform: currentPlatform,
      });
    } else {
      bestPriceText.textContent = formatMessage('bestPrice', 'Best price');
    }
    const priceSpan = document.createElement('span');
    priceSpan.classList.add('hermes-popup-hermesPrice');
    const priceValue = document.createElement('span');
    priceValue.classList.add('hermes-popup-price');
    priceValue.textContent = priceFormatted;
    priceSpan.appendChild(priceValue);
    if (isChargesIncluded) {
      priceSpan.append(` / ${formatMessage('total', 'total')}`);
    }
    if (isPricePerNight) {
      priceSpan.append(` / ${formatMessage('night', 'night')}`);
    }
    popupContainer.appendChild(bestPriceText);
    popupContainer.appendChild(priceSpan);
    if (!isChargesIncluded && charges) {
      const popupTax2 = document.createElement('span');
      popupTax2.classList.add('hermes-popup-tax');
      const finalPrice = price + charges;
      const finalPriceFormatted = formatPrice(finalPrice, currency);
      const totalTextValue = ` ${formatMessage('total', 'total')}`;
      popupTax2.textContent = finalPriceFormatted;
      popupTax2.append(totalTextValue);
      popupContainer.appendChild(popupTax2);
    }
    const popupTax = document.createElement('span');
    popupTax.classList.add('hermes-popup-tax');
    switch (priceDisplayStrategy) {
      case 'BASE_PER_NIGHT':
        popupTax.textContent = formatMessage('exclTaxAndFees', 'excl tax & fees');
        break;
      default:
        popupTax.textContent = formatMessage('inclTaxAndFees', 'incl tax & fees');
        break;
    }
    popupContainer.appendChild(popupTax);
    return popupContainer;
  };
  const createCurrentPriceSection = ({ currency, price, charges, priceDisplayStrategy, currentPlatform }) => {
    const priceFormatted = formatPrice(price, currency);
    const bookingContainer = document.createElement('div');
    bookingContainer.classList.add('hermes-popup-bookingContainer');
    const bookingName = document.createElement('span');
    bookingName.classList.add('hermes-popup-bookingName');
    bookingName.textContent = formatMessage('onCurrentPlatform', 'On {platform}', {
      platform: currentPlatform,
    });
    const bookingPriceSpan = document.createElement('span');
    bookingPriceSpan.classList.add('hermes-popup-bookingPrice');
    const bookingPriceValue = document.createElement('span');
    bookingPriceValue.classList.add('hermes-popup-price');
    bookingPriceValue.textContent = priceFormatted;
    bookingPriceSpan.appendChild(bookingPriceValue);
    switch (priceDisplayStrategy) {
      case 'ALL_INCLUSIVE':
        bookingPriceSpan.append(` / ${formatMessage('total', 'total')}`);
        break;
      case 'BASE_PER_NIGHT':
        bookingPriceSpan.append(` / ${formatMessage('night', 'night')}`);
        break;
    }
    bookingContainer.appendChild(bookingName);
    bookingContainer.appendChild(bookingPriceSpan);
    switch (priceDisplayStrategy) {
      case 'BASE_WITH_CHARGES_ON_SIDE':
        if (!charges) {
          throw new Error('Charges are required for BASE_WITH_CHARGES_ON_SIDE');
        }
        const baseWithChargesOnSideBookingTax = document.createElement('span');
        baseWithChargesOnSideBookingTax.classList.add('hermes-popup-tax');
        const afterTaxPrice = price + charges;
        const afterTaxPriceFormatted = formatPrice(afterTaxPrice, currency);
        baseWithChargesOnSideBookingTax.textContent = afterTaxPriceFormatted;
        baseWithChargesOnSideBookingTax.append(` / ${formatMessage('total', 'total')}`);
        bookingContainer.appendChild(baseWithChargesOnSideBookingTax);
        break;
      case 'BASE_ONLY':
        const baseOnlyBookingTax = document.createElement('span');
        baseOnlyBookingTax.classList.add('hermes-popup-tax');
        baseOnlyBookingTax.textContent = formatMessage('roomPrice', 'room price');
        bookingContainer.appendChild(baseOnlyBookingTax);
        break;
    }
    const bookingTax = document.createElement('span');
    bookingTax.classList.add('hermes-popup-tax');
    switch (priceDisplayStrategy) {
      case 'BASE_PER_NIGHT':
        bookingTax.textContent = formatMessage('exclTaxAndFees', 'excl tax & fees');
        break;
      case 'BASE_ONLY':
      case 'BASE_RATE':
        bookingTax.textContent = formatMessage('withoutTaxAndFees', 'without tax & fees');
        break;
      case 'BASE_RATE_PLUS_FEES':
        bookingTax.textContent = formatMessage('inclFees', 'incl fees');
        break;
      default:
        bookingTax.textContent = formatMessage('inclTaxAndFees', 'incl tax & fees');
        break;
    }
    bookingContainer.appendChild(bookingTax);
    return bookingContainer;
  };
  const createSitesPriceComparisonSection = ({
    bestPrice: bestPrice2,
    bestRate,
    bookingPrice,
    bookingTax,
    currency,
    priceDisplayStrategy,
    isBestOffer,
  }) => {
    const sitesPriceComparisonContainer = document.createElement('div');
    const currentPlatform = getCurrentPlatformNameFromLocation();
    sitesPriceComparisonContainer.classList.add('hermes-popup-sitesPriceComparisonContainer');
    if (isBestOffer) {
      const bookingContainer = createCurrentPriceSection({
        currency,
        price: bookingPrice,
        charges: bookingTax,
        priceDisplayStrategy,
        currentPlatform,
      });
      sitesPriceComparisonContainer.appendChild(bookingContainer);
      switch (priceDisplayStrategy) {
        case 'BASE_PER_NIGHT':
          const offerContainerPerNight = createBestPriceSection({
            currency,
            price: bestPrice2,
            charges: 0,
            priceDisplayStrategy,
          });
          sitesPriceComparisonContainer.appendChild(offerContainerPerNight);
          break;
        default:
          const offerContainer = createBestPriceSection({
            currency,
            price: bestPrice2,
            // bestPrice is already calculated to be either base, base + fees or all inclusive
            charges: bestRate.taxes + bestRate.hotelFees,
            priceDisplayStrategy,
          });
          sitesPriceComparisonContainer.appendChild(offerContainer);
          break;
      }
    } else {
      const bestPriceOnBooking = createBestPriceSection({
        currency,
        price: bookingPrice,
        charges: bookingTax,
        noBetterPriceAvailable: true,
        priceDisplayStrategy,
      });
      sitesPriceComparisonContainer.appendChild(bestPriceOnBooking);
      sitesPriceComparisonContainer.classList.add('hermes-popup-noBetterPriceAvailable');
    }
    return sitesPriceComparisonContainer;
  };
  const createViewDealCallToAction = bestOfferUrl => {
    const viewDealButton = document.createElement('a');
    viewDealButton.classList.add('hermes-popup-viewDealButton');
    viewDealButton.innerHTML = `${formatMessage('viewDeal', 'View Deal')} ${arrowRightSvg}`;
    viewDealButton.href = getDealUrl(bestOfferUrl);
    viewDealButton.setAttribute('target', '_blank');
    return viewDealButton;
  };
  const createPluginView = ({
    priceDifference,
    currency,
    checkIn,
    checkOut,
    stars,
    img,
    hotelName,
    roomsAmount,
    adults,
    children,
    bestPrice: bestPrice2,
    bestRate,
    bookingPrice,
    bookingTax,
    // this is the tax which is shown separately by the platform when strategy is "BASE_WITH_CHARGES_ON_SIDE" (ADDITONAL CHARGES)
    bestOfferUrl,
    offers,
    priceDisplayStrategy,
    isBestOffer,
  }) => {
    const popupWrapper = document.createElement('div');
    popupWrapper.classList.add('hermes-popup-wrapper');
    const popupHeader = createHeader();
    const popupBody = document.createElement('div');
    popupBody.classList.add('hermes-popup-pluginBody');
    const headingPrice = createHeadingPrice({
      priceDifference,
      currency,
      priceDisplayStrategy,
      isBestOffer,
    });
    const hotelContainer = createHotelSection({
      checkIn,
      checkOut,
      hotelName,
      img,
      stars,
    });
    const room = document.createElement('h4');
    const daysBetweenDates = daysBetween(checkIn, checkOut);
    const guests = adults + children;
    room.classList.add('hermes-popup-roomName');
    room.innerHTML = formatMessage(
      'roomsAndNightsAndGuests',
      '{nights, plural, one {1 night} other {# nights}} · {rooms, plural, one {1 room} other {# rooms}} · {guests, plural, one {1 guest} other {# guests}}',
      {
        nights: daysBetweenDates,
        rooms: roomsAmount,
        guests,
      },
    );
    const sitesPriceComparisonContainer = createSitesPriceComparisonSection({
      bookingPrice,
      bookingTax,
      currency,
      bestPrice: bestPrice2,
      bestRate,
      priceDisplayStrategy,
      isBestOffer,
    });
    const viewDealButton = createViewDealCallToAction(bestOfferUrl);
    const compareBestPricesContainer = createCompareBestPricesSection({
      priceDifference,
      bookingPrice,
      currency,
      offers,
    });
    popupBody.append(
      headingPrice,
      hotelContainer,
      room,
      sitesPriceComparisonContainer,
      viewDealButton,
      compareBestPricesContainer,
    );
    popupWrapper.append(popupHeader, popupBody);
    return { html: popupWrapper };
  };
  const updatePopup = data => {
    const popup = document.getElementById('hermes-popup');
    if (!popup) {
      return;
    }
    const pluginView = createPluginView(data);
    const pluginViewContainer = document.createElement('div');
    pluginViewContainer.setAttribute('id', 'hermes-popup-container');
    pluginViewContainer.appendChild(pluginView.html);
    popup.innerHTML = '';
    popup.appendChild(pluginViewContainer);
  };
  const updateCardButton = ({
    parent,
    bestOfferPrice,
    isBestOffer,
    currency,
    pluginViewData,
    trackingContext,
    badgeId,
    details,
  }) => {
    const buttonSelector = badgeId
      ? `.hermes-search-result-badge[${ELEMENTS_ATTRIBUTES.BADGE_ID}=${badgeId}]`
      : '.hermes-search-result-badge';
    const cardButton = parent.querySelector(buttonSelector);
    if (!cardButton) {
      return logger.info('Badge not found');
    }
    cardButton.classList.remove('loading');
    const textContainer = cardButton.querySelector('.textContainer');
    if (!textContainer) {
      return;
    }
    if (!isBestOffer) {
      cardButton.classList.add('noBetterPriceAvailable');
    }
    const price = formatPrice(bestOfferPrice, currency);
    if (isBestOffer) {
      textContainer.innerHTML = `${formatMessage('betterDeal', 'Better deal')}&nbsp<span class="price">${price}</span>`;
      cardButton.parentElement?.setAttribute('data-better-offer', 'true');
      const cardButtonAlreadyHasIcon = cardButton.querySelector('.hermes-icon-arrowRight');
      if (!cardButtonAlreadyHasIcon) {
        cardButton.innerHTML += arrowRightSvg;
      }
    } else {
      textContainer.innerHTML = `${formatMessage('bestPrice', 'Best price')}&nbsp<span class="price">${price}</span>`;
    }
    if (details) {
      const detailsContainer = cardButton.parentElement?.querySelector('.hermes-button-details');
      if (!detailsContainer) {
        return;
      }
      detailsContainer.innerHTML = formatMessage(
        'roomsAndNightsAndGuests',
        '{nights, plural, one {1 night} other {# nights}} · {rooms, plural, one {1 room} other {# rooms}} · {guests, plural, one {1 guest} other {# guests}}',
        {
          nights: details.nights,
          rooms: details.rooms,
          guests: details.guests,
        },
      );
    }
    observeImpression(cardButton, () => {
      void tracking.trackInlineButtonViewed({
        offerContext: {
          ...trackingContext.offerContext,
          offerPosition: 'card',
        },
        hotelContext: trackingContext.hotelContext,
      });
    });
    if (!pluginViewData) {
      return;
    }
    const handleSearchPageClick = event => {
      event.stopImmediatePropagation();
      event.stopPropagation();
      event.preventDefault();
      updatePopup(pluginViewData);
      openPopup(trackingContext.hotelContext);
    };
    cardButton.addEventListener('click', handleSearchPageClick);
  };
  class SiteAdapter {
    constructor(hotelIdProvider = 'OTHER') {
      __publicField(this, 'childrenAges', null);
      __publicField(this, 'rooms', null);
      __publicField(this, 'adults');
      __publicField(this, 'children');
      __publicField(this, 'checkIn');
      __publicField(this, 'checkOut');
      __publicField(this, 'currency');
      __publicField(this, 'country', null);
      __publicField(this, 'city', null);
      __publicField(this, 'lat', null);
      __publicField(this, 'lng', null);
      __publicField(this, 'hotelIdProvider');
      try {
        this.hotelIdProvider = hotelIdProvider;
        if (typeof window === 'undefined') {
          throw new Error('Page has not fully loaded.');
        }
        logger.info('SiteAdapter initialized successfully', { hotelIdProvider });
      } catch (error) {
        logger.error('Error initializing SiteAdapter:', error);
        throw error;
      }
    }
    updateCommonButton(props) {
      try {
        updateCardButton(props);
        logger.info('Common button updated successfully');
      } catch (error) {
        logger.warn('Error updating common button:', error);
        throw error;
      }
    }
    async getValuesFromUrlOrContent() {
      try {
        logger.info('Extracting values from URL or page content.');
        const urlData = this.getSearchContextFromUrl();
        const [checkIn, checkOut, currency, country, city, children, adults, rooms] = await Promise.all([
          urlData.checkInDate || this.getCheckInDateFromContent(),
          urlData.checkOutDate || this.getCheckOutDateFromContent(),
          urlData.currency || this.getCurrencyFromContent(),
          urlData.country || this.getCountryFromContent(),
          urlData.city || this.getCityFromContent(),
          urlData.numberOfChildren ?? this.getChildrenFromContent(),
          urlData.numberOfAdults ?? this.getAdultsFromContent(),
          urlData.numberOfRooms ?? this.getRoomsFromContent(),
        ]);
        const childrenAges = urlData.childrenAges || (await this.getChildrenAgesFromContent(children ?? void 0));
        const extractedData = {
          checkIn,
          checkOut,
          currency,
          country,
          city,
          adults,
          children,
          childrenAges,
          lat: urlData.lat ?? null,
          lng: urlData.lng ?? null,
          rooms,
        };
        logger.info('Extracted values from URL or content:', {
          extractedData,
        });
        return extractedData;
      } catch (error) {
        const errorMessage = error instanceof Error ? error.message : String(error);
        throw new Error(`Error extracting values from URL or content: ${errorMessage}`);
      }
    }
    /**
     * Throws an error if it's not possible to return a value that is not null or undefined
     *
     */
    ensurePropertyExistsAndReturn(value, property) {
      if (value === void 0 || value === null) {
        throw new Error(`Required property=${property} is not found in the URL or page content.`);
      }
      return value;
    }
    /**
     * Initializes the required properties for the site adapter.
     * Throws an error if any required property is not found in the URL or page content.
     * Should be called before all other methods that depend on these properties.
     */
    async initializeSiteAdapterRequiredProperties() {
      try {
        const { checkIn, checkOut, currency, city, country, adults, children, childrenAges, lat, lng, rooms } =
          await this.getValuesFromUrlOrContent();
        this.checkIn = this.ensurePropertyExistsAndReturn(checkIn, 'checkIn');
        this.checkOut = this.ensurePropertyExistsAndReturn(checkOut, 'checkOut');
        this.currency = this.ensurePropertyExistsAndReturn(currency, 'currency');
        this.adults = this.ensurePropertyExistsAndReturn(adults, 'adults');
        this.children = this.ensurePropertyExistsAndReturn(children, 'children');
        this.rooms = this.ensurePropertyExistsAndReturn(rooms, 'rooms');
        this.country = country;
        this.city = city;
        this.childrenAges = childrenAges;
        this.lat = lat;
        this.lng = lng;
        logger.success('All required properties are present and initialized');
      } catch (error) {
        logger.warn('Error initializing site adapter required properties:', error);
        throw error;
      }
    }
    get shouldOptimizeRooms() {
      return this.adults > OPTIMIZE_ROOMS_LIMIT;
    }
    /**
     * Returns formatted optimized rooms string for the API or throws if not possible
     *
     */
    get roomsConfiguration() {
      try {
        logger.info(`Getting rooms data adults=${this.adults} children=${this.children}.`);
        logger.info('Children array for rooms:', this.childrenAges);
        if (isNaN(Number(this.adults)) || isNaN(Number(this.children))) {
          throw new Error(`Required property for rooms not found adults=${this.adults} children=${this.children}`);
        }
        if (this.adults === 0 || this.adults === null || this.adults === void 0) {
          throw new Error(`Required property for rooms: adults not found`);
        }
        if (this.adults < 1) {
          throw new Error(`Required property for rooms: adults must be greater than 0`);
        }
        if (this.shouldOptimizeRooms) {
          return getOptimizedRoomsConfiguration({
            adults: this.adults,
            children: this.children,
            childrenAges: this.childrenAges,
          });
        }
        return getAveragedRoomsConfiguration({
          adults: this.adults,
          children: this.children,
          childrenAges: this.childrenAges,
          rooms: this.rooms ?? 1,
        });
      } catch (error) {
        logger.warn('Error getting rooms configuration:', error);
        throw error;
      }
    }
    /**
     * Returns formatted label for partner and source tracking
     *
     */
    get label() {
      try {
        const labelParams = new URLSearchParams();
        labelParams.set('partner', 'karmanow');
        labelParams.set('source', window.location.hostname.replace('www.', ''));
        labelParams.set('anonymousId', tracking.getAnonymousId());
        labelParams.set('env', getCurrentEnv());
        const label = labelParams.toString();
        const encodedLabel = encodeURIComponent(label);
        logger.info('Generated label for tracking:', { label: encodedLabel });
        return encodedLabel;
      } catch (error) {
        logger.warn('Error generating label:', error);
        return encodeURIComponent(`partner=${'karmanow'}&source=${window.location.hostname}&env=${getCurrentEnv()}`);
      }
    }
    async fetchHotelData(query) {
      try {
        tracking.addToSearchContext({
          checkIn: this.checkIn,
          checkOut: this.checkOut,
          rooms: this.roomsConfiguration,
          numberOfAdults: this.adults,
          numberOfChildren: this.children,
          searchType: 'hotelList',
          query,
          searchProviderHotelIds: query.hotelIds ?? void 0,
          searchProviderName: query.hotelIdsProvider ?? void 0,
        });
        const brandPartnerKey = REMOTE_CONFIG_BRAND_KEY;
        const brandApiParams = REMOTE_CONFIG.brands?.[brandPartnerKey]?.apiParams ?? {};
        const response = await searchAPI.search({
          hotelAttributes: ['details'],
          language: getSupportedLanguageCode(config.options.language),
          rooms: this.roomsConfiguration,
          checkIn: this.checkIn,
          checkOut: this.checkOut,
          currency: this.currency,
          query,
          optimizeRooms: this.shouldOptimizeRooms,
          label: this.label,
          anonymousId: tracking.getAnonymousId(),
          ...REMOTE_CONFIG.apiParams,
          ...brandApiParams,
        });
        logger.success('Hotel data fetched successfully');
        return response;
      } catch (error) {
        const errorMessage = error instanceof Error ? error.message : String(error);
        throw new Error(`Error fetching hotel data: ${errorMessage}`);
      }
    }
  }
  const HOTEL_ID_PROVIDERS = {
    EXPEDIA: 'EXP',
    BOOKING: 'BKS',
    'HOTELS.COM': 'IAN',
    OTHER: null,
  };
  const getOffersWithPrice = ({ offers, priceDisplayStrategy, nights, roomsCount, multiplyPriceByRoomsCount }) => {
    return offers
      .map(offer => {
        const { base, taxes, hotelFees } = offer.rate;
        const baseOnly = base;
        const baseWithFees = base + hotelFees;
        const allInclusive = base + taxes + hotelFees;
        switch (priceDisplayStrategy) {
          case 'BASE_PER_NIGHT':
            return {
              ...offer,
              displayPrice: baseOnly / nights,
              internalComparisonPrice: baseOnly / nights,
            };
          case 'BASE_RATE_PLUS_FEES':
            return { ...offer, displayPrice: baseWithFees, internalComparisonPrice: allInclusive };
          case 'BASE_WITH_CHARGES_ON_SIDE':
            return { ...offer, displayPrice: baseOnly, internalComparisonPrice: allInclusive };
          case 'ALL_IN_TOTAL_STAY':
          case 'ALL_IN_DAILY':
          case 'ALL_INCLUSIVE':
            return { ...offer, displayPrice: allInclusive, internalComparisonPrice: allInclusive };
          case 'BASE_ONLY':
          case 'BASE_RATE':
          default:
            return { ...offer, displayPrice: baseOnly, internalComparisonPrice: baseOnly };
        }
      })
      .map(offer => {
        if (multiplyPriceByRoomsCount && roomsCount) {
          return {
            ...offer,
            displayPrice: offer.displayPrice * roomsCount,
            internalComparisonPrice: offer.internalComparisonPrice * roomsCount,
          };
        }
        return offer;
      });
  };
  const parseOffersForModalList = ({ offers, priceDisplayStrategy, roomsCount, multiplyPriceByRoomsCount, nights }) => {
    const offersWithPrice = getOffersWithPrice({
      offers,
      priceDisplayStrategy,
      nights,
      roomsCount,
      multiplyPriceByRoomsCount,
    });
    const sortedOffers = offersWithPrice.sort((a, b) => a.displayPrice - b.displayPrice);
    const bestOffer = sortedOffers[0];
    return { bestOffer, sortedOffers };
  };
  const getCurrentDomainNameWithoutTLD = () => {
    const currentDomain = getCurrentDomainFromLocation();
    const [domainName] = currentDomain.split('.');
    return domainName;
  };
  const getCurrentProvider = () => {
    const currentDomainWithoutTLD = getCurrentDomainNameWithoutTLD();
    const currentDomainConfig = Object.values(REMOTE_CONFIG.domains).find(domain =>
      domain.domains.some(d => d.includes(currentDomainWithoutTLD)),
    );
    return currentDomainConfig?.provider;
  };
  const getIsBestOffer = ({
    offers,
    currentPrice,
    currentCharges,
    priceDisplayStrategy,
    roomsCount,
    multiplyPriceByRoomsCount = false,
    nights,
  }) => {
    const currentComparisonPrice = (currentPrice || 0) + (currentCharges || 0);
    const currentProvider = getCurrentProvider();
    const offersWithoutCurrentProvider = offers.filter(offer => offer.provider.name !== currentProvider);
    if (offersWithoutCurrentProvider.length === 0) {
      return {
        isBestOffer: false,
        bestDisplayPrice: currentPrice || 0,
        bestComparisonPrice: currentComparisonPrice,
        priceDifference: 0,
        bestOffer: void 0,
      };
    }
    const offersWithPrice = getOffersWithPrice({
      offers: offersWithoutCurrentProvider,
      priceDisplayStrategy,
      nights,
      roomsCount,
      multiplyPriceByRoomsCount,
    });
    const sortedOffers = offersWithPrice.sort((a, b) => a?.internalComparisonPrice - b?.internalComparisonPrice);
    const bestOffer = sortedOffers[0];
    if (!currentPrice && bestOffer) {
      return {
        isBestOffer: true,
        bestDisplayPrice: bestOffer.displayPrice,
        bestComparisonPrice: bestOffer.internalComparisonPrice,
        priceDifference: 0,
        bestOffer,
      };
    }
    if (currentPrice && bestOffer) {
      const priceDifferencePercent =
        ((bestOffer.internalComparisonPrice - currentComparisonPrice) / currentComparisonPrice) * 100;
      const isBestOffer = priceDifferencePercent < REMOTE_CONFIG.variables.BETTER_PRICE_PERCENT_DIFFERENCE;
      const bestDisplayPrice = isBestOffer ? bestOffer.displayPrice : currentPrice;
      const bestComparisonPrice = isBestOffer ? bestOffer.internalComparisonPrice : currentComparisonPrice;
      const priceDifference = currentComparisonPrice - bestOffer.internalComparisonPrice;
      return {
        isBestOffer,
        bestDisplayPrice,
        bestComparisonPrice,
        priceDifference,
        bestOffer,
      };
    }
    if (currentPrice && !bestOffer) {
      return {
        isBestOffer: false,
        bestDisplayPrice: currentPrice,
        bestComparisonPrice: currentComparisonPrice,
        priceDifference: 0,
        bestOffer,
      };
    }
    return {
      isBestOffer: false,
      bestDisplayPrice: 0,
      bestComparisonPrice: 0,
      priceDifference: 0,
      bestOffer,
    };
  };
  const getDateDiffInDays = (date1, date2) => {
    const msPerDay = 1e3 * 60 * 60 * 24;
    const utc1 = Date.UTC(date1.getFullYear(), date1.getMonth(), date1.getDate());
    const utc2 = Date.UTC(date2.getFullYear(), date2.getMonth(), date2.getDate());
    return Math.abs(Math.floor((utc2 - utc1) / msPerDay));
  };
  const createElementWithClass = (tag, className) => {
    const element = document.createElement(tag);
    element.classList.add(className);
    return element;
  };
  const createButton = () => {
    const button = createElementWithClass('button', 'hermes-button-common');
    button.setAttribute('id', 'hermes-floating-plugin-button');
    const textContainer = createElementWithClass('div', 'textContainer');
    button.appendChild(textContainer);
    return button;
  };
  const createStickyButton = () => {
    const stickyContainerButtonContainer = document.querySelector('#hermes-floating-container .button-container');
    if (!stickyContainerButtonContainer) {
      logger.warn('Sticky button container not found');
      return;
    }
    const existingButton = document.querySelector('#hermes-floating-plugin-button');
    if (existingButton) {
      return;
    }
    const floatingButton = createButton();
    stickyContainerButtonContainer.append(floatingButton);
  };
  const removeStickyButton = () => {
    const buttonContainer = document.querySelector('#hermes-floating-container .button-container');
    if (buttonContainer) {
      buttonContainer.classList.add('hidden');
    }
    const floatingButton = document.querySelector('#hermes-floating-plugin-button');
    if (!floatingButton) {
      return;
    }
    floatingButton.remove();
  };
  const arrowDownSvg =
    '<svg viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg" class="arrowDown">\n<path fill-rule="evenodd" clip-rule="evenodd" d="M4.22209 4.98844C4.00041 4.7497 3.62718 4.73588 3.38845 4.95756C3.14972 5.17924 3.13589 5.55247 3.35757 5.7912L7.56769 10.3252C7.6793 10.4454 7.83592 10.5137 7.99995 10.5137C8.16398 10.5137 8.3206 10.4454 8.43221 10.3252L12.6423 5.7912C12.864 5.55247 12.8502 5.17924 12.6115 4.95756C12.3727 4.73588 11.9995 4.7497 11.7778 4.98843L7.99995 9.0569L4.22209 4.98844Z" fill="white"/>\n</svg>\n';
  const showTableButton = () => {
    const expandedButton = document.querySelector('#hermes-expanded-plugin-button');
    if (!expandedButton) {
      return;
    }
    expandedButton.setAttribute('visible', 'true');
  };
  const updateTextContainer = (textContainer, price, isBestOffer) => {
    if (isBestOffer) {
      textContainer.innerHTML = `${formatMessage(
        'betterDeal',
        'Better deal',
      )}&nbsp<span class="price">${price}</span> ${arrowDownSvg}`;
    } else {
      textContainer.innerHTML = `${formatMessage(
        'bestPrice',
        'Best price',
      )}&nbsp<span class="price">${price}</span> ${arrowDownSvg}`;
    }
  };
  const addBetterOfferBadge = stickyContainer => {
    const existingBadge = stickyContainer.querySelector('.betterOfferBadge');
    if (existingBadge) {
      return;
    }
    const betterOfferBadge = createElementWithClass('div', 'betterOfferBadge');
    betterOfferBadge.textContent = '1';
    stickyContainer.appendChild(betterOfferBadge);
  };
  const attachClickHandlers = (floatingPluginButton, hotelContext) => {
    floatingPluginButton.addEventListener('click', () => {
      openPopup(hotelContext);
      showTableButton();
    });
  };
  const updateStickyButton = ({ bestOfferPrice, isBestOffer, currency, trackingContext }) => {
    const floatingPluginButton = document.querySelector('#hermes-floating-plugin-button');
    const stickyContainer = document.querySelector('#hermes-floating-container');
    const buttonContainer = document.querySelector('#hermes-floating-container .button-container');
    if (!floatingPluginButton || !stickyContainer || !buttonContainer) {
      return;
    }
    const textContainer = floatingPluginButton.querySelector('.textContainer');
    if (textContainer) {
      stickyContainer.classList.remove('loading');
      buttonContainer.classList.remove('hidden');
      const price = formatPrice(bestOfferPrice, currency);
      if (isBestOffer) {
        addBetterOfferBadge(stickyContainer);
        stickyContainer.setAttribute('data-better-offer', 'true');
      }
      updateTextContainer(textContainer, price, isBestOffer);
    }
    observeImpression(floatingPluginButton, () => {
      void tracking.trackInlineButtonViewed({
        offerContext: {
          ...trackingContext.offerContext,
          offerPosition: 'sticky',
        },
        hotelContext: trackingContext.hotelContext,
      });
    });
    attachClickHandlers(floatingPluginButton, trackingContext.hotelContext);
  };
  const closeIconSvg =
    '<svg viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg" class="closeIcon">\n<path fill-rule="evenodd" clip-rule="evenodd" d="M11.046 3.69628C11.2511 3.49125 11.2511 3.15884 11.046 2.95382C10.841 2.74879 10.5086 2.74879 10.3036 2.95382L6.9998 6.25759L3.69604 2.95382C3.49101 2.74879 3.1586 2.74879 2.95357 2.95382C2.74855 3.15884 2.74855 3.49125 2.95357 3.69628L6.25734 7.00005L2.95357 10.3038C2.74855 10.5088 2.74855 10.8413 2.95357 11.0463C3.1586 11.2513 3.49101 11.2513 3.69604 11.0463L6.9998 7.74251L10.3036 11.0463C10.5086 11.2513 10.841 11.2513 11.046 11.0463C11.2511 10.8413 11.2511 10.5088 11.046 10.3038L7.74227 7.00005L11.046 3.69628Z" fill="white"/>\n</svg>\n';
  const createTableButton = props => {
    const { mountingPointSelector, mountingPointElement, priceCellSelector, classNames } = props || {};
    const buttonContainer = document.createElement('div');
    buttonContainer.classList.add('hermes-expanded-button-container');
    if (classNames?.container) {
      buttonContainer.classList.add(...classNames.container);
    }
    const buttonShadow = document.createElement('div');
    buttonShadow.classList.add('hermes-button-common-shadow');
    buttonContainer.appendChild(buttonShadow);
    const expandedButton = document.createElement('button');
    const container =
      mountingPointElement ||
      document.querySelector(mountingPointSelector ?? SELECTORS.booking.accommodationPage.table.buttonMountingPoint);
    const priceCell = document.querySelector(priceCellSelector ?? SELECTORS.booking.accommodationPage.table.priceCell);
    if (priceCell) {
      priceCell.style.paddingTop = '16px';
    }
    expandedButton.classList.add('hermes-button-common');
    expandedButton.setAttribute('id', 'hermes-expanded-plugin-button');
    expandedButton.setAttribute('visible', 'true');
    expandedButton.classList.add('loading');
    expandedButton.setAttribute('type', 'button');
    expandedButton.innerHTML = theme.buttonIcon;
    const textContainer = document.createElement('div');
    textContainer.classList.add('textContainer');
    textContainer.textContent = formatMessage('checkingDeals', 'Checking deals');
    expandedButton.appendChild(textContainer);
    const closeExpandedButton = document.createElement('button');
    closeExpandedButton.setAttribute('type', 'button');
    closeExpandedButton.setAttribute('id', 'hermes-close-expanded-plugin-button');
    closeExpandedButton.classList.add('loading');
    closeExpandedButton.innerHTML = closeIconSvg;
    expandedButton.appendChild(closeExpandedButton);
    buttonContainer.appendChild(expandedButton);
    container?.appendChild(buttonContainer);
  };
  const destroyTableButton = () => {
    const expandedButton = document.querySelector('#hermes-expanded-plugin-button');
    if (!expandedButton) {
      return;
    }
    expandedButton.remove();
  };
  const updateTableButton = ({ bestOfferPrice, isBestOffer, currency, trackingContext }) => {
    const expandedButton = document.querySelector('#hermes-expanded-plugin-button');
    if (!expandedButton) {
      return;
    }
    expandedButton.classList.remove('loading');
    const textContainer = expandedButton.querySelector('.textContainer');
    const closeExpandedButton = document.querySelector('#hermes-close-expanded-plugin-button');
    closeExpandedButton?.classList.remove('loading');
    closeExpandedButton?.addEventListener('click', e => {
      e.stopImmediatePropagation();
      e.stopPropagation();
      expandedButton.setAttribute('visible', 'false');
    });
    if (!isBestOffer) {
      expandedButton.classList.add('noBetterPriceAvailable');
    }
    if (textContainer && isBestOffer) {
      const price = formatPrice(bestOfferPrice, currency);
      textContainer.innerHTML = `${formatMessage(
        'betterDeal',
        'Better deal',
      )}&nbsp<span class="price">${price}</span> ${arrowRightSvg}`;
      expandedButton.parentElement?.setAttribute('data-better-offer', 'true');
    }
    observeImpression(expandedButton, () => {
      void tracking.trackInlineButtonViewed({
        offerContext: {
          ...trackingContext.offerContext,
          offerPosition: 'table',
        },
        hotelContext: trackingContext.hotelContext,
      });
    });
    expandedButton.addEventListener('click', () => {
      openPopup(trackingContext.hotelContext);
    });
  };
  (function () {
    var n = window.Document.prototype.createElement,
      p = window.Document.prototype.createElementNS,
      aa = window.Document.prototype.importNode,
      ba = window.Document.prototype.prepend,
      ca = window.Document.prototype.append,
      da = window.DocumentFragment.prototype.prepend,
      ea = window.DocumentFragment.prototype.append,
      q = window.Node.prototype.cloneNode,
      r = window.Node.prototype.appendChild,
      t = window.Node.prototype.insertBefore,
      u = window.Node.prototype.removeChild,
      v = window.Node.prototype.replaceChild,
      w = Object.getOwnPropertyDescriptor(window.Node.prototype, 'textContent'),
      y = window.Element.prototype.attachShadow,
      z = Object.getOwnPropertyDescriptor(window.Element.prototype, 'innerHTML'),
      A = window.Element.prototype.getAttribute,
      B = window.Element.prototype.setAttribute,
      C = window.Element.prototype.removeAttribute,
      D = window.Element.prototype.toggleAttribute,
      E = window.Element.prototype.getAttributeNS,
      F = window.Element.prototype.setAttributeNS,
      G = window.Element.prototype.removeAttributeNS,
      H = window.Element.prototype.insertAdjacentElement,
      fa = window.Element.prototype.insertAdjacentHTML,
      ha = window.Element.prototype.prepend,
      ia = window.Element.prototype.append,
      ja = window.Element.prototype.before,
      ka = window.Element.prototype.after,
      la = window.Element.prototype.replaceWith,
      ma = window.Element.prototype.remove,
      na = window.HTMLElement,
      I = Object.getOwnPropertyDescriptor(window.HTMLElement.prototype, 'innerHTML'),
      oa = window.HTMLElement.prototype.insertAdjacentElement,
      pa = window.HTMLElement.prototype.insertAdjacentHTML;
    var qa = /* @__PURE__ */ new Set();
    'annotation-xml color-profile font-face font-face-src font-face-uri font-face-format font-face-name missing-glyph'
      .split(' ')
      .forEach(function (a) {
        return qa.add(a);
      });
    function ra(a) {
      var b = qa.has(a);
      a = /^[a-z][.0-9_a-z]*-[-.0-9_a-z]*$/.test(a);
      return !b && a;
    }
    var sa = document.contains
      ? document.contains.bind(document)
      : document.documentElement.contains.bind(document.documentElement);
    function J(a) {
      var b = a.isConnected;
      if (void 0 !== b) return b;
      if (sa(a)) return true;
      for (; a && !(a.__CE_isImportDocument || a instanceof Document); )
        a = a.parentNode || (window.ShadowRoot && a instanceof ShadowRoot ? a.host : void 0);
      return !(!a || !(a.__CE_isImportDocument || a instanceof Document));
    }
    function K(a) {
      var b = a.children;
      if (b) return Array.prototype.slice.call(b);
      b = [];
      for (a = a.firstChild; a; a = a.nextSibling) a.nodeType === Node.ELEMENT_NODE && b.push(a);
      return b;
    }
    function L(a, b) {
      for (; b && b !== a && !b.nextSibling; ) b = b.parentNode;
      return b && b !== a ? b.nextSibling : null;
    }
    function M(a, b, d) {
      for (var f = a; f; ) {
        if (f.nodeType === Node.ELEMENT_NODE) {
          var c = f;
          b(c);
          var e = c.localName;
          if ('link' === e && 'import' === c.getAttribute('rel')) {
            f = c.import;
            void 0 === d && (d = /* @__PURE__ */ new Set());
            if (f instanceof Node && !d.has(f)) for (d.add(f), f = f.firstChild; f; f = f.nextSibling) M(f, b, d);
            f = L(a, c);
            continue;
          } else if ('template' === e) {
            f = L(a, c);
            continue;
          }
          if ((c = c.__CE_shadowRoot)) for (c = c.firstChild; c; c = c.nextSibling) M(c, b, d);
        }
        f = f.firstChild ? f.firstChild : L(a, f);
      }
    }
    function N() {
      var a = !(null === O || void 0 === O || !O.noDocumentConstructionObserver),
        b = !(null === O || void 0 === O || !O.shadyDomFastWalk);
      this.m = [];
      this.g = [];
      this.j = false;
      this.shadyDomFastWalk = b;
      this.I = !a;
    }
    function P(a, b, d, f) {
      var c = window.ShadyDOM;
      if (a.shadyDomFastWalk && c && c.inUse) {
        if ((b.nodeType === Node.ELEMENT_NODE && d(b), b.querySelectorAll))
          for (a = c.nativeMethods.querySelectorAll.call(b, '*'), b = 0; b < a.length; b++) d(a[b]);
      } else M(b, d, f);
    }
    function ta(a, b) {
      a.j = true;
      a.m.push(b);
    }
    function ua(a, b) {
      a.j = true;
      a.g.push(b);
    }
    function Q(a, b) {
      a.j &&
        P(a, b, function (d) {
          return R(a, d);
        });
    }
    function R(a, b) {
      if (a.j && !b.__CE_patched) {
        b.__CE_patched = true;
        for (var d = 0; d < a.m.length; d++) a.m[d](b);
        for (d = 0; d < a.g.length; d++) a.g[d](b);
      }
    }
    function S(a, b) {
      var d = [];
      P(a, b, function (c) {
        return d.push(c);
      });
      for (b = 0; b < d.length; b++) {
        var f = d[b];
        1 === f.__CE_state ? a.connectedCallback(f) : T(a, f);
      }
    }
    function U(a, b) {
      var d = [];
      P(a, b, function (c) {
        return d.push(c);
      });
      for (b = 0; b < d.length; b++) {
        var f = d[b];
        1 === f.__CE_state && a.disconnectedCallback(f);
      }
    }
    function V(a, b, d) {
      d = void 0 === d ? {} : d;
      var f = d.J,
        c =
          d.upgrade ||
          function (g) {
            return T(a, g);
          },
        e = [];
      P(
        a,
        b,
        function (g) {
          a.j && R(a, g);
          if ('link' === g.localName && 'import' === g.getAttribute('rel')) {
            var h = g.import;
            h instanceof Node && ((h.__CE_isImportDocument = true), (h.__CE_registry = document.__CE_registry));
            h && 'complete' === h.readyState
              ? (h.__CE_documentLoadHandled = true)
              : g.addEventListener('load', function () {
                  var k = g.import;
                  if (!k.__CE_documentLoadHandled) {
                    k.__CE_documentLoadHandled = true;
                    var l = /* @__PURE__ */ new Set();
                    f &&
                      (f.forEach(function (m) {
                        return l.add(m);
                      }),
                      l.delete(k));
                    V(a, k, { J: l, upgrade: c });
                  }
                });
          } else e.push(g);
        },
        f,
      );
      for (b = 0; b < e.length; b++) c(e[b]);
    }
    function T(a, b) {
      try {
        var d = b.ownerDocument,
          f = d.__CE_registry;
        var c = f && (d.defaultView || d.__CE_isImportDocument) ? W(f, b.localName) : void 0;
        if (c && void 0 === b.__CE_state) {
          c.constructionStack.push(b);
          try {
            try {
              if (new c.constructorFunction() !== b)
                throw Error('The custom element constructor did not produce the element being upgraded.');
            } finally {
              c.constructionStack.pop();
            }
          } catch (k) {
            throw ((b.__CE_state = 2), k);
          }
          b.__CE_state = 1;
          b.__CE_definition = c;
          if (c.attributeChangedCallback && b.hasAttributes()) {
            var e = c.observedAttributes;
            for (c = 0; c < e.length; c++) {
              var g = e[c],
                h = b.getAttribute(g);
              null !== h && a.attributeChangedCallback(b, g, null, h, null);
            }
          }
          J(b) && a.connectedCallback(b);
        }
      } catch (k) {
        X(k);
      }
    }
    N.prototype.connectedCallback = function (a) {
      var b = a.__CE_definition;
      if (b.connectedCallback)
        try {
          b.connectedCallback.call(a);
        } catch (d) {
          X(d);
        }
    };
    N.prototype.disconnectedCallback = function (a) {
      var b = a.__CE_definition;
      if (b.disconnectedCallback)
        try {
          b.disconnectedCallback.call(a);
        } catch (d) {
          X(d);
        }
    };
    N.prototype.attributeChangedCallback = function (a, b, d, f, c) {
      var e = a.__CE_definition;
      if (e.attributeChangedCallback && -1 < e.observedAttributes.indexOf(b))
        try {
          e.attributeChangedCallback.call(a, b, d, f, c);
        } catch (g) {
          X(g);
        }
    };
    function va(a, b, d, f) {
      var c = b.__CE_registry;
      if (c && (null === f || 'http://www.w3.org/1999/xhtml' === f) && (c = W(c, d)))
        try {
          var e = new c.constructorFunction();
          if (void 0 === e.__CE_state || void 0 === e.__CE_definition)
            throw Error(
              "Failed to construct '" +
                d +
                "': The returned value was not constructed with the HTMLElement constructor.",
            );
          if ('http://www.w3.org/1999/xhtml' !== e.namespaceURI)
            throw Error(
              "Failed to construct '" + d + "': The constructed element's namespace must be the HTML namespace.",
            );
          if (e.hasAttributes())
            throw Error("Failed to construct '" + d + "': The constructed element must not have any attributes.");
          if (null !== e.firstChild)
            throw Error("Failed to construct '" + d + "': The constructed element must not have any children.");
          if (null !== e.parentNode)
            throw Error("Failed to construct '" + d + "': The constructed element must not have a parent node.");
          if (e.ownerDocument !== b)
            throw Error("Failed to construct '" + d + "': The constructed element's owner document is incorrect.");
          if (e.localName !== d)
            throw Error("Failed to construct '" + d + "': The constructed element's local name is incorrect.");
          return e;
        } catch (g) {
          return (
            X(g),
            (b = null === f ? n.call(b, d) : p.call(b, f, d)),
            Object.setPrototypeOf(b, HTMLUnknownElement.prototype),
            (b.__CE_state = 2),
            (b.__CE_definition = void 0),
            R(a, b),
            b
          );
        }
      b = null === f ? n.call(b, d) : p.call(b, f, d);
      R(a, b);
      return b;
    }
    function X(a) {
      var b = '',
        d = '',
        f = 0,
        c = 0;
      a instanceof Error
        ? ((b = a.message),
          (d = a.sourceURL || a.fileName || ''),
          (f = a.line || a.lineNumber || 0),
          (c = a.column || a.columnNumber || 0))
        : (b = 'Uncaught ' + String(a));
      var e = void 0;
      void 0 === ErrorEvent.prototype.initErrorEvent
        ? (e = new ErrorEvent('error', { cancelable: true, message: b, filename: d, lineno: f, colno: c, error: a }))
        : ((e = document.createEvent('ErrorEvent')),
          e.initErrorEvent('error', false, true, b, d, f),
          (e.preventDefault = function () {
            Object.defineProperty(this, 'defaultPrevented', {
              configurable: true,
              get: function () {
                return true;
              },
            });
          }));
      void 0 === e.error &&
        Object.defineProperty(e, 'error', {
          configurable: true,
          enumerable: true,
          get: function () {
            return a;
          },
        });
      window.dispatchEvent(e);
      e.defaultPrevented || console.error(a);
    }
    function wa() {
      var a = this;
      this.g = void 0;
      this.F = new Promise(function (b) {
        a.l = b;
      });
    }
    wa.prototype.resolve = function (a) {
      if (this.g) throw Error('Already resolved.');
      this.g = a;
      this.l(a);
    };
    function xa(a) {
      var b = document;
      this.l = void 0;
      this.h = a;
      this.g = b;
      V(this.h, this.g);
      'loading' === this.g.readyState &&
        ((this.l = new MutationObserver(this.G.bind(this))),
        this.l.observe(this.g, { childList: true, subtree: true }));
    }
    function ya(a) {
      a.l && a.l.disconnect();
    }
    xa.prototype.G = function (a) {
      var b = this.g.readyState;
      ('interactive' !== b && 'complete' !== b) || ya(this);
      for (b = 0; b < a.length; b++) for (var d = a[b].addedNodes, f = 0; f < d.length; f++) V(this.h, d[f]);
    };
    function Y(a) {
      this.s = /* @__PURE__ */ new Map();
      this.u = /* @__PURE__ */ new Map();
      this.C = /* @__PURE__ */ new Map();
      this.A = false;
      this.B = /* @__PURE__ */ new Map();
      this.o = function (b) {
        return b();
      };
      this.i = false;
      this.v = [];
      this.h = a;
      this.D = a.I ? new xa(a) : void 0;
    }
    Y.prototype.H = function (a, b) {
      var d = this;
      if (!(b instanceof Function)) throw new TypeError('Custom element constructor getters must be functions.');
      za(this, a);
      this.s.set(a, b);
      this.v.push(a);
      this.i ||
        ((this.i = true),
        this.o(function () {
          return Aa(d);
        }));
    };
    Y.prototype.define = function (a, b) {
      var d = this;
      if (!(b instanceof Function)) throw new TypeError('Custom element constructors must be functions.');
      za(this, a);
      Ba(this, a, b);
      this.v.push(a);
      this.i ||
        ((this.i = true),
        this.o(function () {
          return Aa(d);
        }));
    };
    function za(a, b) {
      if (!ra(b)) throw new SyntaxError("The element name '" + b + "' is not valid.");
      if (W(a, b)) throw Error("A custom element with name '" + (b + "' has already been defined."));
      if (a.A) throw Error('A custom element is already being defined.');
    }
    function Ba(a, b, d) {
      a.A = true;
      var f;
      try {
        var c = d.prototype;
        if (!(c instanceof Object)) throw new TypeError("The custom element constructor's prototype is not an object.");
        var e = function (m) {
          var x = c[m];
          if (void 0 !== x && !(x instanceof Function)) throw Error("The '" + m + "' callback must be a function.");
          return x;
        };
        var g = e('connectedCallback');
        var h = e('disconnectedCallback');
        var k = e('adoptedCallback');
        var l = ((f = e('attributeChangedCallback')) && d.observedAttributes) || [];
      } catch (m) {
        throw m;
      } finally {
        a.A = false;
      }
      d = {
        localName: b,
        constructorFunction: d,
        connectedCallback: g,
        disconnectedCallback: h,
        adoptedCallback: k,
        attributeChangedCallback: f,
        observedAttributes: l,
        constructionStack: [],
      };
      a.u.set(b, d);
      a.C.set(d.constructorFunction, d);
      return d;
    }
    Y.prototype.upgrade = function (a) {
      V(this.h, a);
    };
    function Aa(a) {
      if (false !== a.i) {
        a.i = false;
        for (var b = [], d = a.v, f = /* @__PURE__ */ new Map(), c = 0; c < d.length; c++) f.set(d[c], []);
        V(a.h, document, {
          upgrade: function (k) {
            if (void 0 === k.__CE_state) {
              var l = k.localName,
                m = f.get(l);
              m ? m.push(k) : a.u.has(l) && b.push(k);
            }
          },
        });
        for (c = 0; c < b.length; c++) T(a.h, b[c]);
        for (c = 0; c < d.length; c++) {
          for (var e = d[c], g = f.get(e), h = 0; h < g.length; h++) T(a.h, g[h]);
          (e = a.B.get(e)) && e.resolve(void 0);
        }
        d.length = 0;
      }
    }
    Y.prototype.get = function (a) {
      if ((a = W(this, a))) return a.constructorFunction;
    };
    Y.prototype.whenDefined = function (a) {
      if (!ra(a)) return Promise.reject(new SyntaxError("'" + a + "' is not a valid custom element name."));
      var b = this.B.get(a);
      if (b) return b.F;
      b = new wa();
      this.B.set(a, b);
      var d = this.u.has(a) || this.s.has(a);
      a = -1 === this.v.indexOf(a);
      d && a && b.resolve(void 0);
      return b.F;
    };
    Y.prototype.polyfillWrapFlushCallback = function (a) {
      this.D && ya(this.D);
      var b = this.o;
      this.o = function (d) {
        return a(function () {
          return b(d);
        });
      };
    };
    function W(a, b) {
      var d = a.u.get(b);
      if (d) return d;
      if ((d = a.s.get(b))) {
        a.s.delete(b);
        try {
          return Ba(a, b, d());
        } catch (f) {
          X(f);
        }
      }
    }
    Y.prototype.define = Y.prototype.define;
    Y.prototype.upgrade = Y.prototype.upgrade;
    Y.prototype.get = Y.prototype.get;
    Y.prototype.whenDefined = Y.prototype.whenDefined;
    Y.prototype.polyfillDefineLazy = Y.prototype.H;
    Y.prototype.polyfillWrapFlushCallback = Y.prototype.polyfillWrapFlushCallback;
    function Z(a, b, d) {
      function f(c) {
        return function (e) {
          for (var g = [], h = 0; h < arguments.length; ++h) g[h] = arguments[h];
          h = [];
          for (var k = [], l = 0; l < g.length; l++) {
            var m = g[l];
            m instanceof Element && J(m) && k.push(m);
            if (m instanceof DocumentFragment) for (m = m.firstChild; m; m = m.nextSibling) h.push(m);
            else h.push(m);
          }
          c.apply(this, g);
          for (g = 0; g < k.length; g++) U(a, k[g]);
          if (J(this)) for (g = 0; g < h.length; g++) (k = h[g]), k instanceof Element && S(a, k);
        };
      }
      void 0 !== d.prepend && (b.prepend = f(d.prepend));
      void 0 !== d.append && (b.append = f(d.append));
    }
    function Ca(a) {
      Document.prototype.createElement = function (b) {
        return va(a, this, b, null);
      };
      Document.prototype.importNode = function (b, d) {
        b = aa.call(this, b, !!d);
        this.__CE_registry ? V(a, b) : Q(a, b);
        return b;
      };
      Document.prototype.createElementNS = function (b, d) {
        return va(a, this, d, b);
      };
      Z(a, Document.prototype, { prepend: ba, append: ca });
    }
    function Da(a) {
      function b(f) {
        return function (c) {
          for (var e = [], g = 0; g < arguments.length; ++g) e[g] = arguments[g];
          g = [];
          for (var h = [], k = 0; k < e.length; k++) {
            var l = e[k];
            l instanceof Element && J(l) && h.push(l);
            if (l instanceof DocumentFragment) for (l = l.firstChild; l; l = l.nextSibling) g.push(l);
            else g.push(l);
          }
          f.apply(this, e);
          for (e = 0; e < h.length; e++) U(a, h[e]);
          if (J(this)) for (e = 0; e < g.length; e++) (h = g[e]), h instanceof Element && S(a, h);
        };
      }
      var d = Element.prototype;
      void 0 !== ja && (d.before = b(ja));
      void 0 !== ka && (d.after = b(ka));
      void 0 !== la &&
        (d.replaceWith = function (f) {
          for (var c = [], e = 0; e < arguments.length; ++e) c[e] = arguments[e];
          e = [];
          for (var g = [], h = 0; h < c.length; h++) {
            var k = c[h];
            k instanceof Element && J(k) && g.push(k);
            if (k instanceof DocumentFragment) for (k = k.firstChild; k; k = k.nextSibling) e.push(k);
            else e.push(k);
          }
          h = J(this);
          la.apply(this, c);
          for (c = 0; c < g.length; c++) U(a, g[c]);
          if (h) for (U(a, this), c = 0; c < e.length; c++) (g = e[c]), g instanceof Element && S(a, g);
        });
      void 0 !== ma &&
        (d.remove = function () {
          var f = J(this);
          ma.call(this);
          f && U(a, this);
        });
    }
    function Ea(a) {
      function b(c, e) {
        Object.defineProperty(c, 'innerHTML', {
          enumerable: e.enumerable,
          configurable: true,
          get: e.get,
          set: function (g) {
            var h = this,
              k = void 0;
            J(this) &&
              ((k = []),
              P(a, this, function (x) {
                x !== h && k.push(x);
              }));
            e.set.call(this, g);
            if (k)
              for (var l = 0; l < k.length; l++) {
                var m = k[l];
                1 === m.__CE_state && a.disconnectedCallback(m);
              }
            this.ownerDocument.__CE_registry ? V(a, this) : Q(a, this);
            return g;
          },
        });
      }
      function d(c, e) {
        c.insertAdjacentElement = function (g, h) {
          var k = J(h);
          g = e.call(this, g, h);
          k && U(a, h);
          J(g) && S(a, h);
          return g;
        };
      }
      function f(c, e) {
        function g(h, k) {
          for (var l = []; h !== k; h = h.nextSibling) l.push(h);
          for (k = 0; k < l.length; k++) V(a, l[k]);
        }
        c.insertAdjacentHTML = function (h, k) {
          h = h.toLowerCase();
          if ('beforebegin' === h) {
            var l = this.previousSibling;
            e.call(this, h, k);
            g(l || this.parentNode.firstChild, this);
          } else if ('afterbegin' === h) (l = this.firstChild), e.call(this, h, k), g(this.firstChild, l);
          else if ('beforeend' === h) (l = this.lastChild), e.call(this, h, k), g(l || this.firstChild, null);
          else if ('afterend' === h) (l = this.nextSibling), e.call(this, h, k), g(this.nextSibling, l);
          else
            throw new SyntaxError(
              'The value provided (' +
                String(h) +
                ") is not one of 'beforebegin', 'afterbegin', 'beforeend', or 'afterend'.",
            );
        };
      }
      y &&
        (Element.prototype.attachShadow = function (c) {
          c = y.call(this, c);
          if (a.j && !c.__CE_patched) {
            c.__CE_patched = true;
            for (var e = 0; e < a.m.length; e++) a.m[e](c);
          }
          return (this.__CE_shadowRoot = c);
        });
      z && z.get
        ? b(Element.prototype, z)
        : I && I.get
        ? b(HTMLElement.prototype, I)
        : ua(a, function (c) {
            b(c, {
              enumerable: true,
              configurable: true,
              get: function () {
                return q.call(this, true).innerHTML;
              },
              set: function (e) {
                var g = 'template' === this.localName,
                  h = g ? this.content : this,
                  k = p.call(document, this.namespaceURI, this.localName);
                for (k.innerHTML = e; 0 < h.childNodes.length; ) u.call(h, h.childNodes[0]);
                for (e = g ? k.content : k; 0 < e.childNodes.length; ) r.call(h, e.childNodes[0]);
              },
            });
          });
      Element.prototype.setAttribute = function (c, e) {
        if (1 !== this.__CE_state) return B.call(this, c, e);
        var g = A.call(this, c);
        B.call(this, c, e);
        e = A.call(this, c);
        a.attributeChangedCallback(this, c, g, e, null);
      };
      Element.prototype.setAttributeNS = function (c, e, g) {
        if (1 !== this.__CE_state) return F.call(this, c, e, g);
        var h = E.call(this, c, e);
        F.call(this, c, e, g);
        g = E.call(this, c, e);
        a.attributeChangedCallback(this, e, h, g, c);
      };
      Element.prototype.removeAttribute = function (c) {
        if (1 !== this.__CE_state) return C.call(this, c);
        var e = A.call(this, c);
        C.call(this, c);
        null !== e && a.attributeChangedCallback(this, c, e, null, null);
      };
      D &&
        (Element.prototype.toggleAttribute = function (c, e) {
          if (1 !== this.__CE_state) return D.call(this, c, e);
          var g = A.call(this, c),
            h = null !== g;
          e = D.call(this, c, e);
          h !== e && a.attributeChangedCallback(this, c, g, e ? '' : null, null);
          return e;
        });
      Element.prototype.removeAttributeNS = function (c, e) {
        if (1 !== this.__CE_state) return G.call(this, c, e);
        var g = E.call(this, c, e);
        G.call(this, c, e);
        var h = E.call(this, c, e);
        g !== h && a.attributeChangedCallback(this, e, g, h, c);
      };
      oa ? d(HTMLElement.prototype, oa) : H && d(Element.prototype, H);
      pa ? f(HTMLElement.prototype, pa) : fa && f(Element.prototype, fa);
      Z(a, Element.prototype, { prepend: ha, append: ia });
      Da(a);
    }
    var Fa = {};
    function Ga(a) {
      function b() {
        var d = this.constructor;
        var f = document.__CE_registry.C.get(d);
        if (!f)
          throw Error(
            'Failed to construct a custom element: The constructor was not registered with `customElements`.',
          );
        var c = f.constructionStack;
        if (0 === c.length)
          return (
            (c = n.call(document, f.localName)),
            Object.setPrototypeOf(c, d.prototype),
            (c.__CE_state = 1),
            (c.__CE_definition = f),
            R(a, c),
            c
          );
        var e = c.length - 1,
          g = c[e];
        if (g === Fa) throw Error("Failed to construct '" + f.localName + "': This element was already constructed.");
        c[e] = Fa;
        Object.setPrototypeOf(g, d.prototype);
        R(a, g);
        return g;
      }
      b.prototype = na.prototype;
      Object.defineProperty(HTMLElement.prototype, 'constructor', {
        writable: true,
        configurable: true,
        enumerable: false,
        value: b,
      });
      window.HTMLElement = b;
    }
    function Ha(a) {
      function b(d, f) {
        Object.defineProperty(d, 'textContent', {
          enumerable: f.enumerable,
          configurable: true,
          get: f.get,
          set: function (c) {
            if (this.nodeType === Node.TEXT_NODE) f.set.call(this, c);
            else {
              var e = void 0;
              if (this.firstChild) {
                var g = this.childNodes,
                  h = g.length;
                if (0 < h && J(this)) {
                  e = Array(h);
                  for (var k = 0; k < h; k++) e[k] = g[k];
                }
              }
              f.set.call(this, c);
              if (e) for (c = 0; c < e.length; c++) U(a, e[c]);
            }
          },
        });
      }
      Node.prototype.insertBefore = function (d, f) {
        if (d instanceof DocumentFragment) {
          var c = K(d);
          d = t.call(this, d, f);
          if (J(this)) for (f = 0; f < c.length; f++) S(a, c[f]);
          return d;
        }
        c = d instanceof Element && J(d);
        f = t.call(this, d, f);
        c && U(a, d);
        J(this) && S(a, d);
        return f;
      };
      Node.prototype.appendChild = function (d) {
        if (d instanceof DocumentFragment) {
          var f = K(d);
          d = r.call(this, d);
          if (J(this)) for (var c = 0; c < f.length; c++) S(a, f[c]);
          return d;
        }
        f = d instanceof Element && J(d);
        c = r.call(this, d);
        f && U(a, d);
        J(this) && S(a, d);
        return c;
      };
      Node.prototype.cloneNode = function (d) {
        d = q.call(this, !!d);
        this.ownerDocument.__CE_registry ? V(a, d) : Q(a, d);
        return d;
      };
      Node.prototype.removeChild = function (d) {
        var f = d instanceof Element && J(d),
          c = u.call(this, d);
        f && U(a, d);
        return c;
      };
      Node.prototype.replaceChild = function (d, f) {
        if (d instanceof DocumentFragment) {
          var c = K(d);
          d = v.call(this, d, f);
          if (J(this)) for (U(a, f), f = 0; f < c.length; f++) S(a, c[f]);
          return d;
        }
        c = d instanceof Element && J(d);
        var e = v.call(this, d, f),
          g = J(this);
        g && U(a, f);
        c && U(a, d);
        g && S(a, d);
        return e;
      };
      w && w.get
        ? b(Node.prototype, w)
        : ta(a, function (d) {
            b(d, {
              enumerable: true,
              configurable: true,
              get: function () {
                for (var f = [], c = this.firstChild; c; c = c.nextSibling)
                  c.nodeType !== Node.COMMENT_NODE && f.push(c.textContent);
                return f.join('');
              },
              set: function (f) {
                for (; this.firstChild; ) u.call(this, this.firstChild);
                null != f && '' !== f && r.call(this, document.createTextNode(f));
              },
            });
          });
    }
    var O = window.customElements;
    function Ia() {
      var a = new N();
      Ga(a);
      Ca(a);
      Z(a, DocumentFragment.prototype, { prepend: da, append: ea });
      Ha(a);
      Ea(a);
      window.CustomElementRegistry = Y;
      a = new Y(a);
      document.__CE_registry = a;
      Object.defineProperty(window, 'customElements', { configurable: true, enumerable: true, value: a });
    }
    (O && !O.forcePolyfill && 'function' == typeof O.define && 'function' == typeof O.get) || Ia();
    window.__CE_installPolyfill = Ia;
  }.call(self));
  class DebugToolbar extends HTMLElement {
    constructor() {
      super();
      __publicField(this, 'data', {});
      this.attachShadow({ mode: 'open' });
      this.render();
    }
    connectedCallback() {
      logger.info('DebugToolbar connected to the DOM.');
    }
    set dataProps(data) {
      this.data = data;
      this.render();
    }
    render() {
      if (this.shadowRoot) {
        if (!this.shadowRoot.querySelector('.toolbar-header')) {
          this.shadowRoot.innerHTML =
            /*html*/
            `
          <style>
            .toolbar-header {
              font-weight: bold;
              margin-bottom: 10px;
              text-align: center;
            }

            .positioner {
              position: fixed;
              bottom: 0;
              right: 0;

              max-height: 50vh;
              z-index: 1000;
              margin: 8px;
            }

            .container {
              background-color: white;
              color: black;
              max-width: 158px;
              padding: 25px;
              font-family: Arial, sans-serif;
              font-size: 13px;
              border-radius: 22px;
            }

            .shadow {
              --vibrance: 50%;
              content: " ";
              position: absolute;
              inset: 10px 10px -10px;
              background: linear-gradient(to right in oklch longer hue, oklch(95% var(--vibrance) 0) 0 100%);
              filter: blur(20px);
              border-radius: inherit;
              z-index: -1;
            }

          </style>

          <div class="positioner">
            <div class="container">
              <div class="toolbar-header">Debug Toolbar</div>
              <div class="toolbar-content"></div>
            </div>
            <div class='shadow'></div>
          </div>
        `;
        }
        const contentContainer = this.shadowRoot.querySelector('.toolbar-content');
        if (contentContainer) {
          contentContainer.innerHTML = Object.entries(this.data)
            .map(([key, value]) => `<div><strong>${key}:</strong> ${value?.toString()}</div>`)
            .join('');
        }
      } else {
        logger.error('Shadow DOM is not available.');
      }
    }
  }
  const createDebugToolbar = () => {
    window.customElements.define('debug-toolbar', DebugToolbar);
    const toolbar = document.createElement('debug-toolbar');
    return toolbar;
  };
  const launchDebugToolbar = ({ getToolbarData, interval = 1e3 }) => {
    if (!config.options.debug) {
      return;
    }
    const existingToolbar = document.querySelector('debug-toolbar');
    if (existingToolbar) {
      logger.info('Debug toolbar already exists, skipping initialization.');
      return;
    }
    const toolbar = createDebugToolbar();
    logger.info('Debug toolbar imported');
    document.body.appendChild(toolbar);
    setInterval(() => {
      try {
        logger.info('Refreshing debug toolbar data');
        toolbar.dataProps = getToolbarData();
      } catch (error) {
        toolbar.dataProps = {
          error: 'Error getting data',
          errorMessage: error.message,
        };
      }
    }, interval);
  };
  const removeStickyContainer = () => {
    const floatingContainer = document.querySelector('#hermes-floating-container');
    if (!floatingContainer) {
      return;
    }
    floatingContainer.remove();
  };
  class AccommodationPageAdapter extends SiteAdapter {
    constructor(hotelIdProvider) {
      super(hotelIdProvider);
      __publicField(this, 'hotelName');
      __publicField(this, 'hotelId');
      __publicField(this, 'usedHotelIdsInSearch', false);
      void this.initializeAdapter();
    }
    async initializeAdapter() {
      try {
        await this.initializeSiteAdapterRequiredProperties();
        const hotelName = await this.getHotelNameFromContent();
        if (hotelName === null || hotelName === void 0) {
          throw new Error('No hotel name found');
        }
        this.hotelName = hotelName;
        const hotelId = await this.getHotelIdFromContent();
        this.hotelId = hotelId;
        await this.createUI();
        void this.populateUIWithData();
        if (false);
      } catch (error) {
        logger.error('Error initializing adapter:', error);
        this.removeUI();
      }
    }
    updateStickyButton(params) {
      updateStickyButton(params);
    }
    getToolbarProps() {
      return {
        checkIn: this.checkIn,
        checkOut: this.checkOut,
        adults: this.adults,
        children: this.children,
        country: this.country,
        city: this.city,
        rooms: this.rooms,
        roomsConfiguration: this.roomsConfiguration,
        childrenAges: this.childrenAges,
        currency: this.currency,
      };
    }
    async createUI() {
      try {
        createStickyButton();
        createTableButton();
        logger.info('UI created successfully');
        return Promise.resolve();
      } catch (error) {
        const errorMessage = error instanceof Error ? error.message : String(error);
        logger.warn('Error creating UI:', errorMessage);
        throw error;
      }
    }
    getAdultsFromContent() {
      return showNotImplementedMessageAsync('getAdultsFromContent');
    }
    getCheckInDateFromContent() {
      return showNotImplementedMessageAsync('getCheckInDateFromContent');
    }
    getCheckOutDateFromContent() {
      return showNotImplementedMessageAsync('getCheckOutDateFromContent');
    }
    getChildrenAgesFromContent() {
      return showNotImplementedMessageAsync('getChildrenAgesFromContent');
    }
    getChildrenFromContent() {
      return showNotImplementedMessageAsync('getChildrenFromContent');
    }
    getCityFromContent() {
      return showNotImplementedMessageAsync('getCityFromContent');
    }
    getCountryFromContent() {
      return showNotImplementedMessageAsync('getCountryFromContent');
    }
    getCurrencyFromContent() {
      return showNotImplementedMessageAsync('getCurrencyFromContent');
    }
    getRoomsFromContent() {
      return showNotImplementedMessageAsync('getRoomsFromContent');
    }
    pickHotelFromResponse(hotelDataResponse) {
      try {
        const foundHotel = hotelDataResponse.hotels?.filter(hotel => {
          const hasOffers = hotel.offers?.length > 0;
          const matchesById = hotel.id === this.hotelId;
          const matchesByName = hotel.requestedName === this.hotelName;
          const hasDetails = !!hotel.details;
          return hasOffers && (matchesById || matchesByName) && hasDetails;
        });
        const result = foundHotel?.at(0);
        if (result) {
          logger.info('Hotel found in response:', { hotelId: result.id, hotelName: result.requestedName });
        } else {
          const errorMessage = `No matching hotel found in response}`;
          logger.warn(errorMessage);
          throw new Error(errorMessage);
        }
        return result;
      } catch (error) {
        const errorMessage = error instanceof Error ? error.message : String(error);
        throw new Error(errorMessage);
      }
    }
    removeUI() {
      removeStickyButton();
      destroyTableButton();
      removeStickyContainer();
    }
    async updateUI({ isBestOffer, pluginViewData, price, inlineButtonTrackingContext }) {
      try {
        this.updateStickyButton({
          bestOfferPrice: price,
          isBestOffer,
          currency: this.currency,
          trackingContext: inlineButtonTrackingContext,
        });
        updateTableButton({
          bestOfferPrice: price,
          isBestOffer,
          currency: this.currency,
          trackingContext: inlineButtonTrackingContext,
        });
        updatePopup(pluginViewData);
        logger.info('UI updated successfully');
        return Promise.resolve();
      } catch (error) {
        const errorMessage = error instanceof Error ? error.message : String(error);
        logger.warn('Error updating UI:', errorMessage);
        throw error;
      }
    }
    async updateUIWithData(hotelDataResponse) {
      try {
        const priceDisplayStrategy = this.getPriceDisplayStrategy();
        const foundHotel = this.pickHotelFromResponse(hotelDataResponse);
        if (!foundHotel) {
          throw new Error(`Can't find hotel in response or required data is missing`);
        }
        logger.success('Found hotel:', foundHotel);
        const { charges, price } = await this.getCheapestRoomPriceFromContent();
        logger.info(`Cheapest room combination: charges=${charges}, price=${price}`);
        const nights = getDateDiffInDays(new Date(this.checkIn), new Date(this.checkOut));
        const { isBestOffer, bestDisplayPrice, priceDifference } = getIsBestOffer({
          offers: foundHotel.offers,
          currentPrice: price,
          currentCharges: charges,
          priceDisplayStrategy,
          roomsCount: this.rooms ?? 1,
          // if rooms aren't optimized, prices we get in offers are per room, not per stay
          multiplyPriceByRoomsCount: !this.shouldOptimizeRooms,
          nights,
        });
        logger.info(`Is best offer=${isBestOffer}`, foundHotel);
        const { details, offers } = foundHotel;
        const { name, starRating, images } = details;
        const { checkIn, checkOut } = hotelDataResponse.stay;
        const roomsConfig = foundHotel?.roomsConfig || this.roomsConfiguration;
        const roomsAmount = roomsConfig?.split('|')?.length ?? 1;
        const currentProvider = getCurrentProvider();
        const offersWithoutCurrentProvider = offers.filter(offer => offer.provider.name !== currentProvider);
        const { bestOffer, sortedOffers } = parseOffersForModalList({
          offers: offersWithoutCurrentProvider,
          priceDisplayStrategy,
          roomsCount: this.rooms ?? 1,
          // if rooms aren't optimized, prices we get in offers are per room, not per stay
          multiplyPriceByRoomsCount: !this.shouldOptimizeRooms,
          nights,
        });
        const pluginViewData = {
          priceDifference,
          currency: this.currency,
          checkIn,
          checkOut,
          stars: starRating ?? 0,
          img: images?.[0] || '',
          hotelName: name,
          children: this.children,
          adults: this.adults,
          roomsAmount,
          roomName: bestOffer.roomName,
          bookingPrice: price,
          bookingTax: charges,
          bestPrice: bestOffer.displayPrice,
          bestOfferUrl: bestOffer.url,
          offers: sortedOffers,
          bestRate: bestOffer.rate,
          priceDisplayStrategy,
          isBestOffer,
        };
        const inlineButtonOfferContext = {
          providerName: bestOffer.provider.name,
          displayPriceType: priceDisplayStrategy,
          displayPrice: bestOffer.displayPrice,
          anchorPrice: price,
          currency: this.currency,
          isBetterOffer: isBestOffer,
          rateBreakdown: bestOffer.rate,
        };
        const inlineButtonHotelContext = {
          hotelId: foundHotel.id,
          hotelIdsProvider: this.usedHotelIdsInSearch ? HOTEL_ID_PROVIDERS[this.hotelIdProvider] ?? void 0 : void 0,
        };
        const inlineButtonTrackingContext = {
          offerContext: inlineButtonOfferContext,
          hotelContext: inlineButtonHotelContext,
        };
        await this.updateUI({
          isBestOffer,
          pluginViewData,
          price: bestDisplayPrice,
          inlineButtonTrackingContext,
        });
        logger.info('UI updated with hotel data successfully');
      } catch (error) {
        const errorMessage = error instanceof Error ? error.message : String(error);
        logger.warn('Error updating UI with hotel data:', errorMessage);
        throw error;
      }
    }
    prepareQuery() {
      try {
        if (this.hotelId == null || this.hotelId.trim().length === 0) {
          this.usedHotelIdsInSearch = false;
          logger.info('Preparing query with hotel names', {
            hotelName: this.hotelName,
            country: this.country,
            city: this.city,
          });
          return {
            hotelNames: {
              names: [this.hotelName],
              country: this.country,
              city: this.city,
            },
          };
        }
        this.usedHotelIdsInSearch = true;
        logger.info('Preparing query with hotel IDs', { hotelId: this.hotelId, provider: this.hotelIdProvider });
        return {
          hotelIds: [this.hotelId],
          hotelIdsProvider: HOTEL_ID_PROVIDERS[this.hotelIdProvider],
        };
      } catch (error) {
        const errorMessage = error instanceof Error ? error.message : String(error);
        logger.warn('Error preparing query:', errorMessage);
        throw error;
      }
    }
    async populateUIWithData() {
      try {
        const query = this.prepareQuery();
        const hotelDataResponse = await this.fetchHotelData(query);
        logger.api('API Search response', hotelDataResponse);
        if ('error' in hotelDataResponse) {
          throw new Error('Error in hotel data response');
        }
        if (!hotelDataResponse.hotels) {
          throw new Error('Data in API response incomplete: no hotels');
        }
        if (!hotelDataResponse.stay) {
          throw new Error('Data in API response incomplete: no stay');
        }
        await this.updateUIWithData(hotelDataResponse);
        logger.info('UI populated with data successfully');
      } catch (error) {
        const errorMessage = error instanceof Error ? error.message : String(error);
        logger.error('Error populating UI with data:', errorMessage);
        logger.info('Removing all UI due to error');
        this.removeUI();
      }
    }
  }
  const getPriceDisplayStrategy = roomElement => {
    const parentElement = roomElement || document;
    const perNightPrice = parentElement
      .querySelector(SELECTORS.booking.accommodationPage.table.priceCell)
      ?.querySelector(SELECTORS.booking.accommodationPage.table.room.perNightPrice);
    if (perNightPrice) {
      return 'BASE_PER_NIGHT';
    }
    const taxInfoBlock = document.querySelector(SELECTORS.booking.accommodationPage.taxInfo);
    if (taxInfoBlock) {
      return 'BASE_ONLY';
    }
    const taxesAndFeesUnderPrice = document.querySelector(SELECTORS.booking.accommodationPage.taxAndFeesUnderPrice);
    if (!taxesAndFeesUnderPrice) {
      return 'BASE_ONLY';
    }
    const dataExclChargesRaw = taxesAndFeesUnderPrice.getAttribute(
      SELECTORS.booking.accommodationPage.excludingChargesAttribute,
    );
    if (dataExclChargesRaw) {
      return 'BASE_WITH_CHARGES_ON_SIDE';
    }
    return 'ALL_INCLUSIVE';
  };
  const formatDateForAPI = date => {
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const day = String(date.getDate()).padStart(2, '0');
    const dateString = `${year}-${month}-${day}`;
    return dateString;
  };
  function getBookingSearchContextFromUrl() {
    logger.info('starting getSearchContextFromUrl');
    const urlParams = new URLSearchParams(window.location.search);
    const checkInParam = urlParams.get('checkin');
    const checkOutParam = urlParams.get('checkout');
    const checkIn = checkInParam ? new Date(checkInParam) : null;
    const checkOut = checkOutParam ? new Date(checkOutParam) : null;
    let checkInDate;
    let checkOutDate;
    if (checkIn) {
      checkInDate = formatDateForAPI(checkIn);
    }
    if (checkOut) {
      checkOutDate = formatDateForAPI(checkOut);
    }
    const adultsCountParam = urlParams.get(SELECTORS.booking.common.urlParams.adultsAmount);
    const childrenCountParam = urlParams.get(SELECTORS.booking.common.urlParams.childrenAmount);
    const numberOfRoomsParam = urlParams.get(SELECTORS.booking.common.urlParams.numberOfRooms);
    const adultsCount = adultsCountParam ? Number(adultsCountParam) : void 0;
    const childrenCount = childrenCountParam ? Number(childrenCountParam) : void 0;
    const numberOfRooms = numberOfRoomsParam ? Number(numberOfRoomsParam) : void 0;
    const childrenAgesArray = urlParams
      .getAll(SELECTORS.booking.common.urlParams.childrenArray)
      .map(age => Number(age));
    const childrenArrayIsInvalid = childrenAgesArray.some(isNaN);
    const adultsCountIsInvalid = isNaN(Number(adultsCount));
    const childrenCountIsInvalid = isNaN(Number(childrenCount));
    const roomsCountIsInvalid = isNaN(Number(numberOfRooms));
    if (childrenArrayIsInvalid) {
      logger.warn('Children ages array contains NaN:', childrenAgesArray);
    }
    return {
      checkInDate,
      checkOutDate,
      numberOfAdults: adultsCountIsInvalid ? void 0 : adultsCount,
      numberOfChildren: childrenCountIsInvalid ? void 0 : childrenCount,
      numberOfRooms: roomsCountIsInvalid ? void 0 : numberOfRooms,
      childrenAges: childrenArrayIsInvalid ? void 0 : childrenAgesArray,
    };
  }
  const ENGLISH_MONTH_NAMES = [
    'January',
    'February',
    'March',
    'April',
    'May',
    'June',
    'July',
    'August',
    'September',
    'October',
    'November',
    'December',
  ];
  const ENGLISH_MONTH_ABBREVIATIONS = [
    'Jan',
    'Feb',
    'Mar',
    'Apr',
    'May',
    'Jun',
    'Jul',
    'Aug',
    'Sep',
    'Oct',
    'Nov',
    'Dec',
  ];
  const FRENCH_MONTH_NAMES = [
    'janvier',
    'février',
    'mars',
    'avril',
    'mai',
    'juin',
    'juillet',
    'août',
    'septembre',
    'octobre',
    'novembre',
    'décembre',
  ];
  const FRENCH_MONTH_ABBREVIATIONS = [
    'janv',
    'févr',
    'mars',
    'avr',
    'mai',
    'juin',
    'juill',
    'août',
    'sept',
    'oct',
    'nov',
    'déc',
  ];
  const ENGLISH_MONTH_PATTERN = `(?:${ENGLISH_MONTH_NAMES.join('|')}|${ENGLISH_MONTH_ABBREVIATIONS.map(
    m => `${m}\\.?`,
  ).join('|')})`;
  const FRENCH_MONTH_PATTERN = `(?:${FRENCH_MONTH_NAMES.join('|')}|${FRENCH_MONTH_ABBREVIATIONS.map(
    m => `${m}\\.?`,
  ).join('|')})`;
  const createDatePatterns = monthPattern => [
    // Day Month Year
    new RegExp(`(?<=.*?)(?<day>\\d{1,2})\\s+(?<month>${monthPattern})(?:,\\s*|\\s+)(?<year>\\d{4})`, 'i'),
    // Month Day Year
    new RegExp(`(?<=.*?)(?<month>${monthPattern})\\s+(?<day>\\d{1,2})(?:,\\s*|\\s+)(?<year>\\d{4})`, 'i'),
    // Day Month
    new RegExp(`(?<=.*?)(?<day>\\d{1,2})\\s+(?<month>${monthPattern})`, 'i'),
    // Month Day
    new RegExp(`(?<=.*?)(?<month>${monthPattern})\\s+(?<day>\\d{1,2})`, 'i'),
  ];
  const ENGLISH_DATE_PATTERNS = createDatePatterns(ENGLISH_MONTH_PATTERN);
  const FRENCH_DATE_PATTERNS = createDatePatterns(FRENCH_MONTH_PATTERN);
  const FRENCH_TO_ENGLISH_MONTH_MAPPING = {
    // Full month names
    janvier: 'January',
    février: 'February',
    mars: 'March',
    avril: 'April',
    mai: 'May',
    juin: 'June',
    juillet: 'July',
    août: 'August',
    septembre: 'September',
    octobre: 'October',
    novembre: 'November',
    décembre: 'December',
    // Abbreviated month names (excluding full month duplicates)
    janv: 'Jan',
    févr: 'Feb',
    avr: 'Apr',
    juill: 'Jul',
    sept: 'Sep',
    oct: 'Oct',
    nov: 'Nov',
    déc: 'Dec',
  };
  const convertFrenchMonthToEnglish = monthName => {
    return FRENCH_TO_ENGLISH_MONTH_MAPPING[monthName] || monthName;
  };
  const extractDateWithPatterns = (dateText, patterns) => {
    for (const pattern of patterns) {
      const match = dateText.match(pattern);
      if (match && match.groups) {
        const { day, month, year } = match.groups;
        const trimmedMonth = month.replace(/\.$/, '');
        return {
          day,
          month: trimmedMonth,
          year,
        };
      }
    }
    return null;
  };
  const extractEnglishDate = dateText => {
    return extractDateWithPatterns(dateText, ENGLISH_DATE_PATTERNS);
  };
  const extractFrenchDate = dateText => {
    const extractedDate = extractDateWithPatterns(dateText, FRENCH_DATE_PATTERNS);
    if (!extractedDate) {
      return null;
    }
    const translatedMonth = convertFrenchMonthToEnglish(extractedDate.month);
    return {
      day: extractedDate.day,
      month: translatedMonth,
      year: extractedDate.year,
    };
  };
  const parseExtractedDateWithYearLogic = extractedDate => {
    const currentDate = /* @__PURE__ */ new Date();
    const currentYear = currentDate.getFullYear();
    const { day, month, year } = extractedDate;
    const dateString = year ? `${day} ${month} ${year}` : `${day} ${month}`;
    const hasYear = !!year;
    let parsedDate;
    if (hasYear) {
      parsedDate = new Date(dateString);
    } else {
      parsedDate = /* @__PURE__ */ new Date(`${dateString} ${currentYear}`);
    }
    const today = new Date(currentDate);
    today.setHours(0, 0, 0, 0);
    const yesterday = new Date(currentDate);
    yesterday.setDate(yesterday.getDate() - 1);
    yesterday.setHours(0, 0, 0, 0);
    const parsedDateOnly = new Date(parsedDate);
    parsedDateOnly.setHours(0, 0, 0, 0);
    const isToday = parsedDateOnly.getTime() === today.getTime();
    const isYesterday = parsedDateOnly.getTime() === yesterday.getTime();
    if (!hasYear && parsedDateOnly.getTime() < today.getTime() && !isToday && !isYesterday) {
      parsedDate = /* @__PURE__ */ new Date(`${dateString} ${currentYear + 1}`);
    }
    return formatDateForAPI(parsedDate);
  };
  const parseFormattedDate = dateText => {
    const extractedDate = extractFrenchDate(dateText) || extractEnglishDate(dateText);
    if (extractedDate) {
      return parseExtractedDateWithYearLogic(extractedDate);
    }
    return null;
  };
  const querySelectorAsync = async (selector, timeout) => {
    return new Promise((resolve, reject) => {
      logger.selector(`Waiting for element: ${selector}`);
      const element = document.querySelector(selector);
      if (element) {
        logger.selector(`(querySelectorAsync) Element found immediately: ${selector}`, element);
        resolve(element);
        return;
      }
      const observer = new MutationObserver(() => {
        const element2 = document.querySelector(selector);
        if (element2) {
          logger.selector(`(querySelectorAsync) Element found via MutationObserver: ${selector}`, element2);
          observer.disconnect();
          resolve(element2);
        }
      });
      observer.observe(document.body, { childList: true, subtree: true });
      if (timeout != null) {
        setTimeout(() => {
          logger.selector(`(querySelectorAsync) Timeout reached for element: ${selector}, timeout: ${timeout}ms`);
          observer.disconnect();
          return reject(new Error(`Timeout waiting for element: ${selector}`));
        }, timeout);
      }
    });
  };
  const getCheckInDateFromContent$1 = async () => {
    try {
      const checkInDateElement = await querySelectorAsync(
        SELECTORS.booking.common.checkInDate,
        DEFAULT_SELECTOR_TIMEOUT,
      );
      const checkInDateText = checkInDateElement?.textContent?.trim() || '';
      if (!checkInDateText || checkInDateText?.length === 0) {
        logger.warn('Check-in date from page content is empty');
        return null;
      }
      const checkInDate = parseFormattedDate(checkInDateText);
      return checkInDate;
    } catch (error) {
      logger.warn(
        `(getCheckInDateFromContent) Error extracting check-in date: ${
          error instanceof Error ? error.message : String(error)
        }`,
      );
      return null;
    }
  };
  const getCheckOutDateFromContent$1 = async () => {
    try {
      const checkOutDateElement = await querySelectorAsync(
        SELECTORS.booking.common.checkOutDate,
        DEFAULT_SELECTOR_TIMEOUT,
      );
      const checkOutDateText = checkOutDateElement?.textContent?.trim() || '';
      if (!checkOutDateText || checkOutDateText?.length === 0) {
        logger.warn('Check-out date from page content is empty');
        return null;
      }
      const checkOutDate = parseFormattedDate(checkOutDateText);
      return checkOutDate;
    } catch (error) {
      logger.warn(
        `(getCheckOutDateFromContent) Error extracting check-out date: ${
          error instanceof Error ? error.message : String(error)
        }`,
      );
      return null;
    }
  };
  const PROPERTY_CURRENCIES = '€$£';
  const getCurrencyFromHeader = async () => {
    try {
      const currency = await querySelectorAsync(SELECTORS.booking.common.header.currency, DEFAULT_SELECTOR_TIMEOUT);
      const currencyText = currency?.textContent;
      if (currencyText === PROPERTY_CURRENCIES) {
        return null;
      }
      return currencyText || null;
    } catch (error) {
      logger.warn('(getCurrencyFromHeader) Error extracting currency:', error);
      return null;
    }
  };
  const createCardButton = (args = {}) => {
    const wrapper = document.createElement('div');
    wrapper.classList.add('hermes-search-result-badge-wrapper');
    wrapper.addEventListener('click', event => {
      event.stopImmediatePropagation();
      event.stopPropagation();
    });
    const buttonContainer = document.createElement('div');
    buttonContainer.classList.add('hermes-button-container');
    const currentDomainWithoutTLD = getCurrentDomainNameWithoutTLD();
    buttonContainer.classList.add(currentDomainWithoutTLD);
    const buttonShadow = document.createElement('div');
    buttonShadow.classList.add('hermes-button-common-shadow');
    buttonContainer.appendChild(buttonShadow);
    const searchResultBadge = document.createElement('button');
    searchResultBadge.classList.add('hermes-button-common');
    searchResultBadge.classList.add('hermes-search-result-badge');
    searchResultBadge.setAttribute('visible', 'true');
    searchResultBadge.classList.add('loading');
    searchResultBadge.setAttribute('type', 'button');
    searchResultBadge.innerHTML = theme.buttonIcon;
    if (args.badgeId) {
      searchResultBadge.setAttribute(ELEMENTS_ATTRIBUTES.BADGE_ID, args.badgeId);
    }
    const textContainer = document.createElement('div');
    textContainer.classList.add('textContainer');
    textContainer.textContent = formatMessage('checkingDeals', 'Checking deals');
    searchResultBadge.appendChild(textContainer);
    buttonContainer.appendChild(searchResultBadge);
    wrapper.appendChild(buttonContainer);
    const detailsContainer = document.createElement('div');
    wrapper.classList.add('with-details');
    detailsContainer.classList.add('hermes-button-details');
    buttonContainer.appendChild(detailsContainer);
    return wrapper;
  };
  const removeCardButton = parent => {
    const badge = parent.querySelector('.hermes-search-result-badge-wrapper');
    if (!badge) {
      return;
    }
    badge.dataset.skipRestore = 'true';
    badge.remove();
  };
  const getCurrencyFromPriceText = priceText => {
    const currency = priceText.replace(/[0-9\s.,\u202F]/g, '');
    return currency;
  };
  const CURRENCY_SYMBOLS = {
    AED: ['AED'],
    ARS: ['ARS', 'AR$'],
    AUD: ['AUD'],
    AZN: ['AZN'],
    BGN: ['BGN'],
    BHD: ['BHD'],
    BRL: ['BRL', 'R$'],
    CAD: ['CAD'],
    CHF: ['CHF'],
    CLP: ['CLP', 'CL$'],
    CNY: ['CNY', '元'],
    COP: ['COP'],
    CZK: ['CZK', 'Kč'],
    DKK: ['DKK'],
    EGP: ['EGP'],
    EUR: ['EUR', '€'],
    FJD: ['FJD'],
    GBP: ['GBP', '£'],
    GEL: ['GEL'],
    HKD: ['HKD', 'HK$'],
    HUF: ['HUF'],
    IDR: ['IDR', 'Rp'],
    ILS: ['ILS', '₪'],
    INR: ['INR', 'Rs', '₹'],
    ISK: ['ISK'],
    JOD: ['JOD'],
    JPY: ['JPY', '¥'],
    KRW: ['KRW', '₩'],
    KWD: ['KWD', 'دك'],
    KZT: ['KZT'],
    MDL: ['MDL'],
    MOP: ['MOP'],
    MXN: ['MXN'],
    MYR: ['MYR'],
    NAD: ['NAD'],
    NOK: ['NOK'],
    NZD: ['NZD'],
    OMR: ['OMR'],
    PLN: ['PLN', 'zł'],
    QAR: ['QAR'],
    RON: ['RON', 'lei'],
    RUB: ['RUB', 'руб'],
    SAR: ['SAR'],
    SEK: ['SEK'],
    SGD: ['SGD', 'S$'],
    THB: ['THB'],
    TRY: ['TRY', 'TL'],
    TWD: ['TWD'],
    UAH: ['UAH'],
    USD: ['USD', 'US$', '$'],
    XOF: ['XOF'],
    ZAR: ['ZAR'],
  };
  const getStandardizedCurrency = localizedCurrency => {
    if (!localizedCurrency) {
      return null;
    }
    const standardizedCurrency = Object.entries(CURRENCY_SYMBOLS).find(([, symbols]) =>
      symbols.includes(localizedCurrency),
    )?.[0];
    if (!standardizedCurrency) {
      return null;
    }
    return standardizedCurrency;
  };
  const getCurrencyFromPriceCell = async () => {
    try {
      const priceCell = await querySelectorAsync(
        SELECTORS.booking.accommodationPage.table.room.priceContainer,
        DEFAULT_SELECTOR_TIMEOUT,
      );
      const priceText = priceCell?.innerText;
      if (!priceText) {
        return null;
      }
      const currency = getCurrencyFromPriceText(priceText);
      return getStandardizedCurrency(currency);
    } catch (error) {
      logger.warn('(getCurrencyFromPriceCell) Error extracting currency:', error);
      return null;
    }
  };
  const findCheapestRoomCombination = (rooms, adultsNeeded, childrenNeeded) => {
    const validCombinations = [];
    function findCombination(index, remainingAdults, remainingChildren, selectedRooms, totalPrice, usedRoomsLeft) {
      if (remainingAdults <= 0 && (remainingChildren <= 0 || remainingAdults + remainingChildren <= 0)) {
        validCombinations.push({ rooms: selectedRooms, totalPrice });
        return;
      }
      if (index >= rooms.length) {
        return;
      }
      const room = rooms[index];
      const maxCanBook =
        room.roomsLeft === null || room.roomsLeft === void 0
          ? room.roomsAmount
          : Math.min(room.roomsAmount, Math.max(0, room.roomsLeft - (usedRoomsLeft[room.id] || 0)));
      for (let i = 0; i <= maxCanBook; i++) {
        const newSelectedRooms = [...selectedRooms];
        if (i > 0) {
          newSelectedRooms.push({ ...room, count: i });
        }
        const newUsedRoomsLeft = { ...usedRoomsLeft };
        if (i > 0 && room.roomsLeft !== null && room.roomsLeft !== void 0) {
          newUsedRoomsLeft[room.id] = (newUsedRoomsLeft[room.id] || 0) + i;
        }
        findCombination(
          index + 1,
          remainingAdults - i * room.adults,
          remainingChildren - i * room.children,
          newSelectedRooms,
          totalPrice + i * room.price,
          newUsedRoomsLeft,
        );
      }
    }
    rooms.sort((a, b) => a.price - b.price);
    findCombination(0, adultsNeeded, childrenNeeded, [], 0, {});
    if (validCombinations.length === 0) {
      return [];
    }
    return validCombinations.sort((a, b) => a.totalPrice - b.totalPrice)[0].rooms;
  };
  const getExtraChargesFromRoom = room => {
    const taxesAndFeesUnderPrice = room.querySelector('.prd-taxes-and-fees-under-price');
    const dataExclChargesRaw = taxesAndFeesUnderPrice?.getAttribute('data-excl-charges-raw');
    if (!dataExclChargesRaw) {
      return void 0;
    }
    const dataExclCharges = parseFloat(dataExclChargesRaw);
    if (!dataExclCharges) {
      return void 0;
    }
    return dataExclCharges;
  };
  const removeEverythingButNumbers = price => {
    return parseInt(price.replace(/\D/g, ''));
  };
  const getRoomOffersFromContent = () => {
    const rooms = [...document.querySelectorAll(SELECTORS.booking.accommodationPage.table.room.roomRow)].filter(
      Boolean,
    );
    const roomsOffers = rooms.map(room => {
      const priceDisplayStrategy = getPriceDisplayStrategy(room);
      const id = room?.getAttribute(SELECTORS.booking.accommodationPage.table.room.roomIdAttrib)?.split('_')[0] ?? '';
      const adultsAndChildren = room?.querySelector(SELECTORS.booking.accommodationPage.table.room.roomOccupancyIcons);
      const adults =
        adultsAndChildren?.querySelectorAll(SELECTORS.booking.accommodationPage.table.room.adultOccupancyIcon).length ??
        0;
      const children =
        adultsAndChildren?.querySelectorAll(SELECTORS.booking.accommodationPage.table.room.childOccupancyIcon).length ??
        0;
      const select = room.querySelector(SELECTORS.booking.accommodationPage.table.room.selectElement);
      const roomsAmount = select?.options ? Number(select.options[select.options.length - 1].value) : 0;
      const onlyXLeft = room.querySelector(SELECTORS.booking.accommodationPage.table.room.onlyXLeft)?.textContent;
      const roomsLeft = onlyXLeft ? onlyXLeft?.match(/\d+/g)?.map(Number)[0] : null;
      const priceSelector =
        priceDisplayStrategy === 'BASE_PER_NIGHT'
          ? SELECTORS.booking.accommodationPage.table.room.perNightPrice
          : SELECTORS.booking.accommodationPage.table.room.priceContainer;
      const priceText = room.querySelector(priceSelector)?.textContent;
      const price = removeEverythingButNumbers(priceText || '');
      const charges = getExtraChargesFromRoom(room);
      return {
        id,
        adults,
        children,
        roomsAmount,
        roomsLeft,
        price,
        charges,
      };
    });
    return roomsOffers;
  };
  const getCheapestPriceFromTable = async args => {
    const roomOffers = getRoomOffersFromContent();
    const cheapestCombinationOfRooms = findCheapestRoomCombination(roomOffers, args.adults, args.children);
    const totalPriceOfCheapestCombination = cheapestCombinationOfRooms.reduce((accumulator, currentRoom) => {
      return accumulator + currentRoom.price * currentRoom.count;
    }, 0);
    const totalChargesOfCheapestCombination = cheapestCombinationOfRooms.reduce((accumulator, currentRoom) => {
      const extraCharges = currentRoom.charges ?? 0;
      return accumulator + extraCharges * currentRoom.count;
    }, 0);
    return Promise.resolve({
      price: totalPriceOfCheapestCombination,
      charges: totalChargesOfCheapestCombination,
    });
  };
  const getCityFromBreadcrumb$1 = async () => {
    try {
      const cityLink = await querySelectorAsync(
        SELECTORS.booking.accommodationPage.cityBreadcrumbLink,
        DEFAULT_SELECTOR_TIMEOUT,
      );
      const cityName = cityLink.textContent;
      if (!cityName?.trim()) {
        logger.warn('City name not found in breadcrumb link from page content');
        return null;
      }
      logger.success(`City from breadcrumb extracted successfully: ${cityName.trim()}`);
      return cityName.trim();
    } catch (error) {
      logger.error(
        'Error extracting city from breadcrumb in page content: ' +
          (error instanceof Error ? error.message : String(error)),
      );
      return null;
    }
  };
  const getCountryFromBreadcrumb$1 = async () => {
    try {
      const breadcrumbContainer = await querySelectorAsync(
        SELECTORS.booking.accommodationPage.breadcrumbs,
        DEFAULT_SELECTOR_TIMEOUT,
      );
      if (breadcrumbContainer === null) {
        logger.warn('Breadcrumb container not found in page content');
        return null;
      }
      const breadcrumbLinks = breadcrumbContainer.querySelectorAll('a');
      const countryLink = Array.from(breadcrumbLinks).find(link => link.href.includes('dest_type=country'));
      if (!countryLink) {
        logger.warn('Country breadcrumb link not found in page content');
        return null;
      }
      const countryName = countryLink.textContent?.trim();
      if (!countryName) {
        logger.warn('Country name not found in breadcrumb link from page content');
        return null;
      }
      logger.success('Country from breadcrumb extracted successfully from page content:', countryName);
      return countryName;
    } catch (error) {
      logger.error('Error extracting country from breadcrumb in page content:', error);
      return null;
    }
  };
  const parseBookingOccupancy = occupancyText => {
    try {
      const normalizedText = occupancyText.trim();
      if (!normalizedText) {
        logger.warn('Occupancy text from page content is empty');
        return null;
      }
      const occupancyRegex = /(\d+)\s*[^·]*·\s*(\d+)\s*[^·]*·\s*(\d+)/u;
      const match = normalizedText.match(occupancyRegex);
      if (!match) {
        logger.warn('Could not parse occupancy pattern from page content:', { text: normalizedText });
        return null;
      }
      const adults = parseInt(match[1], 10);
      const children = parseInt(match[2], 10);
      const rooms = parseInt(match[3], 10);
      if (isNaN(adults) || isNaN(children) || isNaN(rooms)) {
        logger.warn('Invalid numbers in occupancy text from page content:', {
          text: normalizedText,
          adults,
          children,
          rooms,
        });
        return null;
      }
      const occupancyData = {
        adults,
        children,
        rooms,
      };
      logger.info('Parsed Booking.com occupancy from page content:', {
        original: normalizedText,
        parsed: occupancyData,
      });
      return occupancyData;
    } catch (error) {
      logger.warn('Error parsing Booking.com occupancy from page content:', error);
      return null;
    }
  };
  const getOccupancyFromContent$1 = async () => {
    try {
      const occupancyElement = await querySelectorAsync(SELECTORS.booking.common.occupancy, DEFAULT_SELECTOR_TIMEOUT);
      const occupancyText = occupancyElement?.textContent?.trim() || '';
      if (!occupancyText || occupancyText.length === 0) {
        logger.warn('Occupancy text from page content is empty');
        return null;
      }
      const occupancyData = parseBookingOccupancy(occupancyText);
      if (occupancyData) {
        logger.success('Parsed occupancy data from page content:', occupancyData);
      }
      return occupancyData;
    } catch (error) {
      logger.warn('(getOccupancyFromContent) Error extracting occupancy data:', error);
      return null;
    }
  };
  const getAdultsFromContent = async () => {
    const occupancyData = await getOccupancyFromContent$1();
    if (!occupancyData) {
      return 1;
    }
    return occupancyData.adults;
  };
  const getChildrenFromContent = async () => {
    const occupancyData = await getOccupancyFromContent$1();
    if (!occupancyData) {
      return 0;
    }
    return occupancyData.children;
  };
  const getRoomsFromContent = async () => {
    const occupancyData = await getOccupancyFromContent$1();
    if (!occupancyData) {
      return 1;
    }
    return occupancyData.rooms;
  };
  const querySelectorAllAsync = async (selector, timeout) => {
    return new Promise((resolve, reject) => {
      logger.selector(`Waiting for elements: ${selector}`);
      const elements = document.querySelectorAll(selector);
      if (elements.length > 0) {
        logger.selector(`(querySelectorAllAsync) Elements found immediately: ${selector}`, elements);
        resolve(Array.from(elements));
        return;
      }
      const observer = new MutationObserver(() => {
        const elements2 = document.querySelectorAll(selector);
        if (elements2.length > 0) {
          logger.selector(`(querySelectorAllAsync) Elements found via MutationObserver: ${selector}`, elements2);
          observer.disconnect();
          resolve(Array.from(elements2));
        }
      });
      observer.observe(document.body, { childList: true, subtree: true });
      if (timeout != null) {
        setTimeout(() => {
          logger.selector(`(querySelectorAllAsync) Timeout reached for element: ${selector}, timeout: ${timeout}ms`);
          observer.disconnect();
          reject(new Error(`Timeout waiting for element: ${selector}`));
        }, timeout);
      }
    });
  };
  const getRecommendedOfferFromContent = async () => {
    const priceDisplayStrategy = getPriceDisplayStrategy();
    const priceSelector =
      priceDisplayStrategy === 'BASE_PER_NIGHT'
        ? SELECTORS.booking.accommodationPage.recommendation.perNightPrice
        : SELECTORS.booking.accommodationPage.recommendation.totalPrice;
    const priceElement = document.querySelector(priceSelector);
    if (!priceElement) {
      return null;
    }
    const priceText = priceElement.textContent;
    const price = removeEverythingButNumbers(priceText || '');
    const charges = getExtraChargesFromRoom(priceElement);
    let roomsSelector = [...document.querySelectorAll(SELECTORS.booking.accommodationPage.recommendation.roomInfo)];
    if (roomsSelector.length === 0) {
      roomsSelector = await querySelectorAllAsync(
        SELECTORS.booking.accommodationPage.recommendation.initialSelectedRoomInfo,
        2e3,
      ).catch(() => {
        return querySelectorAllAsync(
          SELECTORS.booking.accommodationPage.recommendation.initialSingleRoomInfo,
          2e3,
        ).catch(error => {
          logger.warn(`Room extraction from recommended section failed. Error: ${error}`);
          return [];
        });
      });
    }
    const roomsAmount = [...roomsSelector]
      .map(room => room.innerText.match(/((\d+)\s×|×\s(\d+))/))
      .filter(match => match !== null)
      .map(match => match[0])
      .map(roomNumber => parseInt(roomNumber));
    const rooms = roomsAmount.reduce((acc, curr) => acc + curr, 0);
    return {
      price,
      charges,
      rooms,
    };
  };
  const RECOMMENDATION_CARD_BADGE_ID = 'booking-accommodation-page-card';
  const TABLE_CARD_BADGE_ID = 'booking-accommodation-page-table-card';
  class BookingAccommodationPageAdapter extends AccommodationPageAdapter {
    constructor() {
      super('BOOKING');
    }
    getPriceDisplayStrategy() {
      return getPriceDisplayStrategy();
    }
    async getAdultsFromContent() {
      return getAdultsFromContent();
    }
    async getCheapestRoomPriceFromContent() {
      const recommendedOffer = await getRecommendedOfferFromContent();
      if (!recommendedOffer) {
        return await getCheapestPriceFromTable({
          adults: this.adults,
          children: this.children,
        });
      }
      return {
        price: recommendedOffer.price,
        charges: recommendedOffer.charges ?? 0,
      };
    }
    async getChildrenFromContent() {
      return getChildrenFromContent();
    }
    async getRoomsFromContent() {
      return getRoomsFromContent();
    }
    async getCurrencyFromContent() {
      const currencyFromHeader = await getCurrencyFromHeader();
      if (currencyFromHeader) {
        return currencyFromHeader;
      }
      return getCurrencyFromPriceCell();
    }
    async getHotelIdFromContent() {
      try {
        const idInput = await querySelectorAsync(
          SELECTORS.booking.accommodationPage.inputWithHotelId,
          DEFAULT_SELECTOR_TIMEOUT,
        );
        const id = idInput?.value;
        if (!id) {
          throw new Error('Hotel ID not found in the input field.');
        }
        return id;
      } catch (error) {
        logger.warn('(getHotelIdFromContent) Error extracting hotel ID:', error);
        return null;
      }
    }
    async getHotelNameFromContent() {
      try {
        const hotelElement = await querySelectorAsync(
          SELECTORS.booking.accommodationPage.hotelName,
          DEFAULT_SELECTOR_TIMEOUT,
        );
        const hotelName = hotelElement?.textContent?.trim();
        return hotelName || null;
      } catch (error) {
        logger.warn('(getHotelNameFromContent) Error extracting hotel name:', error);
        return null;
      }
    }
    getSearchContextFromUrl() {
      return getBookingSearchContextFromUrl();
    }
    async getCheckInDateFromContent() {
      return getCheckInDateFromContent$1();
    }
    async getCheckOutDateFromContent() {
      return getCheckOutDateFromContent$1();
    }
    async getCityFromContent() {
      return getCityFromBreadcrumb$1();
    }
    async getCountryFromContent() {
      return getCountryFromBreadcrumb$1();
    }
    async createUI() {
      createStickyButton();
      const priceDisplayStrategy = this.getPriceDisplayStrategy();
      const cardButton = createCardButton({ badgeId: RECOMMENDATION_CARD_BADGE_ID });
      const tableCardButton = createCardButton({ badgeId: TABLE_CARD_BADGE_ID });
      switch (priceDisplayStrategy) {
        case 'BASE_PER_NIGHT': {
          const perNightCard = await querySelectorAsync(
            SELECTORS.booking.accommodationPage.recommendation.perNightMountingPoint,
            2e3,
          ).catch(() => null);
          cardButton.classList.add('booking-per-night-accommodation-page-card', 'fill');
          perNightCard?.prepend(cardButton);
          const perNightTableCard = await querySelectorAsync(
            SELECTORS.booking.accommodationPage.selection.perNightMountingPoint,
            2e3,
          ).catch(() => null);
          tableCardButton.classList.add('booking-per-night-accommodation-page-table-button', 'fill');
          perNightTableCard?.prepend(tableCardButton);
          break;
        }
        default: {
          const card = await querySelectorAsync(
            SELECTORS.booking.accommodationPage.recommendation.mountingPoint,
            2e3,
          ).catch(() => null);
          cardButton.classList.add('booking-accommodation-page-card', 'fill');
          card?.append(cardButton);
          const tableCard = await querySelectorAsync(
            SELECTORS.booking.accommodationPage.selection.mountingPoint,
            12e4,
          ).catch(() => null);
          tableCardButton.classList.add('booking-accommodation-page-card', 'fill');
          tableCard?.append(tableCardButton);
        }
      }
      return Promise.resolve();
    }
    async updateUI(args) {
      const { isBestOffer, pluginViewData, price, inlineButtonTrackingContext } = args;
      const recommendationMountingPoint =
        this.getPriceDisplayStrategy() === 'BASE_PER_NIGHT'
          ? SELECTORS.booking.accommodationPage.recommendation.perNightMountingPoint
          : SELECTORS.booking.accommodationPage.recommendation.mountingPoint;
      const tableMountingPoint =
        this.getPriceDisplayStrategy() === 'BASE_PER_NIGHT'
          ? SELECTORS.booking.accommodationPage.selection.perNightMountingPoint
          : SELECTORS.booking.accommodationPage.selection.mountingPoint;
      const nights = getDateDiffInDays(new Date(this.checkIn), new Date(this.checkOut));
      const details = {
        nights,
        rooms: pluginViewData.roomsAmount,
        guests: this.adults + this.children,
      };
      await super.updateUI(args);
      try {
        const recommendationCard = await querySelectorAsync(recommendationMountingPoint, 2e3);
        const args2 = {
          bestOfferPrice: price,
          isBestOffer,
          currency: this.currency,
          pluginViewData,
          trackingContext: inlineButtonTrackingContext,
          details: this.getPriceDisplayStrategy() === 'BASE_PER_NIGHT' ? void 0 : details,
        };
        updateCardButton({
          ...args2,
          badgeId: RECOMMENDATION_CARD_BADGE_ID,
          parent: recommendationCard,
        });
      } catch (error) {
        logger.warn('Error updating recommendation card button:', error);
      }
      try {
        const tableCard = await querySelectorAsync(tableMountingPoint, 2e3);
        const args2 = {
          bestOfferPrice: price,
          isBestOffer,
          currency: this.currency,
          pluginViewData,
          trackingContext: inlineButtonTrackingContext,
          details: this.getPriceDisplayStrategy() === 'BASE_PER_NIGHT' ? void 0 : details,
        };
        updateCardButton({ ...args2, badgeId: TABLE_CARD_BADGE_ID, parent: tableCard });
      } catch (error) {
        logger.warn('Error updating table card button:', error);
      }
    }
    removeUI() {
      super.removeUI();
      logger.info('Removing all card buttons');
      const cardButtons = document.querySelectorAll(`.hermes-search-result-badge-wrapper`);
      cardButtons.forEach(card => {
        if (!card.parentElement) {
          return;
        }
        removeCardButton(card.parentElement);
      });
    }
  }
  class Selector {
    constructor(selector, parent = document) {
      __publicField(this, 'element');
      logger.selector('Selector initialized with selector:', selector);
      const el = parent.querySelector(selector);
      if (el) {
        logger.selector('Element found:', el);
      } else {
        logger.warn('Element not found:', selector);
      }
      this.element = el;
    }
    get textContent() {
      if (this.element && this.element.textContent?.trim().length === 0) {
        logger.warn('Element has empty text content', this.element);
      }
      return this.element?.textContent ?? null;
    }
  }
  const splitIntoChunks = (array, chunkSize) => {
    const chunks = [];
    for (let i = 0; i < array.length; i += chunkSize) {
      chunks.push(array.slice(i, i + chunkSize));
    }
    return chunks;
  };
  const initializeUrlChangeListener = onUrlChange => {
    let lastUrl = location.href;
    const intervalId = setInterval(() => {
      if (location.href !== lastUrl) {
        lastUrl = location.href;
        onUrlChange();
      }
    }, 500);
    logger.success('URL change listener initialized');
    return () => {
      clearInterval(intervalId);
      logger.success('URL change listener stopped');
    };
  };
  class SearchResultsPageAdapter extends SiteAdapter {
    constructor({ selectors, buttonOptions, hotelIdProvider }) {
      super(hotelIdProvider);
      __publicField(this, 'selectors');
      __publicField(this, 'hotelCardObserver');
      __publicField(this, 'usedHotelIdsInSearch', false);
      __publicField(this, 'buttonOptions', {
        place: 'append',
        platform: 'DEFAULT',
        className: [],
      });
      __publicField(this, 'hotelCardMutationHandler', mutations => {
        try {
          const newCards = [];
          mutations.forEach(mutation => {
            mutation.addedNodes.forEach(node => {
              const nodeIsAnElement = node.nodeType === Node.ELEMENT_NODE;
              if (nodeIsAnElement) {
                const element = node;
                const elementIsHotelCard = element.matches(this.selectors.hotelCard);
                const elementIsParentOfHotelCard = Boolean(element.querySelector(this.selectors.hotelCard));
                const hasButtonAlready = element.querySelector('.hermes-search-result-badge');
                if (hasButtonAlready) {
                  return;
                }
                if (elementIsHotelCard) {
                  logger.info('(Mutation) New hotel card added:', element);
                  newCards.push(element);
                } else if (elementIsParentOfHotelCard) {
                  logger.info('Added node was a parent of hotel card');
                  this.remountButtonsOnListRefresh();
                }
              }
            });
          });
          if (newCards.length > 0) {
            logger.info('(Mutation) Handling new cards without buttons:', newCards);
            void this.handleCardsWithoutButtons(newCards);
          }
        } catch (error) {
          const errorMessage = error instanceof Error ? error.message : String(error);
          logger.warn('Error in hotel card mutation handler:', errorMessage);
        }
      });
      removeStickyContainer();
      this.selectors = selectors;
      this.buttonOptions = buttonOptions || this.buttonOptions;
      void this.initializeSearchResultsAdapter();
      initializeUrlChangeListener(() => {
        logger.info('URL changed, re-initializing buttons in cards');
        this.reinstallWholeAdapter();
      });
      logger.success('HotelSearchResultsAdapter initialized:', this);
    }
    getToolbarProps() {
      return {
        checkIn: this.checkIn,
        checkOut: this.checkOut,
        adults: this.adults,
        children: this.children,
        country: this.country,
        city: this.city,
        rooms: this.rooms,
        shouldOptimizeRooms: this.shouldOptimizeRooms,
        roomsConfiguration: this.roomsConfiguration,
        childrenAges: this.childrenAges,
        currency: this.currency,
        lat: this.lat,
        lng: this.lng,
      };
    }
    /** Retrieves hotel cards on page load from DOM */
    getInitialHotelCards() {
      try {
        const cards = document.querySelectorAll(this.selectors.hotelCard);
        if (cards.length === 0) {
          throw new Error('No hotel cards found');
        }
        logger.info(`Found ${cards.length} initial hotel cards`);
        return [...cards];
      } catch (error) {
        const errorMessage = error instanceof Error ? error.message : String(error);
        logger.warn('Error getting initial hotel cards:', errorMessage);
        throw error;
      }
    }
    mountButtonToHotelCard(card) {
      try {
        const badgeMountingPoint = card.querySelector(this.selectors.inlineButtonMountingPoint);
        const hasButtonAlready = card.querySelector('.hermes-search-result-badge');
        if (hasButtonAlready) {
          logger.info('(mountButtonToHotelCard) Button already exists in hotel card:', card);
          return;
        }
        if (!badgeMountingPoint) {
          logger.warn('Button mounting point not found in hotel card:', card);
          card.setAttribute('data-hermes-error', 'mounting-point-not-found');
          return;
        }
        const button = createCardButton();
        button.setAttribute('data-platform', this.hotelIdProvider);
        this.buttonOptions.className?.forEach(className => {
          button.classList.add(className);
        });
        badgeMountingPoint[this.buttonOptions.place](button);
        logger.info('Button mounted successfully to hotel card');
      } catch (error) {
        const errorMessage = error instanceof Error ? error.message : String(error);
        logger.warn('Error mounting button to hotel card:', errorMessage);
      }
    }
    getHotelNameListFromCards(cards) {
      try {
        const hotelNames = cards
          .map(card => {
            const hotelName = this.getHotelNameFromHotelCard(card);
            if (!hotelName) {
              logger.warn('Removing button from card, no hotel name detected:', card);
              removeCardButton(card);
            }
            return hotelName;
          })
          .filter(name => name !== null);
        logger.info(`Extracted ${hotelNames.length} hotel names from cards`);
        return hotelNames;
      } catch (error) {
        const errorMessage = error instanceof Error ? error.message : String(error);
        logger.warn('Error getting hotel name list from cards:', errorMessage);
        throw error;
      }
    }
    getHotelIdsFromCards(cards) {
      try {
        const hotelIds = cards.map(card => {
          const hotelId = this.getHotelIdFromHotelCard(card);
          return hotelId;
        });
        if (hotelIds.some(id => id === null)) {
          logger.warn('There was null in hotel ID in cards:', cards);
          return null;
        }
        logger.info(`Extracted ${hotelIds.length} hotel IDs from cards`);
        return hotelIds;
      } catch (error) {
        const errorMessage = error instanceof Error ? error.message : String(error);
        logger.warn('Error getting hotel IDs from cards:', errorMessage);
        throw error;
      }
    }
    /** Main function for handling buttons on the search result page */
    async handleCardsWithoutButtons(cards) {
      await this.initializeSiteAdapterRequiredProperties();
      const chunkSize = 50;
      const cardChunks = splitIntoChunks(cards, chunkSize);
      logger.info('Card chunks:', cardChunks);
      for (const chunk of cardChunks) {
        chunk.forEach(card => {
          this.mountButtonToHotelCard(card);
        });
        const hotelNames = this.getHotelNameListFromCards(chunk);
        const hotelIds = this.getHotelIdsFromCards(chunk);
        logger.info('Hotel names:', hotelNames);
        let query;
        query = {
          hotelNames: {
            names: hotelNames,
            country: this.country,
            city: this.city,
          },
          lat: this.lat,
          lon: this.lng,
        };
        if (hotelIds) {
          this.usedHotelIdsInSearch = true;
          query = {
            hotelIds,
            hotelIdsProvider: HOTEL_ID_PROVIDERS[this.hotelIdProvider],
            lat: this.lat,
            lon: this.lng,
          };
        } else {
          this.usedHotelIdsInSearch = false;
        }
        try {
          const hotelDataResponse = await this.fetchHotelData(query);
          logger.api('API Search response', hotelDataResponse);
          if ('error' in hotelDataResponse) {
            throw new Error('Error in hotel data response');
          }
          if (!hotelDataResponse.hotels || !hotelDataResponse.stay) {
            throw new Error('Data in API response incomplete');
          }
          this.updateCardButtonsWithNewHotelData(chunk, hotelDataResponse);
        } catch (error) {
          const errorMessage = error instanceof Error ? error.message : String(error);
          logger.error('Error handling cards without buttons:', errorMessage);
          logger.info('Removing all buttons in the current chunk');
          chunk.forEach(card => removeCardButton(card));
        }
      }
    }
    updateCardButtonsWithNewHotelData(cards, response) {
      logger.info('Updating cards with new hotel data');
      const errorsDuringForEach = [];
      cards.forEach(card => {
        try {
          const {
            hotelName,
            price: priceFromCard,
            priceDisplayMode,
            extraCharges,
            hotelId,
          } = this.extractDataFromHotelCard(card);
          const nights = getDateDiffInDays(new Date(this.checkIn), new Date(this.checkOut));
          const noRequiredData = !hotelName || !priceFromCard || !this.currency;
          if (noRequiredData) {
            throw new Error(
              `Missing required data: hotelName=${hotelName}, price=${priceFromCard}, currency=${this.currency}`,
            );
          }
          const foundHotel = response.hotels?.find(hotel => hotel.requestedName === hotelName || hotel.id === hotelId);
          const noHotelsFromAPI = !foundHotel || !foundHotel.details;
          if (noHotelsFromAPI) {
            throw new Error(`No matching hotel or details found for hotelName=${hotelName}`);
          }
          const noOffersForHotelFromAPI = !foundHotel.offers || foundHotel.offers.length === 0;
          if (noOffersForHotelFromAPI) {
            throw new Error(`No offers exist for hotelName=${hotelName}`);
          }
          const { isBestOffer, bestDisplayPrice, priceDifference, bestOffer } = getIsBestOffer({
            offers: foundHotel.offers,
            currentPrice: priceFromCard,
            currentCharges: extraCharges ?? void 0,
            priceDisplayStrategy: priceDisplayMode,
            roomsCount: this.rooms || 1,
            // if rooms aren't optimized, prices we get in offers are per room, not per stay
            multiplyPriceByRoomsCount: !this.shouldOptimizeRooms,
            nights,
          });
          const modalData = this.mapDataForModal({
            foundHotel,
            response,
            price: priceFromCard,
            charges: extraCharges ?? void 0,
            priceDifference,
            priceDisplayStrategy: priceDisplayMode,
            isBestOffer,
          });
          const inlineButtonInCard = card.querySelector('.hermes-search-result-badge');
          if (!inlineButtonInCard) {
            this.mountButtonToHotelCard(card);
          }
          const inlineButtonOfferContext = {
            providerName: bestOffer?.provider.name,
            displayPriceType: priceDisplayMode,
            displayPrice: bestOffer?.displayPrice,
            anchorPrice: priceFromCard,
            currency: this.currency,
            isBetterOffer: isBestOffer,
            rateBreakdown: bestOffer?.rate,
          };
          const inlineButtonHotelContext = {
            hotelId: foundHotel?.id,
            hotelIdsProvider: this.usedHotelIdsInSearch ? HOTEL_ID_PROVIDERS[this.hotelIdProvider] ?? void 0 : void 0,
          };
          const inlineButtonTrackingContext = {
            offerContext: inlineButtonOfferContext,
            hotelContext: inlineButtonHotelContext,
          };
          this.updateCommonButton({
            parent: card,
            bestOfferPrice: bestDisplayPrice,
            isBestOffer,
            currency: this.currency,
            pluginViewData: modalData,
            trackingContext: inlineButtonTrackingContext,
          });
        } catch (error) {
          errorsDuringForEach.push({
            error,
            card,
            scriptAction: 'Inline button removed for that card',
          });
          removeCardButton(card);
        }
      });
      if (errorsDuringForEach.length > 0) {
        logger.warn(
          `There was: ${errorsDuringForEach.length} errors during updateCardButtonsWithNewHotelData function:`,
          errorsDuringForEach,
        );
      }
      logger.success('Cards updating finished');
    }
    mapDataForModal({ foundHotel, price, priceDifference, charges, response, priceDisplayStrategy, isBestOffer }) {
      const { details, offers } = foundHotel;
      const { name, starRating, images } = details;
      const { checkIn, checkOut } = response.stay;
      const roomsConfig = foundHotel?.roomsConfig || this.roomsConfiguration;
      const roomsAmount = roomsConfig?.split('|')?.length || 1;
      const currentProvider = getCurrentProvider();
      const offersWithoutCurrentProvider = offers.filter(offer => offer.provider.name !== currentProvider);
      const nights = getDateDiffInDays(new Date(checkIn), new Date(checkOut));
      const { bestOffer, sortedOffers } = parseOffersForModalList({
        offers: offersWithoutCurrentProvider,
        priceDisplayStrategy,
        roomsCount: this.rooms || 1,
        // if rooms aren't optimized, prices we get in offers are per room, not per stay
        multiplyPriceByRoomsCount: !this.shouldOptimizeRooms,
        nights,
      });
      return {
        priceDifference,
        currency: this.currency,
        checkIn,
        checkOut,
        stars: starRating || 0,
        img: images?.[0] || '',
        hotelName: name,
        children: this.children,
        adults: this.adults,
        roomsAmount,
        roomName: bestOffer.roomName,
        bookingPrice: price,
        bookingTax: charges,
        bestPrice: bestOffer.displayPrice,
        bestOfferUrl: bestOffer.url,
        offers: sortedOffers,
        bestRate: bestOffer.rate,
        priceDisplayStrategy,
        isBestOffer,
      };
    }
    async getAndHandleInitialCardButtons() {
      const hotelCards = this.getInitialHotelCards();
      await this.handleCardsWithoutButtons(hotelCards);
    }
    getCardsWithoutButtons() {
      const cards = document.querySelectorAll(this.selectors.hotelCard);
      const cardsWithoutButtons = [...cards].filter(card => !card.querySelector('.hermes-search-result-badge'));
      return cardsWithoutButtons;
    }
    handleCardsWithoutButtonsOnLoadedPage() {
      const cardsWithoutButtons = this.getCardsWithoutButtons();
      if (cardsWithoutButtons.length > 0) {
        void this.handleCardsWithoutButtons(cardsWithoutButtons);
      }
    }
    reinstallWholeAdapter() {
      try {
        logger.info('Reinstalling whole adapter, removing all buttons');
        const inlineButtons = document.querySelectorAll('.hermes-search-result-badge');
        inlineButtons.forEach(button => {
          removeCardButton(button);
        });
        logger.info('Disconnecting hotel card observer');
        this.hotelCardObserver?.disconnect();
        void this.initializeSearchResultsAdapter();
        logger.info('Whole adapter reinstallation completed successfully');
      } catch (error) {
        const errorMessage = error instanceof Error ? error.message : String(error);
        logger.warn('Error reinstalling whole adapter:', errorMessage);
      }
    }
    getAdultsFromContent() {
      return showNotImplementedMessageAsync('getAdultsFromContent');
    }
    getCheckInDateFromContent() {
      return showNotImplementedMessageAsync('getCheckInDateFromContent');
    }
    getCheckOutDateFromContent() {
      return showNotImplementedMessageAsync('getCheckOutDateFromContent');
    }
    getChildrenAgesFromContent() {
      return showNotImplementedMessageAsync('getChildrenAgesFromContent');
    }
    getChildrenFromContent() {
      return showNotImplementedMessageAsync('getChildrenFromContent');
    }
    getCityFromContent() {
      return showNotImplementedMessageAsync('getCityFromContent');
    }
    getCountryFromContent() {
      return showNotImplementedMessageAsync('getCountryFromContent');
    }
    getCurrencyFromContent() {
      return showNotImplementedMessageAsync('getCurrencyFromContent');
    }
    getRoomsFromContent() {
      return showNotImplementedMessageAsync('getRoomsFromContent');
    }
    async initializeSearchResultsAdapter() {
      try {
        logger.info('Initializing search results adapter steps');
        await this.initializeSiteAdapterRequiredProperties();
        logger.info('1/3 Initialized search results adapter properties');
        await this.setupHotelCardObserver();
        logger.info('2/3 Initialized hotel card observer');
        await this.getAndHandleInitialCardButtons();
        logger.info('3/3 Initialized buttons in hotel cards');
        initializeUrlChangeListener(() => {
          logger.info('URL changed, re-initializing buttons in cards');
          this.reinstallWholeAdapter();
        });
        logger.success('Search results adapter initialization completed successfully');
      } catch (error) {
        const errorMessage = error instanceof Error ? error.message : String(error);
        logger.error('Error initializing search results adapter:', errorMessage);
        if (this.hotelCardObserver) {
          this.hotelCardObserver.disconnect();
        }
      }
    }
    /** Initializes mutation observer for any new dynamically added hotel cards */
    async setupHotelCardObserver() {
      try {
        logger.info('Setting up hotel card observer');
        if (this.hotelCardObserver) {
          logger.info('Disconnecting existing hotel card observer');
          this.hotelCardObserver.disconnect();
        }
        this.hotelCardObserver = new MutationObserver(this.hotelCardMutationHandler);
        const hotelCardsWrapper = await querySelectorAsync(
          this.selectors.hotelCardsWrapper ?? '',
          DEFAULT_SELECTOR_TIMEOUT,
        ).catch(() => null);
        const [targetNode, config2] = hotelCardsWrapper
          ? [hotelCardsWrapper, { childList: true }]
          : [document.body, { childList: true, subtree: true }];
        if (!targetNode) {
          logger.warn('Target node not found for hotel card observer');
          return;
        }
        this.hotelCardObserver.observe(targetNode, config2);
        logger.success('Hotel card observer initialized');
      } catch (error) {
        const errorMessage = error instanceof Error ? error.message : String(error);
        logger.error('Error setting up hotel card observer:', errorMessage);
        throw new Error(errorMessage);
      }
    }
    /** Handles case when all inline buttons are removed when page is randomly re-rendered */
    remountButtonsOnListRefresh() {
      try {
        const anyInlineBadgeExists = document.querySelector('.hermes-search-result-badge');
        if (!anyInlineBadgeExists) {
          logger.warn(
            'No inline buttons found when using intersection observer, initializing again.',
            anyInlineBadgeExists,
          );
          void this.getAndHandleInitialCardButtons();
        } else {
          logger.info(
            '(remountButtonsOnListRefresh) Inline buttons already exist, no need to re-initialize all of them.',
          );
          this.handleCardsWithoutButtonsOnLoadedPage();
        }
        logger.info('Button remounting completed successfully');
      } catch (error) {
        const errorMessage = error instanceof Error ? error.message : String(error);
        logger.warn('Error remounting buttons on list refresh:', errorMessage);
      }
    }
    /**
     * Returns hotel name from the card title and null if not found
     */
    getHotelNameFromHotelCard(card) {
      const titleElement = new Selector(this.selectors.hotelTitle, card);
      const title = titleElement?.textContent?.trim();
      if (!title) {
        logger.info('(getHotelNameFromHotelCard) Hotel name not found');
        return null;
      }
      return title;
    }
    // this is a placeholder - some platforms use IDs
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    getHotelIdFromHotelCard(_card) {
      return null;
    }
    extractDataFromHotelCard(card) {
      const hotelName = this.getHotelNameFromHotelCard(card);
      const hotelId = this.getHotelIdFromHotelCard(card);
      const hotelPrice = this.getHotelPriceFromHotelCard(card);
      const priceDisplayMode = this.getCardPriceDisplayMode(card);
      const hotelExtraCharges = this.getCardExtraCharges(card);
      return {
        hotelName,
        hotelId,
        price: hotelPrice,
        priceDisplayMode,
        extraCharges: hotelExtraCharges,
      };
    }
  }
  const getBreadcrumbElement = async linkTextFragment => {
    const SELECTOR = SELECTORS.booking.searchResultsPage.breadcrumbs;
    const breadcrumbContainer = await querySelectorAsync(SELECTOR.container, DEFAULT_SELECTOR_TIMEOUT);
    logger.selector('breadcrumbContainer', breadcrumbContainer);
    const breadcrumbLinks = [...breadcrumbContainer.querySelectorAll(SELECTOR.link)];
    logger.selector('breadcrumbLinks', breadcrumbLinks);
    const foundLink = breadcrumbLinks.find(link => {
      return link.href.includes(linkTextFragment);
    });
    if (!foundLink) {
      logger.warn(`Breadcrumb link not found for link: ${linkTextFragment}`, foundLink);
      return null;
    }
    return foundLink;
  };
  const getCityFromBreadcrumb = async () => {
    const cityBreadCrumb = await getBreadcrumbElement('/city/');
    if (!cityBreadCrumb) {
      logger.warn('City breadcrumb element not found:', cityBreadCrumb);
      return null;
    }
    const url = cityBreadCrumb.href;
    const match = url.match(/\/city\/[^/]+\/([^/.]+)/);
    const city = match?.at(1);
    if (!match || !city) {
      logger.warn('City not found in breadcrumb');
      return null;
    }
    logger.success('City from breadcrumb extracted successfully:', city);
    return city;
  };
  const parseCountryCodeToCountryName = code => {
    const regionNames = new Intl.DisplayNames(['en'], { type: 'region' });
    const countryName = regionNames.of(code.toUpperCase());
    if (!countryName) {
      logger.warn(`Country name not extracted from country code: ${code}`);
      return null;
    }
    return countryName;
  };
  const getCountryFromBreadcrumb = async () => {
    const countryBreadcrumb = await getBreadcrumbElement('/country/');
    if (!countryBreadcrumb) {
      logger.warn('Country breadcrumb element not found:', countryBreadcrumb);
      return null;
    }
    const url = countryBreadcrumb.href;
    const match = url.match(/\/country\/([^/.]+)/);
    const countryCode = match?.at(1);
    if (!match || !countryCode) {
      logger.warn('Country code not found in breadcrumb');
      return null;
    }
    const fullCountryName = parseCountryCodeToCountryName(countryCode);
    if (!fullCountryName) {
      return null;
    }
    logger.success('Country from breadcrumb extracted successfully:', fullCountryName);
    return fullCountryName;
  };
  const getOccupancyFromContent = async () => {
    try {
      const occupancyConfigElement = await querySelectorAsync(
        SELECTORS.booking.common.occupancy,
        DEFAULT_SELECTOR_TIMEOUT,
      );
      const occupancyText = occupancyConfigElement?.textContent?.trim();
      if (!occupancyText || occupancyText?.length === 0) {
        logger.warn('Occupancy element from page content is empty');
        return { adultsCount: null, childrenCount: null, roomsCount: null };
      }
      const occupancyParts = occupancyText.split('·');
      const adultsText = occupancyParts.at(0);
      const childrenText = occupancyParts.at(1);
      const roomsText = occupancyParts.at(2);
      const adultsCount = adultsText ? parseInt(adultsText.match(/\d+/)?.at(0) || 'NaN') : NaN;
      const childrenCount = childrenText ? parseInt(childrenText.match(/\d+/)?.at(0) || 'NaN') : NaN;
      const roomsCount = roomsText ? parseInt(roomsText.match(/\d+/)?.at(0) || 'NaN') : NaN;
      if (isNaN(adultsCount)) {
        logger.warn('Parsed adults count from page content is NaN');
      }
      if (isNaN(childrenCount)) {
        logger.warn('Parsed children count from page content is NaN');
      }
      if (isNaN(roomsCount)) {
        logger.warn('Parsed rooms count from page content is NaN');
      }
      logger.success('Parsed occupancy from page content:', { adultsCount, childrenCount, roomsCount });
      return {
        adultsCount: isNaN(adultsCount) ? null : adultsCount,
        childrenCount: isNaN(childrenCount) ? null : childrenCount,
        roomsCount: isNaN(roomsCount) ? null : roomsCount,
      };
    } catch (error) {
      logger.warn('Error getting occupancy from page content:', error);
      return { adultsCount: null, childrenCount: null, roomsCount: null };
    }
  };
  const getExtraChargesFromCard = card => {
    const taxInfo = card.querySelector(SELECTORS.booking.searchResultsPage.hotelCard.taxInfo);
    const labelText = taxInfo?.textContent;
    if (labelText && labelText.match(/\d+/g)) {
      const taxPrice = removeEverythingButNumbers(labelText);
      if (!isNaN(taxPrice)) {
        return taxPrice;
      }
    }
    return null;
  };
  const getHotelPriceFromCard = card => {
    const priceText = card.querySelector(SELECTORS.booking.searchResultsPage.hotelCard.price)?.textContent;
    return priceText ? removeEverythingButNumbers(priceText) : null;
  };
  const getPriceDisplayModeFromHotelCard = card => {
    const priceWrapper = card.querySelector(SELECTORS.booking.searchResultsPage.hotelCard.priceWrapper);
    const prices = priceWrapper?.querySelectorAll(SELECTORS.booking.searchResultsPage.hotelCard.price);
    if (prices?.length === 2) {
      return 'BASE_PER_NIGHT';
    }
    const searchPageTaxInfo = card.querySelector(SELECTORS.booking.searchResultsPage.hotelCard.taxInfo);
    if (!searchPageTaxInfo) {
      return 'BASE_ONLY';
    }
    const labelText = searchPageTaxInfo.textContent || '';
    if (labelText.match(/\d+/g)) {
      return 'BASE_WITH_CHARGES_ON_SIDE';
    }
    return 'ALL_INCLUSIVE';
  };
  const getCurrencyFromFirstCard = async () => {
    const priceOfFirstCard = await querySelectorAsync(
      SELECTORS.booking.searchResultsPage.hotelCard.price,
      DEFAULT_SELECTOR_TIMEOUT,
    );
    const priceText = priceOfFirstCard?.innerText;
    if (!priceText) {
      return null;
    }
    const currency = getCurrencyFromPriceText(priceText);
    return getStandardizedCurrency(currency);
  };
  class BookingSearchResultsPageAdapter extends SearchResultsPageAdapter {
    constructor() {
      const selectorsFromAPI = SELECTORS.booking.searchResultsPage;
      super({
        selectors: {
          hotelCard: selectorsFromAPI.hotelCard.wrapper,
          hotelTitle: selectorsFromAPI.hotelCard.title,
          inlineButtonMountingPoint: selectorsFromAPI.hotelCard.buttonMountingPoint,
        },
        buttonOptions: {
          place: 'prepend',
        },
        hotelIdProvider: 'BOOKING',
      });
      logger.success('BookingSearchResultsAdapter initialized:', this);
    }
    async getCurrencyFromContent() {
      const currencyFromHeader = await getCurrencyFromHeader();
      if (currencyFromHeader) {
        return currencyFromHeader;
      }
      const currencyFromFirstCard = await getCurrencyFromFirstCard();
      return currencyFromFirstCard;
    }
    async getCountryFromContent() {
      return getCountryFromBreadcrumb();
    }
    async getCityFromContent() {
      return getCityFromBreadcrumb();
    }
    getHotelPriceFromHotelCard(card) {
      const priceFromCard = getHotelPriceFromCard(card);
      if (!priceFromCard || isNaN(priceFromCard)) {
        logger.warn('Cant extract price from card:', card);
        throw new Error('Not able to extract price from card');
      }
      return priceFromCard;
    }
    getCardPriceDisplayMode(card) {
      return getPriceDisplayModeFromHotelCard(card);
    }
    getSearchContextFromUrl() {
      return getBookingSearchContextFromUrl();
    }
    getCardExtraCharges(card) {
      return getExtraChargesFromCard(card);
    }
    async getAdultsFromContent() {
      const { adultsCount } = await getOccupancyFromContent();
      return adultsCount;
    }
    async getChildrenFromContent() {
      const { childrenCount } = await getOccupancyFromContent();
      return childrenCount;
    }
    async getRoomsFromContent() {
      const { roomsCount } = await getOccupancyFromContent();
      return roomsCount;
    }
    async getCheckInDateFromContent() {
      return getCheckInDateFromContent$1();
    }
    async getCheckOutDateFromContent() {
      return getCheckOutDateFromContent$1();
    }
  }
  const extractPricesFromText = text => {
    const matches = text.match(/\d[\d.,\s]*\d/g);
    if (!matches) {
      return [];
    }
    const prices = /* @__PURE__ */ new Set();
    for (let raw of matches) {
      raw = raw.replace(/\s/g, '');
      const cleaned = raw.replace(/[.,]/g, '');
      if (/^\d+$/.test(cleaned)) {
        prices.add(cleaned);
      }
    }
    return Array.from(prices).map(p => Number(p));
  };
  async function waitUntilElementExist(selector, options2 = {}) {
    const { timeout } = options2;
    return new Promise((resolve, reject) => {
      let timeoutId = null;
      const checkAndMaybeResolve = () => {
        const element = document.querySelector(selector);
        if (element) {
          if (timeoutId) {
            clearTimeout(timeoutId);
          }
          observer.disconnect();
          resolve();
        }
      };
      checkAndMaybeResolve();
      const observer = new MutationObserver(checkAndMaybeResolve);
      observer.observe(document.body, {
        childList: true,
        subtree: true,
      });
      if (timeout !== void 0) {
        timeoutId = setTimeout(() => {
          observer.disconnect();
          reject(new Error(`Timeout: element "${selector}" doesn't exist after ${timeout}ms`));
        }, timeout);
      }
    });
  }
  class ExpediaAccommodationPageAdapter extends AccommodationPageAdapter {
    constructor(hotelIdProvider = 'EXPEDIA') {
      super(hotelIdProvider);
      this.watchForUrlChange();
    }
    watchForUrlChange() {
      initializeUrlChangeListener(() => {
        logger.info('URL changed, re-initializing buttons in cards');
        void this.reinstallWholeAdapter();
      });
    }
    async reinstallWholeAdapter() {
      logger.info('Reinstalling whole adapter, removing all buttons');
      await waitUntilElementExist(SELECTORS.expedia.accommodationPage.cheapestOfferCard.wrapper);
      this.removeUI();
      void this.initializeAdapter();
    }
    async getAdultsFromContent() {
      try {
        const adultsInput = await querySelectorAllAsync(
          SELECTORS.expedia.accommodationPage.adultsInput,
          DEFAULT_SELECTOR_TIMEOUT,
        );
        const adults = Number(adultsInput.map(input => input.value).reduce((acc, curr) => acc + Number(curr), 0));
        if (isNaN(adults)) {
          logger.warn('Adults input is invalid:', adults);
          return null;
        }
        return adults;
      } catch (error) {
        logger.warn('Error getting adults from content:', error);
        return null;
      }
    }
    async getRoomsFromContent() {
      const adultsInputElements = await querySelectorAllAsync(
        SELECTORS.expedia.accommodationPage.adultsInput,
        DEFAULT_SELECTOR_TIMEOUT,
      );
      const roomsCount = adultsInputElements.length;
      return roomsCount;
    }
    async getCheapestRoomPriceFromContent() {
      const cheapestOfferCard = await querySelectorAsync(
        SELECTORS.expedia.accommodationPage.cheapestOfferCard.wrapper,
        1e3 * 60 * 3,
      );
      if (!cheapestOfferCard) {
        logger.warn('Cheapest offer card not found');
        throw new Error('Cheapest offer card not found');
      }
      const prices = [
        ...cheapestOfferCard.querySelectorAll(SELECTORS.expedia.accommodationPage.cheapestOfferCard.price),
      ]
        .flatMap(priceElement => extractPricesFromText(priceElement.textContent ?? ''))
        .map(price => removeEverythingButNumbers(price.toString()));
      return {
        price: Math.max(...prices),
        charges: 0,
      };
    }
    async getChildrenAgesFromContent() {
      try {
        const childrenAges = await querySelectorAllAsync(SELECTORS.expedia.accommodationPage.childrenAgesInputs, 1e3);
        const childrenAgesArray = childrenAges.map(input => Number(input.value)).filter(age => age > 0);
        if (childrenAgesArray.some(isNaN)) {
          logger.warn('Children ages array is invalid:', childrenAgesArray);
          return null;
        }
        return childrenAgesArray;
      } catch (error) {
        logger.warn('Error getting children ages from content:', error);
        return [];
      }
    }
    async getChildrenFromContent() {
      try {
        const childrenAges = await this.getChildrenAgesFromContent();
        const children = childrenAges?.length;
        if (typeof children !== 'number' || isNaN(children)) {
          logger.warn('Children input is invalid:', children);
          return null;
        }
        return children;
      } catch (error) {
        logger.warn('Error getting children from content:', error);
        return null;
      }
    }
    async createUI() {
      createStickyButton();
      const { buttonMountingPoint, wrapper } = SELECTORS.expedia.accommodationPage.cheapestOfferCard;
      const card = await querySelectorAsync(`${wrapper} ${buttonMountingPoint}`, 12e4);
      const cardButton = createCardButton();
      cardButton.classList.add('expedia-accommodation-page-card', 'fill');
      card.append(cardButton);
    }
    async updateUI({ isBestOffer, pluginViewData, price, inlineButtonTrackingContext }) {
      updateStickyButton({
        bestOfferPrice: price,
        isBestOffer,
        currency: this.currency,
        trackingContext: inlineButtonTrackingContext,
      });
      updatePopup(pluginViewData);
      try {
        const hotelCard = await querySelectorAsync(
          SELECTORS.expedia.accommodationPage.cheapestOfferCard.wrapper,
          1e3 * 60 * 3,
        );
        updateCardButton({
          parent: hotelCard,
          bestOfferPrice: price,
          isBestOffer,
          currency: this.currency,
          pluginViewData,
          trackingContext: inlineButtonTrackingContext,
        });
      } catch (error) {
        logger.warn('Error updating card button:', error);
      }
    }
    removeUI() {
      const cheapestOfferCard = document.querySelectorAll(
        SELECTORS.expedia.accommodationPage.cheapestOfferCard.wrapper,
      );
      cheapestOfferCard.forEach(card => {
        removeCardButton(card);
      });
      removeStickyButton();
    }
    async getCurrencyFromContent() {
      logger.info('Getting currency from content');
      const allUrls = document.querySelectorAll('a');
      const currencyUrl = Array.from(allUrls).find(url => url.href.includes('cur'));
      const urlParams = new URLSearchParams(currencyUrl?.search);
      const currency = urlParams.get('cur');
      logger.info('Currency from from content:', currency);
      return currency;
    }
    async getHotelIdFromContent() {
      try {
        const hotelIdElement = await querySelectorAsync(
          SELECTORS.expedia.accommodationPage.hotelId,
          DEFAULT_SELECTOR_TIMEOUT,
        );
        const id = hotelIdElement?.getAttribute('content');
        if (id) {
          return id;
        }
        return null;
      } catch (error) {
        logger.warn('Error getting hotel ID from content:', error);
        return null;
      }
    }
    async getHotelNameFromContent() {
      try {
        const hotelNameElement = await querySelectorAsync(
          SELECTORS.expedia.accommodationPage.hotelName,
          DEFAULT_SELECTOR_TIMEOUT,
        );
        const name = hotelNameElement?.getAttribute('content');
        if (name) {
          return name;
        }
        return null;
      } catch (error) {
        logger.warn('Error getting hotel name from content:', error);
        return null;
      }
    }
    getPriceDisplayStrategy() {
      return 'ALL_INCLUSIVE';
    }
    getSearchContextFromUrl() {
      const urlParams = new URLSearchParams(window.location.search);
      const checkInParam = urlParams.get(SELECTORS.expedia.accommodationPage.urlParams.checkInDate);
      const checkOutParam = urlParams.get(SELECTORS.expedia.accommodationPage.urlParams.checkOutDate);
      const currencyParam = urlParams.get(SELECTORS.expedia.accommodationPage.urlParams.currency);
      const checkIn = checkInParam ? new Date(checkInParam) : null;
      const checkOut = checkOutParam ? new Date(checkOutParam) : null;
      let formattedCheckInDate;
      let formattedCheckOutDate;
      if (checkIn) {
        formattedCheckInDate = formatDateForAPI(checkIn);
      }
      if (checkOut) {
        formattedCheckOutDate = formatDateForAPI(checkOut);
      }
      return {
        checkInDate: formattedCheckInDate,
        checkOutDate: formattedCheckOutDate,
        currency: currencyParam ?? void 0,
      };
    }
  }
  class ExpediaSearchResultsPageAdapter extends SearchResultsPageAdapter {
    constructor(hotelIdProvider = 'EXPEDIA') {
      const selectors = SELECTORS.expedia.searchResultsPage;
      super({
        selectors: {
          hotelCard: selectors.hotelCard.wrapper,
          hotelTitle: selectors.hotelCard.title,
          inlineButtonMountingPoint: selectors.hotelCard.buttonMountingPoint,
          hotelCardsWrapper: selectors.hotelCardsWrapper,
        },
        buttonOptions: {
          place: 'prepend',
          platform: 'EXPEDIA',
        },
        hotelIdProvider,
      });
    }
    getCardExtraCharges() {
      return null;
    }
    getSearchContextFromUrl() {
      logger.info('starting getSearchContextFromUrl');
      const selectors = SELECTORS.expedia.searchResultsPage.urlParams;
      const urlParams = new URLSearchParams(window.location.search);
      const checkInParam = urlParams.get(selectors.checkInDate);
      const checkOutParam = urlParams.get(selectors.checkOutDate);
      const currencyParam = urlParams.get(selectors.currency);
      const checkIn = checkInParam ? new Date(checkInParam) : null;
      const checkOut = checkOutParam ? new Date(checkOutParam) : null;
      let checkInDate;
      let checkOutDate;
      if (checkIn) {
        checkInDate = formatDateForAPI(checkIn);
      }
      if (checkOut) {
        checkOutDate = formatDateForAPI(checkOut);
      }
      const adultsCountArray = urlParams
        .get(SELECTORS.expedia.searchResultsPage.urlParams.adultsAmount)
        ?.split(',')
        .map(Number);
      const adultsCount = adultsCountArray?.length ? adultsCountArray.reduce((acc, curr) => acc + curr, 0) : void 0;
      const childrenAgesArray = urlParams
        .get(SELECTORS.expedia.searchResultsPage.urlParams.childrenArray)
        ?.split(',')
        .flatMap(entry => {
          const [, age] = entry.split('_').map(Number);
          return [age];
        });
      const childrenArrayIsInvalid =
        Boolean(childrenAgesArray?.some(isNaN)) || childrenAgesArray?.length === 0 || childrenAgesArray == null;
      if (childrenArrayIsInvalid) {
        logger.warn('Children ages array is invalid:', childrenAgesArray);
      }
      const numberOfChildren = childrenArrayIsInvalid ? 0 : childrenAgesArray.length;
      logger.info(`Number of children: ${numberOfChildren}`);
      logger.info(`Children array: ${childrenAgesArray?.toString()}`);
      return {
        checkInDate,
        checkOutDate,
        numberOfAdults: adultsCount,
        childrenAges: childrenArrayIsInvalid ? [] : childrenAgesArray,
        numberOfChildren,
        currency: currencyParam ?? void 0,
      };
    }
    getCurrencyFromHotelCards() {
      const allLinks = [...document.querySelectorAll('a')];
      const linksWithCurrency = allLinks
        .filter(link => link.href.includes(SELECTORS.expedia.accommodationPage.urlParams.currency))
        .map(link => link.href);
      const currenciesFromLinks = linksWithCurrency.map(link => {
        const url = new URL(link);
        const currency = url.searchParams.get(SELECTORS.expedia.accommodationPage.urlParams.currency);
        return currency;
      });
      const uniqueCurrencies = [...new Set(currenciesFromLinks)];
      if (uniqueCurrencies.length > 0) {
        return uniqueCurrencies[0];
      }
      return null;
    }
    async getCurrencyFromContent() {
      const priceElement = await querySelectorAsync(SELECTORS.expedia.common.header.currency, DEFAULT_SELECTOR_TIMEOUT);
      if (priceElement) {
        const priceText = priceElement.textContent?.trim() || '';
        const currencyMatch = priceText.match(/([^\d\s.,]+)/);
        return currencyMatch ? currencyMatch[1].trim() : null;
      }
      return this.getCurrencyFromHotelCards();
    }
    async getRoomsFromContent() {
      const adultsInputElements = await querySelectorAllAsync(
        SELECTORS.expedia.accommodationPage.adultsInput,
        DEFAULT_SELECTOR_TIMEOUT,
      );
      const roomsCount = adultsInputElements.length;
      return roomsCount;
    }
    getCardPriceDisplayMode() {
      return 'ALL_INCLUSIVE';
    }
    getHotelPriceFromHotelCard(card) {
      const priceElements = [...card.querySelectorAll(SELECTORS.expedia.searchResultsPage.hotelCard.price)].map(
        element => {
          const pricesArray = extractPricesFromText(element.innerText).map(num =>
            removeEverythingButNumbers(num.toString()),
          );
          const numberInElement = Math.max(...pricesArray);
          return {
            element,
            number: numberInElement,
          };
        },
      );
      const numbersFromElements = priceElements.map(element => element.number).filter(number => number > 0);
      const highestNumber = Math.max(...numbersFromElements);
      const price = highestNumber;
      return price;
    }
    getHotelIdFromHotelCard(card) {
      const linkElement = card.querySelector(SELECTORS.expedia.searchResultsPage.hotelCard.anchor);
      const link = linkElement?.href;
      const id = link?.match(/\.h(\d+)\./)?.at(1);
      return id || null;
    }
  }
  class HotelsAccommodationPageAdapter extends ExpediaAccommodationPageAdapter {
    constructor() {
      super();
    }
  }
  class HotelsSearchResultsAdapter extends ExpediaSearchResultsPageAdapter {
    constructor() {
      super();
    }
    getHotelIdFromHotelCard(card) {
      const linkElement = [...card.querySelectorAll('a')].find(link2 => link2.href.includes('expediaPropertyId='));
      const link = linkElement?.href;
      const id = link?.match(/expediaPropertyId=(\d+)/)?.at(1);
      return id || null;
    }
  }
  const kayakPriceTypes = ['total', 'nightly-base', 'nightly-total'];
  const assertKayakPriceType = value => {
    if (!value || !kayakPriceTypes.includes(value)) {
      logger.warn('Selected option is not a valid Kayak price type:', value);
      throw new Error(`Invalid Kayak price type: ${value}`);
    }
    return value;
  };
  const inferPriceDisplayStrategyFromKayakPriceType = kayakPriceType => {
    switch (kayakPriceType) {
      case 'nightly-base':
        return 'BASE_ONLY';
      case 'nightly-total':
      case 'total':
      default:
        return 'ALL_INCLUSIVE';
    }
  };
  const isNightlyPricing = kayakPriceType => {
    return kayakPriceType === 'nightly-base' || kayakPriceType === 'nightly-total';
  };
  const get = (object, path) => {
    const pathParts = path.split('.');
    let current = object;
    for (const part of pathParts) {
      if (typeof current === 'object' && current !== null && part in current) {
        current = current[part];
      } else {
        return void 0;
      }
    }
    return current;
  };
  const getKayakDataFromHydrationPayload = async () => {
    const hydrationData = await querySelectorAsync(
      SELECTORS.kayak.common.hydrationDataPayload,
      DEFAULT_SELECTOR_TIMEOUT,
    );
    const parsedData = JSON.parse(hydrationData?.innerHTML || '{}');
    const currencyCode = get(parsedData, 'serverData.locale.currency.code') || null;
    const priceTypeRaw = get(parsedData, 'serverData.HotelDetailsData.priceType') || null;
    const priceType = priceTypeRaw ? assertKayakPriceType(priceTypeRaw) : null;
    const country = get(parsedData, 'serverData.contentState.hotelSchema.address.addressCountry') || null;
    const city = get(parsedData, 'serverData.contentState.overview.localizedCityName') || null;
    return { currencyCode, priceType, country, city };
  };
  const isStringUriEncoded = string => {
    return string !== decodeURIComponent(string);
  };
  const getAlwaysDecodedUriComponent = string => {
    if (isStringUriEncoded(string)) {
      return decodeURIComponent(string);
    }
    return string;
  };
  const getLatLngFromKayakBounds = bounds => {
    const [x1, y1, x2, y2] = bounds.split(',');
    return {
      lng: (parseFloat(y1) + parseFloat(y2)) / 2,
      lat: (parseFloat(x1) + parseFloat(x2)) / 2,
    };
  };
  const getKayakDataFromUrl = () => {
    const url = new URL(window.location.href);
    const pathname = url.pathname;
    const parts = pathname.split('/').filter(Boolean);
    const locationRaw = getAlwaysDecodedUriComponent(parts[1]);
    const locationParts = locationRaw.split(',');
    const countryRaw = locationParts[locationParts.length - 1];
    const countryParts = countryRaw.split('-');
    const filteredCountryParts = countryParts.filter(part => !!part.match(/^\D*$/) || part === 'details');
    const country = filteredCountryParts.length > 0 ? filteredCountryParts.join(' ') : '';
    const checkInDate = parts[2];
    const checkOutDate = parts[3];
    const roomsRaw = pathname.match(/(\d)rooms/)?.[1];
    const numberOfRooms = roomsRaw ? Number(roomsRaw) : void 0;
    const adultsRaw = pathname.match(/(\d)adults/)?.[1];
    const numberOfAdults = adultsRaw ? Number(adultsRaw) : void 0;
    const childrenAgesRaw = pathname.match(/\dchildren(.+?)(?:\/|$)/)?.[1];
    const childrenAgesParts = childrenAgesRaw?.split('-');
    const childrenAges = childrenAgesParts ? childrenAgesParts.slice(1).map(age => parseInt(age)) : [];
    const numberOfChildrenRaw = pathname.match(/(\d)children.+?(?:\/|$)/)?.[1];
    const numberOfChildren = numberOfChildrenRaw ? Number(numberOfChildrenRaw) : void 0;
    const fsRaw = url.searchParams.get('fs');
    const fs = new URLSearchParams(fsRaw || {});
    const bounds = fs.get('mbounds');
    const latLng = bounds ? getLatLngFromKayakBounds(bounds) : null;
    return {
      checkInDate,
      checkOutDate,
      numberOfAdults,
      numberOfChildren,
      numberOfRooms,
      country,
      childrenAges,
      ...latLng,
    };
  };
  const getPricePerNight = ({ price, checkIn, checkOut }) => {
    const days = daysBetween(checkIn, checkOut);
    if (days === 0) {
      return price;
    }
    return price / days;
  };
  class KayakAccommodationPageAdapter extends AccommodationPageAdapter {
    constructor() {
      super('OTHER');
      __publicField(this, 'kayakPriceType', null);
    }
    async getHotelIdFromContent() {
      return showNotImplementedMessageAsync('getHotelIdFromContent');
    }
    async getHotelNameFromContent() {
      try {
        const hotelNameElement = await querySelectorAsync(
          SELECTORS.kayak.accommodationPage.hotelName,
          DEFAULT_SELECTOR_TIMEOUT,
        );
        const name = hotelNameElement?.textContent?.trim() || null;
        return name;
      } catch (error) {
        logger.error('Error getting hotel name from content:', error);
        return null;
      }
    }
    async initializeKayakPriceType() {
      const url = new URL(window.location.href);
      const priceTypeFromUrl = url.searchParams.get('pm');
      const { priceType: priceTypeFromHydrationPayload } = await getKayakDataFromHydrationPayload();
      const priceType = priceTypeFromUrl ? assertKayakPriceType(priceTypeFromUrl) : priceTypeFromHydrationPayload;
      if (!priceType) {
        logger.warn('Failed to get price type from content');
        throw new Error('Failed to get price type from content');
      }
      this.kayakPriceType = priceType;
    }
    async initializeAdapter() {
      try {
        if (!this.kayakPriceType) {
          logger.info('Initializing Kayak price type');
          await this.initializeKayakPriceType();
        }
        await super.initializeAdapter();
      } catch (error) {
        const errorMessage = error instanceof Error ? error.message : String(error);
        logger.error('Error initializing Kayak accommodation adapter:', errorMessage);
        this.removeUI();
      }
    }
    getPriceDisplayStrategy() {
      return inferPriceDisplayStrategyFromKayakPriceType(this.kayakPriceType);
    }
    async getCheapestRoomPriceFromContent() {
      const priceText = await querySelectorAsync(SELECTORS.kayak.accommodationPage.price, 15e3);
      if (priceText === null || priceText === void 0) {
        logger.warn('Price element not found on the page');
        throw new Error('Price element not found on the page');
      }
      const priceTextContent = priceText.textContent?.trim() || '';
      const price = removeEverythingButNumbers(priceTextContent);
      if (isNaN(price) || price <= 0) {
        logger.error('Failed to extract price from the content');
        throw new Error('Failed to extract price from the content');
      }
      let finalPrice = price;
      if (this.isNightlyPricing()) {
        const days = getDateDiffInDays(new Date(this.checkIn), new Date(this.checkOut));
        const wholeStayPrice = price * days;
        finalPrice = wholeStayPrice;
      }
      return {
        price: finalPrice,
        charges: 0,
        // Kayak does not provide a breakdown of charges in the price element
        // so we assume charges are 0 for now
      };
    }
    async getCurrencyFromContent() {
      const { currencyCode } = await getKayakDataFromHydrationPayload();
      return currencyCode;
    }
    async getCountryFromContent() {
      const { country } = await getKayakDataFromHydrationPayload();
      return country;
    }
    async getCityFromContent() {
      const { city } = await getKayakDataFromHydrationPayload();
      return city;
    }
    getSearchContextFromUrl() {
      const kayakData = getKayakDataFromUrl();
      return kayakData;
    }
    isNightlyPricing() {
      return isNightlyPricing(this.kayakPriceType);
    }
    updateCommonButton(params) {
      let price = params.bestOfferPrice;
      if (this.isNightlyPricing()) {
        price = getPricePerNight({ price, checkIn: this.checkIn, checkOut: this.checkOut });
      }
      super.updateCommonButton({ ...params, bestOfferPrice: price });
    }
    updateStickyButton(params) {
      let price = params.bestOfferPrice;
      if (this.isNightlyPricing()) {
        price = getPricePerNight({ price, checkIn: this.checkIn, checkOut: this.checkOut });
      }
      super.updateStickyButton({
        ...params,
        bestOfferPrice: price,
      });
    }
    updateTableButton(bestOfferPrice, isBestOffer, currency, inlineButtonTrackingContext) {
      let price = bestOfferPrice;
      if (this.isNightlyPricing()) {
        price = getPricePerNight({ price, checkIn: this.checkIn, checkOut: this.checkOut });
      }
      updateTableButton({
        bestOfferPrice: price,
        isBestOffer,
        currency,
        trackingContext: inlineButtonTrackingContext,
      });
    }
    // ui
    async createUI() {
      createStickyButton();
      const { topHeader, fixedHeader, navigationLeer } = SELECTORS.kayak.accommodationPage.buttonMountingPoint;
      const topHeaderElement = await querySelectorAsync(topHeader, 12e4);
      const topHeaderButton = createCardButton();
      topHeaderButton.classList.add('hermes-kayak-accommodation-page-top-header-button');
      topHeaderElement.append(topHeaderButton);
      const fixedHeaderElement = await querySelectorAsync(fixedHeader, 12e4);
      fixedHeaderElement.style.position = 'relative';
      const navigationLeerElement = await querySelectorAsync(navigationLeer, 12e4);
      navigationLeerElement.style.clipPath = 'inset(0px -10px -25px -10px)';
      createTableButton({
        mountingPointElement: fixedHeaderElement,
        classNames: {
          container: ['hermes-kayak-accommodation-page-fixed-header-button'],
        },
      });
    }
    async updateUI({ isBestOffer, pluginViewData, price, inlineButtonTrackingContext }) {
      this.updateStickyButton({
        bestOfferPrice: price,
        isBestOffer,
        currency: this.currency,
        trackingContext: inlineButtonTrackingContext,
      });
      updatePopup(pluginViewData);
      try {
        const { topHeader } = SELECTORS.kayak.accommodationPage.buttonMountingPoint;
        const topHeaderElement = await querySelectorAsync(topHeader, 12e4);
        this.updateCommonButton({
          parent: topHeaderElement,
          bestOfferPrice: price,
          isBestOffer,
          currency: this.currency,
          pluginViewData,
          trackingContext: inlineButtonTrackingContext,
        });
        this.updateTableButton(price, isBestOffer, this.currency, inlineButtonTrackingContext);
      } catch (error) {
        logger.warn('Error updating card button:', error);
      }
    }
    removeUI() {
      const inlineButtons = document.querySelectorAll('.hermes-search-result-badge');
      inlineButtons.forEach(button => {
        removeCardButton(button);
      });
      removeStickyButton();
      super.removeUI();
    }
    getToolbarProps() {
      return {
        ...super.getToolbarProps(),
        kayakPricingMode: this.kayakPriceType,
      };
    }
  }
  async function waitForElementDoesntExist(selector, options2 = {}) {
    const { timeout } = options2;
    return new Promise((resolve, reject) => {
      let timeoutId = null;
      const checkAndMaybeResolve = () => {
        const element = document.querySelector(selector);
        if (!element) {
          if (timeoutId) {
            clearTimeout(timeoutId);
          }
          observer.disconnect();
          resolve();
        }
      };
      checkAndMaybeResolve();
      const observer = new MutationObserver(checkAndMaybeResolve);
      observer.observe(document.body, {
        childList: true,
        subtree: true,
      });
      if (timeout !== void 0) {
        timeoutId = setTimeout(() => {
          observer.disconnect();
          reject(new Error(`Timeout: element "${selector}" still exists after ${timeout}ms`));
        }, timeout);
      }
    });
  }
  const openDropdown = async () => {
    try {
      const priceTypeDropdownTrigger = await querySelectorAsync(
        SELECTORS.kayak.searchResultsPage.priceType.trigger,
        5e3,
      );
      if (!priceTypeDropdownTrigger) {
        throw new Error('Price type dropdown trigger not found');
      }
      priceTypeDropdownTrigger.click();
    } catch (error) {
      logger.error('Error opening price type dropdown:', error);
      throw new Error('Failed to open price type dropdown');
    }
  };
  const getPriceTypeFromDropdown = async () => {
    try {
      const priceTypeDropdown = await querySelectorAsync(SELECTORS.kayak.searchResultsPage.priceType.dropdown, 5e3);
      if (!priceTypeDropdown) {
        throw new Error('Price type dropdown not found');
      }
      const selectedOption = priceTypeDropdown.getAttribute(
        SELECTORS.kayak.searchResultsPage.priceType.dropdownValueAttribute,
      );
      if (!selectedOption) {
        throw new Error('Selected option in price type dropdown not found');
      }
      const priceType = assertKayakPriceType(selectedOption);
      return priceType;
    } catch (error) {
      logger.warn('Error getting price type from dropdown:', error);
      throw new Error('Failed to get price type from dropdown');
    }
  };
  const closeDropdown = async () => {
    try {
      const priceTypeDropdown = await querySelectorAsync(SELECTORS.kayak.searchResultsPage.priceType.dropdown, 5e3);
      if (!priceTypeDropdown) {
        throw new Error('Price type dropdown not found');
      }
      const closeModalEvent = new KeyboardEvent('keydown', {
        key: 'Escape',
        code: 'Escape',
        keyCode: 27,
        bubbles: true,
        cancelable: true,
      });
      priceTypeDropdown.dispatchEvent(closeModalEvent);
      try {
        await waitForElementDoesntExist(SELECTORS.kayak.searchResultsPage.priceType.dropdown, {
          timeout: 1e3,
        });
      } catch (error) {
        logger.warn('Error waiting for price type dropdown to close, dispatching close dropdown event again', error);
        document.body.dispatchEvent(closeModalEvent);
      }
    } catch (error) {
      logger.warn('Error closing price type dropdown:', error);
      throw new Error('Failed to close price type dropdown');
    }
  };
  const getPriceTypeFromContent = async () => {
    try {
      await openDropdown();
      const priceType = await getPriceTypeFromDropdown();
      await closeDropdown();
      logger.info('Selected Kayak price type:', priceType);
      return priceType;
    } catch (error) {
      logger.warn('Error getting price type from content:', error);
      return null;
    }
  };
  const initializePriceTypeChangeListener = onPriceTypeChange => {
    const priceTypeChangeHandler = event => {
      const target = event.target;
      if (!target) {
        return;
      }
      const optionElement = target.closest('li[role="option"]');
      if (!optionElement) {
        return;
      }
      const optionId = optionElement.id;
      if (kayakPriceTypes.includes(optionId)) {
        onPriceTypeChange(optionId);
      }
    };
    document.addEventListener('click', priceTypeChangeHandler, true);
    window.addEventListener('beforeunload', () => {
      document.removeEventListener('click', priceTypeChangeHandler, true);
    });
  };
  const waitForClassRemoved = (element, className, options2 = {}) => {
    const { classNameFuzzyMatch = false, timeout = 3e4 } = options2;
    return new Promise((resolve, reject) => {
      const cleanup = () => {
        clearTimeout(timer);
        observer.disconnect();
      };
      const observer = new MutationObserver(mutations => {
        for (const mutation of mutations) {
          if (mutation.type === 'attributes' && mutation.attributeName === 'class') {
            const target = mutation.target;
            let classRemoved = false;
            if (classNameFuzzyMatch) {
              classRemoved = !Array.from(target.classList).some(cls => cls.includes(className));
            } else {
              classRemoved = !target.classList.contains(className);
            }
            if (classRemoved) {
              cleanup();
              resolve();
            }
          }
        }
      });
      observer.observe(element, {
        attributes: true,
        attributeFilter: ['class'],
      });
      const timer = setTimeout(() => {
        cleanup();
        reject(new Error(`Timeout waiting for class "${className}" to be removed`));
      }, timeout);
    });
  };
  class KayakSearchResultsPageAdapter extends SearchResultsPageAdapter {
    constructor() {
      const selectors = SELECTORS.kayak.searchResultsPage;
      super({
        selectors: {
          hotelCard: selectors.hotelCard.wrapper,
          hotelTitle: selectors.hotelCard.title,
          inlineButtonMountingPoint: selectors.hotelCard.buttonMountingPoint,
        },
        buttonOptions: {
          place: 'append',
          className: ['hermes-kayak-search-page-button'],
        },
      });
      __publicField(this, 'kayakPriceType', null);
    }
    getSearchContextFromUrl() {
      const kayakData = getKayakDataFromUrl();
      return kayakData;
    }
    async getCurrencyFromContent() {
      const { currencyCode } = await getKayakDataFromHydrationPayload();
      return currencyCode;
    }
    getCardExtraCharges() {
      return null;
    }
    getHotelPriceFromHotelCard(card) {
      const priceText = card.querySelector(SELECTORS.kayak.searchResultsPage.hotelCard.price)?.textContent;
      const price = priceText ? removeEverythingButNumbers(priceText) : null;
      if (price === null || price === void 0 || isNaN(price)) {
        logger.warn('Cant extract price from card:', card);
        throw new Error('Not able to extract price from card');
      }
      if (this.isNightlyPricing()) {
        const days = getDateDiffInDays(new Date(this.checkIn), new Date(this.checkOut));
        const wholeStayPrice = price * days;
        return wholeStayPrice;
      }
      return price;
    }
    async initializeKayakPriceType() {
      let priceType = null;
      const { priceType: priceTypeFromHydrationPayload } = await getKayakDataFromHydrationPayload();
      if (priceTypeFromHydrationPayload) {
        priceType = priceTypeFromHydrationPayload;
      } else {
        const priceTypeFromDropdown = await getPriceTypeFromContent();
        priceType = priceTypeFromDropdown;
      }
      if (!priceType) {
        logger.warn('Failed to get price type from content');
        throw new Error('Failed to get price type from content');
      }
      this.kayakPriceType = priceType;
    }
    async waitUntilPageStopsLoading() {
      const filters = document.querySelector(SELECTORS.kayak.searchResultsPage.resultFiltersWrapperLoading);
      if (!filters) {
        logger.warn('No filters found, assuming page is already loaded');
        return;
      }
      logger.info('Waiting for Kayak search results page to stop loading...');
      try {
        await waitForClassRemoved(filters, 'mod-loading', {
          classNameFuzzyMatch: true,
          timeout: 3e4,
          // Wait up to 30 seconds for the loading to finish
        });
        logger.info('Kayak search results page has stopped loading');
      } catch (error) {
        logger.error('Error while waiting for Kayak search results page to stop loading:', error);
        throw new Error('Failed to wait for Kayak search results page to stop loading');
      }
    }
    reinstallWholeAdapter() {
      logger.info('Reinstalling KayakSearchResultsPageAdapter');
      void (async () => {
        await this.waitUntilPageStopsLoading();
        super.reinstallWholeAdapter();
      })();
    }
    async initializeSiteAdapterRequiredProperties() {
      await this.waitUntilPageStopsLoading();
      if (this.kayakPriceType === null) {
        logger.info('Initializing Kayak price type');
        await this.initializeKayakPriceType();
      }
      await super.initializeSiteAdapterRequiredProperties();
    }
    async initializeSearchResultsAdapter() {
      try {
        await this.waitUntilPageStopsLoading();
        if (this.kayakPriceType === null) {
          logger.info('Initializing Kayak price type in SearchResultsAdapter');
          await this.initializeKayakPriceType();
        }
        await super.initializeSearchResultsAdapter();
        initializePriceTypeChangeListener(newPriceType => {
          logger.info('Price Type Select changed, re-initializing adapter');
          this.kayakPriceType = newPriceType;
          this.reinstallWholeAdapter();
        });
      } catch (error) {
        const errorMessage = error instanceof Error ? error.message : String(error);
        logger.error('Error initializing Kayak search results adapter:', errorMessage);
        if (this.hotelCardObserver) {
          this.hotelCardObserver.disconnect();
        }
      }
    }
    getCardPriceDisplayMode() {
      return inferPriceDisplayStrategyFromKayakPriceType(this.kayakPriceType);
    }
    isNightlyPricing() {
      return isNightlyPricing(this.kayakPriceType);
    }
    updateCommonButton(props) {
      let price = props.bestOfferPrice;
      if (this.isNightlyPricing()) {
        const days = getDateDiffInDays(new Date(this.checkIn), new Date(this.checkOut));
        price = price / days;
      }
      super.updateCommonButton({ ...props, bestOfferPrice: price });
    }
    getToolbarProps() {
      return {
        ...super.getToolbarProps(),
        kayakPricingMode: this.kayakPriceType,
      };
    }
  }
  const waitUntilElementSettles = async (selectors, { settleTime = 300, paths } = {}) => {
    const selectorArray = Array.isArray(selectors) ? selectors : [selectors];
    const elements = selectorArray.map(selector => Array.from(document.querySelectorAll(selector))).flat();
    if (elements.length === 0) {
      throw new Error(`No elements found for selectors: ${selectorArray.join(', ')}`);
    }
    return new Promise((resolve, reject) => {
      const observers = [];
      let timeout = null;
      const validatePaths = () => {
        if (paths === void 0 || paths.length === 0) {
          return true;
        }
        const missingPaths = paths.filter(path => {
          const elements2 = document.querySelectorAll(path);
          return elements2.length === 0;
        });
        if (missingPaths.length > 0) {
          throw new Error(`Required paths not found: ${missingPaths.join(', ')}`);
        }
        return true;
      };
      const resetTimer = () => {
        if (timeout) {
          logger.info(
            `(waitUntilElementSettles) Elements are still changing, waiting another ${settleTime}ms for them to settle...`,
            selectors,
          );
          clearTimeout(timeout);
        }
        try {
          validatePaths();
        } catch (error) {
          observers.forEach(observer => observer.disconnect());
          if (timeout) {
            clearTimeout(timeout);
          }
          logger.warn(error);
          reject(new Error(`(waitUntilElementSettles) Path validation failed, no path matches: ${paths?.join(', ')}`));
          return;
        }
        timeout = setTimeout(() => {
          logger.info('(waitUntilElementSettles) Elements have settled, resolving promise...', selectors);
          observers.forEach(observer => observer.disconnect());
          resolve();
        }, settleTime);
      };
      for (const element of elements) {
        const observer = new MutationObserver(() => {
          resetTimer();
        });
        observer.observe(element, {
          attributes: true,
          childList: true,
          subtree: true,
          characterData: true,
        });
        observers.push(observer);
      }
      resetTimer();
    });
  };
  class DebugNotificationElement extends HTMLElement {
    constructor() {
      super();
      __publicField(this, 'timeoutId', null);
      this.attachShadow({ mode: 'open' });
    }
    static get observedAttributes() {
      return ['message', 'type'];
    }
    connectedCallback() {
      logger.info('Debug notification element connected');
      this.render();
      this.setupEventListeners();
    }
    attributeChangedCallback(name) {
      if (name === 'message' || name === 'type') {
        this.render();
      }
    }
    render() {
      if (!this.shadowRoot) {
        logger.error('Shadow root not initialized');
        return;
      }
      const message = this.getAttribute('message') || '';
      const type = this.getAttribute('type') || 'info';
      const formattedMessage = message
        .split('\n')
        .map(line => line.trim())
        .join('<br>');
      this.shadowRoot.innerHTML = `
        <style>
            :host {
                display: block;
                width: 300px;
                margin-bottom: 10px;
                background: var(--notification-bg, #ffffff);
                border-radius: 4px;
                box-shadow: 0 2px 4px rgba(0,0,0,0.1);
                font-family: system-ui, -apple-system, sans-serif;
            }

            .notification {
                position: relative;
            }

            .header {
                padding: 8px 12px;
                background: var(--header-bg, #f5f5f5);
                border-bottom: 1px solid #eee;
                border-radius: 4px 4px 0 0;
                display: flex;
                justify-content: space-between;
                align-items: center;
            }

            .title {
                font-size: 12px;
                color: #666;
                font-weight: 500;
            }

            .close-button {
                background: none;
                border: none;
                cursor: pointer;
                padding: 4px 8px;
                color: #666;
                font-size: 16px;
            }

            .message {
                padding: 12px;
                color: #333;
                word-break: break-word;
                white-space: pre-line;
                line-height: 1.4;
                background: var(--notification-bg, #ffffff);
            }

            .notification[data-type="error"] {
                --notification-bg: #fff2f0;
                --header-bg: #fff1f0;
            }

            .notification[data-type="warning"] {
                --notification-bg: #fffbe6;
                --header-bg: #fffbe6;
            }

            .notification[data-type="success"] {
                --notification-bg: #f6ffed;
                --header-bg: #f6ffed;
            }

            .wrapper {
            background: repeating-linear-gradient(
                45deg,
                yellow,
                yellow 10px,
                lime 10px,
                lime 20px
              );
              padding: 4px;
              border-radius: 6px;
              box-shadow: 0 2px 14px rgba(0,0,0,0.4);
            }

           
        </style>
        <div class="wrapper">
          <div class="notification" data-type="${type}">
              <div class="header">
                  <span class="title">Dev Mode Notification</span>
                  <button class="close-button" aria-label="Close notification">×</button>
              </div>
              <div class="message">${formattedMessage}</div>
          </div>
        </div>
    `;
    }
    setupEventListeners() {
      const closeButton = this.shadowRoot?.querySelector('.close-button');
      closeButton?.addEventListener('click', () => {
        this.remove();
      });
    }
    startTimeout(duration) {
      this.timeoutId = window.setTimeout(() => {
        this.remove();
      }, duration);
    }
    disconnectedCallback() {
      if (this.timeoutId !== null) {
        window.clearTimeout(this.timeoutId);
        this.timeoutId = null;
      }
    }
  }
  customElements.define('debug-notification', DebugNotificationElement);
  const getAllDealsFromContent = async () => {
    const { dealElement, listSettled, moreDealsButton } = SELECTORS.tripadvisor.accommodationPage.deals;
    await waitUntilElementSettles(listSettled, {
      settleTime: 3e3,
    });
    logger.warn('getAllDealsFromContent function can only detect breakfast included deals in ENGLISH ONLY');
    try {
      const viewMoreButton = await querySelectorAsync(moreDealsButton, 3e3);
      const viewMoreButtonContainsNumbers = /\d/.test(viewMoreButton.innerText);
      if (viewMoreButtonContainsNumbers) {
        viewMoreButton.click();
      }
    } catch (error) {
      logger.warn('View more deals button not found', error);
    }
    await querySelectorAsync(dealElement, 3e3);
    const dealsLinks = [...document.querySelectorAll(dealElement)];
    const deals = dealsLinks.map(link => {
      const vendorName = link.getAttribute(SELECTORS.tripadvisor.accommodationPage.deals.vendorAttribute);
      const priceText = link.innerText.split('\n').at(-2);
      if (!priceText) {
        logger.warn('Price text not found for element', link);
        throw new Error('Price text not found for element');
      }
      const lowestPrice = Math.min(...extractPricesFromText(priceText));
      if (!vendorName) {
        logger.warn('Vendor name not found for element', link);
        throw new Error('Vendor name not found for element');
      }
      return {
        vendorName,
        price: lowestPrice,
        element: link,
      };
    });
    logger.info('Deals found', deals);
    return deals;
  };
  const extractDateFromDateInput = text => {
    try {
      const currentDate = /* @__PURE__ */ new Date();
      const checkInDateWithCurrentYear = /* @__PURE__ */ new Date(`${text} ${currentDate.getFullYear()}`);
      const dateWithCurrentYearIsInPast = checkInDateWithCurrentYear.getTime() < currentDate.getTime();
      if (dateWithCurrentYearIsInPast) {
        checkInDateWithCurrentYear.setFullYear(currentDate.getFullYear() + 1);
      }
      const formattedDate = formatDateForAPI(checkInDateWithCurrentYear);
      logger.info('Extracted-date:', formattedDate);
      return formattedDate;
    } catch (error) {
      logger.warn('Error extracting date from input:', error);
      return null;
    }
  };
  const getDateFromContentInput = async (selector, type) => {
    const dateElement = await querySelectorAsync(selector, 1e3);
    logger.selector(selector);
    const dateText = dateElement.textContent;
    if (!dateText) {
      logger.warn(`${type} date text is empty or not found.`);
      return null;
    }
    return extractDateFromDateInput(dateText.toString());
  };
  const getCheckInDateFromContent = async () => {
    const selector = SELECTORS.tripadvisor.common.filters.checkInDate;
    return getDateFromContentInput(selector, 'check-in');
  };
  const getCheckOutDateFromContent = async () => {
    const selector = SELECTORS.tripadvisor.common.filters.checkOutDate;
    return getDateFromContentInput(selector, 'check-out');
  };
  const getDateFromContent = async () => {
    const [checkInResult, checkOutResult] = await Promise.allSettled([
      getCheckInDateFromContent(),
      getCheckOutDateFromContent(),
    ]);
    const checkInDate = checkInResult.status === 'fulfilled' ? checkInResult.value : null;
    const checkOutDate = checkOutResult.status === 'fulfilled' ? checkOutResult.value : null;
    return {
      checkInDate,
      checkOutDate,
    };
  };
  const getGuestsFromContent = async () => {
    try {
      const { adultsInput, childrenInput, childrenAgesInput, guestsInput } =
        SELECTORS.tripadvisor.common.filters.guests;
      const guests = await querySelectorAsync(guestsInput, DEFAULT_SELECTOR_TIMEOUT);
      guests.click();
      const adultsPromise = querySelectorAsync(adultsInput, DEFAULT_SELECTOR_TIMEOUT);
      const childrenPromise = querySelectorAsync(childrenInput, DEFAULT_SELECTOR_TIMEOUT);
      const [adults, children] = await Promise.all([adultsPromise, childrenPromise]);
      const adultsCount = Number(adults?.textContent);
      const childrenCount = Number(children?.textContent);
      let childrenAges = [];
      if (isNaN(adultsCount) || isNaN(childrenCount)) {
        logger.warn('Invalid adults or children count:', { adultsCount, childrenCount });
        return null;
      }
      if (childrenCount > 0) {
        const agesInputs = [...document.querySelectorAll(childrenAgesInput)];
        const agesFromInputs = agesInputs
          .map(input => {
            const age = Number(input.value);
            return age;
          })
          .filter(age => !isNaN(age));
        if (agesFromInputs.length === childrenCount) {
          childrenAges = agesFromInputs;
        }
      }
      const closeGuestsPopoverEvent = new KeyboardEvent('keydown', {
        key: 'Escape',
        code: 'Escape',
        keyCode: 27,
        bubbles: true,
        cancelable: true,
      });
      adults.dispatchEvent(closeGuestsPopoverEvent);
      return {
        adults: adultsCount,
        children: childrenCount,
        childrenAges,
      };
    } catch (error) {
      logger.warn('Error getting guests from content:', error);
      return null;
    }
  };
  const PRICE_DISPLAY_STRATEGY_BY_DOMAIN = {
    'ar.tripadvisor.com': 'ALL_IN_DAILY',
    'tripadvisor.com.ar': 'BASE_RATE',
    'tripadvisor.com.au': 'ALL_IN_TOTAL_STAY',
    'tripadvisor.at': 'ALL_IN_DAILY',
    'tripadvisor.be': 'ALL_IN_DAILY',
    'tripadvisor.com.br': 'BASE_RATE',
    'tripadvisor.ca': 'BASE_RATE_PLUS_FEES',
    'tripadvisor.cl': 'BASE_RATE',
    'tripadvisor.cn': 'ALL_IN_DAILY',
    'cn.tripadvisor.com': 'ALL_IN_DAILY',
    'tripadvisor.co': 'BASE_RATE',
    'tripadvisor.dk': 'ALL_IN_DAILY',
    'tripadvisor.com.eg': 'ALL_IN_DAILY',
    'tripadvisor.fr': 'ALL_IN_TOTAL_STAY',
    'tripadvisor.de': 'ALL_IN_DAILY',
    'tripadvisor.com.gr': 'ALL_IN_DAILY',
    'en.tripadvisor.com.hk': 'BASE_RATE',
    'tripadvisor.in': 'ALL_IN_DAILY',
    'tripadvisor.co.id': 'BASE_RATE',
    'tripadvisor.ie': 'ALL_IN_DAILY',
    'tripadvisor.co.il': 'BASE_RATE',
    'tripadvisor.it': 'ALL_IN_DAILY',
    'tripadvisor.jp': 'ALL_IN_DAILY',
    'tripadvisor.com.my': 'BASE_RATE',
    'tripadvisor.com.mx': 'BASE_RATE',
    'tripadvisor.co.nz': 'ALL_IN_TOTAL_STAY',
    'no.tripadvisor.com': 'ALL_IN_DAILY',
    'tripadvisor.com.pe': 'BASE_RATE',
    'tripadvisor.com.ph': 'BASE_RATE',
    'tripadvisor.pt': 'ALL_IN_DAILY',
    'tripadvisor.ru': 'ALL_IN_DAILY',
    'tripadvisor.com.sg': 'BASE_RATE',
    'tripadvisor.co.za': 'ALL_IN_DAILY',
    'tripadvisor.co.kr': 'ALL_IN_DAILY',
    'tripadvisor.es': 'ALL_IN_DAILY',
    'tripadvisor.se': 'ALL_IN_DAILY',
    'tripadvisor.ch': 'ALL_IN_DAILY',
    'fr.tripadvisor.ch': 'ALL_IN_DAILY',
    'it.tripadvisor.ch': 'ALL_IN_DAILY',
    'tripadvisor.com.tw': 'BASE_RATE',
    'th.tripadvisor.com': 'BASE_RATE',
    'tripadvisor.nl': 'ALL_IN_DAILY',
    'tripadvisor.com.tr': 'ALL_IN_DAILY',
    'tripadvisor.co.uk': 'ALL_IN_DAILY',
    'tripadvisor.com': 'ALL_IN_TOTAL_STAY',
    'tripadvisor.com.ve': 'BASE_RATE',
    'tripadvisor.com.vn': 'BASE_RATE',
  };
  const getTripadvisorPriceDisplayStrategy = () => {
    const hostname = window.location.hostname.replace('www.', '');
    const strategy = PRICE_DISPLAY_STRATEGY_BY_DOMAIN[hostname];
    return strategy || 'ALL_IN_TOTAL_STAY';
  };
  const pathToRegex = path => {
    const escaped = path
      .replace(/\//g, '\\/')
      .replace(/\*/g, '.*')
      .replace(/:([\w]+)/g, '(?<$1>[^/]+)');
    return new RegExp(`^${escaped}$`, 'i');
  };
  const waitForElementInteractionOrChange = async (selector, options2 = {}) => {
    const { timeout } = options2;
    const element = document.querySelector(selector);
    logger.selector(`(waitForElementInteractionOrChange) selector: "${selector}"`, element);
    if (!element) {
      throw new Error(`Element not found for selector: "${selector}"`);
    }
    return new Promise((resolve, reject) => {
      let settled = false;
      const cleanup = () => {
        settled = true;
        element.removeEventListener('click', onClick);
        observer.disconnect();
        if (timeoutId) {
          clearTimeout(timeoutId);
        }
      };
      const onClick = () => {
        if (!settled) {
          logger.selector(`(waitForElementInteractionOrChange) clicked on element: "${selector}"`, element);
          cleanup();
          resolve();
        }
      };
      const observer = new MutationObserver(() => {
        if (!settled) {
          logger.selector(`(waitForElementInteractionOrChange) element changed: "${selector}"`, element);
          cleanup();
          resolve();
        }
      });
      element.addEventListener('click', onClick);
      observer.observe(element, {
        childList: true,
        subtree: true,
        attributes: true,
        characterData: true,
      });
      let timeoutId = null;
      if (timeout !== void 0) {
        timeoutId = setTimeout(() => {
          if (!settled) {
            cleanup();
            reject(new Error('Timeout waiting for interaction or change'));
          }
        }, timeout);
      }
    });
  };
  const waitUntilUrlMatches = async (paths, options2 = {}) => {
    const { timeout } = options2;
    const doesUrlMatchAnyPath = () => {
      const currentUrl = location.href;
      return paths.some(path => {
        const regex = pathToRegex(path);
        const matches = regex.test(currentUrl);
        if (matches) {
          logger.success(`URL matched pattern: ${path}`);
        }
        return matches;
      });
    };
    if (doesUrlMatchAnyPath()) {
      logger.success('URL already matches one of the patterns');
      return;
    }
    return new Promise((resolve, reject) => {
      let timeoutId;
      if (timeout !== void 0) {
        timeoutId = window.setTimeout(() => {
          cleanup();
          reject(new Error(`URL did not match any of the patterns within ${timeout}ms: ${paths.join(', ')}`));
        }, timeout);
      }
      const cleanup = initializeUrlChangeListener(() => {
        if (doesUrlMatchAnyPath()) {
          cleanup();
          if (timeoutId !== void 0) {
            clearTimeout(timeoutId);
          }
          resolve();
        }
      });
    });
  };
  class TripadvisorAccommodationPageAdapter extends AccommodationPageAdapter {
    constructor() {
      super('OTHER');
    }
    async getHotelIdFromContent() {
      return showNotImplementedMessageAsync('getHotelIdFromContent');
    }
    async getHotelNameFromContent() {
      const hotelName = (await querySelectorAsync('h1#HEADING')).innerText;
      return hotelName.trim();
    }
    getPriceDisplayStrategy() {
      return getTripadvisorPriceDisplayStrategy();
    }
    getSearchContextFromUrl() {
      return {};
    }
    updateCommonButton(props) {
      const days = getDateDiffInDays(new Date(this.checkIn), new Date(this.checkOut));
      const pricePerNight = props.bestOfferPrice / days;
      super.updateCommonButton({ ...props, bestOfferPrice: pricePerNight });
    }
    updateStickyButton(params) {
      const days = getDateDiffInDays(new Date(this.checkIn), new Date(this.checkOut));
      const pricePerNight = params.bestOfferPrice / days;
      super.updateStickyButton({
        ...params,
        bestOfferPrice: pricePerNight,
      });
    }
    async getCheapestDealFromContent() {
      const deals = await getAllDealsFromContent();
      const cheapestDeal = deals.sort((a, b) => a.price - b.price).at(0);
      if (!cheapestDeal) {
        throw new Error('No deals found');
      }
      return cheapestDeal;
    }
    async addButtonToCheapestDeal() {
      const cheapestDeal = await this.getCheapestDealFromContent();
      const priceContainer = cheapestDeal.element.querySelector(
        SELECTORS.tripadvisor.accommodationPage.deals.buttonMountingPoint,
      );
      if (!priceContainer) {
        throw new Error('Mounting point not found');
      }
      priceContainer.append(createCardButton());
    }
    async createUI() {
      await super.createUI();
      try {
        await this.addButtonToCheapestDeal();
      } catch (error) {
        logger.error('Error creating UI:', error);
        if (!pathToRegex(SELECTORS.tripadvisor.accommodationPage.allowedUrl).test(window.location.href)) {
          logger.error('Accommodation URL does not match, removing UI');
          this.removeUI();
        }
      }
    }
    /**
     * Monitors changes in the Tripadvisor filter buttons (check-in, check-out, and room/guest selection) and updates the UI accordingly when filters are modified
     */
    async setupFiltersUpdateListener() {
      try {
        const { buttons, modals } = SELECTORS.tripadvisor.accommodationPage.filters;
        const filterButtonsQuery = buttons;
        const filterModalsQuery = modals.split(',');
        await waitUntilUrlMatches([SELECTORS.tripadvisor.accommodationPage.allowedUrl]);
        logger.info('(setupFiltersUpdateListener) Setting up filters update listener');
        await querySelectorAsync(filterButtonsQuery);
        logger.info('(setupFiltersUpdateListener) Filter buttons are present, waiting for interaction');
        const buttonsChangedPromise = filterButtonsQuery
          .split(',')
          .map(selector => waitForElementInteractionOrChange(selector));
        const buttonInsideListRemovedPromise = waitForElementDoesntExist(
          SELECTORS.tripadvisor.accommodationPage.deals.buttonRemovedPromise,
        );
        await Promise.race([...buttonsChangedPromise, buttonInsideListRemovedPromise]);
        logger.info('(setupFiltersUpdateListener) Filter buttons were interacted with, or changed');
        logger.info('(setupFiltersUpdateListener) Waiting for filter modals to disappear');
        await Promise.allSettled(filterModalsQuery.map(selector => waitForElementDoesntExist(selector)));
        logger.info('(setupFiltersUpdateListener) Filter modals are gone, removing UI, because filters were changed');
        this.removeUI();
        logger.info('(setupFiltersUpdateListener) Waiting for filter buttons to settle');
        await waitUntilElementSettles(filterButtonsQuery, {
          settleTime: 2e3,
          paths: [SELECTORS.tripadvisor.accommodationPage.allowedUrl],
        });
        await this.initializeAdapter();
      } catch (error) {}
    }
    async updateUI({ isBestOffer, pluginViewData, price, inlineButtonTrackingContext }) {
      this.updateStickyButton({
        bestOfferPrice: price,
        isBestOffer,
        currency: this.currency,
        trackingContext: inlineButtonTrackingContext,
      });
      updatePopup(pluginViewData);
      const propsForButton = {
        bestOfferPrice: price,
        isBestOffer,
        currency: this.currency,
        pluginViewData,
        trackingContext: inlineButtonTrackingContext,
      };
      try {
        const button = await querySelectorAsync('.hermes-search-result-badge', 3e3);
        this.updateCommonButton({
          parent: button.parentElement,
          ...propsForButton,
        });
      } catch (error) {
        logger.error('Error updating card button:', error);
        logger.info('Card button not found, creating a new one');
        await this.addButtonToCheapestDeal();
        const button = await querySelectorAsync('.hermes-search-result-badge', 3e3);
        this.updateCommonButton({
          parent: button.parentElement,
          ...propsForButton,
        });
      }
      await this.setupFiltersUpdateListener();
    }
    removeUI() {
      const inlineButtons = document.querySelectorAll('.hermes-search-result-badge');
      inlineButtons.forEach(button => {
        removeCardButton(button);
      });
      removeStickyButton();
    }
    async getCheapestRoomPriceFromContent() {
      const cheapestDeal = await this.getCheapestDealFromContent();
      const days = getDateDiffInDays(new Date(this.checkIn), new Date(this.checkOut));
      logger.success(
        `Cheapest deal found
Price per whole stay ${days} days: ${cheapestDeal.price * days} ${this.currency}
Price per night: ${cheapestDeal.price} ${this.currency}
Name of the deal: ${cheapestDeal.vendorName}`,
        cheapestDeal,
      );
      return {
        price: cheapestDeal.price * days,
        charges: 0,
      };
    }
    async getChildrenFromContent() {
      const guests = await getGuestsFromContent();
      if (!guests) {
        logger.warn('Children count is null.');
        return null;
      }
      return guests.children;
    }
    async getChildrenAgesFromContent() {
      const guests = await getGuestsFromContent();
      if (!guests) {
        logger.warn('No guests from content');
        return null;
      }
      return guests.childrenAges;
    }
    async getCurrencyFromContent() {
      const element = await querySelectorAsync(SELECTORS.tripadvisor.common.header.currency, DEFAULT_SELECTOR_TIMEOUT);
      return element.textContent;
    }
    async getAdultsFromContent() {
      const guests = await getGuestsFromContent();
      if (!guests) {
        logger.warn('Adults count is null.');
        return null;
      }
      return guests.adults;
    }
    async getCheckInDateFromContent() {
      return (await getDateFromContent()).checkInDate;
    }
    async getCheckOutDateFromContent() {
      return (await getDateFromContent()).checkOutDate;
    }
  }
  const mapValueFromSelectedMenuOption = selectedValue => {
    const { allIn, allInFullStay, basePlusFees, baseRate } =
      SELECTORS.tripadvisor.searchResultsPage.filters.pricingModeMenuOptions;
    const menuValuesMap = {
      [baseRate]: 'perNight',
      [basePlusFees]: 'perNight',
      [allIn]: 'perNightTaxesAndFees',
      [allInFullStay]: 'totalStayTaxesAndFees',
    };
    if (!menuValuesMap[selectedValue]) {
      logger.warn('Selected value not found in menu values map', selectedValue);
      throw new Error('Selected value not found in menu values map');
    }
    return menuValuesMap[selectedValue];
  };
  const getPricingModeFromFilters = async () => {
    const { filters } = SELECTORS.tripadvisor.searchResultsPage;
    logger.info('Getting pricing mode from filters...');
    const filterButtonElement = await querySelectorAsync(filters.filterButtonElement, 1e4);
    logger.info('Filter button element found');
    filterButtonElement.click();
    logger.info('Filter button clicked, waiting for menu to open...');
    const selectedOptionElement = await querySelectorAsync(filters.selectedOption, 5e3);
    const selectedElementParam = selectedOptionElement.getAttribute(filters.selectedOptionParam);
    logger.info(`Selected filter value: ${selectedElementParam}`);
    if (!selectedElementParam) {
      throw new Error('No active descendant param in filter option');
    }
    const selectedValue = mapValueFromSelectedMenuOption(selectedElementParam);
    logger.info(`Mapped value: ${selectedValue}`);
    const closePopoverEvent = new KeyboardEvent('keydown', {
      key: 'Escape',
      code: 'Escape',
      keyCode: 27,
      bubbles: true,
      cancelable: true,
    });
    selectedOptionElement.dispatchEvent(closePopoverEvent);
    return selectedValue;
  };
  const getPricingModeFromContent = async () => {
    const { filters } = SELECTORS.tripadvisor.searchResultsPage;
    const filterButtonSelector = filters.openFilterModalButton;
    const filtersControlsSelector = filters.pricingModeInput;
    const taggedPromises = [
      querySelectorAsync(filterButtonSelector, 5e3).then(element => ({
        selector: filterButtonSelector,
        element,
      })),
      querySelectorAsync(filtersControlsSelector, 5e3).then(element => ({
        selector: filtersControlsSelector,
        element,
      })),
    ];
    const result = await Promise.race(taggedPromises);
    if (result.selector === filtersControlsSelector) {
      logger.info('Filters already visible on page, getting pricing mode...');
      return getPricingModeFromFilters();
    } else if (result.selector === filterButtonSelector) {
      logger.info('Filters are not visible on page, opening filter modal...');
      const modalOpenButton = await querySelectorAsync(filterButtonSelector, 5e3);
      modalOpenButton.click();
      const pricingMode = await getPricingModeFromFilters();
      const closeModalEvent = new KeyboardEvent('keydown', {
        key: 'Escape',
        code: 'Escape',
        keyCode: 27,
        bubbles: true,
        cancelable: true,
      });
      document.body.dispatchEvent(closeModalEvent);
      try {
        await waitForElementDoesntExist(filtersControlsSelector, {
          timeout: 1e3,
        });
      } catch (error) {
        logger.warn('Error waiting for filter modal to close, dispatching close modal event again', error);
        document.body.dispatchEvent(closeModalEvent);
      }
      return pricingMode;
    }
    throw new Error('Error in promise when getting filters setup');
  };
  class TripadvisorSearchResultsPageAdapter extends SearchResultsPageAdapter {
    constructor() {
      const selectors = SELECTORS.tripadvisor.searchResultsPage;
      super({
        selectors: {
          hotelCard: selectors.hotelCard.wrapper,
          hotelTitle: selectors.hotelCard.title,
          inlineButtonMountingPoint: selectors.hotelCard.buttonMountingPoint,
          hotelCardsWrapper: selectors.hotelCardsWrapper,
        },
        buttonOptions: {
          place: 'append',
          className: ['hermes-tripadvisor'],
        },
      });
      __publicField(this, 'tripadvisorPricingMode');
    }
    updateCommonButton(props) {
      let price = props.bestOfferPrice;
      if (this.tripadvisorPricingMode === 'perNight' || this.tripadvisorPricingMode === 'perNightTaxesAndFees') {
        const days = getDateDiffInDays(new Date(this.checkIn), new Date(this.checkOut));
        price = price / days;
      }
      super.updateCommonButton({ ...props, bestOfferPrice: price });
    }
    getCardExtraCharges() {
      return null;
    }
    getSearchContextFromUrl() {
      return {};
    }
    async getCurrencyFromContent() {
      const element = await querySelectorAsync(SELECTORS.tripadvisor.common.header.currency, DEFAULT_SELECTOR_TIMEOUT);
      return element.textContent;
    }
    getHotelIdFromHotelCard() {
      return null;
    }
    async setTripadvisorPricingMode() {
      const pricingMode = await getPricingModeFromContent();
      this.tripadvisorPricingMode = pricingMode;
    }
    async initializeSearchResultsAdapter() {
      await this.setTripadvisorPricingMode();
      await super.initializeSearchResultsAdapter();
    }
    async initializeSiteAdapterRequiredProperties() {
      await this.setTripadvisorPricingMode();
      await super.initializeSiteAdapterRequiredProperties();
    }
    getToolbarProps() {
      return {
        ...super.getToolbarProps(),
        tripadvisorPricingMode: this.tripadvisorPricingMode,
      };
    }
    async handleCardsWithoutButtons(cards) {
      const noInlineButtonsOnPage = document.querySelector('.hermes-search-result-badge-wrapper') === null;
      if (noInlineButtonsOnPage) {
        logger.info(
          'No inline buttons visible on page, means page was probably entirely rerendered, reinitializing required properties...',
        );
        await this.initializeSiteAdapterRequiredProperties();
        const cards2 = this.getInitialHotelCards();
        await super.handleCardsWithoutButtons(cards2);
        return;
      }
      await super.handleCardsWithoutButtons(cards);
    }
    async getGuestsFromContent() {
      return getGuestsFromContent();
    }
    async getAdultsFromContent() {
      const guests = await this.getGuestsFromContent();
      if (!guests) {
        logger.warn('Adults count is null.');
        return null;
      }
      return guests.adults;
    }
    getCardPriceDisplayMode() {
      return getTripadvisorPriceDisplayStrategy();
    }
    async getCheckInDateFromContent() {
      return (await getDateFromContent()).checkInDate;
    }
    async getCheckOutDateFromContent() {
      return (await getDateFromContent()).checkOutDate;
    }
    async getChildrenFromContent() {
      const guests = await this.getGuestsFromContent();
      if (!guests) {
        logger.warn('Children count is null.');
        return null;
      }
      return guests.children;
    }
    async getChildrenAgesFromContent() {
      const guests = await this.getGuestsFromContent();
      if (!guests) {
        logger.warn('No guests from content');
        return null;
      }
      return guests.childrenAges;
    }
    getHotelNameFromHotelCard(card) {
      const title = super.getHotelNameFromHotelCard(card);
      if (!title) {
        return null;
      }
      const removeNumberedListPattern = /^\d+\.\s*/;
      const formattedTitle = title.replace(removeNumberedListPattern, '');
      return formattedTitle;
    }
    async getAndHandleInitialCardButtons() {
      await super.getAndHandleInitialCardButtons();
    }
    getHotelPriceFromHotelCard(card) {
      const priceElement = card.querySelector(SELECTORS.tripadvisor.searchResultsPage.hotelCard.price);
      if (!priceElement) {
        throw new Error('Price element not found in card');
      }
      const priceText = priceElement.textContent?.trim();
      if (!priceText) {
        throw new Error('Price text is empty or not found');
      }
      const prices = extractPricesFromText(priceText);
      const price = Math.min(...prices);
      if (this.tripadvisorPricingMode === 'perNight' || this.tripadvisorPricingMode === 'perNightTaxesAndFees') {
        const days = getDateDiffInDays(new Date(this.checkIn), new Date(this.checkOut));
        const wholeStayPrice = price * days;
        return wholeStayPrice;
      }
      return price;
    }
  }
  const handleClickOutside = event => {
    const clickedElement = event.target;
    const hasClickedInsidePopup = clickedElement.closest('#hermes-popup');
    const hasClickedButton = clickedElement.closest('.hermes-button-container');
    if (hasClickedInsidePopup || hasClickedButton) {
      return;
    }
    closePopup();
  };
  const setupClickOutside = () => {
    document.addEventListener('mousedown', handleClickOutside);
  };
  const createPopup = () => {
    const popup = document.createElement('div');
    popup.setAttribute('id', 'hermes-popup');
    popup.setAttribute('visible', 'false');
    setupClickOutside();
    return popup;
  };
  const mountPopup = () => {
    const popup = createPopup();
    document.body.appendChild(popup);
  };
  const STYLE_ELEMENT_ID = 'hermes-theme-variables';
  const injectCssVariables = () => {
    let stylesElement = document.getElementById(STYLE_ELEMENT_ID);
    if (!stylesElement) {
      stylesElement = document.createElement('style');
      stylesElement.id = STYLE_ELEMENT_ID;
      document.head.appendChild(stylesElement);
    }
    const stringifiedCss = Object.entries(theme.variables)
      .map(([key, value]) => `--hermes-${key}: ${value};`)
      .join('\n');
    stylesElement.textContent = `:root {
${stringifiedCss}
}`;
  };
  const dotsSvg =
    '<svg viewBox="0 0 2 10" fill="none" xmlns="http://www.w3.org/2000/svg">\n<path fill-rule="evenodd" clip-rule="evenodd" d="M0 1C0 0.447715 0.447715 0 1 0C1.55229 0 2 0.447715 2 1C2 1.55229 1.55229 2 1 2C0.447715 2 0 1.55229 0 1ZM0 5.00003C0 4.44775 0.447715 4.00003 1 4.00003C1.55229 4.00003 2 4.44775 2 5.00003C2 5.55232 1.55229 6.00003 1 6.00003C0.447715 6.00003 0 5.55232 0 5.00003ZM1 7.99997C0.447715 7.99997 0 8.44769 0 8.99997C0 9.55225 0.447715 9.99997 1 9.99997C1.55229 9.99997 2 9.55225 2 8.99997C2 8.44769 1.55229 7.99997 1 7.99997Z" />\n</svg>\n';
  const EXTENSION_ENABLED_STORAGE_KEY = 'hermes-sdk-extension-enabled';
  const EXTENSION_ENABLED_STORAGE_TIMESTAMP_KEY = 'hermes-sdk-extension-enabled-timestamp';
  const persistExtensionEnabledSettings = async settings => {
    await chrome.storage.sync.set({
      [EXTENSION_ENABLED_STORAGE_KEY]: settings,
      [EXTENSION_ENABLED_STORAGE_TIMESTAMP_KEY]: String(Date.now()),
    });
  };
  const getExtensionEnabledSettings = async () => {
    const settings = await chrome.storage.sync.get([EXTENSION_ENABLED_STORAGE_KEY]);
    return settings[EXTENSION_ENABLED_STORAGE_KEY];
  };
  const getIsDomainEnabled = async domain => {
    const settings = await getExtensionEnabledSettings();
    return settings?.[domain] ?? true;
  };
  const enableExtensionForDomain = async domain => {
    const settings = await getExtensionEnabledSettings();
    const newSettings = { ...settings, [domain]: true };
    void persistExtensionEnabledSettings(newSettings);
  };
  const disableExtensionForDomain = async domain => {
    const settings = await getExtensionEnabledSettings();
    const newSettings = { ...settings, [domain]: false };
    void persistExtensionEnabledSettings(newSettings);
  };
  const createToggleButton = (options2 = {}) => {
    const { initialState = 'off', onToggle } = options2;
    const toggleContainer = createElementWithClass('div', 'hermes-toggle-container');
    toggleContainer.setAttribute('data-state', initialState);
    toggleContainer.setAttribute('role', 'switch');
    toggleContainer.setAttribute('aria-checked', initialState === 'on' ? 'true' : 'false');
    toggleContainer.setAttribute('aria-label', formatMessage('toggleExtension', 'Toggle extension'));
    const toggleTrack = createElementWithClass('div', 'hermes-toggle-track');
    const onLabel = createElementWithClass('div', 'hermes-toggle-label');
    onLabel.classList.add('hermes-toggle-label-on');
    onLabel.textContent = formatMessage('on', 'On');
    const offLabel = createElementWithClass('div', 'hermes-toggle-label');
    offLabel.classList.add('hermes-toggle-label-off');
    offLabel.textContent = formatMessage('off', 'Off');
    const toggleHandle = createElementWithClass('div', 'hermes-toggle-handle');
    toggleTrack.appendChild(onLabel);
    toggleTrack.appendChild(offLabel);
    toggleTrack.appendChild(toggleHandle);
    toggleContainer.appendChild(toggleTrack);
    let currentState = initialState;
    const handleToggle = () => {
      currentState = currentState === 'on' ? 'off' : 'on';
      toggleContainer.setAttribute('data-state', currentState);
      if (onToggle) {
        void onToggle(currentState);
      }
    };
    toggleContainer.addEventListener('click', handleToggle);
    return {
      element: toggleContainer,
      getState: () => currentState,
      setState: newState => {
        currentState = newState;
        toggleContainer.setAttribute('data-state', currentState);
      },
      toggle: handleToggle,
    };
  };
  const createContainer = (domain, domainIsEnabled) => {
    const container = document.createElement('div');
    container.setAttribute('id', 'hermes-floating-container');
    container.innerHTML = theme.buttonIcon;
    let pendingReloadTimeout = null;
    const dotsContainer = createElementWithClass('div', 'dotsContainer');
    dotsContainer.innerHTML = dotsSvg;
    container.appendChild(dotsContainer);
    container.classList.add('loading');
    const toggleButton = createToggleButton({
      initialState: domainIsEnabled ? 'on' : 'off',
      onToggle: async state => {
        try {
          const wrapper = document.querySelector('#hermes-floating-container-wrapper');
          if (state === 'on') {
            await enableExtensionForDomain(domain);
            wrapper?.setAttribute('data-enabled', 'true');
          } else {
            await disableExtensionForDomain(domain);
            wrapper?.setAttribute('data-enabled', 'false');
          }
          if (pendingReloadTimeout !== null) {
            clearTimeout(pendingReloadTimeout);
            pendingReloadTimeout = null;
          } else {
            pendingReloadTimeout = window.setTimeout(() => {
              window.location.reload();
            }, 1e3);
          }
        } catch (error) {
          toggleButton.setState(state === 'on' ? 'off' : 'on');
          logger.error('Failed to update extension state:', error);
        }
      },
    });
    const buttonContainer = createElementWithClass('div', 'button-container');
    buttonContainer.classList.add('hidden');
    container.appendChild(buttonContainer);
    return container;
  };
  const createStickyContainer = ({ domain, domainIsEnabled }) => {
    let containerWrapper = document.querySelector('#hermes-floating-container-wrapper');
    if (!containerWrapper) {
      containerWrapper = document.createElement('div');
      containerWrapper.setAttribute('id', 'hermes-floating-container-wrapper');
      containerWrapper.setAttribute('data-enabled', domainIsEnabled ? 'true' : 'false');
      document.body.append(containerWrapper);
    } else {
      containerWrapper.setAttribute('data-enabled', domainIsEnabled ? 'true' : 'false');
    }
    const existingContainer = document.querySelector('#hermes-floating-container');
    if (existingContainer) {
      return;
    }
    const containerShadow = createElementWithClass('div', 'hermes-container-shadow');
    const floatingContainer = createContainer(domain, domainIsEnabled);
    containerWrapper.append(containerShadow, floatingContainer);
  };
  const beforeEachRoute = async (domain, domainIsEnabledByUser) => {
    logger.success('Remote config initialized');
    injectCssVariables();
    mountPopup();
    createStickyContainer({
      domain,
      domainIsEnabled: domainIsEnabledByUser,
    });
  };
  class Router {
    constructor(beforeEach) {
      __publicField(this, 'routes', []);
      __publicField(this, 'beforeEach');
      this.beforeEach = beforeEach;
      logger.success('Router initialized:', this);
    }
    add({ flagEnabled, path, routeCallback, context }) {
      const regex = pathToRegex(path);
      this.routes.push({
        regex,
        callback: routeCallback,
        initialized: false,
        flagEnabled,
        context,
      });
    }
    async resolve() {
      const url = window.location.href;
      const path = window.location.pathname;
      for (const route of this.routes) {
        const match = url.match(route.regex);
        if (match) {
          tracking.addToPageContext({
            pageDomain: route.context.pageDomain,
            pageType: route.context.pageType,
            pageUrl: url,
            pagePath: path,
          });
          const domainIsEnabledByUser = await getIsDomainEnabled(route.context.pageDomain);
          void tracking.trackPageDisplayed(route.flagEnabled, domainIsEnabledByUser);
          if (!route.flagEnabled) {
            logger.info(`Route: ${route.regex} is disabled, skipping`);
            return;
          }
          if (route.initialized) {
            logger.info(`Route: ${route.regex} already initialized, skipping`);
            return;
          }
          await this.beforeEach(route.context.pageDomain, domainIsEnabledByUser);
          const params = match.groups || {};
          if (domainIsEnabledByUser) {
            route.callback(params);
            logger.success('Route matched and initialized', route.regex);
          }
          route.initialized = true;
          return;
        }
      }
      logger.warn('No route matched:', url);
      throw new Error('No route matched');
    }
  }
  const TARGET_SITE_PATHS = {
    BOOKING_SEARCH_RESULTS: 'https://*.booking.com/searchresults*',
    BOOKING_ACCOMMODATION: 'https://*.booking.com/hotel*',
    EXPEDIA_SEARCH_RESULTS: 'https://*.expedia.*/hotel-search*',
    EXPEDIA_ACCOMMODATION: 'https://*.expedia.*.[Hh]otel*',
    HOTELS_SEARCH_RESULTS: 'https://*.(hotels|hoteles).*/hotel-search*',
    HOTELS_ACCOMMODATION: 'https://*.(hotels|hoteles).*/ho*',
    KAYAK_ACCOMMODATION: 'https://*.kayak.*/hotels/*-details/*',
    KAYAK_SEARCH_RESULTS: 'https://*.kayak.*/hotels/*',
  };
  const setupRouter = async () => {
    await initializeRemoteConfig();
    const router = new Router(beforeEachRoute);
    const { hotelscom, booking, expedia, tripadvisor, kayak } = REMOTE_CONFIG.flags;
    router.add({
      path: TARGET_SITE_PATHS.BOOKING_SEARCH_RESULTS,
      routeCallback: () => new BookingSearchResultsPageAdapter(),
      flagEnabled: booking.searchResults,
      context: { pageDomain: 'booking', pageType: 'searchResults' },
    });
    router.add({
      path: TARGET_SITE_PATHS.BOOKING_ACCOMMODATION,
      routeCallback: () => new BookingAccommodationPageAdapter(),
      flagEnabled: booking.accommodation,
      context: { pageDomain: 'booking', pageType: 'accommodation' },
    });
    router.add({
      path: TARGET_SITE_PATHS.EXPEDIA_SEARCH_RESULTS,
      routeCallback: () => new ExpediaSearchResultsPageAdapter(),
      flagEnabled: expedia.searchResults,
      context: { pageDomain: 'expedia', pageType: 'searchResults' },
    });
    router.add({
      path: TARGET_SITE_PATHS.EXPEDIA_ACCOMMODATION,
      routeCallback: () => new ExpediaAccommodationPageAdapter(),
      flagEnabled: expedia.accommodation,
      context: { pageDomain: 'expedia', pageType: 'accommodation' },
    });
    router.add({
      path: TARGET_SITE_PATHS.HOTELS_SEARCH_RESULTS,
      routeCallback: () => new HotelsSearchResultsAdapter(),
      flagEnabled: hotelscom.searchResults,
      context: { pageDomain: 'hotelscom', pageType: 'searchResults' },
    });
    router.add({
      path: TARGET_SITE_PATHS.HOTELS_ACCOMMODATION,
      routeCallback: () => new HotelsAccommodationPageAdapter(),
      flagEnabled: hotelscom.accommodation,
      context: { pageDomain: 'hotelscom', pageType: 'accommodation' },
    });
    router.add({
      path: 'https://*tripadvisor.*/Hotels*#SPLITVIEW(LIST|MAP)',
      routeCallback: () => new TripadvisorSearchResultsPageAdapter(),
      flagEnabled: tripadvisor.searchResults,
      context: { pageDomain: 'tripadvisor', pageType: 'searchResults' },
    });
    router.add({
      path: 'https://*tripadvisor.*/Hotel_Review*',
      routeCallback: () => new TripadvisorAccommodationPageAdapter(),
      flagEnabled: tripadvisor.accommodation,
      context: { pageDomain: 'tripadvisor', pageType: 'accommodation' },
    });
    router.add({
      path: TARGET_SITE_PATHS.KAYAK_ACCOMMODATION,
      routeCallback: () => new KayakAccommodationPageAdapter(),
      flagEnabled: kayak.accommodation,
      context: { pageDomain: 'kayak', pageType: 'accommodation' },
    });
    router.add({
      path: TARGET_SITE_PATHS.KAYAK_SEARCH_RESULTS,
      routeCallback: () => new KayakSearchResultsPageAdapter(),
      flagEnabled: kayak.searchResults,
      context: { pageDomain: 'kayak', pageType: 'searchResults' },
    });
    try {
      await router.resolve();
    } catch (error) {
      logger.error('Error resolving router:', error);
      initializeUrlChangeListener(() => {
        void router.resolve();
      });
    }
  };
  const matchesPattern = (url, pattern) => {
    const regex = pathToRegex(pattern);
    const match = url.match(regex);
    return match !== null;
  };
  const isTargetSite = url => {
    try {
      const isSupported = Object.values(TARGET_SITE_PATHS).some(path => {
        return matchesPattern(url, path);
      });
      return isSupported;
    } catch {
      return false;
    }
  };
  const _SDK = class _SDK {
    constructor() {}
    static getInstance() {
      if (!_SDK.instance) {
        _SDK.instance = new _SDK();
      } else {
        logger.warn('SDK has already been initialized. Make sure you are only calling init() once.');
      }
      return _SDK.instance;
    }
    /**
     * Initializes the Hermes SDK.
     * @param {string} apiKey - The API key required for authentication.
     * @param {Object} options - Optional configuration options for the client.
     * @throws {Error} Will throw an error if API key is not provided.
     */
    static init(apiKey, options2) {
      if (!apiKey) {
        throw new Error('API key is required');
      }
      if (!isTargetSite(window.location.href)) {
        return;
      }
      const mergedOptions = { ...config.options, ...options2 };
      config.update({ apiKey, options: mergedOptions });
      const i18nPromise = initializeI18n(config.options.language).catch(error => {
        logger.error('Error initializing i18n', error);
      });
      const trackingPromise = tracking.init().catch(error => {
        logger.error('Error setting anonymous id', error);
      });
      Promise.all([i18nPromise, trackingPromise])
        .then(() => {
          _SDK.getInstance().injectIntoPage();
        })
        .catch(error => {
          logger.error('Error initializing SDK', error);
          _SDK.getInstance().injectIntoPage();
        });
    }
    /**
     * Inject markup and handle the current route.
     * @private
     */
    injectIntoPage() {
      try {
        logger.success('SDK initialized');
        void setupRouter();
      } catch (error) {
        logger.error('SDK error', error);
      }
    }
  };
  __publicField(_SDK, 'instance', null);
  let SDK = _SDK;
  return SDK;
})();
