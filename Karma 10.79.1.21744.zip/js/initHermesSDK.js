const browserLanguage = navigator.language;
const { host } = window.location;

if (host.includes('booking.com')) {
  Hermes.init('sIR5G99FbkrmRDRmMrEvZjbX', {
    debug: false,
    language: browserLanguage,
    fetcher: (...args) => {
      console.log(
        '%cCustom fetcher function called.',
        'background-color: blue; color: white; padding: 2px 5px; border-radius: 2px;',
      );
      return fetch(...args);
    },
  });
}
