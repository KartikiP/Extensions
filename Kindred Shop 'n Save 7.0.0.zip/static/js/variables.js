window.__KVARS__ = {
  images: {
    apply_discounts_popup_image: 'icons/images/applyDiscounts.png',
    in_progress_popup_image: 'icons/images/inProgress.png',
    no_deals_found_popup_image: 'icons/images/noDealsFound.png',
    home_icon: 'icons/images/homeIcon.png',
    settings_icon: 'icons/images/settingsIcon.png',
    close_icon: 'icons/images/closeIcon.png',
    no_codes_badge_icon: 'icons/images/noCodesBadge.png',
  },
};
