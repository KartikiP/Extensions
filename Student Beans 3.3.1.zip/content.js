const IFRAME_ID = 'sb-extension-frame'

const IFRAME_ID_LARGE = 'sb-extension-frame-large'

const IFRAME_ID_TAB = 'sb-extension-frame-tab'

const IFRAME_HEIGHT_SMALL = '259px'

const IFRAME_HEIGHT_LARGE = '80vh'

const IFRAME_HEIGHT_TAB = '40px'

const IFRAME_WIDTH_TAB = '62px'

const IFRAME_WIDTH_DEFAULT = '330px'

const IFRAME_TOP_POSITION_DEFAULT = '20px'

const IFRAME_RIGHT_POSITION_DEFAULT = '20px'

const IFRAME_TOP_POSITION_TAB = '200px'

const IFRAME_RIGHT_POSITION_TAB = '0px'

const IFRAME_BORDER_RADIUS_ROUNDED = '8px'

const IFRAME_BORDER_RADIUS_TAB = `${IFRAME_BORDER_RADIUS_ROUNDED} 0px 0px ${IFRAME_BORDER_RADIUS_ROUNDED}`

const IS_OFFER_CONTAINER_PARAM = '&isOfferContainer=true'

const IS_SIDE_TAB_PARAM = '&isSideTab=true'

const getIframeUrl = (brand, country, isOfferContainer) => {
  if (!brand) return `index.html?inactive=true&country=${country}`

  const offerData = JSON.stringify(brand.offerData)

  return `index.html?slug=${brand.slug}&title=${encodeURIComponent(
    brand.brand
  )}&domain=${brand.domains}&country=${country}&offerData=${encodeURIComponent(
    offerData
  )}&logo=${brand.logo}${isOfferContainer}`
}

const getContainer = (containerId) => document.getElementById(containerId)

const createContainer = (
  height,
  width,
  topPosition,
  rightPosition,
  borderRadius,
  containerId
) => {
  const existingContainer = getContainer(containerId)

  if (existingContainer) return getContainer(containerId)

  const container = document.createElement('iframe')
  container.style = `
    width: ${width};
    height: ${height};
    position: fixed;
    top: ${topPosition};
    right: ${rightPosition};
    overflow: hidden;
    border-radius: ${borderRadius};
    z-index: ${Number.MAX_SAFE_INTEGER} !important;
    display: block !important;
    box-shadow: 0px 20px 25px 0px rgba(23, 27, 30, 0.2);
  `
  container.setAttribute('frameBorder', '0')
  container.setAttribute('id', containerId)
  return container
}

const insertContainer = (container) => {
  if (getContainer(IFRAME_ID)) return null

  document.getElementsByTagName('html')[0].append(container)
}

const insertLargeContainer = (container) => {
  if (getContainer(IFRAME_ID_LARGE)) return null

  document.getElementsByTagName('html')[0].append(container)
}

const updateContainerUrl = (container, brand, country, isOfferContainer) => {
  const iframeUrl = getIframeUrl(brand, country, isOfferContainer)

  container.src = chrome.runtime.getURL(iframeUrl)
}

const renderContainer = (brand, country, shouldOpen = true) => {
  const container = createContainer(
    IFRAME_HEIGHT_SMALL,
    IFRAME_WIDTH_DEFAULT,
    IFRAME_TOP_POSITION_DEFAULT,
    IFRAME_RIGHT_POSITION_DEFAULT,
    IFRAME_BORDER_RADIUS_ROUNDED,
    IFRAME_ID
  )
  updateContainerUrl(container, brand, country)

  if (shouldOpen) {
    insertContainer(container)
  }

  setTimeout(() => {
    repositionHoney()
  }, 2000)
}

const renderLargeContainer = (brand, country, shouldOpen = true) => {
  const container = createContainer(
    IFRAME_HEIGHT_LARGE,
    IFRAME_WIDTH_DEFAULT,
    IFRAME_TOP_POSITION_DEFAULT,
    IFRAME_RIGHT_POSITION_DEFAULT,
    IFRAME_BORDER_RADIUS_ROUNDED,
    IFRAME_ID_LARGE
  )
  updateContainerUrl(container, brand, country, IS_OFFER_CONTAINER_PARAM)

  if (shouldOpen) {
    insertLargeContainer(container)
  }

  setTimeout(() => {
    repositionHoney()
  }, 2000)
}

const renderTabContainer = (brand, country, shouldOpen = true) => {
  const container = createContainer(
    IFRAME_HEIGHT_TAB,
    IFRAME_WIDTH_TAB,
    IFRAME_TOP_POSITION_TAB,
    IFRAME_RIGHT_POSITION_TAB,
    IFRAME_BORDER_RADIUS_TAB,
    IFRAME_ID_TAB
  )
  updateContainerUrl(container, brand, country, IS_SIDE_TAB_PARAM)

  if (shouldOpen) {
    insertContainer(container)
  }

  setTimeout(() => {
    repositionHoney()
  }, 2000)
}

const repositionHoney = () => {
  const honeyContainer = document.getElementById('honeyContainer')
  if (honeyContainer) {
    honeyContainer.style = `
      all: unset;
      position: fixed;
      z-index: ${Number.MAX_SAFE_INTEGER - 1};
    `
  }
}

const getActiveContainer = () => {
  const smallFrame = document.getElementById('sb-extension-frame')
  const largeFrame = document.getElementById('sb-extension-frame-large')
  const tabFrame = document.getElementById('sb-extension-frame-tab')
  if (!smallFrame && !largeFrame && !tabFrame) return null

  if (largeFrame) return getContainer(IFRAME_ID_LARGE)

  if (tabFrame) return getContainer(IFRAME_ID_TAB)

  return getContainer(IFRAME_ID)
}

const closeFrame = async ({ domain, autoClose }) => {
  const container = getActiveContainer()
  container.parentNode.removeChild(container)

  if (autoClose) return

  return await setBrandAsDismissed(domain, autoClose)
}

const setBrandAsDismissed = async (domain) => {
  const { brands } = await chrome.storage.local.get('brands')

  const updatedBrands = brands.map((brand) => {
    if (domain === brand.domains) {
      return { ...brand, dismissed: true }
    }
    return brand
  })

  return await chrome.storage.local.set({ brands: updatedBrands })
}

const openFrame = async ({ brand, country }) => {
  return renderContainer(brand, country)
}

const openLargeFrame = async ({ brand, country }) => {
  return renderLargeContainer(brand, country)
}

const openTabFrame = async ({ brand, country }) => {
  if (!brand) return null

  return renderTabContainer(brand, country)
}

const getUpdateIconMessageType = (brand) => {
  if (brand) return 'enableIcon'

  return 'disableIcon'
}

const updateIcon = (brand) => {
  const messageType = getUpdateIconMessageType(brand)
  chrome.runtime.sendMessage({
    type: messageType,
    target: 'background',
    data: {
      brand
    }
  })
}

const hasNativeDiscount = (brand) =>
  brand.offerData.offerCounts.NATIVE_STUDENT_DISCOUNT > 0

const shouldAutomaticallyOpenFrame = (brand) => {
  return !!brand && !brand.dismissed && hasNativeDiscount(brand)
}

const shouldAutomaticallyOpenTabFrame = (brand) => {
  return !!brand && hasNativeDiscount(brand)
}

const closeContainers = (ids) => {
  ids.forEach((id) => {
    if (getContainer(id)) {
      closeFrame({ autoClose: true })
    }
  })
}

const updateFrame = ({ brand, country }) => {
  updateIcon(brand)
  if (shouldAutomaticallyOpenFrame(brand)) {
    closeContainers([IFRAME_ID_TAB, IFRAME_ID_LARGE])
    return renderContainer(brand, country)
  }

  if (shouldAutomaticallyOpenTabFrame(brand))
    return renderTabContainer(brand, country)

  if (getContainer(IFRAME_ID_LARGE)) {
    closeFrame({ autoClose: true })
    renderContainer(brand, country)
  }

  if (getContainer(IFRAME_ID_TAB)) {
    closeFrame({ autoClose: true })
    renderContainer(brand, country)
  }

  if (getContainer(IFRAME_ID)) return renderContainer(brand, country)

  return true
}

const copyCode = async (code) => {
  try {
    await navigator.clipboard.writeText(code)
  } catch (error) {
    console.error('Error copying text: ', error)
  }
}

const handleMessages = async (message) => {
  if (message.target !== 'content') return false

  if (message.type === 'closeFrame') return await closeFrame(message.data)

  if (message.type === 'openFrame' && !getContainer(IFRAME_ID))
    return await openFrame(message.data)

  if (message.type === 'updateFrame') return updateFrame(message.data)

  if (message.type === 'openLargeFrame' && !getContainer(IFRAME_ID_LARGE))
    return await openLargeFrame(message.data)

  if (message.type === 'openTabFrame' && !getContainer(IFRAME_ID_TAB))
    return await openTabFrame(message.data)

  if (message.type === 'copyCode') return await copyCode(message.data)
}

const contentLoaded = () => {
  chrome.runtime.sendMessage({ type: 'contentLoaded', target: 'background' })
}

try {
  contentLoaded()
  chrome.runtime.onMessage.addListener(handleMessages)
} catch (error) {
  console.error(error)
}
