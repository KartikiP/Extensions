let snowplow

const setup = (isDev = false, userId = null) => {
  if (isSnowplowSetup()) return null

  addSnowplow()

  snowplow = window.snowplow

  const endpoint = isDev ? 'staging.t.studentbeans.com' : 't.studentbeans.com'

  snowplow('newTracker', 'co', endpoint, {
    platform: 'web',
    post: true,
    appId: 'browserextension',
    cookieDomain: '.studentbeans.com',
    forceSecureTracker: true,
    contexts: {
      webPage: false,
      performanceTiming: false
    }
  })

  snowplow('setUserId', userId)

  snowplow('enableActivityTracking', 30, 10)
  snowplow('enableLinkClickTracking')
}

const isSnowplowSetup = () => {
  return !!window.snowplow
}

const addSnowplow = () => {
  ;(function (p, l, o, w, i, n, g) {
    if (!p[i]) {
      p.GlobalSnowplowNamespace = p.GlobalSnowplowNamespace || []
      p.GlobalSnowplowNamespace.push(i)
      p[i] = function () {
        ;(p[i].q = p[i].q || []).push(arguments)
      }
      p[i].q = p[i].q || []
      n = l.createElement(o)
      g = l.getElementsByTagName(o)[0]
      n.async = 1
      n.src = w
      g.parentNode.insertBefore(n, g)
    }
  })(window, document, 'script', 'sp.js', 'snowplow')
}

const unstructured = (schema, data, contexts) => {
  snowplow('trackUnstructEvent', { schema, data }, contexts)
}

const handleMessages = (message) => {
  if (message.target !== 'offscreen') return false

  setup(message.isDev, message.userId)

  if (message.type === 'install') return trackInstall()

  if (message.type === 'prompt')
    return trackPrompt(message.data, message.context)

  if (message.type === 'event')
    return trackBrowserExtensionEvent(message.data, message.context)

  if (message.type === 'issuance')
    return trackIssuance(message.data, message.context)

  if (message.type === 'setUserId')
    return window.snowplow('setUserId', message.userId)
}

const trackInstall = () => {
  unstructured(
    'iglu:com.studentbeans/browser_extension_event/jsonschema/1-0-0',
    {
      action: 'install',
      browser: 'chrome'
    },
    ''
  )
}

const BROWSER_EXTENSION_EVENT_SCHEMA =
  'iglu:com.studentbeans/browser_extension_event/jsonschema/1-1-0'

const BROWSER_EXTENSION_PROMPT_SCHEMA =
  'iglu:com.studentbeans/browser_extension_prompt/jsonschema/1-0-0'

const ISSUANCE_SCHEMA = 'iglu:com.studentbeans/issuance/jsonschema/1-7-0'

const trackBrowserExtensionEvent = (data, context = []) => {
  unstructured(BROWSER_EXTENSION_EVENT_SCHEMA, data, context)
}

const trackPrompt = (data, context = []) => {
  const browserExtensionEventData = {
    action: 'prompt',
    browser: 'chrome',
    brand_slug: data.brand,
    country: data.country
  }

  const promptContext = {
    schema: BROWSER_EXTENSION_PROMPT_SCHEMA,
    data: {
      brand: data.brand,
      domain: data.domain,
      redirectUrl: data.redirectUrl
    }
  }

  trackBrowserExtensionEvent(browserExtensionEventData, [
    promptContext,
    ...context
  ])
}

const trackIssuance = (data, context = []) => {
  unstructured(ISSUANCE_SCHEMA, data, [
    {
      schema: BROWSER_EXTENSION_EVENT_SCHEMA,
      data: {
        action: 'issuance',
        browser: 'chrome',
        brand_slug: data.brand_slug,
        country: data.country
      }
    },
    ...context
  ])
}

try {
  chrome.runtime.onMessage.addListener(handleMessages)
} catch (error) {
  console.error(error)
}
