const hasTrackedInstall = async () => {
  const { installTracked } = await chrome.storage.sync.get('installTracked')
  return !!installTracked
}

const setInstallTracked = async () => {
  await chrome.storage.sync.set({ installTracked: true })
}

const handleInstall = async (details) => {
  if (details.reason !== 'install') return

  await chrome.storage.local.clear()

  const isInstallTracked = await hasTrackedInstall()

  if (isInstallTracked) return

  await track('install')
  await setInstallTracked()
}

const handleMessages = async (message) => {
  if (!message?.type) return false

  if (message?.target !== 'background') return false

  if (message.type === 'contentLoaded') return await handleContentLoaded()

  if (message.type === 'enableIcon') return await enableIcon(message.data)

  if (message.type === 'disableIcon') return await disableIcon()

  if (message.type === 'setUserId') return await setUserId(message.data)

  if (message.type === 'trackPrompt')
    return await track('prompt', message.data, message.context)

  if (message.type === 'trackEvent')
    return await track('event', message.data, message.context)

  if (message.type === 'trackIssuance')
    return await track('issuance', message.data, message.context)

  if (message.type === 'changeCountry') return await changeCountry(message.data)

  if (message.type === 'changeFrame') return await changeFrame()

  if (message.type === 'openSideTab') return await openSideTab()

  if (message.type === 'openAffiliateLink')
    return await openAffiliateLink(message.data)
}

const handleContentLoaded = async () => {
  const tab = await getActiveTab()
  return await updateFrame(tab)
}

const changeCountry = async ({ country }) => {
  await chrome.storage.local.set({ country })
  await fetchBrands()

  setChromePopup()

  return chrome.tabs.query({}, (tabs) => {
    tabs.forEach(async (tab) => await updateFrame(tab))
  })
}

const updateFrame = async (tab) => {
  const affiliateLinkOpened = await chrome.storage.local.get(
    'affiliateLinkOpened'
  )
  if (affiliateLinkOpened.affiliateLinkOpened) {
    await chrome.storage.local.remove('affiliateLinkOpened')
    return
  }

  const brand = await getBrand(tab.url)
  const country = await getCountry()

  const message = {
    target: 'content',
    type: 'updateFrame',
    data: {
      brand,
      country
    }
  }

  return await chrome.tabs.sendMessage(tab.id, message)
}

const changeFrame = async () => {
  const tab = await getActiveTab()
  const brand = await getBrand(tab.url)
  const country = await getCountry()

  const message = {
    target: 'content',
    type: 'openLargeFrame',
    data: {
      brand,
      country
    }
  }

  return await chrome.tabs.sendMessage(tab.id, message)
}

const openSideTab = async () => {
  const tab = await getActiveTab()
  const brand = await getBrand(tab.url)
  const country = await getCountry()

  const message = {
    target: 'content',
    type: 'openTabFrame',
    data: {
      brand,
      country
    }
  }

  return await chrome.tabs.sendMessage(tab.id, message)
}

const LOCALE_TO_COUNTRY_MAP = {
  da: 'dk',
  de: 'de',
  en: 'uk',
  'en-GB': 'uk',
  'en-US': 'us',
  'es-ES': 'es',
  fr: 'fr',
  it: 'it',
  nl: 'nl',
  pl: 'pl',
  sv: 'se',
  'zh-CN': 'cn'
}

const guessCountryDefault = () => {
  const uiLanguage = chrome.i18n.getUILanguage()
  return LOCALE_TO_COUNTRY_MAP[uiLanguage] || 'uk'
}

const getCountry = async () => {
  const { country } = await chrome.storage.local.get('country')
  return country || guessCountryDefault()
}

const handleOnActivated = async () => {
  const tab = await getActiveTab()
  const brand = await getBrand(tab.url)

  if (brand) return await enableIcon({ brand })

  return await disableIcon()
}

const setIcon = async (icon) => await chrome.action.setIcon({ path: icon })

const enableIcon = async ({ brand }) => {
  await setIcon('icons/active32.png')
}

const disableIcon = async () => {
  await setIcon('icons/disabled32.png')
}

const getActiveTab = async () => {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true })
  return tab
}

const hasOffscreenDocument = async () => {
  const offscreenUrl = chrome.runtime.getURL('offscreen.html')
  const matchedClients = await clients.matchAll()
  for (const client of matchedClients) {
    if (client.url === offscreenUrl) {
      return true
    }
  }

  return false
}

const createOffscreenDocument = async () => {
  await chrome.offscreen.createDocument({
    url: chrome.runtime.getURL('offscreen.html'),
    reasons: ['IFRAME_SCRIPTING'],
    justification:
      'We track usage to figure out how we can improve our products'
  })
}

const isDevBuild = async () => {
  const self = await chrome.management.getSelf()
  return self.installType === 'development'
}

const track = async (type, data, context) => {
  const hasDocument = await hasOffscreenDocument()

  if (!hasDocument) await createOffscreenDocument()

  const isDev = await isDevBuild()
  const userId = await getUserId()

  chrome.runtime.sendMessage({
    type,
    target: 'offscreen',
    isDev,
    userId,
    data,
    context
  })
}

const getUserId = async () => {
  const { userId } = await chrome.storage.local.get('userId')
  return userId ?? null
}

const setUserId = async ({ userId }) => {
  chrome.runtime.sendMessage({
    type: 'setUserId',
    target: 'offscreen',
    userId
  })
}

const escapeRegExp = (string) => string.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')

const doesBrandMatch = (url, brand) => {
  const escapedBrandDomain = escapeRegExp(brand.domains)

  const searchExpression = new RegExp(`([/]|[.])${escapedBrandDomain}`, 'g')

  return url.search(searchExpression) !== -1
}

const refreshCachedBrands = async () => {
  const { lastUpdated } = await chrome.storage.local.get('lastUpdated')

  if (!lastUpdated) return await fetchBrands()

  const hour = 1000 * 60 * 60
  const day = hour * 24
  const is24HoursStale = Date.now() - day > lastUpdated

  if (is24HoursStale) return await fetchBrands()
}

const getBrand = async (url) => {
  await refreshCachedBrands()

  const { brands } = await chrome.storage.local.get('brands')
  return brands.find((brand) => doesBrandMatch(url, brand))
}

const getBrandJSONUrl = async () => {
  let host = 'cdn.studentbeans.com'

  const isDev = await isDevBuild()
  const country = await getCountry()

  if (isDev) {
    host = 'cdn.staging.studentbeans.com/staging'
  }

  return `https://${host}/offers/browser-extensions/brands/${country}.json`
}

const fetchBrands = async () => {
  const url = await getBrandJSONUrl()

  const response = await fetch(url)
  const brands = await response.json()
  const lastUpdated = Date.now()

  return await chrome.storage.local.set({ brands, lastUpdated })
}

const setChromePopup = async () => {
  const country = await getCountry()

  await chrome.action.setPopup({
    popup: `index.html?isChromePopup=true&country=${country}`
  })
}

const autoCloseAffiliateLink = async (tab) => {
  await chrome.tabs.onUpdated.addListener(function listener(tabId, info) {
    if (tabId === tab.id && info.status === 'complete') {
      chrome.tabs.onUpdated.removeListener(listener)
      chrome.tabs.remove(tab.id)
    }
  })
}

const openAffiliateLink = async (url) => {
  await chrome.storage.local.set({ affiliateLinkOpened: true })
  const currentTab = await getActiveTab()
  await chrome.tabs.create(
    {
      url,
      active: false,
      index: currentTab.index + 1
    },
    async (tab) => {
      autoCloseAffiliateLink(tab)
    }
  )
}

const handleSetAuthTokensMessage = async (request, sendResponse) => {
  const { viewerToken, refreshToken, expiresIn } = request
  const viewerTokenExpiry = Date.now() + parseInt(expiresIn)
  await chrome.storage.local.set({
    viewerToken,
    viewerTokenExpiry,
    refreshToken
  })
  sendResponse('authTokensSet')
}

const handleExternalMessage = async (request, sender, sendResponse) => {
  const { type } = request

  if (type === 'SET_AUTH_TOKENS')
    return await handleSetAuthTokensMessage(request, sendResponse)

  if (type === 'IS_INSTALLED') return await sendResponse(true)
}

try {
  setChromePopup()

  chrome.runtime.onInstalled.addListener(handleInstall)
  chrome.runtime.onMessage.addListener(handleMessages)
  chrome.tabs.onActivated.addListener(handleOnActivated)
  chrome.runtime.onMessageExternal.addListener(handleExternalMessage)
} catch (error) {
  console.error(error)
}
