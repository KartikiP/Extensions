'use strict';
window.prompt = () => {};
