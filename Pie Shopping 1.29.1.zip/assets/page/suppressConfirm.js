'use strict';
window.confirm = () => {};
