'use strict';
window.alert = () => {};
