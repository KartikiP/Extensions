import{v as e}from"./chunk-TGCXPILF.js";var o=async n=>e("pinnedTab",n);export{o as a};
