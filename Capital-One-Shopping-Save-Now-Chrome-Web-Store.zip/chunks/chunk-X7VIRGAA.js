import{v as e}from"./chunk-TGCXPILF.js";var i=t=>e("getRelevantSites",t);export{i as a};
