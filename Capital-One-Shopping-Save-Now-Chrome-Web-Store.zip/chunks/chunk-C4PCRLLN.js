import{v as e}from"./chunk-TGCXPILF.js";var r=t=>e("getLifetimeSavingsData",t);export{r as a};
