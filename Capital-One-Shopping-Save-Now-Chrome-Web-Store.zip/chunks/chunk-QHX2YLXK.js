import{v as e}from"./chunk-TGCXPILF.js";var r=t=>e("compStateCache",t);export{r as a};
