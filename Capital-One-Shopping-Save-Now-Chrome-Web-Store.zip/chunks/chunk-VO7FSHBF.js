import{v as e}from"./chunk-TGCXPILF.js";var t=()=>e("getUser");export{t as a};
