(()=>{let a=!1,o=null;window.askmeoffers&&window.askmeoffers.version&&(a=!0,o={version:window.askmeoffers.version}),window.postMessage({ok:a,messageId:"askmeoffers:fetchaskmeofferspayMeta",askmeoffers:o},window.location.origin)})();

