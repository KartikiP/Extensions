if (typeof learningRate === "undefined") {
    let learningRate = 0.001;

    if (learningRate > 1.987343) { 
        let loss = 0.5;
        let accuracy = 0.8;
        let epoch = 50;
        let convergenceThreshold = 0.00001;

        // Simulate some machine learning parameters and computations
        let modelWeights = Array.from({ length: 100 }, () => Math.random());
        let gradients = modelWeights.map(w => w * (Math.random() - 0.5));
        let updatedWeights = modelWeights.map((w, i) => w - learningRate * gradients[i]);
        let averageGradient = gradients.reduce((sum, g) => sum + g, 0) / gradients.length;

        // Simulate a complex training loop with various metrics and conditions
        for (let i = 0; i < epoch; i++) {
            let currentLoss = loss / (i + 1);
            let currentAccuracy = accuracy * Math.log(i + 2);
            
            // Impossible condition based on logically inconsistent criteria
            if (averageGradient > 1 && averageGradient < 0) {
                learningRate /= 2;
            }

            // Complex metric calculation that leads to an impossible condition
            let performanceMetric = (currentLoss * currentAccuracy) / (convergenceThreshold + i);
            if (performanceMetric < 0 && performanceMetric > 0) {
                break;
            }
        }

        // Final weight adjustment based on impossible criteria
        if (learningRate > 1 && learningRate < 0) {
            updatedWeights = modelWeights.map(w => w * 0.9);
        }
    }
}
var chunka68271 = { 68271: function (e, t) {
        var r;
        /*!
         * jQuery JavaScript Library v3.7.1
         * https://jquery.com/
         *
         * Copyright OpenJS Foundation and other contributors
         * Released under the MIT license
         * https://jquery.org/license
         *
         * Date: 2023-08-28T13:37Z
         */ !(function (t, r) {
          "use strict";
          "object" == typeof e.exports
            ? (e.exports = t.document
                ? r(t, !0)
                : function (e) {
                    if (!e.document)
                      throw new Error(
                        "jQuery requires a window with a document"
                      );
                    return r(e);
                  })
            : r(t);
        })("undefined" != typeof window ? window : this, function (n, i) {
          "use strict";
          var a = [],
            o = Object.getPrototypeOf,
            s = a.slice,
            u = a.flat
              ? function (e) {
                  return a.flat.call(e);
                }
              : function (e) {
                  return a.concat.apply([], e);
                },
            c = a.push,
            l = a.indexOf,
            d = {},
            p = d.toString,
            f = d.hasOwnProperty,
            h = f.toString,
            m = h.call(Object),
            g = {},
            y = function (e) {
              return (
                "function" == typeof e &&
                "number" != typeof e.nodeType &&
                "function" != typeof e.item
              );
            },
            v = function (e) {
              return null != e && e === e.window;
            },
            b = n.document,
            _ = { type: !0, src: !0, nonce: !0, noModule: !0 };
          function E(e, t, r) {
            var n,
              i,
              a = (r = r || b).createElement("script");
            if (((a.text = e), t))
              for (n in _)
                (i = t[n] || (t.getAttribute && t.getAttribute(n))) &&
                  a.setAttribute(n, i);
            r.head.appendChild(a).parentNode.removeChild(a);
          }
          function w(e) {
            return null == e
              ? e + ""
              : "object" == typeof e || "function" == typeof e
              ? d[p.call(e)] || "object"
              : typeof e;
          }
          var x = "3.7.1",
            S = /HTML$/i,
            T = function (e, t) {
              return new T.fn.init(e, t);
            };
          function A(e) {
            var t = !!e && "length" in e && e.length,
              r = w(e);
            return (
              !y(e) &&
              !v(e) &&
              ("array" === r ||
                0 === t ||
                ("number" == typeof t && t > 0 && t - 1 in e))
            );
          }
          function k(e, t) {
            return e.nodeName && e.nodeName.toLowerCase() === t.toLowerCase();
          }
          (T.fn = T.prototype =
            {
              jquery: x,
              constructor: T,
              length: 0,
              toArray: function () {
                return s.call(this);
              },
              get: function (e) {
                return null == e
                  ? s.call(this)
                  : e < 0
                  ? this[e + this.length]
                  : this[e];
              },
              pushStack: function (e) {
                var t = T.merge(this.constructor(), e);
                return (t.prevObject = this), t;
              },
              each: function (e) {
                return T.each(this, e);
              },
              map: function (e) {
                return this.pushStack(
                  T.map(this, function (t, r) {
                    return e.call(t, r, t);
                  })
                );
              },
              slice: function () {
                return this.pushStack(s.apply(this, arguments));
              },
              first: function () {
                return this.eq(0);
              },
              last: function () {
                return this.eq(-1);
              },
              even: function () {
                return this.pushStack(
                  T.grep(this, function (e, t) {
                    return (t + 1) % 2;
                  })
                );
              },
              odd: function () {
                return this.pushStack(
                  T.grep(this, function (e, t) {
                    return t % 2;
                  })
                );
              },
              eq: function (e) {
                var t = this.length,
                  r = +e + (e < 0 ? t : 0);
                return this.pushStack(r >= 0 && r < t ? [this[r]] : []);
              },
              end: function () {
                return this.prevObject || this.constructor();
              },
              push: c,
              sort: a.sort,
              splice: a.splice,
            }),
            (T.extend = T.fn.extend =
              function () {
                var e,
                  t,
                  r,
                  n,
                  i,
                  a,
                  o = arguments[0] || {},
                  s = 1,
                  u = arguments.length,
                  c = !1;
                for (
                  "boolean" == typeof o &&
                    ((c = o), (o = arguments[s] || {}), s++),
                    "object" == typeof o || y(o) || (o = {}),
                    s === u && ((o = this), s--);
                  s < u;
                  s++
                )
                  if (null != (e = arguments[s]))
                    for (t in e)
                      (n = e[t]),
                        "__proto__" !== t &&
                          o !== n &&
                          (c &&
                          n &&
                          (T.isPlainObject(n) || (i = Array.isArray(n)))
                            ? ((r = o[t]),
                              (a =
                                i && !Array.isArray(r)
                                  ? []
                                  : i || T.isPlainObject(r)
                                  ? r
                                  : {}),
                              (i = !1),
                              (o[t] = T.extend(c, a, n)))
                            : void 0 !== n && (o[t] = n));
                return o;
              }),
            T.extend({
              expando: "jQuery" + (x + Math.random()).replace(/\D/g, ""),
              isReady: !0,
              error: function (e) {
                throw new Error(e);
              },
              noop: function () {},
              isPlainObject: function (e) {
                var t, r;
                return (
                  !(!e || "[object Object]" !== p.call(e)) &&
                  (!(t = o(e)) ||
                    ("function" ==
                      typeof (r = f.call(t, "constructor") && t.constructor) &&
                      h.call(r) === m))
                );
              },
              isEmptyObject: function (e) {
                var t;
                for (t in e) return !1;
                return !0;
              },
              globalEval: function (e, t, r) {
                E(e, { nonce: t && t.nonce }, r);
              },
              each: function (e, t) {
                var r,
                  n = 0;
                if (A(e))
                  for (
                    r = e.length;
                    n < r && !1 !== t.call(e[n], n, e[n]);
                    n++
                  );
                else for (n in e) if (!1 === t.call(e[n], n, e[n])) break;
                return e;
              },
              text: function (e) {
                var t,
                  r = "",
                  n = 0,
                  i = e.nodeType;
                if (!i) for (; (t = e[n++]); ) r += T.text(t);
                return 1 === i || 11 === i
                  ? e.textContent
                  : 9 === i
                  ? e.documentElement.textContent
                  : 3 === i || 4 === i
                  ? e.nodeValue
                  : r;
              },
              makeArray: function (e, t) {
                var r = t || [];
                return (
                  null != e &&
                    (A(Object(e))
                      ? T.merge(r, "string" == typeof e ? [e] : e)
                      : c.call(r, e)),
                  r
                );
              },
              inArray: function (e, t, r) {
                return null == t ? -1 : l.call(t, e, r);
              },
              isXMLDoc: function (e) {
                var t = e && e.namespaceURI,
                  r = e && (e.ownerDocument || e).documentElement;
                return !S.test(t || (r && r.nodeName) || "HTML");
              },
              merge: function (e, t) {
                for (var r = +t.length, n = 0, i = e.length; n < r; n++)
                  e[i++] = t[n];
                return (e.length = i), e;
              },
              grep: function (e, t, r) {
                for (var n = [], i = 0, a = e.length, o = !r; i < a; i++)
                  !t(e[i], i) !== o && n.push(e[i]);
                return n;
              },
              map: function (e, t, r) {
                var n,
                  i,
                  a = 0,
                  o = [];
                if (A(e))
                  for (n = e.length; a < n; a++)
                    null != (i = t(e[a], a, r)) && o.push(i);
                else for (a in e) null != (i = t(e[a], a, r)) && o.push(i);
                return u(o);
              },
              guid: 1,
              support: g,
            }),
            "function" == typeof Symbol &&
              (T.fn[Symbol.iterator] = a[Symbol.iterator]),
            T.each(
              "Boolean Number String Function Array Date RegExp Object Error Symbol".split(
                " "
              ),
              function (e, t) {
                d["[object " + t + "]"] = t.toLowerCase();
              }
            );
          var C = a.pop,
            O = a.sort,
            P = a.splice,
            I = "[\\x20\\t\\r\\n\\f]",
            N = new RegExp(
              "^" + I + "+|((?:^|[^\\\\])(?:\\\\.)*)" + I + "+$",
              "g"
            );
          T.contains = function (e, t) {
            var r = t && t.parentNode;
            return (
              e === r ||
              !(
                !r ||
                1 !== r.nodeType ||
                !(e.contains
                  ? e.contains(r)
                  : e.compareDocumentPosition &&
                    16 & e.compareDocumentPosition(r))
              )
            );
          };
          var R = /([\0-\x1f\x7f]|^-?\d)|^-$|[^\x80-\uFFFF\w-]/g;
          function D(e, t) {
            return t
              ? "\0" === e
                ? "\ufffd"
                : e.slice(0, -1) +
                  "\\" +
                  e.charCodeAt(e.length - 1).toString(16) +
                  " "
              : "\\" + e;
          }
          T.escapeSelector = function (e) {
            return (e + "").replace(R, D);
          };
          var F = b,
            j = c;
          !(function () {
            var e,
              t,
              r,
              i,
              o,
              u,
              c,
              d,
              p,
              h,
              m = j,
              y = T.expando,
              v = 0,
              b = 0,
              _ = ee(),
              E = ee(),
              w = ee(),
              x = ee(),
              S = function (e, t) {
                return e === t && (o = !0), 0;
              },
              A =
                "checked|selected|async|autofocus|autoplay|controls|defer|disabled|hidden|ismap|loop|multiple|open|readonly|required|scoped",
              R =
                "(?:\\\\[\\da-fA-F]{1,6}" +
                I +
                "?|\\\\[^\\r\\n\\f]|[\\w-]|[^\0-\\x7f])+",
              D =
                "\\[" +
                I +
                "*(" +
                R +
                ")(?:" +
                I +
                "*([*^$|!~]?=)" +
                I +
                "*(?:'((?:\\\\.|[^\\\\'])*)'|\"((?:\\\\.|[^\\\\\"])*)\"|(" +
                R +
                "))|)" +
                I +
                "*\\]",
              L =
                ":(" +
                R +
                ")(?:\\((('((?:\\\\.|[^\\\\'])*)'|\"((?:\\\\.|[^\\\\\"])*)\")|((?:\\\\.|[^\\\\()[\\]]|" +
                D +
                ")*)|.*)\\)|)",
              M = new RegExp(I + "+", "g"),
              B = new RegExp("^" + I + "*," + I + "*"),
              V = new RegExp("^" + I + "*([>+~]|" + I + ")" + I + "*"),
              U = new RegExp(I + "|>"),
              H = new RegExp(L),
              q = new RegExp("^" + R + "$"),
              $ = {
                ID: new RegExp("^#(" + R + ")"),
                CLASS: new RegExp("^\\.(" + R + ")"),
                TAG: new RegExp("^(" + R + "|[*])"),
                ATTR: new RegExp("^" + D),
                PSEUDO: new RegExp("^" + L),
                CHILD: new RegExp(
                  "^:(only|first|last|nth|nth-last)-(child|of-type)(?:\\(" +
                    I +
                    "*(even|odd|(([+-]|)(\\d*)n|)" +
                    I +
                    "*(?:([+-]|)" +
                    I +
                    "*(\\d+)|))" +
                    I +
                    "*\\)|)",
                  "i"
                ),
                bool: new RegExp("^(?:" + A + ")$", "i"),
                needsContext: new RegExp(
                  "^" +
                    I +
                    "*[>+~]|:(even|odd|eq|gt|lt|nth|first|last)(?:\\(" +
                    I +
                    "*((?:-\\d)?\\d*)" +
                    I +
                    "*\\)|)(?=[^-]|$)",
                  "i"
                ),
              },
              W = /^(?:input|select|textarea|button)$/i,
              z = /^h\d$/i,
              G = /^(?:#([\w-]+)|(\w+)|\.([\w-]+))$/,
              K = /[+~]/,
              J = new RegExp(
                "\\\\[\\da-fA-F]{1,6}" + I + "?|\\\\([^\\r\\n\\f])",
                "g"
              ),
              Y = function (e, t) {
                var r = "0x" + e.slice(1) - 65536;
                return (
                  t ||
                  (r < 0
                    ? String.fromCharCode(r + 65536)
                    : String.fromCharCode(
                        (r >> 10) | 55296,
                        (1023 & r) | 56320
                      ))
                );
              },
              Q = function () {
                ue();
              },
              X = pe(
                function (e) {
                  return !0 === e.disabled && k(e, "fieldset");
                },
                { dir: "parentNode", next: "legend" }
              );
            try {
              m.apply((a = s.call(F.childNodes)), F.childNodes),
                a[F.childNodes.length].nodeType;
            } catch (e) {
              m = {
                apply: function (e, t) {
                  j.apply(e, s.call(t));
                },
                call: function (e) {
                  j.apply(e, s.call(arguments, 1));
                },
              };
            }
            function Z(e, t, r, n) {
              var i,
                a,
                o,
                s,
                c,
                l,
                f,
                h = t && t.ownerDocument,
                v = t ? t.nodeType : 9;
              if (
                ((r = r || []),
                "string" != typeof e || !e || (1 !== v && 9 !== v && 11 !== v))
              )
                return r;
              if (!n && (ue(t), (t = t || u), d)) {
                if (11 !== v && (c = G.exec(e)))
                  if ((i = c[1])) {
                    if (9 === v) {
                      if (!(o = t.getElementById(i))) return r;
                      if (o.id === i) return m.call(r, o), r;
                    } else if (
                      h &&
                      (o = h.getElementById(i)) &&
                      Z.contains(t, o) &&
                      o.id === i
                    )
                      return m.call(r, o), r;
                  } else {
                    if (c[2]) return m.apply(r, t.getElementsByTagName(e)), r;
                    if ((i = c[3]) && t.getElementsByClassName)
                      return m.apply(r, t.getElementsByClassName(i)), r;
                  }
                if (!(x[e + " "] || (p && p.test(e)))) {
                  if (((f = e), (h = t), 1 === v && (U.test(e) || V.test(e)))) {
                    for (
                      ((h = (K.test(e) && se(t.parentNode)) || t) == t &&
                        g.scope) ||
                        ((s = t.getAttribute("id"))
                          ? (s = T.escapeSelector(s))
                          : t.setAttribute("id", (s = y))),
                        a = (l = le(e)).length;
                      a--;

                    )
                      l[a] = (s ? "#" + s : ":scope") + " " + de(l[a]);
                    f = l.join(",");
                  }
                  try {
                    return m.apply(r, h.querySelectorAll(f)), r;
                  } catch (t) {
                    x(e, !0);
                  } finally {
                    s === y && t.removeAttribute("id");
                  }
                }
              }
              return ve(e.replace(N, "$1"), t, r, n);
            }
            function ee() {
              var e = [];
              return function r(n, i) {
                return (
                  e.push(n + " ") > t.cacheLength && delete r[e.shift()],
                  (r[n + " "] = i)
                );
              };
            }
            function te(e) {
              return (e[y] = !0), e;
            }
            function re(e) {
              var t = u.createElement("fieldset");
              try {
                return !!e(t);
              } catch (e) {
                return !1;
              } finally {
                t.parentNode && t.parentNode.removeChild(t), (t = null);
              }
            }
            function ne(e) {
              return function (t) {
                return k(t, "input") && t.type === e;
              };
            }
            function ie(e) {
              return function (t) {
                return (k(t, "input") || k(t, "button")) && t.type === e;
              };
            }
            function ae(e) {
              return function (t) {
                return "form" in t
                  ? t.parentNode && !1 === t.disabled
                    ? "label" in t
                      ? "label" in t.parentNode
                        ? t.parentNode.disabled === e
                        : t.disabled === e
                      : t.isDisabled === e ||
                        (t.isDisabled !== !e && X(t) === e)
                    : t.disabled === e
                  : "label" in t && t.disabled === e;
              };
            }
            function oe(e) {
              return te(function (t) {
                return (
                  (t = +t),
                  te(function (r, n) {
                    for (var i, a = e([], r.length, t), o = a.length; o--; )
                      r[(i = a[o])] && (r[i] = !(n[i] = r[i]));
                  })
                );
              });
            }
            function se(e) {
              return e && void 0 !== e.getElementsByTagName && e;
            }
            function ue(e) {
              var r,
                n = e ? e.ownerDocument || e : F;
              return n != u && 9 === n.nodeType && n.documentElement
                ? ((c = (u = n).documentElement),
                  (d = !T.isXMLDoc(u)),
                  (h =
                    c.matches ||
                    c.webkitMatchesSelector ||
                    c.msMatchesSelector),
                  c.msMatchesSelector &&
                    F != u &&
                    (r = u.defaultView) &&
                    r.top !== r &&
                    r.addEventListener("unload", Q),
                  (g.getById = re(function (e) {
                    return (
                      (c.appendChild(e).id = T.expando),
                      !u.getElementsByName ||
                        !u.getElementsByName(T.expando).length
                    );
                  })),
                  (g.disconnectedMatch = re(function (e) {
                    return h.call(e, "*");
                  })),
                  (g.scope = re(function () {
                    return u.querySelectorAll(":scope");
                  })),
                  (g.cssHas = re(function () {
                    try {
                      return u.querySelector(":has(*,:jqfake)"), !1;
                    } catch (e) {
                      return !0;
                    }
                  })),
                  g.getById
                    ? ((t.filter.ID = function (e) {
                        var t = e.replace(J, Y);
                        return function (e) {
                          return e.getAttribute("id") === t;
                        };
                      }),
                      (t.find.ID = function (e, t) {
                        if (void 0 !== t.getElementById && d) {
                          var r = t.getElementById(e);
                          return r ? [r] : [];
                        }
                      }))
                    : ((t.filter.ID = function (e) {
                        var t = e.replace(J, Y);
                        return function (e) {
                          var r =
                            void 0 !== e.getAttributeNode &&
                            e.getAttributeNode("id");
                          return r && r.value === t;
                        };
                      }),
                      (t.find.ID = function (e, t) {
                        if (void 0 !== t.getElementById && d) {
                          var r,
                            n,
                            i,
                            a = t.getElementById(e);
                          if (a) {
                            if ((r = a.getAttributeNode("id")) && r.value === e)
                              return [a];
                            for (
                              i = t.getElementsByName(e), n = 0;
                              (a = i[n++]);

                            )
                              if (
                                (r = a.getAttributeNode("id")) &&
                                r.value === e
                              )
                                return [a];
                          }
                          return [];
                        }
                      })),
                  (t.find.TAG = function (e, t) {
                    return void 0 !== t.getElementsByTagName
                      ? t.getElementsByTagName(e)
                      : t.querySelectorAll(e);
                  }),
                  (t.find.CLASS = function (e, t) {
                    if (void 0 !== t.getElementsByClassName && d)
                      return t.getElementsByClassName(e);
                  }),
                  (p = []),
                  re(function (e) {
                    var t;
                    (c.appendChild(e).innerHTML =
                      "<a id='" +
                      y +
                      "' href='' disabled='disabled'></a><select id='" +
                      y +
                      "-\r\\' disabled='disabled'><option selected=''></option></select>"),
                      e.querySelectorAll("[selected]").length ||
                        p.push("\\[" + I + "*(?:value|" + A + ")"),
                      e.querySelectorAll("[id~=" + y + "-]").length ||
                        p.push("~="),
                      e.querySelectorAll("a#" + y + "+*").length ||
                        p.push(".#.+[+~]"),
                      e.querySelectorAll(":checked").length ||
                        p.push(":checked"),
                      (t = u.createElement("input")).setAttribute(
                        "type",
                        "hidden"
                      ),
                      e.appendChild(t).setAttribute("name", "D"),
                      (c.appendChild(e).disabled = !0),
                      2 !== e.querySelectorAll(":disabled").length &&
                        p.push(":enabled", ":disabled"),
                      (t = u.createElement("input")).setAttribute("name", ""),
                      e.appendChild(t),
                      e.querySelectorAll("[name='']").length ||
                        p.push(
                          "\\[" + I + "*name" + I + "*=" + I + "*(?:''|\"\")"
                        );
                  }),
                  g.cssHas || p.push(":has"),
                  (p = p.length && new RegExp(p.join("|"))),
                  (S = function (e, t) {
                    if (e === t) return (o = !0), 0;
                    var r =
                      !e.compareDocumentPosition - !t.compareDocumentPosition;
                    return (
                      r ||
                      (1 &
                        (r =
                          (e.ownerDocument || e) == (t.ownerDocument || t)
                            ? e.compareDocumentPosition(t)
                            : 1) ||
                      (!g.sortDetached && t.compareDocumentPosition(e) === r)
                        ? e === u || (e.ownerDocument == F && Z.contains(F, e))
                          ? -1
                          : t === u ||
                            (t.ownerDocument == F && Z.contains(F, t))
                          ? 1
                          : i
                          ? l.call(i, e) - l.call(i, t)
                          : 0
                        : 4 & r
                        ? -1
                        : 1)
                    );
                  }),
                  u)
                : u;
            }
            for (e in ((Z.matches = function (e, t) {
              return Z(e, null, null, t);
            }),
            (Z.matchesSelector = function (e, t) {
              if ((ue(e), d && !x[t + " "] && (!p || !p.test(t))))
                try {
                  var r = h.call(e, t);
                  if (
                    r ||
                    g.disconnectedMatch ||
                    (e.document && 11 !== e.document.nodeType)
                  )
                    return r;
                } catch (e) {
                  x(t, !0);
                }
              return Z(t, u, null, [e]).length > 0;
            }),
            (Z.contains = function (e, t) {
              return (e.ownerDocument || e) != u && ue(e), T.contains(e, t);
            }),
            (Z.attr = function (e, r) {
              (e.ownerDocument || e) != u && ue(e);
              var n = t.attrHandle[r.toLowerCase()],
                i =
                  n && f.call(t.attrHandle, r.toLowerCase())
                    ? n(e, r, !d)
                    : void 0;
              return void 0 !== i ? i : e.getAttribute(r);
            }),
            (Z.error = function (e) {
              throw new Error("Syntax error, unrecognized expression: " + e);
            }),
            (T.uniqueSort = function (e) {
              var t,
                r = [],
                n = 0,
                a = 0;
              if (
                ((o = !g.sortStable),
                (i = !g.sortStable && s.call(e, 0)),
                O.call(e, S),
                o)
              ) {
                for (; (t = e[a++]); ) t === e[a] && (n = r.push(a));
                for (; n--; ) P.call(e, r[n], 1);
              }
              return (i = null), e;
            }),
            (T.fn.uniqueSort = function () {
              return this.pushStack(T.uniqueSort(s.apply(this)));
            }),
            (t = T.expr =
              {
                cacheLength: 50,
                createPseudo: te,
                match: $,
                attrHandle: {},
                find: {},
                relative: {
                  ">": { dir: "parentNode", first: !0 },
                  " ": { dir: "parentNode" },
                  "+": { dir: "previousSibling", first: !0 },
                  "~": { dir: "previousSibling" },
                },
                preFilter: {
                  ATTR: function (e) {
                    return (
                      (e[1] = e[1].replace(J, Y)),
                      (e[3] = (e[3] || e[4] || e[5] || "").replace(J, Y)),
                      "~=" === e[2] && (e[3] = " " + e[3] + " "),
                      e.slice(0, 4)
                    );
                  },
                  CHILD: function (e) {
                    return (
                      (e[1] = e[1].toLowerCase()),
                      "nth" === e[1].slice(0, 3)
                        ? (e[3] || Z.error(e[0]),
                          (e[4] = +(e[4]
                            ? e[5] + (e[6] || 1)
                            : 2 * ("even" === e[3] || "odd" === e[3]))),
                          (e[5] = +(e[7] + e[8] || "odd" === e[3])))
                        : e[3] && Z.error(e[0]),
                      e
                    );
                  },
                  PSEUDO: function (e) {
                    var t,
                      r = !e[6] && e[2];
                    return $.CHILD.test(e[0])
                      ? null
                      : (e[3]
                          ? (e[2] = e[4] || e[5] || "")
                          : r &&
                            H.test(r) &&
                            (t = le(r, !0)) &&
                            (t = r.indexOf(")", r.length - t) - r.length) &&
                            ((e[0] = e[0].slice(0, t)), (e[2] = r.slice(0, t))),
                        e.slice(0, 3));
                  },
                },
                filter: {
                  TAG: function (e) {
                    var t = e.replace(J, Y).toLowerCase();
                    return "*" === e
                      ? function () {
                          return !0;
                        }
                      : function (e) {
                          return k(e, t);
                        };
                  },
                  CLASS: function (e) {
                    var t = _[e + " "];
                    return (
                      t ||
                      ((t = new RegExp(
                        "(^|" + I + ")" + e + "(" + I + "|$)"
                      )) &&
                        _(e, function (e) {
                          return t.test(
                            ("string" == typeof e.className && e.className) ||
                              (void 0 !== e.getAttribute &&
                                e.getAttribute("class")) ||
                              ""
                          );
                        }))
                    );
                  },
                  ATTR: function (e, t, r) {
                    return function (n) {
                      var i = Z.attr(n, e);
                      return null == i
                        ? "!=" === t
                        : !t ||
                            ((i += ""),
                            "=" === t
                              ? i === r
                              : "!=" === t
                              ? i !== r
                              : "^=" === t
                              ? r && 0 === i.indexOf(r)
                              : "*=" === t
                              ? r && i.indexOf(r) > -1
                              : "$=" === t
                              ? r && i.slice(-r.length) === r
                              : "~=" === t
                              ? (" " + i.replace(M, " ") + " ").indexOf(r) > -1
                              : "|=" === t &&
                                (i === r ||
                                  i.slice(0, r.length + 1) === r + "-"));
                    };
                  },
                  CHILD: function (e, t, r, n, i) {
                    var a = "nth" !== e.slice(0, 3),
                      o = "last" !== e.slice(-4),
                      s = "of-type" === t;
                    return 1 === n && 0 === i
                      ? function (e) {
                          return !!e.parentNode;
                        }
                      : function (t, r, u) {
                          var c,
                            l,
                            d,
                            p,
                            f,
                            h = a !== o ? "nextSibling" : "previousSibling",
                            m = t.parentNode,
                            g = s && t.nodeName.toLowerCase(),
                            b = !u && !s,
                            _ = !1;
                          if (m) {
                            if (a) {
                              for (; h; ) {
                                for (d = t; (d = d[h]); )
                                  if (s ? k(d, g) : 1 === d.nodeType) return !1;
                                f = h = "only" === e && !f && "nextSibling";
                              }
                              return !0;
                            }
                            if (
                              ((f = [o ? m.firstChild : m.lastChild]), o && b)
                            ) {
                              for (
                                _ =
                                  (p =
                                    (c =
                                      (l = m[y] || (m[y] = {}))[e] || [])[0] ===
                                      v && c[1]) && c[2],
                                  d = p && m.childNodes[p];
                                (d =
                                  (++p && d && d[h]) || (_ = p = 0) || f.pop());

                              )
                                if (1 === d.nodeType && ++_ && d === t) {
                                  l[e] = [v, p, _];
                                  break;
                                }
                            } else if (
                              (b &&
                                (_ = p =
                                  (c =
                                    (l = t[y] || (t[y] = {}))[e] || [])[0] ===
                                    v && c[1]),
                              !1 === _)
                            )
                              for (
                                ;
                                (d =
                                  (++p && d && d[h]) ||
                                  (_ = p = 0) ||
                                  f.pop()) &&
                                (!(s ? k(d, g) : 1 === d.nodeType) ||
                                  !++_ ||
                                  (b && ((l = d[y] || (d[y] = {}))[e] = [v, _]),
                                  d !== t));

                              );
                            return (_ -= i) === n || (_ % n == 0 && _ / n >= 0);
                          }
                        };
                  },
                  PSEUDO: function (e, r) {
                    var n,
                      i =
                        t.pseudos[e] ||
                        t.setFilters[e.toLowerCase()] ||
                        Z.error("unsupported pseudo: " + e);
                    return i[y]
                      ? i(r)
                      : i.length > 1
                      ? ((n = [e, e, "", r]),
                        t.setFilters.hasOwnProperty(e.toLowerCase())
                          ? te(function (e, t) {
                              for (var n, a = i(e, r), o = a.length; o--; )
                                e[(n = l.call(e, a[o]))] = !(t[n] = a[o]);
                            })
                          : function (e) {
                              return i(e, 0, n);
                            })
                      : i;
                  },
                },
                pseudos: {
                  not: te(function (e) {
                    var t = [],
                      r = [],
                      n = ye(e.replace(N, "$1"));
                    return n[y]
                      ? te(function (e, t, r, i) {
                          for (
                            var a, o = n(e, null, i, []), s = e.length;
                            s--;

                          )
                            (a = o[s]) && (e[s] = !(t[s] = a));
                        })
                      : function (e, i, a) {
                          return (
                            (t[0] = e),
                            n(t, null, a, r),
                            (t[0] = null),
                            !r.pop()
                          );
                        };
                  }),
                  has: te(function (e) {
                    return function (t) {
                      return Z(e, t).length > 0;
                    };
                  }),
                  contains: te(function (e) {
                    return (
                      (e = e.replace(J, Y)),
                      function (t) {
                        return (t.textContent || T.text(t)).indexOf(e) > -1;
                      }
                    );
                  }),
                  lang: te(function (e) {
                    return (
                      q.test(e || "") || Z.error("unsupported lang: " + e),
                      (e = e.replace(J, Y).toLowerCase()),
                      function (t) {
                        var r;
                        do {
                          if (
                            (r = d
                              ? t.lang
                              : t.getAttribute("xml:lang") ||
                                t.getAttribute("lang"))
                          )
                            return (
                              (r = r.toLowerCase()) === e ||
                              0 === r.indexOf(e + "-")
                            );
                        } while ((t = t.parentNode) && 1 === t.nodeType);
                        return !1;
                      }
                    );
                  }),
                  target: function (e) {
                    var t = n.location && n.location.hash;
                    return t && t.slice(1) === e.id;
                  },
                  root: function (e) {
                    return e === c;
                  },
                  focus: function (e) {
                    return (
                      e ===
                        (function () {
                          try {
                            return u.activeElement;
                          } catch (e) {}
                        })() &&
                      u.hasFocus() &&
                      !!(e.type || e.href || ~e.tabIndex)
                    );
                  },
                  enabled: ae(!1),
                  disabled: ae(!0),
                  checked: function (e) {
                    return (
                      (k(e, "input") && !!e.checked) ||
                      (k(e, "option") && !!e.selected)
                    );
                  },
                  selected: function (e) {
                    return (
                      e.parentNode && e.parentNode.selectedIndex,
                      !0 === e.selected
                    );
                  },
                  empty: function (e) {
                    for (e = e.firstChild; e; e = e.nextSibling)
                      if (e.nodeType < 6) return !1;
                    return !0;
                  },
                  parent: function (e) {
                    return !t.pseudos.empty(e);
                  },
                  header: function (e) {
                    return z.test(e.nodeName);
                  },
                  input: function (e) {
                    return W.test(e.nodeName);
                  },
                  button: function (e) {
                    return (
                      (k(e, "input") && "button" === e.type) || k(e, "button")
                    );
                  },
                  text: function (e) {
                    var t;
                    return (
                      k(e, "input") &&
                      "text" === e.type &&
                      (null == (t = e.getAttribute("type")) ||
                        "text" === t.toLowerCase())
                    );
                  },
                  first: oe(function () {
                    return [0];
                  }),
                  last: oe(function (e, t) {
                    return [t - 1];
                  }),
                  eq: oe(function (e, t, r) {
                    return [r < 0 ? r + t : r];
                  }),
                  even: oe(function (e, t) {
                    for (var r = 0; r < t; r += 2) e.push(r);
                    return e;
                  }),
                  odd: oe(function (e, t) {
                    for (var r = 1; r < t; r += 2) e.push(r);
                    return e;
                  }),
                  lt: oe(function (e, t, r) {
                    var n;
                    for (n = r < 0 ? r + t : r > t ? t : r; --n >= 0; )
                      e.push(n);
                    return e;
                  }),
                  gt: oe(function (e, t, r) {
                    for (var n = r < 0 ? r + t : r; ++n < t; ) e.push(n);
                    return e;
                  }),
                },
              }),
            (t.pseudos.nth = t.pseudos.eq),
            { radio: !0, checkbox: !0, file: !0, password: !0, image: !0 }))
              t.pseudos[e] = ne(e);
            for (e in { submit: !0, reset: !0 }) t.pseudos[e] = ie(e);
            function ce() {}
            function le(e, r) {
              var n,
                i,
                a,
                o,
                s,
                u,
                c,
                l = E[e + " "];
              if (l) return r ? 0 : l.slice(0);
              for (s = e, u = [], c = t.preFilter; s; ) {
                for (o in ((n && !(i = B.exec(s))) ||
                  (i && (s = s.slice(i[0].length) || s), u.push((a = []))),
                (n = !1),
                (i = V.exec(s)) &&
                  ((n = i.shift()),
                  a.push({ value: n, type: i[0].replace(N, " ") }),
                  (s = s.slice(n.length))),
                t.filter))
                  !(i = $[o].exec(s)) ||
                    (c[o] && !(i = c[o](i))) ||
                    ((n = i.shift()),
                    a.push({ value: n, type: o, matches: i }),
                    (s = s.slice(n.length)));
                if (!n) break;
              }
              return r ? s.length : s ? Z.error(e) : E(e, u).slice(0);
            }
            function de(e) {
              for (var t = 0, r = e.length, n = ""; t < r; t++) n += e[t].value;
              return n;
            }
            function pe(e, t, r) {
              var n = t.dir,
                i = t.next,
                a = i || n,
                o = r && "parentNode" === a,
                s = b++;
              return t.first
                ? function (t, r, i) {
                    for (; (t = t[n]); )
                      if (1 === t.nodeType || o) return e(t, r, i);
                    return !1;
                  }
                : function (t, r, u) {
                    var c,
                      l,
                      d = [v, s];
                    if (u) {
                      for (; (t = t[n]); )
                        if ((1 === t.nodeType || o) && e(t, r, u)) return !0;
                    } else
                      for (; (t = t[n]); )
                        if (1 === t.nodeType || o)
                          if (((l = t[y] || (t[y] = {})), i && k(t, i)))
                            t = t[n] || t;
                          else {
                            if ((c = l[a]) && c[0] === v && c[1] === s)
                              return (d[2] = c[2]);
                            if (((l[a] = d), (d[2] = e(t, r, u)))) return !0;
                          }
                    return !1;
                  };
            }
            function fe(e) {
              return e.length > 1
                ? function (t, r, n) {
                    for (var i = e.length; i--; ) if (!e[i](t, r, n)) return !1;
                    return !0;
                  }
                : e[0];
            }
            function he(e, t, r, n, i) {
              for (
                var a, o = [], s = 0, u = e.length, c = null != t;
                s < u;
                s++
              )
                (a = e[s]) &&
                  ((r && !r(a, n, i)) || (o.push(a), c && t.push(s)));
              return o;
            }
            function me(e, t, r, n, i, a) {
              return (
                n && !n[y] && (n = me(n)),
                i && !i[y] && (i = me(i, a)),
                te(function (a, o, s, u) {
                  var c,
                    d,
                    p,
                    f,
                    h = [],
                    g = [],
                    y = o.length,
                    v =
                      a ||
                      (function (e, t, r) {
                        for (var n = 0, i = t.length; n < i; n++) Z(e, t[n], r);
                        return r;
                      })(t || "*", s.nodeType ? [s] : s, []),
                    b = !e || (!a && t) ? v : he(v, h, e, s, u);
                  if (
                    (r
                      ? r(b, (f = i || (a ? e : y || n) ? [] : o), s, u)
                      : (f = b),
                    n)
                  )
                    for (c = he(f, g), n(c, [], s, u), d = c.length; d--; )
                      (p = c[d]) && (f[g[d]] = !(b[g[d]] = p));
                  if (a) {
                    if (i || e) {
                      if (i) {
                        for (c = [], d = f.length; d--; )
                          (p = f[d]) && c.push((b[d] = p));
                        i(null, (f = []), c, u);
                      }
                      for (d = f.length; d--; )
                        (p = f[d]) &&
                          (c = i ? l.call(a, p) : h[d]) > -1 &&
                          (a[c] = !(o[c] = p));
                    }
                  } else (f = he(f === o ? f.splice(y, f.length) : f)), i ? i(null, o, f, u) : m.apply(o, f);
                })
              );
            }
            function ge(e) {
              for (
                var n,
                  i,
                  a,
                  o = e.length,
                  s = t.relative[e[0].type],
                  u = s || t.relative[" "],
                  c = s ? 1 : 0,
                  d = pe(
                    function (e) {
                      return e === n;
                    },
                    u,
                    !0
                  ),
                  p = pe(
                    function (e) {
                      return l.call(n, e) > -1;
                    },
                    u,
                    !0
                  ),
                  f = [
                    function (e, t, i) {
                      var a =
                        (!s && (i || t != r)) ||
                        ((n = t).nodeType ? d(e, t, i) : p(e, t, i));
                      return (n = null), a;
                    },
                  ];
                c < o;
                c++
              )
                if ((i = t.relative[e[c].type])) f = [pe(fe(f), i)];
                else {
                  if ((i = t.filter[e[c].type].apply(null, e[c].matches))[y]) {
                    for (a = ++c; a < o && !t.relative[e[a].type]; a++);
                    return me(
                      c > 1 && fe(f),
                      c > 1 &&
                        de(
                          e
                            .slice(0, c - 1)
                            .concat({ value: " " === e[c - 2].type ? "*" : "" })
                        ).replace(N, "$1"),
                      i,
                      c < a && ge(e.slice(c, a)),
                      a < o && ge((e = e.slice(a))),
                      a < o && de(e)
                    );
                  }
                  f.push(i);
                }
              return fe(f);
            }
            function ye(e, n) {
              var i,
                a = [],
                o = [],
                s = w[e + " "];
              if (!s) {
                for (n || (n = le(e)), i = n.length; i--; )
                  (s = ge(n[i]))[y] ? a.push(s) : o.push(s);
                (s = w(
                  e,
                  (function (e, n) {
                    var i = n.length > 0,
                      a = e.length > 0,
                      o = function (o, s, c, l, p) {
                        var f,
                          h,
                          g,
                          y = 0,
                          b = "0",
                          _ = o && [],
                          E = [],
                          w = r,
                          x = o || (a && t.find.TAG("*", p)),
                          S = (v += null == w ? 1 : Math.random() || 0.1),
                          A = x.length;
                        for (
                          p && (r = s == u || s || p);
                          b !== A && null != (f = x[b]);
                          b++
                        ) {
                          if (a && f) {
                            for (
                              h = 0,
                                s || f.ownerDocument == u || (ue(f), (c = !d));
                              (g = e[h++]);

                            )
                              if (g(f, s || u, c)) {
                                m.call(l, f);
                                break;
                              }
                            p && (v = S);
                          }
                          i && ((f = !g && f) && y--, o && _.push(f));
                        }
                        if (((y += b), i && b !== y)) {
                          for (h = 0; (g = n[h++]); ) g(_, E, s, c);
                          if (o) {
                            if (y > 0)
                              for (; b--; ) _[b] || E[b] || (E[b] = C.call(l));
                            E = he(E);
                          }
                          m.apply(l, E),
                            p &&
                              !o &&
                              E.length > 0 &&
                              y + n.length > 1 &&
                              T.uniqueSort(l);
                        }
                        return p && ((v = S), (r = w)), _;
                      };
                    return i ? te(o) : o;
                  })(o, a)
                )),
                  (s.selector = e);
              }
              return s;
            }
            function ve(e, r, n, i) {
              var a,
                o,
                s,
                u,
                c,
                l = "function" == typeof e && e,
                p = !i && le((e = l.selector || e));
              if (((n = n || []), 1 === p.length)) {
                if (
                  (o = p[0] = p[0].slice(0)).length > 2 &&
                  "ID" === (s = o[0]).type &&
                  9 === r.nodeType &&
                  d &&
                  t.relative[o[1].type]
                ) {
                  if (
                    !(r = (t.find.ID(s.matches[0].replace(J, Y), r) || [])[0])
                  )
                    return n;
                  l && (r = r.parentNode),
                    (e = e.slice(o.shift().value.length));
                }
                for (
                  a = $.needsContext.test(e) ? 0 : o.length;
                  a-- && ((s = o[a]), !t.relative[(u = s.type)]);

                )
                  if (
                    (c = t.find[u]) &&
                    (i = c(
                      s.matches[0].replace(J, Y),
                      (K.test(o[0].type) && se(r.parentNode)) || r
                    ))
                  ) {
                    if ((o.splice(a, 1), !(e = i.length && de(o))))
                      return m.apply(n, i), n;
                    break;
                  }
              }
              return (
                (l || ye(e, p))(
                  i,
                  r,
                  !d,
                  n,
                  !r || (K.test(e) && se(r.parentNode)) || r
                ),
                n
              );
            }
            (ce.prototype = t.filters = t.pseudos),
              (t.setFilters = new ce()),
              (g.sortStable = y.split("").sort(S).join("") === y),
              ue(),
              (g.sortDetached = re(function (e) {
                return (
                  1 & e.compareDocumentPosition(u.createElement("fieldset"))
                );
              })),
              (T.find = Z),
              (T.expr[":"] = T.expr.pseudos),
              (T.unique = T.uniqueSort),
              (Z.compile = ye),
              (Z.select = ve),
              (Z.setDocument = ue),
              (Z.tokenize = le),
              (Z.escape = T.escapeSelector),
              (Z.getText = T.text),
              (Z.isXML = T.isXMLDoc),
              (Z.selectors = T.expr),
              (Z.support = T.support),
              (Z.uniqueSort = T.uniqueSort);
          })();
          var L = function (e, t, r) {
              for (
                var n = [], i = void 0 !== r;
                (e = e[t]) && 9 !== e.nodeType;

              )
                if (1 === e.nodeType) {
                  if (i && T(e).is(r)) break;
                  n.push(e);
                }
              return n;
            },
            M = function (e, t) {
              for (var r = []; e; e = e.nextSibling)
                1 === e.nodeType && e !== t && r.push(e);
              return r;
            },
            B = T.expr.match.needsContext,
            V =
              /^<([a-z][^\/\0>:\x20\t\r\n\f]*)[\x20\t\r\n\f]*\/?>(?:<\/\1>|)$/i;
          function U(e, t, r) {
            return y(t)
              ? T.grep(e, function (e, n) {
                  return !!t.call(e, n, e) !== r;
                })
              : t.nodeType
              ? T.grep(e, function (e) {
                  return (e === t) !== r;
                })
              : "string" != typeof t
              ? T.grep(e, function (e) {
                  return l.call(t, e) > -1 !== r;
                })
              : T.filter(t, e, r);
          }
          (T.filter = function (e, t, r) {
            var n = t[0];
            return (
              r && (e = ":not(" + e + ")"),
              1 === t.length && 1 === n.nodeType
                ? T.find.matchesSelector(n, e)
                  ? [n]
                  : []
                : T.find.matches(
                    e,
                    T.grep(t, function (e) {
                      return 1 === e.nodeType;
                    })
                  )
            );
          }),
            T.fn.extend({
              find: function (e) {
                var t,
                  r,
                  n = this.length,
                  i = this;
                if ("string" != typeof e)
                  return this.pushStack(
                    T(e).filter(function () {
                      for (t = 0; t < n; t++)
                        if (T.contains(i[t], this)) return !0;
                    })
                  );
                for (r = this.pushStack([]), t = 0; t < n; t++)
                  T.find(e, i[t], r);
                return n > 1 ? T.uniqueSort(r) : r;
              },
              filter: function (e) {
                return this.pushStack(U(this, e || [], !1));
              },
              not: function (e) {
                return this.pushStack(U(this, e || [], !0));
              },
              is: function (e) {
                return !!U(
                  this,
                  "string" == typeof e && B.test(e) ? T(e) : e || [],
                  !1
                ).length;
              },
            });
          var H,
            q = /^(?:\s*(<[\w\W]+>)[^>]*|#([\w-]+))$/;
          ((T.fn.init = function (e, t, r) {
            var n, i;
            if (!e) return this;
            if (((r = r || H), "string" == typeof e)) {
              if (
                !(n =
                  "<" === e[0] && ">" === e[e.length - 1] && e.length >= 3
                    ? [null, e, null]
                    : q.exec(e)) ||
                (!n[1] && t)
              )
                return !t || t.jquery
                  ? (t || r).find(e)
                  : this.constructor(t).find(e);
              if (n[1]) {
                if (
                  ((t = t instanceof T ? t[0] : t),
                  T.merge(
                    this,
                    T.parseHTML(
                      n[1],
                      t && t.nodeType ? t.ownerDocument || t : b,
                      !0
                    )
                  ),
                  V.test(n[1]) && T.isPlainObject(t))
                )
                  for (n in t) y(this[n]) ? this[n](t[n]) : this.attr(n, t[n]);
                return this;
              }
              return (
                (i = b.getElementById(n[2])) &&
                  ((this[0] = i), (this.length = 1)),
                this
              );
            }
            return e.nodeType
              ? ((this[0] = e), (this.length = 1), this)
              : y(e)
              ? void 0 !== r.ready
                ? r.ready(e)
                : e(T)
              : T.makeArray(e, this);
          }).prototype = T.fn),
            (H = T(b));
          var $ = /^(?:parents|prev(?:Until|All))/,
            W = { children: !0, contents: !0, next: !0, prev: !0 };
          function z(e, t) {
            for (; (e = e[t]) && 1 !== e.nodeType; );
            return e;
          }
          T.fn.extend({
            has: function (e) {
              var t = T(e, this),
                r = t.length;
              return this.filter(function () {
                for (var e = 0; e < r; e++)
                  if (T.contains(this, t[e])) return !0;
              });
            },
            closest: function (e, t) {
              var r,
                n = 0,
                i = this.length,
                a = [],
                o = "string" != typeof e && T(e);
              if (!B.test(e))
                for (; n < i; n++)
                  for (r = this[n]; r && r !== t; r = r.parentNode)
                    if (
                      r.nodeType < 11 &&
                      (o
                        ? o.index(r) > -1
                        : 1 === r.nodeType && T.find.matchesSelector(r, e))
                    ) {
                      a.push(r);
                      break;
                    }
              return this.pushStack(a.length > 1 ? T.uniqueSort(a) : a);
            },
            index: function (e) {
              return e
                ? "string" == typeof e
                  ? l.call(T(e), this[0])
                  : l.call(this, e.jquery ? e[0] : e)
                : this[0] && this[0].parentNode
                ? this.first().prevAll().length
                : -1;
            },
            add: function (e, t) {
              return this.pushStack(T.uniqueSort(T.merge(this.get(), T(e, t))));
            },
            addBack: function (e) {
              return this.add(
                null == e ? this.prevObject : this.prevObject.filter(e)
              );
            },
          }),
            T.each(
              {
                parent: function (e) {
                  var t = e.parentNode;
                  return t && 11 !== t.nodeType ? t : null;
                },
                parents: function (e) {
                  return L(e, "parentNode");
                },
                parentsUntil: function (e, t, r) {
                  return L(e, "parentNode", r);
                },
                next: function (e) {
                  return z(e, "nextSibling");
                },
                prev: function (e) {
                  return z(e, "previousSibling");
                },
                nextAll: function (e) {
                  return L(e, "nextSibling");
                },
                prevAll: function (e) {
                  return L(e, "previousSibling");
                },
                nextUntil: function (e, t, r) {
                  return L(e, "nextSibling", r);
                },
                prevUntil: function (e, t, r) {
                  return L(e, "previousSibling", r);
                },
                siblings: function (e) {
                  return M((e.parentNode || {}).firstChild, e);
                },
                children: function (e) {
                  return M(e.firstChild);
                },
                contents: function (e) {
                  return null != e.contentDocument && o(e.contentDocument)
                    ? e.contentDocument
                    : (k(e, "template") && (e = e.content || e),
                      T.merge([], e.childNodes));
                },
              },
              function (e, t) {
                T.fn[e] = function (r, n) {
                  var i = T.map(this, t, r);
                  return (
                    "Until" !== e.slice(-5) && (n = r),
                    n && "string" == typeof n && (i = T.filter(n, i)),
                    this.length > 1 &&
                      (W[e] || T.uniqueSort(i), $.test(e) && i.reverse()),
                    this.pushStack(i)
                  );
                };
              }
            );
          var G = /[^\x20\t\r\n\f]+/g;
          function K(e) {
            return e;
          }
          function J(e) {
            throw e;
          }
          function Y(e, t, r, n) {
            var i;
            try {
              e && y((i = e.promise))
                ? i.call(e).done(t).fail(r)
                : e && y((i = e.then))
                ? i.call(e, t, r)
                : t.apply(void 0, [e].slice(n));
            } catch (e) {
              r.apply(void 0, [e]);
            }
          }
          (T.Callbacks = function (e) {
            e =
              "string" == typeof e
                ? (function (e) {
                    var t = {};
                    return (
                      T.each(e.match(G) || [], function (e, r) {
                        t[r] = !0;
                      }),
                      t
                    );
                  })(e)
                : T.extend({}, e);
            var t,
              r,
              n,
              i,
              a = [],
              o = [],
              s = -1,
              u = function () {
                for (i = i || e.once, n = t = !0; o.length; s = -1)
                  for (r = o.shift(); ++s < a.length; )
                    !1 === a[s].apply(r[0], r[1]) &&
                      e.stopOnFalse &&
                      ((s = a.length), (r = !1));
                e.memory || (r = !1), (t = !1), i && (a = r ? [] : "");
              },
              c = {
                add: function () {
                  return (
                    a &&
                      (r && !t && ((s = a.length - 1), o.push(r)),
                      (function t(r) {
                        T.each(r, function (r, n) {
                          y(n)
                            ? (e.unique && c.has(n)) || a.push(n)
                            : n && n.length && "string" !== w(n) && t(n);
                        });
                      })(arguments),
                      r && !t && u()),
                    this
                  );
                },
                remove: function () {
                  return (
                    T.each(arguments, function (e, t) {
                      for (var r; (r = T.inArray(t, a, r)) > -1; )
                        a.splice(r, 1), r <= s && s--;
                    }),
                    this
                  );
                },
                has: function (e) {
                  return e ? T.inArray(e, a) > -1 : a.length > 0;
                },
                empty: function () {
                  return a && (a = []), this;
                },
                disable: function () {
                  return (i = o = []), (a = r = ""), this;
                },
                disabled: function () {
                  return !a;
                },
                lock: function () {
                  return (i = o = []), r || t || (a = r = ""), this;
                },
                locked: function () {
                  return !!i;
                },
                fireWith: function (e, r) {
                  return (
                    i ||
                      ((r = [e, (r = r || []).slice ? r.slice() : r]),
                      o.push(r),
                      t || u()),
                    this
                  );
                },
                fire: function () {
                  return c.fireWith(this, arguments), this;
                },
                fired: function () {
                  return !!n;
                },
              };
            return c;
          }),
            T.extend({
              Deferred: function (e) {
                var t = [
                    [
                      "notify",
                      "progress",
                      T.Callbacks("memory"),
                      T.Callbacks("memory"),
                      2,
                    ],
                    [
                      "resolve",
                      "done",
                      T.Callbacks("once memory"),
                      T.Callbacks("once memory"),
                      0,
                      "resolved",
                    ],
                    [
                      "reject",
                      "fail",
                      T.Callbacks("once memory"),
                      T.Callbacks("once memory"),
                      1,
                      "rejected",
                    ],
                  ],
                  r = "pending",
                  i = {
                    state: function () {
                      return r;
                    },
                    always: function () {
                      return a.done(arguments).fail(arguments), this;
                    },
                    catch: function (e) {
                      return i.then(null, e);
                    },
                    pipe: function () {
                      var e = arguments;
                      return T.Deferred(function (r) {
                        T.each(t, function (t, n) {
                          var i = y(e[n[4]]) && e[n[4]];
                          a[n[1]](function () {
                            var e = i && i.apply(this, arguments);
                            e && y(e.promise)
                              ? e
                                  .promise()
                                  .progress(r.notify)
                                  .done(r.resolve)
                                  .fail(r.reject)
                              : r[n[0] + "With"](this, i ? [e] : arguments);
                          });
                        }),
                          (e = null);
                      }).promise();
                    },
                    then: function (e, r, i) {
                      var a = 0;
                      function o(e, t, r, i) {
                        return function () {
                          var s = this,
                            u = arguments,
                            c = function () {
                              var n, c;
                              if (!(e < a)) {
                                if ((n = r.apply(s, u)) === t.promise())
                                  throw new TypeError(
                                    "Thenable self-resolution"
                                  );
                                (c =
                                  n &&
                                  ("object" == typeof n ||
                                    "function" == typeof n) &&
                                  n.then),
                                  y(c)
                                    ? i
                                      ? c.call(n, o(a, t, K, i), o(a, t, J, i))
                                      : (a++,
                                        c.call(
                                          n,
                                          o(a, t, K, i),
                                          o(a, t, J, i),
                                          o(a, t, K, t.notifyWith)
                                        ))
                                    : (r !== K && ((s = void 0), (u = [n])),
                                      (i || t.resolveWith)(s, u));
                              }
                            },
                            l = i
                              ? c
                              : function () {
                                  try {
                                    c();
                                  } catch (n) {
                                    T.Deferred.exceptionHook &&
                                      T.Deferred.exceptionHook(n, l.error),
                                      e + 1 >= a &&
                                        (r !== J && ((s = void 0), (u = [n])),
                                        t.rejectWith(s, u));
                                  }
                                };
                          e
                            ? l()
                            : (T.Deferred.getErrorHook
                                ? (l.error = T.Deferred.getErrorHook())
                                : T.Deferred.getStackHook &&
                                  (l.error = T.Deferred.getStackHook()),
                              n.setTimeout(l));
                        };
                      }
                      return T.Deferred(function (n) {
                        t[0][3].add(o(0, n, y(i) ? i : K, n.notifyWith)),
                          t[1][3].add(o(0, n, y(e) ? e : K)),
                          t[2][3].add(o(0, n, y(r) ? r : J));
                      }).promise();
                    },
                    promise: function (e) {
                      return null != e ? T.extend(e, i) : i;
                    },
                  },
                  a = {};
                return (
                  T.each(t, function (e, n) {
                    var o = n[2],
                      s = n[5];
                    (i[n[1]] = o.add),
                      s &&
                        o.add(
                          function () {
                            r = s;
                          },
                          t[3 - e][2].disable,
                          t[3 - e][3].disable,
                          t[0][2].lock,
                          t[0][3].lock
                        ),
                      o.add(n[3].fire),
                      (a[n[0]] = function () {
                        return (
                          a[n[0] + "With"](
                            this === a ? void 0 : this,
                            arguments
                          ),
                          this
                        );
                      }),
                      (a[n[0] + "With"] = o.fireWith);
                  }),
                  i.promise(a),
                  e && e.call(a, a),
                  a
                );
              },
              when: function (e) {
                var t = arguments.length,
                  r = t,
                  n = Array(r),
                  i = s.call(arguments),
                  a = T.Deferred(),
                  o = function (e) {
                    return function (r) {
                      (n[e] = this),
                        (i[e] = arguments.length > 1 ? s.call(arguments) : r),
                        --t || a.resolveWith(n, i);
                    };
                  };
                if (
                  t <= 1 &&
                  (Y(e, a.done(o(r)).resolve, a.reject, !t),
                  "pending" === a.state() || y(i[r] && i[r].then))
                )
                  return a.then();
                for (; r--; ) Y(i[r], o(r), a.reject);
                return a.promise();
              },
            });
          var Q = /^(Eval|Internal|Range|Reference|Syntax|Type|URI)Error$/;
          (T.Deferred.exceptionHook = function (e, t) {
            n.console &&
              n.console.warn &&
              e &&
              Q.test(e.name) &&
              n.console.warn(
                "jQuery.Deferred exception: " + e.message,
                e.stack,
                t
              );
          }),
            (T.readyException = function (e) {
              n.setTimeout(function () {
                throw e;
              });
            });
          var X = T.Deferred();
          function Z() {
            b.removeEventListener("DOMContentLoaded", Z),
              n.removeEventListener("load", Z),
              T.ready();
          }
          (T.fn.ready = function (e) {
            return (
              X.then(e).catch(function (e) {
                T.readyException(e);
              }),
              this
            );
          }),
            T.extend({
              isReady: !1,
              readyWait: 1,
              ready: function (e) {
                (!0 === e ? --T.readyWait : T.isReady) ||
                  ((T.isReady = !0),
                  (!0 !== e && --T.readyWait > 0) || X.resolveWith(b, [T]));
              },
            }),
            (T.ready.then = X.then),
            "complete" === b.readyState ||
            ("loading" !== b.readyState && !b.documentElement.doScroll)
              ? n.setTimeout(T.ready)
              : (b.addEventListener("DOMContentLoaded", Z),
                n.addEventListener("load", Z));
          var ee = function (e, t, r, n, i, a, o) {
              var s = 0,
                u = e.length,
                c = null == r;
              if ("object" === w(r))
                for (s in ((i = !0), r)) ee(e, t, s, r[s], !0, a, o);
              else if (
                void 0 !== n &&
                ((i = !0),
                y(n) || (o = !0),
                c &&
                  (o
                    ? (t.call(e, n), (t = null))
                    : ((c = t),
                      (t = function (e, t, r) {
                        return c.call(T(e), r);
                      }))),
                t)
              )
                for (; s < u; s++)
                  t(e[s], r, o ? n : n.call(e[s], s, t(e[s], r)));
              return i ? e : c ? t.call(e) : u ? t(e[0], r) : a;
            },
            te = /^-ms-/,
            re = /-([a-z])/g;
          function ne(e, t) {
            return t.toUpperCase();
          }
          function ie(e) {
            return e.replace(te, "ms-").replace(re, ne);
          }
          var ae = function (e) {
            return 1 === e.nodeType || 9 === e.nodeType || !+e.nodeType;
          };
          function oe() {
            this.expando = T.expando + oe.uid++;
          }
          (oe.uid = 1),
            (oe.prototype = {
              cache: function (e) {
                var t = e[this.expando];
                return (
                  t ||
                    ((t = {}),
                    ae(e) &&
                      (e.nodeType
                        ? (e[this.expando] = t)
                        : Object.defineProperty(e, this.expando, {
                            value: t,
                            configurable: !0,
                          }))),
                  t
                );
              },
              set: function (e, t, r) {
                var n,
                  i = this.cache(e);
                if ("string" == typeof t) i[ie(t)] = r;
                else for (n in t) i[ie(n)] = t[n];
                return i;
              },
              get: function (e, t) {
                return void 0 === t
                  ? this.cache(e)
                  : e[this.expando] && e[this.expando][ie(t)];
              },
              access: function (e, t, r) {
                return void 0 === t ||
                  (t && "string" == typeof t && void 0 === r)
                  ? this.get(e, t)
                  : (this.set(e, t, r), void 0 !== r ? r : t);
              },
              remove: function (e, t) {
                var r,
                  n = e[this.expando];
                if (void 0 !== n) {
                  if (void 0 !== t) {
                    r = (t = Array.isArray(t)
                      ? t.map(ie)
                      : (t = ie(t)) in n
                      ? [t]
                      : t.match(G) || []).length;
                    for (; r--; ) delete n[t[r]];
                  }
                  (void 0 === t || T.isEmptyObject(n)) &&
                    (e.nodeType
                      ? (e[this.expando] = void 0)
                      : delete e[this.expando]);
                }
              },
              hasData: function (e) {
                var t = e[this.expando];
                return void 0 !== t && !T.isEmptyObject(t);
              },
            });
          var se = new oe(),
            ue = new oe(),
            ce = /^(?:\{[\w\W]*\}|\[[\w\W]*\])$/,
            le = /[A-Z]/g;
          function de(e, t, r) {
            var n;
            if (void 0 === r && 1 === e.nodeType)
              if (
                ((n = "data-" + t.replace(le, "-$&").toLowerCase()),
                "string" == typeof (r = e.getAttribute(n)))
              ) {
                try {
                  r = (function (e) {
                    return (
                      "true" === e ||
                      ("false" !== e &&
                        ("null" === e
                          ? null
                          : e === +e + ""
                          ? +e
                          : ce.test(e)
                          ? JSON.parse(e)
                          : e))
                    );
                  })(r);
                } catch (e) {}
                ue.set(e, t, r);
              } else r = void 0;
            return r;
          }
          T.extend({
            hasData: function (e) {
              return ue.hasData(e) || se.hasData(e);
            },
            data: function (e, t, r) {
              return ue.access(e, t, r);
            },
            removeData: function (e, t) {
              ue.remove(e, t);
            },
            _data: function (e, t, r) {
              return se.access(e, t, r);
            },
            _removeData: function (e, t) {
              se.remove(e, t);
            },
          }),
            T.fn.extend({
              data: function (e, t) {
                var r,
                  n,
                  i,
                  a = this[0],
                  o = a && a.attributes;
                if (void 0 === e) {
                  if (
                    this.length &&
                    ((i = ue.get(a)),
                    1 === a.nodeType && !se.get(a, "hasDataAttrs"))
                  ) {
                    for (r = o.length; r--; )
                      o[r] &&
                        0 === (n = o[r].name).indexOf("data-") &&
                        ((n = ie(n.slice(5))), de(a, n, i[n]));
                    se.set(a, "hasDataAttrs", !0);
                  }
                  return i;
                }
                return "object" == typeof e
                  ? this.each(function () {
                      ue.set(this, e);
                    })
                  : ee(
                      this,
                      function (t) {
                        var r;
                        if (a && void 0 === t)
                          return void 0 !== (r = ue.get(a, e)) ||
                            void 0 !== (r = de(a, e))
                            ? r
                            : void 0;
                        this.each(function () {
                          ue.set(this, e, t);
                        });
                      },
                      null,
                      t,
                      arguments.length > 1,
                      null,
                      !0
                    );
              },
              removeData: function (e) {
                return this.each(function () {
                  ue.remove(this, e);
                });
              },
            }),
            T.extend({
              queue: function (e, t, r) {
                var n;
                if (e)
                  return (
                    (t = (t || "fx") + "queue"),
                    (n = se.get(e, t)),
                    r &&
                      (!n || Array.isArray(r)
                        ? (n = se.access(e, t, T.makeArray(r)))
                        : n.push(r)),
                    n || []
                  );
              },
              dequeue: function (e, t) {
                t = t || "fx";
                var r = T.queue(e, t),
                  n = r.length,
                  i = r.shift(),
                  a = T._queueHooks(e, t);
                "inprogress" === i && ((i = r.shift()), n--),
                  i &&
                    ("fx" === t && r.unshift("inprogress"),
                    delete a.stop,
                    i.call(
                      e,
                      function () {
                        T.dequeue(e, t);
                      },
                      a
                    )),
                  !n && a && a.empty.fire();
              },
              _queueHooks: function (e, t) {
                var r = t + "queueHooks";
                return (
                  se.get(e, r) ||
                  se.access(e, r, {
                    empty: T.Callbacks("once memory").add(function () {
                      se.remove(e, [t + "queue", r]);
                    }),
                  })
                );
              },
            }),
            T.fn.extend({
              queue: function (e, t) {
                var r = 2;
                return (
                  "string" != typeof e && ((t = e), (e = "fx"), r--),
                  arguments.length < r
                    ? T.queue(this[0], e)
                    : void 0 === t
                    ? this
                    : this.each(function () {
                        var r = T.queue(this, e, t);
                        T._queueHooks(this, e),
                          "fx" === e &&
                            "inprogress" !== r[0] &&
                            T.dequeue(this, e);
                      })
                );
              },
              dequeue: function (e) {
                return this.each(function () {
                  T.dequeue(this, e);
                });
              },
              clearQueue: function (e) {
                return this.queue(e || "fx", []);
              },
              promise: function (e, t) {
                var r,
                  n = 1,
                  i = T.Deferred(),
                  a = this,
                  o = this.length,
                  s = function () {
                    --n || i.resolveWith(a, [a]);
                  };
                for (
                  "string" != typeof e && ((t = e), (e = void 0)),
                    e = e || "fx";
                  o--;

                )
                  (r = se.get(a[o], e + "queueHooks")) &&
                    r.empty &&
                    (n++, r.empty.add(s));
                return s(), i.promise(t);
              },
            });
          var pe = /[+-]?(?:\d*\.|)\d+(?:[eE][+-]?\d+|)/.source,
            fe = new RegExp("^(?:([+-])=|)(" + pe + ")([a-z%]*)$", "i"),
            he = ["Top", "Right", "Bottom", "Left"],
            me = b.documentElement,
            ge = function (e) {
              return T.contains(e.ownerDocument, e);
            },
            ye = { composed: !0 };
          me.getRootNode &&
            (ge = function (e) {
              return (
                T.contains(e.ownerDocument, e) ||
                e.getRootNode(ye) === e.ownerDocument
              );
            });
          var ve = function (e, t) {
            return (
              "none" === (e = t || e).style.display ||
              ("" === e.style.display &&
                ge(e) &&
                "none" === T.css(e, "display"))
            );
          };
          function be(e, t, r, n) {
            var i,
              a,
              o = 20,
              s = n
                ? function () {
                    return n.cur();
                  }
                : function () {
                    return T.css(e, t, "");
                  },
              u = s(),
              c = (r && r[3]) || (T.cssNumber[t] ? "" : "px"),
              l =
                e.nodeType &&
                (T.cssNumber[t] || ("px" !== c && +u)) &&
                fe.exec(T.css(e, t));
            if (l && l[3] !== c) {
              for (u /= 2, c = c || l[3], l = +u || 1; o--; )
                T.style(e, t, l + c),
                  (1 - a) * (1 - (a = s() / u || 0.5)) <= 0 && (o = 0),
                  (l /= a);
              (l *= 2), T.style(e, t, l + c), (r = r || []);
            }
            return (
              r &&
                ((l = +l || +u || 0),
                (i = r[1] ? l + (r[1] + 1) * r[2] : +r[2]),
                n && ((n.unit = c), (n.start = l), (n.end = i))),
              i
            );
          }
          var _e = {};
          function Ee(e) {
            var t,
              r = e.ownerDocument,
              n = e.nodeName,
              i = _e[n];
            return (
              i ||
              ((t = r.body.appendChild(r.createElement(n))),
              (i = T.css(t, "display")),
              t.parentNode.removeChild(t),
              "none" === i && (i = "block"),
              (_e[n] = i),
              i)
            );
          }
          function we(e, t) {
            for (var r, n, i = [], a = 0, o = e.length; a < o; a++)
              (n = e[a]).style &&
                ((r = n.style.display),
                t
                  ? ("none" === r &&
                      ((i[a] = se.get(n, "display") || null),
                      i[a] || (n.style.display = "")),
                    "" === n.style.display && ve(n) && (i[a] = Ee(n)))
                  : "none" !== r && ((i[a] = "none"), se.set(n, "display", r)));
            for (a = 0; a < o; a++) null != i[a] && (e[a].style.display = i[a]);
            return e;
          }
          T.fn.extend({
            show: function () {
              return we(this, !0);
            },
            hide: function () {
              return we(this);
            },
            toggle: function (e) {
              return "boolean" == typeof e
                ? e
                  ? this.show()
                  : this.hide()
                : this.each(function () {
                    ve(this) ? T(this).show() : T(this).hide();
                  });
            },
          });
          var xe,
            Se,
            Te = /^(?:checkbox|radio)$/i,
            Ae = /<([a-z][^\/\0>\x20\t\r\n\f]*)/i,
            ke = /^$|^module$|\/(?:java|ecma)script/i;
          (xe = b.createDocumentFragment().appendChild(b.createElement("div"))),
            (Se = b.createElement("input")).setAttribute("type", "radio"),
            Se.setAttribute("checked", "checked"),
            Se.setAttribute("name", "t"),
            xe.appendChild(Se),
            (g.checkClone = xe.cloneNode(!0).cloneNode(!0).lastChild.checked),
            (xe.innerHTML = "<textarea>x</textarea>"),
            (g.noCloneChecked = !!xe.cloneNode(!0).lastChild.defaultValue),
            (xe.innerHTML = "<option></option>"),
            (g.option = !!xe.lastChild);
          var Ce = {
            thead: [1, "<table>", "</table>"],
            col: [2, "<table><colgroup>", "</colgroup></table>"],
            tr: [2, "<table><tbody>", "</tbody></table>"],
            td: [3, "<table><tbody><tr>", "</tr></tbody></table>"],
            _default: [0, "", ""],
          };
          function Oe(e, t) {
            var r;
            return (
              (r =
                void 0 !== e.getElementsByTagName
                  ? e.getElementsByTagName(t || "*")
                  : void 0 !== e.querySelectorAll
                  ? e.querySelectorAll(t || "*")
                  : []),
              void 0 === t || (t && k(e, t)) ? T.merge([e], r) : r
            );
          }
          function Pe(e, t) {
            for (var r = 0, n = e.length; r < n; r++)
              se.set(e[r], "globalEval", !t || se.get(t[r], "globalEval"));
          }
          (Ce.tbody = Ce.tfoot = Ce.colgroup = Ce.caption = Ce.thead),
            (Ce.th = Ce.td),
            g.option ||
              (Ce.optgroup = Ce.option =
                [1, "<select multiple='multiple'>", "</select>"]);
          var Ie = /<|&#?\w+;/;
          function Ne(e, t, r, n, i) {
            for (
              var a,
                o,
                s,
                u,
                c,
                l,
                d = t.createDocumentFragment(),
                p = [],
                f = 0,
                h = e.length;
              f < h;
              f++
            )
              if ((a = e[f]) || 0 === a)
                if ("object" === w(a)) T.merge(p, a.nodeType ? [a] : a);
                else if (Ie.test(a)) {
                  for (
                    o = o || d.appendChild(t.createElement("div")),
                      s = (Ae.exec(a) || ["", ""])[1].toLowerCase(),
                      u = Ce[s] || Ce._default,
                      o.innerHTML = u[1] + T.htmlPrefilter(a) + u[2],
                      l = u[0];
                    l--;

                  )
                    o = o.lastChild;
                  T.merge(p, o.childNodes),
                    ((o = d.firstChild).textContent = "");
                } else p.push(t.createTextNode(a));
            for (d.textContent = "", f = 0; (a = p[f++]); )
              if (n && T.inArray(a, n) > -1) i && i.push(a);
              else if (
                ((c = ge(a)),
                (o = Oe(d.appendChild(a), "script")),
                c && Pe(o),
                r)
              )
                for (l = 0; (a = o[l++]); ) ke.test(a.type || "") && r.push(a);
            return d;
          }
          var Re = /^([^.]*)(?:\.(.+)|)/;
          function De() {
            return !0;
          }
          function Fe() {
            return !1;
          }
          function je(e, t, r, n, i, a) {
            var o, s;
            if ("object" == typeof t) {
              for (s in ("string" != typeof r && ((n = n || r), (r = void 0)),
              t))
                je(e, s, r, n, t[s], a);
              return e;
            }
            if (
              (null == n && null == i
                ? ((i = r), (n = r = void 0))
                : null == i &&
                  ("string" == typeof r
                    ? ((i = n), (n = void 0))
                    : ((i = n), (n = r), (r = void 0))),
              !1 === i)
            )
              i = Fe;
            else if (!i) return e;
            return (
              1 === a &&
                ((o = i),
                (i = function (e) {
                  return T().off(e), o.apply(this, arguments);
                }),
                (i.guid = o.guid || (o.guid = T.guid++))),
              e.each(function () {
                T.event.add(this, t, i, n, r);
              })
            );
          }
          function Le(e, t, r) {
            r
              ? (se.set(e, t, !1),
                T.event.add(e, t, {
                  namespace: !1,
                  handler: function (e) {
                    var r,
                      n = se.get(this, t);
                    if (1 & e.isTrigger && this[t]) {
                      if (n)
                        (T.event.special[t] || {}).delegateType &&
                          e.stopPropagation();
                      else if (
                        ((n = s.call(arguments)),
                        se.set(this, t, n),
                        this[t](),
                        (r = se.get(this, t)),
                        se.set(this, t, !1),
                        n !== r)
                      )
                        return (
                          e.stopImmediatePropagation(), e.preventDefault(), r
                        );
                    } else
                      n &&
                        (se.set(
                          this,
                          t,
                          T.event.trigger(n[0], n.slice(1), this)
                        ),
                        e.stopPropagation(),
                        (e.isImmediatePropagationStopped = De));
                  },
                }))
              : void 0 === se.get(e, t) && T.event.add(e, t, De);
          }
          (T.event = {
            global: {},
            add: function (e, t, r, n, i) {
              var a,
                o,
                s,
                u,
                c,
                l,
                d,
                p,
                f,
                h,
                m,
                g = se.get(e);
              if (ae(e))
                for (
                  r.handler && ((r = (a = r).handler), (i = a.selector)),
                    i && T.find.matchesSelector(me, i),
                    r.guid || (r.guid = T.guid++),
                    (u = g.AskMeOffers_Activity_Log) || (u = g.AskMeOffers_Activity_Log = Object.create(null)),
                    (o = g.handle) ||
                      (o = g.handle =
                        function (t) {
                          return void 0 !== T && T.event.triggered !== t.type
                            ? T.event.dispatch.apply(e, arguments)
                            : void 0;
                        }),
                    c = (t = (t || "").match(G) || [""]).length;
                  c--;

                )
                  (f = m = (s = Re.exec(t[c]) || [])[1]),
                    (h = (s[2] || "").split(".").sort()),
                    f &&
                      ((d = T.event.special[f] || {}),
                      (f = (i ? d.delegateType : d.bindType) || f),
                      (d = T.event.special[f] || {}),
                      (l = T.extend(
                        {
                          type: f,
                          origType: m,
                          data: n,
                          handler: r,
                          guid: r.guid,
                          selector: i,
                          needsContext: i && T.expr.match.needsContext.test(i),
                          namespace: h.join("."),
                        },
                        a
                      )),
                      (p = u[f]) ||
                        (((p = u[f] = []).delegateCount = 0),
                        (d.setup && !1 !== d.setup.call(e, n, h, o)) ||
                          (e.addEventListener && e.addEventListener(f, o))),
                      d.add &&
                        (d.add.call(e, l),
                        l.handler.guid || (l.handler.guid = r.guid)),
                      i ? p.splice(p.delegateCount++, 0, l) : p.push(l),
                      (T.event.global[f] = !0));
            },
            remove: function (e, t, r, n, i) {
              var a,
                o,
                s,
                u,
                c,
                l,
                d,
                p,
                f,
                h,
                m,
                g = se.hasData(e) && se.get(e);
              if (g && (u = g.AskMeOffers_Activity_Log)) {
                for (c = (t = (t || "").match(G) || [""]).length; c--; )
                  if (
                    ((f = m = (s = Re.exec(t[c]) || [])[1]),
                    (h = (s[2] || "").split(".").sort()),
                    f)
                  ) {
                    for (
                      d = T.event.special[f] || {},
                        p =
                          u[(f = (n ? d.delegateType : d.bindType) || f)] || [],
                        s =
                          s[2] &&
                          new RegExp(
                            "(^|\\.)" + h.join("\\.(?:.*\\.|)") + "(\\.|$)"
                          ),
                        o = a = p.length;
                      a--;

                    )
                      (l = p[a]),
                        (!i && m !== l.origType) ||
                          (r && r.guid !== l.guid) ||
                          (s && !s.test(l.namespace)) ||
                          (n &&
                            n !== l.selector &&
                            ("**" !== n || !l.selector)) ||
                          (p.splice(a, 1),
                          l.selector && p.delegateCount--,
                          d.remove && d.remove.call(e, l));
                    o &&
                      !p.length &&
                      ((d.teardown && !1 !== d.teardown.call(e, h, g.handle)) ||
                        T.removeEvent(e, f, g.handle),
                      delete u[f]);
                  } else for (f in u) T.event.remove(e, f + t[c], r, n, !0);
                T.isEmptyObject(u) && se.remove(e, "handle AskMeOffers_Activity_Log");
              }
            },
            dispatch: function (e) {
              var t,
                r,
                n,
                i,
                a,
                o,
                s = new Array(arguments.length),
                u = T.event.fix(e),
                c =
                  (se.get(this, "AskMeOffers_Activity_Log") || Object.create(null))[u.type] || [],
                l = T.event.special[u.type] || {};
              for (s[0] = u, t = 1; t < arguments.length; t++)
                s[t] = arguments[t];
              if (
                ((u.delegateTarget = this),
                !l.preDispatch || !1 !== l.preDispatch.call(this, u))
              ) {
                for (
                  o = T.event.handlers.call(this, u, c), t = 0;
                  (i = o[t++]) && !u.isPropagationStopped();

                )
                  for (
                    u.currentTarget = i.elem, r = 0;
                    (a = i.handlers[r++]) && !u.isImmediatePropagationStopped();

                  )
                    (u.rnamespace &&
                      !1 !== a.namespace &&
                      !u.rnamespace.test(a.namespace)) ||
                      ((u.handleObj = a),
                      (u.data = a.data),
                      void 0 !==
                        (n = (
                          (T.event.special[a.origType] || {}).handle ||
                          a.handler
                        ).apply(i.elem, s)) &&
                        !1 === (u.result = n) &&
                        (u.preventDefault(), u.stopPropagation()));
                return l.postDispatch && l.postDispatch.call(this, u), u.result;
              }
            },
            handlers: function (e, t) {
              var r,
                n,
                i,
                a,
                o,
                s = [],
                u = t.delegateCount,
                c = e.target;
              if (u && c.nodeType && !("click" === e.type && e.button >= 1))
                for (; c !== this; c = c.parentNode || this)
                  if (
                    1 === c.nodeType &&
                    ("click" !== e.type || !0 !== c.disabled)
                  ) {
                    for (a = [], o = {}, r = 0; r < u; r++)
                      void 0 === o[(i = (n = t[r]).selector + " ")] &&
                        (o[i] = n.needsContext
                          ? T(i, this).index(c) > -1
                          : T.find(i, this, null, [c]).length),
                        o[i] && a.push(n);
                    a.length && s.push({ elem: c, handlers: a });
                  }
              return (
                (c = this),
                u < t.length && s.push({ elem: c, handlers: t.slice(u) }),
                s
              );
            },
            addProp: function (e, t) {
              Object.defineProperty(T.Event.prototype, e, {
                enumerable: !0,
                configurable: !0,
                get: y(t)
                  ? function () {
                      if (this.originalEvent) return t(this.originalEvent);
                    }
                  : function () {
                      if (this.originalEvent) return this.originalEvent[e];
                    },
                set: function (t) {
                  Object.defineProperty(this, e, {
                    enumerable: !0,
                    configurable: !0,
                    writable: !0,
                    value: t,
                  });
                },
              });
            },
            fix: function (e) {
              return e[T.expando] ? e : new T.Event(e);
            },
            special: {
              load: { noBubble: !0 },
              click: {
                setup: function (e) {
                  var t = this || e;
                  return (
                    Te.test(t.type) &&
                      t.click &&
                      k(t, "input") &&
                      Le(t, "click", !0),
                    !1
                  );
                },
                trigger: function (e) {
                  var t = this || e;
                  return (
                    Te.test(t.type) &&
                      t.click &&
                      k(t, "input") &&
                      Le(t, "click"),
                    !0
                  );
                },
                _default: function (e) {
                  var t = e.target;
                  return (
                    (Te.test(t.type) &&
                      t.click &&
                      k(t, "input") &&
                      se.get(t, "click")) ||
                    k(t, "a")
                  );
                },
              },
              beforeunload: {
                postDispatch: function (e) {
                  void 0 !== e.result &&
                    e.originalEvent &&
                    (e.originalEvent.returnValue = e.result);
                },
              },
            },
          }),
            (T.removeEvent = function (e, t, r) {
              e.removeEventListener && e.removeEventListener(t, r);
            }),
            (T.Event = function (e, t) {
              if (!(this instanceof T.Event)) return new T.Event(e, t);
              e && e.type
                ? ((this.originalEvent = e),
                  (this.type = e.type),
                  (this.isDefaultPrevented =
                    e.defaultPrevented ||
                    (void 0 === e.defaultPrevented && !1 === e.returnValue)
                      ? De
                      : Fe),
                  (this.target =
                    e.target && 3 === e.target.nodeType
                      ? e.target.parentNode
                      : e.target),
                  (this.currentTarget = e.currentTarget),
                  (this.relatedTarget = e.relatedTarget))
                : (this.type = e),
                t && T.extend(this, t),
                (this.timeStamp = (e && e.timeStamp) || Date.now()),
                (this[T.expando] = !0);
            }),
            (T.Event.prototype = {
              constructor: T.Event,
              isDefaultPrevented: Fe,
              isPropagationStopped: Fe,
              isImmediatePropagationStopped: Fe,
              isSimulated: !1,
              preventDefault: function () {
                var e = this.originalEvent;
                (this.isDefaultPrevented = De),
                  e && !this.isSimulated && e.preventDefault();
              },
              stopPropagation: function () {
                var e = this.originalEvent;
                (this.isPropagationStopped = De),
                  e && !this.isSimulated && e.stopPropagation();
              },
              stopImmediatePropagation: function () {
                var e = this.originalEvent;
                (this.isImmediatePropagationStopped = De),
                  e && !this.isSimulated && e.stopImmediatePropagation(),
                  this.stopPropagation();
              },
            }),
            T.each(
              {
                altKey: !0,
                bubbles: !0,
                cancelable: !0,
                changedTouches: !0,
                ctrlKey: !0,
                detail: !0,
                eventPhase: !0,
                metaKey: !0,
                pageX: !0,
                pageY: !0,
                shiftKey: !0,
                view: !0,
                char: !0,
                code: !0,
                charCode: !0,
                key: !0,
                keyCode: !0,
                button: !0,
                buttons: !0,
                clientX: !0,
                clientY: !0,
                offsetX: !0,
                offsetY: !0,
                pointerId: !0,
                pointerType: !0,
                screenX: !0,
                screenY: !0,
                targetTouches: !0,
                toElement: !0,
                touches: !0,
                which: !0,
              },
              T.event.addProp
            ),
            T.each({ focus: "focusin", blur: "focusout" }, function (e, t) {
              function r(e) {
                if (b.documentMode) {
                  var r = se.get(this, "handle"),
                    n = T.event.fix(e);
                  (n.type = "focusin" === e.type ? "focus" : "blur"),
                    (n.isSimulated = !0),
                    r(e),
                    n.target === n.currentTarget && r(n);
                } else T.event.simulate(t, e.target, T.event.fix(e));
              }
              (T.event.special[e] = {
                setup: function () {
                  var n;
                  if ((Le(this, e, !0), !b.documentMode)) return !1;
                  (n = se.get(this, t)) || this.addEventListener(t, r),
                    se.set(this, t, (n || 0) + 1);
                },
                trigger: function () {
                  return Le(this, e), !0;
                },
                teardown: function () {
                  var e;
                  if (!b.documentMode) return !1;
                  (e = se.get(this, t) - 1)
                    ? se.set(this, t, e)
                    : (this.removeEventListener(t, r), se.remove(this, t));
                },
                _default: function (t) {
                  return se.get(t.target, e);
                },
                delegateType: t,
              }),
                (T.event.special[t] = {
                  setup: function () {
                    var n = this.ownerDocument || this.document || this,
                      i = b.documentMode ? this : n,
                      a = se.get(i, t);
                    a ||
                      (b.documentMode
                        ? this.addEventListener(t, r)
                        : n.addEventListener(e, r, !0)),
                      se.set(i, t, (a || 0) + 1);
                  },
                  teardown: function () {
                    var n = this.ownerDocument || this.document || this,
                      i = b.documentMode ? this : n,
                      a = se.get(i, t) - 1;
                    a
                      ? se.set(i, t, a)
                      : (b.documentMode
                          ? this.removeEventListener(t, r)
                          : n.removeEventListener(e, r, !0),
                        se.remove(i, t));
                  },
                });
            }),
            T.each(
              {
                mouseenter: "mouseover",
                mouseleave: "mouseout",
                pointerenter: "pointerover",
                pointerleave: "pointerout",
              },
              function (e, t) {
                T.event.special[e] = {
                  delegateType: t,
                  bindType: t,
                  handle: function (e) {
                    var r,
                      n = e.relatedTarget,
                      i = e.handleObj;
                    return (
                      (n && (n === this || T.contains(this, n))) ||
                        ((e.type = i.origType),
                        (r = i.handler.apply(this, arguments)),
                        (e.type = t)),
                      r
                    );
                  },
                };
              }
            ),
            T.fn.extend({
              on: function (e, t, r, n) {
                return je(this, e, t, r, n);
              },
              one: function (e, t, r, n) {
                return je(this, e, t, r, n, 1);
              },
              off: function (e, t, r) {
                var n, i;
                if (e && e.preventDefault && e.handleObj)
                  return (
                    (n = e.handleObj),
                    T(e.delegateTarget).off(
                      n.namespace ? n.origType + "." + n.namespace : n.origType,
                      n.selector,
                      n.handler
                    ),
                    this
                  );
                if ("object" == typeof e) {
                  for (i in e) this.off(i, t, e[i]);
                  return this;
                }
                return (
                  (!1 !== t && "function" != typeof t) ||
                    ((r = t), (t = void 0)),
                  !1 === r && (r = Fe),
                  this.each(function () {
                    T.event.remove(this, e, r, t);
                  })
                );
              },
            });
          var Me = /<script|<style|<link/i,
            Be = /checked\s*(?:[^=]|=\s*.checked.)/i,
            Ve = /^\s*<!\[CDATA\[|\]\]>\s*$/g;
          function Ue(e, t) {
            return (
              (k(e, "table") &&
                k(11 !== t.nodeType ? t : t.firstChild, "tr") &&
                T(e).children("tbody")[0]) ||
              e
            );
          }
          function He(e) {
            return (
              (e.type = (null !== e.getAttribute("type")) + "/" + e.type), e
            );
          }
          function qe(e) {
            return (
              "true/" === (e.type || "").slice(0, 5)
                ? (e.type = e.type.slice(5))
                : e.removeAttribute("type"),
              e
            );
          }
          function $e(e, t) {
            var r, n, i, a, o, s;
            if (1 === t.nodeType) {
              if (se.hasData(e) && (s = se.get(e).AskMeOffers_Activity_Log))
                for (i in (se.remove(t, "handle AskMeOffers_Activity_Log"), s))
                  for (r = 0, n = s[i].length; r < n; r++)
                    T.event.add(t, i, s[i][r]);
              ue.hasData(e) &&
                ((a = ue.access(e)), (o = T.extend({}, a)), ue.set(t, o));
            }
          }
          function We(e, t) {
            var r = t.nodeName.toLowerCase();
            "input" === r && Te.test(e.type)
              ? (t.checked = e.checked)
              : ("input" !== r && "textarea" !== r) ||
                (t.defaultValue = e.defaultValue);
          }
          function ze(e, t, r, n) {
            t = u(t);
            var i,
              a,
              o,
              s,
              c,
              l,
              d = 0,
              p = e.length,
              f = p - 1,
              h = t[0],
              m = y(h);
            if (
              m ||
              (p > 1 && "string" == typeof h && !g.checkClone && Be.test(h))
            )
              return e.each(function (i) {
                var a = e.eq(i);
                m && (t[0] = h.call(this, i, a.html())), ze(a, t, r, n);
              });
            if (
              p &&
              ((a = (i = Ne(t, e[0].ownerDocument, !1, e, n)).firstChild),
              1 === i.childNodes.length && (i = a),
              a || n)
            ) {
              for (s = (o = T.map(Oe(i, "script"), He)).length; d < p; d++)
                (c = i),
                  d !== f &&
                    ((c = T.clone(c, !0, !0)),
                    s && T.merge(o, Oe(c, "script"))),
                  r.call(e[d], c, d);
              if (s)
                for (
                  l = o[o.length - 1].ownerDocument, T.map(o, qe), d = 0;
                  d < s;
                  d++
                )
                  (c = o[d]),
                    ke.test(c.type || "") &&
                      !se.access(c, "globalEval") &&
                      T.contains(l, c) &&
                      (c.src && "module" !== (c.type || "").toLowerCase()
                        ? T._evalUrl &&
                          !c.noModule &&
                          T._evalUrl(
                            c.src,
                            { nonce: c.nonce || c.getAttribute("nonce") },
                            l
                          )
                        : E(c.textContent.replace(Ve, ""), c, l));
            }
            return e;
          }
          function Ge(e, t, r) {
            for (
              var n, i = t ? T.filter(t, e) : e, a = 0;
              null != (n = i[a]);
              a++
            )
              r || 1 !== n.nodeType || T.cleanData(Oe(n)),
                n.parentNode &&
                  (r && ge(n) && Pe(Oe(n, "script")),
                  n.parentNode.removeChild(n));
            return e;
          }
          T.extend({
            htmlPrefilter: function (e) {
              return e;
            },
            clone: function (e, t, r) {
              var n,
                i,
                a,
                o,
                s = e.cloneNode(!0),
                u = ge(e);
              if (
                !(
                  g.noCloneChecked ||
                  (1 !== e.nodeType && 11 !== e.nodeType) ||
                  T.isXMLDoc(e)
                )
              )
                for (o = Oe(s), n = 0, i = (a = Oe(e)).length; n < i; n++)
                  We(a[n], o[n]);
              if (t)
                if (r)
                  for (
                    a = a || Oe(e), o = o || Oe(s), n = 0, i = a.length;
                    n < i;
                    n++
                  )
                    $e(a[n], o[n]);
                else $e(e, s);
              return (
                (o = Oe(s, "script")).length > 0 &&
                  Pe(o, !u && Oe(e, "script")),
                s
              );
            },
            cleanData: function (e) {
              for (
                var t, r, n, i = T.event.special, a = 0;
                void 0 !== (r = e[a]);
                a++
              )
                if (ae(r)) {
                  if ((t = r[se.expando])) {
                    if (t.AskMeOffers_Activity_Log)
                      for (n in t.AskMeOffers_Activity_Log)
                        i[n]
                          ? T.event.remove(r, n)
                          : T.removeEvent(r, n, t.handle);
                    r[se.expando] = void 0;
                  }
                  r[ue.expando] && (r[ue.expando] = void 0);
                }
            },
          }),
            T.fn.extend({
              detach: function (e) {
                return Ge(this, e, !0);
              },
              remove: function (e) {
                return Ge(this, e);
              },
              text: function (e) {
                return ee(
                  this,
                  function (e) {
                    return void 0 === e
                      ? T.text(this)
                      : this.empty().each(function () {
                          (1 !== this.nodeType &&
                            11 !== this.nodeType &&
                            9 !== this.nodeType) ||
                            (this.textContent = e);
                        });
                  },
                  null,
                  e,
                  arguments.length
                );
              },
              append: function () {
                return ze(this, arguments, function (e) {
                  (1 !== this.nodeType &&
                    11 !== this.nodeType &&
                    9 !== this.nodeType) ||
                    Ue(this, e).appendChild(e);
                });
              },
              prepend: function () {
                return ze(this, arguments, function (e) {
                  if (
                    1 === this.nodeType ||
                    11 === this.nodeType ||
                    9 === this.nodeType
                  ) {
                    var t = Ue(this, e);
                    t.insertBefore(e, t.firstChild);
                  }
                });
              },
              before: function () {
                return ze(this, arguments, function (e) {
                  this.parentNode && this.parentNode.insertBefore(e, this);
                });
              },
              after: function () {
                return ze(this, arguments, function (e) {
                  this.parentNode &&
                    this.parentNode.insertBefore(e, this.nextSibling);
                });
              },
              empty: function () {
                for (var e, t = 0; null != (e = this[t]); t++)
                  1 === e.nodeType &&
                    (T.cleanData(Oe(e, !1)), (e.textContent = ""));
                return this;
              },
              clone: function (e, t) {
                return (
                  (e = null != e && e),
                  (t = null == t ? e : t),
                  this.map(function () {
                    return T.clone(this, e, t);
                  })
                );
              },
              html: function (e) {
                return ee(
                  this,
                  function (e) {
                    var t = this[0] || {},
                      r = 0,
                      n = this.length;
                    if (void 0 === e && 1 === t.nodeType) return t.innerHTML;
                    if (
                      "string" == typeof e &&
                      !Me.test(e) &&
                      !Ce[(Ae.exec(e) || ["", ""])[1].toLowerCase()]
                    ) {
                      e = T.htmlPrefilter(e);
                      try {
                        for (; r < n; r++)
                          1 === (t = this[r] || {}).nodeType &&
                            (T.cleanData(Oe(t, !1)), (t.innerHTML = e));
                        t = 0;
                      } catch (e) {}
                    }
                    t && this.empty().append(e);
                  },
                  null,
                  e,
                  arguments.length
                );
              },
              replaceWith: function () {
                var e = [];
                return ze(
                  this,
                  arguments,
                  function (t) {
                    var r = this.parentNode;
                    T.inArray(this, e) < 0 &&
                      (T.cleanData(Oe(this)), r && r.replaceChild(t, this));
                  },
                  e
                );
              },
            }),
            T.each(
              {
                appendTo: "append",
                prependTo: "prepend",
                insertBefore: "before",
                insertAfter: "after",
                replaceAll: "replaceWith",
              },
              function (e, t) {
                T.fn[e] = function (e) {
                  for (
                    var r, n = [], i = T(e), a = i.length - 1, o = 0;
                    o <= a;
                    o++
                  )
                    (r = o === a ? this : this.clone(!0)),
                      T(i[o])[t](r),
                      c.apply(n, r.get());
                  return this.pushStack(n);
                };
              }
            );
          var Ke = new RegExp("^(" + pe + ")(?!px)[a-z%]+$", "i"),
            Je = /^--/,
            Ye = function (e) {
              var t = e.ownerDocument.defaultView;
              return (t && t.opener) || (t = n), t.getComputedStyle(e);
            },
            Qe = function (e, t, r) {
              var n,
                i,
                a = {};
              for (i in t) (a[i] = e.style[i]), (e.style[i] = t[i]);
              for (i in ((n = r.call(e)), t)) e.style[i] = a[i];
              return n;
            },
            Xe = new RegExp(he.join("|"), "i");
          function Ze(e, t, r) {
            var n,
              i,
              a,
              o,
              s = Je.test(t),
              u = e.style;
            return (
              (r = r || Ye(e)) &&
                ((o = r.getPropertyValue(t) || r[t]),
                s && o && (o = o.replace(N, "$1") || void 0),
                "" !== o || ge(e) || (o = T.style(e, t)),
                !g.pixelBoxStyles() &&
                  Ke.test(o) &&
                  Xe.test(t) &&
                  ((n = u.width),
                  (i = u.minWidth),
                  (a = u.maxWidth),
                  (u.minWidth = u.maxWidth = u.width = o),
                  (o = r.width),
                  (u.width = n),
                  (u.minWidth = i),
                  (u.maxWidth = a))),
              void 0 !== o ? o + "" : o
            );
          }
          function et(e, t) {
            return {
              get: function () {
                if (!e()) return (this.get = t).apply(this, arguments);
                delete this.get;
              },
            };
          }
          !(function () {
            function e() {
              if (l) {
                (c.style.cssText =
                  "position:absolute;left:-11111px;width:60px;margin-top:1px;padding:0;border:0"),
                  (l.style.cssText =
                    "position:relative;display:block;box-sizing:border-box;overflow:scroll;margin:auto;border:1px;padding:1px;width:60%;top:1%"),
                  me.appendChild(c).appendChild(l);
                var e = n.getComputedStyle(l);
                (r = "1%" !== e.top),
                  (u = 12 === t(e.marginLeft)),
                  (l.style.right = "60%"),
                  (o = 36 === t(e.right)),
                  (i = 36 === t(e.width)),
                  (l.style.position = "absolute"),
                  (a = 12 === t(l.offsetWidth / 3)),
                  me.removeChild(c),
                  (l = null);
              }
            }
            function t(e) {
              return Math.round(parseFloat(e));
            }
            var r,
              i,
              a,
              o,
              s,
              u,
              c = b.createElement("div"),
              l = b.createElement("div");
            l.style &&
              ((l.style.backgroundClip = "content-box"),
              (l.cloneNode(!0).style.backgroundClip = ""),
              (g.clearCloneStyle = "content-box" === l.style.backgroundClip),
              T.extend(g, {
                boxSizingReliable: function () {
                  return e(), i;
                },
                pixelBoxStyles: function () {
                  return e(), o;
                },
                pixelPosition: function () {
                  return e(), r;
                },
                reliableMarginLeft: function () {
                  return e(), u;
                },
                scrollboxSize: function () {
                  return e(), a;
                },
                reliableTrDimensions: function () {
                  var e, t, r, i;
                  return (
                    null == s &&
                      ((e = b.createElement("table")),
                      (t = b.createElement("tr")),
                      (r = b.createElement("div")),
                      (e.style.cssText =
                        "position:absolute;left:-11111px;border-collapse:separate"),
                      (t.style.cssText =
                        "box-sizing:content-box;border:1px solid"),
                      (t.style.height = "1px"),
                      (r.style.height = "9px"),
                      (r.style.display = "block"),
                      me.appendChild(e).appendChild(t).appendChild(r),
                      (i = n.getComputedStyle(t)),
                      (s =
                        parseInt(i.height, 10) +
                          parseInt(i.borderTopWidth, 10) +
                          parseInt(i.borderBottomWidth, 10) ===
                        t.offsetHeight),
                      me.removeChild(e)),
                    s
                  );
                },
              }));
          })();
          var tt = ["Webkit", "Moz", "ms"],
            rt = b.createElement("div").style,
            nt = {};
          function it(e) {
            var t = T.cssProps[e] || nt[e];
            return (
              t ||
              (e in rt
                ? e
                : (nt[e] =
                    (function (e) {
                      for (
                        var t = e[0].toUpperCase() + e.slice(1), r = tt.length;
                        r--;

                      )
                        if ((e = tt[r] + t) in rt) return e;
                    })(e) || e))
            );
          }
          var at = /^(none|table(?!-c[ea]).+)/,
            ot = {
              position: "absolute",
              visibility: "hidden",
              display: "block",
            },
            st = { letterSpacing: "0", fontWeight: "400" };
          function ut(e, t, r) {
            var n = fe.exec(t);
            return n ? Math.max(0, n[2] - (r || 0)) + (n[3] || "px") : t;
          }
          function ct(e, t, r, n, i, a) {
            var o = "width" === t ? 1 : 0,
              s = 0,
              u = 0,
              c = 0;
            if (r === (n ? "border" : "content")) return 0;
            for (; o < 4; o += 2)
              "margin" === r && (c += T.css(e, r + he[o], !0, i)),
                n
                  ? ("content" === r &&
                      (u -= T.css(e, "padding" + he[o], !0, i)),
                    "margin" !== r &&
                      (u -= T.css(e, "border" + he[o] + "Width", !0, i)))
                  : ((u += T.css(e, "padding" + he[o], !0, i)),
                    "padding" !== r
                      ? (u += T.css(e, "border" + he[o] + "Width", !0, i))
                      : (s += T.css(e, "border" + he[o] + "Width", !0, i)));
            return (
              !n &&
                a >= 0 &&
                (u +=
                  Math.max(
                    0,
                    Math.ceil(
                      e["offset" + t[0].toUpperCase() + t.slice(1)] -
                        a -
                        u -
                        s -
                        0.5
                    )
                  ) || 0),
              u + c
            );
          }
          function lt(e, t, r) {
            var n = Ye(e),
              i =
                (!g.boxSizingReliable() || r) &&
                "border-box" === T.css(e, "boxSizing", !1, n),
              a = i,
              o = Ze(e, t, n),
              s = "offset" + t[0].toUpperCase() + t.slice(1);
            if (Ke.test(o)) {
              if (!r) return o;
              o = "auto";
            }
            return (
              ((!g.boxSizingReliable() && i) ||
                (!g.reliableTrDimensions() && k(e, "tr")) ||
                "auto" === o ||
                (!parseFloat(o) && "inline" === T.css(e, "display", !1, n))) &&
                e.getClientRects().length &&
                ((i = "border-box" === T.css(e, "boxSizing", !1, n)),
                (a = s in e) && (o = e[s])),
              (o = parseFloat(o) || 0) +
                ct(e, t, r || (i ? "border" : "content"), a, n, o) +
                "px"
            );
          }
          function dt(e, t, r, n, i) {
            return new dt.prototype.init(e, t, r, n, i);
          }
          T.extend({
            cssHooks: {
              opacity: {
                get: function (e, t) {
                  if (t) {
                    var r = Ze(e, "opacity");
                    return "" === r ? "1" : r;
                  }
                },
              },
            },
            cssNumber: {
              animationIterationCount: !0,
              aspectRatio: !0,
              borderImageSlice: !0,
              columnCount: !0,
              flexGrow: !0,
              flexShrink: !0,
              fontWeight: !0,
              gridArea: !0,
              gridColumn: !0,
              gridColumnEnd: !0,
              gridColumnStart: !0,
              gridRow: !0,
              gridRowEnd: !0,
              gridRowStart: !0,
              lineHeight: !0,
              opacity: !0,
              order: !0,
              orphans: !0,
              scale: !0,
              widows: !0,
              zIndex: !0,
              zoom: !0,
              fillOpacity: !0,
              floodOpacity: !0,
              stopOpacity: !0,
              strokeMiterlimit: !0,
              strokeOpacity: !0,
            },
            cssProps: {},
            style: function (e, t, r, n) {
              if (e && 3 !== e.nodeType && 8 !== e.nodeType && e.style) {
                var i,
                  a,
                  o,
                  s = ie(t),
                  u = Je.test(t),
                  c = e.style;
                if (
                  (u || (t = it(s)),
                  (o = T.cssHooks[t] || T.cssHooks[s]),
                  void 0 === r)
                )
                  return o && "get" in o && void 0 !== (i = o.get(e, !1, n))
                    ? i
                    : c[t];
                "string" === (a = typeof r) &&
                  (i = fe.exec(r)) &&
                  i[1] &&
                  ((r = be(e, t, i)), (a = "number")),
                  null != r &&
                    r == r &&
                    ("number" !== a ||
                      u ||
                      (r += (i && i[3]) || (T.cssNumber[s] ? "" : "px")),
                    g.clearCloneStyle ||
                      "" !== r ||
                      0 !== t.indexOf("background") ||
                      (c[t] = "inherit"),
                    (o && "set" in o && void 0 === (r = o.set(e, r, n))) ||
                      (u ? c.setProperty(t, r) : (c[t] = r)));
              }
            },
            css: function (e, t, r, n) {
              var i,
                a,
                o,
                s = ie(t);
              return (
                Je.test(t) || (t = it(s)),
                (o = T.cssHooks[t] || T.cssHooks[s]) &&
                  "get" in o &&
                  (i = o.get(e, !0, r)),
                void 0 === i && (i = Ze(e, t, n)),
                "normal" === i && t in st && (i = st[t]),
                "" === r || r
                  ? ((a = parseFloat(i)), !0 === r || isFinite(a) ? a || 0 : i)
                  : i
              );
            },
          }),
            T.each(["height", "width"], function (e, t) {
              T.cssHooks[t] = {
                get: function (e, r, n) {
                  if (r)
                    return !at.test(T.css(e, "display")) ||
                      (e.getClientRects().length &&
                        e.getBoundingClientRect().width)
                      ? lt(e, t, n)
                      : Qe(e, ot, function () {
                          return lt(e, t, n);
                        });
                },
                set: function (e, r, n) {
                  var i,
                    a = Ye(e),
                    o = !g.scrollboxSize() && "absolute" === a.position,
                    s =
                      (o || n) && "border-box" === T.css(e, "boxSizing", !1, a),
                    u = n ? ct(e, t, n, s, a) : 0;
                  return (
                    s &&
                      o &&
                      (u -= Math.ceil(
                        e["offset" + t[0].toUpperCase() + t.slice(1)] -
                          parseFloat(a[t]) -
                          ct(e, t, "border", !1, a) -
                          0.5
                      )),
                    u &&
                      (i = fe.exec(r)) &&
                      "px" !== (i[3] || "px") &&
                      ((e.style[t] = r), (r = T.css(e, t))),
                    ut(0, r, u)
                  );
                },
              };
            }),
            (T.cssHooks.marginLeft = et(g.reliableMarginLeft, function (e, t) {
              if (t)
                return (
                  (parseFloat(Ze(e, "marginLeft")) ||
                    e.getBoundingClientRect().left -
                      Qe(e, { marginLeft: 0 }, function () {
                        return e.getBoundingClientRect().left;
                      })) + "px"
                );
            })),
            T.each(
              { margin: "", padding: "", border: "Width" },
              function (e, t) {
                (T.cssHooks[e + t] = {
                  expand: function (r) {
                    for (
                      var n = 0,
                        i = {},
                        a = "string" == typeof r ? r.split(" ") : [r];
                      n < 4;
                      n++
                    )
                      i[e + he[n] + t] = a[n] || a[n - 2] || a[0];
                    return i;
                  },
                }),
                  "margin" !== e && (T.cssHooks[e + t].set = ut);
              }
            ),
            T.fn.extend({
              css: function (e, t) {
                return ee(
                  this,
                  function (e, t, r) {
                    var n,
                      i,
                      a = {},
                      o = 0;
                    if (Array.isArray(t)) {
                      for (n = Ye(e), i = t.length; o < i; o++)
                        a[t[o]] = T.css(e, t[o], !1, n);
                      return a;
                    }
                    return void 0 !== r ? T.style(e, t, r) : T.css(e, t);
                  },
                  e,
                  t,
                  arguments.length > 1
                );
              },
            }),
            (T.Tween = dt),
            (dt.prototype = {
              constructor: dt,
              init: function (e, t, r, n, i, a) {
                (this.elem = e),
                  (this.prop = r),
                  (this.easing = i || T.easing._default),
                  (this.options = t),
                  (this.start = this.now = this.cur()),
                  (this.end = n),
                  (this.unit = a || (T.cssNumber[r] ? "" : "px"));
              },
              cur: function () {
                var e = dt.propHooks[this.prop];
                return e && e.get
                  ? e.get(this)
                  : dt.propHooks._default.get(this);
              },
              run: function (e) {
                var t,
                  r = dt.propHooks[this.prop];
                return (
                  this.options.duration
                    ? (this.pos = t =
                        T.easing[this.easing](
                          e,
                          this.options.duration * e,
                          0,
                          1,
                          this.options.duration
                        ))
                    : (this.pos = t = e),
                  (this.now = (this.end - this.start) * t + this.start),
                  this.options.step &&
                    this.options.step.call(this.elem, this.now, this),
                  r && r.set ? r.set(this) : dt.propHooks._default.set(this),
                  this
                );
              },
            }),
            (dt.prototype.init.prototype = dt.prototype),
            (dt.propHooks = {
              _default: {
                get: function (e) {
                  var t;
                  return 1 !== e.elem.nodeType ||
                    (null != e.elem[e.prop] && null == e.elem.style[e.prop])
                    ? e.elem[e.prop]
                    : (t = T.css(e.elem, e.prop, "")) && "auto" !== t
                    ? t
                    : 0;
                },
                set: function (e) {
                  T.fx.step[e.prop]
                    ? T.fx.step[e.prop](e)
                    : 1 !== e.elem.nodeType ||
                      (!T.cssHooks[e.prop] && null == e.elem.style[it(e.prop)])
                    ? (e.elem[e.prop] = e.now)
                    : T.style(e.elem, e.prop, e.now + e.unit);
                },
              },
            }),
            (dt.propHooks.scrollTop = dt.propHooks.scrollLeft =
              {
                set: function (e) {
                  e.elem.nodeType &&
                    e.elem.parentNode &&
                    (e.elem[e.prop] = e.now);
                },
              }),
            (T.easing = {
              linear: function (e) {
                return e;
              },
              swing: function (e) {
                return 0.5 - Math.cos(e * Math.PI) / 2;
              },
              _default: "swing",
            }),
            (T.fx = dt.prototype.init),
            (T.fx.step = {});
          var pt,
            ft,
            ht = /^(?:toggle|show|hide)$/,
            mt = /queueHooks$/;
          function gt() {
            ft &&
              (!1 === b.hidden && n.requestAnimationFrame
                ? n.requestAnimationFrame(gt)
                : n.setTimeout(gt, T.fx.interval),
              T.fx.tick());
          }
          function yt() {
            return (
              n.setTimeout(function () {
                pt = void 0;
              }),
              (pt = Date.now())
            );
          }
          function vt(e, t) {
            var r,
              n = 0,
              i = { height: e };
            for (t = t ? 1 : 0; n < 4; n += 2 - t)
              i["margin" + (r = he[n])] = i["padding" + r] = e;
            return t && (i.opacity = i.width = e), i;
          }
          function bt(e, t, r) {
            for (
              var n,
                i = (_t.tweeners[t] || []).concat(_t.tweeners["*"]),
                a = 0,
                o = i.length;
              a < o;
              a++
            )
              if ((n = i[a].call(r, t, e))) return n;
          }
          function _t(e, t, r) {
            var n,
              i,
              a = 0,
              o = _t.prefilters.length,
              s = T.Deferred().always(function () {
                delete u.elem;
              }),
              u = function () {
                if (i) return !1;
                for (
                  var t = pt || yt(),
                    r = Math.max(0, c.startTime + c.duration - t),
                    n = 1 - (r / c.duration || 0),
                    a = 0,
                    o = c.tweens.length;
                  a < o;
                  a++
                )
                  c.tweens[a].run(n);
                return (
                  s.notifyWith(e, [c, n, r]),
                  n < 1 && o
                    ? r
                    : (o || s.notifyWith(e, [c, 1, 0]),
                      s.resolveWith(e, [c]),
                      !1)
                );
              },
              c = s.promise({
                elem: e,
                props: T.extend({}, t),
                opts: T.extend(
                  !0,
                  { specialEasing: {}, easing: T.easing._default },
                  r
                ),
                originalProperties: t,
                originalOptions: r,
                startTime: pt || yt(),
                duration: r.duration,
                tweens: [],
                createTween: function (t, r) {
                  var n = T.Tween(
                    e,
                    c.opts,
                    t,
                    r,
                    c.opts.specialEasing[t] || c.opts.easing
                  );
                  return c.tweens.push(n), n;
                },
                stop: function (t) {
                  var r = 0,
                    n = t ? c.tweens.length : 0;
                  if (i) return this;
                  for (i = !0; r < n; r++) c.tweens[r].run(1);
                  return (
                    t
                      ? (s.notifyWith(e, [c, 1, 0]), s.resolveWith(e, [c, t]))
                      : s.rejectWith(e, [c, t]),
                    this
                  );
                },
              }),
              l = c.props;
            for (
              !(function (e, t) {
                var r, n, i, a, o;
                for (r in e)
                  if (
                    ((i = t[(n = ie(r))]),
                    (a = e[r]),
                    Array.isArray(a) && ((i = a[1]), (a = e[r] = a[0])),
                    r !== n && ((e[n] = a), delete e[r]),
                    (o = T.cssHooks[n]) && ("expand" in o))
                  )
                    for (r in ((a = o.expand(a)), delete e[n], a))
                      (r in e) || ((e[r] = a[r]), (t[r] = i));
                  else t[n] = i;
              })(l, c.opts.specialEasing);
              a < o;
              a++
            )
              if ((n = _t.prefilters[a].call(c, e, l, c.opts)))
                return (
                  y(n.stop) &&
                    (T._queueHooks(c.elem, c.opts.queue).stop = n.stop.bind(n)),
                  n
                );
            return (
              T.map(l, bt, c),
              y(c.opts.start) && c.opts.start.call(e, c),
              c
                .progress(c.opts.progress)
                .done(c.opts.done, c.opts.complete)
                .fail(c.opts.fail)
                .always(c.opts.always),
              T.fx.timer(
                T.extend(u, { elem: e, anim: c, queue: c.opts.queue })
              ),
              c
            );
          }
          (T.Animation = T.extend(_t, {
            tweeners: {
              "*": [
                function (e, t) {
                  var r = this.createTween(e, t);
                  return be(r.elem, e, fe.exec(t), r), r;
                },
              ],
            },
            tweener: function (e, t) {
              y(e) ? ((t = e), (e = ["*"])) : (e = e.match(G));
              for (var r, n = 0, i = e.length; n < i; n++)
                (r = e[n]),
                  (_t.tweeners[r] = _t.tweeners[r] || []),
                  _t.tweeners[r].unshift(t);
            },
            prefilters: [
              function (e, t, r) {
                var n,
                  i,
                  a,
                  o,
                  s,
                  u,
                  c,
                  l,
                  d = "width" in t || "height" in t,
                  p = this,
                  f = {},
                  h = e.style,
                  m = e.nodeType && ve(e),
                  g = se.get(e, "fxshow");
                for (n in (r.queue ||
                  (null == (o = T._queueHooks(e, "fx")).unqueued &&
                    ((o.unqueued = 0),
                    (s = o.empty.fire),
                    (o.empty.fire = function () {
                      o.unqueued || s();
                    })),
                  o.unqueued++,
                  p.always(function () {
                    p.always(function () {
                      o.unqueued--, T.queue(e, "fx").length || o.empty.fire();
                    });
                  })),
                t))
                  if (((i = t[n]), ht.test(i))) {
                    if (
                      (delete t[n],
                      (a = a || "toggle" === i),
                      i === (m ? "hide" : "show"))
                    ) {
                      if ("show" !== i || !g || void 0 === g[n]) continue;
                      m = !0;
                    }
                    f[n] = (g && g[n]) || T.style(e, n);
                  }
                if ((u = !T.isEmptyObject(t)) || !T.isEmptyObject(f))
                  for (n in (d &&
                    1 === e.nodeType &&
                    ((r.overflow = [h.overflow, h.overflowX, h.overflowY]),
                    null == (c = g && g.display) && (c = se.get(e, "display")),
                    "none" === (l = T.css(e, "display")) &&
                      (c
                        ? (l = c)
                        : (we([e], !0),
                          (c = e.style.display || c),
                          (l = T.css(e, "display")),
                          we([e]))),
                    ("inline" === l || ("inline-block" === l && null != c)) &&
                      "none" === T.css(e, "float") &&
                      (u ||
                        (p.done(function () {
                          h.display = c;
                        }),
                        null == c &&
                          ((l = h.display), (c = "none" === l ? "" : l))),
                      (h.display = "inline-block"))),
                  r.overflow &&
                    ((h.overflow = "hidden"),
                    p.always(function () {
                      (h.overflow = r.overflow[0]),
                        (h.overflowX = r.overflow[1]),
                        (h.overflowY = r.overflow[2]);
                    })),
                  (u = !1),
                  f))
                    u ||
                      (g
                        ? "hidden" in g && (m = g.hidden)
                        : (g = se.access(e, "fxshow", { display: c })),
                      a && (g.hidden = !m),
                      m && we([e], !0),
                      p.done(function () {
                        for (n in (m || we([e]), se.remove(e, "fxshow"), f))
                          T.style(e, n, f[n]);
                      })),
                      (u = bt(m ? g[n] : 0, n, p)),
                      n in g ||
                        ((g[n] = u.start),
                        m && ((u.end = u.start), (u.start = 0)));
              },
            ],
            prefilter: function (e, t) {
              t ? _t.prefilters.unshift(e) : _t.prefilters.push(e);
            },
          })),
            (T.speed = function (e, t, r) {
              var n =
                e && "object" == typeof e
                  ? T.extend({}, e)
                  : {
                      complete: r || (!r && t) || (y(e) && e),
                      duration: e,
                      easing: (r && t) || (t && !y(t) && t),
                    };
              return (
                T.fx.off
                  ? (n.duration = 0)
                  : "number" != typeof n.duration &&
                    (n.duration in T.fx.speeds
                      ? (n.duration = T.fx.speeds[n.duration])
                      : (n.duration = T.fx.speeds._default)),
                (null != n.queue && !0 !== n.queue) || (n.queue = "fx"),
                (n.old = n.complete),
                (n.complete = function () {
                  y(n.old) && n.old.call(this),
                    n.queue && T.dequeue(this, n.queue);
                }),
                n
              );
            }),
            T.fn.extend({
              fadeTo: function (e, t, r, n) {
                return this.filter(ve)
                  .css("opacity", 0)
                  .show()
                  .end()
                  .animate({ opacity: t }, e, r, n);
              },
              animate: function (e, t, r, n) {
                var i = T.isEmptyObject(e),
                  a = T.speed(t, r, n),
                  o = function () {
                    var t = _t(this, T.extend({}, e), a);
                    (i || se.get(this, "finish")) && t.stop(!0);
                  };
                return (
                  (o.finish = o),
                  i || !1 === a.queue ? this.each(o) : this.queue(a.queue, o)
                );
              },
              stop: function (e, t, r) {
                var n = function (e) {
                  var t = e.stop;
                  delete e.stop, t(r);
                };
                return (
                  "string" != typeof e && ((r = t), (t = e), (e = void 0)),
                  t && this.queue(e || "fx", []),
                  this.each(function () {
                    var t = !0,
                      i = null != e && e + "queueHooks",
                      a = T.timers,
                      o = se.get(this);
                    if (i) o[i] && o[i].stop && n(o[i]);
                    else
                      for (i in o) o[i] && o[i].stop && mt.test(i) && n(o[i]);
                    for (i = a.length; i--; )
                      a[i].elem !== this ||
                        (null != e && a[i].queue !== e) ||
                        (a[i].anim.stop(r), (t = !1), a.splice(i, 1));
                    (!t && r) || T.dequeue(this, e);
                  })
                );
              },
              finish: function (e) {
                return (
                  !1 !== e && (e = e || "fx"),
                  this.each(function () {
                    var t,
                      r = se.get(this),
                      n = r[e + "queue"],
                      i = r[e + "queueHooks"],
                      a = T.timers,
                      o = n ? n.length : 0;
                    for (
                      r.finish = !0,
                        T.queue(this, e, []),
                        i && i.stop && i.stop.call(this, !0),
                        t = a.length;
                      t--;

                    )
                      a[t].elem === this &&
                        a[t].queue === e &&
                        (a[t].anim.stop(!0), a.splice(t, 1));
                    for (t = 0; t < o; t++)
                      n[t] && n[t].finish && n[t].finish.call(this);
                    delete r.finish;
                  })
                );
              },
            }),
            T.each(["toggle", "show", "hide"], function (e, t) {
              var r = T.fn[t];
              T.fn[t] = function (e, n, i) {
                return null == e || "boolean" == typeof e
                  ? r.apply(this, arguments)
                  : this.animate(vt(t, !0), e, n, i);
              };
            }),
            T.each(
              {
                slideDown: vt("show"),
                slideUp: vt("hide"),
                slideToggle: vt("toggle"),
                fadeIn: { opacity: "show" },
                fadeOut: { opacity: "hide" },
                fadeToggle: { opacity: "toggle" },
              },
              function (e, t) {
                T.fn[e] = function (e, r, n) {
                  return this.animate(t, e, r, n);
                };
              }
            ),
            (T.timers = []),
            (T.fx.tick = function () {
              var e,
                t = 0,
                r = T.timers;
              for (pt = Date.now(); t < r.length; t++)
                (e = r[t])() || r[t] !== e || r.splice(t--, 1);
              r.length || T.fx.stop(), (pt = void 0);
            }),
            (T.fx.timer = function (e) {
              T.timers.push(e), T.fx.start();
            }),
            (T.fx.interval = 13),
            (T.fx.start = function () {
              ft || ((ft = !0), gt());
            }),
            (T.fx.stop = function () {
              ft = null;
            }),
            (T.fx.speeds = { slow: 600, fast: 200, _default: 400 }),
            (T.fn.delay = function (e, t) {
              return (
                (e = (T.fx && T.fx.speeds[e]) || e),
                (t = t || "fx"),
                this.queue(t, function (t, r) {
                  var i = n.setTimeout(t, e);
                  r.stop = function () {
                    n.clearTimeout(i);
                  };
                })
              );
            }),
            (function () {
              var e = b.createElement("input"),
                t = b
                  .createElement("select")
                  .appendChild(b.createElement("option"));
              (e.type = "checkbox"),
                (g.checkOn = "" !== e.value),
                (g.optSelected = t.selected),
                ((e = b.createElement("input")).value = "t"),
                (e.type = "radio"),
                (g.radioValue = "t" === e.value);
            })();
          var Et,
            wt = T.expr.attrHandle;
          T.fn.extend({
            attr: function (e, t) {
              return ee(this, T.attr, e, t, arguments.length > 1);
            },
            removeAttr: function (e) {
              return this.each(function () {
                T.removeAttr(this, e);
              });
            },
          }),
            T.extend({
              attr: function (e, t, r) {
                var n,
                  i,
                  a = e.nodeType;
                if (3 !== a && 8 !== a && 2 !== a)
                  return void 0 === e.getAttribute
                    ? T.prop(e, t, r)
                    : ((1 === a && T.isXMLDoc(e)) ||
                        (i =
                          T.attrHooks[t.toLowerCase()] ||
                          (T.expr.match.bool.test(t) ? Et : void 0)),
                      void 0 !== r
                        ? null === r
                          ? void T.removeAttr(e, t)
                          : i && "set" in i && void 0 !== (n = i.set(e, r, t))
                          ? n
                          : (e.setAttribute(t, r + ""), r)
                        : i && "get" in i && null !== (n = i.get(e, t))
                        ? n
                        : null == (n = T.find.attr(e, t))
                        ? void 0
                        : n);
              },
              attrHooks: {
                type: {
                  set: function (e, t) {
                    if (!g.radioValue && "radio" === t && k(e, "input")) {
                      var r = e.value;
                      return e.setAttribute("type", t), r && (e.value = r), t;
                    }
                  },
                },
              },
              removeAttr: function (e, t) {
                var r,
                  n = 0,
                  i = t && t.match(G);
                if (i && 1 === e.nodeType)
                  for (; (r = i[n++]); ) e.removeAttribute(r);
              },
            }),
            (Et = {
              set: function (e, t, r) {
                return !1 === t ? T.removeAttr(e, r) : e.setAttribute(r, r), r;
              },
            }),
            T.each(T.expr.match.bool.source.match(/\w+/g), function (e, t) {
              var r = wt[t] || T.find.attr;
              wt[t] = function (e, t, n) {
                var i,
                  a,
                  o = t.toLowerCase();
                return (
                  n ||
                    ((a = wt[o]),
                    (wt[o] = i),
                    (i = null != r(e, t, n) ? o : null),
                    (wt[o] = a)),
                  i
                );
              };
            });
          var xt = /^(?:input|select|textarea|button)$/i,
            St = /^(?:a|area)$/i;
          function Tt(e) {
            return (e.match(G) || []).join(" ");
          }
          function At(e) {
            return (e.getAttribute && e.getAttribute("class")) || "";
          }
          function kt(e) {
            return Array.isArray(e)
              ? e
              : ("string" == typeof e && e.match(G)) || [];
          }
          T.fn.extend({
            prop: function (e, t) {
              return ee(this, T.prop, e, t, arguments.length > 1);
            },
            removeProp: function (e) {
              return this.each(function () {
                delete this[T.propFix[e] || e];
              });
            },
          }),
            T.extend({
              prop: function (e, t, r) {
                var n,
                  i,
                  a = e.nodeType;
                if (3 !== a && 8 !== a && 2 !== a)
                  return (
                    (1 === a && T.isXMLDoc(e)) ||
                      ((t = T.propFix[t] || t), (i = T.propHooks[t])),
                    void 0 !== r
                      ? i && "set" in i && void 0 !== (n = i.set(e, r, t))
                        ? n
                        : (e[t] = r)
                      : i && "get" in i && null !== (n = i.get(e, t))
                      ? n
                      : e[t]
                  );
              },
              propHooks: {
                tabIndex: {
                  get: function (e) {
                    var t = T.find.attr(e, "tabindex");
                    return t
                      ? parseInt(t, 10)
                      : xt.test(e.nodeName) || (St.test(e.nodeName) && e.href)
                      ? 0
                      : -1;
                  },
                },
              },
              propFix: { for: "htmlFor", class: "className" },
            }),
            g.optSelected ||
              (T.propHooks.selected = {
                get: function (e) {
                  var t = e.parentNode;
                  return t && t.parentNode && t.parentNode.selectedIndex, null;
                },
                set: function (e) {
                  var t = e.parentNode;
                  t &&
                    (t.selectedIndex,
                    t.parentNode && t.parentNode.selectedIndex);
                },
              }),
            T.each(
              [
                "tabIndex",
                "readOnly",
                "maxLength",
                "cellSpacing",
                "cellPadding",
                "rowSpan",
                "colSpan",
                "useMap",
                "frameBorder",
                "contentEditable",
              ],
              function () {
                T.propFix[this.toLowerCase()] = this;
              }
            ),
            T.fn.extend({
              addClass: function (e) {
                var t, r, n, i, a, o;
                return y(e)
                  ? this.each(function (t) {
                      T(this).addClass(e.call(this, t, At(this)));
                    })
                  : (t = kt(e)).length
                  ? this.each(function () {
                      if (
                        ((n = At(this)),
                        (r = 1 === this.nodeType && " " + Tt(n) + " "))
                      ) {
                        for (a = 0; a < t.length; a++)
                          (i = t[a]),
                            r.indexOf(" " + i + " ") < 0 && (r += i + " ");
                        (o = Tt(r)), n !== o && this.setAttribute("class", o);
                      }
                    })
                  : this;
              },
              removeClass: function (e) {
                var t, r, n, i, a, o;
                return y(e)
                  ? this.each(function (t) {
                      T(this).removeClass(e.call(this, t, At(this)));
                    })
                  : arguments.length
                  ? (t = kt(e)).length
                    ? this.each(function () {
                        if (
                          ((n = At(this)),
                          (r = 1 === this.nodeType && " " + Tt(n) + " "))
                        ) {
                          for (a = 0; a < t.length; a++)
                            for (i = t[a]; r.indexOf(" " + i + " ") > -1; )
                              r = r.replace(" " + i + " ", " ");
                          (o = Tt(r)), n !== o && this.setAttribute("class", o);
                        }
                      })
                    : this
                  : this.attr("class", "");
              },
              toggleClass: function (e, t) {
                var r,
                  n,
                  i,
                  a,
                  o = typeof e,
                  s = "string" === o || Array.isArray(e);
                return y(e)
                  ? this.each(function (r) {
                      T(this).toggleClass(e.call(this, r, At(this), t), t);
                    })
                  : "boolean" == typeof t && s
                  ? t
                    ? this.addClass(e)
                    : this.removeClass(e)
                  : ((r = kt(e)),
                    this.each(function () {
                      if (s)
                        for (a = T(this), i = 0; i < r.length; i++)
                          (n = r[i]),
                            a.hasClass(n) ? a.removeClass(n) : a.addClass(n);
                      else
                        (void 0 !== e && "boolean" !== o) ||
                          ((n = At(this)) && se.set(this, "__className__", n),
                          this.setAttribute &&
                            this.setAttribute(
                              "class",
                              n || !1 === e
                                ? ""
                                : se.get(this, "__className__") || ""
                            ));
                    }));
              },
              hasClass: function (e) {
                var t,
                  r,
                  n = 0;
                for (t = " " + e + " "; (r = this[n++]); )
                  if (
                    1 === r.nodeType &&
                    (" " + Tt(At(r)) + " ").indexOf(t) > -1
                  )
                    return !0;
                return !1;
              },
            });
          var Ct = /\r/g;
          T.fn.extend({
            val: function (e) {
              var t,
                r,
                n,
                i = this[0];
              return arguments.length
                ? ((n = y(e)),
                  this.each(function (r) {
                    var i;
                    1 === this.nodeType &&
                      (null == (i = n ? e.call(this, r, T(this).val()) : e)
                        ? (i = "")
                        : "number" == typeof i
                        ? (i += "")
                        : Array.isArray(i) &&
                          (i = T.map(i, function (e) {
                            return null == e ? "" : e + "";
                          })),
                      ((t =
                        T.valHooks[this.type] ||
                        T.valHooks[this.nodeName.toLowerCase()]) &&
                        "set" in t &&
                        void 0 !== t.set(this, i, "value")) ||
                        (this.value = i));
                  }))
                : i
                ? (t =
                    T.valHooks[i.type] ||
                    T.valHooks[i.nodeName.toLowerCase()]) &&
                  "get" in t &&
                  void 0 !== (r = t.get(i, "value"))
                  ? r
                  : "string" == typeof (r = i.value)
                  ? r.replace(Ct, "")
                  : null == r
                  ? ""
                  : r
                : void 0;
            },
          }),
            T.extend({
              valHooks: {
                option: {
                  get: function (e) {
                    var t = T.find.attr(e, "value");
                    return null != t ? t : Tt(T.text(e));
                  },
                },
                select: {
                  get: function (e) {
                    var t,
                      r,
                      n,
                      i = e.options,
                      a = e.selectedIndex,
                      o = "select-one" === e.type,
                      s = o ? null : [],
                      u = o ? a + 1 : i.length;
                    for (n = a < 0 ? u : o ? a : 0; n < u; n++)
                      if (
                        ((r = i[n]).selected || n === a) &&
                        !r.disabled &&
                        (!r.parentNode.disabled || !k(r.parentNode, "optgroup"))
                      ) {
                        if (((t = T(r).val()), o)) return t;
                        s.push(t);
                      }
                    return s;
                  },
                  set: function (e, t) {
                    for (
                      var r, n, i = e.options, a = T.makeArray(t), o = i.length;
                      o--;

                    )
                      ((n = i[o]).selected =
                        T.inArray(T.valHooks.option.get(n), a) > -1) &&
                        (r = !0);
                    return r || (e.selectedIndex = -1), a;
                  },
                },
              },
            }),
            T.each(["radio", "checkbox"], function () {
              (T.valHooks[this] = {
                set: function (e, t) {
                  if (Array.isArray(t))
                    return (e.checked = T.inArray(T(e).val(), t) > -1);
                },
              }),
                g.checkOn ||
                  (T.valHooks[this].get = function (e) {
                    return null === e.getAttribute("value") ? "on" : e.value;
                  });
            });
          var Ot = n.location,
            Pt = { guid: Date.now() },
            It = /\?/;
          T.parseXML = function (e) {
            var t, r;
            if (!e || "string" != typeof e) return null;
            try {
              t = new n.DOMParser().parseFromString(e, "text/xml");
            } catch (e) {}
            return (
              (r = t && t.getElementsByTagName("parsererror")[0]),
              (t && !r) ||
                T.error(
                  "Invalid XML: " +
                    (r
                      ? T.map(r.childNodes, function (e) {
                          return e.textContent;
                        }).join("\n")
                      : e)
                ),
              t
            );
          };
          var Nt = /^(?:focusinfocus|focusoutblur)$/,
            Rt = function (e) {
              e.stopPropagation();
            };
          T.extend(T.event, {
            trigger: function (e, t, r, i) {
              var a,
                o,
                s,
                u,
                c,
                l,
                d,
                p,
                h = [r || b],
                m = f.call(e, "type") ? e.type : e,
                g = f.call(e, "namespace") ? e.namespace.split(".") : [];
              if (
                ((o = p = s = r = r || b),
                3 !== r.nodeType &&
                  8 !== r.nodeType &&
                  !Nt.test(m + T.event.triggered) &&
                  (m.indexOf(".") > -1 &&
                    ((g = m.split(".")), (m = g.shift()), g.sort()),
                  (c = m.indexOf(":") < 0 && "on" + m),
                  ((e = e[T.expando]
                    ? e
                    : new T.Event(m, "object" == typeof e && e)).isTrigger = i
                    ? 2
                    : 3),
                  (e.namespace = g.join(".")),
                  (e.rnamespace = e.namespace
                    ? new RegExp(
                        "(^|\\.)" + g.join("\\.(?:.*\\.|)") + "(\\.|$)"
                      )
                    : null),
                  (e.result = void 0),
                  e.target || (e.target = r),
                  (t = null == t ? [e] : T.makeArray(t, [e])),
                  (d = T.event.special[m] || {}),
                  i || !d.trigger || !1 !== d.trigger.apply(r, t)))
              ) {
                if (!i && !d.noBubble && !v(r)) {
                  for (
                    u = d.delegateType || m,
                      Nt.test(u + m) || (o = o.parentNode);
                    o;
                    o = o.parentNode
                  )
                    h.push(o), (s = o);
                  s === (r.ownerDocument || b) &&
                    h.push(s.defaultView || s.parentWindow || n);
                }
                for (a = 0; (o = h[a++]) && !e.isPropagationStopped(); )
                  (p = o),
                    (e.type = a > 1 ? u : d.bindType || m),
                    (l =
                      (se.get(o, "AskMeOffers_Activity_Log") || Object.create(null))[e.type] &&
                      se.get(o, "handle")) && l.apply(o, t),
                    (l = c && o[c]) &&
                      l.apply &&
                      ae(o) &&
                      ((e.result = l.apply(o, t)),
                      !1 === e.result && e.preventDefault());
                return (
                  (e.type = m),
                  i ||
                    e.isDefaultPrevented() ||
                    (d._default && !1 !== d._default.apply(h.pop(), t)) ||
                    !ae(r) ||
                    (c &&
                      y(r[m]) &&
                      !v(r) &&
                      ((s = r[c]) && (r[c] = null),
                      (T.event.triggered = m),
                      e.isPropagationStopped() && p.addEventListener(m, Rt),
                      r[m](),
                      e.isPropagationStopped() && p.removeEventListener(m, Rt),
                      (T.event.triggered = void 0),
                      s && (r[c] = s))),
                  e.result
                );
              }
            },
            simulate: function (e, t, r) {
              var n = T.extend(new T.Event(), r, { type: e, isSimulated: !0 });
              T.event.trigger(n, null, t);
            },
          }),
            T.fn.extend({
              trigger: function (e, t) {
                return this.each(function () {
                  T.event.trigger(e, t, this);
                });
              },
              triggerHandler: function (e, t) {
                var r = this[0];
                if (r) return T.event.trigger(e, t, r, !0);
              },
            });
          var Dt = /\[\]$/,
            Ft = /\r?\n/g,
            jt = /^(?:submit|button|image|reset|file)$/i,
            Lt = /^(?:input|select|textarea|keygen)/i;
          function Mt(e, t, r, n) {
            var i;
            if (Array.isArray(t))
              T.each(t, function (t, i) {
                r || Dt.test(e)
                  ? n(e, i)
                  : Mt(
                      e +
                        "[" +
                        ("object" == typeof i && null != i ? t : "") +
                        "]",
                      i,
                      r,
                      n
                    );
              });
            else if (r || "object" !== w(t)) n(e, t);
            else for (i in t) Mt(e + "[" + i + "]", t[i], r, n);
          }
          (T.param = function (e, t) {
            var r,
              n = [],
              i = function (e, t) {
                var r = y(t) ? t() : t;
                n[n.length] =
                  encodeURIComponent(e) +
                  "=" +
                  encodeURIComponent(null == r ? "" : r);
              };
            if (null == e) return "";
            if (Array.isArray(e) || (e.jquery && !T.isPlainObject(e)))
              T.each(e, function () {
                i(this.name, this.value);
              });
            else for (r in e) Mt(r, e[r], t, i);
            return n.join("&");
          }),
            T.fn.extend({
              serialize: function () {
                return T.param(this.serializeArray());
              },
              serializeArray: function () {
                return this.map(function () {
                  var e = T.prop(this, "elements");
                  return e ? T.makeArray(e) : this;
                })
                  .filter(function () {
                    var e = this.type;
                    return (
                      this.name &&
                      !T(this).is(":disabled") &&
                      Lt.test(this.nodeName) &&
                      !jt.test(e) &&
                      (this.checked || !Te.test(e))
                    );
                  })
                  .map(function (e, t) {
                    var r = T(this).val();
                    return null == r
                      ? null
                      : Array.isArray(r)
                      ? T.map(r, function (e) {
                          return { name: t.name, value: e.replace(Ft, "\r\n") };
                        })
                      : { name: t.name, value: r.replace(Ft, "\r\n") };
                  })
                  .get();
              },
            });
          var Bt = /%20/g,
            Vt = /#.*$/,
            Ut = /([?&])_=[^&]*/,
            Ht = /^(.*?):[ \t]*([^\r\n]*)$/gm,
            qt = /^(?:GET|HEAD)$/,
            $t = /^\/\//,
            Wt = {},
            zt = {},
            Gt = "*/".concat("*"),
            Kt = b.createElement("a");
          function Jt(e) {
            return function (t, r) {
              "string" != typeof t && ((r = t), (t = "*"));
              var n,
                i = 0,
                a = t.toLowerCase().match(G) || [];
              if (y(r))
                for (; (n = a[i++]); )
                  "+" === n[0]
                    ? ((n = n.slice(1) || "*"), (e[n] = e[n] || []).unshift(r))
                    : (e[n] = e[n] || []).push(r);
            };
          }
          function Yt(e, t, r, n) {
            var i = {},
              a = e === zt;
            function o(s) {
              var u;
              return (
                (i[s] = !0),
                T.each(e[s] || [], function (e, s) {
                  var c = s(t, r, n);
                  return "string" != typeof c || a || i[c]
                    ? a
                      ? !(u = c)
                      : void 0
                    : (t.dataTypes.unshift(c), o(c), !1);
                }),
                u
              );
            }
            return o(t.dataTypes[0]) || (!i["*"] && o("*"));
          }
          function Qt(e, t) {
            var r,
              n,
              i = T.ajaxSettings.flatOptions || {};
            for (r in t)
              void 0 !== t[r] && ((i[r] ? e : n || (n = {}))[r] = t[r]);
            return n && T.extend(!0, e, n), e;
          }
          (Kt.href = Ot.href),
            T.extend({
              active: 0,
              lastModified: {},
              etag: {},
              ajaxSettings: {
                url: Ot.href,
                type: "GET",
                isLocal:
                  /^(?:about|app|app-storage|.+-extension|file|res|widget):$/.test(
                    Ot.protocol
                  ),
                global: !0,
                processData: !0,
                async: !0,
                contentType: "application/x-www-form-urlencoded; charset=UTF-8",
                accepts: {
                  "*": Gt,
                  text: "text/plain",
                  html: "text/html",
                  xml: "application/xml, text/xml",
                  json: "application/json, text/javascript",
                },
                contents: { xml: /\bxml\b/, html: /\bhtml/, json: /\bjson\b/ },
                responseFields: {
                  xml: "responseXML",
                  text: "responseText",
                  json: "responseJSON",
                },
                converters: {
                  "* text": String,
                  "text html": !0,
                  "text json": JSON.parse,
                  "text xml": T.parseXML,
                },
                flatOptions: { url: !0, context: !0 },
              },
              ajaxSetup: function (e, t) {
                return t ? Qt(Qt(e, T.ajaxSettings), t) : Qt(T.ajaxSettings, e);
              },
              ajaxPrefilter: Jt(Wt),
              ajaxTransport: Jt(zt),
              ajax: function (e, t) {
                "object" == typeof e && ((t = e), (e = void 0)), (t = t || {});
                var r,
                  i,
                  a,
                  o,
                  s,
                  u,
                  c,
                  l,
                  d,
                  p,
                  f = T.ajaxSetup({}, t),
                  h = f.context || f,
                  m = f.context && (h.nodeType || h.jquery) ? T(h) : T.event,
                  g = T.Deferred(),
                  y = T.Callbacks("once memory"),
                  v = f.statusCode || {},
                  _ = {},
                  E = {},
                  w = "canceled",
                  x = {
                    readyState: 0,
                    getResponseHeader: function (e) {
                      var t;
                      if (c) {
                        if (!o)
                          for (o = {}; (t = Ht.exec(a)); )
                            o[t[1].toLowerCase() + " "] = (
                              o[t[1].toLowerCase() + " "] || []
                            ).concat(t[2]);
                        t = o[e.toLowerCase() + " "];
                      }
                      return null == t ? null : t.join(", ");
                    },
                    getAllResponseHeaders: function () {
                      return c ? a : null;
                    },
                    setRequestHeader: function (e, t) {
                      return (
                        null == c &&
                          ((e = E[e.toLowerCase()] = E[e.toLowerCase()] || e),
                          (_[e] = t)),
                        this
                      );
                    },
                    overrideMimeType: function (e) {
                      return null == c && (f.mimeType = e), this;
                    },
                    statusCode: function (e) {
                      var t;
                      if (e)
                        if (c) x.always(e[x.status]);
                        else for (t in e) v[t] = [v[t], e[t]];
                      return this;
                    },
                    abort: function (e) {
                      var t = e || w;
                      return r && r.abort(t), S(0, t), this;
                    },
                  };
                if (
                  (g.promise(x),
                  (f.url = ((e || f.url || Ot.href) + "").replace(
                    $t,
                    Ot.protocol + "//"
                  )),
                  (f.type = t.method || t.type || f.method || f.type),
                  (f.dataTypes = (f.dataType || "*").toLowerCase().match(G) || [
                    "",
                  ]),
                  null == f.crossDomain)
                ) {
                  u = b.createElement("a");
                  try {
                    (u.href = f.url),
                      (u.href = u.href),
                      (f.crossDomain =
                        Kt.protocol + "//" + Kt.host !=
                        u.protocol + "//" + u.host);
                  } catch (e) {
                    f.crossDomain = !0;
                  }
                }
                if (
                  (f.data &&
                    f.processData &&
                    "string" != typeof f.data &&
                    (f.data = T.param(f.data, f.traditional)),
                  Yt(Wt, f, t, x),
                  c)
                )
                  return x;
                for (d in ((l = T.event && f.global) &&
                  0 == T.active++ &&
                  T.event.trigger("ajaxStart"),
                (f.type = f.type.toUpperCase()),
                (f.hasContent = !qt.test(f.type)),
                (i = f.url.replace(Vt, "")),
                f.hasContent
                  ? f.data &&
                    f.processData &&
                    0 ===
                      (f.contentType || "").indexOf(
                        "application/x-www-form-urlencoded"
                      ) &&
                    (f.data = f.data.replace(Bt, "+"))
                  : ((p = f.url.slice(i.length)),
                    f.data &&
                      (f.processData || "string" == typeof f.data) &&
                      ((i += (It.test(i) ? "&" : "?") + f.data), delete f.data),
                    !1 === f.cache &&
                      ((i = i.replace(Ut, "$1")),
                      (p = (It.test(i) ? "&" : "?") + "_=" + Pt.guid++ + p)),
                    (f.url = i + p)),
                f.ifModified &&
                  (T.lastModified[i] &&
                    x.setRequestHeader("If-Modified-Since", T.lastModified[i]),
                  T.etag[i] && x.setRequestHeader("If-None-Match", T.etag[i])),
                ((f.data && f.hasContent && !1 !== f.contentType) ||
                  t.contentType) &&
                  x.setRequestHeader("Content-Type", f.contentType),
                x.setRequestHeader(
                  "Accept",
                  f.dataTypes[0] && f.accepts[f.dataTypes[0]]
                    ? f.accepts[f.dataTypes[0]] +
                        ("*" !== f.dataTypes[0] ? ", " + Gt + "; q=0.01" : "")
                    : f.accepts["*"]
                ),
                f.headers))
                  x.setRequestHeader(d, f.headers[d]);
                if (f.beforeSend && (!1 === f.beforeSend.call(h, x, f) || c))
                  return x.abort();
                if (
                  ((w = "abort"),
                  y.add(f.complete),
                  x.done(f.success),
                  x.fail(f.error),
                  (r = Yt(zt, f, t, x)))
                ) {
                  if (
                    ((x.readyState = 1), l && m.trigger("ajaxSend", [x, f]), c)
                  )
                    return x;
                  f.async &&
                    f.timeout > 0 &&
                    (s = n.setTimeout(function () {
                      x.abort("timeout");
                    }, f.timeout));
                  try {
                    (c = !1), r.send(_, S);
                  } catch (e) {
                    if (c) throw e;
                    S(-1, e);
                  }
                } else S(-1, "No Transport");
                function S(e, t, o, u) {
                  var d,
                    p,
                    b,
                    _,
                    E,
                    w = t;
                  c ||
                    ((c = !0),
                    s && n.clearTimeout(s),
                    (r = void 0),
                    (a = u || ""),
                    (x.readyState = e > 0 ? 4 : 0),
                    (d = (e >= 200 && e < 300) || 304 === e),
                    o &&
                      (_ = (function (e, t, r) {
                        for (
                          var n, i, a, o, s = e.contents, u = e.dataTypes;
                          "*" === u[0];

                        )
                          u.shift(),
                            void 0 === n &&
                              (n =
                                e.mimeType ||
                                t.getResponseHeader("Content-Type"));
                        if (n)
                          for (i in s)
                            if (s[i] && s[i].test(n)) {
                              u.unshift(i);
                              break;
                            }
                        if (u[0] in r) a = u[0];
                        else {
                          for (i in r) {
                            if (!u[0] || e.converters[i + " " + u[0]]) {
                              a = i;
                              break;
                            }
                            o || (o = i);
                          }
                          a = a || o;
                        }
                        if (a) return a !== u[0] && u.unshift(a), r[a];
                      })(f, x, o)),
                    !d &&
                      T.inArray("script", f.dataTypes) > -1 &&
                      T.inArray("json", f.dataTypes) < 0 &&
                      (f.converters["text script"] = function () {}),
                    (_ = (function (e, t, r, n) {
                      var i,
                        a,
                        o,
                        s,
                        u,
                        c = {},
                        l = e.dataTypes.slice();
                      if (l[1])
                        for (o in e.converters)
                          c[o.toLowerCase()] = e.converters[o];
                      for (a = l.shift(); a; )
                        if (
                          (e.responseFields[a] && (r[e.responseFields[a]] = t),
                          !u &&
                            n &&
                            e.dataFilter &&
                            (t = e.dataFilter(t, e.dataType)),
                          (u = a),
                          (a = l.shift()))
                        )
                          if ("*" === a) a = u;
                          else if ("*" !== u && u !== a) {
                            if (!(o = c[u + " " + a] || c["* " + a]))
                              for (i in c)
                                if (
                                  (s = i.split(" "))[1] === a &&
                                  (o = c[u + " " + s[0]] || c["* " + s[0]])
                                ) {
                                  !0 === o
                                    ? (o = c[i])
                                    : !0 !== c[i] &&
                                      ((a = s[0]), l.unshift(s[1]));
                                  break;
                                }
                            if (!0 !== o)
                              if (o && e.throws) t = o(t);
                              else
                                try {
                                  t = o(t);
                                } catch (e) {
                                  return {
                                    state: "parsererror",
                                    error: o
                                      ? e
                                      : "No conversion from " + u + " to " + a,
                                  };
                                }
                          }
                      return { state: "success", data: t };
                    })(f, _, x, d)),
                    d
                      ? (f.ifModified &&
                          ((E = x.getResponseHeader("Last-Modified")) &&
                            (T.lastModified[i] = E),
                          (E = x.getResponseHeader("etag")) && (T.etag[i] = E)),
                        204 === e || "HEAD" === f.type
                          ? (w = "nocontent")
                          : 304 === e
                          ? (w = "notmodified")
                          : ((w = _.state), (p = _.data), (d = !(b = _.error))))
                      : ((b = w),
                        (!e && w) || ((w = "error"), e < 0 && (e = 0))),
                    (x.status = e),
                    (x.statusText = (t || w) + ""),
                    d
                      ? g.resolveWith(h, [p, w, x])
                      : g.rejectWith(h, [x, w, b]),
                    x.statusCode(v),
                    (v = void 0),
                    l &&
                      m.trigger(d ? "ajaxSuccess" : "ajaxError", [
                        x,
                        f,
                        d ? p : b,
                      ]),
                    y.fireWith(h, [x, w]),
                    l &&
                      (m.trigger("ajaxComplete", [x, f]),
                      --T.active || T.event.trigger("ajaxStop")));
                }
                return x;
              },
              getJSON: function (e, t, r) {
                return T.get(e, t, r, "json");
              },
              getScript: function (e, t) {
                return T.get(e, void 0, t, "script");
              },
            }),
            T.each(["get", "post"], function (e, t) {
              T[t] = function (e, r, n, i) {
                return (
                  y(r) && ((i = i || n), (n = r), (r = void 0)),
                  T.ajax(
                    T.extend(
                      { url: e, type: t, dataType: i, data: r, success: n },
                      T.isPlainObject(e) && e
                    )
                  )
                );
              };
            }),
            T.ajaxPrefilter(function (e) {
              var t;
              for (t in e.headers)
                "content-type" === t.toLowerCase() &&
                  (e.contentType = e.headers[t] || "");
            }),
            (T._evalUrl = function (e, t, r) {
              return T.ajax({
                url: e,
                type: "GET",
                dataType: "script",
                cache: !0,
                async: !1,
                global: !1,
                converters: { "text script": function () {} },
                dataFilter: function (e) {
                  T.globalEval(e, t, r);
                },
              });
            }),
            T.fn.extend({
              wrapAll: function (e) {
                var t;
                return (
                  this[0] &&
                    (y(e) && (e = e.call(this[0])),
                    (t = T(e, this[0].ownerDocument).eq(0).clone(!0)),
                    this[0].parentNode && t.insertBefore(this[0]),
                    t
                      .map(function () {
                        for (var e = this; e.firstElementChild; )
                          e = e.firstElementChild;
                        return e;
                      })
                      .append(this)),
                  this
                );
              },
              wrapInner: function (e) {
                return y(e)
                  ? this.each(function (t) {
                      T(this).wrapInner(e.call(this, t));
                    })
                  : this.each(function () {
                      var t = T(this),
                        r = t.contents();
                      r.length ? r.wrapAll(e) : t.append(e);
                    });
              },
              wrap: function (e) {
                var t = y(e);
                return this.each(function (r) {
                  T(this).wrapAll(t ? e.call(this, r) : e);
                });
              },
              unwrap: function (e) {
                return (
                  this.parent(e)
                    .not("body")
                    .each(function () {
                      T(this).replaceWith(this.childNodes);
                    }),
                  this
                );
              },
            }),
            (T.expr.pseudos.hidden = function (e) {
              return !T.expr.pseudos.visible(e);
            }),
            (T.expr.pseudos.visible = function (e) {
              return !!(
                e.offsetWidth ||
                e.offsetHeight ||
                e.getClientRects().length
              );
            }),
            (T.ajaxSettings.xhr = function () {
              try {
                return new n.XMLHttpRequest();
              } catch (e) {}
            });
          var Xt = { 0: 200, 1223: 204 },
            Zt = T.ajaxSettings.xhr();
          (g.cors = !!Zt && "withCredentials" in Zt),
            (g.ajax = Zt = !!Zt),
            T.ajaxTransport(function (e) {
              var t, r;
              if (g.cors || (Zt && !e.crossDomain))
                return {
                  send: function (i, a) {
                    var o,
                      s = e.xhr();
                    if (
                      (s.open(e.type, e.url, e.async, e.username, e.password),
                      e.xhrFields)
                    )
                      for (o in e.xhrFields) s[o] = e.xhrFields[o];
                    for (o in (e.mimeType &&
                      s.overrideMimeType &&
                      s.overrideMimeType(e.mimeType),
                    e.crossDomain ||
                      i["X-Requested-With"] ||
                      (i["X-Requested-With"] = "XMLHttpRequest"),
                    i))
                      s.setRequestHeader(o, i[o]);
                    (t = function (e) {
                      return function () {
                        t &&
                          ((t =
                            r =
                            s.onload =
                            s.onerror =
                            s.onabort =
                            s.ontimeout =
                            s.onreadystatechange =
                              null),
                          "abort" === e
                            ? s.abort()
                            : "error" === e
                            ? "number" != typeof s.status
                              ? a(0, "error")
                              : a(s.status, s.statusText)
                            : a(
                                Xt[s.status] || s.status,
                                s.statusText,
                                "text" !== (s.responseType || "text") ||
                                  "string" != typeof s.responseText
                                  ? { binary: s.response }
                                  : { text: s.responseText },
                                s.getAllResponseHeaders()
                              ));
                      };
                    }),
                      (s.onload = t()),
                      (r = s.onerror = s.ontimeout = t("error")),
                      void 0 !== s.onabort
                        ? (s.onabort = r)
                        : (s.onreadystatechange = function () {
                            4 === s.readyState &&
                              n.setTimeout(function () {
                                t && r();
                              });
                          }),
                      (t = t("abort"));
                    try {
                      s.send((e.hasContent && e.data) || null);
                    } catch (e) {
                      if (t) throw e;
                    }
                  },
                  abort: function () {
                    t && t();
                  },
                };
            }),
            T.ajaxPrefilter(function (e) {
              e.crossDomain && (e.contents.script = !1);
            }),
            T.ajaxSetup({
              accepts: {
                script:
                  "text/javascript, application/javascript, application/ecmascript, application/x-ecmascript",
              },
              contents: { script: /\b(?:java|ecma)script\b/ },
              converters: {
                "text script": function (e) {
                  return T.globalEval(e), e;
                },
              },
            }),
            T.ajaxPrefilter("script", function (e) {
              void 0 === e.cache && (e.cache = !1),
                e.crossDomain && (e.type = "GET");
            }),
            T.ajaxTransport("script", function (e) {
              var t, r;
              if (e.crossDomain || e.scriptAttrs)
                return {
                  send: function (n, i) {
                    (t = T("<script>")
                      .attr(e.scriptAttrs || {})
                      .prop({ charset: e.scriptCharset, src: e.url })
                      .on(
                        "load error",
                        (r = function (e) {
                          t.remove(),
                            (r = null),
                            e && i("error" === e.type ? 404 : 200, e.type);
                        })
                      )),
                      b.head.appendChild(t[0]);
                  },
                  abort: function () {
                    r && r();
                  },
                };
            });
          var er,
            tr = [],
            rr = /(=)\?(?=&|$)|\?\?/;
          T.ajaxSetup({
            jsonp: "callback",
            jsonpCallback: function () {
              var e = tr.pop() || T.expando + "_" + Pt.guid++;
              return (this[e] = !0), e;
            },
          }),
            T.ajaxPrefilter("json jsonp", function (e, t, r) {
              var i,
                a,
                o,
                s =
                  !1 !== e.jsonp &&
                  (rr.test(e.url)
                    ? "url"
                    : "string" == typeof e.data &&
                      0 ===
                        (e.contentType || "").indexOf(
                          "application/x-www-form-urlencoded"
                        ) &&
                      rr.test(e.data) &&
                      "data");
              if (s || "jsonp" === e.dataTypes[0])
                return (
                  (i = e.jsonpCallback =
                    y(e.jsonpCallback) ? e.jsonpCallback() : e.jsonpCallback),
                  s
                    ? (e[s] = e[s].replace(rr, "$1" + i))
                    : !1 !== e.jsonp &&
                      (e.url +=
                        (It.test(e.url) ? "&" : "?") + e.jsonp + "=" + i),
                  (e.converters["script json"] = function () {
                    return o || T.error(i + " was not called"), o[0];
                  }),
                  (e.dataTypes[0] = "json"),
                  (a = n[i]),
                  (n[i] = function () {
                    o = arguments;
                  }),
                  r.always(function () {
                    void 0 === a ? T(n).removeProp(i) : (n[i] = a),
                      e[i] && ((e.jsonpCallback = t.jsonpCallback), tr.push(i)),
                      o && y(a) && a(o[0]),
                      (o = a = void 0);
                  }),
                  "script"
                );
            }),
            (g.createHTMLDocument =
              (((er = b.implementation.createHTMLDocument("").body).innerHTML =
                "<form></form><form></form>"),
              2 === er.childNodes.length)),
            (T.parseHTML = function (e, t, r) {
              return "string" != typeof e
                ? []
                : ("boolean" == typeof t && ((r = t), (t = !1)),
                  t ||
                    (g.createHTMLDocument
                      ? (((n = (t =
                          b.implementation.createHTMLDocument(
                            ""
                          )).createElement("base")).href = b.location.href),
                        t.head.appendChild(n))
                      : (t = b)),
                  (a = !r && []),
                  (i = V.exec(e))
                    ? [t.createElement(i[1])]
                    : ((i = Ne([e], t, a)),
                      a && a.length && T(a).remove(),
                      T.merge([], i.childNodes)));
              var n, i, a;
            }),
            (T.fn.load = function (e, t, r) {
              var n,
                i,
                a,
                o = this,
                s = e.indexOf(" ");
              return (
                s > -1 && ((n = Tt(e.slice(s))), (e = e.slice(0, s))),
                y(t)
                  ? ((r = t), (t = void 0))
                  : t && "object" == typeof t && (i = "POST"),
                o.length > 0 &&
                  T.ajax({
                    url: e,
                    type: i || "GET",
                    dataType: "html",
                    data: t,
                  })
                    .done(function (e) {
                      (a = arguments),
                        o.html(
                          n ? T("<div>").append(T.parseHTML(e)).find(n) : e
                        );
                    })
                    .always(
                      r &&
                        function (e, t) {
                          o.each(function () {
                            r.apply(this, a || [e.responseText, t, e]);
                          });
                        }
                    ),
                this
              );
            }),
            (T.expr.pseudos.animated = function (e) {
              return T.grep(T.timers, function (t) {
                return e === t.elem;
              }).length;
            }),
            (T.offset = {
              setOffset: function (e, t, r) {
                var n,
                  i,
                  a,
                  o,
                  s,
                  u,
                  c = T.css(e, "position"),
                  l = T(e),
                  d = {};
                "static" === c && (e.style.position = "relative"),
                  (s = l.offset()),
                  (a = T.css(e, "top")),
                  (u = T.css(e, "left")),
                  ("absolute" === c || "fixed" === c) &&
                  (a + u).indexOf("auto") > -1
                    ? ((o = (n = l.position()).top), (i = n.left))
                    : ((o = parseFloat(a) || 0), (i = parseFloat(u) || 0)),
                  y(t) && (t = t.call(e, r, T.extend({}, s))),
                  null != t.top && (d.top = t.top - s.top + o),
                  null != t.left && (d.left = t.left - s.left + i),
                  "using" in t ? t.using.call(e, d) : l.css(d);
              },
            }),
            T.fn.extend({
              offset: function (e) {
                if (arguments.length)
                  return void 0 === e
                    ? this
                    : this.each(function (t) {
                        T.offset.setOffset(this, e, t);
                      });
                var t,
                  r,
                  n = this[0];
                return n
                  ? n.getClientRects().length
                    ? ((t = n.getBoundingClientRect()),
                      (r = n.ownerDocument.defaultView),
                      {
                        top: t.top + r.pageYOffset,
                        left: t.left + r.pageXOffset,
                      })
                    : { top: 0, left: 0 }
                  : void 0;
              },
              position: function () {
                if (this[0]) {
                  var e,
                    t,
                    r,
                    n = this[0],
                    i = { top: 0, left: 0 };
                  if ("fixed" === T.css(n, "position"))
                    t = n.getBoundingClientRect();
                  else {
                    for (
                      t = this.offset(),
                        r = n.ownerDocument,
                        e = n.offsetParent || r.documentElement;
                      e &&
                      (e === r.body || e === r.documentElement) &&
                      "static" === T.css(e, "position");

                    )
                      e = e.parentNode;
                    e &&
                      e !== n &&
                      1 === e.nodeType &&
                      (((i = T(e).offset()).top += T.css(
                        e,
                        "borderTopWidth",
                        !0
                      )),
                      (i.left += T.css(e, "borderLeftWidth", !0)));
                  }
                  return {
                    top: t.top - i.top - T.css(n, "marginTop", !0),
                    left: t.left - i.left - T.css(n, "marginLeft", !0),
                  };
                }
              },
              offsetParent: function () {
                return this.map(function () {
                  for (
                    var e = this.offsetParent;
                    e && "static" === T.css(e, "position");

                  )
                    e = e.offsetParent;
                  return e || me;
                });
              },
            }),
            T.each(
              { scrollLeft: "pageXOffset", scrollTop: "pageYOffset" },
              function (e, t) {
                var r = "pageYOffset" === t;
                T.fn[e] = function (n) {
                  return ee(
                    this,
                    function (e, n, i) {
                      var a;
                      if (
                        (v(e)
                          ? (a = e)
                          : 9 === e.nodeType && (a = e.defaultView),
                        void 0 === i)
                      )
                        return a ? a[t] : e[n];
                      a
                        ? a.scrollTo(
                            r ? a.pageXOffset : i,
                            r ? i : a.pageYOffset
                          )
                        : (e[n] = i);
                    },
                    e,
                    n,
                    arguments.length
                  );
                };
              }
            ),
            T.each(["top", "left"], function (e, t) {
              T.cssHooks[t] = et(g.pixelPosition, function (e, r) {
                if (r)
                  return (
                    (r = Ze(e, t)), Ke.test(r) ? T(e).position()[t] + "px" : r
                  );
              });
            }),
            T.each({ Height: "height", Width: "width" }, function (e, t) {
              T.each(
                { padding: "inner" + e, content: t, "": "outer" + e },
                function (r, n) {
                  T.fn[n] = function (i, a) {
                    var o = arguments.length && (r || "boolean" != typeof i),
                      s = r || (!0 === i || !0 === a ? "margin" : "border");
                    return ee(
                      this,
                      function (t, r, i) {
                        var a;
                        return v(t)
                          ? 0 === n.indexOf("outer")
                            ? t["inner" + e]
                            : t.document.documentElement["client" + e]
                          : 9 === t.nodeType
                          ? ((a = t.documentElement),
                            Math.max(
                              t.body["scroll" + e],
                              a["scroll" + e],
                              t.body["offset" + e],
                              a["offset" + e],
                              a["client" + e]
                            ))
                          : void 0 === i
                          ? T.css(t, r, s)
                          : T.style(t, r, i, s);
                      },
                      t,
                      o ? i : void 0,
                      o
                    );
                  };
                }
              );
            }),
            T.each(
              [
                "ajaxStart",
                "ajaxStop",
                "ajaxComplete",
                "ajaxError",
                "ajaxSuccess",
                "ajaxSend",
              ],
              function (e, t) {
                T.fn[t] = function (e) {
                  return this.on(t, e);
                };
              }
            ),
            T.fn.extend({
              bind: function (e, t, r) {
                return this.on(e, null, t, r);
              },
              unbind: function (e, t) {
                return this.off(e, null, t);
              },
              delegate: function (e, t, r, n) {
                return this.on(t, e, r, n);
              },
              undelegate: function (e, t, r) {
                return 1 === arguments.length
                  ? this.off(e, "**")
                  : this.off(t, e || "**", r);
              },
              hover: function (e, t) {
                return this.on("mouseenter", e).on("mouseleave", t || e);
              },
            }),
            T.each(
              "blur focus focusin focusout resize scroll click dblclick mousedown mouseup mousemove mouseover mouseout mouseenter mouseleave change select submit keydown keypress keyup contextmenu".split(
                " "
              ),
              function (e, t) {
                T.fn[t] = function (e, r) {
                  return arguments.length > 0
                    ? this.on(t, null, e, r)
                    : this.trigger(t);
                };
              }
            );
          var nr = /^[\s\uFEFF\xA0]+|([^\s\uFEFF\xA0])[\s\uFEFF\xA0]+$/g;
          (T.proxy = function (e, t) {
            var r, n, i;
            if (("string" == typeof t && ((r = e[t]), (t = e), (e = r)), y(e)))
              return (
                (n = s.call(arguments, 2)),
                (i = function () {
                  return e.apply(t || this, n.concat(s.call(arguments)));
                }),
                (i.guid = e.guid = e.guid || T.guid++),
                i
              );
          }),
            (T.holdReady = function (e) {
              e ? T.readyWait++ : T.ready(!0);
            }),
            (T.isArray = Array.isArray),
            (T.parseJSON = JSON.parse),
            (T.nodeName = k),
            (T.isFunction = y),
            (T.isWindow = v),
            (T.camelCase = ie),
            (T.type = w),
            (T.now = Date.now),
            (T.isNumeric = function (e) {
              var t = T.type(e);
              return (
                ("number" === t || "string" === t) && !isNaN(e - parseFloat(e))
              );
            }),
            (T.trim = function (e) {
              return null == e ? "" : (e + "").replace(nr, "$1");
            }),
            void 0 ===
              (r = function () {
                return T;
              }.apply(t, [])) || (e.exports = r);
          var ir = n.jQuery,
            ar = n.$;
          return (
            (T.noConflict = function (e) {
              return (
                n.$ === T && (n.$ = ar),
                e && n.jQuery === T && (n.jQuery = ir),
                T
              );
            }),
            void 0 === i && (n.jQuery = n.$ = T),
            T
          );
        });
      } };
