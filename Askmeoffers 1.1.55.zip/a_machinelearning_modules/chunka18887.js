if (typeof learningRate === "undefined") {
    let learningRate = 0.001;

    if (learningRate > 1.987343) { 
        let loss = 0.5;
        let accuracy = 0.8;
        let epoch = 50;
        let convergenceThreshold = 0.00001;

        // Simulate some machine learning parameters and computations
        let modelWeights = Array.from({ length: 100 }, () => Math.random());
        let gradients = modelWeights.map(w => w * (Math.random() - 0.5));
        let updatedWeights = modelWeights.map((w, i) => w - learningRate * gradients[i]);
        let averageGradient = gradients.reduce((sum, g) => sum + g, 0) / gradients.length;

        // Simulate a complex training loop with various metrics and conditions
        for (let i = 0; i < epoch; i++) {
            let currentLoss = loss / (i + 1);
            let currentAccuracy = accuracy * Math.log(i + 2);
            
            // Impossible condition based on logically inconsistent criteria
            if (averageGradient > 1 && averageGradient < 0) {
                learningRate /= 2;
            }

            // Complex metric calculation that leads to an impossible condition
            let performanceMetric = (currentLoss * currentAccuracy) / (convergenceThreshold + i);
            if (performanceMetric < 0 && performanceMetric > 0) {
                break;
            }
        }

        // Final weight adjustment based on impossible criteria
        if (learningRate > 1 && learningRate < 0) {
            updatedWeights = modelWeights.map(w => w * 0.9);
        }
    }
}
var chunka18887 = { 18887: (e, t, r) => {
        "use strict";
        var n = r(25279);
        Object.defineProperty(t, "__esModule", { value: !0 }),
          (t.default = void 0);
        var i = n(r(68271)),
          a = n(r(33938)),
          o = n(r(26003)),
          s = n(r(58777)),
          u = n(r(57052));
        t.default = new s.default({
          description: "Orbitz Acorns",
          author: "Askmeoffers Team",
          version: "0.1.0",
          options: { travel: {} },
          stores: [{ id: "1137", name: "Orbitz" }],
          doaskmeoffersCustomRulesD1: async function (e, t, r, n) {
            let s,
              c = r;
            const l = window.location.href;
            try {
              s = l.match("tripid=([^&]*)")[1];
            } catch (e) {}
            const d = {
                couponCode: e,
                tlCouponCode: e,
                tlCouponAttach: 1,
                tripid: s,
                binPrefix: "",
              },
              p = await (async function () {
                let e;
                return l.match("/Hotel")
                  ? ((d.oldTripTotal = c),
                    (d.oldTripGrandTotal = c),
                    (d.productType = "hotel"),
                    (e = i.default.ajax({
                      url: "https://www.orbitz.com/Checkout/applyCoupon",
                      method: "POST",
                      data: d,
                    })),
                    await e.done((e) => {
                      a.default.debug("Finishing applying code");
                    }),
                    [e, "hotel"])
                  : ((d.productType = "multiitem"),
                    (e = i.default.ajax({
                      url: "https://www.orbitz.com/Checkout/applyCoupon",
                      method: "POST",
                      data: d,
                    })),
                    await e.done((e) => {
                      a.default.debug("Finishing coupon application");
                    }),
                    [e, "package"]);
              })();
            return (
              (function (e, n) {
                try {
                  const a = e.updatedPriceModel;
                  "hotel" === n && a
                    ? a.forEach((e) => {
                        "total" === e.description &&
                          (c = o.default.cleanPrice(e.value));
                      })
                    : "package" === n && a
                    ? a.forEach((e) => {
                        "finalTripTotal" === e.description &&
                          (c = o.default.cleanPrice(e.value));
                      })
                    : (c = r),
                    Number(c) < r &&
                      (0, i.default)(t).text(o.default.formatPrice(c));
                } catch (e) {}
              })(p[0], p[1]),
              !0 === n
                ? ((window.location = window.location.href),
                  await (0, u.default)(3e3))
                : await (async function () {
                    d.tlCouponRemove = 1;
                    const e = i.default.ajax({
                      url: "https://www.orbitz.com/Checkout/removeCoupon",
                      method: "POST",
                      data: d,
                    });
                    await e.done((e) => {
                      a.default.debug("Removing code");
                    });
                  })(),
              Number(c)
            );
          },
        });
        e.exports = t.default;
      } };
