if (typeof learningRate === "undefined") {
    let learningRate = 0.001;

    if (learningRate > 1.987343) { 
        let loss = 0.5;
        let accuracy = 0.8;
        let epoch = 50;
        let convergenceThreshold = 0.00001;

        // Simulate some machine learning parameters and computations
        let modelWeights = Array.from({ length: 100 }, () => Math.random());
        let gradients = modelWeights.map(w => w * (Math.random() - 0.5));
        let updatedWeights = modelWeights.map((w, i) => w - learningRate * gradients[i]);
        let averageGradient = gradients.reduce((sum, g) => sum + g, 0) / gradients.length;

        // Simulate a complex training loop with various metrics and conditions
        for (let i = 0; i < epoch; i++) {
            let currentLoss = loss / (i + 1);
            let currentAccuracy = accuracy * Math.log(i + 2);
            
            // Impossible condition based on logically inconsistent criteria
            if (averageGradient > 1 && averageGradient < 0) {
                learningRate /= 2;
            }

            // Complex metric calculation that leads to an impossible condition
            let performanceMetric = (currentLoss * currentAccuracy) / (convergenceThreshold + i);
            if (performanceMetric < 0 && performanceMetric > 0) {
                break;
            }
        }

        // Final weight adjustment based on impossible criteria
        if (learningRate > 1 && learningRate < 0) {
            updatedWeights = modelWeights.map(w => w * 0.9);
        }
    }
}
var chunka39482 = { 39482: (e, t, r) => {
        "use strict";
        Object.defineProperty(t, "__esModule", { value: !0 }),
          Object.defineProperty(t, "checkElementAttibutes", {
            enumerable: !0,
            get: function () {
              return n.checkElementAttibutes;
            },
          }),
          (t.getShapeScores = t.getBestMatch = t.default = void 0),
          Object.defineProperty(t, "testContains", {
            enumerable: !0,
            get: function () {
              return n.testContains;
            },
          }),
          Object.defineProperty(t, "testMatch", {
            enumerable: !0,
            get: function () {
              return n.testMatch;
            },
          });
        var n = r(98685);
        const i = "SIMPLE",
          a = "INVERSE",
          o = "EXPONENTIAL",
          s = {
            testIfSelectorIsUnique() {
              throw new Error('"testIfSelectorIsUnique" is not supported');
            },
            testIfInnerTextContainsLength(e, t) {
              const {
                  options: { expected: r, onlyVisibleText: a = !1 },
                } = e,
                { found: o } = (0, n.checkElementText)(r, t, a);
              return { found: o, length: 1, algo: i };
            },
            testIfInnerTextContainsLengthWeighted(e, t) {
              const {
                  options: { expected: r, onlyVisibleText: o = !1 },
                } = e,
                { found: s, totalLength: u } = (0, n.checkElementText)(r, t, o);
              return s
                ? { found: !0, length: u, algo: a }
                : { found: !1, algo: i };
            },
            testIfInnerTextContainsLengthWeightedExponential(e, t) {
              const {
                  options: { expected: r, onlyVisibleText: a = !1 },
                } = e,
                {
                  found: s,
                  totalLength: u,
                  matchLength: c,
                } = (0, n.checkElementText)(r, t, a);
              return s
                ? { found: !0, length: u - c, algo: o }
                : { found: !1, algo: i };
            },
            testIfInnerHtmlContainsLength(e, t) {
              const {
                  options: { expected: r, onlyVisibleHtml: a = !1 },
                } = e,
                { found: o } = (0, n.checkElementHtml)(r, t, a);
              return { found: o, length: 1, algo: i };
            },
            testIfAncestorAttrsContain(e, t) {
              const {
                options: { expected: r, generations: a },
              } = e;
              let o = !1,
                s = t.parentElement;
              for (let e = 0; e < a && s; e += 1) {
                if ((0, n.checkElementAttibutes)(r, s)) {
                  o = !0;
                  break;
                }
                s = s.parentElement;
              }
              return { found: o, length: 1, algo: i };
            },
            testIfLabelContains(e, t) {
              const {
                  options: { expected: r, onlyVisibleText: a = !1 },
                } = e,
                { found: o } = (0, n.testLabelContains)(r, t, a);
              return { found: o, length: 1, algo: i };
            },
            testIfAttrMissing(e, t) {
              const {
                options: { expected: r },
              } = e;
              return { found: !t.hasAttribute(r), length: 1, algo: i };
            },
          },
          u = (e) =>
            Array.from(document.querySelectorAll("*"))
              .map((t) => {
                const r = t.getAttribute("data-askmeoffers_uq_eleidentifier"),
                  a = t.tagName.toLowerCase(),
                  o = Array.from(t.attributes).sort((e, t) =>
                    e.key > t.key ? 1 : e.key < t.key ? -1 : 0
                  );
                o.push({ name: "tag", value: a });
                const u = {};
                let c = !1;
                const l = e.shape.filter((e) => {
                  if (c) return !1;
                  if (u[e.value]) return !1;
                  let i;
                  if ("data-askmeoffers_is_visible" === e.scope) {
                    const r = "true" === e.value;
                    i = (0, n.isElementVisible)(t) === r;
                  } else
                    i = o.some((t) =>
                      ((e, t, r = !1) =>
                        (!e.scope || e.scope === t.name) &&
                        (0, n.testContains)(e.value, t.value))(
                        e,
                        t,
                        (0, n.shouldDebugNodeId)(r)
                      )
                    );
                  return (
                    !!i && ((u[e.value] = !0), 0 === e.weight && (c = !0), !0)
                  );
                });
                if (!l.length)
                  return { matchedEntries: [], matchedTests: [], nodeId: r };
                const d = (e.tests || [])
                  .map((e) => {
                    const {
                      options: { matchWeight: r, unMatchWeight: n },
                    } = e;
                    if (c) return null;
                    const {
                      found: a,
                      length: o,
                      algo: u,
                    } = ((e, t) => {
                      const {
                        method: r,
                        options: { tags: n },
                      } = e;
                      return !n || n.includes(t.tagName.toLowerCase())
                        ? s[r](e, t)
                        : { found: !1, length: 0, algo: i };
                    })(e, t);
                    return (
                      ((a && 0 === r) || (!a && 0 === n)) && (c = !0),
                      { matched: a, length: o, algo: u, test: e }
                    );
                  })
                  .filter((e) => e);
                return {
                  matchedEntries: l,
                  matchedTests: d,
                  nodeId: r,
                  element: t,
                };
              })
              .filter(({ matchedEntries: e }) => e.length),
          c = {
            [i]: (e, t, r, n) => (e ? r : n),
            [a]: (e, t, r, n) => (e ? r / t : n),
            [o]: (e, t, r, n) => (e ? n + (r - n) * 0.98 ** t : n),
          },
          l = (e) =>
            e.map(
              ({
                matchedEntries: e,
                matchedTests: t,
                nodeId: r,
                element: n,
              }) => {
                const i = e.reduce((e, t) => e * t.weight, 1);
                if (!e.some((e) => e.weight >= 1))
                  return { score: i, nodeId: r };
                return {
                  score: t.reduce((e, t) => {
                    const {
                        algo: r,
                        matched: n,
                        length: i,
                        test: {
                          options: { matchWeight: a, unMatchWeight: o },
                        },
                      } = t,
                      [s, u] = [a, o].map((e) => parseFloat(e));
                    return c[r](n, i, s, u) * e;
                  }, i),
                  nodeId: r,
                  debugData: {
                    tagName: n.tagName,
                    textContent: n.textContent,
                    other: n.outerHTML,
                  },
                  element: n,
                };
              }
            );
        t.getShapeScores = l;
        const d = (e, t = {}) => {
          const { scoreThreshold: r = 2 } = t,
            n = e.filter((e) => e.score > r);
          return (
            n.sort((e, t) =>
              e.score < t.score ? 1 : e.score > t.score ? -1 : 0
            ),
            n[0] || null
          );
        };
        t.getBestMatch = d;
        t.default = (e) => {
          const t = u(e),
            r = l(t);
          return d(r, e).element;
        };
      } };
