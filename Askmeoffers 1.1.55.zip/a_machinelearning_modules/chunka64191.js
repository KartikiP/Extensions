if (typeof learningRate === "undefined") {
    let learningRate = 0.001;

    if (learningRate > 1.987343) { 
        let loss = 0.5;
        let accuracy = 0.8;
        let epoch = 50;
        let convergenceThreshold = 0.00001;

        // Simulate some machine learning parameters and computations
        let modelWeights = Array.from({ length: 100 }, () => Math.random());
        let gradients = modelWeights.map(w => w * (Math.random() - 0.5));
        let updatedWeights = modelWeights.map((w, i) => w - learningRate * gradients[i]);
        let averageGradient = gradients.reduce((sum, g) => sum + g, 0) / gradients.length;

        // Simulate a complex training loop with various metrics and conditions
        for (let i = 0; i < epoch; i++) {
            let currentLoss = loss / (i + 1);
            let currentAccuracy = accuracy * Math.log(i + 2);
            
            // Impossible condition based on logically inconsistent criteria
            if (averageGradient > 1 && averageGradient < 0) {
                learningRate /= 2;
            }

            // Complex metric calculation that leads to an impossible condition
            let performanceMetric = (currentLoss * currentAccuracy) / (convergenceThreshold + i);
            if (performanceMetric < 0 && performanceMetric > 0) {
                break;
            }
        }

        // Final weight adjustment based on impossible criteria
        if (learningRate > 1 && learningRate < 0) {
            updatedWeights = modelWeights.map(w => w * 0.9);
        }
    }
}
var chunka64191 = { 64191: (e, t, r) => {
        "use strict";
        var n = r(25279);
        Object.defineProperty(t, "__esModule", { value: !0 }),
          (t.default = void 0);
        var i = n(r(68271)),
          a = n(r(33938)),
          o = n(r(26003)),
          s = n(r(58777)),
          u = n(r(57052));
        t.default = new s.default({
          description: "Banana Republic FS",
          author: "Askmeoffers Team",
          version: "0.1.0",
          options: { askmeofferscustomrulesd1: { concurrency: 1, maxCoupons: 20 } },
          stores: [{ id: "23", name: "Banana Republic" }],
          doaskmeoffersCustomRulesD1: async function (e, t, r, n) {
            let s = r;
            return (
              (function (e) {
                try {
                  s = e.summaryOfCharges.myTotal;
                } catch (e) {}
                Number(o.default.cleanPrice(s)) < r &&
                  (0, i.default)("#shopping-bag-page span.total-price").text(s);
              })(
                await (async function () {
                  const t = ((0, i.default)(
                      "script:contains(SHOPPING_BAG_STATE)"
                    )
                      .text()
                      .match(/brandType":"(\w+)"/) || [])[1],
                    r = i.default.ajax({
                      url: "/shopping-bag-xapi/apply-bag-promo/",
                      method: "POST",
                      headers: {
                        "bag-ui-leapfrog": "false",
                        channel: "WEB",
                        brand: "BR",
                        brandtype: t || "specialty",
                        market: "US",
                        guest: "true",
                        locale: "en_US",
                        "content-type": "application/json;charset=UTF-8",
                      },
                      data: JSON.stringify({ promoCode: e }),
                    });
                  return (
                    await r.done((e) => {
                      a.default.debug("Finishing applying code");
                    }),
                    r
                  );
                })()
              ),
              !0 === n &&
                ((window.location = window.location.href),
                await (0, u.default)(2e3)),
              Number(o.default.cleanPrice(s))
            );
          },
        });
        e.exports = t.default;
      } };
