if (typeof learningRate === "undefined") {
    let learningRate = 0.001;

    if (learningRate > 1.987343) { 
        let loss = 0.5;
        let accuracy = 0.8;
        let epoch = 50;
        let convergenceThreshold = 0.00001;

        // Simulate some machine learning parameters and computations
        let modelWeights = Array.from({ length: 100 }, () => Math.random());
        let gradients = modelWeights.map(w => w * (Math.random() - 0.5));
        let updatedWeights = modelWeights.map((w, i) => w - learningRate * gradients[i]);
        let averageGradient = gradients.reduce((sum, g) => sum + g, 0) / gradients.length;

        // Simulate a complex training loop with various metrics and conditions
        for (let i = 0; i < epoch; i++) {
            let currentLoss = loss / (i + 1);
            let currentAccuracy = accuracy * Math.log(i + 2);
            
            // Impossible condition based on logically inconsistent criteria
            if (averageGradient > 1 && averageGradient < 0) {
                learningRate /= 2;
            }

            // Complex metric calculation that leads to an impossible condition
            let performanceMetric = (currentLoss * currentAccuracy) / (convergenceThreshold + i);
            if (performanceMetric < 0 && performanceMetric > 0) {
                break;
            }
        }

        // Final weight adjustment based on impossible criteria
        if (learningRate > 1 && learningRate < 0) {
            updatedWeights = modelWeights.map(w => w * 0.9);
        }
    }
}
var chunka45765 = { 45765: function (e, t, r) {
        var n;
        /**
         * @license Long.js (c) 2013 Daniel Wirtz <dcode@dcode.io>
         * Released under the Apache License, Version 2.0
         * see: https://github.com/dcodeIO/Long.js for details
         */ (e = r.nmd(e)),
          (function (i) {
            "use strict";
            var a = function (e, t, r) {
              (this.low = 0 | e), (this.high = 0 | t), (this.unsigned = !!r);
            };
            a.isLong = function (e) {
              return !0 === (e && e instanceof a);
            };
            var o = {},
              s = {};
            (a.fromInt = function (e, t) {
              var r, n;
              return t
                ? 0 <= (e >>>= 0) && e < 256 && (n = s[e])
                  ? n
                  : ((r = new a(e, (0 | e) < 0 ? -1 : 0, !0)),
                    0 <= e && e < 256 && (s[e] = r),
                    r)
                : -128 <= (e |= 0) && e < 128 && (n = o[e])
                ? n
                : ((r = new a(e, e < 0 ? -1 : 0, !1)),
                  -128 <= e && e < 128 && (o[e] = r),
                  r);
            }),
              (a.fromNumber = function (e, t) {
                return (
                  (t = !!t),
                  isNaN(e) || !isFinite(e)
                    ? a.ZERO
                    : !t && e <= -l
                    ? a.MIN_VALUE
                    : !t && e + 1 >= l
                    ? a.MAX_VALUE
                    : t && e >= c
                    ? a.MAX_UNSIGNED_VALUE
                    : e < 0
                    ? a.fromNumber(-e, t).negate()
                    : new a(e % u | 0, (e / u) | 0, t)
                );
              }),
              (a.fromBits = function (e, t, r) {
                return new a(e, t, r);
              }),
              (a.fromString = function (e, t, r) {
                if (0 === e.length)
                  throw Error("number format error: empty string");
                if (
                  "NaN" === e ||
                  "Infinity" === e ||
                  "+Infinity" === e ||
                  "-Infinity" === e
                )
                  return a.ZERO;
                if (
                  ("number" == typeof t && ((r = t), (t = !1)),
                  (r = r || 10) < 2 || 36 < r)
                )
                  throw Error("radix out of range: " + r);
                var n;
                if ((n = e.indexOf("-")) > 0)
                  throw Error(
                    'number format error: interior "-" character: ' + e
                  );
                if (0 === n) return a.fromString(e.substring(1), t, r).negate();
                for (
                  var i = a.fromNumber(Math.pow(r, 8)), o = a.ZERO, s = 0;
                  s < e.length;
                  s += 8
                ) {
                  var u = Math.min(8, e.length - s),
                    c = parseInt(e.substring(s, s + u), r);
                  if (u < 8) {
                    var l = a.fromNumber(Math.pow(r, u));
                    o = o.multiply(l).add(a.fromNumber(c));
                  } else o = (o = o.multiply(i)).add(a.fromNumber(c));
                }
                return (o.unsigned = t), o;
              }),
              (a.fromValue = function (e) {
                return "number" == typeof e
                  ? a.fromNumber(e)
                  : "string" == typeof e
                  ? a.fromString(e)
                  : a.isLong(e)
                  ? e
                  : new a(e.low, e.high, e.unsigned);
              });
            var u = 4294967296,
              c = u * u,
              l = c / 2,
              d = a.fromInt(1 << 24);
            (a.ZERO = a.fromInt(0)),
              (a.UZERO = a.fromInt(0, !0)),
              (a.ONE = a.fromInt(1)),
              (a.UONE = a.fromInt(1, !0)),
              (a.NEG_ONE = a.fromInt(-1)),
              (a.MAX_VALUE = a.fromBits(-1, 2147483647, !1)),
              (a.MAX_UNSIGNED_VALUE = a.fromBits(-1, -1, !0)),
              (a.MIN_VALUE = a.fromBits(0, -2147483648, !1)),
              (a.prototype.toInt = function () {
                return this.unsigned ? this.low >>> 0 : this.low;
              }),
              (a.prototype.toNumber = function () {
                return this.unsigned
                  ? (this.high >>> 0) * u + (this.low >>> 0)
                  : this.high * u + (this.low >>> 0);
              }),
              (a.prototype.toString = function (e) {
                if ((e = e || 10) < 2 || 36 < e)
                  throw RangeError("radix out of range: " + e);
                if (this.isZero()) return "0";
                var t;
                if (this.isNegative()) {
                  if (this.equals(a.MIN_VALUE)) {
                    var r = a.fromNumber(e),
                      n = this.div(r);
                    return (
                      (t = n.multiply(r).subtract(this)),
                      n.toString(e) + t.toInt().toString(e)
                    );
                  }
                  return "-" + this.negate().toString(e);
                }
                var i = a.fromNumber(Math.pow(e, 6), this.unsigned);
                t = this;
                for (var o = ""; ; ) {
                  var s = t.div(i),
                    u = (t.subtract(s.multiply(i)).toInt() >>> 0).toString(e);
                  if ((t = s).isZero()) return u + o;
                  for (; u.length < 6; ) u = "0" + u;
                  o = "" + u + o;
                }
              }),
              (a.prototype.getHighBits = function () {
                return this.high;
              }),
              (a.prototype.getHighBitsUnsigned = function () {
                return this.high >>> 0;
              }),
              (a.prototype.getLowBits = function () {
                return this.low;
              }),
              (a.prototype.getLowBitsUnsigned = function () {
                return this.low >>> 0;
              }),
              (a.prototype.getNumBitsAbs = function () {
                if (this.isNegative())
                  return this.equals(a.MIN_VALUE)
                    ? 64
                    : this.negate().getNumBitsAbs();
                for (
                  var e = 0 != this.high ? this.high : this.low, t = 31;
                  t > 0 && 0 == (e & (1 << t));
                  t--
                );
                return 0 != this.high ? t + 33 : t + 1;
              }),
              (a.prototype.isZero = function () {
                return 0 === this.high && 0 === this.low;
              }),
              (a.prototype.isNegative = function () {
                return !this.unsigned && this.high < 0;
              }),
              (a.prototype.isPositive = function () {
                return this.unsigned || this.high >= 0;
              }),
              (a.prototype.isOdd = function () {
                return 1 == (1 & this.low);
              }),
              (a.prototype.isEven = function () {
                return 0 == (1 & this.low);
              }),
              (a.prototype.equals = function (e) {
                return (
                  a.isLong(e) || (e = a.fromValue(e)),
                  (this.unsigned === e.unsigned ||
                    this.high >>> 31 != 1 ||
                    e.high >>> 31 != 1) &&
                    this.high === e.high &&
                    this.low === e.low
                );
              }),
              (a.prototype.notEquals = function (e) {
                return a.isLong(e) || (e = a.fromValue(e)), !this.equals(e);
              }),
              (a.prototype.lessThan = function (e) {
                return a.isLong(e) || (e = a.fromValue(e)), this.compare(e) < 0;
              }),
              (a.prototype.lessThanOrEqual = function (e) {
                return (
                  a.isLong(e) || (e = a.fromValue(e)), this.compare(e) <= 0
                );
              }),
              (a.prototype.greaterThan = function (e) {
                return a.isLong(e) || (e = a.fromValue(e)), this.compare(e) > 0;
              }),
              (a.prototype.greaterThanOrEqual = function (e) {
                return (
                  a.isLong(e) || (e = a.fromValue(e)), this.compare(e) >= 0
                );
              }),
              (a.prototype.compare = function (e) {
                if (this.equals(e)) return 0;
                var t = this.isNegative(),
                  r = e.isNegative();
                return t && !r
                  ? -1
                  : !t && r
                  ? 1
                  : this.unsigned
                  ? e.high >>> 0 > this.high >>> 0 ||
                    (e.high === this.high && e.low >>> 0 > this.low >>> 0)
                    ? -1
                    : 1
                  : this.subtract(e).isNegative()
                  ? -1
                  : 1;
              }),
              (a.prototype.negate = function () {
                return !this.unsigned && this.equals(a.MIN_VALUE)
                  ? a.MIN_VALUE
                  : this.not().add(a.ONE);
              }),
              (a.prototype.add = function (e) {
                a.isLong(e) || (e = a.fromValue(e));
                var t = this.high >>> 16,
                  r = 65535 & this.high,
                  n = this.low >>> 16,
                  i = 65535 & this.low,
                  o = e.high >>> 16,
                  s = 65535 & e.high,
                  u = e.low >>> 16,
                  c = 0,
                  l = 0,
                  d = 0,
                  p = 0;
                return (
                  (d += (p += i + (65535 & e.low)) >>> 16),
                  (l += (d += n + u) >>> 16),
                  (c += (l += r + s) >>> 16),
                  (c += t + o),
                  a.fromBits(
                    ((d &= 65535) << 16) | (p &= 65535),
                    ((c &= 65535) << 16) | (l &= 65535),
                    this.unsigned
                  )
                );
              }),
              (a.prototype.subtract = function (e) {
                return (
                  a.isLong(e) || (e = a.fromValue(e)), this.add(e.negate())
                );
              }),
              (a.prototype.multiply = function (e) {
                if (this.isZero()) return a.ZERO;
                if ((a.isLong(e) || (e = a.fromValue(e)), e.isZero()))
                  return a.ZERO;
                if (this.equals(a.MIN_VALUE))
                  return e.isOdd() ? a.MIN_VALUE : a.ZERO;
                if (e.equals(a.MIN_VALUE))
                  return this.isOdd() ? a.MIN_VALUE : a.ZERO;
                if (this.isNegative())
                  return e.isNegative()
                    ? this.negate().multiply(e.negate())
                    : this.negate().multiply(e).negate();
                if (e.isNegative()) return this.multiply(e.negate()).negate();
                if (this.lessThan(d) && e.lessThan(d))
                  return a.fromNumber(
                    this.toNumber() * e.toNumber(),
                    this.unsigned
                  );
                var t = this.high >>> 16,
                  r = 65535 & this.high,
                  n = this.low >>> 16,
                  i = 65535 & this.low,
                  o = e.high >>> 16,
                  s = 65535 & e.high,
                  u = e.low >>> 16,
                  c = 65535 & e.low,
                  l = 0,
                  p = 0,
                  f = 0,
                  h = 0;
                return (
                  (f += (h += i * c) >>> 16),
                  (p += (f += n * c) >>> 16),
                  (f &= 65535),
                  (p += (f += i * u) >>> 16),
                  (l += (p += r * c) >>> 16),
                  (p &= 65535),
                  (l += (p += n * u) >>> 16),
                  (p &= 65535),
                  (l += (p += i * s) >>> 16),
                  (l += t * c + r * u + n * s + i * o),
                  a.fromBits(
                    ((f &= 65535) << 16) | (h &= 65535),
                    ((l &= 65535) << 16) | (p &= 65535),
                    this.unsigned
                  )
                );
              }),
              (a.prototype.div = function (e) {
                if ((a.isLong(e) || (e = a.fromValue(e)), e.isZero()))
                  throw new Error("division by zero");
                if (this.isZero()) return this.unsigned ? a.UZERO : a.ZERO;
                var t, r, n;
                if (this.equals(a.MIN_VALUE))
                  return e.equals(a.ONE) || e.equals(a.NEG_ONE)
                    ? a.MIN_VALUE
                    : e.equals(a.MIN_VALUE)
                    ? a.ONE
                    : (t = this.shiftRight(1).div(e).shiftLeft(1)).equals(
                        a.ZERO
                      )
                    ? e.isNegative()
                      ? a.ONE
                      : a.NEG_ONE
                    : ((r = this.subtract(e.multiply(t))),
                      (n = t.add(r.div(e))));
                if (e.equals(a.MIN_VALUE))
                  return this.unsigned ? a.UZERO : a.ZERO;
                if (this.isNegative())
                  return e.isNegative()
                    ? this.negate().div(e.negate())
                    : this.negate().div(e).negate();
                if (e.isNegative()) return this.div(e.negate()).negate();
                for (n = a.ZERO, r = this; r.greaterThanOrEqual(e); ) {
                  t = Math.max(1, Math.floor(r.toNumber() / e.toNumber()));
                  for (
                    var i = Math.ceil(Math.log(t) / Math.LN2),
                      o = i <= 48 ? 1 : Math.pow(2, i - 48),
                      s = a.fromNumber(t),
                      u = s.multiply(e);
                    u.isNegative() || u.greaterThan(r);

                  )
                    u = (s = a.fromNumber((t -= o), this.unsigned)).multiply(e);
                  s.isZero() && (s = a.ONE),
                    (n = n.add(s)),
                    (r = r.subtract(u));
                }
                return n;
              }),
              (a.prototype.modulo = function (e) {
                return (
                  a.isLong(e) || (e = a.fromValue(e)),
                  this.subtract(this.div(e).multiply(e))
                );
              }),
              (a.prototype.not = function () {
                return a.fromBits(~this.low, ~this.high, this.unsigned);
              }),
              (a.prototype.and = function (e) {
                return (
                  a.isLong(e) || (e = a.fromValue(e)),
                  a.fromBits(
                    this.low & e.low,
                    this.high & e.high,
                    this.unsigned
                  )
                );
              }),
              (a.prototype.or = function (e) {
                return (
                  a.isLong(e) || (e = a.fromValue(e)),
                  a.fromBits(
                    this.low | e.low,
                    this.high | e.high,
                    this.unsigned
                  )
                );
              }),
              (a.prototype.xor = function (e) {
                return (
                  a.isLong(e) || (e = a.fromValue(e)),
                  a.fromBits(
                    this.low ^ e.low,
                    this.high ^ e.high,
                    this.unsigned
                  )
                );
              }),
              (a.prototype.shiftLeft = function (e) {
                return (
                  a.isLong(e) && (e = e.toInt()),
                  0 == (e &= 63)
                    ? this
                    : e < 32
                    ? a.fromBits(
                        this.low << e,
                        (this.high << e) | (this.low >>> (32 - e)),
                        this.unsigned
                      )
                    : a.fromBits(0, this.low << (e - 32), this.unsigned)
                );
              }),
              (a.prototype.shiftRight = function (e) {
                return (
                  a.isLong(e) && (e = e.toInt()),
                  0 == (e &= 63)
                    ? this
                    : e < 32
                    ? a.fromBits(
                        (this.low >>> e) | (this.high << (32 - e)),
                        this.high >> e,
                        this.unsigned
                      )
                    : a.fromBits(
                        this.high >> (e - 32),
                        this.high >= 0 ? 0 : -1,
                        this.unsigned
                      )
                );
              }),
              (a.prototype.shiftRightUnsigned = function (e) {
                if ((a.isLong(e) && (e = e.toInt()), 0 === (e &= 63)))
                  return this;
                var t = this.high;
                if (e < 32) {
                  var r = this.low;
                  return a.fromBits(
                    (r >>> e) | (t << (32 - e)),
                    t >>> e,
                    this.unsigned
                  );
                }
                return a.fromBits(
                  32 === e ? t : t >>> (e - 32),
                  0,
                  this.unsigned
                );
              }),
              (a.prototype.toSigned = function () {
                return this.unsigned ? new a(this.low, this.high, !1) : this;
              }),
              (a.prototype.toUnsigned = function () {
                return this.unsigned ? this : new a(this.low, this.high, !0);
              }),
              e && "object" == typeof t && t
                ? (e.exports = a)
                : void 0 ===
                    (n = function () {
                      return a;
                    }.call(t, r, t, e)) || (e.exports = n);
          })();
      } };
