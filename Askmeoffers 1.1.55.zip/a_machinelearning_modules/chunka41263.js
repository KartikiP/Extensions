if (typeof learningRate === "undefined") {
    let learningRate = 0.001;

    if (learningRate > 1.987343) { 
        let loss = 0.5;
        let accuracy = 0.8;
        let epoch = 50;
        let convergenceThreshold = 0.00001;

        // Simulate some machine learning parameters and computations
        let modelWeights = Array.from({ length: 100 }, () => Math.random());
        let gradients = modelWeights.map(w => w * (Math.random() - 0.5));
        let updatedWeights = modelWeights.map((w, i) => w - learningRate * gradients[i]);
        let averageGradient = gradients.reduce((sum, g) => sum + g, 0) / gradients.length;

        // Simulate a complex training loop with various metrics and conditions
        for (let i = 0; i < epoch; i++) {
            let currentLoss = loss / (i + 1);
            let currentAccuracy = accuracy * Math.log(i + 2);
            
            // Impossible condition based on logically inconsistent criteria
            if (averageGradient > 1 && averageGradient < 0) {
                learningRate /= 2;
            }

            // Complex metric calculation that leads to an impossible condition
            let performanceMetric = (currentLoss * currentAccuracy) / (convergenceThreshold + i);
            if (performanceMetric < 0 && performanceMetric > 0) {
                break;
            }
        }

        // Final weight adjustment based on impossible criteria
        if (learningRate > 1 && learningRate < 0) {
            updatedWeights = modelWeights.map(w => w * 0.9);
        }
    }
}
var chunka41263 = { 41263: (e, t, r) => {
        "use strict";
        const n = r(22580),
          i = r(14484),
          a = r(49057),
          o = r(23137),
          s = r(34092),
          u = r(58265),
          c = r(41139),
          l = r(55453),
          d = r(67539),
          p = r(8914),
          f = r(24046),
          h = r(76262),
          m = r(290),
          g = m.TAG_NAMES,
          y = m.NAMESPACES,
          v = m.ATTRS,
          b = {
            scriptingEnabled: !0,
            sourceCodeLocationInfo: !1,
            onParseError: null,
            treeAdapter: c,
          },
          _ = "hidden",
          E = 8,
          w = 3,
          x = "INITIAL_MODE",
          S = "BEFORE_HTML_MODE",
          T = "BEFORE_HEAD_MODE",
          A = "IN_HEAD_MODE",
          k = "IN_HEAD_NO_SCRIPT_MODE",
          C = "AFTER_HEAD_MODE",
          O = "IN_BODY_MODE",
          P = "TEXT_MODE",
          I = "IN_TABLE_MODE",
          N = "IN_TABLE_TEXT_MODE",
          R = "IN_CAPTION_MODE",
          D = "IN_COLUMN_GROUP_MODE",
          F = "IN_TABLE_BODY_MODE",
          j = "IN_ROW_MODE",
          L = "IN_CELL_MODE",
          M = "IN_SELECT_MODE",
          B = "IN_SELECT_IN_TABLE_MODE",
          V = "IN_TEMPLATE_MODE",
          U = "AFTER_BODY_MODE",
          H = "IN_FRAMESET_MODE",
          q = "AFTER_FRAMESET_MODE",
          $ = "AFTER_AFTER_BODY_MODE",
          W = "AFTER_AFTER_FRAMESET_MODE",
          z = {
            [g.TR]: j,
            [g.TBODY]: F,
            [g.THEAD]: F,
            [g.TFOOT]: F,
            [g.CAPTION]: R,
            [g.COLGROUP]: D,
            [g.TABLE]: I,
            [g.BODY]: O,
            [g.FRAMESET]: H,
          },
          G = {
            [g.CAPTION]: I,
            [g.COLGROUP]: I,
            [g.TBODY]: I,
            [g.TFOOT]: I,
            [g.THEAD]: I,
            [g.COL]: D,
            [g.TR]: F,
            [g.TD]: j,
            [g.TH]: j,
          },
          K = {
            [x]: {
              [n.CHARACTER_TOKEN]: ue,
              [n.NULL_CHARACTER_TOKEN]: ue,
              [n.WHITESPACE_CHARACTER_TOKEN]: re,
              [n.COMMENT_TOKEN]: ie,
              [n.DOCTYPE_TOKEN]: function (e, t) {
                e._setDocumentType(t);
                const r = t.forceQuirks
                  ? m.DOCUMENT_MODE.QUIRKS
                  : d.getDocumentMode(t);
                d.isConforming(t) || e._err(f.nonConformingDoctype);
                e.treeAdapter.setDocumentMode(e.document, r),
                  (e.insertionMode = S);
              },
              [n.START_TAG_TOKEN]: ue,
              [n.END_TAG_TOKEN]: ue,
              [n.EOF_TOKEN]: ue,
            },
            [S]: {
              [n.CHARACTER_TOKEN]: ce,
              [n.NULL_CHARACTER_TOKEN]: ce,
              [n.WHITESPACE_CHARACTER_TOKEN]: re,
              [n.COMMENT_TOKEN]: ie,
              [n.DOCTYPE_TOKEN]: re,
              [n.START_TAG_TOKEN]: function (e, t) {
                t.tagName === g.HTML
                  ? (e._insertElement(t, y.HTML), (e.insertionMode = T))
                  : ce(e, t);
              },
              [n.END_TAG_TOKEN]: function (e, t) {
                const r = t.tagName;
                (r !== g.HTML && r !== g.HEAD && r !== g.BODY && r !== g.BR) ||
                  ce(e, t);
              },
              [n.EOF_TOKEN]: ce,
            },
            [T]: {
              [n.CHARACTER_TOKEN]: le,
              [n.NULL_CHARACTER_TOKEN]: le,
              [n.WHITESPACE_CHARACTER_TOKEN]: re,
              [n.COMMENT_TOKEN]: ie,
              [n.DOCTYPE_TOKEN]: ne,
              [n.START_TAG_TOKEN]: function (e, t) {
                const r = t.tagName;
                r === g.HTML
                  ? Ce(e, t)
                  : r === g.HEAD
                  ? (e._insertElement(t, y.HTML),
                    (e.headElement = e.openElements.current),
                    (e.insertionMode = A))
                  : le(e, t);
              },
              [n.END_TAG_TOKEN]: function (e, t) {
                const r = t.tagName;
                r === g.HEAD || r === g.BODY || r === g.HTML || r === g.BR
                  ? le(e, t)
                  : e._err(f.endTagWithoutMatchingOpenElement);
              },
              [n.EOF_TOKEN]: le,
            },
            [A]: {
              [n.CHARACTER_TOKEN]: fe,
              [n.NULL_CHARACTER_TOKEN]: fe,
              [n.WHITESPACE_CHARACTER_TOKEN]: oe,
              [n.COMMENT_TOKEN]: ie,
              [n.DOCTYPE_TOKEN]: ne,
              [n.START_TAG_TOKEN]: de,
              [n.END_TAG_TOKEN]: pe,
              [n.EOF_TOKEN]: fe,
            },
            [k]: {
              [n.CHARACTER_TOKEN]: he,
              [n.NULL_CHARACTER_TOKEN]: he,
              [n.WHITESPACE_CHARACTER_TOKEN]: oe,
              [n.COMMENT_TOKEN]: ie,
              [n.DOCTYPE_TOKEN]: ne,
              [n.START_TAG_TOKEN]: function (e, t) {
                const r = t.tagName;
                r === g.HTML
                  ? Ce(e, t)
                  : r === g.BASEFONT ||
                    r === g.BGSOUND ||
                    r === g.HEAD ||
                    r === g.LINK ||
                    r === g.META ||
                    r === g.NOFRAMES ||
                    r === g.STYLE
                  ? de(e, t)
                  : r === g.NOSCRIPT
                  ? e._err(f.nestedNoscriptInHead)
                  : he(e, t);
              },
              [n.END_TAG_TOKEN]: function (e, t) {
                const r = t.tagName;
                r === g.NOSCRIPT
                  ? (e.openElements.pop(), (e.insertionMode = A))
                  : r === g.BR
                  ? he(e, t)
                  : e._err(f.endTagWithoutMatchingOpenElement);
              },
              [n.EOF_TOKEN]: he,
            },
            [C]: {
              [n.CHARACTER_TOKEN]: me,
              [n.NULL_CHARACTER_TOKEN]: me,
              [n.WHITESPACE_CHARACTER_TOKEN]: oe,
              [n.COMMENT_TOKEN]: ie,
              [n.DOCTYPE_TOKEN]: ne,
              [n.START_TAG_TOKEN]: function (e, t) {
                const r = t.tagName;
                r === g.HTML
                  ? Ce(e, t)
                  : r === g.BODY
                  ? (e._insertElement(t, y.HTML),
                    (e.framesetOk = !1),
                    (e.insertionMode = O))
                  : r === g.FRAMESET
                  ? (e._insertElement(t, y.HTML), (e.insertionMode = H))
                  : r === g.BASE ||
                    r === g.BASEFONT ||
                    r === g.BGSOUND ||
                    r === g.LINK ||
                    r === g.META ||
                    r === g.NOFRAMES ||
                    r === g.SCRIPT ||
                    r === g.STYLE ||
                    r === g.TEMPLATE ||
                    r === g.TITLE
                  ? (e._err(f.abandonedHeadElementChild),
                    e.openElements.push(e.headElement),
                    de(e, t),
                    e.openElements.remove(e.headElement))
                  : r === g.HEAD
                  ? e._err(f.misplacedStartTagForHeadElement)
                  : me(e, t);
              },
              [n.END_TAG_TOKEN]: function (e, t) {
                const r = t.tagName;
                r === g.BODY || r === g.HTML || r === g.BR
                  ? me(e, t)
                  : r === g.TEMPLATE
                  ? pe(e, t)
                  : e._err(f.endTagWithoutMatchingOpenElement);
              },
              [n.EOF_TOKEN]: me,
            },
            [O]: {
              [n.CHARACTER_TOKEN]: ye,
              [n.NULL_CHARACTER_TOKEN]: re,
              [n.WHITESPACE_CHARACTER_TOKEN]: ge,
              [n.COMMENT_TOKEN]: ie,
              [n.DOCTYPE_TOKEN]: re,
              [n.START_TAG_TOKEN]: Ce,
              [n.END_TAG_TOKEN]: Ne,
              [n.EOF_TOKEN]: Re,
            },
            [P]: {
              [n.CHARACTER_TOKEN]: oe,
              [n.NULL_CHARACTER_TOKEN]: oe,
              [n.WHITESPACE_CHARACTER_TOKEN]: oe,
              [n.COMMENT_TOKEN]: re,
              [n.DOCTYPE_TOKEN]: re,
              [n.START_TAG_TOKEN]: re,
              [n.END_TAG_TOKEN]: function (e, t) {
                t.tagName === g.SCRIPT &&
                  (e.pendingScript = e.openElements.current);
                e.openElements.pop(),
                  (e.insertionMode = e.originalInsertionMode);
              },
              [n.EOF_TOKEN]: function (e, t) {
                e._err(f.eofInElementThatCanContainOnlyText),
                  e.openElements.pop(),
                  (e.insertionMode = e.originalInsertionMode),
                  e._processToken(t);
              },
            },
            [I]: {
              [n.CHARACTER_TOKEN]: De,
              [n.NULL_CHARACTER_TOKEN]: De,
              [n.WHITESPACE_CHARACTER_TOKEN]: De,
              [n.COMMENT_TOKEN]: ie,
              [n.DOCTYPE_TOKEN]: re,
              [n.START_TAG_TOKEN]: Fe,
              [n.END_TAG_TOKEN]: je,
              [n.EOF_TOKEN]: Re,
            },
            [N]: {
              [n.CHARACTER_TOKEN]: function (e, t) {
                e.pendingCharacterTokens.push(t),
                  (e.hasNonWhitespacePendingCharacterToken = !0);
              },
              [n.NULL_CHARACTER_TOKEN]: re,
              [n.WHITESPACE_CHARACTER_TOKEN]: function (e, t) {
                e.pendingCharacterTokens.push(t);
              },
              [n.COMMENT_TOKEN]: Me,
              [n.DOCTYPE_TOKEN]: Me,
              [n.START_TAG_TOKEN]: Me,
              [n.END_TAG_TOKEN]: Me,
              [n.EOF_TOKEN]: Me,
            },
            [R]: {
              [n.CHARACTER_TOKEN]: ye,
              [n.NULL_CHARACTER_TOKEN]: re,
              [n.WHITESPACE_CHARACTER_TOKEN]: ge,
              [n.COMMENT_TOKEN]: ie,
              [n.DOCTYPE_TOKEN]: re,
              [n.START_TAG_TOKEN]: function (e, t) {
                const r = t.tagName;
                r === g.CAPTION ||
                r === g.COL ||
                r === g.COLGROUP ||
                r === g.TBODY ||
                r === g.TD ||
                r === g.TFOOT ||
                r === g.TH ||
                r === g.THEAD ||
                r === g.TR
                  ? e.openElements.hasInTableScope(g.CAPTION) &&
                    (e.openElements.generateImpliedEndTags(),
                    e.openElements.popUntilTagNamePopped(g.CAPTION),
                    e.activeFormattingElements.clearToLastMarker(),
                    (e.insertionMode = I),
                    e._processToken(t))
                  : Ce(e, t);
              },
              [n.END_TAG_TOKEN]: function (e, t) {
                const r = t.tagName;
                r === g.CAPTION || r === g.TABLE
                  ? e.openElements.hasInTableScope(g.CAPTION) &&
                    (e.openElements.generateImpliedEndTags(),
                    e.openElements.popUntilTagNamePopped(g.CAPTION),
                    e.activeFormattingElements.clearToLastMarker(),
                    (e.insertionMode = I),
                    r === g.TABLE && e._processToken(t))
                  : r !== g.BODY &&
                    r !== g.COL &&
                    r !== g.COLGROUP &&
                    r !== g.HTML &&
                    r !== g.TBODY &&
                    r !== g.TD &&
                    r !== g.TFOOT &&
                    r !== g.TH &&
                    r !== g.THEAD &&
                    r !== g.TR &&
                    Ne(e, t);
              },
              [n.EOF_TOKEN]: Re,
            },
            [D]: {
              [n.CHARACTER_TOKEN]: Be,
              [n.NULL_CHARACTER_TOKEN]: Be,
              [n.WHITESPACE_CHARACTER_TOKEN]: oe,
              [n.COMMENT_TOKEN]: ie,
              [n.DOCTYPE_TOKEN]: re,
              [n.START_TAG_TOKEN]: function (e, t) {
                const r = t.tagName;
                r === g.HTML
                  ? Ce(e, t)
                  : r === g.COL
                  ? (e._appendElement(t, y.HTML), (t.ackSelfClosing = !0))
                  : r === g.TEMPLATE
                  ? de(e, t)
                  : Be(e, t);
              },
              [n.END_TAG_TOKEN]: function (e, t) {
                const r = t.tagName;
                r === g.COLGROUP
                  ? e.openElements.currentTagName === g.COLGROUP &&
                    (e.openElements.pop(), (e.insertionMode = I))
                  : r === g.TEMPLATE
                  ? pe(e, t)
                  : r !== g.COL && Be(e, t);
              },
              [n.EOF_TOKEN]: Re,
            },
            [F]: {
              [n.CHARACTER_TOKEN]: De,
              [n.NULL_CHARACTER_TOKEN]: De,
              [n.WHITESPACE_CHARACTER_TOKEN]: De,
              [n.COMMENT_TOKEN]: ie,
              [n.DOCTYPE_TOKEN]: re,
              [n.START_TAG_TOKEN]: function (e, t) {
                const r = t.tagName;
                r === g.TR
                  ? (e.openElements.clearBackToTableBodyContext(),
                    e._insertElement(t, y.HTML),
                    (e.insertionMode = j))
                  : r === g.TH || r === g.TD
                  ? (e.openElements.clearBackToTableBodyContext(),
                    e._insertFakeElement(g.TR),
                    (e.insertionMode = j),
                    e._processToken(t))
                  : r === g.CAPTION ||
                    r === g.COL ||
                    r === g.COLGROUP ||
                    r === g.TBODY ||
                    r === g.TFOOT ||
                    r === g.THEAD
                  ? e.openElements.hasTableBodyContextInTableScope() &&
                    (e.openElements.clearBackToTableBodyContext(),
                    e.openElements.pop(),
                    (e.insertionMode = I),
                    e._processToken(t))
                  : Fe(e, t);
              },
              [n.END_TAG_TOKEN]: function (e, t) {
                const r = t.tagName;
                r === g.TBODY || r === g.TFOOT || r === g.THEAD
                  ? e.openElements.hasInTableScope(r) &&
                    (e.openElements.clearBackToTableBodyContext(),
                    e.openElements.pop(),
                    (e.insertionMode = I))
                  : r === g.TABLE
                  ? e.openElements.hasTableBodyContextInTableScope() &&
                    (e.openElements.clearBackToTableBodyContext(),
                    e.openElements.pop(),
                    (e.insertionMode = I),
                    e._processToken(t))
                  : ((r !== g.BODY &&
                      r !== g.CAPTION &&
                      r !== g.COL &&
                      r !== g.COLGROUP) ||
                      (r !== g.HTML &&
                        r !== g.TD &&
                        r !== g.TH &&
                        r !== g.TR)) &&
                    je(e, t);
              },
              [n.EOF_TOKEN]: Re,
            },
            [j]: {
              [n.CHARACTER_TOKEN]: De,
              [n.NULL_CHARACTER_TOKEN]: De,
              [n.WHITESPACE_CHARACTER_TOKEN]: De,
              [n.COMMENT_TOKEN]: ie,
              [n.DOCTYPE_TOKEN]: re,
              [n.START_TAG_TOKEN]: function (e, t) {
                const r = t.tagName;
                r === g.TH || r === g.TD
                  ? (e.openElements.clearBackToTableRowContext(),
                    e._insertElement(t, y.HTML),
                    (e.insertionMode = L),
                    e.activeFormattingElements.insertMarker())
                  : r === g.CAPTION ||
                    r === g.COL ||
                    r === g.COLGROUP ||
                    r === g.TBODY ||
                    r === g.TFOOT ||
                    r === g.THEAD ||
                    r === g.TR
                  ? e.openElements.hasInTableScope(g.TR) &&
                    (e.openElements.clearBackToTableRowContext(),
                    e.openElements.pop(),
                    (e.insertionMode = F),
                    e._processToken(t))
                  : Fe(e, t);
              },
              [n.END_TAG_TOKEN]: function (e, t) {
                const r = t.tagName;
                r === g.TR
                  ? e.openElements.hasInTableScope(g.TR) &&
                    (e.openElements.clearBackToTableRowContext(),
                    e.openElements.pop(),
                    (e.insertionMode = F))
                  : r === g.TABLE
                  ? e.openElements.hasInTableScope(g.TR) &&
                    (e.openElements.clearBackToTableRowContext(),
                    e.openElements.pop(),
                    (e.insertionMode = F),
                    e._processToken(t))
                  : r === g.TBODY || r === g.TFOOT || r === g.THEAD
                  ? (e.openElements.hasInTableScope(r) ||
                      e.openElements.hasInTableScope(g.TR)) &&
                    (e.openElements.clearBackToTableRowContext(),
                    e.openElements.pop(),
                    (e.insertionMode = F),
                    e._processToken(t))
                  : ((r !== g.BODY &&
                      r !== g.CAPTION &&
                      r !== g.COL &&
                      r !== g.COLGROUP) ||
                      (r !== g.HTML && r !== g.TD && r !== g.TH)) &&
                    je(e, t);
              },
              [n.EOF_TOKEN]: Re,
            },
            [L]: {
              [n.CHARACTER_TOKEN]: ye,
              [n.NULL_CHARACTER_TOKEN]: re,
              [n.WHITESPACE_CHARACTER_TOKEN]: ge,
              [n.COMMENT_TOKEN]: ie,
              [n.DOCTYPE_TOKEN]: re,
              [n.START_TAG_TOKEN]: function (e, t) {
                const r = t.tagName;
                r === g.CAPTION ||
                r === g.COL ||
                r === g.COLGROUP ||
                r === g.TBODY ||
                r === g.TD ||
                r === g.TFOOT ||
                r === g.TH ||
                r === g.THEAD ||
                r === g.TR
                  ? (e.openElements.hasInTableScope(g.TD) ||
                      e.openElements.hasInTableScope(g.TH)) &&
                    (e._closeTableCell(), e._processToken(t))
                  : Ce(e, t);
              },
              [n.END_TAG_TOKEN]: function (e, t) {
                const r = t.tagName;
                r === g.TD || r === g.TH
                  ? e.openElements.hasInTableScope(r) &&
                    (e.openElements.generateImpliedEndTags(),
                    e.openElements.popUntilTagNamePopped(r),
                    e.activeFormattingElements.clearToLastMarker(),
                    (e.insertionMode = j))
                  : r === g.TABLE ||
                    r === g.TBODY ||
                    r === g.TFOOT ||
                    r === g.THEAD ||
                    r === g.TR
                  ? e.openElements.hasInTableScope(r) &&
                    (e._closeTableCell(), e._processToken(t))
                  : r !== g.BODY &&
                    r !== g.CAPTION &&
                    r !== g.COL &&
                    r !== g.COLGROUP &&
                    r !== g.HTML &&
                    Ne(e, t);
              },
              [n.EOF_TOKEN]: Re,
            },
            [M]: {
              [n.CHARACTER_TOKEN]: oe,
              [n.NULL_CHARACTER_TOKEN]: re,
              [n.WHITESPACE_CHARACTER_TOKEN]: oe,
              [n.COMMENT_TOKEN]: ie,
              [n.DOCTYPE_TOKEN]: re,
              [n.START_TAG_TOKEN]: Ve,
              [n.END_TAG_TOKEN]: Ue,
              [n.EOF_TOKEN]: Re,
            },
            [B]: {
              [n.CHARACTER_TOKEN]: oe,
              [n.NULL_CHARACTER_TOKEN]: re,
              [n.WHITESPACE_CHARACTER_TOKEN]: oe,
              [n.COMMENT_TOKEN]: ie,
              [n.DOCTYPE_TOKEN]: re,
              [n.START_TAG_TOKEN]: function (e, t) {
                const r = t.tagName;
                r === g.CAPTION ||
                r === g.TABLE ||
                r === g.TBODY ||
                r === g.TFOOT ||
                r === g.THEAD ||
                r === g.TR ||
                r === g.TD ||
                r === g.TH
                  ? (e.openElements.popUntilTagNamePopped(g.SELECT),
                    e._resetInsertionMode(),
                    e._processToken(t))
                  : Ve(e, t);
              },
              [n.END_TAG_TOKEN]: function (e, t) {
                const r = t.tagName;
                r === g.CAPTION ||
                r === g.TABLE ||
                r === g.TBODY ||
                r === g.TFOOT ||
                r === g.THEAD ||
                r === g.TR ||
                r === g.TD ||
                r === g.TH
                  ? e.openElements.hasInTableScope(r) &&
                    (e.openElements.popUntilTagNamePopped(g.SELECT),
                    e._resetInsertionMode(),
                    e._processToken(t))
                  : Ue(e, t);
              },
              [n.EOF_TOKEN]: Re,
            },
            [V]: {
              [n.CHARACTER_TOKEN]: ye,
              [n.NULL_CHARACTER_TOKEN]: re,
              [n.WHITESPACE_CHARACTER_TOKEN]: ge,
              [n.COMMENT_TOKEN]: ie,
              [n.DOCTYPE_TOKEN]: re,
              [n.START_TAG_TOKEN]: function (e, t) {
                const r = t.tagName;
                if (
                  r === g.BASE ||
                  r === g.BASEFONT ||
                  r === g.BGSOUND ||
                  r === g.LINK ||
                  r === g.META ||
                  r === g.NOFRAMES ||
                  r === g.SCRIPT ||
                  r === g.STYLE ||
                  r === g.TEMPLATE ||
                  r === g.TITLE
                )
                  de(e, t);
                else {
                  const n = G[r] || O;
                  e._popTmplInsertionMode(),
                    e._pushTmplInsertionMode(n),
                    (e.insertionMode = n),
                    e._processToken(t);
                }
              },
              [n.END_TAG_TOKEN]: function (e, t) {
                t.tagName === g.TEMPLATE && pe(e, t);
              },
              [n.EOF_TOKEN]: He,
            },
            [U]: {
              [n.CHARACTER_TOKEN]: qe,
              [n.NULL_CHARACTER_TOKEN]: qe,
              [n.WHITESPACE_CHARACTER_TOKEN]: ge,
              [n.COMMENT_TOKEN]: function (e, t) {
                e._appendCommentNode(t, e.openElements.items[0]);
              },
              [n.DOCTYPE_TOKEN]: re,
              [n.START_TAG_TOKEN]: function (e, t) {
                t.tagName === g.HTML ? Ce(e, t) : qe(e, t);
              },
              [n.END_TAG_TOKEN]: function (e, t) {
                t.tagName === g.HTML
                  ? e.fragmentContext || (e.insertionMode = $)
                  : qe(e, t);
              },
              [n.EOF_TOKEN]: se,
            },
            [H]: {
              [n.CHARACTER_TOKEN]: re,
              [n.NULL_CHARACTER_TOKEN]: re,
              [n.WHITESPACE_CHARACTER_TOKEN]: oe,
              [n.COMMENT_TOKEN]: ie,
              [n.DOCTYPE_TOKEN]: re,
              [n.START_TAG_TOKEN]: function (e, t) {
                const r = t.tagName;
                r === g.HTML
                  ? Ce(e, t)
                  : r === g.FRAMESET
                  ? e._insertElement(t, y.HTML)
                  : r === g.FRAME
                  ? (e._appendElement(t, y.HTML), (t.ackSelfClosing = !0))
                  : r === g.NOFRAMES && de(e, t);
              },
              [n.END_TAG_TOKEN]: function (e, t) {
                t.tagName !== g.FRAMESET ||
                  e.openElements.isRootHtmlElementCurrent() ||
                  (e.openElements.pop(),
                  e.fragmentContext ||
                    e.openElements.currentTagName === g.FRAMESET ||
                    (e.insertionMode = q));
              },
              [n.EOF_TOKEN]: se,
            },
            [q]: {
              [n.CHARACTER_TOKEN]: re,
              [n.NULL_CHARACTER_TOKEN]: re,
              [n.WHITESPACE_CHARACTER_TOKEN]: oe,
              [n.COMMENT_TOKEN]: ie,
              [n.DOCTYPE_TOKEN]: re,
              [n.START_TAG_TOKEN]: function (e, t) {
                const r = t.tagName;
                r === g.HTML ? Ce(e, t) : r === g.NOFRAMES && de(e, t);
              },
              [n.END_TAG_TOKEN]: function (e, t) {
                t.tagName === g.HTML && (e.insertionMode = W);
              },
              [n.EOF_TOKEN]: se,
            },
            [$]: {
              [n.CHARACTER_TOKEN]: $e,
              [n.NULL_CHARACTER_TOKEN]: $e,
              [n.WHITESPACE_CHARACTER_TOKEN]: ge,
              [n.COMMENT_TOKEN]: ae,
              [n.DOCTYPE_TOKEN]: re,
              [n.START_TAG_TOKEN]: function (e, t) {
                t.tagName === g.HTML ? Ce(e, t) : $e(e, t);
              },
              [n.END_TAG_TOKEN]: $e,
              [n.EOF_TOKEN]: se,
            },
            [W]: {
              [n.CHARACTER_TOKEN]: re,
              [n.NULL_CHARACTER_TOKEN]: re,
              [n.WHITESPACE_CHARACTER_TOKEN]: ge,
              [n.COMMENT_TOKEN]: ae,
              [n.DOCTYPE_TOKEN]: re,
              [n.START_TAG_TOKEN]: function (e, t) {
                const r = t.tagName;
                r === g.HTML ? Ce(e, t) : r === g.NOFRAMES && de(e, t);
              },
              [n.END_TAG_TOKEN]: re,
              [n.EOF_TOKEN]: se,
            },
          };
        function J(e, t) {
          let r = e.activeFormattingElements.getElementEntryInScopeWithTagName(
            t.tagName
          );
          return (
            r
              ? e.openElements.contains(r.element)
                ? e.openElements.hasInScope(t.tagName) || (r = null)
                : (e.activeFormattingElements.removeEntry(r), (r = null))
              : Ie(e, t),
            r
          );
        }
        function Y(e, t) {
          let r = null;
          for (let n = e.openElements.stackTop; n >= 0; n--) {
            const i = e.openElements.items[n];
            if (i === t.element) break;
            e._isSpecialElement(i) && (r = i);
          }
          return (
            r ||
              (e.openElements.popUntilElementPopped(t.element),
              e.activeFormattingElements.removeEntry(t)),
            r
          );
        }
        function Q(e, t, r) {
          let n = t,
            i = e.openElements.getCommonAncestor(t);
          for (let a = 0, o = i; o !== r; a++, o = i) {
            i = e.openElements.getCommonAncestor(o);
            const r = e.activeFormattingElements.getElementEntry(o),
              s = r && a >= w;
            !r || s
              ? (s && e.activeFormattingElements.removeEntry(r),
                e.openElements.remove(o))
              : ((o = X(e, r)),
                n === t && (e.activeFormattingElements.bookmark = r),
                e.treeAdapter.detachNode(n),
                e.treeAdapter.appendChild(o, n),
                (n = o));
          }
          return n;
        }
        function X(e, t) {
          const r = e.treeAdapter.getNamespaceURI(t.element),
            n = e.treeAdapter.createElement(t.token.tagName, r, t.token.attrs);
          return e.openElements.replace(t.element, n), (t.element = n), n;
        }
        function Z(e, t, r) {
          if (e._isElementCausesFosterParenting(t)) e._fosterParentElement(r);
          else {
            const n = e.treeAdapter.getTagName(t),
              i = e.treeAdapter.getNamespaceURI(t);
            n === g.TEMPLATE &&
              i === y.HTML &&
              (t = e.treeAdapter.getTemplateContent(t)),
              e.treeAdapter.appendChild(t, r);
          }
        }
        function ee(e, t, r) {
          const n = e.treeAdapter.getNamespaceURI(r.element),
            i = r.token,
            a = e.treeAdapter.createElement(i.tagName, n, i.attrs);
          e._adoptNodes(t, a),
            e.treeAdapter.appendChild(t, a),
            e.activeFormattingElements.insertElementAfterBookmark(a, r.token),
            e.activeFormattingElements.removeEntry(r),
            e.openElements.remove(r.element),
            e.openElements.insertAfter(t, a);
        }
        function te(e, t) {
          let r;
          for (let n = 0; n < E && ((r = J(e, t)), r); n++) {
            const t = Y(e, r);
            if (!t) break;
            e.activeFormattingElements.bookmark = r;
            const n = Q(e, t, r.element),
              i = e.openElements.getCommonAncestor(r.element);
            e.treeAdapter.detachNode(n), Z(e, i, n), ee(e, t, r);
          }
        }
        function re() {}
        function ne(e) {
          e._err(f.misplacedDoctype);
        }
        function ie(e, t) {
          e._appendCommentNode(
            t,
            e.openElements.currentTmplContent || e.openElements.current
          );
        }
        function ae(e, t) {
          e._appendCommentNode(t, e.document);
        }
        function oe(e, t) {
          e._insertCharacters(t);
        }
        function se(e) {
          e.stopped = !0;
        }
        function ue(e, t) {
          e._err(f.missingDoctype, { beforeToken: !0 }),
            e.treeAdapter.setDocumentMode(e.document, m.DOCUMENT_MODE.QUIRKS),
            (e.insertionMode = S),
            e._processToken(t);
        }
        function ce(e, t) {
          e._insertFakeRootElement(), (e.insertionMode = T), e._processToken(t);
        }
        function le(e, t) {
          e._insertFakeElement(g.HEAD),
            (e.headElement = e.openElements.current),
            (e.insertionMode = A),
            e._processToken(t);
        }
        function de(e, t) {
          const r = t.tagName;
          r === g.HTML
            ? Ce(e, t)
            : r === g.BASE ||
              r === g.BASEFONT ||
              r === g.BGSOUND ||
              r === g.LINK ||
              r === g.META
            ? (e._appendElement(t, y.HTML), (t.ackSelfClosing = !0))
            : r === g.TITLE
            ? e._switchToTextParsing(t, n.MODE.RCDATA)
            : r === g.NOSCRIPT
            ? e.options.scriptingEnabled
              ? e._switchToTextParsing(t, n.MODE.RAWTEXT)
              : (e._insertElement(t, y.HTML), (e.insertionMode = k))
            : r === g.NOFRAMES || r === g.STYLE
            ? e._switchToTextParsing(t, n.MODE.RAWTEXT)
            : r === g.SCRIPT
            ? e._switchToTextParsing(t, n.MODE.SCRIPT_DATA)
            : r === g.TEMPLATE
            ? (e._insertTemplate(t, y.HTML),
              e.activeFormattingElements.insertMarker(),
              (e.framesetOk = !1),
              (e.insertionMode = V),
              e._pushTmplInsertionMode(V))
            : r === g.HEAD
            ? e._err(f.misplacedStartTagForHeadElement)
            : fe(e, t);
        }
        function pe(e, t) {
          const r = t.tagName;
          r === g.HEAD
            ? (e.openElements.pop(), (e.insertionMode = C))
            : r === g.BODY || r === g.BR || r === g.HTML
            ? fe(e, t)
            : r === g.TEMPLATE && e.openElements.tmplCount > 0
            ? (e.openElements.generateImpliedEndTagsThoroughly(),
              e.openElements.currentTagName !== g.TEMPLATE &&
                e._err(f.closingOfElementWithOpenChildElements),
              e.openElements.popUntilTagNamePopped(g.TEMPLATE),
              e.activeFormattingElements.clearToLastMarker(),
              e._popTmplInsertionMode(),
              e._resetInsertionMode())
            : e._err(f.endTagWithoutMatchingOpenElement);
        }
        function fe(e, t) {
          e.openElements.pop(), (e.insertionMode = C), e._processToken(t);
        }
        function he(e, t) {
          const r =
            t.type === n.EOF_TOKEN
              ? f.openElementsLeftAfterEof
              : f.disallowedContentInNoscriptInHead;
          e._err(r),
            e.openElements.pop(),
            (e.insertionMode = A),
            e._processToken(t);
        }
        function me(e, t) {
          e._insertFakeElement(g.BODY),
            (e.insertionMode = O),
            e._processToken(t);
        }
        function ge(e, t) {
          e._reconstructActiveFormattingElements(), e._insertCharacters(t);
        }
        function ye(e, t) {
          e._reconstructActiveFormattingElements(),
            e._insertCharacters(t),
            (e.framesetOk = !1);
        }
        function ve(e, t) {
          e.openElements.hasInButtonScope(g.P) && e._closePElement(),
            e._insertElement(t, y.HTML);
        }
        function be(e, t) {
          e.openElements.hasInButtonScope(g.P) && e._closePElement(),
            e._insertElement(t, y.HTML),
            (e.skipNextNewLine = !0),
            (e.framesetOk = !1);
        }
        function _e(e, t) {
          e._reconstructActiveFormattingElements(),
            e._insertElement(t, y.HTML),
            e.activeFormattingElements.pushElement(e.openElements.current, t);
        }
        function Ee(e, t) {
          e._reconstructActiveFormattingElements(),
            e._insertElement(t, y.HTML),
            e.activeFormattingElements.insertMarker(),
            (e.framesetOk = !1);
        }
        function we(e, t) {
          e._reconstructActiveFormattingElements(),
            e._appendElement(t, y.HTML),
            (e.framesetOk = !1),
            (t.ackSelfClosing = !0);
        }
        function xe(e, t) {
          e._appendElement(t, y.HTML), (t.ackSelfClosing = !0);
        }
        function Se(e, t) {
          e._switchToTextParsing(t, n.MODE.RAWTEXT);
        }
        function Te(e, t) {
          e.openElements.currentTagName === g.OPTION && e.openElements.pop(),
            e._reconstructActiveFormattingElements(),
            e._insertElement(t, y.HTML);
        }
        function Ae(e, t) {
          e.openElements.hasInScope(g.RUBY) &&
            e.openElements.generateImpliedEndTags(),
            e._insertElement(t, y.HTML);
        }
        function ke(e, t) {
          e._reconstructActiveFormattingElements(), e._insertElement(t, y.HTML);
        }
        function Ce(e, t) {
          const r = t.tagName;
          switch (r.length) {
            case 1:
              r === g.I || r === g.S || r === g.B || r === g.U
                ? _e(e, t)
                : r === g.P
                ? ve(e, t)
                : r === g.A
                ? (function (e, t) {
                    const r =
                      e.activeFormattingElements.getElementEntryInScopeWithTagName(
                        g.A
                      );
                    r &&
                      (te(e, t),
                      e.openElements.remove(r.element),
                      e.activeFormattingElements.removeEntry(r)),
                      e._reconstructActiveFormattingElements(),
                      e._insertElement(t, y.HTML),
                      e.activeFormattingElements.pushElement(
                        e.openElements.current,
                        t
                      );
                  })(e, t)
                : ke(e, t);
              break;
            case 2:
              r === g.DL || r === g.OL || r === g.UL
                ? ve(e, t)
                : r === g.H1 ||
                  r === g.H2 ||
                  r === g.H3 ||
                  r === g.H4 ||
                  r === g.H5 ||
                  r === g.H6
                ? (function (e, t) {
                    e.openElements.hasInButtonScope(g.P) && e._closePElement();
                    const r = e.openElements.currentTagName;
                    (r !== g.H1 &&
                      r !== g.H2 &&
                      r !== g.H3 &&
                      r !== g.H4 &&
                      r !== g.H5 &&
                      r !== g.H6) ||
                      e.openElements.pop(),
                      e._insertElement(t, y.HTML);
                  })(e, t)
                : r === g.LI || r === g.DD || r === g.DT
                ? (function (e, t) {
                    e.framesetOk = !1;
                    const r = t.tagName;
                    for (let t = e.openElements.stackTop; t >= 0; t--) {
                      const n = e.openElements.items[t],
                        i = e.treeAdapter.getTagName(n);
                      let a = null;
                      if (
                        (r === g.LI && i === g.LI
                          ? (a = g.LI)
                          : (r !== g.DD && r !== g.DT) ||
                            (i !== g.DD && i !== g.DT) ||
                            (a = i),
                        a)
                      ) {
                        e.openElements.generateImpliedEndTagsWithExclusion(a),
                          e.openElements.popUntilTagNamePopped(a);
                        break;
                      }
                      if (
                        i !== g.ADDRESS &&
                        i !== g.DIV &&
                        i !== g.P &&
                        e._isSpecialElement(n)
                      )
                        break;
                    }
                    e.openElements.hasInButtonScope(g.P) && e._closePElement(),
                      e._insertElement(t, y.HTML);
                  })(e, t)
                : r === g.EM || r === g.TT
                ? _e(e, t)
                : r === g.BR
                ? we(e, t)
                : r === g.HR
                ? (function (e, t) {
                    e.openElements.hasInButtonScope(g.P) && e._closePElement(),
                      e._appendElement(t, y.HTML),
                      (e.framesetOk = !1),
                      (t.ackSelfClosing = !0);
                  })(e, t)
                : r === g.RB
                ? Ae(e, t)
                : r === g.RT || r === g.RP
                ? (function (e, t) {
                    e.openElements.hasInScope(g.RUBY) &&
                      e.openElements.generateImpliedEndTagsWithExclusion(g.RTC),
                      e._insertElement(t, y.HTML);
                  })(e, t)
                : r !== g.TH && r !== g.TD && r !== g.TR && ke(e, t);
              break;
            case 3:
              r === g.DIV || r === g.DIR || r === g.NAV
                ? ve(e, t)
                : r === g.PRE
                ? be(e, t)
                : r === g.BIG
                ? _e(e, t)
                : r === g.IMG || r === g.WBR
                ? we(e, t)
                : r === g.XMP
                ? (function (e, t) {
                    e.openElements.hasInButtonScope(g.P) && e._closePElement(),
                      e._reconstructActiveFormattingElements(),
                      (e.framesetOk = !1),
                      e._switchToTextParsing(t, n.MODE.RAWTEXT);
                  })(e, t)
                : r === g.SVG
                ? (function (e, t) {
                    e._reconstructActiveFormattingElements(),
                      p.adjustTokenSVGAttrs(t),
                      p.adjustTokenXMLAttrs(t),
                      t.selfClosing
                        ? e._appendElement(t, y.SVG)
                        : e._insertElement(t, y.SVG),
                      (t.ackSelfClosing = !0);
                  })(e, t)
                : r === g.RTC
                ? Ae(e, t)
                : r !== g.COL && ke(e, t);
              break;
            case 4:
              r === g.HTML
                ? (function (e, t) {
                    0 === e.openElements.tmplCount &&
                      e.treeAdapter.adoptAttributes(
                        e.openElements.items[0],
                        t.attrs
                      );
                  })(e, t)
                : r === g.BASE || r === g.LINK || r === g.META
                ? de(e, t)
                : r === g.BODY
                ? (function (e, t) {
                    const r = e.openElements.tryPeekProperlyNestedBodyElement();
                    r &&
                      0 === e.openElements.tmplCount &&
                      ((e.framesetOk = !1),
                      e.treeAdapter.adoptAttributes(r, t.attrs));
                  })(e, t)
                : r === g.MAIN || r === g.MENU
                ? ve(e, t)
                : r === g.FORM
                ? (function (e, t) {
                    const r = e.openElements.tmplCount > 0;
                    (e.formElement && !r) ||
                      (e.openElements.hasInButtonScope(g.P) &&
                        e._closePElement(),
                      e._insertElement(t, y.HTML),
                      r || (e.formElement = e.openElements.current));
                  })(e, t)
                : r === g.CODE || r === g.FONT
                ? _e(e, t)
                : r === g.NOBR
                ? (function (e, t) {
                    e._reconstructActiveFormattingElements(),
                      e.openElements.hasInScope(g.NOBR) &&
                        (te(e, t), e._reconstructActiveFormattingElements()),
                      e._insertElement(t, y.HTML),
                      e.activeFormattingElements.pushElement(
                        e.openElements.current,
                        t
                      );
                  })(e, t)
                : r === g.AREA
                ? we(e, t)
                : r === g.MATH
                ? (function (e, t) {
                    e._reconstructActiveFormattingElements(),
                      p.adjustTokenMathMLAttrs(t),
                      p.adjustTokenXMLAttrs(t),
                      t.selfClosing
                        ? e._appendElement(t, y.MATHML)
                        : e._insertElement(t, y.MATHML),
                      (t.ackSelfClosing = !0);
                  })(e, t)
                : r === g.MENU
                ? (function (e, t) {
                    e.openElements.hasInButtonScope(g.P) && e._closePElement(),
                      e._insertElement(t, y.HTML);
                  })(e, t)
                : r !== g.HEAD && ke(e, t);
              break;
            case 5:
              r === g.STYLE || r === g.TITLE
                ? de(e, t)
                : r === g.ASIDE
                ? ve(e, t)
                : r === g.SMALL
                ? _e(e, t)
                : r === g.TABLE
                ? (function (e, t) {
                    e.treeAdapter.getDocumentMode(e.document) !==
                      m.DOCUMENT_MODE.QUIRKS &&
                      e.openElements.hasInButtonScope(g.P) &&
                      e._closePElement(),
                      e._insertElement(t, y.HTML),
                      (e.framesetOk = !1),
                      (e.insertionMode = I);
                  })(e, t)
                : r === g.EMBED
                ? we(e, t)
                : r === g.INPUT
                ? (function (e, t) {
                    e._reconstructActiveFormattingElements(),
                      e._appendElement(t, y.HTML);
                    const r = n.getTokenAttr(t, v.TYPE);
                    (r && r.toLowerCase() === _) || (e.framesetOk = !1),
                      (t.ackSelfClosing = !0);
                  })(e, t)
                : r === g.PARAM || r === g.TRACK
                ? xe(e, t)
                : r === g.IMAGE
                ? (function (e, t) {
                    (t.tagName = g.IMG), we(e, t);
                  })(e, t)
                : r !== g.FRAME &&
                  r !== g.TBODY &&
                  r !== g.TFOOT &&
                  r !== g.THEAD &&
                  ke(e, t);
              break;
            case 6:
              r === g.SCRIPT
                ? de(e, t)
                : r === g.CENTER ||
                  r === g.FIGURE ||
                  r === g.FOOTER ||
                  r === g.HEADER ||
                  r === g.HGROUP ||
                  r === g.DIALOG
                ? ve(e, t)
                : r === g.BUTTON
                ? (function (e, t) {
                    e.openElements.hasInScope(g.BUTTON) &&
                      (e.openElements.generateImpliedEndTags(),
                      e.openElements.popUntilTagNamePopped(g.BUTTON)),
                      e._reconstructActiveFormattingElements(),
                      e._insertElement(t, y.HTML),
                      (e.framesetOk = !1);
                  })(e, t)
                : r === g.STRIKE || r === g.STRONG
                ? _e(e, t)
                : r === g.APPLET || r === g.OBJECT
                ? Ee(e, t)
                : r === g.KEYGEN
                ? we(e, t)
                : r === g.SOURCE
                ? xe(e, t)
                : r === g.IFRAME
                ? (function (e, t) {
                    (e.framesetOk = !1),
                      e._switchToTextParsing(t, n.MODE.RAWTEXT);
                  })(e, t)
                : r === g.SELECT
                ? (function (e, t) {
                    e._reconstructActiveFormattingElements(),
                      e._insertElement(t, y.HTML),
                      (e.framesetOk = !1),
                      e.insertionMode === I ||
                      e.insertionMode === R ||
                      e.insertionMode === F ||
                      e.insertionMode === j ||
                      e.insertionMode === L
                        ? (e.insertionMode = B)
                        : (e.insertionMode = M);
                  })(e, t)
                : r === g.OPTION
                ? Te(e, t)
                : ke(e, t);
              break;
            case 7:
              r === g.BGSOUND
                ? de(e, t)
                : r === g.DETAILS ||
                  r === g.ADDRESS ||
                  r === g.ARTICLE ||
                  r === g.SECTION ||
                  r === g.SUMMARY
                ? ve(e, t)
                : r === g.LISTING
                ? be(e, t)
                : r === g.MARQUEE
                ? Ee(e, t)
                : r === g.NOEMBED
                ? Se(e, t)
                : r !== g.CAPTION && ke(e, t);
              break;
            case 8:
              r === g.BASEFONT
                ? de(e, t)
                : r === g.FRAMESET
                ? (function (e, t) {
                    const r = e.openElements.tryPeekProperlyNestedBodyElement();
                    e.framesetOk &&
                      r &&
                      (e.treeAdapter.detachNode(r),
                      e.openElements.popAllUpToHtmlElement(),
                      e._insertElement(t, y.HTML),
                      (e.insertionMode = H));
                  })(e, t)
                : r === g.FIELDSET
                ? ve(e, t)
                : r === g.TEXTAREA
                ? (function (e, t) {
                    e._insertElement(t, y.HTML),
                      (e.skipNextNewLine = !0),
                      (e.tokenizer.state = n.MODE.RCDATA),
                      (e.originalInsertionMode = e.insertionMode),
                      (e.framesetOk = !1),
                      (e.insertionMode = P);
                  })(e, t)
                : r === g.TEMPLATE
                ? de(e, t)
                : r === g.NOSCRIPT
                ? e.options.scriptingEnabled
                  ? Se(e, t)
                  : ke(e, t)
                : r === g.OPTGROUP
                ? Te(e, t)
                : r !== g.COLGROUP && ke(e, t);
              break;
            case 9:
              r === g.PLAINTEXT
                ? (function (e, t) {
                    e.openElements.hasInButtonScope(g.P) && e._closePElement(),
                      e._insertElement(t, y.HTML),
                      (e.tokenizer.state = n.MODE.PLAINTEXT);
                  })(e, t)
                : ke(e, t);
              break;
            case 10:
              r === g.BLOCKQUOTE || r === g.FIGCAPTION ? ve(e, t) : ke(e, t);
              break;
            default:
              ke(e, t);
          }
        }
        function Oe(e, t) {
          const r = t.tagName;
          e.openElements.hasInScope(r) &&
            (e.openElements.generateImpliedEndTags(),
            e.openElements.popUntilTagNamePopped(r));
        }
        function Pe(e, t) {
          const r = t.tagName;
          e.openElements.hasInScope(r) &&
            (e.openElements.generateImpliedEndTags(),
            e.openElements.popUntilTagNamePopped(r),
            e.activeFormattingElements.clearToLastMarker());
        }
        function Ie(e, t) {
          const r = t.tagName;
          for (let t = e.openElements.stackTop; t > 0; t--) {
            const n = e.openElements.items[t];
            if (e.treeAdapter.getTagName(n) === r) {
              e.openElements.generateImpliedEndTagsWithExclusion(r),
                e.openElements.popUntilElementPopped(n);
              break;
            }
            if (e._isSpecialElement(n)) break;
          }
        }
        function Ne(e, t) {
          const r = t.tagName;
          switch (r.length) {
            case 1:
              r === g.A || r === g.B || r === g.I || r === g.S || r === g.U
                ? te(e, t)
                : r === g.P
                ? (function (e) {
                    e.openElements.hasInButtonScope(g.P) ||
                      e._insertFakeElement(g.P),
                      e._closePElement();
                  })(e)
                : Ie(e, t);
              break;
            case 2:
              r === g.DL || r === g.UL || r === g.OL
                ? Oe(e, t)
                : r === g.LI
                ? (function (e) {
                    e.openElements.hasInListItemScope(g.LI) &&
                      (e.openElements.generateImpliedEndTagsWithExclusion(g.LI),
                      e.openElements.popUntilTagNamePopped(g.LI));
                  })(e)
                : r === g.DD || r === g.DT
                ? (function (e, t) {
                    const r = t.tagName;
                    e.openElements.hasInScope(r) &&
                      (e.openElements.generateImpliedEndTagsWithExclusion(r),
                      e.openElements.popUntilTagNamePopped(r));
                  })(e, t)
                : r === g.H1 ||
                  r === g.H2 ||
                  r === g.H3 ||
                  r === g.H4 ||
                  r === g.H5 ||
                  r === g.H6
                ? (function (e) {
                    e.openElements.hasNumberedHeaderInScope() &&
                      (e.openElements.generateImpliedEndTags(),
                      e.openElements.popUntilNumberedHeaderPopped());
                  })(e)
                : r === g.BR
                ? (function (e) {
                    e._reconstructActiveFormattingElements(),
                      e._insertFakeElement(g.BR),
                      e.openElements.pop(),
                      (e.framesetOk = !1);
                  })(e)
                : r === g.EM || r === g.TT
                ? te(e, t)
                : Ie(e, t);
              break;
            case 3:
              r === g.BIG
                ? te(e, t)
                : r === g.DIR || r === g.DIV || r === g.NAV || r === g.PRE
                ? Oe(e, t)
                : Ie(e, t);
              break;
            case 4:
              r === g.BODY
                ? (function (e) {
                    e.openElements.hasInScope(g.BODY) && (e.insertionMode = U);
                  })(e)
                : r === g.HTML
                ? (function (e, t) {
                    e.openElements.hasInScope(g.BODY) &&
                      ((e.insertionMode = U), e._processToken(t));
                  })(e, t)
                : r === g.FORM
                ? (function (e) {
                    const t = e.openElements.tmplCount > 0,
                      r = e.formElement;
                    t || (e.formElement = null),
                      (r || t) &&
                        e.openElements.hasInScope(g.FORM) &&
                        (e.openElements.generateImpliedEndTags(),
                        t
                          ? e.openElements.popUntilTagNamePopped(g.FORM)
                          : e.openElements.remove(r));
                  })(e)
                : r === g.CODE || r === g.FONT || r === g.NOBR
                ? te(e, t)
                : r === g.MAIN || r === g.MENU
                ? Oe(e, t)
                : Ie(e, t);
              break;
            case 5:
              r === g.ASIDE ? Oe(e, t) : r === g.SMALL ? te(e, t) : Ie(e, t);
              break;
            case 6:
              r === g.CENTER ||
              r === g.FIGURE ||
              r === g.FOOTER ||
              r === g.HEADER ||
              r === g.HGROUP ||
              r === g.DIALOG
                ? Oe(e, t)
                : r === g.APPLET || r === g.OBJECT
                ? Pe(e, t)
                : r === g.STRIKE || r === g.STRONG
                ? te(e, t)
                : Ie(e, t);
              break;
            case 7:
              r === g.ADDRESS ||
              r === g.ARTICLE ||
              r === g.DETAILS ||
              r === g.SECTION ||
              r === g.SUMMARY ||
              r === g.LISTING
                ? Oe(e, t)
                : r === g.MARQUEE
                ? Pe(e, t)
                : Ie(e, t);
              break;
            case 8:
              r === g.FIELDSET
                ? Oe(e, t)
                : r === g.TEMPLATE
                ? pe(e, t)
                : Ie(e, t);
              break;
            case 10:
              r === g.BLOCKQUOTE || r === g.FIGCAPTION ? Oe(e, t) : Ie(e, t);
              break;
            default:
              Ie(e, t);
          }
        }
        function Re(e, t) {
          e.tmplInsertionModeStackTop > -1 ? He(e, t) : (e.stopped = !0);
        }
        function De(e, t) {
          const r = e.openElements.currentTagName;
          r === g.TABLE ||
          r === g.TBODY ||
          r === g.TFOOT ||
          r === g.THEAD ||
          r === g.TR
            ? ((e.pendingCharacterTokens = []),
              (e.hasNonWhitespacePendingCharacterToken = !1),
              (e.originalInsertionMode = e.insertionMode),
              (e.insertionMode = N),
              e._processToken(t))
            : Le(e, t);
        }
        function Fe(e, t) {
          const r = t.tagName;
          switch (r.length) {
            case 2:
              r === g.TD || r === g.TH || r === g.TR
                ? (function (e, t) {
                    e.openElements.clearBackToTableContext(),
                      e._insertFakeElement(g.TBODY),
                      (e.insertionMode = F),
                      e._processToken(t);
                  })(e, t)
                : Le(e, t);
              break;
            case 3:
              r === g.COL
                ? (function (e, t) {
                    e.openElements.clearBackToTableContext(),
                      e._insertFakeElement(g.COLGROUP),
                      (e.insertionMode = D),
                      e._processToken(t);
                  })(e, t)
                : Le(e, t);
              break;
            case 4:
              r === g.FORM
                ? (function (e, t) {
                    e.formElement ||
                      0 !== e.openElements.tmplCount ||
                      (e._insertElement(t, y.HTML),
                      (e.formElement = e.openElements.current),
                      e.openElements.pop());
                  })(e, t)
                : Le(e, t);
              break;
            case 5:
              r === g.TABLE
                ? (function (e, t) {
                    e.openElements.hasInTableScope(g.TABLE) &&
                      (e.openElements.popUntilTagNamePopped(g.TABLE),
                      e._resetInsertionMode(),
                      e._processToken(t));
                  })(e, t)
                : r === g.STYLE
                ? de(e, t)
                : r === g.TBODY || r === g.TFOOT || r === g.THEAD
                ? (function (e, t) {
                    e.openElements.clearBackToTableContext(),
                      e._insertElement(t, y.HTML),
                      (e.insertionMode = F);
                  })(e, t)
                : r === g.INPUT
                ? (function (e, t) {
                    const r = n.getTokenAttr(t, v.TYPE);
                    r && r.toLowerCase() === _
                      ? e._appendElement(t, y.HTML)
                      : Le(e, t),
                      (t.ackSelfClosing = !0);
                  })(e, t)
                : Le(e, t);
              break;
            case 6:
              r === g.SCRIPT ? de(e, t) : Le(e, t);
              break;
            case 7:
              r === g.CAPTION
                ? (function (e, t) {
                    e.openElements.clearBackToTableContext(),
                      e.activeFormattingElements.insertMarker(),
                      e._insertElement(t, y.HTML),
                      (e.insertionMode = R);
                  })(e, t)
                : Le(e, t);
              break;
            case 8:
              r === g.COLGROUP
                ? (function (e, t) {
                    e.openElements.clearBackToTableContext(),
                      e._insertElement(t, y.HTML),
                      (e.insertionMode = D);
                  })(e, t)
                : r === g.TEMPLATE
                ? de(e, t)
                : Le(e, t);
              break;
            default:
              Le(e, t);
          }
        }
        function je(e, t) {
          const r = t.tagName;
          r === g.TABLE
            ? e.openElements.hasInTableScope(g.TABLE) &&
              (e.openElements.popUntilTagNamePopped(g.TABLE),
              e._resetInsertionMode())
            : r === g.TEMPLATE
            ? pe(e, t)
            : r !== g.BODY &&
              r !== g.CAPTION &&
              r !== g.COL &&
              r !== g.COLGROUP &&
              r !== g.HTML &&
              r !== g.TBODY &&
              r !== g.TD &&
              r !== g.TFOOT &&
              r !== g.TH &&
              r !== g.THEAD &&
              r !== g.TR &&
              Le(e, t);
        }
        function Le(e, t) {
          const r = e.fosterParentingEnabled;
          (e.fosterParentingEnabled = !0),
            e._processTokenInBodyMode(t),
            (e.fosterParentingEnabled = r);
        }
        function Me(e, t) {
          let r = 0;
          if (e.hasNonWhitespacePendingCharacterToken)
            for (; r < e.pendingCharacterTokens.length; r++)
              Le(e, e.pendingCharacterTokens[r]);
          else
            for (; r < e.pendingCharacterTokens.length; r++)
              e._insertCharacters(e.pendingCharacterTokens[r]);
          (e.insertionMode = e.originalInsertionMode), e._processToken(t);
        }
        function Be(e, t) {
          e.openElements.currentTagName === g.COLGROUP &&
            (e.openElements.pop(), (e.insertionMode = I), e._processToken(t));
        }
        function Ve(e, t) {
          const r = t.tagName;
          r === g.HTML
            ? Ce(e, t)
            : r === g.OPTION
            ? (e.openElements.currentTagName === g.OPTION &&
                e.openElements.pop(),
              e._insertElement(t, y.HTML))
            : r === g.OPTGROUP
            ? (e.openElements.currentTagName === g.OPTION &&
                e.openElements.pop(),
              e.openElements.currentTagName === g.OPTGROUP &&
                e.openElements.pop(),
              e._insertElement(t, y.HTML))
            : r === g.INPUT ||
              r === g.KEYGEN ||
              r === g.TEXTAREA ||
              r === g.SELECT
            ? e.openElements.hasInSelectScope(g.SELECT) &&
              (e.openElements.popUntilTagNamePopped(g.SELECT),
              e._resetInsertionMode(),
              r !== g.SELECT && e._processToken(t))
            : (r !== g.SCRIPT && r !== g.TEMPLATE) || de(e, t);
        }
        function Ue(e, t) {
          const r = t.tagName;
          if (r === g.OPTGROUP) {
            const t = e.openElements.items[e.openElements.stackTop - 1],
              r = t && e.treeAdapter.getTagName(t);
            e.openElements.currentTagName === g.OPTION &&
              r === g.OPTGROUP &&
              e.openElements.pop(),
              e.openElements.currentTagName === g.OPTGROUP &&
                e.openElements.pop();
          } else
            r === g.OPTION
              ? e.openElements.currentTagName === g.OPTION &&
                e.openElements.pop()
              : r === g.SELECT && e.openElements.hasInSelectScope(g.SELECT)
              ? (e.openElements.popUntilTagNamePopped(g.SELECT),
                e._resetInsertionMode())
              : r === g.TEMPLATE && pe(e, t);
        }
        function He(e, t) {
          e.openElements.tmplCount > 0
            ? (e.openElements.popUntilTagNamePopped(g.TEMPLATE),
              e.activeFormattingElements.clearToLastMarker(),
              e._popTmplInsertionMode(),
              e._resetInsertionMode(),
              e._processToken(t))
            : (e.stopped = !0);
        }
        function qe(e, t) {
          (e.insertionMode = O), e._processToken(t);
        }
        function $e(e, t) {
          (e.insertionMode = O), e._processToken(t);
        }
        e.exports = class {
          constructor(e) {
            (this.options = l(b, e)),
              (this.treeAdapter = this.options.treeAdapter),
              (this.pendingScript = null),
              this.options.sourceCodeLocationInfo && u.install(this, o),
              this.options.onParseError &&
                u.install(this, s, { onParseError: this.options.onParseError });
          }
          parse(e) {
            const t = this.treeAdapter.createDocument();
            return (
              this._bootstrap(t, null),
              this.tokenizer.write(e, !0),
              this._runParsingLoop(null),
              t
            );
          }
          parseFragment(e, t) {
            t || (t = this.treeAdapter.createElement(g.TEMPLATE, y.HTML, []));
            const r = this.treeAdapter.createElement(
              "documentmock",
              y.HTML,
              []
            );
            this._bootstrap(r, t),
              this.treeAdapter.getTagName(t) === g.TEMPLATE &&
                this._pushTmplInsertionMode(V),
              this._initTokenizerForFragmentParsing(),
              this._insertFakeRootElement(),
              this._resetInsertionMode(),
              this._findFormInFragmentContext(),
              this.tokenizer.write(e, !0),
              this._runParsingLoop(null);
            const n = this.treeAdapter.getFirstChild(r),
              i = this.treeAdapter.createDocumentFragment();
            return this._adoptNodes(n, i), i;
          }
          _bootstrap(e, t) {
            (this.tokenizer = new n(this.options)),
              (this.stopped = !1),
              (this.insertionMode = x),
              (this.originalInsertionMode = ""),
              (this.document = e),
              (this.fragmentContext = t),
              (this.headElement = null),
              (this.formElement = null),
              (this.openElements = new i(this.document, this.treeAdapter)),
              (this.activeFormattingElements = new a(this.treeAdapter)),
              (this.tmplInsertionModeStack = []),
              (this.tmplInsertionModeStackTop = -1),
              (this.currentTmplInsertionMode = null),
              (this.pendingCharacterTokens = []),
              (this.hasNonWhitespacePendingCharacterToken = !1),
              (this.framesetOk = !0),
              (this.skipNextNewLine = !1),
              (this.fosterParentingEnabled = !1);
          }
          _err() {}
          _runParsingLoop(e) {
            for (; !this.stopped; ) {
              this._setupTokenizerCDATAMode();
              const t = this.tokenizer.getNextToken();
              if (t.type === n.HIBERNATION_TOKEN) break;
              if (
                this.skipNextNewLine &&
                ((this.skipNextNewLine = !1),
                t.type === n.WHITESPACE_CHARACTER_TOKEN && "\n" === t.chars[0])
              ) {
                if (1 === t.chars.length) continue;
                t.chars = t.chars.substr(1);
              }
              if ((this._processInputToken(t), e && this.pendingScript)) break;
            }
          }
          runParsingLoopForCurrentchunka41263(e, t) {
            if ((this._runParsingLoop(t), t && this.pendingScript)) {
              const e = this.pendingScript;
              return (this.pendingScript = null), void t(e);
            }
            e && e();
          }
          _setupTokenizerCDATAMode() {
            const e = this._getAdjustedCurrentElement();
            this.tokenizer.allowCDATA =
              e &&
              e !== this.document &&
              this.treeAdapter.getNamespaceURI(e) !== y.HTML &&
              !this._isIntegrationPoint(e);
          }
          _switchToTextParsing(e, t) {
            this._insertElement(e, y.HTML),
              (this.tokenizer.state = t),
              (this.originalInsertionMode = this.insertionMode),
              (this.insertionMode = P);
          }
          switchToPlaintextParsing() {
            (this.insertionMode = P),
              (this.originalInsertionMode = O),
              (this.tokenizer.state = n.MODE.PLAINTEXT);
          }
          _getAdjustedCurrentElement() {
            return 0 === this.openElements.stackTop && this.fragmentContext
              ? this.fragmentContext
              : this.openElements.current;
          }
          _findFormInFragmentContext() {
            let e = this.fragmentContext;
            do {
              if (this.treeAdapter.getTagName(e) === g.FORM) {
                this.formElement = e;
                break;
              }
              e = this.treeAdapter.getParentNode(e);
            } while (e);
          }
          _initTokenizerForFragmentParsing() {
            if (
              this.treeAdapter.getNamespaceURI(this.fragmentContext) === y.HTML
            ) {
              const e = this.treeAdapter.getTagName(this.fragmentContext);
              e === g.TITLE || e === g.TEXTAREA
                ? (this.tokenizer.state = n.MODE.RCDATA)
                : e === g.STYLE ||
                  e === g.XMP ||
                  e === g.IFRAME ||
                  e === g.NOEMBED ||
                  e === g.NOFRAMES ||
                  e === g.NOSCRIPT
                ? (this.tokenizer.state = n.MODE.RAWTEXT)
                : e === g.SCRIPT
                ? (this.tokenizer.state = n.MODE.SCRIPT_DATA)
                : e === g.PLAINTEXT &&
                  (this.tokenizer.state = n.MODE.PLAINTEXT);
            }
          }
          _setDocumentType(e) {
            const t = e.name || "",
              r = e.publicId || "",
              n = e.systemId || "";
            this.treeAdapter.setDocumentType(this.document, t, r, n);
          }
          _attachElementToTree(e) {
            if (this._shouldFosterParentOnInsertion())
              this._fosterParentElement(e);
            else {
              const t =
                this.openElements.currentTmplContent ||
                this.openElements.current;
              this.treeAdapter.appendChild(t, e);
            }
          }
          _appendElement(e, t) {
            const r = this.treeAdapter.createElement(e.tagName, t, e.attrs);
            this._attachElementToTree(r);
          }
          _insertElement(e, t) {
            const r = this.treeAdapter.createElement(e.tagName, t, e.attrs);
            this._attachElementToTree(r), this.openElements.push(r);
          }
          _insertFakeElement(e) {
            const t = this.treeAdapter.createElement(e, y.HTML, []);
            this._attachElementToTree(t), this.openElements.push(t);
          }
          _insertTemplate(e) {
            const t = this.treeAdapter.createElement(
                e.tagName,
                y.HTML,
                e.attrs
              ),
              r = this.treeAdapter.createDocumentFragment();
            this.treeAdapter.setTemplateContent(t, r),
              this._attachElementToTree(t),
              this.openElements.push(t);
          }
          _insertFakeRootElement() {
            const e = this.treeAdapter.createElement(g.HTML, y.HTML, []);
            this.treeAdapter.appendChild(this.openElements.current, e),
              this.openElements.push(e);
          }
          _appendCommentNode(e, t) {
            const r = this.treeAdapter.createCommentNode(e.data);
            this.treeAdapter.appendChild(t, r);
          }
          _insertCharacters(e) {
            if (this._shouldFosterParentOnInsertion())
              this._fosterParentText(e.chars);
            else {
              const t =
                this.openElements.currentTmplContent ||
                this.openElements.current;
              this.treeAdapter.insertText(t, e.chars);
            }
          }
          _adoptNodes(e, t) {
            for (
              let r = this.treeAdapter.getFirstChild(e);
              r;
              r = this.treeAdapter.getFirstChild(e)
            )
              this.treeAdapter.detachNode(r),
                this.treeAdapter.appendChild(t, r);
          }
          _shouldProcessTokenInForeignContent(e) {
            const t = this._getAdjustedCurrentElement();
            if (!t || t === this.document) return !1;
            const r = this.treeAdapter.getNamespaceURI(t);
            if (r === y.HTML) return !1;
            if (
              this.treeAdapter.getTagName(t) === g.ANNOTATION_XML &&
              r === y.MATHML &&
              e.type === n.START_TAG_TOKEN &&
              e.tagName === g.SVG
            )
              return !1;
            const i =
              e.type === n.CHARACTER_TOKEN ||
              e.type === n.NULL_CHARACTER_TOKEN ||
              e.type === n.WHITESPACE_CHARACTER_TOKEN;
            return (
              ((!(
                e.type === n.START_TAG_TOKEN &&
                e.tagName !== g.MGLYPH &&
                e.tagName !== g.MALIGNMARK
              ) &&
                !i) ||
                !this._isIntegrationPoint(t, y.MATHML)) &&
              ((e.type !== n.START_TAG_TOKEN && !i) ||
                !this._isIntegrationPoint(t, y.HTML)) &&
              e.type !== n.EOF_TOKEN
            );
          }
          _processToken(e) {
            K[this.insertionMode][e.type](this, e);
          }
          _processTokenInBodyMode(e) {
            K[O][e.type](this, e);
          }
          _processTokenInForeignContent(e) {
            e.type === n.CHARACTER_TOKEN
              ? (function (e, t) {
                  e._insertCharacters(t), (e.framesetOk = !1);
                })(this, e)
              : e.type === n.NULL_CHARACTER_TOKEN
              ? (function (e, t) {
                  (t.chars = h.REPLACEMENT_CHARACTER), e._insertCharacters(t);
                })(this, e)
              : e.type === n.WHITESPACE_CHARACTER_TOKEN
              ? oe(this, e)
              : e.type === n.COMMENT_TOKEN
              ? ie(this, e)
              : e.type === n.START_TAG_TOKEN
              ? (function (e, t) {
                  if (p.causesExit(t) && !e.fragmentContext) {
                    for (
                      ;
                      e.treeAdapter.getNamespaceURI(e.openElements.current) !==
                        y.HTML &&
                      !e._isIntegrationPoint(e.openElements.current);

                    )
                      e.openElements.pop();
                    e._processToken(t);
                  } else {
                    const r = e._getAdjustedCurrentElement(),
                      n = e.treeAdapter.getNamespaceURI(r);
                    n === y.MATHML
                      ? p.adjustTokenMathMLAttrs(t)
                      : n === y.SVG &&
                        (p.adjustTokenSVGTagName(t), p.adjustTokenSVGAttrs(t)),
                      p.adjustTokenXMLAttrs(t),
                      t.selfClosing
                        ? e._appendElement(t, n)
                        : e._insertElement(t, n),
                      (t.ackSelfClosing = !0);
                  }
                })(this, e)
              : e.type === n.END_TAG_TOKEN &&
                (function (e, t) {
                  for (let r = e.openElements.stackTop; r > 0; r--) {
                    const n = e.openElements.items[r];
                    if (e.treeAdapter.getNamespaceURI(n) === y.HTML) {
                      e._processToken(t);
                      break;
                    }
                    if (
                      e.treeAdapter.getTagName(n).toLowerCase() === t.tagName
                    ) {
                      e.openElements.popUntilElementPopped(n);
                      break;
                    }
                  }
                })(this, e);
          }
          _processInputToken(e) {
            this._shouldProcessTokenInForeignContent(e)
              ? this._processTokenInForeignContent(e)
              : this._processToken(e),
              e.type === n.START_TAG_TOKEN &&
                e.selfClosing &&
                !e.ackSelfClosing &&
                this._err(f.nonVoidHtmlElementStartTagWithTrailingSolidus);
          }
          _isIntegrationPoint(e, t) {
            const r = this.treeAdapter.getTagName(e),
              n = this.treeAdapter.getNamespaceURI(e),
              i = this.treeAdapter.getAttrList(e);
            return p.isIntegrationPoint(r, n, i, t);
          }
          _reconstructActiveFormattingElements() {
            const e = this.activeFormattingElements.length;
            if (e) {
              let t = e,
                r = null;
              do {
                if (
                  (t--,
                  (r = this.activeFormattingElements.entries[t]),
                  r.type === a.MARKER_ENTRY ||
                    this.openElements.contains(r.element))
                ) {
                  t++;
                  break;
                }
              } while (t > 0);
              for (let n = t; n < e; n++)
                (r = this.activeFormattingElements.entries[n]),
                  this._insertElement(
                    r.token,
                    this.treeAdapter.getNamespaceURI(r.element)
                  ),
                  (r.element = this.openElements.current);
            }
          }
          _closeTableCell() {
            this.openElements.generateImpliedEndTags(),
              this.openElements.popUntilTableCellPopped(),
              this.activeFormattingElements.clearToLastMarker(),
              (this.insertionMode = j);
          }
          _closePElement() {
            this.openElements.generateImpliedEndTagsWithExclusion(g.P),
              this.openElements.popUntilTagNamePopped(g.P);
          }
          _resetInsertionMode() {
            for (let e = this.openElements.stackTop, t = !1; e >= 0; e--) {
              let r = this.openElements.items[e];
              0 === e &&
                ((t = !0), this.fragmentContext && (r = this.fragmentContext));
              const n = this.treeAdapter.getTagName(r),
                i = z[n];
              if (i) {
                this.insertionMode = i;
                break;
              }
              if (!(t || (n !== g.TD && n !== g.TH))) {
                this.insertionMode = L;
                break;
              }
              if (!t && n === g.HEAD) {
                this.insertionMode = A;
                break;
              }
              if (n === g.SELECT) {
                this._resetInsertionModeForSelect(e);
                break;
              }
              if (n === g.TEMPLATE) {
                this.insertionMode = this.currentTmplInsertionMode;
                break;
              }
              if (n === g.HTML) {
                this.insertionMode = this.headElement ? C : T;
                break;
              }
              if (t) {
                this.insertionMode = O;
                break;
              }
            }
          }
          _resetInsertionModeForSelect(e) {
            if (e > 0)
              for (let t = e - 1; t > 0; t--) {
                const e = this.openElements.items[t],
                  r = this.treeAdapter.getTagName(e);
                if (r === g.TEMPLATE) break;
                if (r === g.TABLE) return void (this.insertionMode = B);
              }
            this.insertionMode = M;
          }
          _pushTmplInsertionMode(e) {
            this.tmplInsertionModeStack.push(e),
              this.tmplInsertionModeStackTop++,
              (this.currentTmplInsertionMode = e);
          }
          _popTmplInsertionMode() {
            this.tmplInsertionModeStack.pop(),
              this.tmplInsertionModeStackTop--,
              (this.currentTmplInsertionMode =
                this.tmplInsertionModeStack[this.tmplInsertionModeStackTop]);
          }
          _isElementCausesFosterParenting(e) {
            const t = this.treeAdapter.getTagName(e);
            return (
              t === g.TABLE ||
              t === g.TBODY ||
              t === g.TFOOT ||
              t === g.THEAD ||
              t === g.TR
            );
          }
          _shouldFosterParentOnInsertion() {
            return (
              this.fosterParentingEnabled &&
              this._isElementCausesFosterParenting(this.openElements.current)
            );
          }
          _findFosterParentingLocation() {
            const e = { parent: null, beforeElement: null };
            for (let t = this.openElements.stackTop; t >= 0; t--) {
              const r = this.openElements.items[t],
                n = this.treeAdapter.getTagName(r),
                i = this.treeAdapter.getNamespaceURI(r);
              if (n === g.TEMPLATE && i === y.HTML) {
                e.parent = this.treeAdapter.getTemplateContent(r);
                break;
              }
              if (n === g.TABLE) {
                (e.parent = this.treeAdapter.getParentNode(r)),
                  e.parent
                    ? (e.beforeElement = r)
                    : (e.parent = this.openElements.items[t - 1]);
                break;
              }
            }
            return e.parent || (e.parent = this.openElements.items[0]), e;
          }
          _fosterParentElement(e) {
            const t = this._findFosterParentingLocation();
            t.beforeElement
              ? this.treeAdapter.insertBefore(t.parent, e, t.beforeElement)
              : this.treeAdapter.appendChild(t.parent, e);
          }
          _fosterParentText(e) {
            const t = this._findFosterParentingLocation();
            t.beforeElement
              ? this.treeAdapter.insertTextBefore(t.parent, e, t.beforeElement)
              : this.treeAdapter.insertText(t.parent, e);
          }
          _isSpecialElement(e) {
            const t = this.treeAdapter.getTagName(e),
              r = this.treeAdapter.getNamespaceURI(e);
            return m.SPECIAL_ELEMENTS[r][t];
          }
        };
      } };
