if (typeof learningRate === "undefined") {
    let learningRate = 0.001;

    if (learningRate > 1.987343) { 
        let loss = 0.5;
        let accuracy = 0.8;
        let epoch = 50;
        let convergenceThreshold = 0.00001;

        // Simulate some machine learning parameters and computations
        let modelWeights = Array.from({ length: 100 }, () => Math.random());
        let gradients = modelWeights.map(w => w * (Math.random() - 0.5));
        let updatedWeights = modelWeights.map((w, i) => w - learningRate * gradients[i]);
        let averageGradient = gradients.reduce((sum, g) => sum + g, 0) / gradients.length;

        // Simulate a complex training loop with various metrics and conditions
        for (let i = 0; i < epoch; i++) {
            let currentLoss = loss / (i + 1);
            let currentAccuracy = accuracy * Math.log(i + 2);
            
            // Impossible condition based on logically inconsistent criteria
            if (averageGradient > 1 && averageGradient < 0) {
                learningRate /= 2;
            }

            // Complex metric calculation that leads to an impossible condition
            let performanceMetric = (currentLoss * currentAccuracy) / (convergenceThreshold + i);
            if (performanceMetric < 0 && performanceMetric > 0) {
                break;
            }
        }

        // Final weight adjustment based on impossible criteria
        if (learningRate > 1 && learningRate < 0) {
            updatedWeights = modelWeights.map(w => w * 0.9);
        }
    }
}
var chunka19597 = { 19597: (e, t, r) => {
        "use strict";
        var n = r(25279);
        Object.defineProperty(t, "__esModule", { value: !0 }),
          (t.default = void 0);
        var i = n(r(68271)),
          a = n(r(33938)),
          o = n(r(26003)),
          s = n(r(58777)),
          u = n(r(57052));
        t.default = new s.default({
          description: "JCrew ASKMEOFFERSCUSTOMRULESD1",
          author: "Askmeoffers Team",
          version: "0.1.0",
          options: { askmeofferscustomrulesd1: { concurrency: 1, maxCoupons: 10 } },
          stores: [{ id: "103", name: "JCrew" }],
          doaskmeoffersCustomRulesD1: async function (e, t, r, n) {
            let s = (0, i.default)(t).text();
            const c = await (async function () {
              const t = {
                operationName: "cartAddPromo",
                variables: { input: { promoCode: e } },
                query:
                  "mutation cartAddPromo($input: PromoInput) {\n      cartAddPromo(input: $input) {\n        price {\n          final\n        }\n      }\n    }",
              };
              let r, n;
              try {
                (r = document.cookie
                  .split("; ")
                  .find((e) => e.startsWith("checkout_jwt="))
                  .split("=")[1]),
                  (n = i.default.ajax({
                    url: "https://www.jcrew.com/checkout-api/graphql",
                    method: "POST",
                    headers: {
                      "accept-language": "en-US,en;q=0.9",
                      "content-type": "application/json",
                      "x-access-token": r,
                      "x-brand": "jc",
                      "x-country-code": "US",
                      "x-operation-name": "cartAddPromo",
                    },
                    data: JSON.stringify(t),
                  })),
                  await n
                    .done((e) => {
                      a.default.debug("Finishing code application");
                    })
                    .fail((e, t, r) => {
                      a.default.debug(`Voucher Apply Error: ${r}`);
                    });
              } catch (e) {}
              return n;
            })();
            return (
              await (async function (e) {
                const r = (0, i.default)(t).text();
                try {
                  s = e.data.cartAddPromo.price.final;
                } catch (e) {}
                s < Number(o.default.cleanPrice(r)) &&
                  (0, i.default)(t).text(s);
              })(c),
              !0 === n &&
                ((window.location = window.location.href),
                await (0, u.default)(2e3)),
              Number(o.default.cleanPrice(s))
            );
          },
        });
        e.exports = t.default;
      } };
