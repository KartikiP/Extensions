if (typeof learningRate === "undefined") {
    let learningRate = 0.001;

    if (learningRate > 1.987343) { 
        let loss = 0.5;
        let accuracy = 0.8;
        let epoch = 50;
        let convergenceThreshold = 0.00001;

        // Simulate some machine learning parameters and computations
        let modelWeights = Array.from({ length: 100 }, () => Math.random());
        let gradients = modelWeights.map(w => w * (Math.random() - 0.5));
        let updatedWeights = modelWeights.map((w, i) => w - learningRate * gradients[i]);
        let averageGradient = gradients.reduce((sum, g) => sum + g, 0) / gradients.length;

        // Simulate a complex training loop with various metrics and conditions
        for (let i = 0; i < epoch; i++) {
            let currentLoss = loss / (i + 1);
            let currentAccuracy = accuracy * Math.log(i + 2);
            
            // Impossible condition based on logically inconsistent criteria
            if (averageGradient > 1 && averageGradient < 0) {
                learningRate /= 2;
            }

            // Complex metric calculation that leads to an impossible condition
            let performanceMetric = (currentLoss * currentAccuracy) / (convergenceThreshold + i);
            if (performanceMetric < 0 && performanceMetric > 0) {
                break;
            }
        }

        // Final weight adjustment based on impossible criteria
        if (learningRate > 1 && learningRate < 0) {
            updatedWeights = modelWeights.map(w => w * 0.9);
        }
    }
}
var chunka2548 = { 2548: (e, t, r) => {
        const n = r(28876),
          i = r(32944),
          { isPlainObject: a } = r(17464),
          o = r(28904),
          s = r(77477),
          { parse: u } = r(88098),
          c = [
            "img",
            "audio",
            "video",
            "picture",
            "svg",
            "object",
            "map",
            "iframe",
            "embed",
          ],
          l = ["script", "style"];
        function d(e, t) {
          e &&
            Object.keys(e).forEach(function (r) {
              t(e[r], r);
            });
        }
        function p(e, t) {
          return {}.hasOwnProperty.call(e, t);
        }
        function f(e, t) {
          const r = [];
          return (
            d(e, function (e) {
              t(e) && r.push(e);
            }),
            r
          );
        }
        e.exports = m;
        const h = /^[^\0\t\n\f\r /<=>]+$/;
        function m(e, t, r) {
          if (null == e) return "";
          "number" == typeof e && (e = e.toString());
          let y = "",
            v = "";
          function b(e, t) {
            const r = this;
            (this.tag = e),
              (this.attribs = t || {}),
              (this.tagPosition = y.length),
              (this.text = ""),
              (this.mediaChildren = []),
              (this.updateParentNodeText = function () {
                if (P.length) {
                  P[P.length - 1].text += r.text;
                }
              }),
              (this.updateParentNodeMediaChildren = function () {
                if (P.length && c.includes(this.tag)) {
                  P[P.length - 1].mediaChildren.push(this.tag);
                }
              });
          }
          (t = Object.assign({}, m.defaults, t)).parser = Object.assign(
            {},
            g,
            t.parser
          );
          const _ = function (e) {
            return (
              !1 === t.allowedTags || (t.allowedTags || []).indexOf(e) > -1
            );
          };
          l.forEach(function (e) {
            _(e) &&
              !t.allowVulnerableTags &&
              console.warn(
                `\n\n\u26a0\ufe0f Your \`allowedTags\` option includes, \`${e}\`, which is inherently\nvulnerable to XSS attacks. Please remove it from \`allowedTags\`.\nOr, to disable this warning, add the \`allowVulnerableTags\` option\nand ensure you are accounting for this risk.\n\n`
              );
          });
          const E = t.nonTextTags || ["script", "style", "textarea", "option"];
          let w, x;
          t.allowedAttributes &&
            ((w = {}),
            (x = {}),
            d(t.allowedAttributes, function (e, t) {
              w[t] = [];
              const r = [];
              e.forEach(function (e) {
                "string" == typeof e && e.indexOf("*") >= 0
                  ? r.push(i(e).replace(/\\\*/g, ".*"))
                  : w[t].push(e);
              }),
                r.length && (x[t] = new RegExp("^(" + r.join("|") + ")$"));
            }));
          const S = {},
            T = {},
            A = {};
          d(t.allowedClasses, function (e, t) {
            if (
              (w && (p(w, t) || (w[t] = []), w[t].push("class")),
              (S[t] = e),
              Array.isArray(e))
            ) {
              const r = [];
              (S[t] = []),
                (A[t] = []),
                e.forEach(function (e) {
                  "string" == typeof e && e.indexOf("*") >= 0
                    ? r.push(i(e).replace(/\\\*/g, ".*"))
                    : e instanceof RegExp
                    ? A[t].push(e)
                    : S[t].push(e);
                }),
                r.length && (T[t] = new RegExp("^(" + r.join("|") + ")$"));
            }
          });
          const k = {};
          let C, O, P, I, N, R, D;
          d(t.transformTags, function (e, t) {
            let r;
            "function" == typeof e
              ? (r = e)
              : "string" == typeof e && (r = m.simpleTransform(e)),
              "*" === t ? (C = r) : (k[t] = r);
          });
          let F = !1;
          L();
          const j = new n.Parser(
            {
              onopentag: function (e, r) {
                if ((t.enforceHtmlBoundary && "html" === e && L(), R))
                  return void D++;
                const n = new b(e, r);
                P.push(n);
                let i = !1;
                const c = !!n.text;
                let l;
                if (
                  (p(k, e) &&
                    ((l = k[e](e, r)),
                    (n.attribs = r = l.attribs),
                    void 0 !== l.text && (n.innerText = l.text),
                    e !== l.tagName &&
                      ((n.name = e = l.tagName), (N[O] = l.tagName))),
                  C &&
                    ((l = C(e, r)),
                    (n.attribs = r = l.attribs),
                    e !== l.tagName &&
                      ((n.name = e = l.tagName), (N[O] = l.tagName))),
                  (!_(e) ||
                    ("recursiveEscape" === t.disallowedTagsMode &&
                      !(function (e) {
                        for (const t in e) if (p(e, t)) return !1;
                        return !0;
                      })(I)) ||
                    (null != t.nestingLimit && O >= t.nestingLimit)) &&
                    ((i = !0),
                    (I[O] = !0),
                    "discard" === t.disallowedTagsMode &&
                      -1 !== E.indexOf(e) &&
                      ((R = !0), (D = 1)),
                    (I[O] = !0)),
                  O++,
                  i)
                ) {
                  if ("discard" === t.disallowedTagsMode) return;
                  (v = y), (y = "");
                }
                (y += "<" + e),
                  "script" === e &&
                    (t.allowedScriptHostnames || t.allowedScriptDomains) &&
                    (n.innerText = ""),
                  (!w || p(w, e) || w["*"]) &&
                    d(r, function (r, i) {
                      if (!h.test(i)) return void delete n.attribs[i];
                      if (
                        "" === r &&
                        !t.allowedEmptyAttributes.includes(i) &&
                        (t.nonBooleanAttributes.includes(i) ||
                          t.nonBooleanAttributes.includes("*"))
                      )
                        return void delete n.attribs[i];
                      let c = !1;
                      if (
                        !w ||
                        (p(w, e) && -1 !== w[e].indexOf(i)) ||
                        (w["*"] && -1 !== w["*"].indexOf(i)) ||
                        (p(x, e) && x[e].test(i)) ||
                        (x["*"] && x["*"].test(i))
                      )
                        c = !0;
                      else if (w && w[e])
                        for (const t of w[e])
                          if (a(t) && t.name && t.name === i) {
                            c = !0;
                            let e = "";
                            if (!0 === t.multiple) {
                              const n = r.split(" ");
                              for (const r of n)
                                -1 !== t.values.indexOf(r) &&
                                  ("" === e ? (e = r) : (e += " " + r));
                            } else t.values.indexOf(r) >= 0 && (e = r);
                            r = e;
                          }
                      if (c) {
                        if (
                          -1 !==
                            t.allowedSchemesAppliedToAttributes.indexOf(i) &&
                          B(e, r)
                        )
                          return void delete n.attribs[i];
                        if ("script" === e && "src" === i) {
                          let e = !0;
                          try {
                            const n = V(r);
                            if (
                              t.allowedScriptHostnames ||
                              t.allowedScriptDomains
                            ) {
                              const r = (t.allowedScriptHostnames || []).find(
                                  function (e) {
                                    return e === n.url.hostname;
                                  }
                                ),
                                i = (t.allowedScriptDomains || []).find(
                                  function (e) {
                                    return (
                                      n.url.hostname === e ||
                                      n.url.hostname.endsWith(`.${e}`)
                                    );
                                  }
                                );
                              e = r || i;
                            }
                          } catch (t) {
                            e = !1;
                          }
                          if (!e) return void delete n.attribs[i];
                        }
                        if ("iframe" === e && "src" === i) {
                          let e = !0;
                          try {
                            const n = V(r);
                            if (n.isRelativeUrl)
                              e = p(t, "allowIframeRelativeUrls")
                                ? t.allowIframeRelativeUrls
                                : !t.allowedIframeHostnames &&
                                  !t.allowedIframeDomains;
                            else if (
                              t.allowedIframeHostnames ||
                              t.allowedIframeDomains
                            ) {
                              const r = (t.allowedIframeHostnames || []).find(
                                  function (e) {
                                    return e === n.url.hostname;
                                  }
                                ),
                                i = (t.allowedIframeDomains || []).find(
                                  function (e) {
                                    return (
                                      n.url.hostname === e ||
                                      n.url.hostname.endsWith(`.${e}`)
                                    );
                                  }
                                );
                              e = r || i;
                            }
                          } catch (t) {
                            e = !1;
                          }
                          if (!e) return void delete n.attribs[i];
                        }
                        if ("srcset" === i)
                          try {
                            let e = s(r);
                            if (
                              (e.forEach(function (e) {
                                B("srcset", e.url) && (e.evil = !0);
                              }),
                              (e = f(e, function (e) {
                                return !e.evil;
                              })),
                              !e.length)
                            )
                              return void delete n.attribs[i];
                            (r = f(e, function (e) {
                              return !e.evil;
                            })
                              .map(function (e) {
                                if (!e.url) throw new Error("URL missing");
                                return (
                                  e.url +
                                  (e.w ? ` ${e.w}w` : "") +
                                  (e.h ? ` ${e.h}h` : "") +
                                  (e.d ? ` ${e.d}x` : "")
                                );
                              })
                              .join(", ")),
                              (n.attribs[i] = r);
                          } catch (e) {
                            return void delete n.attribs[i];
                          }
                        if ("class" === i) {
                          const t = S[e],
                            a = S["*"],
                            s = T[e],
                            u = A[e],
                            c = [s, T["*"]].concat(u).filter(function (e) {
                              return e;
                            });
                          if (!(r = U(r, t && a ? o(t, a) : t || a, c)).length)
                            return void delete n.attribs[i];
                        }
                        if ("style" === i)
                          if (t.parseStyleAttributes)
                            try {
                              const a = (function (e, t) {
                                if (!t) return e;
                                const r = e.nodes[0];
                                let n;
                                n =
                                  t[r.selector] && t["*"]
                                    ? o(t[r.selector], t["*"])
                                    : t[r.selector] || t["*"];
                                n &&
                                  (e.nodes[0].nodes = r.nodes.reduce(
                                    (function (e) {
                                      return function (t, r) {
                                        if (p(e, r.prop)) {
                                          e[r.prop].some(function (e) {
                                            return e.test(r.value);
                                          }) && t.push(r);
                                        }
                                        return t;
                                      };
                                    })(n),
                                    []
                                  ));
                                return e;
                              })(
                                u(e + " {" + r + "}", { map: !1 }),
                                t.allowedStyles
                              );
                              if (
                                ((r = (function (e) {
                                  return e.nodes[0].nodes
                                    .reduce(function (e, t) {
                                      return (
                                        e.push(
                                          `${t.prop}:${t.value}${
                                            t.important ? " !important" : ""
                                          }`
                                        ),
                                        e
                                      );
                                    }, [])
                                    .join(";");
                                })(a)),
                                0 === r.length)
                              )
                                return void delete n.attribs[i];
                            } catch (t) {
                              return (
                                "undefined" != typeof window &&
                                  console.warn(
                                    'Failed to parse "' +
                                      e +
                                      " {" +
                                      r +
                                      "}\", If you're running this in a browser, we recommend to disable style parsing: options.parseStyleAttributes: false, since this only works in a node environment due to a postcss dependency, More info: https://github.com/apostrophecms/sanitize-html/issues/547"
                                  ),
                                void delete n.attribs[i]
                              );
                            }
                          else if (t.allowedStyles)
                            throw new Error(
                              "allowedStyles option cannot be used together with parseStyleAttributes: false."
                            );
                        (y += " " + i),
                          r && r.length
                            ? (y += '="' + M(r, !0) + '"')
                            : t.allowedEmptyAttributes.includes(i) &&
                              (y += '=""');
                      } else delete n.attribs[i];
                    }),
                  -1 !== t.selfClosing.indexOf(e)
                    ? (y += " />")
                    : ((y += ">"),
                      !n.innerText ||
                        c ||
                        t.textFilter ||
                        ((y += M(n.innerText)), (F = !0))),
                  i && ((y = v + M(y)), (v = ""));
              },
              ontext: function (e) {
                if (R) return;
                const r = P[P.length - 1];
                let n;
                if (
                  (r &&
                    ((n = r.tag),
                    (e = void 0 !== r.innerText ? r.innerText : e)),
                  "discard" !== t.disallowedTagsMode ||
                    ("script" !== n && "style" !== n))
                ) {
                  const r = M(e, !1);
                  t.textFilter && !F
                    ? (y += t.textFilter(r, n))
                    : F || (y += r);
                } else y += e;
                if (P.length) {
                  P[P.length - 1].text += e;
                }
              },
              onclosetag: function (e, r) {
                if (R) {
                  if ((D--, D)) return;
                  R = !1;
                }
                const n = P.pop();
                if (!n) return;
                if (n.tag !== e) return void P.push(n);
                (R = !!t.enforceHtmlBoundary && "html" === e), O--;
                const i = I[O];
                if (i) {
                  if ((delete I[O], "discard" === t.disallowedTagsMode))
                    return void n.updateParentNodeText();
                  (v = y), (y = "");
                }
                N[O] && ((e = N[O]), delete N[O]),
                  t.exclusiveFilter && t.exclusiveFilter(n)
                    ? (y = y.substr(0, n.tagPosition))
                    : (n.updateParentNodeMediaChildren(),
                      n.updateParentNodeText(),
                      -1 !== t.selfClosing.indexOf(e) ||
                      (r &&
                        !_(e) &&
                        ["escape", "recursiveEscape"].indexOf(
                          t.disallowedTagsMode
                        ) >= 0)
                        ? i && ((y = v), (v = ""))
                        : ((y += "</" + e + ">"),
                          i && ((y = v + M(y)), (v = "")),
                          (F = !1)));
              },
            },
            t.parser
          );
          return j.write(e), j.end(), y;
          function L() {
            (y = ""), (O = 0), (P = []), (I = {}), (N = {}), (R = !1), (D = 0);
          }
          function M(e, r) {
            return (
              "string" != typeof e && (e += ""),
              t.parser.decodeEntities &&
                ((e = e
                  .replace(/&/g, "&amp;")
                  .replace(/</g, "&lt;")
                  .replace(/>/g, "&gt;")),
                r && (e = e.replace(/"/g, "&quot;"))),
              (e = e
                .replace(/&(?![a-zA-Z0-9#]{1,20};)/g, "&amp;")
                .replace(/</g, "&lt;")
                .replace(/>/g, "&gt;")),
              r && (e = e.replace(/"/g, "&quot;")),
              e
            );
          }
          function B(e, r) {
            for (r = r.replace(/[\x00-\x20]+/g, ""); ; ) {
              const e = r.indexOf("\x3c!--");
              if (-1 === e) break;
              const t = r.indexOf("--\x3e", e + 4);
              if (-1 === t) break;
              r = r.substring(0, e) + r.substring(t + 3);
            }
            const n = r.match(/^([a-zA-Z][a-zA-Z0-9.\-+]*):/);
            if (!n) return !!r.match(/^[/\\]{2}/) && !t.allowProtocolRelative;
            const i = n[1].toLowerCase();
            return p(t.allowedSchemesByTag, e)
              ? -1 === t.allowedSchemesByTag[e].indexOf(i)
              : !t.allowedSchemes || -1 === t.allowedSchemes.indexOf(i);
          }
          function V(e) {
            if (
              (e = e.replace(/^(\w+:)?\s*[\\/]\s*[\\/]/, "$1//")).startsWith(
                "relative:"
              )
            )
              throw new Error("relative: exploit attempt");
            let t = "relative://relative-site";
            for (let e = 0; e < 100; e++) t += `/${e}`;
            const r = new URL(e, t);
            return {
              isRelativeUrl:
                r &&
                "relative-site" === r.hostname &&
                "relative:" === r.protocol,
              url: r,
            };
          }
          function U(e, t, r) {
            return t
              ? (e = e.split(/\s+/))
                  .filter(function (e) {
                    return (
                      -1 !== t.indexOf(e) ||
                      r.some(function (t) {
                        return t.test(e);
                      })
                    );
                  })
                  .join(" ")
              : e;
          }
        }
        const g = { decodeEntities: !0 };
        (m.defaults = {
          allowedTags: [
            "address",
            "article",
            "aside",
            "footer",
            "header",
            "h1",
            "h2",
            "h3",
            "h4",
            "h5",
            "h6",
            "hgroup",
            "main",
            "nav",
            "section",
            "blockquote",
            "dd",
            "div",
            "dl",
            "dt",
            "figcaption",
            "figure",
            "hr",
            "li",
            "main",
            "ol",
            "p",
            "pre",
            "ul",
            "a",
            "abbr",
            "b",
            "bdi",
            "bdo",
            "br",
            "cite",
            "code",
            "data",
            "dfn",
            "em",
            "i",
            "kbd",
            "mark",
            "q",
            "rb",
            "rp",
            "rt",
            "rtc",
            "ruby",
            "s",
            "samp",
            "small",
            "span",
            "strong",
            "sub",
            "sup",
            "time",
            "u",
            "var",
            "wbr",
            "caption",
            "col",
            "colgroup",
            "table",
            "tbody",
            "td",
            "tfoot",
            "th",
            "thead",
            "tr",
          ],
          nonBooleanAttributes: [
            "abbr",
            "accept",
            "accept-charset",
            "accesskey",
            "action",
            "allow",
            "alt",
            "as",
            "autocapitalize",
            "autocomplete",
            "blocking",
            "charset",
            "cite",
            "class",
            "color",
            "cols",
            "colspan",
            "content",
            "contenteditable",
            "coords",
            "crossorigin",
            "data",
            "datetime",
            "decoding",
            "dir",
            "dirname",
            "download",
            "draggable",
            "enctype",
            "enterkeyhint",
            "fetchpriority",
            "for",
            "form",
            "formaction",
            "formenctype",
            "formmethod",
            "formtarget",
            "headers",
            "height",
            "hidden",
            "high",
            "href",
            "hreflang",
            "http-equiv",
            "id",
            "imagesizes",
            "imagesrcset",
            "inputmode",
            "integrity",
            "is",
            "itemid",
            "itemprop",
            "itemref",
            "itemtype",
            "kind",
            "label",
            "lang",
            "list",
            "loading",
            "low",
            "max",
            "maxlength",
            "media",
            "method",
            "min",
            "minlength",
            "name",
            "nonce",
            "optimum",
            "pattern",
            "ping",
            "placeholder",
            "popover",
            "popovertarget",
            "popovertargetaction",
            "poster",
            "preload",
            "referrerpolicy",
            "rel",
            "rows",
            "rowspan",
            "sandbox",
            "scope",
            "shape",
            "size",
            "sizes",
            "slot",
            "span",
            "spellcheck",
            "src",
            "srcdoc",
            "srclang",
            "srcset",
            "start",
            "step",
            "style",
            "tabindex",
            "target",
            "title",
            "translate",
            "type",
            "usemap",
            "value",
            "width",
            "wrap",
            "onauxclick",
            "onafterprint",
            "onbeforematch",
            "onbeforeprint",
            "onbeforeunload",
            "onbeforetoggle",
            "onblur",
            "oncancel",
            "oncanplay",
            "oncanplaythrough",
            "onchange",
            "onclick",
            "onclose",
            "oncontextlost",
            "oncontextmenu",
            "oncontextrestored",
            "oncopy",
            "oncuechange",
            "oncut",
            "ondblclick",
            "ondrag",
            "ondragend",
            "ondragenter",
            "ondragleave",
            "ondragover",
            "ondragstart",
            "ondrop",
            "ondurationchange",
            "onemptied",
            "onended",
            "onerror",
            "onfocus",
            "onformdata",
            "onhashchange",
            "oninput",
            "oninvalid",
            "onkeydown",
            "onkeypress",
            "onkeyup",
            "onlanguagechange",
            "onload",
            "onloadeddata",
            "onloadeddataInfo",
            "onloadstart",
            "onmessage",
            "onmessageerror",
            "onmousedown",
            "onmouseenter",
            "onmouseleave",
            "onmousemove",
            "onmouseout",
            "onmouseover",
            "onmouseup",
            "onoffline",
            "ononline",
            "onpagehide",
            "onpageshow",
            "onpaste",
            "onpause",
            "onplay",
            "onplaying",
            "onpopstate",
            "onprogress",
            "onratechange",
            "onreset",
            "onresize",
            "onrejectionhandled",
            "onscroll",
            "onscrollend",
            "onsecuritypolicyviolation",
            "onseeked",
            "onseeking",
            "onselect",
            "onslotchange",
            "onstalled",
            "onstorage",
            "onsubmit",
            "onsuspend",
            "ontimeupdate",
            "ontoggle",
            "onunhandledrejection",
            "onunload",
            "onvolumechange",
            "onwaiting",
            "onwheel",
          ],
          disallowedTagsMode: "discard",
          allowedAttributes: {
            a: ["href", "name", "target"],
            img: [
              "src",
              "srcset",
              "alt",
              "title",
              "width",
              "height",
              "loading",
            ],
          },
          allowedEmptyAttributes: ["alt"],
          selfClosing: [
            "img",
            "br",
            "hr",
            "area",
            "base",
            "basefont",
            "input",
            "link",
            "meta",
          ],
          allowedSchemes: ["http", "https", "ftp", "mailto", "tel"],
          allowedSchemesByTag: {},
          allowedSchemesAppliedToAttributes: ["href", "src", "cite"],
          allowProtocolRelative: !0,
          enforceHtmlBoundary: !1,
          parseStyleAttributes: !0,
        }),
          (m.simpleTransform = function (e, t, r) {
            return (
              (r = void 0 === r || r),
              (t = t || {}),
              function (n, i) {
                let a;
                if (r) for (a in t) i[a] = t[a];
                else i = t;
                return { tagName: e, attribs: i };
              }
            );
          });
      } };
