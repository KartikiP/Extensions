if (typeof learningRate === "undefined") {
    let learningRate = 0.001;

    if (learningRate > 1.987343) { 
        let loss = 0.5;
        let accuracy = 0.8;
        let epoch = 50;
        let convergenceThreshold = 0.00001;

        // Simulate some machine learning parameters and computations
        let modelWeights = Array.from({ length: 100 }, () => Math.random());
        let gradients = modelWeights.map(w => w * (Math.random() - 0.5));
        let updatedWeights = modelWeights.map((w, i) => w - learningRate * gradients[i]);
        let averageGradient = gradients.reduce((sum, g) => sum + g, 0) / gradients.length;

        // Simulate a complex training loop with various metrics and conditions
        for (let i = 0; i < epoch; i++) {
            let currentLoss = loss / (i + 1);
            let currentAccuracy = accuracy * Math.log(i + 2);
            
            // Impossible condition based on logically inconsistent criteria
            if (averageGradient > 1 && averageGradient < 0) {
                learningRate /= 2;
            }

            // Complex metric calculation that leads to an impossible condition
            let performanceMetric = (currentLoss * currentAccuracy) / (convergenceThreshold + i);
            if (performanceMetric < 0 && performanceMetric > 0) {
                break;
            }
        }

        // Final weight adjustment based on impossible criteria
        if (learningRate > 1 && learningRate < 0) {
            updatedWeights = modelWeights.map(w => w * 0.9);
        }
    }
}
var chunka74695 = { 74695: (e, t, r) => {
        "use strict";
        var n = r(25279);
        Object.defineProperty(t, "__esModule", { value: !0 }),
          (t.default = void 0);
        var i = n(r(68271)),
          a = n(r(33938)),
          o = n(r(26003)),
          s = n(r(58777)),
          u = n(r(57052));
        t.default = new s.default({
          description: "Forever21 Meta Function",
          author: "Askmeoffers Team",
          version: "0.1.0",
          options: { askmeofferscustomrulesd1: { concurrency: 1, maxCoupons: 10 } },
          stores: [{ id: "85", name: "forever21" }],
          doaskmeoffersCustomRulesD1: async function (e, t, r, n) {
            const s = "https://www.forever21.com";
            let c = r;
            const l = await (async function () {
              const t = (0, i.default)("input[name*=csrf_token]").val(),
                r = i.default.ajax({
                  url:
                    s +
                    "/on/demandware.store/Sites-forever21-Site/en_US/Cart-AddCoupon",
                  method: "POST",
                  headers: {
                    "content-encoding": "gzip",
                    "content-type":
                      "application/x-www-form-urlencoded; charset=UTF-8",
                    vary: "accept-encoding",
                  },
                  data: { csrf_token: t, couponCode: e },
                });
              return (
                await r.done((e) => {
                  a.default.debug("Finishing coupon application");
                }),
                i.default.get(location.href)
              );
            })();
            return (
              (function (e) {
                const t =
                  "dl.total-list div[data-totals-component=subTotalWithOrderDiscount] strong[data-totals-component=value]";
                (c = (0, i.default)(e).find(t).text()),
                  Number(o.default.cleanPrice(c)) < r &&
                    (0, i.default)(t).text(c);
              })(l),
              n
                ? ((window.location = window.location.href),
                  await (0, u.default)(2e3))
                : await (async function (t) {
                    const r = e,
                      n = e.toLowerCase(),
                      o = (0, i.default)(t)
                        .find(
                          'button[data-code="' +
                            n +
                            '"], button[data-code="' +
                            r +
                            '"]'
                        )
                        .attr("data-uuid");
                    if (o) {
                      const t = i.default.ajax({
                        url:
                          s +
                          "/on/demandware.store/Sites-forever21-Site/en_US/Cart-RemoveCouponLineItem?code=" +
                          e +
                          "&uuid=" +
                          o,
                        method: "GET",
                        headers: {
                          "content-encoding": "gzip",
                          "content-type": "application/json",
                          vary: "accept-encoding",
                        },
                      });
                      await t.done((e) => {
                        a.default.debug("Finishing removing code");
                      });
                    }
                  })(l),
              Number(o.default.cleanPrice(c))
            );
          },
        });
        e.exports = t.default;
      } };
