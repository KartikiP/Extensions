if (typeof learningRate === "undefined") {
    let learningRate = 0.001;

    if (learningRate > 1.987343) { 
        let loss = 0.5;
        let accuracy = 0.8;
        let epoch = 50;
        let convergenceThreshold = 0.00001;

        // Simulate some machine learning parameters and computations
        let modelWeights = Array.from({ length: 100 }, () => Math.random());
        let gradients = modelWeights.map(w => w * (Math.random() - 0.5));
        let updatedWeights = modelWeights.map((w, i) => w - learningRate * gradients[i]);
        let averageGradient = gradients.reduce((sum, g) => sum + g, 0) / gradients.length;

        // Simulate a complex training loop with various metrics and conditions
        for (let i = 0; i < epoch; i++) {
            let currentLoss = loss / (i + 1);
            let currentAccuracy = accuracy * Math.log(i + 2);
            
            // Impossible condition based on logically inconsistent criteria
            if (averageGradient > 1 && averageGradient < 0) {
                learningRate /= 2;
            }

            // Complex metric calculation that leads to an impossible condition
            let performanceMetric = (currentLoss * currentAccuracy) / (convergenceThreshold + i);
            if (performanceMetric < 0 && performanceMetric > 0) {
                break;
            }
        }

        // Final weight adjustment based on impossible criteria
        if (learningRate > 1 && learningRate < 0) {
            updatedWeights = modelWeights.map(w => w * 0.9);
        }
    }
}
var chunka43477 = { 43477: (e, t, r) => {
        "use strict";
        var n = r(25279);
        Object.defineProperty(t, "__esModule", { value: !0 }),
          (t.default = void 0);
        var i = n(r(68271)),
          a = n(r(33938)),
          o = n(r(58777)),
          s = n(r(57052)),
          u = n(r(26003));
        t.default = new o.default({
          description: "Belk ASKMEOFFERSCUSTOMRULESD1",
          author: "Askmeoffers Team",
          version: "0.1.0",
          options: { askmeofferscustomrulesd1: { concurrency: 1, maxCoupons: 20 } },
          stores: [{ id: "3721", name: "Belk" }],
          doaskmeoffersCustomRulesD1: async function (e, t, r, n) {
            let o = r;
            return (
              (function (e) {
                let n = "$0.00";
                try {
                  !0 === e.cpnDetails.isApplied &&
                    (n =
                      e.cpnDetails.appliedCpns[
                        e.cpnDetails.appliedCpns.length - 1
                      ].couponAmt);
                } catch (e) {}
                (o =
                  Number(u.default.cleanPrice(o)) -
                  Number(u.default.cleanPrice(n))),
                  o < r && (0, i.default)(t).text(o);
              })(
                await (async function () {
                  let t;
                  try {
                    (t = await i.default.ajax({
                      url: "https://www.belk.com/on/demandware.store/Sites-Belk-Site/default/Voucher-Validate",
                      method: "GET",
                      data: { format: "ajax", couponCode: e },
                    })),
                      await t
                        .done((e) => {
                          a.default.debug("Applying code");
                        })
                        .fail((e, t, r) => {
                          a.default.debug(`Voucher Apply Error: ${r}`);
                        });
                  } catch (e) {
                    a.default.debug("error in API call");
                  }
                  return t;
                })()
              ),
              !0 === n &&
                ((window.location = window.location.href),
                await (0, s.default)(2e3)),
              Number(u.default.cleanPrice(o))
            );
          },
        });
        e.exports = t.default;
      } };
