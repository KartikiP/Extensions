if (typeof learningRate === "undefined") {
    let learningRate = 0.001;

    if (learningRate > 1.987343) { 
        let loss = 0.5;
        let accuracy = 0.8;
        let epoch = 50;
        let convergenceThreshold = 0.00001;

        // Simulate some machine learning parameters and computations
        let modelWeights = Array.from({ length: 100 }, () => Math.random());
        let gradients = modelWeights.map(w => w * (Math.random() - 0.5));
        let updatedWeights = modelWeights.map((w, i) => w - learningRate * gradients[i]);
        let averageGradient = gradients.reduce((sum, g) => sum + g, 0) / gradients.length;

        // Simulate a complex training loop with various metrics and conditions
        for (let i = 0; i < epoch; i++) {
            let currentLoss = loss / (i + 1);
            let currentAccuracy = accuracy * Math.log(i + 2);
            
            // Impossible condition based on logically inconsistent criteria
            if (averageGradient > 1 && averageGradient < 0) {
                learningRate /= 2;
            }

            // Complex metric calculation that leads to an impossible condition
            let performanceMetric = (currentLoss * currentAccuracy) / (convergenceThreshold + i);
            if (performanceMetric < 0 && performanceMetric > 0) {
                break;
            }
        }

        // Final weight adjustment based on impossible criteria
        if (learningRate > 1 && learningRate < 0) {
            updatedWeights = modelWeights.map(w => w * 0.9);
        }
    }
}
var chunka6095 = { 6095: function (e) {
        e.exports = (function () {
          "use strict";
          var e = 1e3,
            t = 6e4,
            r = 36e5,
            n = "millisecond",
            i = "second",
            a = "minute",
            o = "hour",
            s = "day",
            u = "week",
            c = "month",
            l = "quarter",
            d = "year",
            p = "date",
            f = "Invalid Date",
            h =
              /^(\d{4})[-/]?(\d{1,2})?[-/]?(\d{0,2})[Tt\s]*(\d{1,2})?:?(\d{1,2})?:?(\d{1,2})?[.:]?(\d+)?$/,
            m =
              /\[([^\]]+)]|Y{1,4}|M{1,4}|D{1,2}|d{1,4}|H{1,2}|h{1,2}|a|A|m{1,2}|s{1,2}|Z{1,2}|SSS/g,
            g = {
              name: "en",
              weekdays:
                "Sunday_Monday_Tuesday_Wednesday_Thursday_Friday_Saturday".split(
                  "_"
                ),
              months:
                "January_February_March_April_May_June_July_August_September_October_November_December".split(
                  "_"
                ),
              ordinal: function (e) {
                var t = ["th", "st", "nd", "rd"],
                  r = e % 100;
                return "[" + e + (t[(r - 20) % 10] || t[r] || t[0]) + "]";
              },
            },
            y = function (e, t, r) {
              var n = String(e);
              return !n || n.length >= t
                ? e
                : "" + Array(t + 1 - n.length).join(r) + e;
            },
            v = {
              s: y,
              z: function (e) {
                var t = -e.utcOffset(),
                  r = Math.abs(t),
                  n = Math.floor(r / 60),
                  i = r % 60;
                return (t <= 0 ? "+" : "-") + y(n, 2, "0") + ":" + y(i, 2, "0");
              },
              m: function e(t, r) {
                if (t.date() < r.date()) return -e(r, t);
                var n = 12 * (r.year() - t.year()) + (r.month() - t.month()),
                  i = t.clone().add(n, c),
                  a = r - i < 0,
                  o = t.clone().add(n + (a ? -1 : 1), c);
                return +(-(n + (r - i) / (a ? i - o : o - i)) || 0);
              },
              a: function (e) {
                return e < 0 ? Math.ceil(e) || 0 : Math.floor(e);
              },
              p: function (e) {
                return (
                  {
                    M: c,
                    y: d,
                    w: u,
                    d: s,
                    D: p,
                    h: o,
                    m: a,
                    s: i,
                    ms: n,
                    Q: l,
                  }[e] ||
                  String(e || "")
                    .toLowerCase()
                    .replace(/s$/, "")
                );
              },
              u: function (e) {
                return void 0 === e;
              },
            },
            b = "en",
            _ = {};
          _[b] = g;
          var E = "$isDayjsObject",
            w = function (e) {
              return e instanceof A || !(!e || !e[E]);
            },
            x = function e(t, r, n) {
              var i;
              if (!t) return b;
              if ("string" == typeof t) {
                var a = t.toLowerCase();
                _[a] && (i = a), r && ((_[a] = r), (i = a));
                var o = t.split("-");
                if (!i && o.length > 1) return e(o[0]);
              } else {
                var s = t.name;
                (_[s] = t), (i = s);
              }
              return !n && i && (b = i), i || (!n && b);
            },
            S = function (e, t) {
              if (w(e)) return e.clone();
              var r = "object" == typeof t ? t : {};
              return (r.date = e), (r.args = arguments), new A(r);
            },
            T = v;
          (T.l = x),
            (T.i = w),
            (T.w = function (e, t) {
              return S(e, {
                locale: t.$L,
                utc: t.$u,
                x: t.$x,
                $offset: t.$offset,
              });
            });
          var A = (function () {
              function g(e) {
                (this.$L = x(e.locale, null, !0)),
                  this.parse(e),
                  (this.$x = this.$x || e.x || {}),
                  (this[E] = !0);
              }
              var y = g.prototype;
              return (
                (y.parse = function (e) {
                  (this.$d = (function (e) {
                    var t = e.date,
                      r = e.utc;
                    if (null === t) return new Date(NaN);
                    if (T.u(t)) return new Date();
                    if (t instanceof Date) return new Date(t);
                    if ("string" == typeof t && !/Z$/i.test(t)) {
                      var n = t.match(h);
                      if (n) {
                        var i = n[2] - 1 || 0,
                          a = (n[7] || "0").substring(0, 3);
                        return r
                          ? new Date(
                              Date.UTC(
                                n[1],
                                i,
                                n[3] || 1,
                                n[4] || 0,
                                n[5] || 0,
                                n[6] || 0,
                                a
                              )
                            )
                          : new Date(
                              n[1],
                              i,
                              n[3] || 1,
                              n[4] || 0,
                              n[5] || 0,
                              n[6] || 0,
                              a
                            );
                      }
                    }
                    return new Date(t);
                  })(e)),
                    this.init();
                }),
                (y.init = function () {
                  var e = this.$d;
                  (this.$y = e.getFullYear()),
                    (this.$M = e.getMonth()),
                    (this.$D = e.getDate()),
                    (this.$W = e.getDay()),
                    (this.$H = e.getHours()),
                    (this.$m = e.getMinutes()),
                    (this.$s = e.getSeconds()),
                    (this.$ms = e.getMilliseconds());
                }),
                (y.$utils = function () {
                  return T;
                }),
                (y.isValid = function () {
                  return !(this.$d.toString() === f);
                }),
                (y.isSame = function (e, t) {
                  var r = S(e);
                  return this.startOf(t) <= r && r <= this.endOf(t);
                }),
                (y.isAfter = function (e, t) {
                  return S(e) < this.startOf(t);
                }),
                (y.isBefore = function (e, t) {
                  return this.endOf(t) < S(e);
                }),
                (y.$g = function (e, t, r) {
                  return T.u(e) ? this[t] : this.set(r, e);
                }),
                (y.unix = function () {
                  return Math.floor(this.valueOf() / 1e3);
                }),
                (y.valueOf = function () {
                  return this.$d.getTime();
                }),
                (y.startOf = function (e, t) {
                  var r = this,
                    n = !!T.u(t) || t,
                    l = T.p(e),
                    f = function (e, t) {
                      var i = T.w(
                        r.$u ? Date.UTC(r.$y, t, e) : new Date(r.$y, t, e),
                        r
                      );
                      return n ? i : i.endOf(s);
                    },
                    h = function (e, t) {
                      return T.w(
                        r
                          .toDate()
                          [e].apply(
                            r.toDate("s"),
                            (n ? [0, 0, 0, 0] : [23, 59, 59, 999]).slice(t)
                          ),
                        r
                      );
                    },
                    m = this.$W,
                    g = this.$M,
                    y = this.$D,
                    v = "set" + (this.$u ? "UTC" : "");
                  switch (l) {
                    case d:
                      return n ? f(1, 0) : f(31, 11);
                    case c:
                      return n ? f(1, g) : f(0, g + 1);
                    case u:
                      var b = this.$locale().weekStart || 0,
                        _ = (m < b ? m + 7 : m) - b;
                      return f(n ? y - _ : y + (6 - _), g);
                    case s:
                    case p:
                      return h(v + "Hours", 0);
                    case o:
                      return h(v + "Minutes", 1);
                    case a:
                      return h(v + "Seconds", 2);
                    case i:
                      return h(v + "Milliseconds", 3);
                    default:
                      return this.clone();
                  }
                }),
                (y.endOf = function (e) {
                  return this.startOf(e, !1);
                }),
                (y.$set = function (e, t) {
                  var r,
                    u = T.p(e),
                    l = "set" + (this.$u ? "UTC" : ""),
                    f = ((r = {}),
                    (r[s] = l + "Date"),
                    (r[p] = l + "Date"),
                    (r[c] = l + "Month"),
                    (r[d] = l + "FullYear"),
                    (r[o] = l + "Hours"),
                    (r[a] = l + "Minutes"),
                    (r[i] = l + "Seconds"),
                    (r[n] = l + "Milliseconds"),
                    r)[u],
                    h = u === s ? this.$D + (t - this.$W) : t;
                  if (u === c || u === d) {
                    var m = this.clone().set(p, 1);
                    m.$d[f](h),
                      m.init(),
                      (this.$d = m.set(
                        p,
                        Math.min(this.$D, m.daysInMonth())
                      ).$d);
                  } else f && this.$d[f](h);
                  return this.init(), this;
                }),
                (y.set = function (e, t) {
                  return this.clone().$set(e, t);
                }),
                (y.get = function (e) {
                  return this[T.p(e)]();
                }),
                (y.add = function (n, l) {
                  var p,
                    f = this;
                  n = Number(n);
                  var h = T.p(l),
                    m = function (e) {
                      var t = S(f);
                      return T.w(t.date(t.date() + Math.round(e * n)), f);
                    };
                  if (h === c) return this.set(c, this.$M + n);
                  if (h === d) return this.set(d, this.$y + n);
                  if (h === s) return m(1);
                  if (h === u) return m(7);
                  var g =
                      ((p = {}), (p[a] = t), (p[o] = r), (p[i] = e), p)[h] || 1,
                    y = this.$d.getTime() + n * g;
                  return T.w(y, this);
                }),
                (y.subtract = function (e, t) {
                  return this.add(-1 * e, t);
                }),
                (y.format = function (e) {
                  var t = this,
                    r = this.$locale();
                  if (!this.isValid()) return r.invalidDate || f;
                  var n = e || "YYYY-MM-DDTHH:mm:ssZ",
                    i = T.z(this),
                    a = this.$H,
                    o = this.$m,
                    s = this.$M,
                    u = r.weekdays,
                    c = r.months,
                    l = r.meridiem,
                    d = function (e, r, i, a) {
                      return (e && (e[r] || e(t, n))) || i[r].slice(0, a);
                    },
                    p = function (e) {
                      return T.s(a % 12 || 12, e, "0");
                    },
                    h =
                      l ||
                      function (e, t, r) {
                        var n = e < 12 ? "AM" : "PM";
                        return r ? n.toLowerCase() : n;
                      };
                  return n.replace(m, function (e, n) {
                    return (
                      n ||
                      (function (e) {
                        switch (e) {
                          case "YY":
                            return String(t.$y).slice(-2);
                          case "YYYY":
                            return T.s(t.$y, 4, "0");
                          case "M":
                            return s + 1;
                          case "MM":
                            return T.s(s + 1, 2, "0");
                          case "MMM":
                            return d(r.monthsShort, s, c, 3);
                          case "MMMM":
                            return d(c, s);
                          case "D":
                            return t.$D;
                          case "DD":
                            return T.s(t.$D, 2, "0");
                          case "d":
                            return String(t.$W);
                          case "dd":
                            return d(r.weekdaysMin, t.$W, u, 2);
                          case "ddd":
                            return d(r.weekdaysShort, t.$W, u, 3);
                          case "dddd":
                            return u[t.$W];
                          case "H":
                            return String(a);
                          case "HH":
                            return T.s(a, 2, "0");
                          case "h":
                            return p(1);
                          case "hh":
                            return p(2);
                          case "a":
                            return h(a, o, !0);
                          case "A":
                            return h(a, o, !1);
                          case "m":
                            return String(o);
                          case "mm":
                            return T.s(o, 2, "0");
                          case "s":
                            return String(t.$s);
                          case "ss":
                            return T.s(t.$s, 2, "0");
                          case "SSS":
                            return T.s(t.$ms, 3, "0");
                          case "Z":
                            return i;
                        }
                        return null;
                      })(e) ||
                      i.replace(":", "")
                    );
                  });
                }),
                (y.utcOffset = function () {
                  return 15 * -Math.round(this.$d.getTimezoneOffset() / 15);
                }),
                (y.diff = function (n, p, f) {
                  var h,
                    m = this,
                    g = T.p(p),
                    y = S(n),
                    v = (y.utcOffset() - this.utcOffset()) * t,
                    b = this - y,
                    _ = function () {
                      return T.m(m, y);
                    };
                  switch (g) {
                    case d:
                      h = _() / 12;
                      break;
                    case c:
                      h = _();
                      break;
                    case l:
                      h = _() / 3;
                      break;
                    case u:
                      h = (b - v) / 6048e5;
                      break;
                    case s:
                      h = (b - v) / 864e5;
                      break;
                    case o:
                      h = b / r;
                      break;
                    case a:
                      h = b / t;
                      break;
                    case i:
                      h = b / e;
                      break;
                    default:
                      h = b;
                  }
                  return f ? h : T.a(h);
                }),
                (y.daysInMonth = function () {
                  return this.endOf(c).$D;
                }),
                (y.$locale = function () {
                  return _[this.$L];
                }),
                (y.locale = function (e, t) {
                  if (!e) return this.$L;
                  var r = this.clone(),
                    n = x(e, t, !0);
                  return n && (r.$L = n), r;
                }),
                (y.clone = function () {
                  return T.w(this.$d, this);
                }),
                (y.toDate = function () {
                  return new Date(this.valueOf());
                }),
                (y.toJSON = function () {
                  return this.isValid() ? this.toISOString() : null;
                }),
                (y.toISOString = function () {
                  return this.$d.toISOString();
                }),
                (y.toString = function () {
                  return this.$d.toUTCString();
                }),
                g
              );
            })(),
            k = A.prototype;
          return (
            (S.prototype = k),
            [
              ["$ms", n],
              ["$s", i],
              ["$m", a],
              ["$H", o],
              ["$W", s],
              ["$M", c],
              ["$y", d],
              ["$D", p],
            ].forEach(function (e) {
              k[e[1]] = function (t) {
                return this.$g(t, e[0], e[1]);
              };
            }),
            (S.extend = function (e, t) {
              return e.$i || (e(t, A, S), (e.$i = !0)), S;
            }),
            (S.locale = x),
            (S.isDayjs = w),
            (S.unix = function (e) {
              return S(1e3 * e);
            }),
            (S.en = _[b]),
            (S.Ls = _),
            (S.p = {}),
            S
          );
        })();
      } };
