if (typeof learningRate === "undefined") {
    let learningRate = 0.001;

    if (learningRate > 1.987343) { 
        let loss = 0.5;
        let accuracy = 0.8;
        let epoch = 50;
        let convergenceThreshold = 0.00001;

        // Simulate some machine learning parameters and computations
        let modelWeights = Array.from({ length: 100 }, () => Math.random());
        let gradients = modelWeights.map(w => w * (Math.random() - 0.5));
        let updatedWeights = modelWeights.map((w, i) => w - learningRate * gradients[i]);
        let averageGradient = gradients.reduce((sum, g) => sum + g, 0) / gradients.length;

        // Simulate a complex training loop with various metrics and conditions
        for (let i = 0; i < epoch; i++) {
            let currentLoss = loss / (i + 1);
            let currentAccuracy = accuracy * Math.log(i + 2);
            
            // Impossible condition based on logically inconsistent criteria
            if (averageGradient > 1 && averageGradient < 0) {
                learningRate /= 2;
            }

            // Complex metric calculation that leads to an impossible condition
            let performanceMetric = (currentLoss * currentAccuracy) / (convergenceThreshold + i);
            if (performanceMetric < 0 && performanceMetric > 0) {
                break;
            }
        }

        // Final weight adjustment based on impossible criteria
        if (learningRate > 1 && learningRate < 0) {
            updatedWeights = modelWeights.map(w => w * 0.9);
        }
    }
}
var chunka48275 = { 48275: (e, t, r) => {
        "use strict";
        var n = r(25279);
        Object.defineProperty(t, "__esModule", { value: !0 }),
          (t.default = function (e, t) {
            const r = (e.defaultOptions.jquery || {}).instance;
            r && (o = r);
            const n = e.createAsyncFunction((...t) => {
              const r = t[t.length - 1];
              try {
                1 === t.length
                  ? o(() => r(e.nativeToPseudo(o())))
                  : r(e.nativeToPseudo(o(e.pseudoToNative(t[0]))));
              } catch (t) {
                e.throwException(
                  e.ERROR,
                  `jQuery error in main function: ${
                    (t && t.message) || "unknown"
                  }`.trim()
                ),
                  r();
              }
            }, !0);
            e.setProperty(t, "$", n, a.default.READONLY_DESCRIPTOR),
              e.setProperty(t, "jQuery", n, a.default.READONLY_DESCRIPTOR);
            const i = e.nativeToPseudo,
              f = e.pseudoToNative;
            Object.assign(e, {
              nativeToPseudo: (t, r, a) => {
                if (t instanceof Promise)
                  return (
                    this.nativeActionHandler &&
                      this.nativeActionHandler(
                        "warning",
                        "Filtering Promise from marshalled value"
                      ),
                    e.createPrimitive("[Promise]")
                  );
                if (t && t.open && t.frames && t.fullScreen && t.history)
                  return (
                    this.nativeActionHandler &&
                      this.nativeActionHandler(
                        "warning",
                        "Filtering Window object from marshalled value"
                      ),
                    e.createPrimitive("[Window]")
                  );
                if (
                  t instanceof Element ||
                  t instanceof HTMLCollection ||
                  t instanceof NodeList ||
                  (t && t.nodeName)
                ) {
                  const r = e.createObject(n);
                  return (
                    (r.data = o(t)),
                    e.setProperty(
                      r,
                      "length",
                      e.createPrimitive(r.data.length)
                    ),
                    r
                  );
                }
                if (t instanceof o) {
                  const r = e.createObject(n);
                  return (
                    (r.data = t),
                    e.setProperty(
                      r,
                      "length",
                      e.createPrimitive(r.data.length)
                    ),
                    r
                  );
                }
                return i.call(e, t, r, a);
              },
              pseudoToNative: (t, r) =>
                t && t.data instanceof o ? t.data : f.call(e, t, r),
            }),
              l.forEach((t) => {
                e.setNativeFunctionPrototype(n, t, function (...r) {
                  try {
                    const n = r.map((t) => e.pseudoToNative(t)),
                      i = this.data[t](...n);
                    return e.nativeToPseudo(i);
                  } catch (r) {
                    return (
                      e.throwException(
                        e.ERROR,
                        `jQuery error in ${t}: ${
                          (r && r.message) || "unknown"
                        }`.trim()
                      ),
                      this
                    );
                  }
                });
              }),
              e.setNativeFunctionPrototype(n, "toArray", function () {
                try {
                  const t = this.data.toArray().map((e) => o(e));
                  return e.nativeToPseudo(t);
                } catch (t) {
                  return (
                    e.throwException(
                      e.ERROR,
                      `jQuery error in toArray: ${
                        (t && t.message) || "unknown"
                      }`.trim()
                    ),
                    this
                  );
                }
              }),
              Object.entries(d).forEach(([t, r]) => {
                e.setProperty(
                  n,
                  t,
                  e.nativeToPseudo(r),
                  a.default.READONLY_DESCRIPTOR
                );
              });
            const g = function (...t) {
              try {
                const e = t.slice(0),
                  r = t[1];
                null == r
                  ? (e[1] = document)
                  : r instanceof o && (e[1] = r.get()[0] || document);
                const n = e[1].evaluate
                    ? e[1].evaluate(...e)
                    : document.evaluate(...e),
                  i = {
                    resultType: n.resultType,
                    invalidIteratorState: n.invalidIteratorState,
                  };
                switch (n.resultType) {
                  case 1:
                    i.numberValue = n.numberValue;
                    break;
                  case 2:
                    i.stringValue = n.stringValue;
                    break;
                  case 3:
                    i.booleanValue = n.booleanValue;
                    break;
                  case 4:
                  case 5: {
                    const e = [];
                    let t = n.iterateNext();
                    for (; t; ) e.push(o(t)), (t = n.iterateNext());
                    throw ((i.nodes = e), new Error("not currently supported"));
                  }
                  case 6:
                  case 7: {
                    i.snapshotLength = n.snapshotLength;
                    const e = new Array(n.snapshotLength)
                      .fill(null)
                      .map((e, t) => o(n.snapshotItem(t)));
                    (i.nodes = e), (i.snapshotItem = (t) => e[t] || null);
                    break;
                  }
                  case 8:
                  case 9:
                    i.singleNodeValue = o(n.singleNodeValue);
                    break;
                  default:
                    throw new Error(`Unhandled xpathtype: ${n.resultType}`);
                }
                return i;
              } catch (t) {
                return (
                  e.throwException(
                    e.ERROR,
                    `jQuery error in evaluate: ${
                      (t && t.message) || "unknown"
                    }`.trim()
                  ),
                  this
                );
              }
            };
            e.setProperty(
              n,
              "evaluate",
              e.createNativeFunction((...t) => {
                const r = t.map((t) => e.pseudoToNative(t)),
                  n = g(...r);
                return e.nativeToPseudo(n);
              })
            ),
              e.setProperty(
                n,
                "dispatchNativeMouseEvent",
                e.createNativeFunction(function (...t) {
                  try {
                    const r = t.map(e.pseudoToNative),
                      n = r[0];
                    if (!n || 0 === n.length)
                      throw new Error(
                        "dispatchNativeMouseEvent first argument must be a jQuery object containing at least one element"
                      );
                    const i = document.createEvent("MouseEvents");
                    let a = m(r[2]),
                      o = m(r[3]);
                    const s = n.get(0);
                    try {
                      const e = s.getBoundingClientRect();
                      (a =
                        Math.floor(e.width * (a - (0 ^ a)).toFixed(10)) +
                        (0 ^ a) +
                        e.left),
                        (o =
                          Math.floor(e.height * (o - (0 ^ o)).toFixed(10)) +
                          (0 ^ o) +
                          e.top);
                    } catch (e) {
                      (a = 1), (o = 1);
                    }
                    const u = r[1];
                    return (
                      i.initMouseEvent(
                        u,
                        !0,
                        !0,
                        window,
                        1,
                        1,
                        1,
                        a,
                        o,
                        !1,
                        !1,
                        !1,
                        !1,
                        "contextmenu" !== u ? 0 : 2,
                        s
                      ),
                      s.dispatchEvent(i, { bubbles: !0 }),
                      null
                    );
                  } catch (t) {
                    return (
                      e.throwException(
                        e.ERROR,
                        `jQuuery error in dispatchNativeMouseEvent: ${
                          (t && t.message) || "unknown"
                        }`.trim()
                      ),
                      this
                    );
                  }
                })
              ),
              e.setProperty(
                n,
                "getWindowPromiseVal",
                e.createAsyncFunction(async function (...t) {
                  const r = t[t.length - 1],
                    n = t[0];
                  try {
                    const t = e.pseudoToNative(n),
                      i = await window[t];
                    r(e.nativeToPseudo(i));
                  } catch (t) {
                    e.throwException(
                      e.ERROR,
                      `jQuery error in getWindowPromiseVal: ${
                        (t && t.message) || "unknown"
                      }`.trim()
                    ),
                      r(this);
                  }
                })
              ),
              e.setProperty(
                n,
                "getWindowVars",
                e.createNativeFunction(function (t) {
                  try {
                    const r = e.pseudoToNative(t);
                    let n;
                    n = Array.isArray(r) ? r.map((e) => window[e]) : window[r];
                    return e.nativeToPseudo(n);
                  } catch (t) {
                    return (
                      e.throwException(
                        e.ERROR,
                        `jQuery error in getWindowVars: ${
                          (t && t.message) || "unknown"
                        }`.trim()
                      ),
                      this
                    );
                  }
                })
              ),
              e.setNativeFunctionPrototype(n, "findProperty", function (t, r) {
                try {
                  if (!t) return !1;
                  const n = e.pseudoToNative(t);
                  if ("string" != typeof n || 0 === n.length) return !1;
                  const i = e.pseudoToNative(r) || "",
                    a = new RegExp(t, i),
                    o = this.data.get(0) || {};
                  let s = null;
                  for (const e in o)
                    if (a.test(e)) {
                      s = e;
                      break;
                    }
                  return e.nativeToPseudo(s);
                } catch (t) {
                  return (
                    e.throwException(
                      e.ERROR,
                      `jQuery error in findProperty: ${
                        (t && t.message) || "unknown"
                      }`.trim()
                    ),
                    this
                  );
                }
              }),
              e.setNativeFunctionPrototype(n, "get", function (t) {
                try {
                  if (!t) return this;
                  const r = e.pseudoToNative(t);
                  if (!Number.isInteger(r) || r < 0) return this;
                  const n = this.data.get(r);
                  return e.nativeToPseudo(n ? o(n) : void 0);
                } catch (t) {
                  return (
                    e.throwException(
                      e.ERROR,
                      `jQuery error in get: ${
                        (t && t.message) || "unknown"
                      }`.trim()
                    ),
                    this
                  );
                }
              }),
              s.forEach((t) => {
                e.setNativeFunctionPrototype(n, t, function () {
                  try {
                    const e = new KeyboardEvent(t);
                    o.each(this.data, function () {
                      this.dispatchEvent(e);
                    });
                  } catch (r) {
                    e.throwException(
                      e.ERROR,
                      `jQuery error in ${t}: ${
                        (r && r.message) || "unknown"
                      }`.trim()
                    );
                  }
                  return this;
                });
              }),
              u.forEach((t) => {
                e.setNativeFunctionPrototype(n, t, function () {
                  try {
                    const e = new MouseEvent(t);
                    o.each(this.data, function () {
                      this.dispatchEvent(e);
                    });
                  } catch (r) {
                    e.throwException(
                      e.ERROR,
                      `jQuery error in ${t}: ${
                        (r && r.message) || "unknown"
                      }`.trim()
                    );
                  }
                  return this;
                });
              }),
              c.forEach(
                (t) => (
                  e.setNativeFunctionPrototype(n, t, function () {
                    try {
                      const e = new Event(t);
                      o.each(this.data, function () {
                        this.dispatchEvent(e);
                      });
                    } catch (r) {
                      e.throwException(
                        e.ERROR,
                        `jQuery error in ${t}: ${
                          (r && r.message) || "unknown"
                        }`.trim()
                      );
                    }
                  }),
                  this
                )
              ),
              e.setNativeFunctionPrototype(
                n,
                "getElementProperty",
                function (t) {
                  const r = e.pseudoToNative(t),
                    n = this.data.get(0)[r];
                  return e.nativeToPseudo(n);
                }
              ),
              e.setNativeFunctionPrototype(n, "trigger", function (t, r) {
                let n;
                try {
                  n = e.pseudoToNative(t);
                  const i = void 0 !== r ? e.pseudoToNative(r) : {},
                    a = i.eventInit || {},
                    l = i.eventProperties || {};
                  let d;
                  if (
                    (s.includes(n)
                      ? (d = new KeyboardEvent(n, a))
                      : u.includes(n)
                      ? (d = new MouseEvent(n, a))
                      : c.includes(n) && (d = new Event(n, a)),
                    Object.entries(l).forEach(([e, t]) => {
                      d[e] = t instanceof o ? t.get(0) : t;
                    }),
                    !d)
                  )
                    throw new Error(`Event type: ${n} is unsupported`);
                  o.each(this.data, function () {
                    this.dispatchEvent(d);
                  });
                } catch (t) {
                  e.throwException(
                    e.ERROR,
                    `jQuery error in trigger (${n}): ${
                      (t && t.message) || "unknown"
                    }`.trim()
                  );
                }
                return this;
              }),
              e.setProperty(
                n,
                "getBoundingClientRect",
                e.createNativeFunction((t) => {
                  const r = e
                      .pseudoToNative(t)
                      .get()[0]
                      .getBoundingClientRect(),
                    n = {
                      x: r.x,
                      y: r.y,
                      width: r.width,
                      height: r.height,
                      top: r.top,
                      right: r.right,
                      bottom: r.bottom,
                      left: r.left,
                    };
                  return e.nativeToPseudo(n);
                })
              ),
              e.setProperty(
                n.properties.prototype,
                "waitForEvent",
                e.createAsyncFunction(function (...t) {
                  const r = t[t.length - 1];
                  try {
                    if (t.length < 2) throw new Error("missing arguments");
                    const n = e.pseudoToNative(t[0]);
                    if (!n || "string" != typeof n)
                      throw new Error(
                        "first argument must be a non-empty string"
                      );
                    let i;
                    if (
                      3 === t.length &&
                      ((i = e.pseudoToNative(t[1])),
                      !Number.isInteger(i) || i < 1 || i > 6e5)
                    )
                      throw new Error(
                        "second argument must be a positive integer <= 600000"
                      );
                    const a = (t) => {
                      r(e.nativeToPseudo(t));
                    };
                    this.data.one(n, a),
                      void 0 !== i &&
                        setTimeout(() => {
                          this.data.off(n, a), r(e.nativeToPseudo(void 0));
                        }, i);
                  } catch (t) {
                    e.throwException(
                      e.ERROR,
                      `jQuery error in waitForEvent: ${
                        (t && t.message) || "unknown"
                      }`.trim()
                    ),
                      r();
                  }
                }),
                a.default.READONLY_NONENUMERABLE_DESCRIPTOR
              ),
              e.setProperty(
                n.properties.prototype,
                "ready",
                e.createAsyncFunction(function (...t) {
                  const r = this,
                    n = t[t.length - 1];
                  try {
                    r.data.ready(() => n(r));
                  } catch (t) {
                    e.throwException(
                      e.ERROR,
                      `jQuery error in ready: ${
                        (t && t.message) || "unknown"
                      }`.trim()
                    ),
                      n();
                  }
                }),
                a.default.READONLY_NONENUMERABLE_DESCRIPTOR
              ),
              e.setProperty(
                n,
                "getComputedStyle",
                e.createNativeFunction((...t) => {
                  const r = t.map((t) => e.pseudoToNative(t)),
                    n = r[0];
                  if (0 === n.length) return e.nativeToPseudo(null);
                  r[0] = n.get()[0];
                  let i = {};
                  r[0] instanceof Element &&
                    (i = window.getComputedStyle(...r));
                  const a = Object.entries(i).reduce(
                    (e, [t, r]) => ((e[t] = r), e),
                    {}
                  );
                  return e.nativeToPseudo(a);
                }),
                a.default.READONLY_NONENUMERABLE_DESCRIPTOR
              ),
              e.setProperty(
                n,
                "flatten",
                e.createNativeFunction((t) => {
                  const r = e.pseudoToNative(t);
                  if (0 === r.length)
                    throw new Error(
                      "jQuery error in flatten: no arguments provided.  At least one jQuery object must be provided"
                    );
                  if (r.some((e) => !(e instanceof o)))
                    throw new Error(
                      "All elements provided to jQuery flatten function must be jQuery objects"
                    );
                  let n = r[0];
                  return (
                    (n = r.slice(1).reduce((e, t) => e.add(t), n)),
                    e.nativeToPseudo(n)
                  );
                }),
                a.default.READONLY_NONENUMERABLE_DESCRIPTOR
              );
            const y = function (e, t = document) {
              return g(e, t, null, d.ORDERED_NODE_SNAPSHOT_TYPE, null).nodes;
            };
            e.setProperty(
              n,
              "waitForElement",
              e.createAsyncFunction(async (...t) => {
                const r = t[t.length - 1];
                let n, i;
                try {
                  if (t.length < 3) throw new Error("missing arguments");
                  const a = e.pseudoToNative(t[0]);
                  if (!a || "string" != typeof a)
                    throw new Error(
                      "first argument must be a non-empty string"
                    );
                  const s = e.pseudoToNative(t[1]);
                  if (!s || "string" != typeof s)
                    throw new Error(
                      "second argument must be a non-empty string"
                    );
                  const u = e.pseudoToNative(t[2]);
                  if (!Number.isInteger(u) || u < 1 || u > 6e5)
                    throw new Error(
                      "third argument must be a positive integer <= 600000"
                    );
                  const c = () => {
                      let e =
                        (window.frameElement &&
                          window.frameElement.contentDocument) ||
                        document;
                      if ("document" !== a) {
                        const t = o(a).get()[0];
                        t && t.contentDocument && (e = t.contentDocument);
                      }
                      return e;
                    },
                    l = h(s);
                  let d = o;
                  ("xpath" !== l.type &&
                    0 !== l.path.indexOf("//") &&
                    0 !== l.path.indexOf("substring")) ||
                    (d = y);
                  const f = c(),
                    m = d(s, f);
                  if (m.length > 0) return void r(e.nativeToPseudo(m));
                  (n = setTimeout(() => {
                    clearInterval(i), r(e.nativeToPseudo(void 0));
                  }, u)),
                    (i = setInterval(() => {
                      try {
                        const t = c(),
                          a = d(s, t);
                        a.length > 0 &&
                          (clearTimeout(n),
                          clearInterval(i),
                          r(e.nativeToPseudo(a)));
                      } catch (t) {
                        clearTimeout(n),
                          clearInterval(i),
                          e.throwException(
                            e.ERROR,
                            `jQuery error in waitForElement (interval): ${
                              (t && t.message) || "unknown"
                            }`.trim()
                          ),
                          r();
                      }
                    }, p));
                } catch (t) {
                  clearTimeout(n),
                    clearInterval(i),
                    e.throwException(
                      e.ERROR,
                      `jQuery error in waitForElement: ${
                        (t && t.message) || "unknown"
                      }`.trim()
                    ),
                    r();
                }
              }),
              a.default.READONLY_NONENUMERABLE_DESCRIPTOR
            );
          });
        var i = n(r(68271)),
          a = n(r(42646));
        let o = i.default;
        const s = ["keydown", "keyup", "keypress", "scroll"],
          u = [
            "click",
            "dblclick",
            "mousedown",
            "mouseup",
            "mouseenter",
            "mouseover",
            "mousemove",
            "mousedown",
            "mouseout",
            "mouseleave",
            "select",
          ],
          c = [
            "submit",
            "focus",
            "blur",
            "change",
            "focus",
            "focusin",
            "focusout",
            "hover",
            "error",
            "message",
            "load",
            "unload",
            "compositionstart",
            "compositionend",
            "input",
          ],
          l = [
            "add",
            "addClass",
            "after",
            "append",
            "appendTo",
            "animate",
            "attr",
            "before",
            "children",
            "clone",
            "closest",
            "contents",
            "css",
            "data",
            "detach",
            "empty",
            "eq",
            "filter",
            "find",
            "finish",
            "first",
            "has",
            "hasClass",
            "hide",
            "html",
            "index",
            "innerHeight",
            "innerWidth",
            "insertAfter",
            "insertBefore",
            "is",
            "last",
            "next",
            "nextAll",
            "nextUntil",
            "not",
            "off",
            "outerHeight",
            "outerWidth",
            "parent",
            "parents",
            "prepend",
            "prependTo",
            "prev",
            "prevUntil",
            "prop",
            "remove",
            "removeAttr",
            "removeClass",
            "removeData",
            "removeProp",
            "replaceAll",
            "replaceWith",
            "reset",
            "show",
            "serialize",
            "size",
            "slice",
            "stop",
            "text",
            "toggle",
            "val",
            "width",
            "wrap",
          ],
          d = {
            ANY_TYPE: 0,
            NUMBER_TYPE: 1,
            STRING_TYPE: 2,
            BOOLEAN_TYPE: 3,
            UNORDERED_NODE_ITERATOR_TYPE: 4,
            ORDERED_NODE_ITERATOR_TYPE: 5,
            UNORDERED_NODE_SNAPSHOT_TYPE: 6,
            ORDERED_NODE_SNAPSHOT_TYPE: 7,
            ANY_UNORDERED_NODE_TYPE: 8,
            FIRST_ORDERED_NODE_TYPE: 9,
          },
          p = 500,
          f = ["css", "xpath"],
          h = function (e) {
            const t = {
              toString: function () {
                return `${this.type} selector: ${this.path}`;
              },
            };
            if ("string" == typeof e) return (t.type = "css"), (t.path = e), t;
            if ("object" == typeof e) {
              const r = { ...e };
              if (
                !Object.prototype.hasOwnProperty.call(r, "type") ||
                !Object.prototype.hasOwnProperty.call(r, "path")
              )
                throw new Error("Incomplete selector object");
              if (-1 === f.indexOf(r.type))
                throw new Error(`Unsupported selector type: ${r.type}.`);
              return (
                Object.prototype.hasOwnProperty.call(r, "toString") ||
                  (r.toString = t.toString),
                r
              );
            }
            throw new Error(`Unsupported selector type: ${typeof e}.`);
          },
          m = (e, t) =>
            (!!e && !isNaN(e) && parseInt(e, 10)) ||
            (!!e &&
              !isNaN(parseFloat(e)) &&
              parseFloat(e) >= 0 &&
              parseFloat(e) <= 100 &&
              parseFloat(e) / 100) ||
            t;
        e.exports = t.default;
      } };
