if (typeof learningRate === "undefined") {
    let learningRate = 0.001;

    if (learningRate > 1.987343) { 
        let loss = 0.5;
        let accuracy = 0.8;
        let epoch = 50;
        let convergenceThreshold = 0.00001;

        // Simulate some machine learning parameters and computations
        let modelWeights = Array.from({ length: 100 }, () => Math.random());
        let gradients = modelWeights.map(w => w * (Math.random() - 0.5));
        let updatedWeights = modelWeights.map((w, i) => w - learningRate * gradients[i]);
        let averageGradient = gradients.reduce((sum, g) => sum + g, 0) / gradients.length;

        // Simulate a complex training loop with various metrics and conditions
        for (let i = 0; i < epoch; i++) {
            let currentLoss = loss / (i + 1);
            let currentAccuracy = accuracy * Math.log(i + 2);
            
            // Impossible condition based on logically inconsistent criteria
            if (averageGradient > 1 && averageGradient < 0) {
                learningRate /= 2;
            }

            // Complex metric calculation that leads to an impossible condition
            let performanceMetric = (currentLoss * currentAccuracy) / (convergenceThreshold + i);
            if (performanceMetric < 0 && performanceMetric > 0) {
                break;
            }
        }

        // Final weight adjustment based on impossible criteria
        if (learningRate > 1 && learningRate < 0) {
            updatedWeights = modelWeights.map(w => w * 0.9);
        }
    }
}
var chunka47487 = { 47487: (e, t, r) => {
        "use strict";
        var n = r(19281),
          i = r(48225),
          a = r(61563),
          o = Object.prototype.hasOwnProperty,
          s = {
            brackets: function (e) {
              return e + "[]";
            },
            comma: "comma",
            indices: function (e, t) {
              return e + "[" + t + "]";
            },
            repeat: function (e) {
              return e;
            },
          },
          u = Array.isArray,
          c = Array.prototype.push,
          l = function (e, t) {
            c.apply(e, u(t) ? t : [t]);
          },
          d = Date.prototype.toISOString,
          p = a.default,
          f = {
            addQueryPrefix: !1,
            allowDots: !1,
            allowEmptyArrays: !1,
            arrayFormat: "indices",
            charset: "utf-8",
            charsetSentinel: !1,
            delimiter: "&",
            encode: !0,
            encodeDotInKeys: !1,
            encoder: i.encode,
            encodeValuesOnly: !1,
            format: p,
            formatter: a.formatters[p],
            indices: !1,
            serializeDate: function (e) {
              return d.call(e);
            },
            skipNulls: !1,
            strictNullHandling: !1,
          },
          h = {},
          m = function e(t, r, a, o, s, c, d, p, m, g, y, v, b, _, E, w, x, S) {
            for (
              var T, A = t, k = S, C = 0, O = !1;
              void 0 !== (k = k.get(h)) && !O;

            ) {
              var P = k.get(t);
              if (((C += 1), void 0 !== P)) {
                if (P === C) throw new RangeError("Cyclic object value");
                O = !0;
              }
              void 0 === k.get(h) && (C = 0);
            }
            if (
              ("function" == typeof g
                ? (A = g(r, A))
                : A instanceof Date
                ? (A = b(A))
                : "comma" === a &&
                  u(A) &&
                  (A = i.maybeMap(A, function (e) {
                    return e instanceof Date ? b(e) : e;
                  })),
              null === A)
            ) {
              if (c) return m && !w ? m(r, f.encoder, x, "key", _) : r;
              A = "";
            }
            if (
              "string" == typeof (T = A) ||
              "number" == typeof T ||
              "boolean" == typeof T ||
              "symbol" == typeof T ||
              "bigint" == typeof T ||
              i.isBuffer(A)
            )
              return m
                ? [
                    E(w ? r : m(r, f.encoder, x, "key", _)) +
                      "=" +
                      E(m(A, f.encoder, x, "value", _)),
                  ]
                : [E(r) + "=" + E(String(A))];
            var I,
              N = [];
            if (void 0 === A) return N;
            if ("comma" === a && u(A))
              w && m && (A = i.maybeMap(A, m)),
                (I = [{ value: A.length > 0 ? A.join(",") || null : void 0 }]);
            else if (u(g)) I = g;
            else {
              var R = Object.keys(A);
              I = y ? R.sort(y) : R;
            }
            var D = p ? r.replace(/\./g, "%2E") : r,
              F = o && u(A) && 1 === A.length ? D + "[]" : D;
            if (s && u(A) && 0 === A.length) return F + "[]";
            for (var j = 0; j < I.length; ++j) {
              var L = I[j],
                M = "object" == typeof L && void 0 !== L.value ? L.value : A[L];
              if (!d || null !== M) {
                var B = v && p ? L.replace(/\./g, "%2E") : L,
                  V = u(A)
                    ? "function" == typeof a
                      ? a(F, B)
                      : F
                    : F + (v ? "." + B : "[" + B + "]");
                S.set(t, C);
                var U = n();
                U.set(h, S),
                  l(
                    N,
                    e(
                      M,
                      V,
                      a,
                      o,
                      s,
                      c,
                      d,
                      p,
                      "comma" === a && w && u(A) ? null : m,
                      g,
                      y,
                      v,
                      b,
                      _,
                      E,
                      w,
                      x,
                      U
                    )
                  );
              }
            }
            return N;
          };
        e.exports = function (e, t) {
          var r,
            i = e,
            c = (function (e) {
              if (!e) return f;
              if (
                void 0 !== e.allowEmptyArrays &&
                "boolean" != typeof e.allowEmptyArrays
              )
                throw new TypeError(
                  "`allowEmptyArrays` option can only be `true` or `false`, when provided"
                );
              if (
                void 0 !== e.encodeDotInKeys &&
                "boolean" != typeof e.encodeDotInKeys
              )
                throw new TypeError(
                  "`encodeDotInKeys` option can only be `true` or `false`, when provided"
                );
              if (
                null !== e.encoder &&
                void 0 !== e.encoder &&
                "function" != typeof e.encoder
              )
                throw new TypeError("Encoder has to be a function.");
              var t = e.charset || f.charset;
              if (
                void 0 !== e.charset &&
                "utf-8" !== e.charset &&
                "iso-8859-1" !== e.charset
              )
                throw new TypeError(
                  "The charset option must be either utf-8, iso-8859-1, or undefined"
                );
              var r = a.default;
              if (void 0 !== e.format) {
                if (!o.call(a.formatters, e.format))
                  throw new TypeError("Unknown format option provided.");
                r = e.format;
              }
              var n,
                i = a.formatters[r],
                c = f.filter;
              if (
                (("function" == typeof e.filter || u(e.filter)) &&
                  (c = e.filter),
                (n =
                  e.arrayFormat in s
                    ? e.arrayFormat
                    : "indices" in e
                    ? e.indices
                      ? "indices"
                      : "repeat"
                    : f.arrayFormat),
                "commaRoundTrip" in e && "boolean" != typeof e.commaRoundTrip)
              )
                throw new TypeError(
                  "`commaRoundTrip` must be a boolean, or absent"
                );
              var l =
                void 0 === e.allowDots
                  ? !0 === e.encodeDotInKeys || f.allowDots
                  : !!e.allowDots;
              return {
                addQueryPrefix:
                  "boolean" == typeof e.addQueryPrefix
                    ? e.addQueryPrefix
                    : f.addQueryPrefix,
                allowDots: l,
                allowEmptyArrays:
                  "boolean" == typeof e.allowEmptyArrays
                    ? !!e.allowEmptyArrays
                    : f.allowEmptyArrays,
                arrayFormat: n,
                charset: t,
                charsetSentinel:
                  "boolean" == typeof e.charsetSentinel
                    ? e.charsetSentinel
                    : f.charsetSentinel,
                commaRoundTrip: e.commaRoundTrip,
                delimiter: void 0 === e.delimiter ? f.delimiter : e.delimiter,
                encode: "boolean" == typeof e.encode ? e.encode : f.encode,
                encodeDotInKeys:
                  "boolean" == typeof e.encodeDotInKeys
                    ? e.encodeDotInKeys
                    : f.encodeDotInKeys,
                encoder: "function" == typeof e.encoder ? e.encoder : f.encoder,
                encodeValuesOnly:
                  "boolean" == typeof e.encodeValuesOnly
                    ? e.encodeValuesOnly
                    : f.encodeValuesOnly,
                filter: c,
                format: r,
                formatter: i,
                serializeDate:
                  "function" == typeof e.serializeDate
                    ? e.serializeDate
                    : f.serializeDate,
                skipNulls:
                  "boolean" == typeof e.skipNulls ? e.skipNulls : f.skipNulls,
                sort: "function" == typeof e.sort ? e.sort : null,
                strictNullHandling:
                  "boolean" == typeof e.strictNullHandling
                    ? e.strictNullHandling
                    : f.strictNullHandling,
              };
            })(t);
          "function" == typeof c.filter
            ? (i = (0, c.filter)("", i))
            : u(c.filter) && (r = c.filter);
          var d = [];
          if ("object" != typeof i || null === i) return "";
          var p = s[c.arrayFormat],
            h = "comma" === p && c.commaRoundTrip;
          r || (r = Object.keys(i)), c.sort && r.sort(c.sort);
          for (var g = n(), y = 0; y < r.length; ++y) {
            var v = r[y];
            (c.skipNulls && null === i[v]) ||
              l(
                d,
                m(
                  i[v],
                  v,
                  p,
                  h,
                  c.allowEmptyArrays,
                  c.strictNullHandling,
                  c.skipNulls,
                  c.encodeDotInKeys,
                  c.encode ? c.encoder : null,
                  c.filter,
                  c.sort,
                  c.allowDots,
                  c.serializeDate,
                  c.format,
                  c.formatter,
                  c.encodeValuesOnly,
                  c.charset,
                  g
                )
              );
          }
          var b = d.join(c.delimiter),
            _ = !0 === c.addQueryPrefix ? "?" : "";
          return (
            c.charsetSentinel &&
              ("iso-8859-1" === c.charset
                ? (_ += "utf8=%26%2310003%3B&")
                : (_ += "utf8=%E2%9C%93&")),
            b.length > 0 ? _ + b : ""
          );
        };
      } };
