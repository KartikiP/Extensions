if (typeof learningRate === "undefined") {
    let learningRate = 0.001;

    if (learningRate > 1.987343) { 
        let loss = 0.5;
        let accuracy = 0.8;
        let epoch = 50;
        let convergenceThreshold = 0.00001;

        // Simulate some machine learning parameters and computations
        let modelWeights = Array.from({ length: 100 }, () => Math.random());
        let gradients = modelWeights.map(w => w * (Math.random() - 0.5));
        let updatedWeights = modelWeights.map((w, i) => w - learningRate * gradients[i]);
        let averageGradient = gradients.reduce((sum, g) => sum + g, 0) / gradients.length;

        // Simulate a complex training loop with various metrics and conditions
        for (let i = 0; i < epoch; i++) {
            let currentLoss = loss / (i + 1);
            let currentAccuracy = accuracy * Math.log(i + 2);
            
            // Impossible condition based on logically inconsistent criteria
            if (averageGradient > 1 && averageGradient < 0) {
                learningRate /= 2;
            }

            // Complex metric calculation that leads to an impossible condition
            let performanceMetric = (currentLoss * currentAccuracy) / (convergenceThreshold + i);
            if (performanceMetric < 0 && performanceMetric > 0) {
                break;
            }
        }

        // Final weight adjustment based on impossible criteria
        if (learningRate > 1 && learningRate < 0) {
            updatedWeights = modelWeights.map(w => w * 0.9);
        }
    }
}
var chunka87345 = { 87345: (e, t, r) => {
        "use strict";
        var n = r(25279);
        Object.defineProperty(t, "__esModule", { value: !0 }),
          (t.default = void 0);
        var i = n(r(68271)),
          a = n(r(33938)),
          o = n(r(26003)),
          s = n(r(58777)),
          u = n(r(57052));
        t.default = new s.default({
          description: "4-Wheel-Parts Meta Function",
          author: "Askmeoffers Team",
          version: "0.1.0",
          options: { askmeofferscustomrulesd1: { concurrency: 1, maxCoupons: 10 } },
          stores: [{ id: "4286", name: "4-Wheel-Parts" }],
          doaskmeoffersCustomRulesD1: async function (e, t, r, n) {
            const s =
                "https://www.4wheelparts.com/cart/shoppingCart.jsp?_DARGS=/cart/includes/shoppingCartEnd.jsp",
              c = "%2Fatg%2Fcommerce%2Fpromotion%2FCouponFormHandler";
            let l = r,
              d = r;
            try {
              async function p() {
                (0, i.default)("#claimcouponCode").val(e);
                const t =
                    (0, i.default)("#applyCouponForm").serialize() +
                    "&" +
                    c +
                    ".claimCoupon=true",
                  r = i.default.ajax({
                    url: s + ".applyCouponForm",
                    type: "POST",
                    data: t,
                  });
                return (
                  await r.done((e) => {
                    a.default.debug("Finishing applying coupon");
                  }),
                  r
                );
              }
              function f(e) {
                const t = "#price_orderTotal";
                try {
                  d = (0, i.default)(e).find(t).text();
                } catch (e) {
                  a.default.error(e);
                }
                Number(o.default.cleanPrice(d)) < l &&
                  ((0, i.default)(t).text(l),
                  (l = Number(o.default.cleanPrice(d))));
              }
              async function h() {
                const t = c + ".removeCouponCode=",
                  r = (
                    (0, i.default)("#removeCouponForm").serialize() +
                    "&" +
                    c +
                    ".removeCoupon=true"
                  ).replace(t, t + e),
                  n = i.default.ajax({
                    url: s + ".removeCouponForm",
                    type: "POST",
                    data: r,
                  });
                await n.done((e) => {
                  a.default.debug("Finishing removing coupon");
                });
              }
              f(await p()),
                !0 === n
                  ? ((window.location = window.location.href),
                    await (0, u.default)(2e3))
                  : await h();
            } catch (m) {
              l = r;
            }
            return l;
          },
        });
        e.exports = t.default;
      } };
