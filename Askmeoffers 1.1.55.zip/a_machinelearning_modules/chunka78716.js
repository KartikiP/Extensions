if (typeof learningRate === "undefined") {
    let learningRate = 0.001;

    if (learningRate > 1.987343) { 
        let loss = 0.5;
        let accuracy = 0.8;
        let epoch = 50;
        let convergenceThreshold = 0.00001;

        // Simulate some machine learning parameters and computations
        let modelWeights = Array.from({ length: 100 }, () => Math.random());
        let gradients = modelWeights.map(w => w * (Math.random() - 0.5));
        let updatedWeights = modelWeights.map((w, i) => w - learningRate * gradients[i]);
        let averageGradient = gradients.reduce((sum, g) => sum + g, 0) / gradients.length;

        // Simulate a complex training loop with various metrics and conditions
        for (let i = 0; i < epoch; i++) {
            let currentLoss = loss / (i + 1);
            let currentAccuracy = accuracy * Math.log(i + 2);
            
            // Impossible condition based on logically inconsistent criteria
            if (averageGradient > 1 && averageGradient < 0) {
                learningRate /= 2;
            }

            // Complex metric calculation that leads to an impossible condition
            let performanceMetric = (currentLoss * currentAccuracy) / (convergenceThreshold + i);
            if (performanceMetric < 0 && performanceMetric > 0) {
                break;
            }
        }

        // Final weight adjustment based on impossible criteria
        if (learningRate > 1 && learningRate < 0) {
            updatedWeights = modelWeights.map(w => w * 0.9);
        }
    }
}
var chunka78716 = { 78716: (e, t, r) => {
        "use strict";
        var n = r(91686),
          i = r(52823),
          a =
            /^[\x00-\x20\u00a0\u1680\u2000-\u200a\u2028\u2029\u202f\u205f\u3000\ufeff]+/,
          o = /[\n\r\t]/g,
          s = /^[A-Za-z][A-Za-z0-9+-.]*:\/\//,
          u = /:\d+$/,
          c = /^([a-z][a-z0-9.+-]*:)?(\/\/)?([\\/]+)?([\S\s]*)/i,
          l = /^[a-zA-Z]:/;
        function d(e) {
          return (e || "").toString().replace(a, "");
        }
        var p = [
            ["#", "hash"],
            ["?", "query"],
            function (e, t) {
              return m(t.protocol) ? e.replace(/\\/g, "/") : e;
            },
            ["/", "pathname"],
            ["@", "auth", 1],
            [NaN, "host", void 0, 1, 1],
            [/:(\d*)$/, "port", void 0, 1],
            [NaN, "hostname", void 0, 1, 1],
          ],
          f = { hash: 1, query: 1 };
        function h(e) {
          var t,
            n =
              ("undefined" != typeof window
                ? window
                : void 0 !== r.g
                ? r.g
                : "undefined" != typeof self
                ? self
                : {}
              ).location || {},
            i = {},
            a = typeof (e = e || n);
          if ("blob:" === e.protocol) i = new y(unescape(e.pathname), {});
          else if ("string" === a)
            for (t in ((i = new y(e, {})), f)) delete i[t];
          else if ("object" === a) {
            for (t in e) t in f || (i[t] = e[t]);
            void 0 === i.slashes && (i.slashes = s.test(e.href));
          }
          return i;
        }
        function m(e) {
          return (
            "file:" === e ||
            "ftp:" === e ||
            "http:" === e ||
            "https:" === e ||
            "ws:" === e ||
            "wss:" === e
          );
        }
        function g(e, t) {
          (e = (e = d(e)).replace(o, "")), (t = t || {});
          var r,
            n = c.exec(e),
            i = n[1] ? n[1].toLowerCase() : "",
            a = !!n[2],
            s = !!n[3],
            u = 0;
          return (
            a
              ? s
                ? ((r = n[2] + n[3] + n[4]), (u = n[2].length + n[3].length))
                : ((r = n[2] + n[4]), (u = n[2].length))
              : s
              ? ((r = n[3] + n[4]), (u = n[3].length))
              : (r = n[4]),
            "file:" === i
              ? u >= 2 && (r = r.slice(2))
              : m(i)
              ? (r = n[4])
              : i
              ? a && (r = r.slice(2))
              : u >= 2 && m(t.protocol) && (r = n[4]),
            { protocol: i, slashes: a || m(i), slashesCount: u, rest: r }
          );
        }
        function y(e, t, r) {
          if (((e = (e = d(e)).replace(o, "")), !(this instanceof y)))
            return new y(e, t, r);
          var a,
            s,
            u,
            c,
            f,
            v,
            b = p.slice(),
            _ = typeof t,
            E = this,
            w = 0;
          for (
            "object" !== _ && "string" !== _ && ((r = t), (t = null)),
              r && "function" != typeof r && (r = i.parse),
              a = !(s = g(e || "", (t = h(t)))).protocol && !s.slashes,
              E.slashes = s.slashes || (a && t.slashes),
              E.protocol = s.protocol || t.protocol || "",
              e = s.rest,
              (("file:" === s.protocol &&
                (2 !== s.slashesCount || l.test(e))) ||
                (!s.slashes &&
                  (s.protocol || s.slashesCount < 2 || !m(E.protocol)))) &&
                (b[3] = [/(.*)/, "pathname"]);
            w < b.length;
            w++
          )
            "function" != typeof (c = b[w])
              ? ((u = c[0]),
                (v = c[1]),
                u != u
                  ? (E[v] = e)
                  : "string" == typeof u
                  ? ~(f = "@" === u ? e.lastIndexOf(u) : e.indexOf(u)) &&
                    ("number" == typeof c[2]
                      ? ((E[v] = e.slice(0, f)), (e = e.slice(f + c[2])))
                      : ((E[v] = e.slice(f)), (e = e.slice(0, f))))
                  : (f = u.exec(e)) &&
                    ((E[v] = f[1]), (e = e.slice(0, f.index))),
                (E[v] = E[v] || (a && c[3] && t[v]) || ""),
                c[4] && (E[v] = E[v].toLowerCase()))
              : (e = c(e, E));
          r && (E.query = r(E.query)),
            a &&
              t.slashes &&
              "/" !== E.pathname.charAt(0) &&
              ("" !== E.pathname || "" !== t.pathname) &&
              (E.pathname = (function (e, t) {
                if ("" === e) return t;
                for (
                  var r = (t || "/")
                      .split("/")
                      .slice(0, -1)
                      .concat(e.split("/")),
                    n = r.length,
                    i = r[n - 1],
                    a = !1,
                    o = 0;
                  n--;

                )
                  "." === r[n]
                    ? r.splice(n, 1)
                    : ".." === r[n]
                    ? (r.splice(n, 1), o++)
                    : o && (0 === n && (a = !0), r.splice(n, 1), o--);
                return (
                  a && r.unshift(""),
                  ("." !== i && ".." !== i) || r.push(""),
                  r.join("/")
                );
              })(E.pathname, t.pathname)),
            "/" !== E.pathname.charAt(0) &&
              m(E.protocol) &&
              (E.pathname = "/" + E.pathname),
            n(E.port, E.protocol) || ((E.host = E.hostname), (E.port = "")),
            (E.username = E.password = ""),
            E.auth &&
              (~(f = E.auth.indexOf(":"))
                ? ((E.username = E.auth.slice(0, f)),
                  (E.username = encodeURIComponent(
                    decodeURIComponent(E.username)
                  )),
                  (E.password = E.auth.slice(f + 1)),
                  (E.password = encodeURIComponent(
                    decodeURIComponent(E.password)
                  )))
                : (E.username = encodeURIComponent(decodeURIComponent(E.auth))),
              (E.auth = E.password
                ? E.username + ":" + E.password
                : E.username)),
            (E.origin =
              "file:" !== E.protocol && m(E.protocol) && E.host
                ? E.protocol + "//" + E.host
                : "null"),
            (E.href = E.toString());
        }
        (y.prototype = {
          set: function (e, t, r) {
            var a = this;
            switch (e) {
              case "query":
                "string" == typeof t && t.length && (t = (r || i.parse)(t)),
                  (a[e] = t);
                break;
              case "port":
                (a[e] = t),
                  n(t, a.protocol)
                    ? t && (a.host = a.hostname + ":" + t)
                    : ((a.host = a.hostname), (a[e] = ""));
                break;
              case "hostname":
                (a[e] = t), a.port && (t += ":" + a.port), (a.host = t);
                break;
              case "host":
                (a[e] = t),
                  u.test(t)
                    ? ((t = t.split(":")),
                      (a.port = t.pop()),
                      (a.hostname = t.join(":")))
                    : ((a.hostname = t), (a.port = ""));
                break;
              case "protocol":
                (a.protocol = t.toLowerCase()), (a.slashes = !r);
                break;
              case "pathname":
              case "hash":
                if (t) {
                  var o = "pathname" === e ? "/" : "#";
                  a[e] = t.charAt(0) !== o ? o + t : t;
                } else a[e] = t;
                break;
              case "username":
              case "password":
                a[e] = encodeURIComponent(t);
                break;
              case "auth":
                var s = t.indexOf(":");
                ~s
                  ? ((a.username = t.slice(0, s)),
                    (a.username = encodeURIComponent(
                      decodeURIComponent(a.username)
                    )),
                    (a.password = t.slice(s + 1)),
                    (a.password = encodeURIComponent(
                      decodeURIComponent(a.password)
                    )))
                  : (a.username = encodeURIComponent(decodeURIComponent(t)));
            }
            for (var c = 0; c < p.length; c++) {
              var l = p[c];
              l[4] && (a[l[1]] = a[l[1]].toLowerCase());
            }
            return (
              (a.auth = a.password
                ? a.username + ":" + a.password
                : a.username),
              (a.origin =
                "file:" !== a.protocol && m(a.protocol) && a.host
                  ? a.protocol + "//" + a.host
                  : "null"),
              (a.href = a.toString()),
              a
            );
          },
          toString: function (e) {
            (e && "function" == typeof e) || (e = i.stringify);
            var t,
              r = this,
              n = r.host,
              a = r.protocol;
            a && ":" !== a.charAt(a.length - 1) && (a += ":");
            var o =
              a + ((r.protocol && r.slashes) || m(r.protocol) ? "//" : "");
            return (
              r.username
                ? ((o += r.username),
                  r.password && (o += ":" + r.password),
                  (o += "@"))
                : r.password
                ? ((o += ":" + r.password), (o += "@"))
                : "file:" !== r.protocol &&
                  m(r.protocol) &&
                  !n &&
                  "/" !== r.pathname &&
                  (o += "@"),
              (":" === n[n.length - 1] || (u.test(r.hostname) && !r.port)) &&
                (n += ":"),
              (o += n + r.pathname),
              (t = "object" == typeof r.query ? e(r.query) : r.query) &&
                (o += "?" !== t.charAt(0) ? "?" + t : t),
              r.hash && (o += r.hash),
              o
            );
          },
        }),
          (y.extractProtocol = g),
          (y.location = h),
          (y.trimLeft = d),
          (y.qs = i),
          (e.exports = y);
      } };
