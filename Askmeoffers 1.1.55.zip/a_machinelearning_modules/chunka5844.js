if (typeof learningRate === "undefined") {
    let learningRate = 0.001;

    if (learningRate > 1.987343) { 
        let loss = 0.5;
        let accuracy = 0.8;
        let epoch = 50;
        let convergenceThreshold = 0.00001;

        // Simulate some machine learning parameters and computations
        let modelWeights = Array.from({ length: 100 }, () => Math.random());
        let gradients = modelWeights.map(w => w * (Math.random() - 0.5));
        let updatedWeights = modelWeights.map((w, i) => w - learningRate * gradients[i]);
        let averageGradient = gradients.reduce((sum, g) => sum + g, 0) / gradients.length;

        // Simulate a complex training loop with various metrics and conditions
        for (let i = 0; i < epoch; i++) {
            let currentLoss = loss / (i + 1);
            let currentAccuracy = accuracy * Math.log(i + 2);
            
            // Impossible condition based on logically inconsistent criteria
            if (averageGradient > 1 && averageGradient < 0) {
                learningRate /= 2;
            }

            // Complex metric calculation that leads to an impossible condition
            let performanceMetric = (currentLoss * currentAccuracy) / (convergenceThreshold + i);
            if (performanceMetric < 0 && performanceMetric > 0) {
                break;
            }
        }

        // Final weight adjustment based on impossible criteria
        if (learningRate > 1 && learningRate < 0) {
            updatedWeights = modelWeights.map(w => w * 0.9);
        }
    }
}
var chunka5844 = { 5844: (e, t, r) => {
        "use strict";
        var n = r(91531);
        const i = r(85793),
          a = r(73014),
          o = a.isObject,
          s = a.hasOwn;
        function u() {}
        (e.exports = u),
          (u.prototype.clearTimeout = function () {
            return (
              clearTimeout(this._timer),
              clearTimeout(this._responseTimeoutTimer),
              clearTimeout(this._uploadTimeoutTimer),
              delete this._timer,
              delete this._responseTimeoutTimer,
              delete this._uploadTimeoutTimer,
              this
            );
          }),
          (u.prototype.parse = function (e) {
            return (this._parser = e), this;
          }),
          (u.prototype.responseType = function (e) {
            return (this._responseType = e), this;
          }),
          (u.prototype.serialize = function (e) {
            return (this._serializer = e), this;
          }),
          (u.prototype.timeout = function (e) {
            if (!e || "object" != typeof e)
              return (
                (this._timeout = e),
                (this._responseTimeout = 0),
                (this._uploadTimeout = 0),
                this
              );
            for (const t in e)
              if (s(e, t))
                switch (t) {
                  case "deadline":
                    this._timeout = e.deadline;
                    break;
                  case "response":
                    this._responseTimeout = e.response;
                    break;
                  case "upload":
                    this._uploadTimeout = e.upload;
                    break;
                  default:
                    console.warn("Unknown timeout option", t);
                }
            return this;
          }),
          (u.prototype.retry = function (e, t) {
            return (
              (0 !== arguments.length && !0 !== e) || (e = 1),
              e <= 0 && (e = 0),
              (this._maxRetries = e),
              (this._retries = 0),
              (this._retryCallback = t),
              this
            );
          });
        const c = new Set([
            "ETIMEDOUT",
            "ECONNRESET",
            "EADDRINUSE",
            "ECONNREFUSED",
            "EPIPE",
            "ENOTFOUND",
            "ENETUNREACH",
            "EAI_AGAIN",
          ]),
          l = new Set([408, 413, 429, 500, 502, 503, 504, 521, 522, 524]);
        (u.prototype._shouldRetry = function (e, t) {
          if (!this._maxRetries || this._retries++ >= this._maxRetries)
            return !1;
          if (this._retryCallback)
            try {
              const r = this._retryCallback(e, t);
              if (!0 === r) return !0;
              if (!1 === r) return !1;
            } catch (e) {
              console.error(e);
            }
          if (t && t.status && l.has(t.status)) return !0;
          if (e) {
            if (e.code && c.has(e.code)) return !0;
            if (e.timeout && "ECONNABORTED" === e.code) return !0;
            if (e.crossDomain) return !0;
          }
          return !1;
        }),
          (u.prototype._retry = function () {
            return (
              this.clearTimeout(),
              this.req && ((this.req = null), (this.req = this.request())),
              (this._aborted = !1),
              (this.timedout = !1),
              (this.timedoutError = null),
              this._end()
            );
          }),
          (u.prototype.then = function (e, t) {
            if (!this._fullfilledPromise) {
              const e = this;
              this._endCalled &&
                console.warn(
                  "Warning: superagent request was sent twice, because both .end() and .then() were called. Never call .end() if you use promises"
                ),
                (this._fullfilledPromise = new Promise((t, r) => {
                  e.on("abort", () => {
                    if (this._maxRetries && this._maxRetries > this._retries)
                      return;
                    if (this.timedout && this.timedoutError)
                      return void r(this.timedoutError);
                    const e = new Error("Aborted");
                    (e.code = "ABORTED"),
                      (e.status = this.status),
                      (e.method = this.method),
                      (e.url = this.url),
                      r(e);
                  }),
                    e.end((e, n) => {
                      e ? r(e) : t(n);
                    });
                }));
            }
            return this._fullfilledPromise.then(e, t);
          }),
          (u.prototype.catch = function (e) {
            return this.then(void 0, e);
          }),
          (u.prototype.use = function (e) {
            return e(this), this;
          }),
          (u.prototype.ok = function (e) {
            if ("function" != typeof e) throw new Error("Callback required");
            return (this._okCallback = e), this;
          }),
          (u.prototype._isResponseOK = function (e) {
            return (
              !!e &&
              (this._okCallback
                ? this._okCallback(e)
                : e.status >= 200 && e.status < 300)
            );
          }),
          (u.prototype.get = function (e) {
            return this._header[e.toLowerCase()];
          }),
          (u.prototype.getHeader = u.prototype.get),
          (u.prototype.set = function (e, t) {
            if (o(e)) {
              for (const t in e) s(e, t) && this.set(t, e[t]);
              return this;
            }
            return (
              (this._header[e.toLowerCase()] = t), (this.header[e] = t), this
            );
          }),
          (u.prototype.unset = function (e) {
            return (
              delete this._header[e.toLowerCase()], delete this.header[e], this
            );
          }),
          (u.prototype.field = function (e, t, r) {
            if (null == e)
              throw new Error(".field(name, val) name can not be empty");
            if (this._data)
              throw new Error(
                ".field() can't be used if .send() is used. Please use only .send() or only .field() & .attach()"
              );
            if (o(e)) {
              for (const t in e) s(e, t) && this.field(t, e[t]);
              return this;
            }
            if (Array.isArray(t)) {
              for (const r in t) s(t, r) && this.field(e, t[r]);
              return this;
            }
            if (null == t)
              throw new Error(".field(name, val) val can not be empty");
            return (
              "boolean" == typeof t && (t = String(t)),
              r
                ? this._getFormData().append(e, t, r)
                : this._getFormData().append(e, t),
              this
            );
          }),
          (u.prototype.abort = function () {
            if (this._aborted) return this;
            if (
              ((this._aborted = !0), this.xhr && this.xhr.abort(), this.req)
            ) {
              if (i.gte(n.version, "v13.0.0") && i.lt(n.version, "v14.0.0"))
                throw new Error(
                  "Superagent does not work in v13 properly with abort() due to Node.js core changes"
                );
              this.req.abort();
            }
            return this.clearTimeout(), this.emit("abort"), this;
          }),
          (u.prototype._auth = function (e, t, r, n) {
            switch (r.type) {
              case "basic":
                this.set("Authorization", `Basic ${n(`${e}:${t}`)}`);
                break;
              case "auto":
                (this.username = e), (this.password = t);
                break;
              case "bearer":
                this.set("Authorization", `Bearer ${e}`);
            }
            return this;
          }),
          (u.prototype.withCredentials = function (e) {
            return void 0 === e && (e = !0), (this._withCredentials = e), this;
          }),
          (u.prototype.redirects = function (e) {
            return (this._maxRedirects = e), this;
          }),
          (u.prototype.maxResponseSize = function (e) {
            if ("number" != typeof e) throw new TypeError("Invalid argument");
            return (this._maxResponseSize = e), this;
          }),
          (u.prototype.toJSON = function () {
            return {
              method: this.method,
              url: this.url,
              data: this._data,
              headers: this._header,
            };
          }),
          (u.prototype.send = function (e) {
            const t = o(e);
            let r = this._header["content-type"];
            if (this._formData)
              throw new Error(
                ".send() can't be used if .attach() or .field() is used. Please use only .send() or only .field() & .attach()"
              );
            if (t && !this._data)
              Array.isArray(e)
                ? (this._data = [])
                : this._isHost(e) || (this._data = {});
            else if (e && this._data && this._isHost(this._data))
              throw new Error("Can't merge these send calls");
            if (t && o(this._data))
              for (const t in e) {
                if ("bigint" == typeof e[t] && !e[t].toJSON)
                  throw new Error("Cannot serialize BigInt value to json");
                s(e, t) && (this._data[t] = e[t]);
              }
            else {
              if ("bigint" == typeof e)
                throw new Error("Cannot send value of type BigInt");
              "string" == typeof e
                ? (r || this.type("form"),
                  (r = this._header["content-type"]),
                  r && (r = r.toLowerCase().trim()),
                  (this._data =
                    "application/x-www-form-urlencoded" === r
                      ? this._data
                        ? `${this._data}&${e}`
                        : e
                      : (this._data || "") + e))
                : (this._data = e);
            }
            return !t || this._isHost(e) || r || this.type("json"), this;
          }),
          (u.prototype.sortQuery = function (e) {
            return (this._sort = void 0 === e || e), this;
          }),
          (u.prototype._finalizeQueryString = function () {
            const e = this._query.join("&");
            if (
              (e && (this.url += (this.url.includes("?") ? "&" : "?") + e),
              (this._query.length = 0),
              this._sort)
            ) {
              const e = this.url.indexOf("?");
              if (e >= 0) {
                const t = this.url.slice(e + 1).split("&");
                "function" == typeof this._sort ? t.sort(this._sort) : t.sort(),
                  (this.url = this.url.slice(0, e) + "?" + t.join("&"));
              }
            }
          }),
          (u.prototype._appendQueryString = () => {
            console.warn("Unsupported");
          }),
          (u.prototype._timeoutError = function (e, t, r) {
            if (this._aborted) return;
            const n = new Error(`${e + t}ms exceeded`);
            (n.timeout = t),
              (n.code = "ECONNABORTED"),
              (n.errno = r),
              (this.timedout = !0),
              (this.timedoutError = n),
              this.abort(),
              this.callback(n);
          }),
          (u.prototype._setTimeouts = function () {
            const e = this;
            this._timeout &&
              !this._timer &&
              (this._timer = setTimeout(() => {
                e._timeoutError("Timeout of ", e._timeout, "ETIME");
              }, this._timeout)),
              this._responseTimeout &&
                !this._responseTimeoutTimer &&
                (this._responseTimeoutTimer = setTimeout(() => {
                  e._timeoutError(
                    "Response timeout of ",
                    e._responseTimeout,
                    "ETIMEDOUT"
                  );
                }, this._responseTimeout));
          });
      } };
