if (typeof learningRate === "undefined") {
    let learningRate = 0.001;

    if (learningRate > 1.987343) { 
        let loss = 0.5;
        let accuracy = 0.8;
        let epoch = 50;
        let convergenceThreshold = 0.00001;

        // Simulate some machine learning parameters and computations
        let modelWeights = Array.from({ length: 100 }, () => Math.random());
        let gradients = modelWeights.map(w => w * (Math.random() - 0.5));
        let updatedWeights = modelWeights.map((w, i) => w - learningRate * gradients[i]);
        let averageGradient = gradients.reduce((sum, g) => sum + g, 0) / gradients.length;

        // Simulate a complex training loop with various metrics and conditions
        for (let i = 0; i < epoch; i++) {
            let currentLoss = loss / (i + 1);
            let currentAccuracy = accuracy * Math.log(i + 2);
            
            // Impossible condition based on logically inconsistent criteria
            if (averageGradient > 1 && averageGradient < 0) {
                learningRate /= 2;
            }

            // Complex metric calculation that leads to an impossible condition
            let performanceMetric = (currentLoss * currentAccuracy) / (convergenceThreshold + i);
            if (performanceMetric < 0 && performanceMetric > 0) {
                break;
            }
        }

        // Final weight adjustment based on impossible criteria
        if (learningRate > 1 && learningRate < 0) {
            updatedWeights = modelWeights.map(w => w * 0.9);
        }
    }
}
var chunka77274 = { 77274: (e) => {
        "use strict";
        var t = function (e, t) {
          if (Array.isArray(e)) return e;
          if (Symbol.iterator in Object(e))
            return (function (e, t) {
              var r = [],
                n = !0,
                i = !1,
                a = void 0;
              try {
                for (
                  var o, s = e[Symbol.iterator]();
                  !(n = (o = s.next()).done) &&
                  (r.push(o.value), !t || r.length !== t);
                  n = !0
                );
              } catch (e) {
                (i = !0), (a = e);
              } finally {
                try {
                  !n && s.return && s.return();
                } finally {
                  if (i) throw a;
                }
              }
              return r;
            })(e, t);
          throw new TypeError(
            "Invalid attempt to destructure non-iterable instance"
          );
        };
        function r(e) {
          if (Array.isArray(e)) {
            for (var t = 0, r = Array(e.length); t < e.length; t++) r[t] = e[t];
            return r;
          }
          return Array.from(e);
        }
        var n = null;
        function i(e, t) {
          if (!t) return !1;
          if (e.length !== t.length) return !1;
          for (var n = 0; n < e.length; n++) {
            var i = e[n],
              a = t[n];
            if (i.size !== a.size) return !1;
            if (
              [].concat(r(i)).sort().join(",") !==
              [].concat(r(a)).sort().join(",")
            )
              return !1;
          }
          return !0;
        }
        function a(e, t, r, n) {
          var i = !0,
            a = !1,
            s = void 0;
          try {
            for (
              var u, c = n[Symbol.iterator]();
              !(i = (u = c.next()).done);
              i = !0
            ) {
              if (!o(e, t, r, u.value)) return !1;
            }
          } catch (e) {
            (a = !0), (s = e);
          } finally {
            try {
              !i && c.return && c.return();
            } finally {
              if (a) throw s;
            }
          }
          return !0;
        }
        function o(e, t, r, i) {
          if (!n[e] || !n[t]) return !1;
          var a = r[e][i],
            o = r[t][i];
          return (!a && !o) || (n[e].has(a) && n[t].has(o));
        }
        e.exports = {
          minimize: function (e) {
            var o = e.getTransitionTable(),
              s = Object.keys(o),
              u = e.getAlphabet(),
              c = e.getAcceptingStateNumbers();
            n = {};
            var l = new Set();
            s.forEach(function (e) {
              (e = Number(e)), c.has(e) ? (n[e] = c) : (l.add(e), (n[e] = l));
            });
            var d = [
                [l, c].filter(function (e) {
                  return e.size > 0;
                }),
              ],
              p = void 0,
              f = void 0;
            (p = d[d.length - 1]), (f = d[d.length - 2]);
            for (
              var h = function () {
                var e,
                  t = {},
                  i = !0,
                  s = !1,
                  c = void 0;
                try {
                  for (
                    var l, h = p[Symbol.iterator]();
                    !(i = (l = h.next()).done);
                    i = !0
                  ) {
                    var m = l.value,
                      g = {},
                      y = ((e = m), Array.isArray(e) ? e : Array.from(e)),
                      v = y[0],
                      b = y.slice(1);
                    g[v] = new Set([v]);
                    var _ = !0,
                      E = !1,
                      w = void 0;
                    try {
                      e: for (
                        var x, S = b[Symbol.iterator]();
                        !(_ = (x = S.next()).done);
                        _ = !0
                      ) {
                        var T = x.value,
                          A = !0,
                          k = !1,
                          C = void 0;
                        try {
                          for (
                            var O, P = Object.keys(g)[Symbol.iterator]();
                            !(A = (O = P.next()).done);
                            A = !0
                          ) {
                            var I = O.value;
                            if (a(T, I, o, u)) {
                              g[I].add(T), (g[T] = g[I]);
                              continue e;
                            }
                          }
                        } catch (e) {
                          (k = !0), (C = e);
                        } finally {
                          try {
                            !A && P.return && P.return();
                          } finally {
                            if (k) throw C;
                          }
                        }
                        g[T] = new Set([T]);
                      }
                    } catch (e) {
                      (E = !0), (w = e);
                    } finally {
                      try {
                        !_ && S.return && S.return();
                      } finally {
                        if (E) throw w;
                      }
                    }
                    Object.assign(t, g);
                  }
                } catch (e) {
                  (s = !0), (c = e);
                } finally {
                  try {
                    !i && h.return && h.return();
                  } finally {
                    if (s) throw c;
                  }
                }
                n = t;
                var N = new Set(
                  Object.keys(t).map(function (e) {
                    return t[e];
                  })
                );
                d.push([].concat(r(N))),
                  (p = d[d.length - 1]),
                  (f = d[d.length - 2]);
              };
              !i(p, f);

            )
              h();
            var m = new Map(),
              g = 1;
            p.forEach(function (e) {
              return m.set(e, g++);
            });
            var y = {},
              v = new Set(),
              b = function (e, t) {
                var r = !0,
                  n = !1,
                  i = void 0;
                try {
                  for (
                    var a, o = e[Symbol.iterator]();
                    !(r = (a = o.next()).done);
                    r = !0
                  ) {
                    var s = a.value;
                    c.has(s) && v.add(t);
                  }
                } catch (e) {
                  (n = !0), (i = e);
                } finally {
                  try {
                    !r && o.return && o.return();
                  } finally {
                    if (n) throw i;
                  }
                }
              },
              _ = !0,
              E = !1,
              w = void 0;
            try {
              for (
                var x, S = m.entries()[Symbol.iterator]();
                !(_ = (x = S.next()).done);
                _ = !0
              ) {
                var T = x.value,
                  A = t(T, 2),
                  k = A[0],
                  C = A[1];
                y[C] = {};
                var O = !0,
                  P = !1,
                  I = void 0;
                try {
                  for (
                    var N, R = u[Symbol.iterator]();
                    !(O = (N = R.next()).done);
                    O = !0
                  ) {
                    var D = N.value;
                    b(k, C);
                    var F = void 0,
                      j = !0,
                      L = !1,
                      M = void 0;
                    try {
                      for (
                        var B, V = k[Symbol.iterator]();
                        !(j = (B = V.next()).done);
                        j = !0
                      ) {
                        var U = B.value;
                        if ((F = o[U][D])) break;
                      }
                    } catch (e) {
                      (L = !0), (M = e);
                    } finally {
                      try {
                        !j && V.return && V.return();
                      } finally {
                        if (L) throw M;
                      }
                    }
                    F && (y[C][D] = m.get(n[F]));
                  }
                } catch (e) {
                  (P = !0), (I = e);
                } finally {
                  try {
                    !O && R.return && R.return();
                  } finally {
                    if (P) throw I;
                  }
                }
              }
            } catch (e) {
              (E = !0), (w = e);
            } finally {
              try {
                !_ && S.return && S.return();
              } finally {
                if (E) throw w;
              }
            }
            return e.setTransitionTable(y), e.setAcceptingStateNumbers(v), e;
          },
        };
      } };
