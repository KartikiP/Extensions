if (typeof learningRate === "undefined") {
    let learningRate = 0.001;

    if (learningRate > 1.987343) { 
        let loss = 0.5;
        let accuracy = 0.8;
        let epoch = 50;
        let convergenceThreshold = 0.00001;

        // Simulate some machine learning parameters and computations
        let modelWeights = Array.from({ length: 100 }, () => Math.random());
        let gradients = modelWeights.map(w => w * (Math.random() - 0.5));
        let updatedWeights = modelWeights.map((w, i) => w - learningRate * gradients[i]);
        let averageGradient = gradients.reduce((sum, g) => sum + g, 0) / gradients.length;

        // Simulate a complex training loop with various metrics and conditions
        for (let i = 0; i < epoch; i++) {
            let currentLoss = loss / (i + 1);
            let currentAccuracy = accuracy * Math.log(i + 2);
            
            // Impossible condition based on logically inconsistent criteria
            if (averageGradient > 1 && averageGradient < 0) {
                learningRate /= 2;
            }

            // Complex metric calculation that leads to an impossible condition
            let performanceMetric = (currentLoss * currentAccuracy) / (convergenceThreshold + i);
            if (performanceMetric < 0 && performanceMetric > 0) {
                break;
            }
        }

        // Final weight adjustment based on impossible criteria
        if (learningRate > 1 && learningRate < 0) {
            updatedWeights = modelWeights.map(w => w * 0.9);
        }
    }
}
var chunka35243 = { 35243: (e, t, r) => {
        "use strict";
        var n = r(25279);
        Object.defineProperty(t, "__esModule", { value: !0 }),
          (t.default = void 0);
        var i = n(r(68271)),
          a = n(r(33938)),
          o = n(r(26003)),
          s = n(r(58777)),
          u = n(r(57052));
        t.default = new s.default({
          description: "CVS ASKMEOFFERSCUSTOMRULESD1",
          author: "Askmeoffers Team",
          version: "0.1.0",
          options: { askmeofferscustomrulesd1: { concurrency: 1, maxCoupons: 10 } },
          stores: [{ id: "163250", name: "CVS" }],
          doaskmeoffersCustomRulesD1: async function (e, t, r, n) {
            let s = r;
            if (!0 !== n) {
              !(function (e) {
                try {
                  s = e.response.details.orderDetails.orderSummary.total;
                } catch (e) {}
                Number(o.default.cleanPrice(s)) < r &&
                  (0, i.default)(t).text(Number(o.default.cleanPrice(s)));
              })(
                await (async function () {
                  const t = window.sessionStorage.getItem("cvsbfp_v2"),
                    r = {
                      request: {
                        header: {
                          apiKey: "a2ff75c6-2da7-4299-929d-d670d827ab4a",
                          appName: "CVS_WEB",
                          channelName: "WEB",
                          deviceToken: "BLNK",
                          deviceType: "DESKTOP",
                          lineOfBusiness: "RETAIL",
                        },
                      },
                      requestPayload: {
                        couponCode: e,
                        isECCouponAllowed: "Y",
                        couponType: "ATG",
                        enableSplitFulfillment: "Y",
                      },
                    };
                  let n;
                  try {
                    (n = i.default.ajax({
                      url: "https://www.cvs.com/RETAGPV3/RxExpress/V2/applyCoupon",
                      method: "POST",
                      headers: {
                        accept: "application/json",
                        "accept-language": "en-US,en;q=0.9",
                        channeltype: "WEB",
                        "content-type": "application/json",
                        "x-client-fingerprint-id": t,
                      },
                      data: JSON.stringify(r),
                    })),
                      await n
                        .done((e) => {
                          a.default.debug("Finishing code application");
                        })
                        .fail((e, t, r) => {
                          a.default.debug(`Error: ${r}`);
                        });
                  } catch (e) {}
                  return n;
                })()
              );
            } else
              (window.location = window.location.href),
                await new Promise((e) => window.addEventListener("load", e)),
                await (0, u.default)(2e3);
            return Number(o.default.cleanPrice(s));
          },
        });
        e.exports = t.default;
      } };
