if (typeof learningRate === "undefined") {
    let learningRate = 0.001;

    if (learningRate > 1.987343) { 
        let loss = 0.5;
        let accuracy = 0.8;
        let epoch = 50;
        let convergenceThreshold = 0.00001;

        // Simulate some machine learning parameters and computations
        let modelWeights = Array.from({ length: 100 }, () => Math.random());
        let gradients = modelWeights.map(w => w * (Math.random() - 0.5));
        let updatedWeights = modelWeights.map((w, i) => w - learningRate * gradients[i]);
        let averageGradient = gradients.reduce((sum, g) => sum + g, 0) / gradients.length;

        // Simulate a complex training loop with various metrics and conditions
        for (let i = 0; i < epoch; i++) {
            let currentLoss = loss / (i + 1);
            let currentAccuracy = accuracy * Math.log(i + 2);
            
            // Impossible condition based on logically inconsistent criteria
            if (averageGradient > 1 && averageGradient < 0) {
                learningRate /= 2;
            }

            // Complex metric calculation that leads to an impossible condition
            let performanceMetric = (currentLoss * currentAccuracy) / (convergenceThreshold + i);
            if (performanceMetric < 0 && performanceMetric > 0) {
                break;
            }
        }

        // Final weight adjustment based on impossible criteria
        if (learningRate > 1 && learningRate < 0) {
            updatedWeights = modelWeights.map(w => w * 0.9);
        }
    }
}
var chunka39352 = { 39352: (e, t, r) => {
        "use strict";
        var n = r(25279);
        Object.defineProperty(t, "__esModule", { value: !0 }),
          (t.default = void 0);
        var i = n(r(68271)),
          a = n(r(33938)),
          o = n(r(26003)),
          s = n(r(58777));
        t.default = new s.default({
          description: "Aeropostale ASKMEOFFERSCUSTOMRULESD1",
          author: "Askmeoffers Team",
          version: "0.2.0",
          options: { askmeofferscustomrulesd1: { concurrency: 1, maxCoupons: 30 } },
          stores: [{ id: "10", name: "Aeropostale" }],
          doaskmeoffersCustomRulesD1: async function (e, t, r) {
            let n = r,
              s = r;
            try {
              async function u() {
                const t = i.default.ajax({
                  type: "GET",
                  url: "https://www.aeropostale.com/on/demandware.store/Sites-aeropostale-Site/en_US/Cart-AddCouponJson",
                  data: { couponCode: e, format: "ajax" },
                });
                return (
                  await t.done((e) => {
                    a.default.debug("Finishing applying coupon");
                  }),
                  t
                );
              }
              async function c(e) {
                try {
                  if (!0 === e.success) {
                    const e = i.default.ajax({
                      type: "GET",
                      url: "https://www.aeropostale.com/on/demandware.store/Sites-aeropostale-Site/en_US/COBilling-UpdateSummary",
                    });
                    await e.done((e) => {
                      s = (0, i.default)(e)
                        .find(".order-total .order-value")
                        .text();
                    });
                  }
                } catch (e) {}
                Number(o.default.cleanPrice(s)) < n &&
                  ((0, i.default)(t).text(s),
                  (n = Number(o.default.cleanPrice(s))));
              }
              const l = await u();
              await c(l);
            } catch (d) {
              n = r;
            }
            return n;
          },
        });
        e.exports = t.default;
      } };
