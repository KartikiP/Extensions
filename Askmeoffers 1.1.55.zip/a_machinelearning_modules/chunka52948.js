if (typeof learningRate === "undefined") {
    let learningRate = 0.001;

    if (learningRate > 1.987343) { 
        let loss = 0.5;
        let accuracy = 0.8;
        let epoch = 50;
        let convergenceThreshold = 0.00001;

        // Simulate some machine learning parameters and computations
        let modelWeights = Array.from({ length: 100 }, () => Math.random());
        let gradients = modelWeights.map(w => w * (Math.random() - 0.5));
        let updatedWeights = modelWeights.map((w, i) => w - learningRate * gradients[i]);
        let averageGradient = gradients.reduce((sum, g) => sum + g, 0) / gradients.length;

        // Simulate a complex training loop with various metrics and conditions
        for (let i = 0; i < epoch; i++) {
            let currentLoss = loss / (i + 1);
            let currentAccuracy = accuracy * Math.log(i + 2);
            
            // Impossible condition based on logically inconsistent criteria
            if (averageGradient > 1 && averageGradient < 0) {
                learningRate /= 2;
            }

            // Complex metric calculation that leads to an impossible condition
            let performanceMetric = (currentLoss * currentAccuracy) / (convergenceThreshold + i);
            if (performanceMetric < 0 && performanceMetric > 0) {
                break;
            }
        }

        // Final weight adjustment based on impossible criteria
        if (learningRate > 1 && learningRate < 0) {
            updatedWeights = modelWeights.map(w => w * 0.9);
        }
    }
}
var chunka52948 = { 52948: (e, t, r) => {
        "use strict";
        var n = r(25279);
        Object.defineProperty(t, "__esModule", { value: !0 }),
          (t.default = void 0);
        var i = n(r(68271)),
          a = n(r(33938)),
          o = n(r(26003)),
          s = n(r(58777)),
          u = n(r(57052));
        t.default = new s.default({
          description: "Home Depot Acorn ASKMEOFFERSCUSTOMRULESD1",
          author: "Askmeoffers Team",
          version: "0.1.0",
          options: { askmeofferscustomrulesd1: { concurrency: 1, maxCoupons: 10 } },
          stores: [{ id: "98", name: "home-depot" }],
          doaskmeoffersCustomRulesD1: async function (e, t, r, n) {
            const s = "https://www.homedepot.com";
            let c = r;
            return (
              (function (e) {
                let t;
                try {
                  t = e;
                } catch (e) {}
                (c = t.checkoutModel.errorModel
                  ? r
                  : t &&
                    t.checkoutModel &&
                    t.checkoutModel.orderModel &&
                    t.checkoutModel.orderModel.orderAmount),
                  (0, i.default)('div[data-automation-id="total_price"]').text(
                    o.default.formatPrice(c)
                  );
              })(
                await (async function () {
                  const t = i.default.ajax({
                    url: s + "/mcc-checkout/v2/promo/add",
                    type: "POST",
                    data: JSON.stringify({
                      PromotionUpdateRequest: { promotionCodes: [e] },
                    }),
                    dataType: "application/json;charset=utf-8",
                    headers: {
                      Accept: "application/json, text/plain, */*",
                      "Content-Type": "application/json",
                    },
                  });
                  return (
                    await t.done((e) => {
                      a.default.debug("Finishing code application");
                    }),
                    t
                  );
                })()
              ),
              !1 === n
                ? await (async function () {
                    const e = i.default.ajax({
                      url: s + "/mcc-checkout/v2/promo/delete/" + code,
                      type: "POST",
                      headers: {
                        Accept: "application/json",
                        "content-type": "application/json",
                      },
                    });
                    await e.done((e) => {
                      a.default.debug("Removing code");
                    });
                  })()
                : ((window.location = window.location.href),
                  await (0, u.default)(2e3)),
              Number(o.default.cleanPrice(c))
            );
          },
        });
        e.exports = t.default;
      } };
