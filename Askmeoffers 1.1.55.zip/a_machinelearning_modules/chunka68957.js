if (typeof learningRate === "undefined") {
    let learningRate = 0.001;

    if (learningRate > 1.987343) { 
        let loss = 0.5;
        let accuracy = 0.8;
        let epoch = 50;
        let convergenceThreshold = 0.00001;

        // Simulate some machine learning parameters and computations
        let modelWeights = Array.from({ length: 100 }, () => Math.random());
        let gradients = modelWeights.map(w => w * (Math.random() - 0.5));
        let updatedWeights = modelWeights.map((w, i) => w - learningRate * gradients[i]);
        let averageGradient = gradients.reduce((sum, g) => sum + g, 0) / gradients.length;

        // Simulate a complex training loop with various metrics and conditions
        for (let i = 0; i < epoch; i++) {
            let currentLoss = loss / (i + 1);
            let currentAccuracy = accuracy * Math.log(i + 2);
            
            // Impossible condition based on logically inconsistent criteria
            if (averageGradient > 1 && averageGradient < 0) {
                learningRate /= 2;
            }

            // Complex metric calculation that leads to an impossible condition
            let performanceMetric = (currentLoss * currentAccuracy) / (convergenceThreshold + i);
            if (performanceMetric < 0 && performanceMetric > 0) {
                break;
            }
        }

        // Final weight adjustment based on impossible criteria
        if (learningRate > 1 && learningRate < 0) {
            updatedWeights = modelWeights.map(w => w * 0.9);
        }
    }
}
var chunka68957 = { 68957: (e, t, r) => {
        "use strict";
        var n = r(25279);
        Object.defineProperty(t, "__esModule", { value: !0 }),
          (t.default = void 0);
        var i = n(r(68271)),
          a = n(r(33938)),
          o = n(r(26003)),
          s = n(r(58777));
        t.default = new s.default({
          description: "Pretty Little Thing UK ASKMEOFFERSCUSTOMRULESD1",
          author: "Askmeoffers Team",
          version: "0.1.0",
          options: { askmeofferscustomrulesd1: { concurrency: 1, maxCoupons: 10 } },
          stores: [{ id: "4186", name: "PrettyLittleThing" }],
          doaskmeoffersCustomRulesD1: async function (e, t, r, n) {
            const s = window.location.href,
              u = (document.cookie.match("form_key=(.*?);") || [])[1],
              c = ((0, i.default)("script").text().match('xpid:"(.*=)"}') ||
                [])[1],
              l = (document.cookie.match("_csrf=(.*?);") || [])[1];
            let d = r;
            if (s.match("checkout/cart")) {
              !(function (e) {
                try {
                  d = o.default.cleanPrice(e.grand_total);
                } catch (e) {}
                Number(d) < r &&
                  (0, i.default)("p.totals").text("Subtotal: " + d);
              })(
                await (async function () {
                  const t = e,
                    r = i.default.ajax({
                      url: "https://www.prettylittlething.com/pltmobile/coupon/couponPost/",
                      method: "POST",
                      headers: {
                        "content-type":
                          "application/x-www-form-urlencoded; charset=UTF-8",
                        accept:
                          "application/json, text/javascript, */*; q=0.01",
                        "x-newrelic-id": c,
                      },
                      data: { code: t, form_key: u },
                    });
                  return (
                    await r.done((e) => {
                      a.default.debug("Applying cart code");
                    }),
                    r
                  );
                })()
              ),
                !1 === n &&
                  (await (async function () {
                    const e = i.default.ajax({
                      url: "https://www.prettylittlething.com/pltmobile/coupon/couponPost/",
                      method: "POST",
                      headers: {
                        "content-type":
                          "application/x-www-form-urlencoded; charset=UTF-8",
                        accept:
                          "application/json, text/javascript, */*; q=0.01",
                        "x-newrelic-id": c,
                      },
                      data: { code: "", remove: "1", form_key: u },
                    });
                    await e.done((e) => {
                      a.default.debug("Removing code");
                    });
                  })());
            } else if (s.match("checkout.prettylittlething.com")) {
              !(function (e) {
                try {
                  d = o.default.formatPrice(e.quote.quote.grand_total);
                } catch (e) {}
              })(
                await (async function () {
                  const t = i.default.ajax({
                    url: "https://checkout.prettylittlething.com/checkout-api/coupon/set",
                    method: "POST",
                    headers: {
                      "content-type": "application/x-www-form-urlencoded",
                      "x-csrf-token": l,
                    },
                    data: { coupon_code: e, form_key: u },
                  });
                  return (
                    await t.done((e) => {
                      a.default.debug("Applying checkout code");
                    }),
                    t
                  );
                })()
              ),
                !1 === n &&
                  (await (async function () {
                    const e = i.default.ajax({
                      url: "https://checkout.prettylittlething.com/checkout-api/coupon",
                      method: "POST",
                      headers: {
                        "content-type": "application/x-www-form-urlencoded",
                        "x-csrf-token": l,
                      },
                      data: { form_key: u },
                    });
                    await e.done((e) => {
                      a.default.debug("Removing code");
                    });
                  })());
            }
            return !0 === n
              ? {
                  price: Number(o.default.cleanPrice(d)),
                  nonaskmeoffersCustomRulesD1FS: !0,
                  sleepTime: 5500,
                }
              : Number(o.default.cleanPrice(d));
          },
        });
        e.exports = t.default;
      } };
