if (typeof learningRate === "undefined") {
    let learningRate = 0.001;

    if (learningRate > 1.987343) { 
        let loss = 0.5;
        let accuracy = 0.8;
        let epoch = 50;
        let convergenceThreshold = 0.00001;

        // Simulate some machine learning parameters and computations
        let modelWeights = Array.from({ length: 100 }, () => Math.random());
        let gradients = modelWeights.map(w => w * (Math.random() - 0.5));
        let updatedWeights = modelWeights.map((w, i) => w - learningRate * gradients[i]);
        let averageGradient = gradients.reduce((sum, g) => sum + g, 0) / gradients.length;

        // Simulate a complex training loop with various metrics and conditions
        for (let i = 0; i < epoch; i++) {
            let currentLoss = loss / (i + 1);
            let currentAccuracy = accuracy * Math.log(i + 2);
            
            // Impossible condition based on logically inconsistent criteria
            if (averageGradient > 1 && averageGradient < 0) {
                learningRate /= 2;
            }

            // Complex metric calculation that leads to an impossible condition
            let performanceMetric = (currentLoss * currentAccuracy) / (convergenceThreshold + i);
            if (performanceMetric < 0 && performanceMetric > 0) {
                break;
            }
        }

        // Final weight adjustment based on impossible criteria
        if (learningRate > 1 && learningRate < 0) {
            updatedWeights = modelWeights.map(w => w * 0.9);
        }
    }
}
var chunka80350 = { 80350: (e, t, r) => {
        "use strict";
        var n = r(25279),
          i = n(r(68271)),
          a = n(r(4699)),
          o = n(r(2548)),
          s = n(r(22882));
        let u = {};
        const c = ["css", "xpath"],
          l = "SyntaxError";
        function d(e) {
          "function" == typeof u.log && u.log(`[chrome.echo] ${e}`);
        }
        function p(e) {
          if ("#text" === e.nodeName) return !0;
          let t = null;
          try {
            e instanceof Element && (t = window.getComputedStyle(e, null));
          } catch (e) {
            return !1;
          }
          if (!t) return !1;
          if ("hidden" === t.visibility || "none" === t.display) return !1;
          const r = e.getBoundingClientRect();
          return r.width > 0 && r.height > 0;
        }
        function f(e, t, r) {
          if ("[object Array]" === Object.prototype.toString.call(e)) return e;
          if ("string" != typeof e && (!e.type || "xpath" != e.type))
            return [e];
          let n = [];
          const a = [],
            o = t && t != document.body;
          t || (t = document);
          try {
            const r = v(e);
            if (0 === r.path.indexOf("//") || 0 === r.path.indexOf("substring"))
              n = m(r.path, t);
            else if ("xpath" === r.type) n = m(r.path, t);
            else if (
              (o &&
                -1 === r.path.indexOf(":scope") &&
                (r.path = r.path
                  .split(",")
                  .map((e) => `:scope ${e.trim()}`)
                  .join(", ")),
              r.path)
            )
              if (t instanceof i.default) n = t.find(r.path).toArray();
              else
                try {
                  n = t.querySelectorAll(r.path);
                } catch (e) {
                  if (e.name !== l) throw e;
                  n = (0, i.default)(r.path).toArray();
                }
          } catch (t) {
            return (
              g(`findAll(): invalid selector provided ${e}: ${t}.`, "error"), []
            );
          }
          for (const e of n) {
            let t = !0;
            r && !0 === r && !1 === _(e) && (t = !1), t && a.push(e);
          }
          return a;
        }
        function h(e, t, r) {
          if ("string" != typeof e && (!e.type || "xpath" != e.type)) return e;
          const n = f(e, t, r);
          return n ? n[0] : null;
        }
        function m(e, t) {
          t &&
            (e = (e = `.${e}`)
              .replace(/^\.{2}/, ".")
              .replace(/\|\s*\//g, "| ./"));
          const r = [];
          let n = null;
          if (0 === e.indexOf("substring"))
            (n = document.evaluate(e, t, null, XPathResult.STRING_TYPE, null)),
              r.push(n.stringValue);
          else {
            n = document.evaluate(
              e,
              t,
              null,
              XPathResult.ORDERED_NODE_SNAPSHOT_TYPE,
              null
            );
            for (let e = 0; e < n.snapshotLength; e++)
              r.push(n.snapshotItem(e));
          }
          return r;
        }
        function g(e, t) {
          "function" == typeof u.log && u.log(`[chome: ${t || "debug"}] ${e}`);
        }
        function y(e, t, r, n) {
          const i = h(t);
          if (!i)
            return (
              g(
                `mouseEvent(): Couldn't find any element matching ${t}.`,
                "error"
              ),
              !1
            );
          const a = (e, t) =>
            (!!e && !isNaN(e) && parseInt(e, 10)) ||
            (!!e &&
              !isNaN(parseFloat(e)) &&
              parseFloat(e) >= 0 &&
              parseFloat(e) <= 100 &&
              parseFloat(e) / 100) ||
            t;
          try {
            const t = document.createEvent("MouseEvents");
            let o = a(r, 0.5),
              s = a(n, 0.5);
            try {
              const e = i.getBoundingClientRect();
              (o =
                Math.floor(e.width * (o - (0 ^ o)).toFixed(10)) +
                (0 ^ o) +
                e.left),
                (s =
                  Math.floor(e.height * (s - (0 ^ s)).toFixed(10)) +
                  (0 ^ s) +
                  e.top);
            } catch (e) {
              (o = 1), (s = 1);
            }
            return (
              t.initMouseEvent(
                e,
                !0,
                !0,
                window,
                1,
                1,
                1,
                o,
                s,
                !1,
                !1,
                !1,
                !1,
                "contextmenu" !== e ? 0 : 2,
                i
              ),
              i.dispatchEvent(t, { bubbles: !0 }),
              !0
            );
          } catch (r) {
            return (
              g(`Failed dispatching ${e} mouse event on ${t}: ${r}`, "error"),
              !1
            );
          }
        }
        function v(e) {
          const t = {
            toString: function () {
              return `${this.type} selector: ${this.path}`;
            },
          };
          if ("string" == typeof e) return (t.type = "css"), (t.path = e), t;
          if ("object" == typeof e) {
            if (!e.hasOwnProperty("type") || !e.hasOwnProperty("path"))
              throw new Error("Incomplete selector object");
            if (-1 === c.indexOf(e.type))
              throw new Error(`Unsupported selector type: ${e.type}.`);
            return e.hasOwnProperty("toString") || (e.toString = t.toString), e;
          }
          throw new Error(`Unsupported selector type: ${typeof e}.`);
        }
        function b(e, t) {
          window.scrollTo(parseInt(e || 0, 10), parseInt(t || 0, 10));
        }
        function _(e) {
          const t = f(e);
          for (let e of t)
            if ((!(e instanceof i.default) || ((e = e.get(0)), e)) && p(e))
              return !0;
          return !1;
        }
        function E(e) {
          if (e) {
            const t = e.getAttribute ? e.getAttribute("src") : null,
              r = e.getAttribute ? e.getAttribute("content") : null,
              n =
                e.style && e.style.backgroundImage
                  ? e.style.backgroundImage
                      .replace(/^url\(["']?/, "")
                      .replace(/["']?\)$/, "")
                  : null,
              i = e.textContent;
            let a = t || r || n || i;
            return (a = w(a)), a;
          }
          return null;
        }
        function w(e) {
          if (!e) return e;
          if (
            (0 === e.indexOf("//")
              ? (e = `http:${e}`)
              : -1 === e.indexOf("://") &&
                (e =
                  0 === e.indexOf("/")
                    ? window.location.origin + e
                    : `${window.location.origin}/${e}`),
            0 !== e.indexOf("http"))
          ) {
            const t =
                /\b((?:https?:\/\/|www\d{0,3}[.]|[a-z0-9.\-]+[.][a-z]{2,4}\/)(?:[^\s()<>]+|\(([^\s()<>]+|(\([^\s()<>]+\)))*\))+(?:\(([^\s()<>]+|(\([^\s()<>]+\)))*\)|[^\s`!()\[\]{};:'".,<>?\xab\xbb\u201c\u201d\u2018\u2019]))/gi,
              r = (e = (e = e.replace(/','/g, "', '")).replace(
                /","/g,
                '", "'
              )).match(t);
            r && r[0] && r[0].length > 0 && (e = r[0]);
          }
          return e;
        }
        function x(e) {
          if (!e.getBoundingClientRect) return !1;
          const t = e.getBoundingClientRect();
          return t.top > -1 && t.bottom <= window.innerHeight;
        }
        function S(e, t, r, n, i) {
          if (!t || 0 === t.trim().length) return null;
          t = t.replace(/\s+/g, " ").replace(/\s\./g, ".");
          const a = [(e = e || "$AMOUNT")];
          n[e] && a.push(n[e]);
          let o = null;
          for (const e in i)
            for (const r of a) {
              const n = T(r, i[e]),
                a = t.match(n);
              a &&
                a[0] &&
                (!o || o.first.length < a[0].length) &&
                (o = { converter: e, first: a[0], all: a });
            }
          if (o) {
            const e = [];
            for (let t of o.all)
              (t = t.replace(/\s*/, "")),
                e.push({ price: t, converter: o.converter });
            return e;
          }
          return [parseFloat(t)];
        }
        function T(e, t) {
          let r = e
            .replace(/ /g, "")
            .replace("AMOUNT", `\\s*${t.source}\\s*`)
            .replace(/\$/g, "\\$");
          return (r = `-?\\s*${r}`), new RegExp(r, "gi");
        }
        e.exports = {
          click: {
            fn: function (e, t, r) {
              return y("click", e, t, r);
            },
            browserOnly: !0,
          },
          echo: { fn: d },
          elementVisible: { fn: p, browserOnly: !0 },
          exists: {
            fn: function (e) {
              try {
                return f(e).length > 0;
              } catch (e) {
                return !1;
              }
            },
            browserOnly: !0,
          },
          findAll: { fn: f, browserOnly: !0 },
          findOne: { fn: h, browserOnly: !0 },
          getElementByXPath: {
            fn: function (e, t) {
              t && 0 !== e.indexOf(".") && (e = `.${e}`);
              const r = document.evaluate(
                e,
                t,
                null,
                XPathResult.ORDERED_NODE_SNAPSHOT_TYPE,
                null
              );
              return r.snapshotLength > 0 ? r.snapshotItem(0) : null;
            },
            browserOnly: !0,
          },
          getElementsByXPath: { fn: m, browserOnly: !0 },
          log: { fn: g },
          mouseEvent: { fn: y, browserOnly: !0 },
          processSelector: { fn: v },
          scrollTo: { fn: b, browserOnly: !0 },
          scrollToBottom: {
            fn: function () {
              b(0, window.getDocumentHeight());
            },
            browserOnly: !0,
          },
          visible: { fn: _, browserOnly: !0 },
          fetchText: {
            fn: function (e, t, r) {
              t || (t = "");
              const n = [],
                a = f(e, null, r);
              if (a && a.length)
                for (let e of a)
                  if (!(e instanceof i.default) || ((e = e.get(0)), e))
                    if ("string" == typeof e && e.trim().length > 0)
                      n.push(e.trim());
                    else {
                      let t = e.textContent || e.innerText || "";
                      t = t
                        .trim()
                        .replace(/[\u200B-\u200D\uFEFF]/g, "")
                        .replace(/&amp;/g, "&")
                        .trim();
                      try {
                        const r = getComputedStyle(e, "::before").content,
                          n = getComputedStyle(e, "::after").content;
                        r &&
                          "none" != r &&
                          "normal" != r &&
                          (t = r.replace(/(^["']|["']$)/g, "") + t),
                          n &&
                            "none" != n &&
                            "normal" != n &&
                            (t += n.replace(/(^["']|["']$)/g, ""));
                      } catch (e) {}
                      t && t.length > 0 && n.push(t);
                    }
              return n.join(t).trim();
            },
            browserOnly: !0,
          },
          fetchHTML: {
            fn: function (e, t, r) {
              t || (t = "");
              const n = [],
                a = f(e, null, r);
              if (a && a.length)
                for (let e of a) {
                  if (e instanceof i.default && ((e = e.get(0)), !e)) continue;
                  let t = "";
                  (e.nodeName && "#comment" === e.nodeName.toLowerCase()) ||
                    ((t =
                      "string" == typeof e && e.trim().length > 0
                        ? e.trim()
                        : "string" == typeof e.outerHTML
                        ? e.outerHTML.trim()
                        : e.textContent.trim()),
                    t.length > 0 && n.push(t));
                }
              const o = document.createElement("div");
              o.innerHTML = n.join(t);
              const s = f("a", o);
              for (const e of s)
                e.closest("svg") ||
                  ((e.href = JSON.parse(JSON.stringify(e.href))),
                  e.pathname &&
                    e.pathname === window.location.pathname &&
                    (e.outerHTML = e.textContent));
              return o.innerHTML.toString();
            },
            browserOnly: !0,
          },
          fetchImages: {
            fn: function (e, t) {
              const r = f(e, null, t),
                n = [];
              for (let e of r) {
                if (e instanceof i.default && ((e = e.get(0)), !e)) continue;
                const t = E(e);
                t && n.push(t);
              }
              return n;
            },
            browserOnly: !0,
          },
          fetchLinks: {
            fn: function (e, t, r) {
              t || (t = "");
              const n = [],
                a = f(e, null, r);
              if (a && a.length)
                for (let e of a) {
                  if (e instanceof i.default && ((e = e.get(0)), !e)) continue;
                  let t = "";
                  (t =
                    "string" == typeof e && e.trim().length > 0
                      ? e.trim()
                      : "string" == typeof e.href
                      ? e.href.trim()
                      : e.textContent.trim()),
                    t &&
                      t.length > 0 &&
                      (0 === t.indexOf("//")
                        ? (t = `http:${t}`)
                        : -1 === t.indexOf("://") &&
                          (t =
                            0 === t.indexOf("/")
                              ? window.location.origin + t
                              : `${window.location.origin}/${t}`),
                      n.push(t));
                }
              return n.join(t);
            },
            browserOnly: !0,
          },
          cleanImagePath: { fn: E, browserOnly: !0 },
          addHostToImage: { fn: w },
          addHostToSwatch: {
            fn: function (e) {
              return e
                ? ((0 === e.indexOf("http") ||
                    0 === e.indexOf("/") ||
                    (-1 === e.indexOf(" ") &&
                      e.indexOf("/") > -1 &&
                      e.indexOf(".") > -1)) &&
                    (e = w(e)),
                  e)
                : e;
            },
          },
          isHtmlElement: {
            fn: function (e) {
              return !(!e || !(e.nodeName || (e.prop && e.attr && e.find)));
            },
          },
          hasReact: {
            fn: function (e) {
              if (!e) return !1;
              let t = !1;
              for (const r in e)
                if (r.indexOf("__reactInternalInstance") > -1) {
                  t = !0;
                  break;
                }
              return !t && e.getAttribute("data-reactid") && (t = !0), t;
            },
            browserOnly: !0,
          },
          setReactOnChangeListener: {
            fn: function (e) {
              let t = null;
              for (const r in e)
                r.indexOf("__reactInternalInstance") > -1 && (t = r);
              const r = function (r) {
                e[t].memoizedProps.onChange(r),
                  r && r.target && d(`--- target value: ${r.target.value}`);
              };
              t &&
                e[t].memoizedProps &&
                "function" == typeof e[t].memoizedProps.onChange &&
                e.addEventListener("change", r);
            },
            browserOnly: !0,
          },
          setReactElementValue: {
            fn: function (e, t) {
              for (const r of [
                "focus",
                "compositionstart",
                "set_value",
                "input",
                "keyup",
                "change",
                "compositionend",
                "blur",
              ])
                if ("set_value" === r) e.value = t;
                else {
                  const t = new Event(r, { bubbles: !0 });
                  (t.simulated = !0), e.dispatchEvent(t);
                }
            },
            browserOnly: !0,
          },
          isElInViewport: { fn: x, browserOnly: !0 },
          visibleTexts: {
            fn: function e(t, r, n) {
              t || (t = document.body);
              const i = _(t) && t.offsetHeight > 1 && t.offsetWidth > 1,
                a = !r || x(t),
                o = t.childNodes;
              for (const e of o) {
                const t =
                    3 === e.nodeType ||
                    (_(e) && e.offsetHeight > 1 && e.offsetWidth > 1),
                  o = !r || x(e),
                  s = 3 === e.nodeType ? e.parentElement : null,
                  u =
                    s && s.getAttribute("class") ? s.getAttribute("class") : "";
                if (
                  3 === e.nodeType &&
                  i &&
                  a &&
                  s &&
                  "SCRIPT" != s.tagName &&
                  -1 === u.indexOf("disabled") &&
                  -1 === u.indexOf("inactive") &&
                  null === s.getAttribute("disabled")
                ) {
                  let t = e.nodeValue;
                  (t = t
                    .replace(/\s/g, " ")
                    .replace(/\s{2,}/g, " ")
                    .trim()),
                    t &&
                      -1 === t.indexOf("function") &&
                      -1 === t.indexOf("</") &&
                      n.push(t);
                } else
                  1 === e.nodeType &&
                    t &&
                    o &&
                    "INPUT" === e.tagName &&
                    "hidden" != e.type &&
                    !e.disabled &&
                    n.push(e.value);
              }
              for (const t of o) 3 != t.nodeType && e(t, r, n);
              return n;
            },
            browserOnly: !0,
          },
          applyRegExpToString: {
            fn: function (e, t) {
              if (!t || 0 === t.length) return e;
              const r = t.split("||");
              try {
                for (let t of r) {
                  t = t.trim();
                  let r = t.split("--\x3e");
                  if (r.length > 1) {
                    const t = r[1].trim(),
                      n = r[0].trim();
                    let i = null;
                    (i =
                      r[2] && r[2].trim().length >= 1
                        ? new RegExp(n, r[2].trim())
                        : new RegExp(n)),
                      (e = e.replace(i, t));
                  }
                }
              } catch (e) {}
              return e.trim();
            },
          },
          matchRegExpToString: {
            fn: function (e, t) {
              if (!t || !e || 0 === t.length) return !1;
              let r = !1;
              try {
                r = new RegExp(t, "gi").test(e);
              } catch (e) {
                d(`Error in askmeoffersAskmeoffersCustomGeneratorV1Utils/matchRegExpToString: ${e.message}`);
              }
              return r;
            },
          },
          prependSelectorFromVariable: {
            fn: function (e, t) {
              if (!t || 0 === t.length || !e) return e;
              if (0 === e.indexOf("//")) {
                let r = JSON.parse(JSON.stringify(e));
                const n = r.split("|");
                for (let e = 0; e < n.length; e++)
                  n[e] = `//*[contains(@class, '${t.replace(".", "")}')]${n[
                    e
                  ].trim()}`;
                (r = n.join(" | ")), (e = r);
              } else {
                const r = e.split(",");
                for (let e = 0; e < r.length; e++)
                  r[e] = `.${t} ${r[e].trim()}`;
                e = r.join(", ");
              }
              return e;
            },
          },
          findMultipleCurrenciesInLargeString: { fn: S },
          findCurrencyInLargeString: {
            fn: function (e, t, r, n, i) {
              const a = S(e, t, 0, n, i);
              return a ? a[0] : parseFloat(t);
            },
          },
          currencyFormatRegexp: { fn: T },
          parseCurrency: {
            fn: function (e) {
              const t = new RegExp("[^0-9-.]", ["g"]);
              return parseFloat(
                `${e}`.replace(/\((.*)\)/, "-$1").replace(t, "")
              );
            },
          },
          callSetter: {
            fn: function (e, t, r) {
              return (
                e instanceof i.default && (e = e.get(0)),
                Object.getOwnPropertyDescriptor(
                  Object.getPrototypeOf(e),
                  t
                ).set.call(e, r)
              );
            },
            browserOnly: !0,
          },
          getCurrencyInfo: {
            fn: function (e) {
              return a.default[e];
            },
          },
          sanitizeHTML: {
            fn: function (e, t, r, n, i) {
              let a = (0, o.default)(e, { allowedTags: t, transformTags: r });
              a = n.reduce((e, t) => e.replace(t[0], t[1]), a);
              for (let e = 0; e < 10; e += 1)
                a = a.replace(/<p>\s*<\/p>\s*<p>\s*<\/p>/g, "<p></p>");
              if (i) return a;
              let u = null;
              try {
                (u = s.default.load(a)),
                  u("a, button").replaceWith(() => {
                    const e = u(this).text().trim();
                    let t = u(this).attr("href"),
                      r = `<span>${e}`;
                    return (
                      t &&
                        t.length > 0 &&
                        -1 === t.indexOf("javascript") &&
                        "#" !== t.trim() &&
                        "/" !== t.trim() &&
                        (t.indexOf("mailto:") > -1
                          ? ((t = t.replace(/mailto:/gi, "")),
                            t.trim() !== e && (r += ` [${t}]`))
                          : (r += ` [${t}]`)),
                      (r += "</span>"),
                      r
                    );
                  }),
                  (a = JSON.parse(JSON.stringify(u.html())));
              } catch (e) {
                u = null;
              }
              return JSON.parse(JSON.stringify(a));
            },
          },
          consoleToUse: u,
        };
      } };
