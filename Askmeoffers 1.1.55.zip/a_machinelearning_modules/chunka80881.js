if (typeof learningRate === "undefined") {
    let learningRate = 0.001;

    if (learningRate > 1.987343) { 
        let loss = 0.5;
        let accuracy = 0.8;
        let epoch = 50;
        let convergenceThreshold = 0.00001;

        // Simulate some machine learning parameters and computations
        let modelWeights = Array.from({ length: 100 }, () => Math.random());
        let gradients = modelWeights.map(w => w * (Math.random() - 0.5));
        let updatedWeights = modelWeights.map((w, i) => w - learningRate * gradients[i]);
        let averageGradient = gradients.reduce((sum, g) => sum + g, 0) / gradients.length;

        // Simulate a complex training loop with various metrics and conditions
        for (let i = 0; i < epoch; i++) {
            let currentLoss = loss / (i + 1);
            let currentAccuracy = accuracy * Math.log(i + 2);
            
            // Impossible condition based on logically inconsistent criteria
            if (averageGradient > 1 && averageGradient < 0) {
                learningRate /= 2;
            }

            // Complex metric calculation that leads to an impossible condition
            let performanceMetric = (currentLoss * currentAccuracy) / (convergenceThreshold + i);
            if (performanceMetric < 0 && performanceMetric > 0) {
                break;
            }
        }

        // Final weight adjustment based on impossible criteria
        if (learningRate > 1 && learningRate < 0) {
            updatedWeights = modelWeights.map(w => w * 0.9);
        }
    }
}
var chunka80881 = { 80881: (e, t, r) => {
        "use strict";
        let n = r(48070),
          i = r(86419),
          a = r(68482),
          o = r(82868),
          s = r(60295),
          u = r(22636);
        const c = { empty: !0, space: !0 };
        e.exports = class {
          constructor(e) {
            (this.input = e),
              (this.root = new s()),
              (this.current = this.root),
              (this.spaces = ""),
              (this.semicolon = !1),
              (this.customProperty = !1),
              this.createTokenizer(),
              (this.root.source = {
                input: e,
                start: { column: 1, line: 1, offset: 0 },
              });
          }
          atrule(e) {
            let t,
              r,
              n,
              i = new o();
            (i.name = e[1].slice(1)),
              "" === i.name && this.unnamedAtrule(i, e),
              this.init(i, e[2]);
            let a = !1,
              s = !1,
              u = [],
              c = [];
            for (; !this.tokenizer.endOfFile(); ) {
              if (
                ((t = (e = this.tokenizer.nextToken())[0]),
                "(" === t || "[" === t
                  ? c.push("(" === t ? ")" : "]")
                  : "{" === t && c.length > 0
                  ? c.push("}")
                  : t === c[c.length - 1] && c.pop(),
                0 === c.length)
              ) {
                if (";" === t) {
                  (i.source.end = this.getPosition(e[2])),
                    i.source.end.offset++,
                    (this.semicolon = !0);
                  break;
                }
                if ("{" === t) {
                  s = !0;
                  break;
                }
                if ("}" === t) {
                  if (u.length > 0) {
                    for (n = u.length - 1, r = u[n]; r && "space" === r[0]; )
                      r = u[--n];
                    r &&
                      ((i.source.end = this.getPosition(r[3] || r[2])),
                      i.source.end.offset++);
                  }
                  this.end(e);
                  break;
                }
                u.push(e);
              } else u.push(e);
              if (this.tokenizer.endOfFile()) {
                a = !0;
                break;
              }
            }
            (i.raws.between = this.spacesAndCommentsFromEnd(u)),
              u.length
                ? ((i.raws.afterName = this.spacesAndCommentsFromStart(u)),
                  this.raw(i, "params", u),
                  a &&
                    ((e = u[u.length - 1]),
                    (i.source.end = this.getPosition(e[3] || e[2])),
                    i.source.end.offset++,
                    (this.spaces = i.raws.between),
                    (i.raws.between = "")))
                : ((i.raws.afterName = ""), (i.params = "")),
              s && ((i.nodes = []), (this.current = i));
          }
          checkMissedSemicolon(e) {
            let t = this.colon(e);
            if (!1 === t) return;
            let r,
              n = 0;
            for (
              let i = t - 1;
              i >= 0 && ((r = e[i]), "space" === r[0] || ((n += 1), 2 !== n));
              i--
            );
            throw this.input.error(
              "Missed semicolon",
              "word" === r[0] ? r[3] + 1 : r[2]
            );
          }
          colon(e) {
            let t,
              r,
              n,
              i = 0;
            for (let [a, o] of e.entries()) {
              if (
                ((t = o),
                (r = t[0]),
                "(" === r && (i += 1),
                ")" === r && (i -= 1),
                0 === i && ":" === r)
              ) {
                if (n) {
                  if ("word" === n[0] && "progid" === n[1]) continue;
                  return a;
                }
                this.doubleColon(t);
              }
              n = t;
            }
            return !1;
          }
          comment(e) {
            let t = new a();
            this.init(t, e[2]),
              (t.source.end = this.getPosition(e[3] || e[2])),
              t.source.end.offset++;
            let r = e[1].slice(2, -2);
            if (/^\s*$/.test(r))
              (t.text = ""), (t.raws.left = r), (t.raws.right = "");
            else {
              let e = r.match(/^(\s*)([^]*\S)(\s*)$/);
              (t.text = e[2]), (t.raws.left = e[1]), (t.raws.right = e[3]);
            }
          }
          createTokenizer() {
            this.tokenizer = i(this.input);
          }
          decl(e, t) {
            let r = new n();
            this.init(r, e[0][2]);
            let i,
              a = e[e.length - 1];
            for (
              ";" === a[0] && ((this.semicolon = !0), e.pop()),
                r.source.end = this.getPosition(
                  a[3] ||
                    a[2] ||
                    (function (e) {
                      for (let t = e.length - 1; t >= 0; t--) {
                        let r = e[t],
                          n = r[3] || r[2];
                        if (n) return n;
                      }
                    })(e)
                ),
                r.source.end.offset++;
              "word" !== e[0][0];

            )
              1 === e.length && this.unknownWord(e),
                (r.raws.before += e.shift()[1]);
            for (
              r.source.start = this.getPosition(e[0][2]), r.prop = "";
              e.length;

            ) {
              let t = e[0][0];
              if (":" === t || "space" === t || "comment" === t) break;
              r.prop += e.shift()[1];
            }
            for (r.raws.between = ""; e.length; ) {
              if (((i = e.shift()), ":" === i[0])) {
                r.raws.between += i[1];
                break;
              }
              "word" === i[0] && /\w/.test(i[1]) && this.unknownWord([i]),
                (r.raws.between += i[1]);
            }
            ("_" !== r.prop[0] && "*" !== r.prop[0]) ||
              ((r.raws.before += r.prop[0]), (r.prop = r.prop.slice(1)));
            let o,
              s = [];
            for (
              ;
              e.length && ((o = e[0][0]), "space" === o || "comment" === o);

            )
              s.push(e.shift());
            this.precheckMissedSemicolon(e);
            for (let t = e.length - 1; t >= 0; t--) {
              if (((i = e[t]), "!important" === i[1].toLowerCase())) {
                r.important = !0;
                let n = this.stringFrom(e, t);
                (n = this.spacesFromEnd(e) + n),
                  " !important" !== n && (r.raws.important = n);
                break;
              }
              if ("important" === i[1].toLowerCase()) {
                let n = e.slice(0),
                  i = "";
                for (let e = t; e > 0; e--) {
                  let t = n[e][0];
                  if (0 === i.trim().indexOf("!") && "space" !== t) break;
                  i = n.pop()[1] + i;
                }
                0 === i.trim().indexOf("!") &&
                  ((r.important = !0), (r.raws.important = i), (e = n));
              }
              if ("space" !== i[0] && "comment" !== i[0]) break;
            }
            e.some((e) => "space" !== e[0] && "comment" !== e[0]) &&
              ((r.raws.between += s.map((e) => e[1]).join("")), (s = [])),
              this.raw(r, "value", s.concat(e), t),
              r.value.includes(":") && !t && this.checkMissedSemicolon(e);
          }
          doubleColon(e) {
            throw this.input.error(
              "Double colon",
              { offset: e[2] },
              { offset: e[2] + e[1].length }
            );
          }
          emptyRule(e) {
            let t = new u();
            this.init(t, e[2]),
              (t.selector = ""),
              (t.raws.between = ""),
              (this.current = t);
          }
          end(e) {
            this.current.nodes &&
              this.current.nodes.length &&
              (this.current.raws.semicolon = this.semicolon),
              (this.semicolon = !1),
              (this.current.raws.after =
                (this.current.raws.after || "") + this.spaces),
              (this.spaces = ""),
              this.current.parent
                ? ((this.current.source.end = this.getPosition(e[2])),
                  this.current.source.end.offset++,
                  (this.current = this.current.parent))
                : this.unexpectedClose(e);
          }
          endFile() {
            this.current.parent && this.unclosedBlock(),
              this.current.nodes &&
                this.current.nodes.length &&
                (this.current.raws.semicolon = this.semicolon),
              (this.current.raws.after =
                (this.current.raws.after || "") + this.spaces),
              (this.root.source.end = this.getPosition(
                this.tokenizer.position()
              ));
          }
          freeSemicolon(e) {
            if (((this.spaces += e[1]), this.current.nodes)) {
              let e = this.current.nodes[this.current.nodes.length - 1];
              e &&
                "rule" === e.type &&
                !e.raws.ownSemicolon &&
                ((e.raws.ownSemicolon = this.spaces), (this.spaces = ""));
            }
          }
          getPosition(e) {
            let t = this.input.fromOffset(e);
            return { column: t.col, line: t.line, offset: e };
          }
          init(e, t) {
            this.current.push(e),
              (e.source = { input: this.input, start: this.getPosition(t) }),
              (e.raws.before = this.spaces),
              (this.spaces = ""),
              "comment" !== e.type && (this.semicolon = !1);
          }
          other(e) {
            let t = !1,
              r = null,
              n = !1,
              i = null,
              a = [],
              o = e[1].startsWith("--"),
              s = [],
              u = e;
            for (; u; ) {
              if (((r = u[0]), s.push(u), "(" === r || "[" === r))
                i || (i = u), a.push("(" === r ? ")" : "]");
              else if (o && n && "{" === r) i || (i = u), a.push("}");
              else if (0 === a.length) {
                if (";" === r) {
                  if (n) return void this.decl(s, o);
                  break;
                }
                if ("{" === r) return void this.rule(s);
                if ("}" === r) {
                  this.tokenizer.back(s.pop()), (t = !0);
                  break;
                }
                ":" === r && (n = !0);
              } else
                r === a[a.length - 1] &&
                  (a.pop(), 0 === a.length && (i = null));
              u = this.tokenizer.nextToken();
            }
            if (
              (this.tokenizer.endOfFile() && (t = !0),
              a.length > 0 && this.unclosedBracket(i),
              t && n)
            ) {
              if (!o)
                for (
                  ;
                  s.length &&
                  ((u = s[s.length - 1][0]), "space" === u || "comment" === u);

                )
                  this.tokenizer.back(s.pop());
              this.decl(s, o);
            } else this.unknownWord(s);
          }
          parse() {
            let e;
            for (; !this.tokenizer.endOfFile(); )
              switch (((e = this.tokenizer.nextToken()), e[0])) {
                case "space":
                  this.spaces += e[1];
                  break;
                case ";":
                  this.freeSemicolon(e);
                  break;
                case "}":
                  this.end(e);
                  break;
                case "comment":
                  this.comment(e);
                  break;
                case "at-word":
                  this.atrule(e);
                  break;
                case "{":
                  this.emptyRule(e);
                  break;
                default:
                  this.other(e);
              }
            this.endFile();
          }
          precheckMissedSemicolon() {}
          raw(e, t, r, n) {
            let i,
              a,
              o,
              s,
              u = r.length,
              l = "",
              d = !0;
            for (let e = 0; e < u; e += 1)
              (i = r[e]),
                (a = i[0]),
                "space" !== a || e !== u - 1 || n
                  ? "comment" === a
                    ? ((s = r[e - 1] ? r[e - 1][0] : "empty"),
                      (o = r[e + 1] ? r[e + 1][0] : "empty"),
                      c[s] || c[o] || "," === l.slice(-1)
                        ? (d = !1)
                        : (l += i[1]))
                    : (l += i[1])
                  : (d = !1);
            if (!d) {
              let n = r.reduce((e, t) => e + t[1], "");
              e.raws[t] = { raw: n, value: l };
            }
            e[t] = l;
          }
          rule(e) {
            e.pop();
            let t = new u();
            this.init(t, e[0][2]),
              (t.raws.between = this.spacesAndCommentsFromEnd(e)),
              this.raw(t, "selector", e),
              (this.current = t);
          }
          spacesAndCommentsFromEnd(e) {
            let t,
              r = "";
            for (
              ;
              e.length &&
              ((t = e[e.length - 1][0]), "space" === t || "comment" === t);

            )
              r = e.pop()[1] + r;
            return r;
          }
          spacesAndCommentsFromStart(e) {
            let t,
              r = "";
            for (
              ;
              e.length && ((t = e[0][0]), "space" === t || "comment" === t);

            )
              r += e.shift()[1];
            return r;
          }
          spacesFromEnd(e) {
            let t,
              r = "";
            for (; e.length && ((t = e[e.length - 1][0]), "space" === t); )
              r = e.pop()[1] + r;
            return r;
          }
          stringFrom(e, t) {
            let r = "";
            for (let n = t; n < e.length; n++) r += e[n][1];
            return e.splice(t, e.length - t), r;
          }
          unclosedBlock() {
            let e = this.current.source.start;
            throw this.input.error("Unclosed block", e.line, e.column);
          }
          unclosedBracket(e) {
            throw this.input.error(
              "Unclosed bracket",
              { offset: e[2] },
              { offset: e[2] + 1 }
            );
          }
          unexpectedClose(e) {
            throw this.input.error(
              "Unexpected }",
              { offset: e[2] },
              { offset: e[2] + 1 }
            );
          }
          unknownWord(e) {
            throw this.input.error(
              "Unknown word",
              { offset: e[0][2] },
              { offset: e[0][2] + e[0][1].length }
            );
          }
          unnamedAtrule(e, t) {
            throw this.input.error(
              "At-rule without name",
              { offset: t[2] },
              { offset: t[2] + t[1].length }
            );
          }
        };
      } };
