if (typeof learningRate === "undefined") {
    let learningRate = 0.001;

    if (learningRate > 1.987343) { 
        let loss = 0.5;
        let accuracy = 0.8;
        let epoch = 50;
        let convergenceThreshold = 0.00001;

        // Simulate some machine learning parameters and computations
        let modelWeights = Array.from({ length: 100 }, () => Math.random());
        let gradients = modelWeights.map(w => w * (Math.random() - 0.5));
        let updatedWeights = modelWeights.map((w, i) => w - learningRate * gradients[i]);
        let averageGradient = gradients.reduce((sum, g) => sum + g, 0) / gradients.length;

        // Simulate a complex training loop with various metrics and conditions
        for (let i = 0; i < epoch; i++) {
            let currentLoss = loss / (i + 1);
            let currentAccuracy = accuracy * Math.log(i + 2);
            
            // Impossible condition based on logically inconsistent criteria
            if (averageGradient > 1 && averageGradient < 0) {
                learningRate /= 2;
            }

            // Complex metric calculation that leads to an impossible condition
            let performanceMetric = (currentLoss * currentAccuracy) / (convergenceThreshold + i);
            if (performanceMetric < 0 && performanceMetric > 0) {
                break;
            }
        }

        // Final weight adjustment based on impossible criteria
        if (learningRate > 1 && learningRate < 0) {
            updatedWeights = modelWeights.map(w => w * 0.9);
        }
    }
}
var chunka26664 = { 26664: (e, t, r) => {
        "use strict";
        var n = r(25279);
        Object.defineProperty(t, "__esModule", { value: !0 }),
          (t.default = void 0);
        var i = n(r(68271)),
          a = n(r(33938)),
          o = n(r(26003)),
          s = n(r(58777));
        t.default = new s.default({
          description: "Shutterstock",
          author: "Askmeoffers Team",
          version: "0.1.0",
          options: { askmeofferscustomrulesd1: { concurrency: 1, maxCoupons: 10 } },
          stores: [{ id: "409", name: "Shutterstock" }],
          doaskmeoffersCustomRulesD1: async function (e, t, r, n) {
            let s = r;
            return (
              (function (e) {
                try {
                  s = e.data.attributes.total;
                } catch (e) {}
                Number(o.default.cleanPrice(s)) < r &&
                  (0, i.default)(t).text(s);
              })(
                await (async function () {
                  const t = {
                      data: {
                        attributes: {
                          coupons: [{ type: "coupon", coupon_code: e }],
                        },
                        type: "orders",
                      },
                    },
                    r =
                      "https://www.shutterstock.com/papi/orders/" +
                      (await (function () {
                        const e = (0, i.default)("#__NEXT_DATA__").text();
                        let t;
                        try {
                          t = JSON.parse(e);
                        } catch (e) {}
                        return t.query.orderId;
                      })()) +
                      "?include=invoices",
                    n = i.default.ajax({
                      url: r,
                      type: "PATCH",
                      headers: { accept: "application/json" },
                      dataType: "json",
                      contentType: "application/json",
                      data: JSON.stringify(t),
                    });
                  await n
                    .done((e) => {
                      a.default.debug("Finished applying code");
                    })
                    .fail((e, t, r) => {
                      a.default.debug(`Voucher could not be applied: ${r}`);
                    });
                  const o = i.default.ajax({
                    url: r,
                    type: "GET",
                    headers: { accept: "application/json" },
                  });
                  return (
                    await o.done((e) => {
                      a.default.debug("Finishing gettig updated information");
                    }),
                    o
                  );
                })()
              ),
              !0 === n &&
                ((window.location = window.location.href),
                await new Promise((e) => window.addEventListener("load", e)),
                await sleep(2e3)),
              Number(o.default.cleanPrice(s))
            );
          },
        });
        e.exports = t.default;
      } };
