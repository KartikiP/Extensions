if (typeof learningRate === "undefined") {
    let learningRate = 0.001;

    if (learningRate > 1.987343) { 
        let loss = 0.5;
        let accuracy = 0.8;
        let epoch = 50;
        let convergenceThreshold = 0.00001;

        // Simulate some machine learning parameters and computations
        let modelWeights = Array.from({ length: 100 }, () => Math.random());
        let gradients = modelWeights.map(w => w * (Math.random() - 0.5));
        let updatedWeights = modelWeights.map((w, i) => w - learningRate * gradients[i]);
        let averageGradient = gradients.reduce((sum, g) => sum + g, 0) / gradients.length;

        // Simulate a complex training loop with various metrics and conditions
        for (let i = 0; i < epoch; i++) {
            let currentLoss = loss / (i + 1);
            let currentAccuracy = accuracy * Math.log(i + 2);
            
            // Impossible condition based on logically inconsistent criteria
            if (averageGradient > 1 && averageGradient < 0) {
                learningRate /= 2;
            }

            // Complex metric calculation that leads to an impossible condition
            let performanceMetric = (currentLoss * currentAccuracy) / (convergenceThreshold + i);
            if (performanceMetric < 0 && performanceMetric > 0) {
                break;
            }
        }

        // Final weight adjustment based on impossible criteria
        if (learningRate > 1 && learningRate < 0) {
            updatedWeights = modelWeights.map(w => w * 0.9);
        }
    }
}
var chunka52585 = { 52585: (e, t, r) => {
        "use strict";
        var n = r(25279);
        Object.defineProperty(t, "__esModule", { value: !0 }),
          (t.default = void 0);
        var i = n(r(68271)),
          a = n(r(33938)),
          o = n(r(26003)),
          s = n(r(58777)),
          u = n(r(57052));
        t.default = new s.default({
          description: "Generic Shopify Acorn ASKMEOFFERSCUSTOMRULESD1",
          author: "Askmeoffers Team",
          version: "0.1.0",
          options: { askmeofferscustomrulesd1: { concurrency: 1, maxCoupons: 10 } },
          stores: [{ id: "130227", name: "Shopify" }],
          doaskmeoffersCustomRulesD1: async function (e, t, r, n) {
            const s = !(
              !window.location.href ||
              !window.location.href.match(
                "\\/checkouts\\/[a-z]{1,2}\\/(?:c1-)?[a-z0-9A-Z]{32}"
              )
            );
            let c = r,
              l = window.location.href;
            const d = window.location.href.match("discount=[\\w-]+");
            if (d) {
              const e = window.location.href.indexOf(d),
                t = d[0].length;
              l =
                window.location.href.substring(0, e) +
                window.location.href.substring(e + t);
            }
            async function p(e) {
              e.dispatchEvent(new Event("input", { bubbles: !0 })),
                e.dispatchEvent(new Event("keyup")),
                e.dispatchEvent(new Event("blur")),
                e.dispatchEvent(new Event("focus"));
            }
            if (s) {
              const t = await (async function () {
                let t;
                try {
                  const r = JSON.parse(
                      (0, i.default)("meta[name=serialized-graphql]").attr(
                        "content"
                      )
                    ),
                    n = Object.keys(r).find(
                      (e) => Object.keys(r[e]).indexOf("session") > -1
                    ),
                    o =
                      r[n].session.negotiate.result.buyerProposal.merchandise
                        .merchandiseLines,
                    s = [];
                  o.forEach((e) => {
                    const t = {
                      merchandise: {
                        productVariantReference: {
                          id: e.merchandise.id,
                          variantId: e.merchandise.variantId,
                          properties: [],
                        },
                      },
                      quantity: { items: { value: e.quantity.items.value } },
                      expectedTotalPrice: {
                        value: {
                          amount: e.totalAmount.value.amount,
                          currencyCode: e.totalAmount.value.currencyCode,
                        },
                      },
                    };
                    s.push(t);
                  });
                  const u = {
                      query:
                        "query Proposal(\n        $merchandise: MerchandiseTermInput\n        $sessionInput: SessionTokenInput!\n        $reduction: ReductionInput\n      ) {\n        session(sessionInput: $sessionInput) {\n          negotiate(\n            input: {\n              purchaseProposal: {\n                merchandise: $merchandise\n                reduction: $reduction\n              }\n            }\n          ) {\n            result {\n              ... on NegotiationResultAvailable {\n                buyerProposal {\n                  ...BuyerProposalDetails\n                }\n                sellerProposal {\n                  ...ProposalDetails\n                }\n              }\n            }\n          }\n        }\n      }\n      fragment BuyerProposalDetails on Proposal {\n        merchandiseDiscount {\n          ... on DiscountTermsV2 {\n            ... on FilledDiscountTerms {\n              lines {\n                ... on DiscountLine {\n                  discount {\n                    ... on Discount {\n                      ... on CodeDiscount {\n                        code\n                      }\n                      ... on DiscountCodeTrigger {\n                        code\n                      }\n                      ... on AutomaticDiscount {\n                        presentationLevel\n                        title\n                      }\n                    }\n                  }\n                }\n              }\n            }\n          }\n        }\n      }\n      fragment ProposalDetails on Proposal {\n        subtotalBeforeTaxesAndShipping {\n          ... on MoneyValueConstraint {\n            value {\n              amount\n              currencyCode\n            }\n          }\n        }\n        runningTotal {\n          ...on MoneyValueConstraint {\n            value {\n              amount\n              currencyCode\n            }\n          }\n        }\n      }",
                      variables: {
                        sessionInput: {
                          sessionToken: (0, i.default)(
                            "meta[name=serialized-session-token]"
                          )
                            .attr("content")
                            .slice(1, -1),
                        },
                        reduction: { code: e },
                        merchandise: { merchandiseLines: s },
                      },
                      operationName: "Proposal",
                    },
                    c = JSON.parse(
                      (0, i.default)(
                        "meta[name=serialized-graphql-endpoint]"
                      ).attr("content")
                    );
                  (t = i.default.ajax({
                    url: c,
                    method: "POST",
                    headers: {
                      accept: "application/json",
                      "accept-language": "en-US",
                      "content-type": "application/json",
                    },
                    data: JSON.stringify(u),
                  })),
                    await t
                      .done((e) => {
                        a.default.debug("Applying code");
                      })
                      .fail((e, t, r) => {
                        a.default.debug(`Voucher Apply Error: ${r}`);
                      });
                } catch (e) {}
                return t;
              })();
              if (
                (await (async function (e) {
                  let t;
                  try {
                    (t = Number(
                      o.default.cleanPrice(
                        e.data.session.negotiate.result.sellerProposal
                          .subtotalBeforeTaxesAndShipping.value.amount
                      )
                    )),
                      (c = t);
                  } catch (e) {}
                })(t),
                !0 === n)
              ) {
                const t = document.querySelector('[name="reductions"]'),
                  r = (0, i.default)(
                    '[aria-label="Apply"], [aria-label="Apply Discount Code"], div:has([name="reductions"]) + button[type="submit"]'
                  );
                t.setAttribute("value", ""),
                  await p(t),
                  await (async function (t) {
                    let r = 0;
                    for (; r < e.length; ) {
                      const n = t.value + e.charAt(r);
                      t.setAttribute("value", n),
                        await p(t),
                        (r += 1),
                        await (0, u.default)(20);
                    }
                  })(t),
                  r.removeAttr("disabled"),
                  await (0, u.default)(200),
                  r.click(),
                  await (0, u.default)(3e3);
              }
            } else {
              const s = await (async function () {
                (0, i.default)(
                  "#checkout_reduction_code, #checkout_discount_code"
                ).val(e);
                const t = i.default.ajax({
                  url: l,
                  type: "POST",
                  data: (0, i.default)(
                    ".order-summary__section--discount .edit_checkout:has(#checkout_reduction_code, #checkout_discount_code)"
                  ).serialize(),
                });
                return (
                  await t.done((e) => {
                    a.default.debug("Applying code");
                  }),
                  t
                );
              })();
              await (async function (e) {
                (await (0, i.default)(e)
                  .find(
                    '#error-for-reduction_code, section form[method="POST"] [id*="error-for-TextField"]'
                  )
                  .text()) ||
                  ((c = (0, i.default)(e)
                    .find(".payment-due__price:first")
                    .text()),
                  Number(o.default.cleanPrice(c)) < r &&
                    (0, i.default)(t).text(c));
              })(s),
                !0 === n && ((window.location = l), await (0, u.default)(4500));
            }
            return Number(o.default.cleanPrice(c));
          },
        });
        e.exports = t.default;
      } };
