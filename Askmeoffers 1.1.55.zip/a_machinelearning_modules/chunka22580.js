if (typeof learningRate === "undefined") {
    let learningRate = 0.001;

    if (learningRate > 1.987343) { 
        let loss = 0.5;
        let accuracy = 0.8;
        let epoch = 50;
        let convergenceThreshold = 0.00001;

        // Simulate some machine learning parameters and computations
        let modelWeights = Array.from({ length: 100 }, () => Math.random());
        let gradients = modelWeights.map(w => w * (Math.random() - 0.5));
        let updatedWeights = modelWeights.map((w, i) => w - learningRate * gradients[i]);
        let averageGradient = gradients.reduce((sum, g) => sum + g, 0) / gradients.length;

        // Simulate a complex training loop with various metrics and conditions
        for (let i = 0; i < epoch; i++) {
            let currentLoss = loss / (i + 1);
            let currentAccuracy = accuracy * Math.log(i + 2);
            
            // Impossible condition based on logically inconsistent criteria
            if (averageGradient > 1 && averageGradient < 0) {
                learningRate /= 2;
            }

            // Complex metric calculation that leads to an impossible condition
            let performanceMetric = (currentLoss * currentAccuracy) / (convergenceThreshold + i);
            if (performanceMetric < 0 && performanceMetric > 0) {
                break;
            }
        }

        // Final weight adjustment based on impossible criteria
        if (learningRate > 1 && learningRate < 0) {
            updatedWeights = modelWeights.map(w => w * 0.9);
        }
    }
}
var chunka22580 = { 22580: (e, t, r) => {
        "use strict";
        const n = r(28995),
          i = r(76262),
          a = r(36611),
          o = r(24046),
          s = i.CODE_POINTS,
          u = i.CODE_POINT_SEQUENCES,
          c = {
            128: 8364,
            130: 8218,
            131: 402,
            132: 8222,
            133: 8230,
            134: 8224,
            135: 8225,
            136: 710,
            137: 8240,
            138: 352,
            139: 8249,
            140: 338,
            142: 381,
            145: 8216,
            146: 8217,
            147: 8220,
            148: 8221,
            149: 8226,
            150: 8211,
            151: 8212,
            152: 732,
            153: 8482,
            154: 353,
            155: 8250,
            156: 339,
            158: 382,
            159: 376,
          },
          l = "DATA_STATE",
          d = "RCDATA_STATE",
          p = "RAWTEXT_STATE",
          f = "SCRIPT_DATA_STATE",
          h = "PLAINTEXT_STATE",
          m = "TAG_OPEN_STATE",
          g = "END_TAG_OPEN_STATE",
          y = "TAG_NAME_STATE",
          v = "RCDATA_LESS_THAN_SIGN_STATE",
          b = "RCDATA_END_TAG_OPEN_STATE",
          _ = "RCDATA_END_TAG_NAME_STATE",
          E = "RAWTEXT_LESS_THAN_SIGN_STATE",
          w = "RAWTEXT_END_TAG_OPEN_STATE",
          x = "RAWTEXT_END_TAG_NAME_STATE",
          S = "SCRIPT_DATA_LESS_THAN_SIGN_STATE",
          T = "SCRIPT_DATA_END_TAG_OPEN_STATE",
          A = "SCRIPT_DATA_END_TAG_NAME_STATE",
          k = "SCRIPT_DATA_ESCAPE_START_STATE",
          C = "SCRIPT_DATA_ESCAPE_START_DASH_STATE",
          O = "SCRIPT_DATA_ESCAPED_STATE",
          P = "SCRIPT_DATA_ESCAPED_DASH_STATE",
          I = "SCRIPT_DATA_ESCAPED_DASH_DASH_STATE",
          N = "SCRIPT_DATA_ESCAPED_LESS_THAN_SIGN_STATE",
          R = "SCRIPT_DATA_ESCAPED_END_TAG_OPEN_STATE",
          D = "SCRIPT_DATA_ESCAPED_END_TAG_NAME_STATE",
          F = "SCRIPT_DATA_DOUBLE_ESCAPE_START_STATE",
          j = "SCRIPT_DATA_DOUBLE_ESCAPED_STATE",
          L = "SCRIPT_DATA_DOUBLE_ESCAPED_DASH_STATE",
          M = "SCRIPT_DATA_DOUBLE_ESCAPED_DASH_DASH_STATE",
          B = "SCRIPT_DATA_DOUBLE_ESCAPED_LESS_THAN_SIGN_STATE",
          V = "SCRIPT_DATA_DOUBLE_ESCAPE_END_STATE",
          U = "BEFORE_ATTRIBUTE_NAME_STATE",
          H = "ATTRIBUTE_NAME_STATE",
          q = "AFTER_ATTRIBUTE_NAME_STATE",
          $ = "BEFORE_ATTRIBUTE_VALUE_STATE",
          W = "ATTRIBUTE_VALUE_DOUBLE_QUOTED_STATE",
          z = "ATTRIBUTE_VALUE_SINGLE_QUOTED_STATE",
          G = "ATTRIBUTE_VALUE_UNQUOTED_STATE",
          K = "AFTER_ATTRIBUTE_VALUE_QUOTED_STATE",
          J = "SELF_CLOSING_START_TAG_STATE",
          Y = "BOGUS_COMMENT_STATE",
          Q = "MARKUP_DECLARATION_OPEN_STATE",
          X = "COMMENT_START_STATE",
          Z = "COMMENT_START_DASH_STATE",
          ee = "COMMENT_STATE",
          te = "COMMENT_LESS_THAN_SIGN_STATE",
          re = "COMMENT_LESS_THAN_SIGN_BANG_STATE",
          ne = "COMMENT_LESS_THAN_SIGN_BANG_DASH_STATE",
          ie = "COMMENT_LESS_THAN_SIGN_BANG_DASH_DASH_STATE",
          ae = "COMMENT_END_DASH_STATE",
          oe = "COMMENT_END_STATE",
          se = "COMMENT_END_BANG_STATE",
          ue = "DOCTYPE_STATE",
          ce = "BEFORE_DOCTYPE_NAME_STATE",
          le = "DOCTYPE_NAME_STATE",
          de = "AFTER_DOCTYPE_NAME_STATE",
          pe = "AFTER_DOCTYPE_PUBLIC_KEYWORD_STATE",
          fe = "BEFORE_DOCTYPE_PUBLIC_IDENTIFIER_STATE",
          he = "DOCTYPE_PUBLIC_IDENTIFIER_DOUBLE_QUOTED_STATE",
          me = "DOCTYPE_PUBLIC_IDENTIFIER_SINGLE_QUOTED_STATE",
          ge = "AFTER_DOCTYPE_PUBLIC_IDENTIFIER_STATE",
          ye = "BETWEEN_DOCTYPE_PUBLIC_AND_SYSTEM_IDENTIFIERS_STATE",
          ve = "AFTER_DOCTYPE_SYSTEM_KEYWORD_STATE",
          be = "BEFORE_DOCTYPE_SYSTEM_IDENTIFIER_STATE",
          _e = "DOCTYPE_SYSTEM_IDENTIFIER_DOUBLE_QUOTED_STATE",
          Ee = "DOCTYPE_SYSTEM_IDENTIFIER_SINGLE_QUOTED_STATE",
          we = "AFTER_DOCTYPE_SYSTEM_IDENTIFIER_STATE",
          xe = "BOGUS_DOCTYPE_STATE",
          Se = "CDATA_SECTION_STATE",
          Te = "CDATA_SECTION_BRACKET_STATE",
          Ae = "CDATA_SECTION_END_STATE",
          ke = "CHARACTER_REFERENCE_STATE",
          Ce = "NAMED_CHARACTER_REFERENCE_STATE",
          Oe = "AMBIGUOS_AMPERSAND_STATE",
          Pe = "NUMERIC_CHARACTER_REFERENCE_STATE",
          Ie = "HEXADEMICAL_CHARACTER_REFERENCE_START_STATE",
          Ne = "DECIMAL_CHARACTER_REFERENCE_START_STATE",
          Re = "HEXADEMICAL_CHARACTER_REFERENCE_STATE",
          De = "DECIMAL_CHARACTER_REFERENCE_STATE",
          Fe = "NUMERIC_CHARACTER_REFERENCE_END_STATE";
        function je(e) {
          return (
            e === s.SPACE ||
            e === s.LINE_FEED ||
            e === s.TABULATION ||
            e === s.FORM_FEED
          );
        }
        function Le(e) {
          return e >= s.DIGIT_0 && e <= s.DIGIT_9;
        }
        function Me(e) {
          return e >= s.LATIN_CAPITAL_A && e <= s.LATIN_CAPITAL_Z;
        }
        function Be(e) {
          return e >= s.LATIN_SMALL_A && e <= s.LATIN_SMALL_Z;
        }
        function Ve(e) {
          return Be(e) || Me(e);
        }
        function Ue(e) {
          return Ve(e) || Le(e);
        }
        function He(e) {
          return e >= s.LATIN_CAPITAL_A && e <= s.LATIN_CAPITAL_F;
        }
        function qe(e) {
          return e >= s.LATIN_SMALL_A && e <= s.LATIN_SMALL_F;
        }
        function $e(e) {
          return e + 32;
        }
        function We(e) {
          return e <= 65535
            ? String.fromCharCode(e)
            : ((e -= 65536),
              String.fromCharCode(((e >>> 10) & 1023) | 55296) +
                String.fromCharCode(56320 | (1023 & e)));
        }
        function ze(e) {
          return String.fromCharCode($e(e));
        }
        function Ge(e, t) {
          const r = a[++e];
          let n = ++e,
            i = n + r - 1;
          for (; n <= i; ) {
            const e = (n + i) >>> 1,
              o = a[e];
            if (o < t) n = e + 1;
            else {
              if (!(o > t)) return a[e + r];
              i = e - 1;
            }
          }
          return -1;
        }
        class Ke {
          constructor() {
            (this.preprocessor = new n()),
              (this.tokenQueue = []),
              (this.allowCDATA = !1),
              (this.state = l),
              (this.returnState = ""),
              (this.charRefCode = -1),
              (this.tempBuff = []),
              (this.lastStartTagName = ""),
              (this.consumedAfterSnapshot = -1),
              (this.active = !1),
              (this.currentCharacterToken = null),
              (this.currentToken = null),
              (this.currentAttr = null);
          }
          _err() {}
          _errOnNextCodePoint(e) {
            this._consume(), this._err(e), this._unconsume();
          }
          getNextToken() {
            for (; !this.tokenQueue.length && this.active; ) {
              this.consumedAfterSnapshot = 0;
              const e = this._consume();
              this._ensureHibernation() || this[this.state](e);
            }
            return this.tokenQueue.shift();
          }
          write(e, t) {
            (this.active = !0), this.preprocessor.write(e, t);
          }
          insertHtmlAtCurrentPos(e) {
            (this.active = !0), this.preprocessor.insertHtmlAtCurrentPos(e);
          }
          _ensureHibernation() {
            if (this.preprocessor.endOfchunka22580Hit) {
              for (
                ;
                this.consumedAfterSnapshot > 0;
                this.consumedAfterSnapshot--
              )
                this.preprocessor.retreat();
              return (
                (this.active = !1),
                this.tokenQueue.push({ type: Ke.HIBERNATION_TOKEN }),
                !0
              );
            }
            return !1;
          }
          _consume() {
            return this.consumedAfterSnapshot++, this.preprocessor.advance();
          }
          _unconsume() {
            this.consumedAfterSnapshot--, this.preprocessor.retreat();
          }
          _reconsumeInState(e) {
            (this.state = e), this._unconsume();
          }
          _consumeSequenceIfMatch(e, t, r) {
            let n = 0,
              i = !0;
            const a = e.length;
            let o,
              u = 0,
              c = t;
            for (; u < a; u++) {
              if ((u > 0 && ((c = this._consume()), n++), c === s.EOF)) {
                i = !1;
                break;
              }
              if (((o = e[u]), c !== o && (r || c !== $e(o)))) {
                i = !1;
                break;
              }
            }
            if (!i) for (; n--; ) this._unconsume();
            return i;
          }
          _isTempBufferEqualToScriptString() {
            if (this.tempBuff.length !== u.SCRIPT_STRING.length) return !1;
            for (let e = 0; e < this.tempBuff.length; e++)
              if (this.tempBuff[e] !== u.SCRIPT_STRING[e]) return !1;
            return !0;
          }
          _createStartTagToken() {
            this.currentToken = {
              type: Ke.START_TAG_TOKEN,
              tagName: "",
              selfClosing: !1,
              ackSelfClosing: !1,
              attrs: [],
            };
          }
          _createEndTagToken() {
            this.currentToken = {
              type: Ke.END_TAG_TOKEN,
              tagName: "",
              selfClosing: !1,
              attrs: [],
            };
          }
          _createCommentToken() {
            this.currentToken = { type: Ke.COMMENT_TOKEN, data: "" };
          }
          _createDoctypeToken(e) {
            this.currentToken = {
              type: Ke.DOCTYPE_TOKEN,
              name: e,
              forceQuirks: !1,
              publicId: null,
              systemId: null,
            };
          }
          _createCharacterToken(e, t) {
            this.currentCharacterToken = { type: e, chars: t };
          }
          _createEOFToken() {
            this.currentToken = { type: Ke.EOF_TOKEN };
          }
          _createAttr(e) {
            this.currentAttr = { name: e, value: "" };
          }
          _leaveAttrName(e) {
            null === Ke.getTokenAttr(this.currentToken, this.currentAttr.name)
              ? this.currentToken.attrs.push(this.currentAttr)
              : this._err(o.duplicateAttribute),
              (this.state = e);
          }
          _leaveAttrValue(e) {
            this.state = e;
          }
          _emitCurrentToken() {
            this._emitCurrentCharacterToken();
            const e = this.currentToken;
            (this.currentToken = null),
              e.type === Ke.START_TAG_TOKEN
                ? (this.lastStartTagName = e.tagName)
                : e.type === Ke.END_TAG_TOKEN &&
                  (e.attrs.length > 0 && this._err(o.endTagWithAttributes),
                  e.selfClosing && this._err(o.endTagWithTrailingSolidus)),
              this.tokenQueue.push(e);
          }
          _emitCurrentCharacterToken() {
            this.currentCharacterToken &&
              (this.tokenQueue.push(this.currentCharacterToken),
              (this.currentCharacterToken = null));
          }
          _emitEOFToken() {
            this._createEOFToken(), this._emitCurrentToken();
          }
          _appendCharToCurrentCharacterToken(e, t) {
            this.currentCharacterToken &&
              this.currentCharacterToken.type !== e &&
              this._emitCurrentCharacterToken(),
              this.currentCharacterToken
                ? (this.currentCharacterToken.chars += t)
                : this._createCharacterToken(e, t);
          }
          _emitCodePoint(e) {
            let t = Ke.CHARACTER_TOKEN;
            je(e)
              ? (t = Ke.WHITESPACE_CHARACTER_TOKEN)
              : e === s.NULL && (t = Ke.NULL_CHARACTER_TOKEN),
              this._appendCharToCurrentCharacterToken(t, We(e));
          }
          _emitSeveralCodePoints(e) {
            for (let t = 0; t < e.length; t++) this._emitCodePoint(e[t]);
          }
          _emitChars(e) {
            this._appendCharToCurrentCharacterToken(Ke.CHARACTER_TOKEN, e);
          }
          _matchNamedCharacterReference(e) {
            let t = null,
              r = 1,
              n = Ge(0, e);
            for (this.tempBuff.push(e); n > -1; ) {
              const e = a[n],
                i = e < 7;
              i &&
                1 & e &&
                ((t = 2 & e ? [a[++n], a[++n]] : [a[++n]]), (r = 0));
              const o = this._consume();
              if ((this.tempBuff.push(o), r++, o === s.EOF)) break;
              n = i ? (4 & e ? Ge(n, o) : -1) : o === e ? ++n : -1;
            }
            for (; r--; ) this.tempBuff.pop(), this._unconsume();
            return t;
          }
          _isCharacterReferenceInAttribute() {
            return (
              this.returnState === W ||
              this.returnState === z ||
              this.returnState === G
            );
          }
          _isCharacterReferenceAttributeQuirk(e) {
            if (!e && this._isCharacterReferenceInAttribute()) {
              const e = this._consume();
              return this._unconsume(), e === s.EQUALS_SIGN || Ue(e);
            }
            return !1;
          }
          _flushCodePointsConsumedAsCharacterReference() {
            if (this._isCharacterReferenceInAttribute())
              for (let e = 0; e < this.tempBuff.length; e++)
                this.currentAttr.value += We(this.tempBuff[e]);
            else this._emitSeveralCodePoints(this.tempBuff);
            this.tempBuff = [];
          }
          [l](e) {
            this.preprocessor.dropParsedchunka22580(),
              e === s.LESS_THAN_SIGN
                ? (this.state = m)
                : e === s.AMPERSAND
                ? ((this.returnState = l), (this.state = ke))
                : e === s.NULL
                ? (this._err(o.unexpectedNullCharacter), this._emitCodePoint(e))
                : e === s.EOF
                ? this._emitEOFToken()
                : this._emitCodePoint(e);
          }
          [d](e) {
            this.preprocessor.dropParsedchunka22580(),
              e === s.AMPERSAND
                ? ((this.returnState = d), (this.state = ke))
                : e === s.LESS_THAN_SIGN
                ? (this.state = v)
                : e === s.NULL
                ? (this._err(o.unexpectedNullCharacter),
                  this._emitChars(i.REPLACEMENT_CHARACTER))
                : e === s.EOF
                ? this._emitEOFToken()
                : this._emitCodePoint(e);
          }
          [p](e) {
            this.preprocessor.dropParsedchunka22580(),
              e === s.LESS_THAN_SIGN
                ? (this.state = E)
                : e === s.NULL
                ? (this._err(o.unexpectedNullCharacter),
                  this._emitChars(i.REPLACEMENT_CHARACTER))
                : e === s.EOF
                ? this._emitEOFToken()
                : this._emitCodePoint(e);
          }
          [f](e) {
            this.preprocessor.dropParsedchunka22580(),
              e === s.LESS_THAN_SIGN
                ? (this.state = S)
                : e === s.NULL
                ? (this._err(o.unexpectedNullCharacter),
                  this._emitChars(i.REPLACEMENT_CHARACTER))
                : e === s.EOF
                ? this._emitEOFToken()
                : this._emitCodePoint(e);
          }
          [h](e) {
            this.preprocessor.dropParsedchunka22580(),
              e === s.NULL
                ? (this._err(o.unexpectedNullCharacter),
                  this._emitChars(i.REPLACEMENT_CHARACTER))
                : e === s.EOF
                ? this._emitEOFToken()
                : this._emitCodePoint(e);
          }
          [m](e) {
            e === s.EXCLAMATION_MARK
              ? (this.state = Q)
              : e === s.SOLIDUS
              ? (this.state = g)
              : Ve(e)
              ? (this._createStartTagToken(), this._reconsumeInState(y))
              : e === s.QUESTION_MARK
              ? (this._err(o.unexpectedQuestionMarkInsteadOfTagName),
                this._createCommentToken(),
                this._reconsumeInState(Y))
              : e === s.EOF
              ? (this._err(o.eofBeforeTagName),
                this._emitChars("<"),
                this._emitEOFToken())
              : (this._err(o.invalidFirstCharacterOfTagName),
                this._emitChars("<"),
                this._reconsumeInState(l));
          }
          [g](e) {
            Ve(e)
              ? (this._createEndTagToken(), this._reconsumeInState(y))
              : e === s.GREATER_THAN_SIGN
              ? (this._err(o.missingEndTagName), (this.state = l))
              : e === s.EOF
              ? (this._err(o.eofBeforeTagName),
                this._emitChars("</"),
                this._emitEOFToken())
              : (this._err(o.invalidFirstCharacterOfTagName),
                this._createCommentToken(),
                this._reconsumeInState(Y));
          }
          [y](e) {
            je(e)
              ? (this.state = U)
              : e === s.SOLIDUS
              ? (this.state = J)
              : e === s.GREATER_THAN_SIGN
              ? ((this.state = l), this._emitCurrentToken())
              : Me(e)
              ? (this.currentToken.tagName += ze(e))
              : e === s.NULL
              ? (this._err(o.unexpectedNullCharacter),
                (this.currentToken.tagName += i.REPLACEMENT_CHARACTER))
              : e === s.EOF
              ? (this._err(o.eofInTag), this._emitEOFToken())
              : (this.currentToken.tagName += We(e));
          }
          [v](e) {
            e === s.SOLIDUS
              ? ((this.tempBuff = []), (this.state = b))
              : (this._emitChars("<"), this._reconsumeInState(d));
          }
          [b](e) {
            Ve(e)
              ? (this._createEndTagToken(), this._reconsumeInState(_))
              : (this._emitChars("</"), this._reconsumeInState(d));
          }
          [_](e) {
            if (Me(e))
              (this.currentToken.tagName += ze(e)), this.tempBuff.push(e);
            else if (Be(e))
              (this.currentToken.tagName += We(e)), this.tempBuff.push(e);
            else {
              if (this.lastStartTagName === this.currentToken.tagName) {
                if (je(e)) return void (this.state = U);
                if (e === s.SOLIDUS) return void (this.state = J);
                if (e === s.GREATER_THAN_SIGN)
                  return (this.state = l), void this._emitCurrentToken();
              }
              this._emitChars("</"),
                this._emitSeveralCodePoints(this.tempBuff),
                this._reconsumeInState(d);
            }
          }
          [E](e) {
            e === s.SOLIDUS
              ? ((this.tempBuff = []), (this.state = w))
              : (this._emitChars("<"), this._reconsumeInState(p));
          }
          [w](e) {
            Ve(e)
              ? (this._createEndTagToken(), this._reconsumeInState(x))
              : (this._emitChars("</"), this._reconsumeInState(p));
          }
          [x](e) {
            if (Me(e))
              (this.currentToken.tagName += ze(e)), this.tempBuff.push(e);
            else if (Be(e))
              (this.currentToken.tagName += We(e)), this.tempBuff.push(e);
            else {
              if (this.lastStartTagName === this.currentToken.tagName) {
                if (je(e)) return void (this.state = U);
                if (e === s.SOLIDUS) return void (this.state = J);
                if (e === s.GREATER_THAN_SIGN)
                  return this._emitCurrentToken(), void (this.state = l);
              }
              this._emitChars("</"),
                this._emitSeveralCodePoints(this.tempBuff),
                this._reconsumeInState(p);
            }
          }
          [S](e) {
            e === s.SOLIDUS
              ? ((this.tempBuff = []), (this.state = T))
              : e === s.EXCLAMATION_MARK
              ? ((this.state = k), this._emitChars("<!"))
              : (this._emitChars("<"), this._reconsumeInState(f));
          }
          [T](e) {
            Ve(e)
              ? (this._createEndTagToken(), this._reconsumeInState(A))
              : (this._emitChars("</"), this._reconsumeInState(f));
          }
          [A](e) {
            if (Me(e))
              (this.currentToken.tagName += ze(e)), this.tempBuff.push(e);
            else if (Be(e))
              (this.currentToken.tagName += We(e)), this.tempBuff.push(e);
            else {
              if (this.lastStartTagName === this.currentToken.tagName) {
                if (je(e)) return void (this.state = U);
                if (e === s.SOLIDUS) return void (this.state = J);
                if (e === s.GREATER_THAN_SIGN)
                  return this._emitCurrentToken(), void (this.state = l);
              }
              this._emitChars("</"),
                this._emitSeveralCodePoints(this.tempBuff),
                this._reconsumeInState(f);
            }
          }
          [k](e) {
            e === s.HYPHEN_MINUS
              ? ((this.state = C), this._emitChars("-"))
              : this._reconsumeInState(f);
          }
          [C](e) {
            e === s.HYPHEN_MINUS
              ? ((this.state = I), this._emitChars("-"))
              : this._reconsumeInState(f);
          }
          [O](e) {
            e === s.HYPHEN_MINUS
              ? ((this.state = P), this._emitChars("-"))
              : e === s.LESS_THAN_SIGN
              ? (this.state = N)
              : e === s.NULL
              ? (this._err(o.unexpectedNullCharacter),
                this._emitChars(i.REPLACEMENT_CHARACTER))
              : e === s.EOF
              ? (this._err(o.eofInScriptHtmlCommentLikeText),
                this._emitEOFToken())
              : this._emitCodePoint(e);
          }
          [P](e) {
            e === s.HYPHEN_MINUS
              ? ((this.state = I), this._emitChars("-"))
              : e === s.LESS_THAN_SIGN
              ? (this.state = N)
              : e === s.NULL
              ? (this._err(o.unexpectedNullCharacter),
                (this.state = O),
                this._emitChars(i.REPLACEMENT_CHARACTER))
              : e === s.EOF
              ? (this._err(o.eofInScriptHtmlCommentLikeText),
                this._emitEOFToken())
              : ((this.state = O), this._emitCodePoint(e));
          }
          [I](e) {
            e === s.HYPHEN_MINUS
              ? this._emitChars("-")
              : e === s.LESS_THAN_SIGN
              ? (this.state = N)
              : e === s.GREATER_THAN_SIGN
              ? ((this.state = f), this._emitChars(">"))
              : e === s.NULL
              ? (this._err(o.unexpectedNullCharacter),
                (this.state = O),
                this._emitChars(i.REPLACEMENT_CHARACTER))
              : e === s.EOF
              ? (this._err(o.eofInScriptHtmlCommentLikeText),
                this._emitEOFToken())
              : ((this.state = O), this._emitCodePoint(e));
          }
          [N](e) {
            e === s.SOLIDUS
              ? ((this.tempBuff = []), (this.state = R))
              : Ve(e)
              ? ((this.tempBuff = []),
                this._emitChars("<"),
                this._reconsumeInState(F))
              : (this._emitChars("<"), this._reconsumeInState(O));
          }
          [R](e) {
            Ve(e)
              ? (this._createEndTagToken(), this._reconsumeInState(D))
              : (this._emitChars("</"), this._reconsumeInState(O));
          }
          [D](e) {
            if (Me(e))
              (this.currentToken.tagName += ze(e)), this.tempBuff.push(e);
            else if (Be(e))
              (this.currentToken.tagName += We(e)), this.tempBuff.push(e);
            else {
              if (this.lastStartTagName === this.currentToken.tagName) {
                if (je(e)) return void (this.state = U);
                if (e === s.SOLIDUS) return void (this.state = J);
                if (e === s.GREATER_THAN_SIGN)
                  return this._emitCurrentToken(), void (this.state = l);
              }
              this._emitChars("</"),
                this._emitSeveralCodePoints(this.tempBuff),
                this._reconsumeInState(O);
            }
          }
          [F](e) {
            je(e) || e === s.SOLIDUS || e === s.GREATER_THAN_SIGN
              ? ((this.state = this._isTempBufferEqualToScriptString() ? j : O),
                this._emitCodePoint(e))
              : Me(e)
              ? (this.tempBuff.push($e(e)), this._emitCodePoint(e))
              : Be(e)
              ? (this.tempBuff.push(e), this._emitCodePoint(e))
              : this._reconsumeInState(O);
          }
          [j](e) {
            e === s.HYPHEN_MINUS
              ? ((this.state = L), this._emitChars("-"))
              : e === s.LESS_THAN_SIGN
              ? ((this.state = B), this._emitChars("<"))
              : e === s.NULL
              ? (this._err(o.unexpectedNullCharacter),
                this._emitChars(i.REPLACEMENT_CHARACTER))
              : e === s.EOF
              ? (this._err(o.eofInScriptHtmlCommentLikeText),
                this._emitEOFToken())
              : this._emitCodePoint(e);
          }
          [L](e) {
            e === s.HYPHEN_MINUS
              ? ((this.state = M), this._emitChars("-"))
              : e === s.LESS_THAN_SIGN
              ? ((this.state = B), this._emitChars("<"))
              : e === s.NULL
              ? (this._err(o.unexpectedNullCharacter),
                (this.state = j),
                this._emitChars(i.REPLACEMENT_CHARACTER))
              : e === s.EOF
              ? (this._err(o.eofInScriptHtmlCommentLikeText),
                this._emitEOFToken())
              : ((this.state = j), this._emitCodePoint(e));
          }
          [M](e) {
            e === s.HYPHEN_MINUS
              ? this._emitChars("-")
              : e === s.LESS_THAN_SIGN
              ? ((this.state = B), this._emitChars("<"))
              : e === s.GREATER_THAN_SIGN
              ? ((this.state = f), this._emitChars(">"))
              : e === s.NULL
              ? (this._err(o.unexpectedNullCharacter),
                (this.state = j),
                this._emitChars(i.REPLACEMENT_CHARACTER))
              : e === s.EOF
              ? (this._err(o.eofInScriptHtmlCommentLikeText),
                this._emitEOFToken())
              : ((this.state = j), this._emitCodePoint(e));
          }
          [B](e) {
            e === s.SOLIDUS
              ? ((this.tempBuff = []), (this.state = V), this._emitChars("/"))
              : this._reconsumeInState(j);
          }
          [V](e) {
            je(e) || e === s.SOLIDUS || e === s.GREATER_THAN_SIGN
              ? ((this.state = this._isTempBufferEqualToScriptString() ? O : j),
                this._emitCodePoint(e))
              : Me(e)
              ? (this.tempBuff.push($e(e)), this._emitCodePoint(e))
              : Be(e)
              ? (this.tempBuff.push(e), this._emitCodePoint(e))
              : this._reconsumeInState(j);
          }
          [U](e) {
            je(e) ||
              (e === s.SOLIDUS || e === s.GREATER_THAN_SIGN || e === s.EOF
                ? this._reconsumeInState(q)
                : e === s.EQUALS_SIGN
                ? (this._err(o.unexpectedEqualsSignBeforeAttributeName),
                  this._createAttr("="),
                  (this.state = H))
                : (this._createAttr(""), this._reconsumeInState(H)));
          }
          [H](e) {
            je(e) || e === s.SOLIDUS || e === s.GREATER_THAN_SIGN || e === s.EOF
              ? (this._leaveAttrName(q), this._unconsume())
              : e === s.EQUALS_SIGN
              ? this._leaveAttrName($)
              : Me(e)
              ? (this.currentAttr.name += ze(e))
              : e === s.QUOTATION_MARK ||
                e === s.APOSTROPHE ||
                e === s.LESS_THAN_SIGN
              ? (this._err(o.unexpectedCharacterInAttributeName),
                (this.currentAttr.name += We(e)))
              : e === s.NULL
              ? (this._err(o.unexpectedNullCharacter),
                (this.currentAttr.name += i.REPLACEMENT_CHARACTER))
              : (this.currentAttr.name += We(e));
          }
          [q](e) {
            je(e) ||
              (e === s.SOLIDUS
                ? (this.state = J)
                : e === s.EQUALS_SIGN
                ? (this.state = $)
                : e === s.GREATER_THAN_SIGN
                ? ((this.state = l), this._emitCurrentToken())
                : e === s.EOF
                ? (this._err(o.eofInTag), this._emitEOFToken())
                : (this._createAttr(""), this._reconsumeInState(H)));
          }
          [$](e) {
            je(e) ||
              (e === s.QUOTATION_MARK
                ? (this.state = W)
                : e === s.APOSTROPHE
                ? (this.state = z)
                : e === s.GREATER_THAN_SIGN
                ? (this._err(o.missingAttributeValue),
                  (this.state = l),
                  this._emitCurrentToken())
                : this._reconsumeInState(G));
          }
          [W](e) {
            e === s.QUOTATION_MARK
              ? (this.state = K)
              : e === s.AMPERSAND
              ? ((this.returnState = W), (this.state = ke))
              : e === s.NULL
              ? (this._err(o.unexpectedNullCharacter),
                (this.currentAttr.value += i.REPLACEMENT_CHARACTER))
              : e === s.EOF
              ? (this._err(o.eofInTag), this._emitEOFToken())
              : (this.currentAttr.value += We(e));
          }
          [z](e) {
            e === s.APOSTROPHE
              ? (this.state = K)
              : e === s.AMPERSAND
              ? ((this.returnState = z), (this.state = ke))
              : e === s.NULL
              ? (this._err(o.unexpectedNullCharacter),
                (this.currentAttr.value += i.REPLACEMENT_CHARACTER))
              : e === s.EOF
              ? (this._err(o.eofInTag), this._emitEOFToken())
              : (this.currentAttr.value += We(e));
          }
          [G](e) {
            je(e)
              ? this._leaveAttrValue(U)
              : e === s.AMPERSAND
              ? ((this.returnState = G), (this.state = ke))
              : e === s.GREATER_THAN_SIGN
              ? (this._leaveAttrValue(l), this._emitCurrentToken())
              : e === s.NULL
              ? (this._err(o.unexpectedNullCharacter),
                (this.currentAttr.value += i.REPLACEMENT_CHARACTER))
              : e === s.QUOTATION_MARK ||
                e === s.APOSTROPHE ||
                e === s.LESS_THAN_SIGN ||
                e === s.EQUALS_SIGN ||
                e === s.GRAVE_ACCENT
              ? (this._err(o.unexpectedCharacterInUnquotedAttributeValue),
                (this.currentAttr.value += We(e)))
              : e === s.EOF
              ? (this._err(o.eofInTag), this._emitEOFToken())
              : (this.currentAttr.value += We(e));
          }
          [K](e) {
            je(e)
              ? this._leaveAttrValue(U)
              : e === s.SOLIDUS
              ? this._leaveAttrValue(J)
              : e === s.GREATER_THAN_SIGN
              ? (this._leaveAttrValue(l), this._emitCurrentToken())
              : e === s.EOF
              ? (this._err(o.eofInTag), this._emitEOFToken())
              : (this._err(o.missingWhitespaceBetweenAttributes),
                this._reconsumeInState(U));
          }
          [J](e) {
            e === s.GREATER_THAN_SIGN
              ? ((this.currentToken.selfClosing = !0),
                (this.state = l),
                this._emitCurrentToken())
              : e === s.EOF
              ? (this._err(o.eofInTag), this._emitEOFToken())
              : (this._err(o.unexpectedSolidusInTag),
                this._reconsumeInState(U));
          }
          [Y](e) {
            e === s.GREATER_THAN_SIGN
              ? ((this.state = l), this._emitCurrentToken())
              : e === s.EOF
              ? (this._emitCurrentToken(), this._emitEOFToken())
              : e === s.NULL
              ? (this._err(o.unexpectedNullCharacter),
                (this.currentToken.data += i.REPLACEMENT_CHARACTER))
              : (this.currentToken.data += We(e));
          }
          [Q](e) {
            this._consumeSequenceIfMatch(u.DASH_DASH_STRING, e, !0)
              ? (this._createCommentToken(), (this.state = X))
              : this._consumeSequenceIfMatch(u.DOCTYPE_STRING, e, !1)
              ? (this.state = ue)
              : this._consumeSequenceIfMatch(u.CDATA_START_STRING, e, !0)
              ? this.allowCDATA
                ? (this.state = Se)
                : (this._err(o.cdataInHtmlContent),
                  this._createCommentToken(),
                  (this.currentToken.data = "[CDATA["),
                  (this.state = Y))
              : this._ensureHibernation() ||
                (this._err(o.incorrectlyOpenedComment),
                this._createCommentToken(),
                this._reconsumeInState(Y));
          }
          [X](e) {
            e === s.HYPHEN_MINUS
              ? (this.state = Z)
              : e === s.GREATER_THAN_SIGN
              ? (this._err(o.abruptClosingOfEmptyComment),
                (this.state = l),
                this._emitCurrentToken())
              : this._reconsumeInState(ee);
          }
          [Z](e) {
            e === s.HYPHEN_MINUS
              ? (this.state = oe)
              : e === s.GREATER_THAN_SIGN
              ? (this._err(o.abruptClosingOfEmptyComment),
                (this.state = l),
                this._emitCurrentToken())
              : e === s.EOF
              ? (this._err(o.eofInComment),
                this._emitCurrentToken(),
                this._emitEOFToken())
              : ((this.currentToken.data += "-"), this._reconsumeInState(ee));
          }
          [ee](e) {
            e === s.HYPHEN_MINUS
              ? (this.state = ae)
              : e === s.LESS_THAN_SIGN
              ? ((this.currentToken.data += "<"), (this.state = te))
              : e === s.NULL
              ? (this._err(o.unexpectedNullCharacter),
                (this.currentToken.data += i.REPLACEMENT_CHARACTER))
              : e === s.EOF
              ? (this._err(o.eofInComment),
                this._emitCurrentToken(),
                this._emitEOFToken())
              : (this.currentToken.data += We(e));
          }
          [te](e) {
            e === s.EXCLAMATION_MARK
              ? ((this.currentToken.data += "!"), (this.state = re))
              : e === s.LESS_THAN_SIGN
              ? (this.currentToken.data += "!")
              : this._reconsumeInState(ee);
          }
          [re](e) {
            e === s.HYPHEN_MINUS
              ? (this.state = ne)
              : this._reconsumeInState(ee);
          }
          [ne](e) {
            e === s.HYPHEN_MINUS
              ? (this.state = ie)
              : this._reconsumeInState(ae);
          }
          [ie](e) {
            e !== s.GREATER_THAN_SIGN &&
              e !== s.EOF &&
              this._err(o.nestedComment),
              this._reconsumeInState(oe);
          }
          [ae](e) {
            e === s.HYPHEN_MINUS
              ? (this.state = oe)
              : e === s.EOF
              ? (this._err(o.eofInComment),
                this._emitCurrentToken(),
                this._emitEOFToken())
              : ((this.currentToken.data += "-"), this._reconsumeInState(ee));
          }
          [oe](e) {
            e === s.GREATER_THAN_SIGN
              ? ((this.state = l), this._emitCurrentToken())
              : e === s.EXCLAMATION_MARK
              ? (this.state = se)
              : e === s.HYPHEN_MINUS
              ? (this.currentToken.data += "-")
              : e === s.EOF
              ? (this._err(o.eofInComment),
                this._emitCurrentToken(),
                this._emitEOFToken())
              : ((this.currentToken.data += "--"), this._reconsumeInState(ee));
          }
          [se](e) {
            e === s.HYPHEN_MINUS
              ? ((this.currentToken.data += "--!"), (this.state = ae))
              : e === s.GREATER_THAN_SIGN
              ? (this._err(o.incorrectlyClosedComment),
                (this.state = l),
                this._emitCurrentToken())
              : e === s.EOF
              ? (this._err(o.eofInComment),
                this._emitCurrentToken(),
                this._emitEOFToken())
              : ((this.currentToken.data += "--!"), this._reconsumeInState(ee));
          }
          [ue](e) {
            je(e)
              ? (this.state = ce)
              : e === s.GREATER_THAN_SIGN
              ? this._reconsumeInState(ce)
              : e === s.EOF
              ? (this._err(o.eofInDoctype),
                this._createDoctypeToken(null),
                (this.currentToken.forceQuirks = !0),
                this._emitCurrentToken(),
                this._emitEOFToken())
              : (this._err(o.missingWhitespaceBeforeDoctypeName),
                this._reconsumeInState(ce));
          }
          [ce](e) {
            je(e) ||
              (Me(e)
                ? (this._createDoctypeToken(ze(e)), (this.state = le))
                : e === s.NULL
                ? (this._err(o.unexpectedNullCharacter),
                  this._createDoctypeToken(i.REPLACEMENT_CHARACTER),
                  (this.state = le))
                : e === s.GREATER_THAN_SIGN
                ? (this._err(o.missingDoctypeName),
                  this._createDoctypeToken(null),
                  (this.currentToken.forceQuirks = !0),
                  this._emitCurrentToken(),
                  (this.state = l))
                : e === s.EOF
                ? (this._err(o.eofInDoctype),
                  this._createDoctypeToken(null),
                  (this.currentToken.forceQuirks = !0),
                  this._emitCurrentToken(),
                  this._emitEOFToken())
                : (this._createDoctypeToken(We(e)), (this.state = le)));
          }
          [le](e) {
            je(e)
              ? (this.state = de)
              : e === s.GREATER_THAN_SIGN
              ? ((this.state = l), this._emitCurrentToken())
              : Me(e)
              ? (this.currentToken.name += ze(e))
              : e === s.NULL
              ? (this._err(o.unexpectedNullCharacter),
                (this.currentToken.name += i.REPLACEMENT_CHARACTER))
              : e === s.EOF
              ? (this._err(o.eofInDoctype),
                (this.currentToken.forceQuirks = !0),
                this._emitCurrentToken(),
                this._emitEOFToken())
              : (this.currentToken.name += We(e));
          }
          [de](e) {
            je(e) ||
              (e === s.GREATER_THAN_SIGN
                ? ((this.state = l), this._emitCurrentToken())
                : e === s.EOF
                ? (this._err(o.eofInDoctype),
                  (this.currentToken.forceQuirks = !0),
                  this._emitCurrentToken(),
                  this._emitEOFToken())
                : this._consumeSequenceIfMatch(u.PUBLIC_STRING, e, !1)
                ? (this.state = pe)
                : this._consumeSequenceIfMatch(u.SYSTEM_STRING, e, !1)
                ? (this.state = ve)
                : this._ensureHibernation() ||
                  (this._err(o.invalidCharacterSequenceAfterDoctypeName),
                  (this.currentToken.forceQuirks = !0),
                  this._reconsumeInState(xe)));
          }
          [pe](e) {
            je(e)
              ? (this.state = fe)
              : e === s.QUOTATION_MARK
              ? (this._err(o.missingWhitespaceAfterDoctypePublicKeyword),
                (this.currentToken.publicId = ""),
                (this.state = he))
              : e === s.APOSTROPHE
              ? (this._err(o.missingWhitespaceAfterDoctypePublicKeyword),
                (this.currentToken.publicId = ""),
                (this.state = me))
              : e === s.GREATER_THAN_SIGN
              ? (this._err(o.missingDoctypePublicIdentifier),
                (this.currentToken.forceQuirks = !0),
                (this.state = l),
                this._emitCurrentToken())
              : e === s.EOF
              ? (this._err(o.eofInDoctype),
                (this.currentToken.forceQuirks = !0),
                this._emitCurrentToken(),
                this._emitEOFToken())
              : (this._err(o.missingQuoteBeforeDoctypePublicIdentifier),
                (this.currentToken.forceQuirks = !0),
                this._reconsumeInState(xe));
          }
          [fe](e) {
            je(e) ||
              (e === s.QUOTATION_MARK
                ? ((this.currentToken.publicId = ""), (this.state = he))
                : e === s.APOSTROPHE
                ? ((this.currentToken.publicId = ""), (this.state = me))
                : e === s.GREATER_THAN_SIGN
                ? (this._err(o.missingDoctypePublicIdentifier),
                  (this.currentToken.forceQuirks = !0),
                  (this.state = l),
                  this._emitCurrentToken())
                : e === s.EOF
                ? (this._err(o.eofInDoctype),
                  (this.currentToken.forceQuirks = !0),
                  this._emitCurrentToken(),
                  this._emitEOFToken())
                : (this._err(o.missingQuoteBeforeDoctypePublicIdentifier),
                  (this.currentToken.forceQuirks = !0),
                  this._reconsumeInState(xe)));
          }
          [he](e) {
            e === s.QUOTATION_MARK
              ? (this.state = ge)
              : e === s.NULL
              ? (this._err(o.unexpectedNullCharacter),
                (this.currentToken.publicId += i.REPLACEMENT_CHARACTER))
              : e === s.GREATER_THAN_SIGN
              ? (this._err(o.abruptDoctypePublicIdentifier),
                (this.currentToken.forceQuirks = !0),
                this._emitCurrentToken(),
                (this.state = l))
              : e === s.EOF
              ? (this._err(o.eofInDoctype),
                (this.currentToken.forceQuirks = !0),
                this._emitCurrentToken(),
                this._emitEOFToken())
              : (this.currentToken.publicId += We(e));
          }
          [me](e) {
            e === s.APOSTROPHE
              ? (this.state = ge)
              : e === s.NULL
              ? (this._err(o.unexpectedNullCharacter),
                (this.currentToken.publicId += i.REPLACEMENT_CHARACTER))
              : e === s.GREATER_THAN_SIGN
              ? (this._err(o.abruptDoctypePublicIdentifier),
                (this.currentToken.forceQuirks = !0),
                this._emitCurrentToken(),
                (this.state = l))
              : e === s.EOF
              ? (this._err(o.eofInDoctype),
                (this.currentToken.forceQuirks = !0),
                this._emitCurrentToken(),
                this._emitEOFToken())
              : (this.currentToken.publicId += We(e));
          }
          [ge](e) {
            je(e)
              ? (this.state = ye)
              : e === s.GREATER_THAN_SIGN
              ? ((this.state = l), this._emitCurrentToken())
              : e === s.QUOTATION_MARK
              ? (this._err(
                  o.missingWhitespaceBetweenDoctypePublicAndSystemIdentifiers
                ),
                (this.currentToken.systemId = ""),
                (this.state = _e))
              : e === s.APOSTROPHE
              ? (this._err(
                  o.missingWhitespaceBetweenDoctypePublicAndSystemIdentifiers
                ),
                (this.currentToken.systemId = ""),
                (this.state = Ee))
              : e === s.EOF
              ? (this._err(o.eofInDoctype),
                (this.currentToken.forceQuirks = !0),
                this._emitCurrentToken(),
                this._emitEOFToken())
              : (this._err(o.missingQuoteBeforeDoctypeSystemIdentifier),
                (this.currentToken.forceQuirks = !0),
                this._reconsumeInState(xe));
          }
          [ye](e) {
            je(e) ||
              (e === s.GREATER_THAN_SIGN
                ? (this._emitCurrentToken(), (this.state = l))
                : e === s.QUOTATION_MARK
                ? ((this.currentToken.systemId = ""), (this.state = _e))
                : e === s.APOSTROPHE
                ? ((this.currentToken.systemId = ""), (this.state = Ee))
                : e === s.EOF
                ? (this._err(o.eofInDoctype),
                  (this.currentToken.forceQuirks = !0),
                  this._emitCurrentToken(),
                  this._emitEOFToken())
                : (this._err(o.missingQuoteBeforeDoctypeSystemIdentifier),
                  (this.currentToken.forceQuirks = !0),
                  this._reconsumeInState(xe)));
          }
          [ve](e) {
            je(e)
              ? (this.state = be)
              : e === s.QUOTATION_MARK
              ? (this._err(o.missingWhitespaceAfterDoctypeSystemKeyword),
                (this.currentToken.systemId = ""),
                (this.state = _e))
              : e === s.APOSTROPHE
              ? (this._err(o.missingWhitespaceAfterDoctypeSystemKeyword),
                (this.currentToken.systemId = ""),
                (this.state = Ee))
              : e === s.GREATER_THAN_SIGN
              ? (this._err(o.missingDoctypeSystemIdentifier),
                (this.currentToken.forceQuirks = !0),
                (this.state = l),
                this._emitCurrentToken())
              : e === s.EOF
              ? (this._err(o.eofInDoctype),
                (this.currentToken.forceQuirks = !0),
                this._emitCurrentToken(),
                this._emitEOFToken())
              : (this._err(o.missingQuoteBeforeDoctypeSystemIdentifier),
                (this.currentToken.forceQuirks = !0),
                this._reconsumeInState(xe));
          }
          [be](e) {
            je(e) ||
              (e === s.QUOTATION_MARK
                ? ((this.currentToken.systemId = ""), (this.state = _e))
                : e === s.APOSTROPHE
                ? ((this.currentToken.systemId = ""), (this.state = Ee))
                : e === s.GREATER_THAN_SIGN
                ? (this._err(o.missingDoctypeSystemIdentifier),
                  (this.currentToken.forceQuirks = !0),
                  (this.state = l),
                  this._emitCurrentToken())
                : e === s.EOF
                ? (this._err(o.eofInDoctype),
                  (this.currentToken.forceQuirks = !0),
                  this._emitCurrentToken(),
                  this._emitEOFToken())
                : (this._err(o.missingQuoteBeforeDoctypeSystemIdentifier),
                  (this.currentToken.forceQuirks = !0),
                  this._reconsumeInState(xe)));
          }
          [_e](e) {
            e === s.QUOTATION_MARK
              ? (this.state = we)
              : e === s.NULL
              ? (this._err(o.unexpectedNullCharacter),
                (this.currentToken.systemId += i.REPLACEMENT_CHARACTER))
              : e === s.GREATER_THAN_SIGN
              ? (this._err(o.abruptDoctypeSystemIdentifier),
                (this.currentToken.forceQuirks = !0),
                this._emitCurrentToken(),
                (this.state = l))
              : e === s.EOF
              ? (this._err(o.eofInDoctype),
                (this.currentToken.forceQuirks = !0),
                this._emitCurrentToken(),
                this._emitEOFToken())
              : (this.currentToken.systemId += We(e));
          }
          [Ee](e) {
            e === s.APOSTROPHE
              ? (this.state = we)
              : e === s.NULL
              ? (this._err(o.unexpectedNullCharacter),
                (this.currentToken.systemId += i.REPLACEMENT_CHARACTER))
              : e === s.GREATER_THAN_SIGN
              ? (this._err(o.abruptDoctypeSystemIdentifier),
                (this.currentToken.forceQuirks = !0),
                this._emitCurrentToken(),
                (this.state = l))
              : e === s.EOF
              ? (this._err(o.eofInDoctype),
                (this.currentToken.forceQuirks = !0),
                this._emitCurrentToken(),
                this._emitEOFToken())
              : (this.currentToken.systemId += We(e));
          }
          [we](e) {
            je(e) ||
              (e === s.GREATER_THAN_SIGN
                ? (this._emitCurrentToken(), (this.state = l))
                : e === s.EOF
                ? (this._err(o.eofInDoctype),
                  (this.currentToken.forceQuirks = !0),
                  this._emitCurrentToken(),
                  this._emitEOFToken())
                : (this._err(o.unexpectedCharacterAfterDoctypeSystemIdentifier),
                  this._reconsumeInState(xe)));
          }
          [xe](e) {
            e === s.GREATER_THAN_SIGN
              ? (this._emitCurrentToken(), (this.state = l))
              : e === s.NULL
              ? this._err(o.unexpectedNullCharacter)
              : e === s.EOF && (this._emitCurrentToken(), this._emitEOFToken());
          }
          [Se](e) {
            e === s.RIGHT_SQUARE_BRACKET
              ? (this.state = Te)
              : e === s.EOF
              ? (this._err(o.eofInCdata), this._emitEOFToken())
              : this._emitCodePoint(e);
          }
          [Te](e) {
            e === s.RIGHT_SQUARE_BRACKET
              ? (this.state = Ae)
              : (this._emitChars("]"), this._reconsumeInState(Se));
          }
          [Ae](e) {
            e === s.GREATER_THAN_SIGN
              ? (this.state = l)
              : e === s.RIGHT_SQUARE_BRACKET
              ? this._emitChars("]")
              : (this._emitChars("]]"), this._reconsumeInState(Se));
          }
          [ke](e) {
            (this.tempBuff = [s.AMPERSAND]),
              e === s.NUMBER_SIGN
                ? (this.tempBuff.push(e), (this.state = Pe))
                : Ue(e)
                ? this._reconsumeInState(Ce)
                : (this._flushCodePointsConsumedAsCharacterReference(),
                  this._reconsumeInState(this.returnState));
          }
          [Ce](e) {
            const t = this._matchNamedCharacterReference(e);
            if (this._ensureHibernation()) this.tempBuff = [s.AMPERSAND];
            else if (t) {
              const e = this.tempBuff[this.tempBuff.length - 1] === s.SEMICOLON;
              this._isCharacterReferenceAttributeQuirk(e) ||
                (e ||
                  this._errOnNextCodePoint(
                    o.missingSemicolonAfterCharacterReference
                  ),
                (this.tempBuff = t)),
                this._flushCodePointsConsumedAsCharacterReference(),
                (this.state = this.returnState);
            } else
              this._flushCodePointsConsumedAsCharacterReference(),
                (this.state = Oe);
          }
          [Oe](e) {
            Ue(e)
              ? this._isCharacterReferenceInAttribute()
                ? (this.currentAttr.value += We(e))
                : this._emitCodePoint(e)
              : (e === s.SEMICOLON &&
                  this._err(o.unknownNamedCharacterReference),
                this._reconsumeInState(this.returnState));
          }
          [Pe](e) {
            (this.charRefCode = 0),
              e === s.LATIN_SMALL_X || e === s.LATIN_CAPITAL_X
                ? (this.tempBuff.push(e), (this.state = Ie))
                : this._reconsumeInState(Ne);
          }
          [Ie](e) {
            !(function (e) {
              return Le(e) || He(e) || qe(e);
            })(e)
              ? (this._err(o.absenceOfDigitsInNumericCharacterReference),
                this._flushCodePointsConsumedAsCharacterReference(),
                this._reconsumeInState(this.returnState))
              : this._reconsumeInState(Re);
          }
          [Ne](e) {
            Le(e)
              ? this._reconsumeInState(De)
              : (this._err(o.absenceOfDigitsInNumericCharacterReference),
                this._flushCodePointsConsumedAsCharacterReference(),
                this._reconsumeInState(this.returnState));
          }
          [Re](e) {
            He(e)
              ? (this.charRefCode = 16 * this.charRefCode + e - 55)
              : qe(e)
              ? (this.charRefCode = 16 * this.charRefCode + e - 87)
              : Le(e)
              ? (this.charRefCode = 16 * this.charRefCode + e - 48)
              : e === s.SEMICOLON
              ? (this.state = Fe)
              : (this._err(o.missingSemicolonAfterCharacterReference),
                this._reconsumeInState(Fe));
          }
          [De](e) {
            Le(e)
              ? (this.charRefCode = 10 * this.charRefCode + e - 48)
              : e === s.SEMICOLON
              ? (this.state = Fe)
              : (this._err(o.missingSemicolonAfterCharacterReference),
                this._reconsumeInState(Fe));
          }
          [Fe]() {
            if (this.charRefCode === s.NULL)
              this._err(o.nullCharacterReference),
                (this.charRefCode = s.REPLACEMENT_CHARACTER);
            else if (this.charRefCode > 1114111)
              this._err(o.characterReferenceOutsideUnicodeRange),
                (this.charRefCode = s.REPLACEMENT_CHARACTER);
            else if (i.isSurrogate(this.charRefCode))
              this._err(o.surrogateCharacterReference),
                (this.charRefCode = s.REPLACEMENT_CHARACTER);
            else if (i.isUndefinedCodePoint(this.charRefCode))
              this._err(o.noncharacterCharacterReference);
            else if (
              i.isControlCodePoint(this.charRefCode) ||
              this.charRefCode === s.CARRIAGE_RETURN
            ) {
              this._err(o.controlCharacterReference);
              const e = c[this.charRefCode];
              e && (this.charRefCode = e);
            }
            (this.tempBuff = [this.charRefCode]),
              this._flushCodePointsConsumedAsCharacterReference(),
              this._reconsumeInState(this.returnState);
          }
        }
        (Ke.CHARACTER_TOKEN = "CHARACTER_TOKEN"),
          (Ke.NULL_CHARACTER_TOKEN = "NULL_CHARACTER_TOKEN"),
          (Ke.WHITESPACE_CHARACTER_TOKEN = "WHITESPACE_CHARACTER_TOKEN"),
          (Ke.START_TAG_TOKEN = "START_TAG_TOKEN"),
          (Ke.END_TAG_TOKEN = "END_TAG_TOKEN"),
          (Ke.COMMENT_TOKEN = "COMMENT_TOKEN"),
          (Ke.DOCTYPE_TOKEN = "DOCTYPE_TOKEN"),
          (Ke.EOF_TOKEN = "EOF_TOKEN"),
          (Ke.HIBERNATION_TOKEN = "HIBERNATION_TOKEN"),
          (Ke.MODE = {
            DATA: l,
            RCDATA: d,
            RAWTEXT: p,
            SCRIPT_DATA: f,
            PLAINTEXT: h,
          }),
          (Ke.getTokenAttr = function (e, t) {
            for (let r = e.attrs.length - 1; r >= 0; r--)
              if (e.attrs[r].name === t) return e.attrs[r].value;
            return null;
          }),
          (e.exports = Ke);
      } };
