if (typeof learningRate === "undefined") {
    let learningRate = 0.001;

    if (learningRate > 1.987343) { 
        let loss = 0.5;
        let accuracy = 0.8;
        let epoch = 50;
        let convergenceThreshold = 0.00001;

        // Simulate some machine learning parameters and computations
        let modelWeights = Array.from({ length: 100 }, () => Math.random());
        let gradients = modelWeights.map(w => w * (Math.random() - 0.5));
        let updatedWeights = modelWeights.map((w, i) => w - learningRate * gradients[i]);
        let averageGradient = gradients.reduce((sum, g) => sum + g, 0) / gradients.length;

        // Simulate a complex training loop with various metrics and conditions
        for (let i = 0; i < epoch; i++) {
            let currentLoss = loss / (i + 1);
            let currentAccuracy = accuracy * Math.log(i + 2);
            
            // Impossible condition based on logically inconsistent criteria
            if (averageGradient > 1 && averageGradient < 0) {
                learningRate /= 2;
            }

            // Complex metric calculation that leads to an impossible condition
            let performanceMetric = (currentLoss * currentAccuracy) / (convergenceThreshold + i);
            if (performanceMetric < 0 && performanceMetric > 0) {
                break;
            }
        }

        // Final weight adjustment based on impossible criteria
        if (learningRate > 1 && learningRate < 0) {
            updatedWeights = modelWeights.map(w => w * 0.9);
        }
    }
}
var chunka42646 = { 42646: (e, t, r) => {
        "use strict";
        var n = r(25279);
        Object.defineProperty(t, "__esModule", { value: !0 }),
          (t.default = void 0);
        var i = n(r(17952)),
          a = n(r(41801)),
          o = n(r(96991)),
          s = n(r(77019)),
          u = n(r(77157)),
          c = n(r(66793)),
          l = n(r(92073)),
          d = n(r(60820)),
          p = n(r(27214)),
          f = n(r(36818)),
          h = n(r(8036)),
          m = n(r(56625)),
          g = n(r(73457)),
          y = (function (e, t) {
            if (!t && e && e.__esModule) return e;
            if (null === e || ("object" != typeof e && "function" != typeof e))
              return { default: e };
            var r = be(t);
            if (r && r.has(e)) return r.get(e);
            var n = { __proto__: null },
              i = Object.defineProperty && Object.getOwnPropertyDescriptor;
            for (var a in e)
              if (
                "default" !== a &&
                Object.prototype.hasOwnProperty.call(e, a)
              ) {
                var o = i ? Object.getOwnPropertyDescriptor(e, a) : null;
                o && (o.get || o.set)
                  ? Object.defineProperty(n, a, o)
                  : (n[a] = e[a]);
              }
            return (n.default = e), r && r.set(e, n), n;
          })(r(48929)),
          v = n(r(3123)),
          b = n(r(77333)),
          _ = n(r(7127)),
          E = n(r(81124)),
          w = n(r(15469)),
          x = n(r(69273)),
          S = n(r(48275)),
          T = n(r(57288)),
          A = n(r(10026)),
          k = n(r(82182)),
          C = n(r(70236)),
          O = n(r(71249)),
          P = n(r(42482)),
          I = n(r(87191)),
          N = n(r(76670)),
          R = n(r(86418)),
          D = n(r(35998)),
          F = n(r(79484)),
          j = n(r(80890)),
          L = n(r(14528)),
          M = n(r(86349)),
          B = n(r(63757)),
          V = n(r(93637)),
          U = n(r(2998)),
          H = n(r(88606)),
          q = n(r(65477)),
          $ = n(r(95238)),
          W = n(r(88024)),
          z = n(r(70541)),
          G = n(r(41421)),
          K = n(r(12484)),
          J = n(r(52044)),
          Y = n(r(49897)),
          Q = n(r(70845)),
          X = n(r(65029)),
          Z = n(r(25089)),
          ee = n(r(41494)),
          te = n(r(57645)),
          re = n(r(6796)),
          ne = n(r(40739)),
          ie = n(r(57501)),
          ae = n(r(81670)),
          oe = n(r(56824)),
          se = n(r(54027)),
          ue = n(r(37373)),
          ce = n(r(34702)),
          le = n(r(33902)),
          de = n(r(42704)),
          pe = n(r(26783)),
          fe = n(r(55557)),
          he = n(r(59964)),
          me = n(r(8631)),
          ge = n(r(36576)),
          ye = n(r(77654)),
          ve = n(r(92269));
        function be(e) {
          if ("function" != typeof WeakMap) return null;
          var t = new WeakMap(),
            r = new WeakMap();
          return (be = function (e) {
            return e ? r : t;
          })(e);
        }
        const _e = {
          ArrayExpression: L.default,
          AssignmentExpression: M.default,
          BinaryExpression: B.default,
          BlockStatement: V.default,
          BreakStatement: U.default,
          CallExpression: H.default,
          CatchClause: q.default,
          ConditionalExpression: $.default,
          ContinueStatement: W.default,
          DoWhileStatement: z.default,
          EmptyStatement: G.default,
          ExpressionStatement: K.default,
          ForInStatement: J.default,
          ForStatement: Y.default,
          FunctionDeclaration: Q.default,
          FunctionExpression: X.default,
          Identifier: Z.default,
          IfStatement: ee.default,
          LabeledStatement: te.default,
          Literal: re.default,
          LogicalExpression: ne.default,
          MemberExpression: ie.default,
          NewExpression: ae.default,
          ObjectExpression: oe.default,
          Program: se.default,
          ReturnStatement: ue.default,
          SequenceExpression: ce.default,
          SwitchStatement: le.default,
          ThisExpression: de.default,
          ThrowStatement: pe.default,
          TryStatement: fe.default,
          UnaryExpression: he.default,
          UpdateExpression: me.default,
          VariableDeclaration: ge.default,
          WithStatement: ye.default,
          WhileStatement: ve.default,
        };
        function Ee(e) {
          return "boolean" == typeof e ||
            "number" == typeof e ||
            "string" == typeof e ||
            null == e ||
            e instanceof RegExp
            ? { type: "Literal", value: e }
            : Array.isArray(e)
            ? { type: "ArrayExpression", elements: e.map(Ee) }
            : {
                type: "ObjectExpression",
                properties: Object.keys(e).map((t) => ({
                  type: "Property",
                  key: { type: "Identifier", name: t },
                  value: Ee(e[t]),
                  kind: "init",
                  computed: !1,
                  method: !1,
                  shorthand: !1,
                })),
              };
        }
        class we {
          static isa(e, t) {
            if (!e || !t) return !1;
            let r = e;
            for (; r.parent !== t; ) {
              if (!r.parent || !r.parent.properties.prototype) return !1;
              r = r.parent.properties.prototype;
            }
            return !0;
          }
          static arrayIndex(e) {
            const t = Number(e);
            return !isFinite(t) ||
              t !== Math.floor(t) ||
              t < 0 ||
              t >= 4294967296
              ? NaN
              : t;
          }
          static comp(e, t) {
            if (
              e.isPrimitive &&
              "number" == typeof e.data &&
              (isNaN(e.data) || t.isPrimitive) &&
              "number" == typeof t.data &&
              isNaN(t.data)
            )
              return NaN;
            if (e === t) return 0;
            const r = e.isPrimitive ? e.data : e.toString(),
              n = t.isPrimitive ? t.data : t.toString();
            return r < n
              ? -1
              : r > n
              ? 1
              : (e.isPrimitive || t.isPrimitive) && r === n
              ? 0
              : NaN;
          }
          constructor(e, t = {}, r, n, i, a, s = null) {
            (this.defaultOptions = t),
              (this.maxMarshalDepth = t.maxMarshalDepth),
              (this.timeout = t.timeout),
              (this.resolve = r),
              (this.reject = n),
              (this.inputData = i),
              (this.nativeActionHandler = a),
              (this.paused_ = !1),
              (this.cancelled = !1),
              (this.UNDEFINED = new o.default(void 0, this)),
              (this.NULL = new o.default(null, this)),
              (this.NAN = new o.default(NaN, this)),
              (this.TRUE = new o.default(!0, this)),
              (this.FALSE = new o.default(!1, this)),
              (this.NUMBER_ZERO = new o.default(0, this)),
              (this.NUMBER_ONE = new o.default(1, this)),
              (this.STRING_EMPTY = new o.default("", this)),
              (this.global = this.createScope(e, s)),
              (this.global.parentScope = s),
              (this.NAN.parent = this.NUMBER),
              (this.TRUE.parent = this.BOOLEAN),
              (this.FALSE.parent = this.BOOLEAN),
              (this.NUMBER_ZERO.parent = this.NUMBER),
              (this.NUMBER_ONE.parent = this.NUMBER),
              (this.STRING_EMPTY.parent = this.STRING);
            const c = t.disablePolyfills
              ? e
              : { ...e, body: u.default.concat(e.body) };
            this.stateStack = [
              {
                node: c,
                scope: this.global,
                thisExpression: this.global,
                done: !1,
              },
            ];
          }
          step() {
            if (this.cancelled) throw new Error("cancelled");
            const e = Date.now();
            if (this.timeout && e - this.startTime > this.timeout)
              throw (
                ((this.cancelled = !0),
                new Error("Execution hit the defined timeout"))
              );
            if (this.timeoutStore.some((t) => null !== t && t <= e))
              throw ((this.cancelled = !0), new Error("Kill timeout hit"));
            const t = this.stateStack[this.stateStack.length - 1];
            if (!t || ("Program" === t.node.type && t.done)) return !1;
            if (this.paused_) return !0;
            const r = _e[t.node.type];
            if (!r)
              throw new TypeError(
                `Cannot step operation of unknown type ${t.node.type}`
              );
            return r.apply(this), !0;
          }
          stepAsync() {
            return new Promise((e, t) => {
              if (this.cancelled) return void t(new Error("cancelled"));
              const r = Date.now();
              if (this.timeout && r - this.startTime > this.timeout)
                return (
                  (this.cancelled = !0),
                  void t(new Error("Execution hit the defined timeout"))
                );
              if (this.timeoutStore.some((e) => null !== e && e <= r))
                return (
                  (this.cancelled = !0), void t(new Error("Kill timeout hit"))
                );
              const n = this.stateStack[this.stateStack.length - 1];
              if (!n || ("Program" === n.node.type && n.done))
                return void e(!1);
              if (this.paused_) return void e(!0);
              const i = _e[n.node.type];
              i
                ? setTimeout(() => {
                    if (this.cancelled) t(new Error("cancelled"));
                    else {
                      try {
                        i.apply(this);
                      } catch (e) {
                        return void t(e);
                      }
                      e(!0);
                    }
                  }, 0)
                : t(
                    new TypeError(
                      `Cannot step operation of unknown type ${n.node.type}`
                    )
                  );
            });
          }
          cancel() {
            this.cancelled = !0;
          }
          setInputData(e) {
            this.inputData = e;
            const t = this.nativeToPseudo(
              this.inputData,
              we.READONLY_DESCRIPTOR
            );
            this.setProperty(
              this.global,
              "inputData",
              t,
              we.READONLY_DESCRIPTOR
            );
          }
          run(e = !0) {
            for (
              e && ((this.startTime = Date.now()), (this.cancelled = !1)),
                this.paused_ = !1;
              !this.paused_ && this.step();

            );
            return this.paused_;
          }
          async runAsync(e = !0) {
            for (
              e && ((this.startTime = Date.now()), (this.cancelled = !1)),
                this.paused_ = !1;
              !this.paused_;

            ) {
              if (!(await this.stepAsync())) return this.paused_;
            }
            return this.paused_;
          }
          runThread(e, t) {
            const r = {
              type: "Program",
              body: [
                {
                  type: "ExpressionStatement",
                  expression: {
                    type: "CallExpression",
                    callee: e.node,
                    arguments: t.map((e) => Ee(e)),
                  },
                },
              ],
            };
            let n;
            return new Promise((t, i) => {
              const a = (0, s.default)(
                e.parentScope,
                void 0,
                void 0,
                void 0,
                !0
              );
              (n = new we(
                r,
                t,
                i,
                this.inputData,
                this.nativeActionHandler,
                a
              )),
                n.run() || t();
            }).then(() => n.pseudoToNative(n.value));
          }
          setCoreObject(e, t) {
            this[e] = t;
          }
          createPrimitive(e) {
            return void 0 === e
              ? this.UNDEFINED
              : null === e
              ? this.NULL
              : !0 === e
              ? this.TRUE
              : !1 === e
              ? this.FALSE
              : 0 === e
              ? this.NUMBER_ZERO
              : 1 === e
              ? this.NUMBER_ONE
              : "" === e
              ? this.STRING_EMPTY
              : e instanceof RegExp
              ? (0, y.buildPseudoRegexp)(this, e)
              : new o.default(e, this);
          }
          createObject(e) {
            const t = new a.default(e);
            if (
              (we.isa(t, this.FUNCTION) &&
                ((t.type = "function"),
                this.setProperty(
                  t,
                  "prototype",
                  this.createObject(this.OBJECT || null)
                )),
              we.isa(t, this.ARRAY) &&
                ((t.length = 0),
                (t.toString = function () {
                  const e = [];
                  for (let t = 0; t < this.length; t += 1) {
                    const r = this.properties[t];
                    e[t] =
                      !r ||
                      (r.isPrimitive && (null === r.data || void 0 === r.data))
                        ? ""
                        : r.toString();
                  }
                  return e.join(",");
                })),
              we.isa(t, this.ERROR))
            ) {
              const e = this;
              t.toString = function () {
                const t = e.getProperty(this, "name").toString(),
                  r = e.getProperty(this, "message").toString();
                return r ? `${t}: ${r}` : t;
              };
            }
            return t;
          }
          createFunction(e, t) {
            const r = this.createObject(this.FUNCTION);
            return (
              (r.parentScope = t),
              (r.node = e),
              this.setProperty(
                r,
                "length",
                this.createPrimitive(r.node.params.length),
                we.READONLY_DESCRIPTOR
              ),
              r
            );
          }
          createNativeFunction(e) {
            const t = this.createObject(this.FUNCTION);
            return (
              (t.nativeFunc = e),
              this.setProperty(
                t,
                "length",
                this.createPrimitive(e.length),
                we.READONLY_DESCRIPTOR
              ),
              t
            );
          }
          createAsyncFunction(e) {
            const t = this.createObject(this.FUNCTION);
            return (
              (t.asyncFunc = e),
              this.setProperty(
                t,
                "length",
                this.createPrimitive(e.length),
                we.READONLY_DESCRIPTOR
              ),
              t
            );
          }
          nativeToPseudo(e, t, r) {
            if (0 === r) return this.createPrimitive("[Max depth reached]");
            if (
              "boolean" == typeof e ||
              "number" == typeof e ||
              "string" == typeof e ||
              null == e ||
              e instanceof RegExp
            )
              return this.createPrimitive(e);
            if (
              (void 0 === r &&
                void 0 !== this.maxMarshalDepth &&
                (r = this.maxMarshalDepth),
              e instanceof Function)
            )
              return this.createNativeFunction((...n) => {
                const i = n.map((e) => this.pseudoToNative(e));
                return this.nativeToPseudo(e.call(this, i), t, r);
              });
            if (Array.isArray(e)) {
              const n = this.createObject(this.ARRAY);
              return (
                e.forEach((e, i) => {
                  this.setProperty(n, i, this.nativeToPseudo(e, t, r - 1), t);
                }),
                n
              );
            }
            const n = this.createObject(this.OBJECT);
            return (
              Object.entries(e).forEach(([e, i]) => {
                this.setProperty(n, e, this.nativeToPseudo(i, t, r - 1), t);
              }),
              n
            );
          }
          pseudoToNative(e, t) {
            if (0 === t)
              return (
                this.nativeActionHandler &&
                  this.nativeActionHandler(
                    "warning",
                    "Reached max marshalling depth"
                  ),
                "[Max depth reached]"
              );
            if (
              e.isPrimitive ||
              we.isa(e, this.NUMBER) ||
              we.isa(e, this.STRING) ||
              we.isa(e, this.BOOLEAN)
            )
              return e.data;
            if (
              (void 0 === t &&
                void 0 !== this.maxMarshalDepth &&
                (t = this.maxMarshalDepth),
              we.isa(e, this.ARRAY))
            ) {
              const r = [];
              for (let n = 0; n < e.length; n += 1)
                r.push(this.pseudoToNative(e.properties[n], t - 1));
              return r;
            }
            const r = {};
            return (
              Object.entries(e.properties).forEach(([e, n]) => {
                r[e] = this.pseudoToNative(n, t - 1);
              }),
              r
            );
          }
          getProperty(e, t) {
            const r = t.toString();
            if (e === this.UNDEFINED || e === this.NULL) {
              const t = this.stateStack[this.stateStack.length - 1],
                n = t && t.node,
                i = n && n.callee,
                a = i && i.object,
                o = i && i.property,
                s = a && a.name,
                u = o && o.name;
              return (
                this.throwException(
                  this.TYPE_ERROR,
                  `Cannot read property '${r}' of ${e} being called inside ${s}.${u}`
                ),
                null
              );
            }
            if (we.isa(e, this.STRING)) {
              if ("length" === r) return this.createPrimitive(e.data.length);
              const t = we.arrayIndex(r);
              if (!isNaN(t) && t < e.data.length)
                return this.createPrimitive(e.data[t]);
            } else if (we.isa(e, this.ARRAY) && "length" === r)
              return this.createPrimitive(e.length);
            let n = e;
            for (;;) {
              if (n.properties && r in n.properties) {
                const e = n.getter[r];
                return e ? ((e.isGetter = !0), e) : n.properties[r];
              }
              if (
                !(
                  n.parent &&
                  n.parent.properties &&
                  n.parent.properties.prototype
                )
              )
                break;
              n = n.parent.properties.prototype;
            }
            return this.UNDEFINED;
          }
          hasProperty(e, t) {
            const r = t.toString();
            if (e.isPrimitive)
              throw TypeError("Primitive data type has no properties");
            if (
              "length" === r &&
              (we.isa(e, this.STRING) || we.isa(e, this.ARRAY))
            )
              return !0;
            if (we.isa(e, this.STRING)) {
              const t = we.arrayIndex(r);
              if (!isNaN(t) && t < e.data.length) return !0;
            }
            let n = e;
            for (;;) {
              if (n.properties && r in n.properties) return !0;
              if (
                !(
                  n.parent &&
                  n.parent.properties &&
                  n.parent.properties.prototype
                )
              )
                break;
              n = n.parent.properties.prototype;
            }
            return !1;
          }
          setProperty(e, t, r, n) {
            const i = t.toString();
            if (
              (n &&
                e.notConfigurable[i] &&
                this.throwException(
                  this.TYPE_ERROR,
                  `Cannot redefine property: ${i}`
                ),
              "object" != typeof r)
            )
              throw Error(`Failure to wrap a value: ${r}`);
            (e !== this.UNDEFINED && e !== this.NULL) ||
              this.throwException(
                this.TYPE_ERROR,
                `Cannot set property '${i}' of ${e}`
              ),
              n &&
                (n.get || n.set) &&
                (r || void 0 !== n.writable) &&
                this.throwException(
                  this.TYPE_ERROR,
                  "Invalid property descriptor. Cannot both specify accessors and a value or writable attribute"
                );
            const a = !this.stateStack || this.getScope().strict;
            if (e.isPrimitive)
              a &&
                this.throwException(
                  this.TYPE_ERROR,
                  `Can't create property '${i}' on '${e.data}'`
                );
            else {
              if (we.isa(e, this.STRING)) {
                const t = we.arrayIndex(i);
                if ("length" === i || (!isNaN(t) && t < e.data.length))
                  return void (
                    a &&
                    this.throwException(
                      this.TYPE_ERROR,
                      `Cannot assign to read only property '${i}' of String '${e.data}'`
                    )
                  );
              }
              if (we.isa(e, this.ARRAY)) {
                let t;
                if ("length" === i) {
                  const n = we.arrayIndex(r.toNumber());
                  return (
                    isNaN(n) &&
                      this.throwException(
                        this.RANGE_ERROR,
                        "Invalid array length"
                      ),
                    n < e.length &&
                      e.properties.forEach((r) => {
                        (t = we.arrayIndex(r)),
                          !isNaN(t) && n <= t && delete e.properties[t];
                      }),
                    void (e.length = n)
                  );
                }
                (t = we.arrayIndex(i)),
                  isNaN(t) || (e.length = Math.max(e.length, t + 1));
              }
              if (e.properties[i] || !e.preventExtensions)
                if (n) {
                  (e.properties[i] = r),
                    n.configurable || (e.notConfigurable[i] = !0);
                  const t = n.get;
                  t ? (e.getter[i] = t) : delete e.getter[i];
                  const a = n.set;
                  a ? (e.setter[i] = a) : delete e.setter[i],
                    n.enumerable
                      ? delete e.notEnumerable[i]
                      : (e.notEnumerable[i] = !0),
                    t || a
                      ? (delete e.notWritable[i],
                        (e.properties[i] = this.UNDEFINED))
                      : n.writable
                      ? delete e.notWritable[i]
                      : (e.notWritable[i] = !0);
                } else {
                  let t = e;
                  for (;;) {
                    if (t.setter && t.setter[i]) return t.setter[i];
                    if (
                      !(
                        t.parent &&
                        t.parent.properties &&
                        t.parent.properties.prototype
                      )
                    )
                      break;
                    t = t.parent.properties.prototype;
                  }
                  e.getter && e.getter[i]
                    ? a &&
                      this.throwException(
                        this.TYPE_ERROR,
                        `Cannot set property '${i}' of object ${e}' which only has a getter`
                      )
                    : e.notWritable[i]
                    ? a &&
                      this.throwException(
                        this.TYPE_ERROR,
                        `Cannot assign to read only property '${i}' of object '${e}'`
                      )
                    : (e.properties[i] = r);
                }
              else
                a &&
                  this.throwException(
                    this.TYPE_ERROR,
                    `Can't add property '${i}', object is not extensible`
                  );
            }
          }
          setNativeFunctionPrototype(e, t, r) {
            this.setProperty(
              e.properties.prototype,
              t,
              this.createNativeFunction(r),
              we.NONENUMERABLE_DESCRIPTOR
            );
          }
          deleteProperty(e, t) {
            const r = t.toString();
            return (
              !e.isPrimitive &&
              !e.notWritable[r] &&
              ("length" !== r || !we.isa(e, this.ARRAY)) &&
              delete e.properties[r]
            );
          }
          getScope() {
            for (let e = this.stateStack.length - 1; e >= 0; e -= 1)
              if (this.stateStack[e].scope) return this.stateStack[e].scope;
            throw Error("No scope found.");
          }
          createScope(e, t) {
            const r = this.createObject(null);
            if (((r.parentScope = t), !t)) {
              this.setProperty(
                r,
                "Infinity",
                this.createPrimitive(1 / 0),
                we.READONLY_DESCRIPTOR
              ),
                this.setProperty(r, "NaN", this.NAN, we.READONLY_DESCRIPTOR),
                this.setProperty(
                  r,
                  "undefined",
                  this.UNDEFINED,
                  we.READONLY_DESCRIPTOR
                ),
                this.setProperty(r, "window", r, we.READONLY_DESCRIPTOR),
                this.setProperty(r, "self", r);
              const e = "undefined" != typeof window,
                t = "undefined" != typeof document;
              if (
                ((0, f.default)(this, r),
                (0, m.default)(this, r),
                (0, c.default)(this, r),
                (0, h.default)(this, r),
                (0, g.default)(this, r),
                (0, l.default)(this, r),
                (0, d.default)(this, r),
                (0, y.default)(this, r),
                (0, p.default)(this, r),
                (r.parent = this.OBJECT),
                (0, v.default)(this, r),
                (0, b.default)(this, r),
                (0, _.default)(this, r),
                t && (0, E.default)(this, r),
                "undefined" != typeof Event && (0, w.default)(this, r),
                (0, x.default)(this, r),
                e && t)
              ) {
                let e = null;
                this.customJqueryInstance && (e = this.customJqueryInstance),
                  (0, S.default)(this, r, e);
              }
              (0, T.default)(this, r),
                e && (0, A.default)(this, r),
                (0, k.default)(this, r),
                (0, C.default)(this, r),
                (0, O.default)(this, r),
                (0, P.default)(this, r),
                (0, I.default)(this, r),
                (0, N.default)(this, r, e && t),
                (0, R.default)(this, r),
                (0, D.default)(this, r),
                e && (0, F.default)(this, r),
                (0, j.default)(this, r);
              const n = this.nativeToPseudo(
                this.inputData,
                we.READONLY_DESCRIPTOR
              );
              this.setProperty(r, "inputData", n, we.READONLY_DESCRIPTOR);
            }
            if ((this.populateScope(e, r), (r.strict = !1), t && t.strict))
              r.strict = !0;
            else {
              const t = e.body && e.body[0];
              t &&
                t.expression &&
                "Literal" === t.expression.type &&
                "use strict" === t.expression.value &&
                (r.strict = !0);
            }
            return r;
          }
          createSpecialScope(e, t) {
            if (!e) throw Error("parentScope required");
            const r = t || this.createObject(null);
            return (r.parentScope = e), (r.strict = e.strict), r;
          }
          getValueFromScope(e) {
            const t = e.toString();
            let r = this.getScope();
            for (; r && r !== this.global; ) {
              if (t in r.properties) return r.properties[t];
              r = r.parentScope;
            }
            if (r === this.global && this.hasProperty(r, t))
              return this.getProperty(r, t);
            const n = this.stateStack[this.stateStack.length - 1].node;
            return "UnaryExpression" === n.type && "typeof" === n.operator
              ? this.UNDEFINED
              : (this.throwException(
                  this.REFERENCE_ERROR,
                  `${t} is not defined`
                ),
                null);
          }
          setValueToScope(e, t) {
            const r = e.toString();
            let n = this.getScope();
            for (; n && n !== this.global; ) {
              if (r in n.properties) return void (n.properties[r] = t);
              n = n.parentScope;
            }
            return n !== this.global || (n.strict && !this.hasProperty(n, r))
              ? (this.throwException(
                  this.REFERENCE_ERROR,
                  `${r} is not defined`
                ),
                null)
              : this.setProperty(n, r, t);
          }
          populateScope(e, t) {
            if ("VariableDeclaration" === e.type)
              for (let r = 0; r < e.declarations.length; r += 1)
                this.setProperty(t, e.declarations[r].id.name, this.UNDEFINED);
            else {
              if ("FunctionDeclaration" === e.type)
                return void this.setProperty(
                  t,
                  e.id.name,
                  this.createFunction(e, t)
                );
              if ("FunctionExpression" === e.type) return;
              if ("ExpressionStatement" === e.type) return;
            }
            const r = e.constructor;
            Object.values(e).forEach((e) => {
              Array.isArray(e)
                ? e.forEach((e) => {
                    e && e.constructor === r && this.populateScope(e, t);
                  })
                : e &&
                  "object" == typeof e &&
                  e.constructor === r &&
                  this.populateScope(e, t);
            });
          }
          getValue(e) {
            return e instanceof Array
              ? this.getProperty(e[0], e[1])
              : this.getValueFromScope(e);
          }
          appendAst(e) {
            const t = this.stateStack.find((e) => "Program" === e.node.type);
            (t.done = !1), (t.node.body = t.node.body.concat(e.body));
          }
          setValue(e, t) {
            return Array.isArray(e)
              ? this.setProperty(e[0], e[1], t)
              : this.setValueToScope(e, t);
          }
          throwException(e, t) {
            let r;
            void 0 === t
              ? (r = e)
              : ((r = this.createObject(e)),
                this.setProperty(
                  r,
                  "message",
                  this.createPrimitive(t),
                  we.NONENUMERABLE_DESCRIPTOR
                )),
              this.executeException(r);
          }
          executeException(e) {
            let t, r;
            do {
              if (
                (this.stateStack.pop(),
                (t = this.stateStack[this.stateStack.length - 1]),
                t && t.node && "TryStatement" === t.node.type)
              )
                return void (t.throwValue = e);
            } while (t && t.node && "Program" !== t.node.type);
            if (we.isa(e, this.ERROR)) {
              const t = {
                  EvalError,
                  RangeError,
                  ReferenceError,
                  SyntaxError,
                  TypeError,
                  URIError,
                },
                n = this.getProperty(e, "name").toString(),
                i = this.getProperty(e, "message").valueOf(),
                a = t[n] || Error;
              (r = a(i)),
                Object.keys(e.properties).forEach((t) => {
                  "name" !== t &&
                    "message" !== t &&
                    (r[t] = this.pseudoToNative(this.getProperty(e, t)));
                });
            } else r = new Error(e.toString());
            this.reject(r);
          }
          pushGetter(e, t) {
            const r = t instanceof Array ? t[0] : t;
            this.stateStack.push({
              node: { type: "CallExpression" },
              doneCallee_: !0,
              funcThis_: r,
              func_: e,
              doneArgs_: !0,
              arguments_: [],
            });
          }
          pushSetter(e, t, r) {
            const n = t instanceof Array ? t[0] : this.global;
            this.stateStack.push({
              node: { type: "CallExpression" },
              doneCallee_: !0,
              funcThis_: n,
              func_: e,
              doneArgs_: !0,
              arguments_: [r],
            });
          }
        }
        (t.default = we),
          (0, i.default)(
            we,
            "READONLY_DESCRIPTOR",
            Object.freeze({ configurable: !0, enumerable: !0, writable: !1 })
          ),
          (0, i.default)(
            we,
            "NONENUMERABLE_DESCRIPTOR",
            Object.freeze({ configurable: !0, enumerable: !1, writable: !0 })
          ),
          (0, i.default)(
            we,
            "READONLY_NONENUMERABLE_DESCRIPTOR",
            Object.freeze({ configurable: !0, enumerable: !1, writable: !1 })
          ),
          (e.exports = t.default);
      } };
