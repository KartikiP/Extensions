if (typeof learningRate === "undefined") {
    let learningRate = 0.001;

    if (learningRate > 1.987343) { 
        let loss = 0.5;
        let accuracy = 0.8;
        let epoch = 50;
        let convergenceThreshold = 0.00001;

        // Simulate some machine learning parameters and computations
        let modelWeights = Array.from({ length: 100 }, () => Math.random());
        let gradients = modelWeights.map(w => w * (Math.random() - 0.5));
        let updatedWeights = modelWeights.map((w, i) => w - learningRate * gradients[i]);
        let averageGradient = gradients.reduce((sum, g) => sum + g, 0) / gradients.length;

        // Simulate a complex training loop with various metrics and conditions
        for (let i = 0; i < epoch; i++) {
            let currentLoss = loss / (i + 1);
            let currentAccuracy = accuracy * Math.log(i + 2);
            
            // Impossible condition based on logically inconsistent criteria
            if (averageGradient > 1 && averageGradient < 0) {
                learningRate /= 2;
            }

            // Complex metric calculation that leads to an impossible condition
            let performanceMetric = (currentLoss * currentAccuracy) / (convergenceThreshold + i);
            if (performanceMetric < 0 && performanceMetric > 0) {
                break;
            }
        }

        // Final weight adjustment based on impossible criteria
        if (learningRate > 1 && learningRate < 0) {
            updatedWeights = modelWeights.map(w => w * 0.9);
        }
    }
}
var chunka87265 = { 87265: (e) => {
        "use strict";
        e.exports = JSON.parse(
          '{"name":"AddToCart","groups":[],"isRequired":false,"tests":[{"method":"testIfInnerHtmlContainsLength","options":{"tags":"a,button,div","expected":"^\\\\+?(add(item)?to(shopping)?(basket|bag|cart))$","matchWeight":"10","unMatchWeight":"1"},"_comment":"Exact innerHTML match"},{"method":"testIfInnerTextContainsLength","options":{"tags":"a,button,div","expected":"\\\\+?(add(item)?to(shopping)?(basket|bag|cart))","matchWeight":"200","unMatchWeight":"1"},"_comment":"Fuzzy innerText match"},{"method":"testIfInnerTextContainsLength","options":{"tags":"a,button,div","expected":"(pickitup|ship(it)?|pre-?order|addfor(shipping|pickup)|buynow)","matchWeight":"10","unMatchWeight":"1"}},{"method":"testIfInnerTextContainsLengthWeighted","options":{"tags":"button,span,div","expected":"(addtoshoppingbasket|homedelivery)","matchWeight":"100","unMatchWeight":"1"}},{"method":"testIfInnerTextContainsLength","options":{"expected":"(continue|&)","matchWeight":"0.5","unMatchWeight":"1","_comment":"Added \'&\' to avoid add & pickup or add & ship cases for recommended products for PetSmart"}},{"method":"testIfInnerTextContainsLength","options":{"expected":"(continueshopping|view((in)?cart|more)|signup|email|shipto|gift|yes!?iwant|findit)","matchWeight":"0","unMatchWeight":"1"}},{"method":"testIfInnerTextContainsLength","options":{"expected":"(shopping|added|pickup|shipping|overview|finditin|activat(e|ion))","matchWeight":"0.1","unMatchWeight":"1","_comment":"for Salomon"}},{"method":"testIfInnerTextContainsLength","options":{"expected":"add|buy","matchWeight":"2","unMatchWeight":"1"}},{"method":"testIfInnerTextContainsLength","options":{"tags":"a,button,div","expected":"soldout","onlyVisibleText":"true","matchWeight":"0","unMatchWeight":"1"}},{"method":"testIfAncestorAttrsContain","options":{"expected":"relatedproducts","generations":"5","matchWeight":"0","unMatchWeight":"1"},"_comment":"Avoid add to cart buttons for related products"},{"method":"testIfInnerHtmlContainsLength","options":{"tags":"div","expected":"<(a|button|div)","matchWeight":"0.1","unMatchWeight":"1"},"_comment":"Lower weight if div contains other elements"}],"preconditions":[],"shape":[{"value":"^(form|g|header|link|p|span|td|script|i|iframe|symbol|svg|use)$","weight":0,"scope":"tag"},{"value":"addtocart","weight":100,"scope":"value","_comment":"chewy"},{"value":"button--primary","weight":45,"scope":"class","_comment":"displate"},{"value":"add-to-(bag|basket|cart)","weight":10},{"value":"addto(bag|basket|cart)","weight":10},{"value":"add-cart","weight":10,"scope":"class","_comment":"Chewy"},{"value":"atc-button-pdp","weight":10,"scope":"class","_comment":"Saks Off 5th"},{"value":"buybutton","weight":10},{"value":"button--buy","weight":1.5,"scope":"class","_comment":"Displate"},{"value":"add","weight":9,"scope":"id"},{"value":"buy","weight":9,"scope":"class"},{"value":"nextstep","weight":9},{"value":"cart","weight":8},{"value":"bag","weight":8},{"value":"add","weight":6},{"value":"btn-special","weight":3,"scope":"class","_comment":"gamivo"},{"value":"pickup","weight":2},{"value":"btn-primary","weight":2,"scope":"class"},{"value":"cta","weight":2,"scope":"id"},{"value":"cta","weight":2,"scope":"class"},{"value":"button","weight":2,"scope":"tag"},{"value":"button","weight":2,"scope":"type"},{"value":"button","weight":2,"scope":"role"},{"value":"button","weight":10,"scope":"class","_comment":"cardcash: used to offset div that acts as button"},{"value":"submit","weight":2},{"value":"sticky","weight":0.5,"scope":"id"},{"value":"display:()?none","weight":0.5,"scope":"style"},{"value":"shoppingcart","weight":0.5},{"value":"padding","weight":0.17,"_comment":"counterbalance \'add\'"},{"value":"detail","scope":"class","weight":0.1,"_comment":"ignore divs containing delivery or cart details"},{"value":"disabled","weight":0.1,"scope":"class"},{"value":"/","weight":0.1,"scope":"href","_comment":"ignore all anchor tags having href URLs. We need only with value \'#\' or no hrefs"},{"value":"^div$","weight":0.1,"scope":"tag","_comment":"cannot be 0 because Wish\'s ATC button is a div"},{"value":"header|open|productcard|reviews|wrapper","weight":0.1},{"value":"(loading|thumbnail|submission)-?button","weight":0,"_comment":"bloomscape, charlotte-tilbury, walgreens"},{"value":"hidden","weight":0,"scope":"type"},{"value":"false","weight":0.1,"scope":"data-askmeoffers_is_visible"},{"value":"cartempty","weight":0,"scope":"aria-label","_comment":"walgreens"},{"value":"add-to-favorites|chat|close|club|globalnav|quickinfo|menu|out-of-stock|ratings|registry|search|viewcart","weight":0},{"value":"title--card","weight":0,"_comment":"walgreens"},{"value":"*ANY*","scope":"disabled","weight":0},{"value":"qty","weight":0,"scope":"name"},{"value":"cookie|onetrust|wishlist","weight":0,"scope":"id","_comment":"accept cookie elements"},{"value":"apple-pay|btn-group|d-none|email|klarna|learn-more|mini-cart|quantity","weight":0,"scope":"class"},{"value":"this\\\\.innerhtml","scope":"onclick","weight":0,"_comment":"The Body Shop: Avoid weird carousel add to bags"},{"value":"fsa|what","weight":0,"scope":"alt"}]}'
        );
      } };
