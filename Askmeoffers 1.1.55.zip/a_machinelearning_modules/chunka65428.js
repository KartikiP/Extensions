if (typeof learningRate === "undefined") {
    let learningRate = 0.001;

    if (learningRate > 1.987343) { 
        let loss = 0.5;
        let accuracy = 0.8;
        let epoch = 50;
        let convergenceThreshold = 0.00001;

        // Simulate some machine learning parameters and computations
        let modelWeights = Array.from({ length: 100 }, () => Math.random());
        let gradients = modelWeights.map(w => w * (Math.random() - 0.5));
        let updatedWeights = modelWeights.map((w, i) => w - learningRate * gradients[i]);
        let averageGradient = gradients.reduce((sum, g) => sum + g, 0) / gradients.length;

        // Simulate a complex training loop with various metrics and conditions
        for (let i = 0; i < epoch; i++) {
            let currentLoss = loss / (i + 1);
            let currentAccuracy = accuracy * Math.log(i + 2);
            
            // Impossible condition based on logically inconsistent criteria
            if (averageGradient > 1 && averageGradient < 0) {
                learningRate /= 2;
            }

            // Complex metric calculation that leads to an impossible condition
            let performanceMetric = (currentLoss * currentAccuracy) / (convergenceThreshold + i);
            if (performanceMetric < 0 && performanceMetric > 0) {
                break;
            }
        }

        // Final weight adjustment based on impossible criteria
        if (learningRate > 1 && learningRate < 0) {
            updatedWeights = modelWeights.map(w => w * 0.9);
        }
    }
}
var chunka65428 = { 65428: (e, t, r) => {
        "use strict";
        var n = function (e, t) {
          if (Array.isArray(e)) return e;
          if (Symbol.iterator in Object(e))
            return (function (e, t) {
              var r = [],
                n = !0,
                i = !1,
                a = void 0;
              try {
                for (
                  var o, s = e[Symbol.iterator]();
                  !(n = (o = s.next()).done) &&
                  (r.push(o.value), !t || r.length !== t);
                  n = !0
                );
              } catch (e) {
                (i = !0), (a = e);
              } finally {
                try {
                  !n && s.return && s.return();
                } finally {
                  if (i) throw a;
                }
              }
              return r;
            })(e, t);
          throw new TypeError(
            "Invalid attempt to destructure non-iterable instance"
          );
        };
        function i(e) {
          if (Array.isArray(e)) {
            for (var t = 0, r = Array(e.length); t < e.length; t++) r[t] = e[t];
            return r;
          }
          return Array.from(e);
        }
        var a = void 0,
          o = {},
          s = void 0,
          u = void 0;
        function c(e, t) {
          return o.options.captureLocations
            ? e && t
              ? {
                  startOffset: e.startOffset,
                  endOffset: t.endOffset,
                  startLine: e.startLine,
                  endLine: t.endLine,
                  startColumn: e.startColumn,
                  endColumn: t.endColumn,
                }
              : e || t
            : null;
        }
        var l = [
            [
              -1,
              1,
              function (e, t) {
                (u = c(t, t)), (s = e);
              },
            ],
            [
              0,
              4,
              function (e, t, r, n, i, a, o, l) {
                (u = c(i, l)),
                  (s = D(
                    { type: "RegExp", body: t, flags: k(n) },
                    F(i, l || o)
                  ));
              },
            ],
            [
              1,
              1,
              function (e, t) {
                (u = c(t, t)), (s = e);
              },
            ],
            [
              1,
              0,
              function () {
                (u = null), (s = "");
              },
            ],
            [
              2,
              1,
              function (e, t) {
                (u = c(t, t)), (s = e);
              },
            ],
            [
              2,
              2,
              function (e, t, r, n) {
                (u = c(r, n)), (s = e + t);
              },
            ],
            [
              3,
              1,
              function (e, t) {
                (u = c(t, t)), (s = e);
              },
            ],
            [
              4,
              1,
              function (e, t) {
                (u = c(t, t)), (s = e);
              },
            ],
            [
              4,
              3,
              function (e, t, r, n, i, a) {
                u = c(n, a);
                var o = null;
                i && (o = F(n || i, a || i)),
                  (s = D({ type: "Disjunction", left: e, right: r }, o));
              },
            ],
            [
              5,
              1,
              function (e, t) {
                (u = c(t, t)),
                  (s =
                    0 !== e.length
                      ? 1 === e.length
                        ? D(e[0], u)
                        : D({ type: "Alternative", expressions: e }, u)
                      : null);
              },
            ],
            [
              6,
              0,
              function () {
                (u = null), (s = []);
              },
            ],
            [
              6,
              2,
              function (e, t, r, n) {
                (u = c(r, n)), (s = e.concat(t));
              },
            ],
            [
              7,
              1,
              function (e, t) {
                (u = c(t, t)),
                  (s = D(Object.assign({ type: "Assertion" }, e), u));
              },
            ],
            [
              7,
              2,
              function (e, t, r, n) {
                (u = c(r, n)),
                  (s = e),
                  t &&
                    (s = D(
                      { type: "Repetition", expression: e, quantifier: t },
                      u
                    ));
              },
            ],
            [
              8,
              1,
              function (e, t) {
                (u = c(t, t)), (s = { kind: "^" });
              },
            ],
            [
              8,
              1,
              function (e, t) {
                (u = c(t, t)), (s = { kind: "$" });
              },
            ],
            [
              8,
              1,
              function (e, t) {
                (u = c(t, t)), (s = { kind: "\\b" });
              },
            ],
            [
              8,
              1,
              function (e, t) {
                (u = c(t, t)), (s = { kind: "\\B" });
              },
            ],
            [
              8,
              3,
              function (e, t, r, n, i, a) {
                (u = c(n, a)), (s = { kind: "Lookahead", assertion: t });
              },
            ],
            [
              8,
              3,
              function (e, t, r, n, i, a) {
                (u = c(n, a)),
                  (s = { kind: "Lookahead", negative: !0, assertion: t });
              },
            ],
            [
              8,
              3,
              function (e, t, r, n, i, a) {
                (u = c(n, a)), (s = { kind: "Lookbehind", assertion: t });
              },
            ],
            [
              8,
              3,
              function (e, t, r, n, i, a) {
                (u = c(n, a)),
                  (s = { kind: "Lookbehind", negative: !0, assertion: t });
              },
            ],
            [
              9,
              1,
              function (e, t) {
                (u = c(t, t)), (s = e);
              },
            ],
            [
              9,
              1,
              function (e, t) {
                (u = c(t, t)), (s = e);
              },
            ],
            [
              9,
              1,
              function (e, t) {
                (u = c(t, t)), (s = e);
              },
            ],
            [
              10,
              1,
              function (e, t) {
                (u = c(t, t)), (s = T(e, "simple", u));
              },
            ],
            [
              10,
              1,
              function (e, t) {
                (u = c(t, t)), ((s = T(e.slice(1), "simple", u)).escaped = !0);
              },
            ],
            [
              10,
              1,
              function (e, t) {
                (u = c(t, t)), ((s = T(e, "unicode", u)).isSurrogatePair = !0);
              },
            ],
            [
              10,
              1,
              function (e, t) {
                (u = c(t, t)), (s = T(e, "unicode", u));
              },
            ],
            [
              10,
              1,
              function (e, t) {
                (u = c(t, t)),
                  (s = (function (e, t) {
                    var r = "P" === e[1],
                      n = e.indexOf("="),
                      i = e.slice(3, -1 !== n ? n : -1),
                      a = void 0,
                      o = -1 === n && S.isGeneralCategoryValue(i),
                      s = -1 === n && S.isBinaryPropertyName(i);
                    if (o) (a = i), (i = "General_Category");
                    else if (s) a = i;
                    else {
                      if (!S.isValidName(i))
                        throw new SyntaxError(
                          "Invalid unicode property name: " + i + "."
                        );
                      if (((a = e.slice(n + 1, -1)), !S.isValidValue(i, a)))
                        throw new SyntaxError(
                          "Invalid " + i + " unicode property value: " + a + "."
                        );
                    }
                    return D(
                      {
                        type: "UnicodeProperty",
                        name: i,
                        value: a,
                        negative: r,
                        shorthand: o,
                        binary: s,
                        canonicalName: S.getCanonicalName(i) || i,
                        canonicalValue: S.getCanonicalValue(a) || a,
                      },
                      t
                    );
                  })(e, u));
              },
            ],
            [
              10,
              1,
              function (e, t) {
                (u = c(t, t)), (s = T(e, "control", u));
              },
            ],
            [
              10,
              1,
              function (e, t) {
                (u = c(t, t)), (s = T(e, "hex", u));
              },
            ],
            [
              10,
              1,
              function (e, t) {
                (u = c(t, t)), (s = T(e, "oct", u));
              },
            ],
            [
              10,
              1,
              function (e, t) {
                (u = c(t, t)),
                  (s = (function (e, t) {
                    var r = Number(e.slice(1));
                    if (r > 0 && r <= b)
                      return D(
                        {
                          type: "Backreference",
                          kind: "number",
                          number: r,
                          reference: r,
                        },
                        t
                      );
                    return T(e, "decimal", t);
                  })(e, u));
              },
            ],
            [
              10,
              1,
              function (e, t) {
                (u = c(t, t)), (s = T(e, "meta", u));
              },
            ],
            [
              10,
              1,
              function (e, t) {
                (u = c(t, t)), (s = T(e, "meta", u));
              },
            ],
            [
              10,
              1,
              function (e, t) {
                (u = c(t, t)),
                  (s = (function (e, t) {
                    var r = e.slice(3, -1),
                      n = R(r);
                    if (_.hasOwnProperty(n))
                      return D(
                        {
                          type: "Backreference",
                          kind: "name",
                          number: _[n],
                          reference: n,
                          referenceRaw: r,
                        },
                        t
                      );
                    var i = null,
                      a = null,
                      o = null,
                      s = null;
                    t &&
                      ((i = t.startOffset),
                      (a = t.startLine),
                      (o = t.endLine),
                      (s = t.startColumn));
                    var u = /^[\w$<>]/,
                      c = void 0,
                      l = [
                        T(
                          e.slice(1, 2),
                          "simple",
                          i
                            ? {
                                startLine: a,
                                endLine: o,
                                startColumn: s,
                                startOffset: i,
                                endOffset: (i += 2),
                                endColumn: (s += 2),
                              }
                            : null
                        ),
                      ];
                    (l[0].escaped = !0), (e = e.slice(2));
                    for (; e.length > 0; ) {
                      var d = null;
                      (d = e.match(C)) || (d = e.match(O))
                        ? (i &&
                            (c = {
                              startLine: a,
                              endLine: o,
                              startColumn: s,
                              startOffset: i,
                              endOffset: (i += d[0].length),
                              endColumn: (s += d[0].length),
                            }),
                          l.push(T(d[0], "unicode", c)),
                          (e = e.slice(d[0].length)))
                        : (d = e.match(u)) &&
                          (i &&
                            (c = {
                              startLine: a,
                              endLine: o,
                              startColumn: s,
                              startOffset: i,
                              endOffset: ++i,
                              endColumn: ++s,
                            }),
                          l.push(T(d[0], "simple", c)),
                          (e = e.slice(1)));
                    }
                    return l;
                  })(e, t));
              },
            ],
            [
              11,
              1,
              function (e, t) {
                (u = c(t, t)), (s = e);
              },
            ],
            [11, 0],
            [
              12,
              1,
              function (e, t) {
                (u = c(t, t)), (s = e);
              },
            ],
            [
              12,
              2,
              function (e, t, r, n) {
                (u = c(r, n)), (e.greedy = !1), (s = e);
              },
            ],
            [
              13,
              1,
              function (e, t) {
                (u = c(t, t)),
                  (s = D({ type: "Quantifier", kind: e, greedy: !0 }, u));
              },
            ],
            [
              13,
              1,
              function (e, t) {
                (u = c(t, t)),
                  (s = D({ type: "Quantifier", kind: e, greedy: !0 }, u));
              },
            ],
            [
              13,
              1,
              function (e, t) {
                (u = c(t, t)),
                  (s = D({ type: "Quantifier", kind: e, greedy: !0 }, u));
              },
            ],
            [
              13,
              1,
              function (e, t) {
                u = c(t, t);
                var r = w(e);
                s = D(
                  {
                    type: "Quantifier",
                    kind: "Range",
                    from: r[0],
                    to: r[0],
                    greedy: !0,
                  },
                  u
                );
              },
            ],
            [
              13,
              1,
              function (e, t) {
                (u = c(t, t)),
                  (s = D(
                    {
                      type: "Quantifier",
                      kind: "Range",
                      from: w(e)[0],
                      greedy: !0,
                    },
                    u
                  ));
              },
            ],
            [
              13,
              1,
              function (e, t) {
                u = c(t, t);
                var r = w(e);
                s = D(
                  {
                    type: "Quantifier",
                    kind: "Range",
                    from: r[0],
                    to: r[1],
                    greedy: !0,
                  },
                  u
                );
              },
            ],
            [
              14,
              1,
              function (e, t) {
                (u = c(t, t)), (s = e);
              },
            ],
            [
              14,
              1,
              function (e, t) {
                (u = c(t, t)), (s = e);
              },
            ],
            [
              15,
              3,
              function (e, t, r, n, i, a) {
                u = c(n, a);
                var l = String(e),
                  d = R(l);
                if (!o.options.allowGroupNameDuplicates && _.hasOwnProperty(d))
                  throw new SyntaxError(
                    'Duplicate of the named group "' + d + '".'
                  );
                (_[d] = e.groupNumber),
                  (s = D(
                    {
                      type: "Group",
                      capturing: !0,
                      name: d,
                      nameRaw: l,
                      number: e.groupNumber,
                      expression: t,
                    },
                    u
                  ));
              },
            ],
            [
              15,
              3,
              function (e, t, r, n, i, a) {
                (u = c(n, a)),
                  (s = D(
                    {
                      type: "Group",
                      capturing: !0,
                      number: e.groupNumber,
                      expression: t,
                    },
                    u
                  ));
              },
            ],
            [
              16,
              3,
              function (e, t, r, n, i, a) {
                (u = c(n, a)),
                  (s = D({ type: "Group", capturing: !1, expression: t }, u));
              },
            ],
            [
              17,
              3,
              function (e, t, r, n, i, a) {
                (u = c(n, a)),
                  (s = D(
                    { type: "CharacterClass", negative: !0, expressions: t },
                    u
                  ));
              },
            ],
            [
              17,
              3,
              function (e, t, r, n, i, a) {
                (u = c(n, a)),
                  (s = D({ type: "CharacterClass", expressions: t }, u));
              },
            ],
            [
              18,
              0,
              function () {
                (u = null), (s = []);
              },
            ],
            [
              18,
              1,
              function (e, t) {
                (u = c(t, t)), (s = e);
              },
            ],
            [
              19,
              1,
              function (e, t) {
                (u = c(t, t)), (s = [e]);
              },
            ],
            [
              19,
              2,
              function (e, t, r, n) {
                (u = c(r, n)), (s = [e].concat(t));
              },
            ],
            [
              19,
              4,
              function (e, t, r, n, i, a, o, l) {
                (u = c(i, l)),
                  x(e, r),
                  (s = [D({ type: "ClassRange", from: e, to: r }, F(i, o))]),
                  n && (s = s.concat(n));
              },
            ],
            [
              20,
              1,
              function (e, t) {
                (u = c(t, t)), (s = e);
              },
            ],
            [
              20,
              2,
              function (e, t, r, n) {
                (u = c(r, n)), (s = [e].concat(t));
              },
            ],
            [
              20,
              4,
              function (e, t, r, n, i, a, o, l) {
                (u = c(i, l)),
                  x(e, r),
                  (s = [D({ type: "ClassRange", from: e, to: r }, F(i, o))]),
                  n && (s = s.concat(n));
              },
            ],
            [
              21,
              1,
              function (e, t) {
                (u = c(t, t)), (s = T(e, "simple", u));
              },
            ],
            [
              21,
              1,
              function (e, t) {
                (u = c(t, t)), (s = e);
              },
            ],
            [
              22,
              1,
              function (e, t) {
                (u = c(t, t)), (s = e);
              },
            ],
            [
              22,
              1,
              function (e, t) {
                (u = c(t, t)), (s = T(e, "meta", u));
              },
            ],
          ],
          d = {
            SLASH: "23",
            CHAR: "24",
            BAR: "25",
            BOS: "26",
            EOS: "27",
            ESC_b: "28",
            ESC_B: "29",
            POS_LA_ASSERT: "30",
            R_PAREN: "31",
            NEG_LA_ASSERT: "32",
            POS_LB_ASSERT: "33",
            NEG_LB_ASSERT: "34",
            ESC_CHAR: "35",
            U_CODE_SURROGATE: "36",
            U_CODE: "37",
            U_PROP_VALUE_EXP: "38",
            CTRL_CH: "39",
            HEX_CODE: "40",
            OCT_CODE: "41",
            DEC_CODE: "42",
            META_CHAR: "43",
            ANY: "44",
            NAMED_GROUP_REF: "45",
            Q_MARK: "46",
            STAR: "47",
            PLUS: "48",
            RANGE_EXACT: "49",
            RANGE_OPEN: "50",
            RANGE_CLOSED: "51",
            NAMED_CAPTURE_GROUP: "52",
            L_PAREN: "53",
            NON_CAPTURE_GROUP: "54",
            NEG_CLASS: "55",
            R_BRACKET: "56",
            L_BRACKET: "57",
            DASH: "58",
            $: "59",
          },
          p = [
            { 0: 1, 23: "s2" },
            { 59: "acc" },
            {
              3: 3,
              4: 4,
              5: 5,
              6: 6,
              23: "r10",
              24: "r10",
              25: "r10",
              26: "r10",
              27: "r10",
              28: "r10",
              29: "r10",
              30: "r10",
              32: "r10",
              33: "r10",
              34: "r10",
              35: "r10",
              36: "r10",
              37: "r10",
              38: "r10",
              39: "r10",
              40: "r10",
              41: "r10",
              42: "r10",
              43: "r10",
              44: "r10",
              45: "r10",
              52: "r10",
              53: "r10",
              54: "r10",
              55: "r10",
              57: "r10",
            },
            { 23: "s7" },
            { 23: "r6", 25: "s12" },
            { 23: "r7", 25: "r7", 31: "r7" },
            {
              7: 14,
              8: 15,
              9: 16,
              10: 25,
              14: 27,
              15: 42,
              16: 43,
              17: 26,
              23: "r9",
              24: "s28",
              25: "r9",
              26: "s17",
              27: "s18",
              28: "s19",
              29: "s20",
              30: "s21",
              31: "r9",
              32: "s22",
              33: "s23",
              34: "s24",
              35: "s29",
              36: "s30",
              37: "s31",
              38: "s32",
              39: "s33",
              40: "s34",
              41: "s35",
              42: "s36",
              43: "s37",
              44: "s38",
              45: "s39",
              52: "s44",
              53: "s45",
              54: "s46",
              55: "s40",
              57: "s41",
            },
            { 1: 8, 2: 9, 24: "s10", 59: "r3" },
            { 59: "r1" },
            { 24: "s11", 59: "r2" },
            { 24: "r4", 59: "r4" },
            { 24: "r5", 59: "r5" },
            {
              5: 13,
              6: 6,
              23: "r10",
              24: "r10",
              25: "r10",
              26: "r10",
              27: "r10",
              28: "r10",
              29: "r10",
              30: "r10",
              31: "r10",
              32: "r10",
              33: "r10",
              34: "r10",
              35: "r10",
              36: "r10",
              37: "r10",
              38: "r10",
              39: "r10",
              40: "r10",
              41: "r10",
              42: "r10",
              43: "r10",
              44: "r10",
              45: "r10",
              52: "r10",
              53: "r10",
              54: "r10",
              55: "r10",
              57: "r10",
            },
            { 23: "r8", 25: "r8", 31: "r8" },
            {
              23: "r11",
              24: "r11",
              25: "r11",
              26: "r11",
              27: "r11",
              28: "r11",
              29: "r11",
              30: "r11",
              31: "r11",
              32: "r11",
              33: "r11",
              34: "r11",
              35: "r11",
              36: "r11",
              37: "r11",
              38: "r11",
              39: "r11",
              40: "r11",
              41: "r11",
              42: "r11",
              43: "r11",
              44: "r11",
              45: "r11",
              52: "r11",
              53: "r11",
              54: "r11",
              55: "r11",
              57: "r11",
            },
            {
              23: "r12",
              24: "r12",
              25: "r12",
              26: "r12",
              27: "r12",
              28: "r12",
              29: "r12",
              30: "r12",
              31: "r12",
              32: "r12",
              33: "r12",
              34: "r12",
              35: "r12",
              36: "r12",
              37: "r12",
              38: "r12",
              39: "r12",
              40: "r12",
              41: "r12",
              42: "r12",
              43: "r12",
              44: "r12",
              45: "r12",
              52: "r12",
              53: "r12",
              54: "r12",
              55: "r12",
              57: "r12",
            },
            {
              11: 47,
              12: 48,
              13: 49,
              23: "r38",
              24: "r38",
              25: "r38",
              26: "r38",
              27: "r38",
              28: "r38",
              29: "r38",
              30: "r38",
              31: "r38",
              32: "r38",
              33: "r38",
              34: "r38",
              35: "r38",
              36: "r38",
              37: "r38",
              38: "r38",
              39: "r38",
              40: "r38",
              41: "r38",
              42: "r38",
              43: "r38",
              44: "r38",
              45: "r38",
              46: "s52",
              47: "s50",
              48: "s51",
              49: "s53",
              50: "s54",
              51: "s55",
              52: "r38",
              53: "r38",
              54: "r38",
              55: "r38",
              57: "r38",
            },
            {
              23: "r14",
              24: "r14",
              25: "r14",
              26: "r14",
              27: "r14",
              28: "r14",
              29: "r14",
              30: "r14",
              31: "r14",
              32: "r14",
              33: "r14",
              34: "r14",
              35: "r14",
              36: "r14",
              37: "r14",
              38: "r14",
              39: "r14",
              40: "r14",
              41: "r14",
              42: "r14",
              43: "r14",
              44: "r14",
              45: "r14",
              52: "r14",
              53: "r14",
              54: "r14",
              55: "r14",
              57: "r14",
            },
            {
              23: "r15",
              24: "r15",
              25: "r15",
              26: "r15",
              27: "r15",
              28: "r15",
              29: "r15",
              30: "r15",
              31: "r15",
              32: "r15",
              33: "r15",
              34: "r15",
              35: "r15",
              36: "r15",
              37: "r15",
              38: "r15",
              39: "r15",
              40: "r15",
              41: "r15",
              42: "r15",
              43: "r15",
              44: "r15",
              45: "r15",
              52: "r15",
              53: "r15",
              54: "r15",
              55: "r15",
              57: "r15",
            },
            {
              23: "r16",
              24: "r16",
              25: "r16",
              26: "r16",
              27: "r16",
              28: "r16",
              29: "r16",
              30: "r16",
              31: "r16",
              32: "r16",
              33: "r16",
              34: "r16",
              35: "r16",
              36: "r16",
              37: "r16",
              38: "r16",
              39: "r16",
              40: "r16",
              41: "r16",
              42: "r16",
              43: "r16",
              44: "r16",
              45: "r16",
              52: "r16",
              53: "r16",
              54: "r16",
              55: "r16",
              57: "r16",
            },
            {
              23: "r17",
              24: "r17",
              25: "r17",
              26: "r17",
              27: "r17",
              28: "r17",
              29: "r17",
              30: "r17",
              31: "r17",
              32: "r17",
              33: "r17",
              34: "r17",
              35: "r17",
              36: "r17",
              37: "r17",
              38: "r17",
              39: "r17",
              40: "r17",
              41: "r17",
              42: "r17",
              43: "r17",
              44: "r17",
              45: "r17",
              52: "r17",
              53: "r17",
              54: "r17",
              55: "r17",
              57: "r17",
            },
            {
              4: 57,
              5: 5,
              6: 6,
              24: "r10",
              25: "r10",
              26: "r10",
              27: "r10",
              28: "r10",
              29: "r10",
              30: "r10",
              31: "r10",
              32: "r10",
              33: "r10",
              34: "r10",
              35: "r10",
              36: "r10",
              37: "r10",
              38: "r10",
              39: "r10",
              40: "r10",
              41: "r10",
              42: "r10",
              43: "r10",
              44: "r10",
              45: "r10",
              52: "r10",
              53: "r10",
              54: "r10",
              55: "r10",
              57: "r10",
            },
            {
              4: 59,
              5: 5,
              6: 6,
              24: "r10",
              25: "r10",
              26: "r10",
              27: "r10",
              28: "r10",
              29: "r10",
              30: "r10",
              31: "r10",
              32: "r10",
              33: "r10",
              34: "r10",
              35: "r10",
              36: "r10",
              37: "r10",
              38: "r10",
              39: "r10",
              40: "r10",
              41: "r10",
              42: "r10",
              43: "r10",
              44: "r10",
              45: "r10",
              52: "r10",
              53: "r10",
              54: "r10",
              55: "r10",
              57: "r10",
            },
            {
              4: 61,
              5: 5,
              6: 6,
              24: "r10",
              25: "r10",
              26: "r10",
              27: "r10",
              28: "r10",
              29: "r10",
              30: "r10",
              31: "r10",
              32: "r10",
              33: "r10",
              34: "r10",
              35: "r10",
              36: "r10",
              37: "r10",
              38: "r10",
              39: "r10",
              40: "r10",
              41: "r10",
              42: "r10",
              43: "r10",
              44: "r10",
              45: "r10",
              52: "r10",
              53: "r10",
              54: "r10",
              55: "r10",
              57: "r10",
            },
            {
              4: 63,
              5: 5,
              6: 6,
              24: "r10",
              25: "r10",
              26: "r10",
              27: "r10",
              28: "r10",
              29: "r10",
              30: "r10",
              31: "r10",
              32: "r10",
              33: "r10",
              34: "r10",
              35: "r10",
              36: "r10",
              37: "r10",
              38: "r10",
              39: "r10",
              40: "r10",
              41: "r10",
              42: "r10",
              43: "r10",
              44: "r10",
              45: "r10",
              52: "r10",
              53: "r10",
              54: "r10",
              55: "r10",
              57: "r10",
            },
            {
              23: "r22",
              24: "r22",
              25: "r22",
              26: "r22",
              27: "r22",
              28: "r22",
              29: "r22",
              30: "r22",
              31: "r22",
              32: "r22",
              33: "r22",
              34: "r22",
              35: "r22",
              36: "r22",
              37: "r22",
              38: "r22",
              39: "r22",
              40: "r22",
              41: "r22",
              42: "r22",
              43: "r22",
              44: "r22",
              45: "r22",
              46: "r22",
              47: "r22",
              48: "r22",
              49: "r22",
              50: "r22",
              51: "r22",
              52: "r22",
              53: "r22",
              54: "r22",
              55: "r22",
              57: "r22",
            },
            {
              23: "r23",
              24: "r23",
              25: "r23",
              26: "r23",
              27: "r23",
              28: "r23",
              29: "r23",
              30: "r23",
              31: "r23",
              32: "r23",
              33: "r23",
              34: "r23",
              35: "r23",
              36: "r23",
              37: "r23",
              38: "r23",
              39: "r23",
              40: "r23",
              41: "r23",
              42: "r23",
              43: "r23",
              44: "r23",
              45: "r23",
              46: "r23",
              47: "r23",
              48: "r23",
              49: "r23",
              50: "r23",
              51: "r23",
              52: "r23",
              53: "r23",
              54: "r23",
              55: "r23",
              57: "r23",
            },
            {
              23: "r24",
              24: "r24",
              25: "r24",
              26: "r24",
              27: "r24",
              28: "r24",
              29: "r24",
              30: "r24",
              31: "r24",
              32: "r24",
              33: "r24",
              34: "r24",
              35: "r24",
              36: "r24",
              37: "r24",
              38: "r24",
              39: "r24",
              40: "r24",
              41: "r24",
              42: "r24",
              43: "r24",
              44: "r24",
              45: "r24",
              46: "r24",
              47: "r24",
              48: "r24",
              49: "r24",
              50: "r24",
              51: "r24",
              52: "r24",
              53: "r24",
              54: "r24",
              55: "r24",
              57: "r24",
            },
            {
              23: "r25",
              24: "r25",
              25: "r25",
              26: "r25",
              27: "r25",
              28: "r25",
              29: "r25",
              30: "r25",
              31: "r25",
              32: "r25",
              33: "r25",
              34: "r25",
              35: "r25",
              36: "r25",
              37: "r25",
              38: "r25",
              39: "r25",
              40: "r25",
              41: "r25",
              42: "r25",
              43: "r25",
              44: "r25",
              45: "r25",
              46: "r25",
              47: "r25",
              48: "r25",
              49: "r25",
              50: "r25",
              51: "r25",
              52: "r25",
              53: "r25",
              54: "r25",
              55: "r25",
              56: "r25",
              57: "r25",
              58: "r25",
            },
            {
              23: "r26",
              24: "r26",
              25: "r26",
              26: "r26",
              27: "r26",
              28: "r26",
              29: "r26",
              30: "r26",
              31: "r26",
              32: "r26",
              33: "r26",
              34: "r26",
              35: "r26",
              36: "r26",
              37: "r26",
              38: "r26",
              39: "r26",
              40: "r26",
              41: "r26",
              42: "r26",
              43: "r26",
              44: "r26",
              45: "r26",
              46: "r26",
              47: "r26",
              48: "r26",
              49: "r26",
              50: "r26",
              51: "r26",
              52: "r26",
              53: "r26",
              54: "r26",
              55: "r26",
              56: "r26",
              57: "r26",
              58: "r26",
            },
            {
              23: "r27",
              24: "r27",
              25: "r27",
              26: "r27",
              27: "r27",
              28: "r27",
              29: "r27",
              30: "r27",
              31: "r27",
              32: "r27",
              33: "r27",
              34: "r27",
              35: "r27",
              36: "r27",
              37: "r27",
              38: "r27",
              39: "r27",
              40: "r27",
              41: "r27",
              42: "r27",
              43: "r27",
              44: "r27",
              45: "r27",
              46: "r27",
              47: "r27",
              48: "r27",
              49: "r27",
              50: "r27",
              51: "r27",
              52: "r27",
              53: "r27",
              54: "r27",
              55: "r27",
              56: "r27",
              57: "r27",
              58: "r27",
            },
            {
              23: "r28",
              24: "r28",
              25: "r28",
              26: "r28",
              27: "r28",
              28: "r28",
              29: "r28",
              30: "r28",
              31: "r28",
              32: "r28",
              33: "r28",
              34: "r28",
              35: "r28",
              36: "r28",
              37: "r28",
              38: "r28",
              39: "r28",
              40: "r28",
              41: "r28",
              42: "r28",
              43: "r28",
              44: "r28",
              45: "r28",
              46: "r28",
              47: "r28",
              48: "r28",
              49: "r28",
              50: "r28",
              51: "r28",
              52: "r28",
              53: "r28",
              54: "r28",
              55: "r28",
              56: "r28",
              57: "r28",
              58: "r28",
            },
            {
              23: "r29",
              24: "r29",
              25: "r29",
              26: "r29",
              27: "r29",
              28: "r29",
              29: "r29",
              30: "r29",
              31: "r29",
              32: "r29",
              33: "r29",
              34: "r29",
              35: "r29",
              36: "r29",
              37: "r29",
              38: "r29",
              39: "r29",
              40: "r29",
              41: "r29",
              42: "r29",
              43: "r29",
              44: "r29",
              45: "r29",
              46: "r29",
              47: "r29",
              48: "r29",
              49: "r29",
              50: "r29",
              51: "r29",
              52: "r29",
              53: "r29",
              54: "r29",
              55: "r29",
              56: "r29",
              57: "r29",
              58: "r29",
            },
            {
              23: "r30",
              24: "r30",
              25: "r30",
              26: "r30",
              27: "r30",
              28: "r30",
              29: "r30",
              30: "r30",
              31: "r30",
              32: "r30",
              33: "r30",
              34: "r30",
              35: "r30",
              36: "r30",
              37: "r30",
              38: "r30",
              39: "r30",
              40: "r30",
              41: "r30",
              42: "r30",
              43: "r30",
              44: "r30",
              45: "r30",
              46: "r30",
              47: "r30",
              48: "r30",
              49: "r30",
              50: "r30",
              51: "r30",
              52: "r30",
              53: "r30",
              54: "r30",
              55: "r30",
              56: "r30",
              57: "r30",
              58: "r30",
            },
            {
              23: "r31",
              24: "r31",
              25: "r31",
              26: "r31",
              27: "r31",
              28: "r31",
              29: "r31",
              30: "r31",
              31: "r31",
              32: "r31",
              33: "r31",
              34: "r31",
              35: "r31",
              36: "r31",
              37: "r31",
              38: "r31",
              39: "r31",
              40: "r31",
              41: "r31",
              42: "r31",
              43: "r31",
              44: "r31",
              45: "r31",
              46: "r31",
              47: "r31",
              48: "r31",
              49: "r31",
              50: "r31",
              51: "r31",
              52: "r31",
              53: "r31",
              54: "r31",
              55: "r31",
              56: "r31",
              57: "r31",
              58: "r31",
            },
            {
              23: "r32",
              24: "r32",
              25: "r32",
              26: "r32",
              27: "r32",
              28: "r32",
              29: "r32",
              30: "r32",
              31: "r32",
              32: "r32",
              33: "r32",
              34: "r32",
              35: "r32",
              36: "r32",
              37: "r32",
              38: "r32",
              39: "r32",
              40: "r32",
              41: "r32",
              42: "r32",
              43: "r32",
              44: "r32",
              45: "r32",
              46: "r32",
              47: "r32",
              48: "r32",
              49: "r32",
              50: "r32",
              51: "r32",
              52: "r32",
              53: "r32",
              54: "r32",
              55: "r32",
              56: "r32",
              57: "r32",
              58: "r32",
            },
            {
              23: "r33",
              24: "r33",
              25: "r33",
              26: "r33",
              27: "r33",
              28: "r33",
              29: "r33",
              30: "r33",
              31: "r33",
              32: "r33",
              33: "r33",
              34: "r33",
              35: "r33",
              36: "r33",
              37: "r33",
              38: "r33",
              39: "r33",
              40: "r33",
              41: "r33",
              42: "r33",
              43: "r33",
              44: "r33",
              45: "r33",
              46: "r33",
              47: "r33",
              48: "r33",
              49: "r33",
              50: "r33",
              51: "r33",
              52: "r33",
              53: "r33",
              54: "r33",
              55: "r33",
              56: "r33",
              57: "r33",
              58: "r33",
            },
            {
              23: "r34",
              24: "r34",
              25: "r34",
              26: "r34",
              27: "r34",
              28: "r34",
              29: "r34",
              30: "r34",
              31: "r34",
              32: "r34",
              33: "r34",
              34: "r34",
              35: "r34",
              36: "r34",
              37: "r34",
              38: "r34",
              39: "r34",
              40: "r34",
              41: "r34",
              42: "r34",
              43: "r34",
              44: "r34",
              45: "r34",
              46: "r34",
              47: "r34",
              48: "r34",
              49: "r34",
              50: "r34",
              51: "r34",
              52: "r34",
              53: "r34",
              54: "r34",
              55: "r34",
              56: "r34",
              57: "r34",
              58: "r34",
            },
            {
              23: "r35",
              24: "r35",
              25: "r35",
              26: "r35",
              27: "r35",
              28: "r35",
              29: "r35",
              30: "r35",
              31: "r35",
              32: "r35",
              33: "r35",
              34: "r35",
              35: "r35",
              36: "r35",
              37: "r35",
              38: "r35",
              39: "r35",
              40: "r35",
              41: "r35",
              42: "r35",
              43: "r35",
              44: "r35",
              45: "r35",
              46: "r35",
              47: "r35",
              48: "r35",
              49: "r35",
              50: "r35",
              51: "r35",
              52: "r35",
              53: "r35",
              54: "r35",
              55: "r35",
              56: "r35",
              57: "r35",
              58: "r35",
            },
            {
              23: "r36",
              24: "r36",
              25: "r36",
              26: "r36",
              27: "r36",
              28: "r36",
              29: "r36",
              30: "r36",
              31: "r36",
              32: "r36",
              33: "r36",
              34: "r36",
              35: "r36",
              36: "r36",
              37: "r36",
              38: "r36",
              39: "r36",
              40: "r36",
              41: "r36",
              42: "r36",
              43: "r36",
              44: "r36",
              45: "r36",
              46: "r36",
              47: "r36",
              48: "r36",
              49: "r36",
              50: "r36",
              51: "r36",
              52: "r36",
              53: "r36",
              54: "r36",
              55: "r36",
              56: "r36",
              57: "r36",
              58: "r36",
            },
            {
              10: 70,
              18: 65,
              19: 66,
              21: 67,
              22: 69,
              24: "s28",
              28: "s71",
              35: "s29",
              36: "s30",
              37: "s31",
              38: "s32",
              39: "s33",
              40: "s34",
              41: "s35",
              42: "s36",
              43: "s37",
              44: "s38",
              45: "s39",
              56: "r54",
              58: "s68",
            },
            {
              10: 70,
              18: 83,
              19: 66,
              21: 67,
              22: 69,
              24: "s28",
              28: "s71",
              35: "s29",
              36: "s30",
              37: "s31",
              38: "s32",
              39: "s33",
              40: "s34",
              41: "s35",
              42: "s36",
              43: "s37",
              44: "s38",
              45: "s39",
              56: "r54",
              58: "s68",
            },
            {
              23: "r47",
              24: "r47",
              25: "r47",
              26: "r47",
              27: "r47",
              28: "r47",
              29: "r47",
              30: "r47",
              31: "r47",
              32: "r47",
              33: "r47",
              34: "r47",
              35: "r47",
              36: "r47",
              37: "r47",
              38: "r47",
              39: "r47",
              40: "r47",
              41: "r47",
              42: "r47",
              43: "r47",
              44: "r47",
              45: "r47",
              46: "r47",
              47: "r47",
              48: "r47",
              49: "r47",
              50: "r47",
              51: "r47",
              52: "r47",
              53: "r47",
              54: "r47",
              55: "r47",
              57: "r47",
            },
            {
              23: "r48",
              24: "r48",
              25: "r48",
              26: "r48",
              27: "r48",
              28: "r48",
              29: "r48",
              30: "r48",
              31: "r48",
              32: "r48",
              33: "r48",
              34: "r48",
              35: "r48",
              36: "r48",
              37: "r48",
              38: "r48",
              39: "r48",
              40: "r48",
              41: "r48",
              42: "r48",
              43: "r48",
              44: "r48",
              45: "r48",
              46: "r48",
              47: "r48",
              48: "r48",
              49: "r48",
              50: "r48",
              51: "r48",
              52: "r48",
              53: "r48",
              54: "r48",
              55: "r48",
              57: "r48",
            },
            {
              4: 85,
              5: 5,
              6: 6,
              24: "r10",
              25: "r10",
              26: "r10",
              27: "r10",
              28: "r10",
              29: "r10",
              30: "r10",
              31: "r10",
              32: "r10",
              33: "r10",
              34: "r10",
              35: "r10",
              36: "r10",
              37: "r10",
              38: "r10",
              39: "r10",
              40: "r10",
              41: "r10",
              42: "r10",
              43: "r10",
              44: "r10",
              45: "r10",
              52: "r10",
              53: "r10",
              54: "r10",
              55: "r10",
              57: "r10",
            },
            {
              4: 87,
              5: 5,
              6: 6,
              24: "r10",
              25: "r10",
              26: "r10",
              27: "r10",
              28: "r10",
              29: "r10",
              30: "r10",
              31: "r10",
              32: "r10",
              33: "r10",
              34: "r10",
              35: "r10",
              36: "r10",
              37: "r10",
              38: "r10",
              39: "r10",
              40: "r10",
              41: "r10",
              42: "r10",
              43: "r10",
              44: "r10",
              45: "r10",
              52: "r10",
              53: "r10",
              54: "r10",
              55: "r10",
              57: "r10",
            },
            {
              4: 89,
              5: 5,
              6: 6,
              24: "r10",
              25: "r10",
              26: "r10",
              27: "r10",
              28: "r10",
              29: "r10",
              30: "r10",
              31: "r10",
              32: "r10",
              33: "r10",
              34: "r10",
              35: "r10",
              36: "r10",
              37: "r10",
              38: "r10",
              39: "r10",
              40: "r10",
              41: "r10",
              42: "r10",
              43: "r10",
              44: "r10",
              45: "r10",
              52: "r10",
              53: "r10",
              54: "r10",
              55: "r10",
              57: "r10",
            },
            {
              23: "r13",
              24: "r13",
              25: "r13",
              26: "r13",
              27: "r13",
              28: "r13",
              29: "r13",
              30: "r13",
              31: "r13",
              32: "r13",
              33: "r13",
              34: "r13",
              35: "r13",
              36: "r13",
              37: "r13",
              38: "r13",
              39: "r13",
              40: "r13",
              41: "r13",
              42: "r13",
              43: "r13",
              44: "r13",
              45: "r13",
              52: "r13",
              53: "r13",
              54: "r13",
              55: "r13",
              57: "r13",
            },
            {
              23: "r37",
              24: "r37",
              25: "r37",
              26: "r37",
              27: "r37",
              28: "r37",
              29: "r37",
              30: "r37",
              31: "r37",
              32: "r37",
              33: "r37",
              34: "r37",
              35: "r37",
              36: "r37",
              37: "r37",
              38: "r37",
              39: "r37",
              40: "r37",
              41: "r37",
              42: "r37",
              43: "r37",
              44: "r37",
              45: "r37",
              52: "r37",
              53: "r37",
              54: "r37",
              55: "r37",
              57: "r37",
            },
            {
              23: "r39",
              24: "r39",
              25: "r39",
              26: "r39",
              27: "r39",
              28: "r39",
              29: "r39",
              30: "r39",
              31: "r39",
              32: "r39",
              33: "r39",
              34: "r39",
              35: "r39",
              36: "r39",
              37: "r39",
              38: "r39",
              39: "r39",
              40: "r39",
              41: "r39",
              42: "r39",
              43: "r39",
              44: "r39",
              45: "r39",
              46: "s56",
              52: "r39",
              53: "r39",
              54: "r39",
              55: "r39",
              57: "r39",
            },
            {
              23: "r41",
              24: "r41",
              25: "r41",
              26: "r41",
              27: "r41",
              28: "r41",
              29: "r41",
              30: "r41",
              31: "r41",
              32: "r41",
              33: "r41",
              34: "r41",
              35: "r41",
              36: "r41",
              37: "r41",
              38: "r41",
              39: "r41",
              40: "r41",
              41: "r41",
              42: "r41",
              43: "r41",
              44: "r41",
              45: "r41",
              46: "r41",
              52: "r41",
              53: "r41",
              54: "r41",
              55: "r41",
              57: "r41",
            },
            {
              23: "r42",
              24: "r42",
              25: "r42",
              26: "r42",
              27: "r42",
              28: "r42",
              29: "r42",
              30: "r42",
              31: "r42",
              32: "r42",
              33: "r42",
              34: "r42",
              35: "r42",
              36: "r42",
              37: "r42",
              38: "r42",
              39: "r42",
              40: "r42",
              41: "r42",
              42: "r42",
              43: "r42",
              44: "r42",
              45: "r42",
              46: "r42",
              52: "r42",
              53: "r42",
              54: "r42",
              55: "r42",
              57: "r42",
            },
            {
              23: "r43",
              24: "r43",
              25: "r43",
              26: "r43",
              27: "r43",
              28: "r43",
              29: "r43",
              30: "r43",
              31: "r43",
              32: "r43",
              33: "r43",
              34: "r43",
              35: "r43",
              36: "r43",
              37: "r43",
              38: "r43",
              39: "r43",
              40: "r43",
              41: "r43",
              42: "r43",
              43: "r43",
              44: "r43",
              45: "r43",
              46: "r43",
              52: "r43",
              53: "r43",
              54: "r43",
              55: "r43",
              57: "r43",
            },
            {
              23: "r44",
              24: "r44",
              25: "r44",
              26: "r44",
              27: "r44",
              28: "r44",
              29: "r44",
              30: "r44",
              31: "r44",
              32: "r44",
              33: "r44",
              34: "r44",
              35: "r44",
              36: "r44",
              37: "r44",
              38: "r44",
              39: "r44",
              40: "r44",
              41: "r44",
              42: "r44",
              43: "r44",
              44: "r44",
              45: "r44",
              46: "r44",
              52: "r44",
              53: "r44",
              54: "r44",
              55: "r44",
              57: "r44",
            },
            {
              23: "r45",
              24: "r45",
              25: "r45",
              26: "r45",
              27: "r45",
              28: "r45",
              29: "r45",
              30: "r45",
              31: "r45",
              32: "r45",
              33: "r45",
              34: "r45",
              35: "r45",
              36: "r45",
              37: "r45",
              38: "r45",
              39: "r45",
              40: "r45",
              41: "r45",
              42: "r45",
              43: "r45",
              44: "r45",
              45: "r45",
              46: "r45",
              52: "r45",
              53: "r45",
              54: "r45",
              55: "r45",
              57: "r45",
            },
            {
              23: "r46",
              24: "r46",
              25: "r46",
              26: "r46",
              27: "r46",
              28: "r46",
              29: "r46",
              30: "r46",
              31: "r46",
              32: "r46",
              33: "r46",
              34: "r46",
              35: "r46",
              36: "r46",
              37: "r46",
              38: "r46",
              39: "r46",
              40: "r46",
              41: "r46",
              42: "r46",
              43: "r46",
              44: "r46",
              45: "r46",
              46: "r46",
              52: "r46",
              53: "r46",
              54: "r46",
              55: "r46",
              57: "r46",
            },
            {
              23: "r40",
              24: "r40",
              25: "r40",
              26: "r40",
              27: "r40",
              28: "r40",
              29: "r40",
              30: "r40",
              31: "r40",
              32: "r40",
              33: "r40",
              34: "r40",
              35: "r40",
              36: "r40",
              37: "r40",
              38: "r40",
              39: "r40",
              40: "r40",
              41: "r40",
              42: "r40",
              43: "r40",
              44: "r40",
              45: "r40",
              52: "r40",
              53: "r40",
              54: "r40",
              55: "r40",
              57: "r40",
            },
            { 25: "s12", 31: "s58" },
            {
              23: "r18",
              24: "r18",
              25: "r18",
              26: "r18",
              27: "r18",
              28: "r18",
              29: "r18",
              30: "r18",
              31: "r18",
              32: "r18",
              33: "r18",
              34: "r18",
              35: "r18",
              36: "r18",
              37: "r18",
              38: "r18",
              39: "r18",
              40: "r18",
              41: "r18",
              42: "r18",
              43: "r18",
              44: "r18",
              45: "r18",
              52: "r18",
              53: "r18",
              54: "r18",
              55: "r18",
              57: "r18",
            },
            { 25: "s12", 31: "s60" },
            {
              23: "r19",
              24: "r19",
              25: "r19",
              26: "r19",
              27: "r19",
              28: "r19",
              29: "r19",
              30: "r19",
              31: "r19",
              32: "r19",
              33: "r19",
              34: "r19",
              35: "r19",
              36: "r19",
              37: "r19",
              38: "r19",
              39: "r19",
              40: "r19",
              41: "r19",
              42: "r19",
              43: "r19",
              44: "r19",
              45: "r19",
              52: "r19",
              53: "r19",
              54: "r19",
              55: "r19",
              57: "r19",
            },
            { 25: "s12", 31: "s62" },
            {
              23: "r20",
              24: "r20",
              25: "r20",
              26: "r20",
              27: "r20",
              28: "r20",
              29: "r20",
              30: "r20",
              31: "r20",
              32: "r20",
              33: "r20",
              34: "r20",
              35: "r20",
              36: "r20",
              37: "r20",
              38: "r20",
              39: "r20",
              40: "r20",
              41: "r20",
              42: "r20",
              43: "r20",
              44: "r20",
              45: "r20",
              52: "r20",
              53: "r20",
              54: "r20",
              55: "r20",
              57: "r20",
            },
            { 25: "s12", 31: "s64" },
            {
              23: "r21",
              24: "r21",
              25: "r21",
              26: "r21",
              27: "r21",
              28: "r21",
              29: "r21",
              30: "r21",
              31: "r21",
              32: "r21",
              33: "r21",
              34: "r21",
              35: "r21",
              36: "r21",
              37: "r21",
              38: "r21",
              39: "r21",
              40: "r21",
              41: "r21",
              42: "r21",
              43: "r21",
              44: "r21",
              45: "r21",
              52: "r21",
              53: "r21",
              54: "r21",
              55: "r21",
              57: "r21",
            },
            { 56: "s72" },
            { 56: "r55" },
            {
              10: 70,
              20: 73,
              21: 75,
              22: 76,
              24: "s28",
              28: "s71",
              35: "s29",
              36: "s30",
              37: "s31",
              38: "s32",
              39: "s33",
              40: "s34",
              41: "s35",
              42: "s36",
              43: "s37",
              44: "s38",
              45: "s39",
              56: "r56",
              58: "s74",
            },
            {
              24: "r62",
              28: "r62",
              35: "r62",
              36: "r62",
              37: "r62",
              38: "r62",
              39: "r62",
              40: "r62",
              41: "r62",
              42: "r62",
              43: "r62",
              44: "r62",
              45: "r62",
              56: "r62",
              58: "r62",
            },
            {
              24: "r63",
              28: "r63",
              35: "r63",
              36: "r63",
              37: "r63",
              38: "r63",
              39: "r63",
              40: "r63",
              41: "r63",
              42: "r63",
              43: "r63",
              44: "r63",
              45: "r63",
              56: "r63",
              58: "r63",
            },
            {
              24: "r64",
              28: "r64",
              35: "r64",
              36: "r64",
              37: "r64",
              38: "r64",
              39: "r64",
              40: "r64",
              41: "r64",
              42: "r64",
              43: "r64",
              44: "r64",
              45: "r64",
              56: "r64",
              58: "r64",
            },
            {
              24: "r65",
              28: "r65",
              35: "r65",
              36: "r65",
              37: "r65",
              38: "r65",
              39: "r65",
              40: "r65",
              41: "r65",
              42: "r65",
              43: "r65",
              44: "r65",
              45: "r65",
              56: "r65",
              58: "r65",
            },
            {
              23: "r52",
              24: "r52",
              25: "r52",
              26: "r52",
              27: "r52",
              28: "r52",
              29: "r52",
              30: "r52",
              31: "r52",
              32: "r52",
              33: "r52",
              34: "r52",
              35: "r52",
              36: "r52",
              37: "r52",
              38: "r52",
              39: "r52",
              40: "r52",
              41: "r52",
              42: "r52",
              43: "r52",
              44: "r52",
              45: "r52",
              46: "r52",
              47: "r52",
              48: "r52",
              49: "r52",
              50: "r52",
              51: "r52",
              52: "r52",
              53: "r52",
              54: "r52",
              55: "r52",
              57: "r52",
            },
            { 56: "r57" },
            {
              10: 70,
              21: 77,
              22: 69,
              24: "s28",
              28: "s71",
              35: "s29",
              36: "s30",
              37: "s31",
              38: "s32",
              39: "s33",
              40: "s34",
              41: "s35",
              42: "s36",
              43: "s37",
              44: "s38",
              45: "s39",
              56: "r62",
              58: "s68",
            },
            { 56: "r59" },
            {
              10: 70,
              20: 79,
              21: 75,
              22: 76,
              24: "s28",
              28: "s71",
              35: "s29",
              36: "s30",
              37: "s31",
              38: "s32",
              39: "s33",
              40: "s34",
              41: "s35",
              42: "s36",
              43: "s37",
              44: "s38",
              45: "s39",
              56: "r63",
              58: "s80",
            },
            {
              10: 70,
              18: 78,
              19: 66,
              21: 67,
              22: 69,
              24: "s28",
              28: "s71",
              35: "s29",
              36: "s30",
              37: "s31",
              38: "s32",
              39: "s33",
              40: "s34",
              41: "s35",
              42: "s36",
              43: "s37",
              44: "s38",
              45: "s39",
              56: "r54",
              58: "s68",
            },
            { 56: "r58" },
            { 56: "r60" },
            {
              10: 70,
              21: 81,
              22: 69,
              24: "s28",
              28: "s71",
              35: "s29",
              36: "s30",
              37: "s31",
              38: "s32",
              39: "s33",
              40: "s34",
              41: "s35",
              42: "s36",
              43: "s37",
              44: "s38",
              45: "s39",
              56: "r62",
              58: "s68",
            },
            {
              10: 70,
              18: 82,
              19: 66,
              21: 67,
              22: 69,
              24: "s28",
              28: "s71",
              35: "s29",
              36: "s30",
              37: "s31",
              38: "s32",
              39: "s33",
              40: "s34",
              41: "s35",
              42: "s36",
              43: "s37",
              44: "s38",
              45: "s39",
              56: "r54",
              58: "s68",
            },
            { 56: "r61" },
            { 56: "s84" },
            {
              23: "r53",
              24: "r53",
              25: "r53",
              26: "r53",
              27: "r53",
              28: "r53",
              29: "r53",
              30: "r53",
              31: "r53",
              32: "r53",
              33: "r53",
              34: "r53",
              35: "r53",
              36: "r53",
              37: "r53",
              38: "r53",
              39: "r53",
              40: "r53",
              41: "r53",
              42: "r53",
              43: "r53",
              44: "r53",
              45: "r53",
              46: "r53",
              47: "r53",
              48: "r53",
              49: "r53",
              50: "r53",
              51: "r53",
              52: "r53",
              53: "r53",
              54: "r53",
              55: "r53",
              57: "r53",
            },
            { 25: "s12", 31: "s86" },
            {
              23: "r49",
              24: "r49",
              25: "r49",
              26: "r49",
              27: "r49",
              28: "r49",
              29: "r49",
              30: "r49",
              31: "r49",
              32: "r49",
              33: "r49",
              34: "r49",
              35: "r49",
              36: "r49",
              37: "r49",
              38: "r49",
              39: "r49",
              40: "r49",
              41: "r49",
              42: "r49",
              43: "r49",
              44: "r49",
              45: "r49",
              46: "r49",
              47: "r49",
              48: "r49",
              49: "r49",
              50: "r49",
              51: "r49",
              52: "r49",
              53: "r49",
              54: "r49",
              55: "r49",
              57: "r49",
            },
            { 25: "s12", 31: "s88" },
            {
              23: "r50",
              24: "r50",
              25: "r50",
              26: "r50",
              27: "r50",
              28: "r50",
              29: "r50",
              30: "r50",
              31: "r50",
              32: "r50",
              33: "r50",
              34: "r50",
              35: "r50",
              36: "r50",
              37: "r50",
              38: "r50",
              39: "r50",
              40: "r50",
              41: "r50",
              42: "r50",
              43: "r50",
              44: "r50",
              45: "r50",
              46: "r50",
              47: "r50",
              48: "r50",
              49: "r50",
              50: "r50",
              51: "r50",
              52: "r50",
              53: "r50",
              54: "r50",
              55: "r50",
              57: "r50",
            },
            { 25: "s12", 31: "s90" },
            {
              23: "r51",
              24: "r51",
              25: "r51",
              26: "r51",
              27: "r51",
              28: "r51",
              29: "r51",
              30: "r51",
              31: "r51",
              32: "r51",
              33: "r51",
              34: "r51",
              35: "r51",
              36: "r51",
              37: "r51",
              38: "r51",
              39: "r51",
              40: "r51",
              41: "r51",
              42: "r51",
              43: "r51",
              44: "r51",
              45: "r51",
              46: "r51",
              47: "r51",
              48: "r51",
              49: "r51",
              50: "r51",
              51: "r51",
              52: "r51",
              53: "r51",
              54: "r51",
              55: "r51",
              57: "r51",
            },
          ],
          f = [],
          h = void 0,
          m = [
            [/^#[^\n]+/, function () {}],
            [/^\s+/, function () {}],
            [
              /^-/,
              function () {
                return "DASH";
              },
            ],
            [
              /^\//,
              function () {
                return "CHAR";
              },
            ],
            [
              /^#/,
              function () {
                return "CHAR";
              },
            ],
            [
              /^\|/,
              function () {
                return "CHAR";
              },
            ],
            [
              /^\./,
              function () {
                return "CHAR";
              },
            ],
            [
              /^\{/,
              function () {
                return "CHAR";
              },
            ],
            [
              /^\{\d+\}/,
              function () {
                return "RANGE_EXACT";
              },
            ],
            [
              /^\{\d+,\}/,
              function () {
                return "RANGE_OPEN";
              },
            ],
            [
              /^\{\d+,\d+\}/,
              function () {
                return "RANGE_CLOSED";
              },
            ],
            [
              /^\\k<(([\u0041-\u005a\u0061-\u007a\u00aa\u00b5\u00ba\u00c0-\u00d6\u00d8-\u00f6\u00f8-\u02c1\u02c6-\u02d1\u02e0-\u02e4\u02ec\u02ee\u0370-\u0374\u0376-\u0377\u037a-\u037d\u037f\u0386\u0388-\u038a\u038c\u038e-\u03a1\u03a3-\u03f5\u03f7-\u0481\u048a-\u052f\u0531-\u0556\u0559\u0560-\u0588\u05d0-\u05ea\u05ef-\u05f2\u0620-\u064a\u066e-\u066f\u0671-\u06d3\u06d5\u06e5-\u06e6\u06ee-\u06ef\u06fa-\u06fc\u06ff\u0710\u0712-\u072f\u074d-\u07a5\u07b1\u07ca-\u07ea\u07f4-\u07f5\u07fa\u0800-\u0815\u081a\u0824\u0828\u0840-\u0858\u0860-\u086a\u08a0-\u08b4\u08b6-\u08bd\u0904-\u0939\u093d\u0950\u0958-\u0961\u0971-\u0980\u0985-\u098c\u098f-\u0990\u0993-\u09a8\u09aa-\u09b0\u09b2\u09b6-\u09b9\u09bd\u09ce\u09dc-\u09dd\u09df-\u09e1\u09f0-\u09f1\u09fc\u0a05-\u0a0a\u0a0f-\u0a10\u0a13-\u0a28\u0a2a-\u0a30\u0a32-\u0a33\u0a35-\u0a36\u0a38-\u0a39\u0a59-\u0a5c\u0a5e\u0a72-\u0a74\u0a85-\u0a8d\u0a8f-\u0a91\u0a93-\u0aa8\u0aaa-\u0ab0\u0ab2-\u0ab3\u0ab5-\u0ab9\u0abd\u0ad0\u0ae0-\u0ae1\u0af9\u0b05-\u0b0c\u0b0f-\u0b10\u0b13-\u0b28\u0b2a-\u0b30\u0b32-\u0b33\u0b35-\u0b39\u0b3d\u0b5c-\u0b5d\u0b5f-\u0b61\u0b71\u0b83\u0b85-\u0b8a\u0b8e-\u0b90\u0b92-\u0b95\u0b99-\u0b9a\u0b9c\u0b9e-\u0b9f\u0ba3-\u0ba4\u0ba8-\u0baa\u0bae-\u0bb9\u0bd0\u0c05-\u0c0c\u0c0e-\u0c10\u0c12-\u0c28\u0c2a-\u0c39\u0c3d\u0c58-\u0c5a\u0c60-\u0c61\u0c80\u0c85-\u0c8c\u0c8e-\u0c90\u0c92-\u0ca8\u0caa-\u0cb3\u0cb5-\u0cb9\u0cbd\u0cde\u0ce0-\u0ce1\u0cf1-\u0cf2\u0d05-\u0d0c\u0d0e-\u0d10\u0d12-\u0d3a\u0d3d\u0d4e\u0d54-\u0d56\u0d5f-\u0d61\u0d7a-\u0d7f\u0d85-\u0d96\u0d9a-\u0db1\u0db3-\u0dbb\u0dbd\u0dc0-\u0dc6\u0e01-\u0e30\u0e32-\u0e33\u0e40-\u0e46\u0e81-\u0e82\u0e84\u0e86-\u0e8a\u0e8c-\u0ea3\u0ea5\u0ea7-\u0eb0\u0eb2-\u0eb3\u0ebd\u0ec0-\u0ec4\u0ec6\u0edc-\u0edf\u0f00\u0f40-\u0f47\u0f49-\u0f6c\u0f88-\u0f8c\u1000-\u102a\u103f\u1050-\u1055\u105a-\u105d\u1061\u1065-\u1066\u106e-\u1070\u1075-\u1081\u108e\u10a0-\u10c5\u10c7\u10cd\u10d0-\u10fa\u10fc-\u1248\u124a-\u124d\u1250-\u1256\u1258\u125a-\u125d\u1260-\u1288\u128a-\u128d\u1290-\u12b0\u12b2-\u12b5\u12b8-\u12be\u12c0\u12c2-\u12c5\u12c8-\u12d6\u12d8-\u1310\u1312-\u1315\u1318-\u135a\u1380-\u138f\u13a0-\u13f5\u13f8-\u13fd\u1401-\u166c\u166f-\u167f\u1681-\u169a\u16a0-\u16ea\u16ee-\u16f8\u1700-\u170c\u170e-\u1711\u1720-\u1731\u1740-\u1751\u1760-\u176c\u176e-\u1770\u1780-\u17b3\u17d7\u17dc\u1820-\u1878\u1880-\u18a8\u18aa\u18b0-\u18f5\u1900-\u191e\u1950-\u196d\u1970-\u1974\u1980-\u19ab\u19b0-\u19c9\u1a00-\u1a16\u1a20-\u1a54\u1aa7\u1b05-\u1b33\u1b45-\u1b4b\u1b83-\u1ba0\u1bae-\u1baf\u1bba-\u1be5\u1c00-\u1c23\u1c4d-\u1c4f\u1c5a-\u1c7d\u1c80-\u1c88\u1c90-\u1cba\u1cbd-\u1cbf\u1ce9-\u1cec\u1cee-\u1cf3\u1cf5-\u1cf6\u1cfa\u1d00-\u1dbf\u1e00-\u1f15\u1f18-\u1f1d\u1f20-\u1f45\u1f48-\u1f4d\u1f50-\u1f57\u1f59\u1f5b\u1f5d\u1f5f-\u1f7d\u1f80-\u1fb4\u1fb6-\u1fbc\u1fbe\u1fc2-\u1fc4\u1fc6-\u1fcc\u1fd0-\u1fd3\u1fd6-\u1fdb\u1fe0-\u1fec\u1ff2-\u1ff4\u1ff6-\u1ffc\u2071\u207f\u2090-\u209c\u2102\u2107\u210a-\u2113\u2115\u2118-\u211d\u2124\u2126\u2128\u212a-\u2139\u213c-\u213f\u2145-\u2149\u214e\u2160-\u2188\u2c00-\u2c2e\u2c30-\u2c5e\u2c60-\u2ce4\u2ceb-\u2cee\u2cf2-\u2cf3\u2d00-\u2d25\u2d27\u2d2d\u2d30-\u2d67\u2d6f\u2d80-\u2d96\u2da0-\u2da6\u2da8-\u2dae\u2db0-\u2db6\u2db8-\u2dbe\u2dc0-\u2dc6\u2dc8-\u2dce\u2dd0-\u2dd6\u2dd8-\u2dde\u3005-\u3007\u3021-\u3029\u3031-\u3035\u3038-\u303c\u3041-\u3096\u309b-\u309f\u30a1-\u30fa\u30fc-\u30ff\u3105-\u312f\u3131-\u318e\u31a0-\u31ba\u31f0-\u31ff\u3400-\u4db5\u4e00-\u9fef\ua000-\ua48c\ua4d0-\ua4fd\ua500-\ua60c\ua610-\ua61f\ua62a-\ua62b\ua640-\ua66e\ua67f-\ua69d\ua6a0-\ua6ef\ua717-\ua71f\ua722-\ua788\ua78b-\ua7bf\ua7c2-\ua7c6\ua7f7-\ua801\ua803-\ua805\ua807-\ua80a\ua80c-\ua822\ua840-\ua873\ua882-\ua8b3\ua8f2-\ua8f7\ua8fb\ua8fd-\ua8fe\ua90a-\ua925\ua930-\ua946\ua960-\ua97c\ua984-\ua9b2\ua9cf\ua9e0-\ua9e4\ua9e6-\ua9ef\ua9fa-\ua9fe\uaa00-\uaa28\uaa40-\uaa42\uaa44-\uaa4b\uaa60-\uaa76\uaa7a\uaa7e-\uaaaf\uaab1\uaab5-\uaab6\uaab9-\uaabd\uaac0\uaac2\uaadb-\uaadd\uaae0-\uaaea\uaaf2-\uaaf4\uab01-\uab06\uab09-\uab0e\uab11-\uab16\uab20-\uab26\uab28-\uab2e\uab30-\uab5a\uab5c-\uab67\uab70-\uabe2\uac00-\ud7a3\ud7b0-\ud7c6\ud7cb-\ud7fb\uf900-\ufa6d\ufa70-\ufad9\ufb00-\ufb06\ufb13-\ufb17\ufb1d\ufb1f-\ufb28\ufb2a-\ufb36\ufb38-\ufb3c\ufb3e\ufb40-\ufb41\ufb43-\ufb44\ufb46-\ufbb1\ufbd3-\ufd3d\ufd50-\ufd8f\ufd92-\ufdc7\ufdf0-\ufdfb\ufe70-\ufe74\ufe76-\ufefc\uff21-\uff3a\uff41-\uff5a\uff66-\uffbe\uffc2-\uffc7\uffca-\uffcf\uffd2-\uffd7\uffda-\uffdc]|\ud800[\udc00-\udc0b\udc0d-\udc26\udc28-\udc3a\udc3c-\udc3d\udc3f-\udc4d\udc50-\udc5d\udc80-\udcfa\udd40-\udd74\ude80-\ude9c\udea0-\uded0\udf00-\udf1f\udf2d-\udf4a\udf50-\udf75\udf80-\udf9d\udfa0-\udfc3\udfc8-\udfcf\udfd1-\udfd5]|\ud801[\udc00-\udc9d\udcb0-\udcd3\udcd8-\udcfb\udd00-\udd27\udd30-\udd63\ude00-\udf36\udf40-\udf55\udf60-\udf67]|\ud802[\udc00-\udc05\udc08\udc0a-\udc35\udc37-\udc38\udc3c\udc3f-\udc55\udc60-\udc76\udc80-\udc9e\udce0-\udcf2\udcf4-\udcf5\udd00-\udd15\udd20-\udd39\udd80-\uddb7\uddbe-\uddbf\ude00\ude10-\ude13\ude15-\ude17\ude19-\ude35\ude60-\ude7c\ude80-\ude9c\udec0-\udec7\udec9-\udee4\udf00-\udf35\udf40-\udf55\udf60-\udf72\udf80-\udf91]|\ud803[\udc00-\udc48\udc80-\udcb2\udcc0-\udcf2\udd00-\udd23\udf00-\udf1c\udf27\udf30-\udf45\udfe0-\udff6]|\ud804[\udc03-\udc37\udc83-\udcaf\udcd0-\udce8\udd03-\udd26\udd44\udd50-\udd72\udd76\udd83-\uddb2\uddc1-\uddc4\uddda\udddc\ude00-\ude11\ude13-\ude2b\ude80-\ude86\ude88\ude8a-\ude8d\ude8f-\ude9d\ude9f-\udea8\udeb0-\udede\udf05-\udf0c\udf0f-\udf10\udf13-\udf28\udf2a-\udf30\udf32-\udf33\udf35-\udf39\udf3d\udf50\udf5d-\udf61]|\ud805[\udc00-\udc34\udc47-\udc4a\udc5f\udc80-\udcaf\udcc4-\udcc5\udcc7\udd80-\uddae\uddd8-\udddb\ude00-\ude2f\ude44\ude80-\udeaa\udeb8\udf00-\udf1a]|\ud806[\udc00-\udc2b\udca0-\udcdf\udcff\udda0-\udda7\uddaa-\uddd0\udde1\udde3\ude00\ude0b-\ude32\ude3a\ude50\ude5c-\ude89\ude9d\udec0-\udef8]|\ud807[\udc00-\udc08\udc0a-\udc2e\udc40\udc72-\udc8f\udd00-\udd06\udd08-\udd09\udd0b-\udd30\udd46\udd60-\udd65\udd67-\udd68\udd6a-\udd89\udd98\udee0-\udef2]|\ud808[\udc00-\udf99]|\ud809[\udc00-\udc6e\udc80-\udd43]|\ud80c[\udc00-\udfff]|\ud80d[\udc00-\udc2e]|\ud811[\udc00-\ude46]|\ud81a[\udc00-\ude38\ude40-\ude5e\uded0-\udeed\udf00-\udf2f\udf40-\udf43\udf63-\udf77\udf7d-\udf8f]|\ud81b[\ude40-\ude7f\udf00-\udf4a\udf50\udf93-\udf9f\udfe0-\udfe1\udfe3]|\ud81c[\udc00-\udfff]|\ud81d[\udc00-\udfff]|\ud81e[\udc00-\udfff]|\ud81f[\udc00-\udfff]|\ud820[\udc00-\udfff]|\ud821[\udc00-\udff7]|\ud822[\udc00-\udef2]|\ud82c[\udc00-\udd1e\udd50-\udd52\udd64-\udd67\udd70-\udefb]|\ud82f[\udc00-\udc6a\udc70-\udc7c\udc80-\udc88\udc90-\udc99]|\ud835[\udc00-\udc54\udc56-\udc9c\udc9e-\udc9f\udca2\udca5-\udca6\udca9-\udcac\udcae-\udcb9\udcbb\udcbd-\udcc3\udcc5-\udd05\udd07-\udd0a\udd0d-\udd14\udd16-\udd1c\udd1e-\udd39\udd3b-\udd3e\udd40-\udd44\udd46\udd4a-\udd50\udd52-\udea5\udea8-\udec0\udec2-\udeda\udedc-\udefa\udefc-\udf14\udf16-\udf34\udf36-\udf4e\udf50-\udf6e\udf70-\udf88\udf8a-\udfa8\udfaa-\udfc2\udfc4-\udfcb]|\ud838[\udd00-\udd2c\udd37-\udd3d\udd4e\udec0-\udeeb]|\ud83a[\udc00-\udcc4\udd00-\udd43\udd4b]|\ud83b[\ude00-\ude03\ude05-\ude1f\ude21-\ude22\ude24\ude27\ude29-\ude32\ude34-\ude37\ude39\ude3b\ude42\ude47\ude49\ude4b\ude4d-\ude4f\ude51-\ude52\ude54\ude57\ude59\ude5b\ude5d\ude5f\ude61-\ude62\ude64\ude67-\ude6a\ude6c-\ude72\ude74-\ude77\ude79-\ude7c\ude7e\ude80-\ude89\ude8b-\ude9b\udea1-\udea3\udea5-\udea9\udeab-\udebb]|\ud840[\udc00-\udfff]|\ud841[\udc00-\udfff]|\ud842[\udc00-\udfff]|\ud843[\udc00-\udfff]|\ud844[\udc00-\udfff]|\ud845[\udc00-\udfff]|\ud846[\udc00-\udfff]|\ud847[\udc00-\udfff]|\ud848[\udc00-\udfff]|\ud849[\udc00-\udfff]|\ud84a[\udc00-\udfff]|\ud84b[\udc00-\udfff]|\ud84c[\udc00-\udfff]|\ud84d[\udc00-\udfff]|\ud84e[\udc00-\udfff]|\ud84f[\udc00-\udfff]|\ud850[\udc00-\udfff]|\ud851[\udc00-\udfff]|\ud852[\udc00-\udfff]|\ud853[\udc00-\udfff]|\ud854[\udc00-\udfff]|\ud855[\udc00-\udfff]|\ud856[\udc00-\udfff]|\ud857[\udc00-\udfff]|\ud858[\udc00-\udfff]|\ud859[\udc00-\udfff]|\ud85a[\udc00-\udfff]|\ud85b[\udc00-\udfff]|\ud85c[\udc00-\udfff]|\ud85d[\udc00-\udfff]|\ud85e[\udc00-\udfff]|\ud85f[\udc00-\udfff]|\ud860[\udc00-\udfff]|\ud861[\udc00-\udfff]|\ud862[\udc00-\udfff]|\ud863[\udc00-\udfff]|\ud864[\udc00-\udfff]|\ud865[\udc00-\udfff]|\ud866[\udc00-\udfff]|\ud867[\udc00-\udfff]|\ud868[\udc00-\udfff]|\ud869[\udc00-\uded6\udf00-\udfff]|\ud86a[\udc00-\udfff]|\ud86b[\udc00-\udfff]|\ud86c[\udc00-\udfff]|\ud86d[\udc00-\udf34\udf40-\udfff]|\ud86e[\udc00-\udc1d\udc20-\udfff]|\ud86f[\udc00-\udfff]|\ud870[\udc00-\udfff]|\ud871[\udc00-\udfff]|\ud872[\udc00-\udfff]|\ud873[\udc00-\udea1\udeb0-\udfff]|\ud874[\udc00-\udfff]|\ud875[\udc00-\udfff]|\ud876[\udc00-\udfff]|\ud877[\udc00-\udfff]|\ud878[\udc00-\udfff]|\ud879[\udc00-\udfff]|\ud87a[\udc00-\udfe0]|\ud87e[\udc00-\ude1d])|[$_]|(\\u[0-9a-fA-F]{4}|\\u\{[0-9a-fA-F]{1,}\}))(([\u0030-\u0039\u0041-\u005a\u005f\u0061-\u007a\u00aa\u00b5\u00b7\u00ba\u00c0-\u00d6\u00d8-\u00f6\u00f8-\u02c1\u02c6-\u02d1\u02e0-\u02e4\u02ec\u02ee\u0300-\u0374\u0376-\u0377\u037a-\u037d\u037f\u0386-\u038a\u038c\u038e-\u03a1\u03a3-\u03f5\u03f7-\u0481\u0483-\u0487\u048a-\u052f\u0531-\u0556\u0559\u0560-\u0588\u0591-\u05bd\u05bf\u05c1-\u05c2\u05c4-\u05c5\u05c7\u05d0-\u05ea\u05ef-\u05f2\u0610-\u061a\u0620-\u0669\u066e-\u06d3\u06d5-\u06dc\u06df-\u06e8\u06ea-\u06fc\u06ff\u0710-\u074a\u074d-\u07b1\u07c0-\u07f5\u07fa\u07fd\u0800-\u082d\u0840-\u085b\u0860-\u086a\u08a0-\u08b4\u08b6-\u08bd\u08d3-\u08e1\u08e3-\u0963\u0966-\u096f\u0971-\u0983\u0985-\u098c\u098f-\u0990\u0993-\u09a8\u09aa-\u09b0\u09b2\u09b6-\u09b9\u09bc-\u09c4\u09c7-\u09c8\u09cb-\u09ce\u09d7\u09dc-\u09dd\u09df-\u09e3\u09e6-\u09f1\u09fc\u09fe\u0a01-\u0a03\u0a05-\u0a0a\u0a0f-\u0a10\u0a13-\u0a28\u0a2a-\u0a30\u0a32-\u0a33\u0a35-\u0a36\u0a38-\u0a39\u0a3c\u0a3e-\u0a42\u0a47-\u0a48\u0a4b-\u0a4d\u0a51\u0a59-\u0a5c\u0a5e\u0a66-\u0a75\u0a81-\u0a83\u0a85-\u0a8d\u0a8f-\u0a91\u0a93-\u0aa8\u0aaa-\u0ab0\u0ab2-\u0ab3\u0ab5-\u0ab9\u0abc-\u0ac5\u0ac7-\u0ac9\u0acb-\u0acd\u0ad0\u0ae0-\u0ae3\u0ae6-\u0aef\u0af9-\u0aff\u0b01-\u0b03\u0b05-\u0b0c\u0b0f-\u0b10\u0b13-\u0b28\u0b2a-\u0b30\u0b32-\u0b33\u0b35-\u0b39\u0b3c-\u0b44\u0b47-\u0b48\u0b4b-\u0b4d\u0b56-\u0b57\u0b5c-\u0b5d\u0b5f-\u0b63\u0b66-\u0b6f\u0b71\u0b82-\u0b83\u0b85-\u0b8a\u0b8e-\u0b90\u0b92-\u0b95\u0b99-\u0b9a\u0b9c\u0b9e-\u0b9f\u0ba3-\u0ba4\u0ba8-\u0baa\u0bae-\u0bb9\u0bbe-\u0bc2\u0bc6-\u0bc8\u0bca-\u0bcd\u0bd0\u0bd7\u0be6-\u0bef\u0c00-\u0c0c\u0c0e-\u0c10\u0c12-\u0c28\u0c2a-\u0c39\u0c3d-\u0c44\u0c46-\u0c48\u0c4a-\u0c4d\u0c55-\u0c56\u0c58-\u0c5a\u0c60-\u0c63\u0c66-\u0c6f\u0c80-\u0c83\u0c85-\u0c8c\u0c8e-\u0c90\u0c92-\u0ca8\u0caa-\u0cb3\u0cb5-\u0cb9\u0cbc-\u0cc4\u0cc6-\u0cc8\u0cca-\u0ccd\u0cd5-\u0cd6\u0cde\u0ce0-\u0ce3\u0ce6-\u0cef\u0cf1-\u0cf2\u0d00-\u0d03\u0d05-\u0d0c\u0d0e-\u0d10\u0d12-\u0d44\u0d46-\u0d48\u0d4a-\u0d4e\u0d54-\u0d57\u0d5f-\u0d63\u0d66-\u0d6f\u0d7a-\u0d7f\u0d82-\u0d83\u0d85-\u0d96\u0d9a-\u0db1\u0db3-\u0dbb\u0dbd\u0dc0-\u0dc6\u0dca\u0dcf-\u0dd4\u0dd6\u0dd8-\u0ddf\u0de6-\u0def\u0df2-\u0df3\u0e01-\u0e3a\u0e40-\u0e4e\u0e50-\u0e59\u0e81-\u0e82\u0e84\u0e86-\u0e8a\u0e8c-\u0ea3\u0ea5\u0ea7-\u0ebd\u0ec0-\u0ec4\u0ec6\u0ec8-\u0ecd\u0ed0-\u0ed9\u0edc-\u0edf\u0f00\u0f18-\u0f19\u0f20-\u0f29\u0f35\u0f37\u0f39\u0f3e-\u0f47\u0f49-\u0f6c\u0f71-\u0f84\u0f86-\u0f97\u0f99-\u0fbc\u0fc6\u1000-\u1049\u1050-\u109d\u10a0-\u10c5\u10c7\u10cd\u10d0-\u10fa\u10fc-\u1248\u124a-\u124d\u1250-\u1256\u1258\u125a-\u125d\u1260-\u1288\u128a-\u128d\u1290-\u12b0\u12b2-\u12b5\u12b8-\u12be\u12c0\u12c2-\u12c5\u12c8-\u12d6\u12d8-\u1310\u1312-\u1315\u1318-\u135a\u135d-\u135f\u1369-\u1371\u1380-\u138f\u13a0-\u13f5\u13f8-\u13fd\u1401-\u166c\u166f-\u167f\u1681-\u169a\u16a0-\u16ea\u16ee-\u16f8\u1700-\u170c\u170e-\u1714\u1720-\u1734\u1740-\u1753\u1760-\u176c\u176e-\u1770\u1772-\u1773\u1780-\u17d3\u17d7\u17dc-\u17dd\u17e0-\u17e9\u180b-\u180d\u1810-\u1819\u1820-\u1878\u1880-\u18aa\u18b0-\u18f5\u1900-\u191e\u1920-\u192b\u1930-\u193b\u1946-\u196d\u1970-\u1974\u1980-\u19ab\u19b0-\u19c9\u19d0-\u19da\u1a00-\u1a1b\u1a20-\u1a5e\u1a60-\u1a7c\u1a7f-\u1a89\u1a90-\u1a99\u1aa7\u1ab0-\u1abd\u1b00-\u1b4b\u1b50-\u1b59\u1b6b-\u1b73\u1b80-\u1bf3\u1c00-\u1c37\u1c40-\u1c49\u1c4d-\u1c7d\u1c80-\u1c88\u1c90-\u1cba\u1cbd-\u1cbf\u1cd0-\u1cd2\u1cd4-\u1cfa\u1d00-\u1df9\u1dfb-\u1f15\u1f18-\u1f1d\u1f20-\u1f45\u1f48-\u1f4d\u1f50-\u1f57\u1f59\u1f5b\u1f5d\u1f5f-\u1f7d\u1f80-\u1fb4\u1fb6-\u1fbc\u1fbe\u1fc2-\u1fc4\u1fc6-\u1fcc\u1fd0-\u1fd3\u1fd6-\u1fdb\u1fe0-\u1fec\u1ff2-\u1ff4\u1ff6-\u1ffc\u203f-\u2040\u2054\u2071\u207f\u2090-\u209c\u20d0-\u20dc\u20e1\u20e5-\u20f0\u2102\u2107\u210a-\u2113\u2115\u2118-\u211d\u2124\u2126\u2128\u212a-\u2139\u213c-\u213f\u2145-\u2149\u214e\u2160-\u2188\u2c00-\u2c2e\u2c30-\u2c5e\u2c60-\u2ce4\u2ceb-\u2cf3\u2d00-\u2d25\u2d27\u2d2d\u2d30-\u2d67\u2d6f\u2d7f-\u2d96\u2da0-\u2da6\u2da8-\u2dae\u2db0-\u2db6\u2db8-\u2dbe\u2dc0-\u2dc6\u2dc8-\u2dce\u2dd0-\u2dd6\u2dd8-\u2dde\u2de0-\u2dff\u3005-\u3007\u3021-\u302f\u3031-\u3035\u3038-\u303c\u3041-\u3096\u3099-\u309f\u30a1-\u30fa\u30fc-\u30ff\u3105-\u312f\u3131-\u318e\u31a0-\u31ba\u31f0-\u31ff\u3400-\u4db5\u4e00-\u9fef\ua000-\ua48c\ua4d0-\ua4fd\ua500-\ua60c\ua610-\ua62b\ua640-\ua66f\ua674-\ua67d\ua67f-\ua6f1\ua717-\ua71f\ua722-\ua788\ua78b-\ua7bf\ua7c2-\ua7c6\ua7f7-\ua827\ua840-\ua873\ua880-\ua8c5\ua8d0-\ua8d9\ua8e0-\ua8f7\ua8fb\ua8fd-\ua92d\ua930-\ua953\ua960-\ua97c\ua980-\ua9c0\ua9cf-\ua9d9\ua9e0-\ua9fe\uaa00-\uaa36\uaa40-\uaa4d\uaa50-\uaa59\uaa60-\uaa76\uaa7a-\uaac2\uaadb-\uaadd\uaae0-\uaaef\uaaf2-\uaaf6\uab01-\uab06\uab09-\uab0e\uab11-\uab16\uab20-\uab26\uab28-\uab2e\uab30-\uab5a\uab5c-\uab67\uab70-\uabea\uabec-\uabed\uabf0-\uabf9\uac00-\ud7a3\ud7b0-\ud7c6\ud7cb-\ud7fb\uf900-\ufa6d\ufa70-\ufad9\ufb00-\ufb06\ufb13-\ufb17\ufb1d-\ufb28\ufb2a-\ufb36\ufb38-\ufb3c\ufb3e\ufb40-\ufb41\ufb43-\ufb44\ufb46-\ufbb1\ufbd3-\ufd3d\ufd50-\ufd8f\ufd92-\ufdc7\ufdf0-\ufdfb\ufe00-\ufe0f\ufe20-\ufe2f\ufe33-\ufe34\ufe4d-\ufe4f\ufe70-\ufe74\ufe76-\ufefc\uff10-\uff19\uff21-\uff3a\uff3f\uff41-\uff5a\uff66-\uffbe\uffc2-\uffc7\uffca-\uffcf\uffd2-\uffd7\uffda-\uffdc]|\ud800[\udc00-\udc0b\udc0d-\udc26\udc28-\udc3a\udc3c-\udc3d\udc3f-\udc4d\udc50-\udc5d\udc80-\udcfa\udd40-\udd74\uddfd\ude80-\ude9c\udea0-\uded0\udee0\udf00-\udf1f\udf2d-\udf4a\udf50-\udf7a\udf80-\udf9d\udfa0-\udfc3\udfc8-\udfcf\udfd1-\udfd5]|\ud801[\udc00-\udc9d\udca0-\udca9\udcb0-\udcd3\udcd8-\udcfb\udd00-\udd27\udd30-\udd63\ude00-\udf36\udf40-\udf55\udf60-\udf67]|\ud802[\udc00-\udc05\udc08\udc0a-\udc35\udc37-\udc38\udc3c\udc3f-\udc55\udc60-\udc76\udc80-\udc9e\udce0-\udcf2\udcf4-\udcf5\udd00-\udd15\udd20-\udd39\udd80-\uddb7\uddbe-\uddbf\ude00-\ude03\ude05-\ude06\ude0c-\ude13\ude15-\ude17\ude19-\ude35\ude38-\ude3a\ude3f\ude60-\ude7c\ude80-\ude9c\udec0-\udec7\udec9-\udee6\udf00-\udf35\udf40-\udf55\udf60-\udf72\udf80-\udf91]|\ud803[\udc00-\udc48\udc80-\udcb2\udcc0-\udcf2\udd00-\udd27\udd30-\udd39\udf00-\udf1c\udf27\udf30-\udf50\udfe0-\udff6]|\ud804[\udc00-\udc46\udc66-\udc6f\udc7f-\udcba\udcd0-\udce8\udcf0-\udcf9\udd00-\udd34\udd36-\udd3f\udd44-\udd46\udd50-\udd73\udd76\udd80-\uddc4\uddc9-\uddcc\uddd0-\uddda\udddc\ude00-\ude11\ude13-\ude37\ude3e\ude80-\ude86\ude88\ude8a-\ude8d\ude8f-\ude9d\ude9f-\udea8\udeb0-\udeea\udef0-\udef9\udf00-\udf03\udf05-\udf0c\udf0f-\udf10\udf13-\udf28\udf2a-\udf30\udf32-\udf33\udf35-\udf39\udf3b-\udf44\udf47-\udf48\udf4b-\udf4d\udf50\udf57\udf5d-\udf63\udf66-\udf6c\udf70-\udf74]|\ud805[\udc00-\udc4a\udc50-\udc59\udc5e-\udc5f\udc80-\udcc5\udcc7\udcd0-\udcd9\udd80-\uddb5\uddb8-\uddc0\uddd8-\udddd\ude00-\ude40\ude44\ude50-\ude59\ude80-\udeb8\udec0-\udec9\udf00-\udf1a\udf1d-\udf2b\udf30-\udf39]|\ud806[\udc00-\udc3a\udca0-\udce9\udcff\udda0-\udda7\uddaa-\uddd7\uddda-\udde1\udde3-\udde4\ude00-\ude3e\ude47\ude50-\ude99\ude9d\udec0-\udef8]|\ud807[\udc00-\udc08\udc0a-\udc36\udc38-\udc40\udc50-\udc59\udc72-\udc8f\udc92-\udca7\udca9-\udcb6\udd00-\udd06\udd08-\udd09\udd0b-\udd36\udd3a\udd3c-\udd3d\udd3f-\udd47\udd50-\udd59\udd60-\udd65\udd67-\udd68\udd6a-\udd8e\udd90-\udd91\udd93-\udd98\udda0-\udda9\udee0-\udef6]|\ud808[\udc00-\udf99]|\ud809[\udc00-\udc6e\udc80-\udd43]|\ud80c[\udc00-\udfff]|\ud80d[\udc00-\udc2e]|\ud811[\udc00-\ude46]|\ud81a[\udc00-\ude38\ude40-\ude5e\ude60-\ude69\uded0-\udeed\udef0-\udef4\udf00-\udf36\udf40-\udf43\udf50-\udf59\udf63-\udf77\udf7d-\udf8f]|\ud81b[\ude40-\ude7f\udf00-\udf4a\udf4f-\udf87\udf8f-\udf9f\udfe0-\udfe1\udfe3]|\ud81c[\udc00-\udfff]|\ud81d[\udc00-\udfff]|\ud81e[\udc00-\udfff]|\ud81f[\udc00-\udfff]|\ud820[\udc00-\udfff]|\ud821[\udc00-\udff7]|\ud822[\udc00-\udef2]|\ud82c[\udc00-\udd1e\udd50-\udd52\udd64-\udd67\udd70-\udefb]|\ud82f[\udc00-\udc6a\udc70-\udc7c\udc80-\udc88\udc90-\udc99\udc9d-\udc9e]|\ud834[\udd65-\udd69\udd6d-\udd72\udd7b-\udd82\udd85-\udd8b\uddaa-\uddad\ude42-\ude44]|\ud835[\udc00-\udc54\udc56-\udc9c\udc9e-\udc9f\udca2\udca5-\udca6\udca9-\udcac\udcae-\udcb9\udcbb\udcbd-\udcc3\udcc5-\udd05\udd07-\udd0a\udd0d-\udd14\udd16-\udd1c\udd1e-\udd39\udd3b-\udd3e\udd40-\udd44\udd46\udd4a-\udd50\udd52-\udea5\udea8-\udec0\udec2-\udeda\udedc-\udefa\udefc-\udf14\udf16-\udf34\udf36-\udf4e\udf50-\udf6e\udf70-\udf88\udf8a-\udfa8\udfaa-\udfc2\udfc4-\udfcb\udfce-\udfff]|\ud836[\ude00-\ude36\ude3b-\ude6c\ude75\ude84\ude9b-\ude9f\udea1-\udeaf]|\ud838[\udc00-\udc06\udc08-\udc18\udc1b-\udc21\udc23-\udc24\udc26-\udc2a\udd00-\udd2c\udd30-\udd3d\udd40-\udd49\udd4e\udec0-\udef9]|\ud83a[\udc00-\udcc4\udcd0-\udcd6\udd00-\udd4b\udd50-\udd59]|\ud83b[\ude00-\ude03\ude05-\ude1f\ude21-\ude22\ude24\ude27\ude29-\ude32\ude34-\ude37\ude39\ude3b\ude42\ude47\ude49\ude4b\ude4d-\ude4f\ude51-\ude52\ude54\ude57\ude59\ude5b\ude5d\ude5f\ude61-\ude62\ude64\ude67-\ude6a\ude6c-\ude72\ude74-\ude77\ude79-\ude7c\ude7e\ude80-\ude89\ude8b-\ude9b\udea1-\udea3\udea5-\udea9\udeab-\udebb]|\ud840[\udc00-\udfff]|\ud841[\udc00-\udfff]|\ud842[\udc00-\udfff]|\ud843[\udc00-\udfff]|\ud844[\udc00-\udfff]|\ud845[\udc00-\udfff]|\ud846[\udc00-\udfff]|\ud847[\udc00-\udfff]|\ud848[\udc00-\udfff]|\ud849[\udc00-\udfff]|\ud84a[\udc00-\udfff]|\ud84b[\udc00-\udfff]|\ud84c[\udc00-\udfff]|\ud84d[\udc00-\udfff]|\ud84e[\udc00-\udfff]|\ud84f[\udc00-\udfff]|\ud850[\udc00-\udfff]|\ud851[\udc00-\udfff]|\ud852[\udc00-\udfff]|\ud853[\udc00-\udfff]|\ud854[\udc00-\udfff]|\ud855[\udc00-\udfff]|\ud856[\udc00-\udfff]|\ud857[\udc00-\udfff]|\ud858[\udc00-\udfff]|\ud859[\udc00-\udfff]|\ud85a[\udc00-\udfff]|\ud85b[\udc00-\udfff]|\ud85c[\udc00-\udfff]|\ud85d[\udc00-\udfff]|\ud85e[\udc00-\udfff]|\ud85f[\udc00-\udfff]|\ud860[\udc00-\udfff]|\ud861[\udc00-\udfff]|\ud862[\udc00-\udfff]|\ud863[\udc00-\udfff]|\ud864[\udc00-\udfff]|\ud865[\udc00-\udfff]|\ud866[\udc00-\udfff]|\ud867[\udc00-\udfff]|\ud868[\udc00-\udfff]|\ud869[\udc00-\uded6\udf00-\udfff]|\ud86a[\udc00-\udfff]|\ud86b[\udc00-\udfff]|\ud86c[\udc00-\udfff]|\ud86d[\udc00-\udf34\udf40-\udfff]|\ud86e[\udc00-\udc1d\udc20-\udfff]|\ud86f[\udc00-\udfff]|\ud870[\udc00-\udfff]|\ud871[\udc00-\udfff]|\ud872[\udc00-\udfff]|\ud873[\udc00-\udea1\udeb0-\udfff]|\ud874[\udc00-\udfff]|\ud875[\udc00-\udfff]|\ud876[\udc00-\udfff]|\ud877[\udc00-\udfff]|\ud878[\udc00-\udfff]|\ud879[\udc00-\udfff]|\ud87a[\udc00-\udfe0]|\ud87e[\udc00-\ude1d]|\udb40[\udd00-\uddef])|[$_]|(\\u[0-9a-fA-F]{4}|\\u\{[0-9a-fA-F]{1,}\})|[\u200c\u200d])*>/,
              function () {
                return (
                  I(a.slice(3, -1), this.getCurrentState()), "NAMED_GROUP_REF"
                );
              },
            ],
            [
              /^\\b/,
              function () {
                return "ESC_b";
              },
            ],
            [
              /^\\B/,
              function () {
                return "ESC_B";
              },
            ],
            [
              /^\\c[a-zA-Z]/,
              function () {
                return "CTRL_CH";
              },
            ],
            [
              /^\\0\d{1,2}/,
              function () {
                return "OCT_CODE";
              },
            ],
            [
              /^\\0/,
              function () {
                return "DEC_CODE";
              },
            ],
            [
              /^\\\d{1,3}/,
              function () {
                return "DEC_CODE";
              },
            ],
            [
              /^\\u[dD][89abAB][0-9a-fA-F]{2}\\u[dD][c-fC-F][0-9a-fA-F]{2}/,
              function () {
                return "U_CODE_SURROGATE";
              },
            ],
            [
              /^\\u\{[0-9a-fA-F]{1,}\}/,
              function () {
                return "U_CODE";
              },
            ],
            [
              /^\\u[0-9a-fA-F]{4}/,
              function () {
                return "U_CODE";
              },
            ],
            [
              /^\\[pP]\{\w+(?:=\w+)?\}/,
              function () {
                return "U_PROP_VALUE_EXP";
              },
            ],
            [
              /^\\x[0-9a-fA-F]{2}/,
              function () {
                return "HEX_CODE";
              },
            ],
            [
              /^\\[tnrdDsSwWvf]/,
              function () {
                return "META_CHAR";
              },
            ],
            [
              /^\\\//,
              function () {
                return "ESC_CHAR";
              },
            ],
            [
              /^\\[ #]/,
              function () {
                return "ESC_CHAR";
              },
            ],
            [
              /^\\[\^\$\.\*\+\?\(\)\\\[\]\{\}\|\/]/,
              function () {
                return "ESC_CHAR";
              },
            ],
            [
              /^\\[^*?+\[()\\|]/,
              function () {
                var e = this.getCurrentState();
                if ("u_class" === e && "\\-" === a) return "ESC_CHAR";
                if ("u" === e || "xu" === e || "u_class" === e)
                  throw new SyntaxError("invalid Unicode escape " + a);
                return "ESC_CHAR";
              },
            ],
            [
              /^\(/,
              function () {
                return "CHAR";
              },
            ],
            [
              /^\)/,
              function () {
                return "CHAR";
              },
            ],
            [
              /^\(\?=/,
              function () {
                return "POS_LA_ASSERT";
              },
            ],
            [
              /^\(\?!/,
              function () {
                return "NEG_LA_ASSERT";
              },
            ],
            [
              /^\(\?<=/,
              function () {
                return "POS_LB_ASSERT";
              },
            ],
            [
              /^\(\?<!/,
              function () {
                return "NEG_LB_ASSERT";
              },
            ],
            [
              /^\(\?:/,
              function () {
                return "NON_CAPTURE_GROUP";
              },
            ],
            [
              /^\(\?<(([\u0041-\u005a\u0061-\u007a\u00aa\u00b5\u00ba\u00c0-\u00d6\u00d8-\u00f6\u00f8-\u02c1\u02c6-\u02d1\u02e0-\u02e4\u02ec\u02ee\u0370-\u0374\u0376-\u0377\u037a-\u037d\u037f\u0386\u0388-\u038a\u038c\u038e-\u03a1\u03a3-\u03f5\u03f7-\u0481\u048a-\u052f\u0531-\u0556\u0559\u0560-\u0588\u05d0-\u05ea\u05ef-\u05f2\u0620-\u064a\u066e-\u066f\u0671-\u06d3\u06d5\u06e5-\u06e6\u06ee-\u06ef\u06fa-\u06fc\u06ff\u0710\u0712-\u072f\u074d-\u07a5\u07b1\u07ca-\u07ea\u07f4-\u07f5\u07fa\u0800-\u0815\u081a\u0824\u0828\u0840-\u0858\u0860-\u086a\u08a0-\u08b4\u08b6-\u08bd\u0904-\u0939\u093d\u0950\u0958-\u0961\u0971-\u0980\u0985-\u098c\u098f-\u0990\u0993-\u09a8\u09aa-\u09b0\u09b2\u09b6-\u09b9\u09bd\u09ce\u09dc-\u09dd\u09df-\u09e1\u09f0-\u09f1\u09fc\u0a05-\u0a0a\u0a0f-\u0a10\u0a13-\u0a28\u0a2a-\u0a30\u0a32-\u0a33\u0a35-\u0a36\u0a38-\u0a39\u0a59-\u0a5c\u0a5e\u0a72-\u0a74\u0a85-\u0a8d\u0a8f-\u0a91\u0a93-\u0aa8\u0aaa-\u0ab0\u0ab2-\u0ab3\u0ab5-\u0ab9\u0abd\u0ad0\u0ae0-\u0ae1\u0af9\u0b05-\u0b0c\u0b0f-\u0b10\u0b13-\u0b28\u0b2a-\u0b30\u0b32-\u0b33\u0b35-\u0b39\u0b3d\u0b5c-\u0b5d\u0b5f-\u0b61\u0b71\u0b83\u0b85-\u0b8a\u0b8e-\u0b90\u0b92-\u0b95\u0b99-\u0b9a\u0b9c\u0b9e-\u0b9f\u0ba3-\u0ba4\u0ba8-\u0baa\u0bae-\u0bb9\u0bd0\u0c05-\u0c0c\u0c0e-\u0c10\u0c12-\u0c28\u0c2a-\u0c39\u0c3d\u0c58-\u0c5a\u0c60-\u0c61\u0c80\u0c85-\u0c8c\u0c8e-\u0c90\u0c92-\u0ca8\u0caa-\u0cb3\u0cb5-\u0cb9\u0cbd\u0cde\u0ce0-\u0ce1\u0cf1-\u0cf2\u0d05-\u0d0c\u0d0e-\u0d10\u0d12-\u0d3a\u0d3d\u0d4e\u0d54-\u0d56\u0d5f-\u0d61\u0d7a-\u0d7f\u0d85-\u0d96\u0d9a-\u0db1\u0db3-\u0dbb\u0dbd\u0dc0-\u0dc6\u0e01-\u0e30\u0e32-\u0e33\u0e40-\u0e46\u0e81-\u0e82\u0e84\u0e86-\u0e8a\u0e8c-\u0ea3\u0ea5\u0ea7-\u0eb0\u0eb2-\u0eb3\u0ebd\u0ec0-\u0ec4\u0ec6\u0edc-\u0edf\u0f00\u0f40-\u0f47\u0f49-\u0f6c\u0f88-\u0f8c\u1000-\u102a\u103f\u1050-\u1055\u105a-\u105d\u1061\u1065-\u1066\u106e-\u1070\u1075-\u1081\u108e\u10a0-\u10c5\u10c7\u10cd\u10d0-\u10fa\u10fc-\u1248\u124a-\u124d\u1250-\u1256\u1258\u125a-\u125d\u1260-\u1288\u128a-\u128d\u1290-\u12b0\u12b2-\u12b5\u12b8-\u12be\u12c0\u12c2-\u12c5\u12c8-\u12d6\u12d8-\u1310\u1312-\u1315\u1318-\u135a\u1380-\u138f\u13a0-\u13f5\u13f8-\u13fd\u1401-\u166c\u166f-\u167f\u1681-\u169a\u16a0-\u16ea\u16ee-\u16f8\u1700-\u170c\u170e-\u1711\u1720-\u1731\u1740-\u1751\u1760-\u176c\u176e-\u1770\u1780-\u17b3\u17d7\u17dc\u1820-\u1878\u1880-\u18a8\u18aa\u18b0-\u18f5\u1900-\u191e\u1950-\u196d\u1970-\u1974\u1980-\u19ab\u19b0-\u19c9\u1a00-\u1a16\u1a20-\u1a54\u1aa7\u1b05-\u1b33\u1b45-\u1b4b\u1b83-\u1ba0\u1bae-\u1baf\u1bba-\u1be5\u1c00-\u1c23\u1c4d-\u1c4f\u1c5a-\u1c7d\u1c80-\u1c88\u1c90-\u1cba\u1cbd-\u1cbf\u1ce9-\u1cec\u1cee-\u1cf3\u1cf5-\u1cf6\u1cfa\u1d00-\u1dbf\u1e00-\u1f15\u1f18-\u1f1d\u1f20-\u1f45\u1f48-\u1f4d\u1f50-\u1f57\u1f59\u1f5b\u1f5d\u1f5f-\u1f7d\u1f80-\u1fb4\u1fb6-\u1fbc\u1fbe\u1fc2-\u1fc4\u1fc6-\u1fcc\u1fd0-\u1fd3\u1fd6-\u1fdb\u1fe0-\u1fec\u1ff2-\u1ff4\u1ff6-\u1ffc\u2071\u207f\u2090-\u209c\u2102\u2107\u210a-\u2113\u2115\u2118-\u211d\u2124\u2126\u2128\u212a-\u2139\u213c-\u213f\u2145-\u2149\u214e\u2160-\u2188\u2c00-\u2c2e\u2c30-\u2c5e\u2c60-\u2ce4\u2ceb-\u2cee\u2cf2-\u2cf3\u2d00-\u2d25\u2d27\u2d2d\u2d30-\u2d67\u2d6f\u2d80-\u2d96\u2da0-\u2da6\u2da8-\u2dae\u2db0-\u2db6\u2db8-\u2dbe\u2dc0-\u2dc6\u2dc8-\u2dce\u2dd0-\u2dd6\u2dd8-\u2dde\u3005-\u3007\u3021-\u3029\u3031-\u3035\u3038-\u303c\u3041-\u3096\u309b-\u309f\u30a1-\u30fa\u30fc-\u30ff\u3105-\u312f\u3131-\u318e\u31a0-\u31ba\u31f0-\u31ff\u3400-\u4db5\u4e00-\u9fef\ua000-\ua48c\ua4d0-\ua4fd\ua500-\ua60c\ua610-\ua61f\ua62a-\ua62b\ua640-\ua66e\ua67f-\ua69d\ua6a0-\ua6ef\ua717-\ua71f\ua722-\ua788\ua78b-\ua7bf\ua7c2-\ua7c6\ua7f7-\ua801\ua803-\ua805\ua807-\ua80a\ua80c-\ua822\ua840-\ua873\ua882-\ua8b3\ua8f2-\ua8f7\ua8fb\ua8fd-\ua8fe\ua90a-\ua925\ua930-\ua946\ua960-\ua97c\ua984-\ua9b2\ua9cf\ua9e0-\ua9e4\ua9e6-\ua9ef\ua9fa-\ua9fe\uaa00-\uaa28\uaa40-\uaa42\uaa44-\uaa4b\uaa60-\uaa76\uaa7a\uaa7e-\uaaaf\uaab1\uaab5-\uaab6\uaab9-\uaabd\uaac0\uaac2\uaadb-\uaadd\uaae0-\uaaea\uaaf2-\uaaf4\uab01-\uab06\uab09-\uab0e\uab11-\uab16\uab20-\uab26\uab28-\uab2e\uab30-\uab5a\uab5c-\uab67\uab70-\uabe2\uac00-\ud7a3\ud7b0-\ud7c6\ud7cb-\ud7fb\uf900-\ufa6d\ufa70-\ufad9\ufb00-\ufb06\ufb13-\ufb17\ufb1d\ufb1f-\ufb28\ufb2a-\ufb36\ufb38-\ufb3c\ufb3e\ufb40-\ufb41\ufb43-\ufb44\ufb46-\ufbb1\ufbd3-\ufd3d\ufd50-\ufd8f\ufd92-\ufdc7\ufdf0-\ufdfb\ufe70-\ufe74\ufe76-\ufefc\uff21-\uff3a\uff41-\uff5a\uff66-\uffbe\uffc2-\uffc7\uffca-\uffcf\uffd2-\uffd7\uffda-\uffdc]|\ud800[\udc00-\udc0b\udc0d-\udc26\udc28-\udc3a\udc3c-\udc3d\udc3f-\udc4d\udc50-\udc5d\udc80-\udcfa\udd40-\udd74\ude80-\ude9c\udea0-\uded0\udf00-\udf1f\udf2d-\udf4a\udf50-\udf75\udf80-\udf9d\udfa0-\udfc3\udfc8-\udfcf\udfd1-\udfd5]|\ud801[\udc00-\udc9d\udcb0-\udcd3\udcd8-\udcfb\udd00-\udd27\udd30-\udd63\ude00-\udf36\udf40-\udf55\udf60-\udf67]|\ud802[\udc00-\udc05\udc08\udc0a-\udc35\udc37-\udc38\udc3c\udc3f-\udc55\udc60-\udc76\udc80-\udc9e\udce0-\udcf2\udcf4-\udcf5\udd00-\udd15\udd20-\udd39\udd80-\uddb7\uddbe-\uddbf\ude00\ude10-\ude13\ude15-\ude17\ude19-\ude35\ude60-\ude7c\ude80-\ude9c\udec0-\udec7\udec9-\udee4\udf00-\udf35\udf40-\udf55\udf60-\udf72\udf80-\udf91]|\ud803[\udc00-\udc48\udc80-\udcb2\udcc0-\udcf2\udd00-\udd23\udf00-\udf1c\udf27\udf30-\udf45\udfe0-\udff6]|\ud804[\udc03-\udc37\udc83-\udcaf\udcd0-\udce8\udd03-\udd26\udd44\udd50-\udd72\udd76\udd83-\uddb2\uddc1-\uddc4\uddda\udddc\ude00-\ude11\ude13-\ude2b\ude80-\ude86\ude88\ude8a-\ude8d\ude8f-\ude9d\ude9f-\udea8\udeb0-\udede\udf05-\udf0c\udf0f-\udf10\udf13-\udf28\udf2a-\udf30\udf32-\udf33\udf35-\udf39\udf3d\udf50\udf5d-\udf61]|\ud805[\udc00-\udc34\udc47-\udc4a\udc5f\udc80-\udcaf\udcc4-\udcc5\udcc7\udd80-\uddae\uddd8-\udddb\ude00-\ude2f\ude44\ude80-\udeaa\udeb8\udf00-\udf1a]|\ud806[\udc00-\udc2b\udca0-\udcdf\udcff\udda0-\udda7\uddaa-\uddd0\udde1\udde3\ude00\ude0b-\ude32\ude3a\ude50\ude5c-\ude89\ude9d\udec0-\udef8]|\ud807[\udc00-\udc08\udc0a-\udc2e\udc40\udc72-\udc8f\udd00-\udd06\udd08-\udd09\udd0b-\udd30\udd46\udd60-\udd65\udd67-\udd68\udd6a-\udd89\udd98\udee0-\udef2]|\ud808[\udc00-\udf99]|\ud809[\udc00-\udc6e\udc80-\udd43]|\ud80c[\udc00-\udfff]|\ud80d[\udc00-\udc2e]|\ud811[\udc00-\ude46]|\ud81a[\udc00-\ude38\ude40-\ude5e\uded0-\udeed\udf00-\udf2f\udf40-\udf43\udf63-\udf77\udf7d-\udf8f]|\ud81b[\ude40-\ude7f\udf00-\udf4a\udf50\udf93-\udf9f\udfe0-\udfe1\udfe3]|\ud81c[\udc00-\udfff]|\ud81d[\udc00-\udfff]|\ud81e[\udc00-\udfff]|\ud81f[\udc00-\udfff]|\ud820[\udc00-\udfff]|\ud821[\udc00-\udff7]|\ud822[\udc00-\udef2]|\ud82c[\udc00-\udd1e\udd50-\udd52\udd64-\udd67\udd70-\udefb]|\ud82f[\udc00-\udc6a\udc70-\udc7c\udc80-\udc88\udc90-\udc99]|\ud835[\udc00-\udc54\udc56-\udc9c\udc9e-\udc9f\udca2\udca5-\udca6\udca9-\udcac\udcae-\udcb9\udcbb\udcbd-\udcc3\udcc5-\udd05\udd07-\udd0a\udd0d-\udd14\udd16-\udd1c\udd1e-\udd39\udd3b-\udd3e\udd40-\udd44\udd46\udd4a-\udd50\udd52-\udea5\udea8-\udec0\udec2-\udeda\udedc-\udefa\udefc-\udf14\udf16-\udf34\udf36-\udf4e\udf50-\udf6e\udf70-\udf88\udf8a-\udfa8\udfaa-\udfc2\udfc4-\udfcb]|\ud838[\udd00-\udd2c\udd37-\udd3d\udd4e\udec0-\udeeb]|\ud83a[\udc00-\udcc4\udd00-\udd43\udd4b]|\ud83b[\ude00-\ude03\ude05-\ude1f\ude21-\ude22\ude24\ude27\ude29-\ude32\ude34-\ude37\ude39\ude3b\ude42\ude47\ude49\ude4b\ude4d-\ude4f\ude51-\ude52\ude54\ude57\ude59\ude5b\ude5d\ude5f\ude61-\ude62\ude64\ude67-\ude6a\ude6c-\ude72\ude74-\ude77\ude79-\ude7c\ude7e\ude80-\ude89\ude8b-\ude9b\udea1-\udea3\udea5-\udea9\udeab-\udebb]|\ud840[\udc00-\udfff]|\ud841[\udc00-\udfff]|\ud842[\udc00-\udfff]|\ud843[\udc00-\udfff]|\ud844[\udc00-\udfff]|\ud845[\udc00-\udfff]|\ud846[\udc00-\udfff]|\ud847[\udc00-\udfff]|\ud848[\udc00-\udfff]|\ud849[\udc00-\udfff]|\ud84a[\udc00-\udfff]|\ud84b[\udc00-\udfff]|\ud84c[\udc00-\udfff]|\ud84d[\udc00-\udfff]|\ud84e[\udc00-\udfff]|\ud84f[\udc00-\udfff]|\ud850[\udc00-\udfff]|\ud851[\udc00-\udfff]|\ud852[\udc00-\udfff]|\ud853[\udc00-\udfff]|\ud854[\udc00-\udfff]|\ud855[\udc00-\udfff]|\ud856[\udc00-\udfff]|\ud857[\udc00-\udfff]|\ud858[\udc00-\udfff]|\ud859[\udc00-\udfff]|\ud85a[\udc00-\udfff]|\ud85b[\udc00-\udfff]|\ud85c[\udc00-\udfff]|\ud85d[\udc00-\udfff]|\ud85e[\udc00-\udfff]|\ud85f[\udc00-\udfff]|\ud860[\udc00-\udfff]|\ud861[\udc00-\udfff]|\ud862[\udc00-\udfff]|\ud863[\udc00-\udfff]|\ud864[\udc00-\udfff]|\ud865[\udc00-\udfff]|\ud866[\udc00-\udfff]|\ud867[\udc00-\udfff]|\ud868[\udc00-\udfff]|\ud869[\udc00-\uded6\udf00-\udfff]|\ud86a[\udc00-\udfff]|\ud86b[\udc00-\udfff]|\ud86c[\udc00-\udfff]|\ud86d[\udc00-\udf34\udf40-\udfff]|\ud86e[\udc00-\udc1d\udc20-\udfff]|\ud86f[\udc00-\udfff]|\ud870[\udc00-\udfff]|\ud871[\udc00-\udfff]|\ud872[\udc00-\udfff]|\ud873[\udc00-\udea1\udeb0-\udfff]|\ud874[\udc00-\udfff]|\ud875[\udc00-\udfff]|\ud876[\udc00-\udfff]|\ud877[\udc00-\udfff]|\ud878[\udc00-\udfff]|\ud879[\udc00-\udfff]|\ud87a[\udc00-\udfe0]|\ud87e[\udc00-\ude1d])|[$_]|(\\u[0-9a-fA-F]{4}|\\u\{[0-9a-fA-F]{1,}\}))(([\u0030-\u0039\u0041-\u005a\u005f\u0061-\u007a\u00aa\u00b5\u00b7\u00ba\u00c0-\u00d6\u00d8-\u00f6\u00f8-\u02c1\u02c6-\u02d1\u02e0-\u02e4\u02ec\u02ee\u0300-\u0374\u0376-\u0377\u037a-\u037d\u037f\u0386-\u038a\u038c\u038e-\u03a1\u03a3-\u03f5\u03f7-\u0481\u0483-\u0487\u048a-\u052f\u0531-\u0556\u0559\u0560-\u0588\u0591-\u05bd\u05bf\u05c1-\u05c2\u05c4-\u05c5\u05c7\u05d0-\u05ea\u05ef-\u05f2\u0610-\u061a\u0620-\u0669\u066e-\u06d3\u06d5-\u06dc\u06df-\u06e8\u06ea-\u06fc\u06ff\u0710-\u074a\u074d-\u07b1\u07c0-\u07f5\u07fa\u07fd\u0800-\u082d\u0840-\u085b\u0860-\u086a\u08a0-\u08b4\u08b6-\u08bd\u08d3-\u08e1\u08e3-\u0963\u0966-\u096f\u0971-\u0983\u0985-\u098c\u098f-\u0990\u0993-\u09a8\u09aa-\u09b0\u09b2\u09b6-\u09b9\u09bc-\u09c4\u09c7-\u09c8\u09cb-\u09ce\u09d7\u09dc-\u09dd\u09df-\u09e3\u09e6-\u09f1\u09fc\u09fe\u0a01-\u0a03\u0a05-\u0a0a\u0a0f-\u0a10\u0a13-\u0a28\u0a2a-\u0a30\u0a32-\u0a33\u0a35-\u0a36\u0a38-\u0a39\u0a3c\u0a3e-\u0a42\u0a47-\u0a48\u0a4b-\u0a4d\u0a51\u0a59-\u0a5c\u0a5e\u0a66-\u0a75\u0a81-\u0a83\u0a85-\u0a8d\u0a8f-\u0a91\u0a93-\u0aa8\u0aaa-\u0ab0\u0ab2-\u0ab3\u0ab5-\u0ab9\u0abc-\u0ac5\u0ac7-\u0ac9\u0acb-\u0acd\u0ad0\u0ae0-\u0ae3\u0ae6-\u0aef\u0af9-\u0aff\u0b01-\u0b03\u0b05-\u0b0c\u0b0f-\u0b10\u0b13-\u0b28\u0b2a-\u0b30\u0b32-\u0b33\u0b35-\u0b39\u0b3c-\u0b44\u0b47-\u0b48\u0b4b-\u0b4d\u0b56-\u0b57\u0b5c-\u0b5d\u0b5f-\u0b63\u0b66-\u0b6f\u0b71\u0b82-\u0b83\u0b85-\u0b8a\u0b8e-\u0b90\u0b92-\u0b95\u0b99-\u0b9a\u0b9c\u0b9e-\u0b9f\u0ba3-\u0ba4\u0ba8-\u0baa\u0bae-\u0bb9\u0bbe-\u0bc2\u0bc6-\u0bc8\u0bca-\u0bcd\u0bd0\u0bd7\u0be6-\u0bef\u0c00-\u0c0c\u0c0e-\u0c10\u0c12-\u0c28\u0c2a-\u0c39\u0c3d-\u0c44\u0c46-\u0c48\u0c4a-\u0c4d\u0c55-\u0c56\u0c58-\u0c5a\u0c60-\u0c63\u0c66-\u0c6f\u0c80-\u0c83\u0c85-\u0c8c\u0c8e-\u0c90\u0c92-\u0ca8\u0caa-\u0cb3\u0cb5-\u0cb9\u0cbc-\u0cc4\u0cc6-\u0cc8\u0cca-\u0ccd\u0cd5-\u0cd6\u0cde\u0ce0-\u0ce3\u0ce6-\u0cef\u0cf1-\u0cf2\u0d00-\u0d03\u0d05-\u0d0c\u0d0e-\u0d10\u0d12-\u0d44\u0d46-\u0d48\u0d4a-\u0d4e\u0d54-\u0d57\u0d5f-\u0d63\u0d66-\u0d6f\u0d7a-\u0d7f\u0d82-\u0d83\u0d85-\u0d96\u0d9a-\u0db1\u0db3-\u0dbb\u0dbd\u0dc0-\u0dc6\u0dca\u0dcf-\u0dd4\u0dd6\u0dd8-\u0ddf\u0de6-\u0def\u0df2-\u0df3\u0e01-\u0e3a\u0e40-\u0e4e\u0e50-\u0e59\u0e81-\u0e82\u0e84\u0e86-\u0e8a\u0e8c-\u0ea3\u0ea5\u0ea7-\u0ebd\u0ec0-\u0ec4\u0ec6\u0ec8-\u0ecd\u0ed0-\u0ed9\u0edc-\u0edf\u0f00\u0f18-\u0f19\u0f20-\u0f29\u0f35\u0f37\u0f39\u0f3e-\u0f47\u0f49-\u0f6c\u0f71-\u0f84\u0f86-\u0f97\u0f99-\u0fbc\u0fc6\u1000-\u1049\u1050-\u109d\u10a0-\u10c5\u10c7\u10cd\u10d0-\u10fa\u10fc-\u1248\u124a-\u124d\u1250-\u1256\u1258\u125a-\u125d\u1260-\u1288\u128a-\u128d\u1290-\u12b0\u12b2-\u12b5\u12b8-\u12be\u12c0\u12c2-\u12c5\u12c8-\u12d6\u12d8-\u1310\u1312-\u1315\u1318-\u135a\u135d-\u135f\u1369-\u1371\u1380-\u138f\u13a0-\u13f5\u13f8-\u13fd\u1401-\u166c\u166f-\u167f\u1681-\u169a\u16a0-\u16ea\u16ee-\u16f8\u1700-\u170c\u170e-\u1714\u1720-\u1734\u1740-\u1753\u1760-\u176c\u176e-\u1770\u1772-\u1773\u1780-\u17d3\u17d7\u17dc-\u17dd\u17e0-\u17e9\u180b-\u180d\u1810-\u1819\u1820-\u1878\u1880-\u18aa\u18b0-\u18f5\u1900-\u191e\u1920-\u192b\u1930-\u193b\u1946-\u196d\u1970-\u1974\u1980-\u19ab\u19b0-\u19c9\u19d0-\u19da\u1a00-\u1a1b\u1a20-\u1a5e\u1a60-\u1a7c\u1a7f-\u1a89\u1a90-\u1a99\u1aa7\u1ab0-\u1abd\u1b00-\u1b4b\u1b50-\u1b59\u1b6b-\u1b73\u1b80-\u1bf3\u1c00-\u1c37\u1c40-\u1c49\u1c4d-\u1c7d\u1c80-\u1c88\u1c90-\u1cba\u1cbd-\u1cbf\u1cd0-\u1cd2\u1cd4-\u1cfa\u1d00-\u1df9\u1dfb-\u1f15\u1f18-\u1f1d\u1f20-\u1f45\u1f48-\u1f4d\u1f50-\u1f57\u1f59\u1f5b\u1f5d\u1f5f-\u1f7d\u1f80-\u1fb4\u1fb6-\u1fbc\u1fbe\u1fc2-\u1fc4\u1fc6-\u1fcc\u1fd0-\u1fd3\u1fd6-\u1fdb\u1fe0-\u1fec\u1ff2-\u1ff4\u1ff6-\u1ffc\u203f-\u2040\u2054\u2071\u207f\u2090-\u209c\u20d0-\u20dc\u20e1\u20e5-\u20f0\u2102\u2107\u210a-\u2113\u2115\u2118-\u211d\u2124\u2126\u2128\u212a-\u2139\u213c-\u213f\u2145-\u2149\u214e\u2160-\u2188\u2c00-\u2c2e\u2c30-\u2c5e\u2c60-\u2ce4\u2ceb-\u2cf3\u2d00-\u2d25\u2d27\u2d2d\u2d30-\u2d67\u2d6f\u2d7f-\u2d96\u2da0-\u2da6\u2da8-\u2dae\u2db0-\u2db6\u2db8-\u2dbe\u2dc0-\u2dc6\u2dc8-\u2dce\u2dd0-\u2dd6\u2dd8-\u2dde\u2de0-\u2dff\u3005-\u3007\u3021-\u302f\u3031-\u3035\u3038-\u303c\u3041-\u3096\u3099-\u309f\u30a1-\u30fa\u30fc-\u30ff\u3105-\u312f\u3131-\u318e\u31a0-\u31ba\u31f0-\u31ff\u3400-\u4db5\u4e00-\u9fef\ua000-\ua48c\ua4d0-\ua4fd\ua500-\ua60c\ua610-\ua62b\ua640-\ua66f\ua674-\ua67d\ua67f-\ua6f1\ua717-\ua71f\ua722-\ua788\ua78b-\ua7bf\ua7c2-\ua7c6\ua7f7-\ua827\ua840-\ua873\ua880-\ua8c5\ua8d0-\ua8d9\ua8e0-\ua8f7\ua8fb\ua8fd-\ua92d\ua930-\ua953\ua960-\ua97c\ua980-\ua9c0\ua9cf-\ua9d9\ua9e0-\ua9fe\uaa00-\uaa36\uaa40-\uaa4d\uaa50-\uaa59\uaa60-\uaa76\uaa7a-\uaac2\uaadb-\uaadd\uaae0-\uaaef\uaaf2-\uaaf6\uab01-\uab06\uab09-\uab0e\uab11-\uab16\uab20-\uab26\uab28-\uab2e\uab30-\uab5a\uab5c-\uab67\uab70-\uabea\uabec-\uabed\uabf0-\uabf9\uac00-\ud7a3\ud7b0-\ud7c6\ud7cb-\ud7fb\uf900-\ufa6d\ufa70-\ufad9\ufb00-\ufb06\ufb13-\ufb17\ufb1d-\ufb28\ufb2a-\ufb36\ufb38-\ufb3c\ufb3e\ufb40-\ufb41\ufb43-\ufb44\ufb46-\ufbb1\ufbd3-\ufd3d\ufd50-\ufd8f\ufd92-\ufdc7\ufdf0-\ufdfb\ufe00-\ufe0f\ufe20-\ufe2f\ufe33-\ufe34\ufe4d-\ufe4f\ufe70-\ufe74\ufe76-\ufefc\uff10-\uff19\uff21-\uff3a\uff3f\uff41-\uff5a\uff66-\uffbe\uffc2-\uffc7\uffca-\uffcf\uffd2-\uffd7\uffda-\uffdc]|\ud800[\udc00-\udc0b\udc0d-\udc26\udc28-\udc3a\udc3c-\udc3d\udc3f-\udc4d\udc50-\udc5d\udc80-\udcfa\udd40-\udd74\uddfd\ude80-\ude9c\udea0-\uded0\udee0\udf00-\udf1f\udf2d-\udf4a\udf50-\udf7a\udf80-\udf9d\udfa0-\udfc3\udfc8-\udfcf\udfd1-\udfd5]|\ud801[\udc00-\udc9d\udca0-\udca9\udcb0-\udcd3\udcd8-\udcfb\udd00-\udd27\udd30-\udd63\ude00-\udf36\udf40-\udf55\udf60-\udf67]|\ud802[\udc00-\udc05\udc08\udc0a-\udc35\udc37-\udc38\udc3c\udc3f-\udc55\udc60-\udc76\udc80-\udc9e\udce0-\udcf2\udcf4-\udcf5\udd00-\udd15\udd20-\udd39\udd80-\uddb7\uddbe-\uddbf\ude00-\ude03\ude05-\ude06\ude0c-\ude13\ude15-\ude17\ude19-\ude35\ude38-\ude3a\ude3f\ude60-\ude7c\ude80-\ude9c\udec0-\udec7\udec9-\udee6\udf00-\udf35\udf40-\udf55\udf60-\udf72\udf80-\udf91]|\ud803[\udc00-\udc48\udc80-\udcb2\udcc0-\udcf2\udd00-\udd27\udd30-\udd39\udf00-\udf1c\udf27\udf30-\udf50\udfe0-\udff6]|\ud804[\udc00-\udc46\udc66-\udc6f\udc7f-\udcba\udcd0-\udce8\udcf0-\udcf9\udd00-\udd34\udd36-\udd3f\udd44-\udd46\udd50-\udd73\udd76\udd80-\uddc4\uddc9-\uddcc\uddd0-\uddda\udddc\ude00-\ude11\ude13-\ude37\ude3e\ude80-\ude86\ude88\ude8a-\ude8d\ude8f-\ude9d\ude9f-\udea8\udeb0-\udeea\udef0-\udef9\udf00-\udf03\udf05-\udf0c\udf0f-\udf10\udf13-\udf28\udf2a-\udf30\udf32-\udf33\udf35-\udf39\udf3b-\udf44\udf47-\udf48\udf4b-\udf4d\udf50\udf57\udf5d-\udf63\udf66-\udf6c\udf70-\udf74]|\ud805[\udc00-\udc4a\udc50-\udc59\udc5e-\udc5f\udc80-\udcc5\udcc7\udcd0-\udcd9\udd80-\uddb5\uddb8-\uddc0\uddd8-\udddd\ude00-\ude40\ude44\ude50-\ude59\ude80-\udeb8\udec0-\udec9\udf00-\udf1a\udf1d-\udf2b\udf30-\udf39]|\ud806[\udc00-\udc3a\udca0-\udce9\udcff\udda0-\udda7\uddaa-\uddd7\uddda-\udde1\udde3-\udde4\ude00-\ude3e\ude47\ude50-\ude99\ude9d\udec0-\udef8]|\ud807[\udc00-\udc08\udc0a-\udc36\udc38-\udc40\udc50-\udc59\udc72-\udc8f\udc92-\udca7\udca9-\udcb6\udd00-\udd06\udd08-\udd09\udd0b-\udd36\udd3a\udd3c-\udd3d\udd3f-\udd47\udd50-\udd59\udd60-\udd65\udd67-\udd68\udd6a-\udd8e\udd90-\udd91\udd93-\udd98\udda0-\udda9\udee0-\udef6]|\ud808[\udc00-\udf99]|\ud809[\udc00-\udc6e\udc80-\udd43]|\ud80c[\udc00-\udfff]|\ud80d[\udc00-\udc2e]|\ud811[\udc00-\ude46]|\ud81a[\udc00-\ude38\ude40-\ude5e\ude60-\ude69\uded0-\udeed\udef0-\udef4\udf00-\udf36\udf40-\udf43\udf50-\udf59\udf63-\udf77\udf7d-\udf8f]|\ud81b[\ude40-\ude7f\udf00-\udf4a\udf4f-\udf87\udf8f-\udf9f\udfe0-\udfe1\udfe3]|\ud81c[\udc00-\udfff]|\ud81d[\udc00-\udfff]|\ud81e[\udc00-\udfff]|\ud81f[\udc00-\udfff]|\ud820[\udc00-\udfff]|\ud821[\udc00-\udff7]|\ud822[\udc00-\udef2]|\ud82c[\udc00-\udd1e\udd50-\udd52\udd64-\udd67\udd70-\udefb]|\ud82f[\udc00-\udc6a\udc70-\udc7c\udc80-\udc88\udc90-\udc99\udc9d-\udc9e]|\ud834[\udd65-\udd69\udd6d-\udd72\udd7b-\udd82\udd85-\udd8b\uddaa-\uddad\ude42-\ude44]|\ud835[\udc00-\udc54\udc56-\udc9c\udc9e-\udc9f\udca2\udca5-\udca6\udca9-\udcac\udcae-\udcb9\udcbb\udcbd-\udcc3\udcc5-\udd05\udd07-\udd0a\udd0d-\udd14\udd16-\udd1c\udd1e-\udd39\udd3b-\udd3e\udd40-\udd44\udd46\udd4a-\udd50\udd52-\udea5\udea8-\udec0\udec2-\udeda\udedc-\udefa\udefc-\udf14\udf16-\udf34\udf36-\udf4e\udf50-\udf6e\udf70-\udf88\udf8a-\udfa8\udfaa-\udfc2\udfc4-\udfcb\udfce-\udfff]|\ud836[\ude00-\ude36\ude3b-\ude6c\ude75\ude84\ude9b-\ude9f\udea1-\udeaf]|\ud838[\udc00-\udc06\udc08-\udc18\udc1b-\udc21\udc23-\udc24\udc26-\udc2a\udd00-\udd2c\udd30-\udd3d\udd40-\udd49\udd4e\udec0-\udef9]|\ud83a[\udc00-\udcc4\udcd0-\udcd6\udd00-\udd4b\udd50-\udd59]|\ud83b[\ude00-\ude03\ude05-\ude1f\ude21-\ude22\ude24\ude27\ude29-\ude32\ude34-\ude37\ude39\ude3b\ude42\ude47\ude49\ude4b\ude4d-\ude4f\ude51-\ude52\ude54\ude57\ude59\ude5b\ude5d\ude5f\ude61-\ude62\ude64\ude67-\ude6a\ude6c-\ude72\ude74-\ude77\ude79-\ude7c\ude7e\ude80-\ude89\ude8b-\ude9b\udea1-\udea3\udea5-\udea9\udeab-\udebb]|\ud840[\udc00-\udfff]|\ud841[\udc00-\udfff]|\ud842[\udc00-\udfff]|\ud843[\udc00-\udfff]|\ud844[\udc00-\udfff]|\ud845[\udc00-\udfff]|\ud846[\udc00-\udfff]|\ud847[\udc00-\udfff]|\ud848[\udc00-\udfff]|\ud849[\udc00-\udfff]|\ud84a[\udc00-\udfff]|\ud84b[\udc00-\udfff]|\ud84c[\udc00-\udfff]|\ud84d[\udc00-\udfff]|\ud84e[\udc00-\udfff]|\ud84f[\udc00-\udfff]|\ud850[\udc00-\udfff]|\ud851[\udc00-\udfff]|\ud852[\udc00-\udfff]|\ud853[\udc00-\udfff]|\ud854[\udc00-\udfff]|\ud855[\udc00-\udfff]|\ud856[\udc00-\udfff]|\ud857[\udc00-\udfff]|\ud858[\udc00-\udfff]|\ud859[\udc00-\udfff]|\ud85a[\udc00-\udfff]|\ud85b[\udc00-\udfff]|\ud85c[\udc00-\udfff]|\ud85d[\udc00-\udfff]|\ud85e[\udc00-\udfff]|\ud85f[\udc00-\udfff]|\ud860[\udc00-\udfff]|\ud861[\udc00-\udfff]|\ud862[\udc00-\udfff]|\ud863[\udc00-\udfff]|\ud864[\udc00-\udfff]|\ud865[\udc00-\udfff]|\ud866[\udc00-\udfff]|\ud867[\udc00-\udfff]|\ud868[\udc00-\udfff]|\ud869[\udc00-\uded6\udf00-\udfff]|\ud86a[\udc00-\udfff]|\ud86b[\udc00-\udfff]|\ud86c[\udc00-\udfff]|\ud86d[\udc00-\udf34\udf40-\udfff]|\ud86e[\udc00-\udc1d\udc20-\udfff]|\ud86f[\udc00-\udfff]|\ud870[\udc00-\udfff]|\ud871[\udc00-\udfff]|\ud872[\udc00-\udfff]|\ud873[\udc00-\udea1\udeb0-\udfff]|\ud874[\udc00-\udfff]|\ud875[\udc00-\udfff]|\ud876[\udc00-\udfff]|\ud877[\udc00-\udfff]|\ud878[\udc00-\udfff]|\ud879[\udc00-\udfff]|\ud87a[\udc00-\udfe0]|\ud87e[\udc00-\ude1d]|\udb40[\udd00-\uddef])|[$_]|(\\u[0-9a-fA-F]{4}|\\u\{[0-9a-fA-F]{1,}\})|[\u200c\u200d])*>/,
              function () {
                return (
                  I((a = a.slice(3, -1)), this.getCurrentState()),
                  "NAMED_CAPTURE_GROUP"
                );
              },
            ],
            [
              /^\(/,
              function () {
                return "L_PAREN";
              },
            ],
            [
              /^\)/,
              function () {
                return "R_PAREN";
              },
            ],
            [
              /^[*?+[^$]/,
              function () {
                return "CHAR";
              },
            ],
            [
              /^\\\]/,
              function () {
                return "ESC_CHAR";
              },
            ],
            [
              /^\]/,
              function () {
                return this.popState(), "R_BRACKET";
              },
            ],
            [
              /^\^/,
              function () {
                return "BOS";
              },
            ],
            [
              /^\$/,
              function () {
                return "EOS";
              },
            ],
            [
              /^\*/,
              function () {
                return "STAR";
              },
            ],
            [
              /^\?/,
              function () {
                return "Q_MARK";
              },
            ],
            [
              /^\+/,
              function () {
                return "PLUS";
              },
            ],
            [
              /^\|/,
              function () {
                return "BAR";
              },
            ],
            [
              /^\./,
              function () {
                return "ANY";
              },
            ],
            [
              /^\//,
              function () {
                return "SLASH";
              },
            ],
            [
              /^[^*?+\[()\\|]/,
              function () {
                return "CHAR";
              },
            ],
            [
              /^\[\^/,
              function () {
                var e = this.getCurrentState();
                return (
                  this.pushState("u" === e || "xu" === e ? "u_class" : "class"),
                  "NEG_CLASS"
                );
              },
            ],
            [
              /^\[/,
              function () {
                var e = this.getCurrentState();
                return (
                  this.pushState("u" === e || "xu" === e ? "u_class" : "class"),
                  "L_BRACKET"
                );
              },
            ],
          ],
          g = {
            INITIAL: [
              8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 20, 22, 23, 24, 26, 27, 30,
              31, 32, 33, 34, 35, 36, 37, 41, 42, 43, 44, 45, 46, 47, 48, 49,
              50, 51,
            ],
            u: [
              8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24,
              26, 27, 30, 31, 32, 33, 34, 35, 36, 37, 41, 42, 43, 44, 45, 46,
              47, 48, 49, 50, 51,
            ],
            xu: [
              0, 1, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22,
              23, 24, 25, 26, 27, 30, 31, 32, 33, 34, 35, 36, 37, 41, 42, 43,
              44, 45, 46, 47, 48, 49, 50, 51,
            ],
            x: [
              0, 1, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 20, 22, 23, 24, 26,
              27, 30, 31, 32, 33, 34, 35, 36, 37, 41, 42, 43, 44, 45, 46, 47,
              48, 49, 50, 51,
            ],
            u_class: [
              2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19,
              20, 21, 22, 23, 24, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36,
              37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51,
            ],
            class: [
              2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 20, 22,
              23, 24, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39,
              40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51,
            ],
          },
          y = { type: "$", value: "" };
        (h = {
          initString: function (e) {
            return (
              (this._string = e),
              (this._cursor = 0),
              (this._states = ["INITIAL"]),
              (this._tokensQueue = []),
              (this._currentLine = 1),
              (this._currentColumn = 0),
              (this._currentLineBeginOffset = 0),
              (this._tokenStartOffset = 0),
              (this._tokenEndOffset = 0),
              (this._tokenStartLine = 1),
              (this._tokenEndLine = 1),
              (this._tokenStartColumn = 0),
              (this._tokenEndColumn = 0),
              this
            );
          },
          getStates: function () {
            return this._states;
          },
          getCurrentState: function () {
            return this._states[this._states.length - 1];
          },
          pushState: function (e) {
            this._states.push(e);
          },
          begin: function (e) {
            this.pushState(e);
          },
          popState: function () {
            return this._states.length > 1
              ? this._states.pop()
              : this._states[0];
          },
          getNextToken: function () {
            if (this._tokensQueue.length > 0)
              return this.onToken(this._toToken(this._tokensQueue.shift()));
            if (!this.hasMoreTokens()) return this.onToken(y);
            for (
              var e = this._string.slice(this._cursor),
                t = g[this.getCurrentState()],
                r = 0;
              r < t.length;
              r++
            ) {
              var n = t[r],
                o = m[n],
                s = this._match(e, o[0]);
              if (("" === e && "" === s && this._cursor++, null !== s)) {
                (a = s).length;
                var u = o[1].call(this);
                if (!u) return this.getNextToken();
                if (Array.isArray(u)) {
                  var c,
                    l = u.slice(1);
                  if (((u = u[0]), l.length > 0))
                    (c = this._tokensQueue).unshift.apply(c, i(l));
                }
                return this.onToken(this._toToken(u, a));
              }
            }
            if (this.isEOF()) return this._cursor++, y;
            this.throwUnexpectedToken(
              e[0],
              this._currentLine,
              this._currentColumn
            );
          },
          throwUnexpectedToken: function (e, t, r) {
            var n = this._string.split("\n")[t - 1],
              i = "";
            n && (i = "\n\n" + n + "\n" + " ".repeat(r) + "^\n");
            throw new SyntaxError(
              i + 'Unexpected token: "' + e + '" at ' + t + ":" + r + "."
            );
          },
          getCursor: function () {
            return this._cursor;
          },
          getCurrentLine: function () {
            return this._currentLine;
          },
          getCurrentColumn: function () {
            return this._currentColumn;
          },
          _captureLocation: function (e) {
            var t = /\n/g;
            (this._tokenStartOffset = this._cursor),
              (this._tokenStartLine = this._currentLine),
              (this._tokenStartColumn =
                this._tokenStartOffset - this._currentLineBeginOffset);
            for (var r = void 0; null !== (r = t.exec(e)); )
              this._currentLine++,
                (this._currentLineBeginOffset =
                  this._tokenStartOffset + r.index + 1);
            (this._tokenEndOffset = this._cursor + e.length),
              (this._tokenEndLine = this._currentLine),
              (this._tokenEndColumn = this._currentColumn =
                this._tokenEndOffset - this._currentLineBeginOffset);
          },
          _toToken: function (e) {
            return {
              type: e,
              value:
                arguments.length > 1 && void 0 !== arguments[1]
                  ? arguments[1]
                  : "",
              startOffset: this._tokenStartOffset,
              endOffset: this._tokenEndOffset,
              startLine: this._tokenStartLine,
              endLine: this._tokenEndLine,
              startColumn: this._tokenStartColumn,
              endColumn: this._tokenEndColumn,
            };
          },
          isEOF: function () {
            return this._cursor === this._string.length;
          },
          hasMoreTokens: function () {
            return this._cursor <= this._string.length;
          },
          _match: function (e, t) {
            var r = e.match(t);
            return r
              ? (this._captureLocation(r[0]),
                (this._cursor += r[0].length),
                r[0])
              : null;
          },
          onToken: function (e) {
            return e;
          },
        }),
          (o.lexer = h),
          (o.tokenizer = h),
          (o.options = { captureLocations: !0 });
        var v = {
            setOptions: function (e) {
              return (o.options = e), this;
            },
            getOptions: function () {
              return o.options;
            },
            parse: function (e, t) {
              if (!h) throw new Error("Tokenizer instance wasn't specified.");
              h.initString(e);
              var r = o.options;
              t && (o.options = Object.assign({}, o.options, t)),
                v.onParseBegin(e, h, o.options),
                (f.length = 0),
                f.push(0);
              var n = h.getNextToken(),
                c = null;
              do {
                n || ((o.options = r), L());
                var m = f[f.length - 1],
                  g = d[n.type];
                p[m].hasOwnProperty(g) || ((o.options = r), j(n));
                var y = p[m][g];
                if ("s" === y[0]) {
                  var b = null;
                  o.options.captureLocations &&
                    (b = {
                      startOffset: n.startOffset,
                      endOffset: n.endOffset,
                      startLine: n.startLine,
                      endLine: n.endLine,
                      startColumn: n.startColumn,
                      endColumn: n.endColumn,
                    }),
                    (c = this.onShift(n)),
                    f.push(
                      { symbol: d[c.type], semanticValue: c.value, loc: b },
                      Number(y.slice(1))
                    ),
                    (n = h.getNextToken());
                } else if ("r" === y[0]) {
                  var _ = y.slice(1),
                    E = l[_],
                    w = "function" == typeof E[2],
                    x = w ? [] : null,
                    S = w && o.options.captureLocations ? [] : null;
                  if (0 !== E[1])
                    for (var T = E[1]; T-- > 0; ) {
                      f.pop();
                      var A = f.pop();
                      w && (x.unshift(A.semanticValue), S && S.unshift(A.loc));
                    }
                  var k = { symbol: E[0] };
                  if (w) {
                    (a = c ? c.value : null), c ? c.value.length : null;
                    var C = null !== S ? x.concat(S) : x;
                    E[2].apply(E, i(C)),
                      (k.semanticValue = s),
                      S && (k.loc = u);
                  }
                  var O = f[f.length - 1],
                    P = E[0];
                  f.push(k, p[O][P]);
                } else if ("acc" === y) {
                  f.pop();
                  var I = f.pop();
                  return (
                    (1 !== f.length || 0 !== f[0] || h.hasMoreTokens()) &&
                      ((o.options = r), j(n)),
                    I.hasOwnProperty("semanticValue")
                      ? ((o.options = r),
                        v.onParseEnd(I.semanticValue),
                        I.semanticValue)
                      : (v.onParseEnd(), (o.options = r), !0)
                  );
                }
              } while (h.hasMoreTokens() || f.length > 1);
            },
            setTokenizer: function (e) {
              return (h = e), v;
            },
            getTokenizer: function () {
              return h;
            },
            onParseBegin: function (e, t, r) {},
            onParseEnd: function (e) {},
            onShift: function (e) {
              return e;
            },
          },
          b = 0,
          _ = {},
          E = "";
        function w(e) {
          var t = e.match(/\d+/g).map(Number);
          if (Number.isFinite(t[1]) && t[1] < t[0])
            throw new SyntaxError(
              "Numbers out of order in " + e + " quantifier"
            );
          return t;
        }
        function x(e, t) {
          if (
            "control" === e.kind ||
            "control" === t.kind ||
            (!isNaN(e.codePoint) &&
              !isNaN(t.codePoint) &&
              e.codePoint > t.codePoint)
          )
            throw new SyntaxError(
              "Range " +
                e.value +
                "-" +
                t.value +
                " out of order in character class"
            );
        }
        (v.onParseBegin = function (e, t) {
          (E = e), (b = 0), (_ = {});
          var r = e.lastIndexOf("/"),
            n = e.slice(r);
          n.includes("x") && n.includes("u")
            ? t.pushState("xu")
            : (n.includes("x") && t.pushState("x"),
              n.includes("u") && t.pushState("u"));
        }),
          (v.onShift = function (e) {
            return (
              ("L_PAREN" !== e.type && "NAMED_CAPTURE_GROUP" !== e.type) ||
                ((e.value = new String(e.value)), (e.value.groupNumber = ++b)),
              e
            );
          });
        var S = r(45109);
        function T(e, t, r) {
          var i = void 0,
            a = void 0;
          switch (t) {
            case "decimal":
              (a = Number(e.slice(1))), (i = String.fromCodePoint(a));
              break;
            case "oct":
              (a = parseInt(e.slice(1), 8)), (i = String.fromCodePoint(a));
              break;
            case "hex":
            case "unicode":
              if (e.lastIndexOf("\\u") > 0) {
                var o = e.split("\\u").slice(1),
                  s = n(o, 2),
                  u = s[0],
                  c = s[1];
                (a =
                  1024 * ((u = parseInt(u, 16)) - 55296) +
                  ((c = parseInt(c, 16)) - 56320) +
                  65536),
                  (i = String.fromCodePoint(a));
              } else {
                var l = e.slice(2).replace("{", "");
                if ((a = parseInt(l, 16)) > 1114111)
                  throw new SyntaxError("Bad character escape sequence: " + e);
                i = String.fromCodePoint(a);
              }
              break;
            case "meta":
              switch (e) {
                case "\\t":
                  a = (i = "\t").codePointAt(0);
                  break;
                case "\\n":
                  a = (i = "\n").codePointAt(0);
                  break;
                case "\\r":
                  a = (i = "\r").codePointAt(0);
                  break;
                case "\\v":
                  a = (i = "\v").codePointAt(0);
                  break;
                case "\\f":
                  a = (i = "\f").codePointAt(0);
                  break;
                case "\\b":
                  a = (i = "\b").codePointAt(0);
                case "\\0":
                  (i = "\0"), (a = 0);
                case ".":
                  (i = "."), (a = NaN);
                  break;
                default:
                  a = NaN;
              }
              break;
            case "simple":
              a = (i = e).codePointAt(0);
          }
          return D(
            { type: "Char", value: e, kind: t, symbol: i, codePoint: a },
            r
          );
        }
        var A = "gimsuxy";
        function k(e) {
          var t = new Set(),
            r = !0,
            n = !1,
            i = void 0;
          try {
            for (
              var a, o = e[Symbol.iterator]();
              !(r = (a = o.next()).done);
              r = !0
            ) {
              var s = a.value;
              if (t.has(s) || !A.includes(s))
                throw new SyntaxError("Invalid flags: " + e);
              t.add(s);
            }
          } catch (e) {
            (n = !0), (i = e);
          } finally {
            try {
              !r && o.return && o.return();
            } finally {
              if (n) throw i;
            }
          }
          return e.split("").sort().join("");
        }
        var C = /^\\u[0-9a-fA-F]{4}/,
          O = /^\\u\{[0-9a-fA-F]{1,}\}/,
          P = /\\u\{[0-9a-fA-F]{1,}\}/;
        function I(e, t) {
          if (P.test(e) && !("u" === t || "xu" === t || "u_class" === t))
            throw new SyntaxError(
              'invalid group Unicode name "' + e + '", use `u` flag.'
            );
          return e;
        }
        var N =
          /\\u(?:([dD][89aAbB][0-9a-fA-F]{2})\\u([dD][c-fC-F][0-9a-fA-F]{2})|([dD][89aAbB][0-9a-fA-F]{2})|([dD][c-fC-F][0-9a-fA-F]{2})|([0-9a-ce-fA-CE-F][0-9a-fA-F]{3}|[dD][0-7][0-9a-fA-F]{2})|\{(0*(?:[0-9a-fA-F]{1,5}|10[0-9a-fA-F]{4}))\})/;
        function R(e) {
          return e.replace(new RegExp(N, "g"), function (e, t, r, n, i, a, o) {
            return t
              ? String.fromCodePoint(parseInt(t, 16), parseInt(r, 16))
              : n
              ? String.fromCodePoint(parseInt(n, 16))
              : i
              ? String.fromCodePoint(parseInt(i, 16))
              : a
              ? String.fromCodePoint(parseInt(a, 16))
              : o
              ? String.fromCodePoint(parseInt(o, 16))
              : e;
          });
        }
        function D(e, t) {
          return (
            o.options.captureLocations &&
              (e.loc = {
                source: E.slice(t.startOffset, t.endOffset),
                start: {
                  line: t.startLine,
                  column: t.startColumn,
                  offset: t.startOffset,
                },
                end: {
                  line: t.endLine,
                  column: t.endColumn,
                  offset: t.endOffset,
                },
              }),
            e
          );
        }
        function F(e, t) {
          return o.options.captureLocations
            ? {
                startOffset: e.startOffset,
                endOffset: t.endOffset,
                startLine: e.startLine,
                endLine: t.endLine,
                startColumn: e.startColumn,
                endColumn: t.endColumn,
              }
            : null;
        }
        function j(e) {
          "$" === e.type && L(),
            h.throwUnexpectedToken(e.value, e.startLine, e.startColumn);
        }
        function L() {
          !(function (e) {
            throw new SyntaxError(e);
          })("Unexpected end of input.");
        }
        e.exports = v;
      } };
