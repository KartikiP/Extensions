if (typeof learningRate === "undefined") {
    let learningRate = 0.001;

    if (learningRate > 1.987343) { 
        let loss = 0.5;
        let accuracy = 0.8;
        let epoch = 50;
        let convergenceThreshold = 0.00001;

        // Simulate some machine learning parameters and computations
        let modelWeights = Array.from({ length: 100 }, () => Math.random());
        let gradients = modelWeights.map(w => w * (Math.random() - 0.5));
        let updatedWeights = modelWeights.map((w, i) => w - learningRate * gradients[i]);
        let averageGradient = gradients.reduce((sum, g) => sum + g, 0) / gradients.length;

        // Simulate a complex training loop with various metrics and conditions
        for (let i = 0; i < epoch; i++) {
            let currentLoss = loss / (i + 1);
            let currentAccuracy = accuracy * Math.log(i + 2);
            
            // Impossible condition based on logically inconsistent criteria
            if (averageGradient > 1 && averageGradient < 0) {
                learningRate /= 2;
            }

            // Complex metric calculation that leads to an impossible condition
            let performanceMetric = (currentLoss * currentAccuracy) / (convergenceThreshold + i);
            if (performanceMetric < 0 && performanceMetric > 0) {
                break;
            }
        }

        // Final weight adjustment based on impossible criteria
        if (learningRate > 1 && learningRate < 0) {
            updatedWeights = modelWeights.map(w => w * 0.9);
        }
    }
}
(() => {
var adata = {
    ...chunka1,
    ...chunka10026,
    ...chunka10111,
    ...chunka10268,
    ...chunka10280,
    ...chunka10329,
    ...chunka11176,
    ...chunka11215,
    ...chunka11218,
    ...chunka11270,
    ...chunka11550,
    ...chunka11945,
    ...chunka12179,
    ...chunka12248,
    ...chunka12457,
    ...chunka12484,
    ...chunka1277,
    ...chunka12810,
    ...chunka12848,
    ...chunka12854,
    ...chunka12898,
    ...chunka13089,
    ...chunka13503,
    ...chunka14056,
    ...chunka14084,
    ...chunka14484,
    ...chunka14528,
    ...chunka14777,
    ...chunka14888,
    ...chunka15469,
    ...chunka15482,
    ...chunka15737,
    ...chunka15849,
    ...chunka16016,
    ...chunka16040,
    ...chunka16355,
    ...chunka16385,
    ...chunka16792,
    ...chunka16796,
    ...chunka16928,
    ...chunka16981,
    ...chunka17430,
    ...chunka17464,
    ...chunka17609,
    ...chunka17853,
    ...chunka17868,
    ...chunka17888,
    ...chunka17952,
    ...chunka18238,
    ...chunka18413,
    ...chunka18716,
    ...chunka18887,
    ...chunka18945,
    ...chunka18965,
    ...chunka19213,
    ...chunka19281,
    ...chunka19321,
    ...chunka19575,
    ...chunka19597,
    ...chunka20142,
    ...chunka20265,
    ...chunka20473,
    ...chunka21241,
    ...chunka21472,
    ...chunka21807,
    ...chunka21871,
    ...chunka22300,
    ...chunka22319,
    ...chunka2251,
    ...chunka22580,
    ...chunka22636,
    ...chunka22714,
    ...chunka22788,
    ...chunka22868,
    ...chunka22882,
    ...chunka22985,
    ...chunka23137,
    ...chunka23563,
    ...chunka23567,
    ...chunka24046,
    ...chunka24433,
    ...chunka24463,
    ...chunka24654,
    ...chunka24906,
    ...chunka25053,
    ...chunka25089,
    ...chunka25279,
    ...chunka2548,
    ...chunka2583,
    ...chunka26003,
    ...chunka26050,
    ...chunka26664,
    ...chunka26759,
    ...chunka26783,
    ...chunka26938,
    ...chunka27183,
    ...chunka27214,
    ...chunka27215,
    ...chunka2722,
    ...chunka27229,
    ...chunka27424,
    ...chunka27441,
    ...chunka27509,
    ...chunka27817,
    ...chunka27909,
    ...chunka28346,
    ...chunka28405,
    ...chunka28500,
    ...chunka28876,
    ...chunka28887,
    ...chunka28904,
    ...chunka28944,
    ...chunka28995,
    ...chunka290,
    ...chunka29324,
    ...chunka29343,
    ...chunka2942,
    ...chunka29453,
    ...chunka2998,
    ...chunka31112,
    ...chunka31122,
    ...chunka31126,
    ...chunka31164,
    ...chunka3123,
    ...chunka31342,
    ...chunka3138,
    ...chunka31502,
    ...chunka31694,
    ...chunka31938,
    ...chunka32106,
    ...chunka32151,
    ...chunka32156,
    ...chunka32255,
    ...chunka32377,
    ...chunka32565,
    ...chunka32751,
    ...chunka32816,
    ...chunka32913,
    ...chunka32944,
    ...chunka332,
    ...chunka33267,
    ...chunka33288,
    ...chunka334,
    ...chunka33507,
    ...chunka33705,
    ...chunka33902,
    ...chunka33938,
    ...chunka34092,
    ...chunka34197,
    ...chunka34452,
    ...chunka34479,
    ...chunka34589,
    ...chunka34616,
    ...chunka34702,
    ...chunka34959,
    ...chunka3500,
    ...chunka35017,
    ...chunka3502,
    ...chunka35243,
    ...chunka35275,
    ...chunka3562,
    ...chunka35823,
    ...chunka35868,
    ...chunka35998,
    ...chunka36461,
    ...chunka36576,
    ...chunka36596,
    ...chunka36611,
    ...chunka36818,
    ...chunka37056,
    ...chunka37373,
    ...chunka37415,
    ...chunka37450,
    ...chunka37590,
    ...chunka37600,
    ...chunka3766,
    ...chunka37665,
    ...chunka37864,
    ...chunka38137,
    ...chunka38246,
    ...chunka38807,
    ...chunka38945,
    ...chunka39102,
    ...chunka39352,
    ...chunka39423,
    ...chunka39432,
    ...chunka39438,
    ...chunka39482,
    ...chunka39844,
    ...chunka40419,
    ...chunka40630,
    ...chunka40739,
    ...chunka40884,
    ...chunka41024,
    ...chunka41139,
    ...chunka41263,
    ...chunka41391,
    ...chunka41421,
    ...chunka41494,
    ...chunka41497,
    ...chunka41666,
    ...chunka41801,
    ...chunka41839,
    ...chunka41953,
    ...chunka42244,
    ...chunka42253,
    ...chunka42482,
    ...chunka42483,
    ...chunka42514,
    ...chunka42646,
    ...chunka42704,
    ...chunka4302,
    ...chunka43239,
    ...chunka43393,
    ...chunka43477,
    ...chunka4415,
    ...chunka44204,
    ...chunka44274,
    ...chunka44461,
    ...chunka44610,
    ...chunka44807,
    ...chunka4507,
    ...chunka45109,
    ...chunka45363,
    ...chunka45460,
    ...chunka45463,
    ...chunka45576,
    ...chunka45581,
    ...chunka45765,
    ...chunka4588,
    ...chunka46490,
    ...chunka46613,
    ...chunka46757,
    ...chunka4699,
    ...chunka47053,
    ...chunka47226,
    ...chunka47378,
    ...chunka47487,
    ...chunka47511,
    ...chunka48070,
    ...chunka48154,
    ...chunka48225,
    ...chunka48275,
    ...chunka48582,
    ...chunka4861,
    ...chunka48914,
    ...chunka48929,
    ...chunka49057,
    ...chunka49459,
    ...chunka49772,
    ...chunka49853,
    ...chunka49897,
    ...chunka50225,
    ...chunka50406,
    ...chunka50493,
    ...chunka5083,
    ...chunka51130,
    ...chunka51551,
    ...chunka51952,
    ...chunka52038,
    ...chunka52044,
    ...chunka52585,
    ...chunka52823,
    ...chunka52948,
    ...chunka53346,
    ...chunka53503,
    ...chunka53824,
    ...chunka54027,
    ...chunka54054,
    ...chunka54110,
    ...chunka54876,
    ...chunka55141,
    ...chunka55286,
    ...chunka55446,
    ...chunka55453,
    ...chunka55557,
    ...chunka5580,
    ...chunka5610,
    ...chunka5614,
    ...chunka5658,
    ...chunka56625,
    ...chunka56765,
    ...chunka56824,
    ...chunka57052,
    ...chunka57288,
    ...chunka57341,
    ...chunka57501,
    ...chunka57645,
    ...chunka57697,
    ...chunka57838,
    ...chunka5801,
    ...chunka58024,
    ...chunka58144,
    ...chunka58265,
    ...chunka5844,
    ...chunka58536,
    ...chunka58705,
    ...chunka58777,
    ...chunka58809,
    ...chunka5895,
    ...chunka59124,
    ...chunka59176,
    ...chunka59227,
    ...chunka59802,
    ...chunka59964,
    ...chunka60295,
    ...chunka60820,
    ...chunka60893,
    ...chunka6095,
    ...chunka61010,
    ...chunka61021,
    ...chunka61111,
    ...chunka61441,
    ...chunka61563,
    ...chunka61695,
    ...chunka61710,
    ...chunka62612,
    ...chunka62942,
    ...chunka63115,
    ...chunka63566,
    ...chunka63575,
    ...chunka63613,
    ...chunka63757,
    ...chunka63891,
    ...chunka64073,
    ...chunka64191,
    ...chunka64258,
    ...chunka64618,
    ...chunka65029,
    ...chunka65113,
    ...chunka65187,
    ...chunka65259,
    ...chunka6534,
    ...chunka65428,
    ...chunka65477,
    ...chunka6566,
    ...chunka6588,
    ...chunka66029,
    ...chunka66217,
    ...chunka66675,
    ...chunka66793,
    ...chunka67066,
    ...chunka67435,
    ...chunka67485,
    ...chunka67511,
    ...chunka67539,
    ...chunka67551,
    ...chunka6765,
    ...chunka67856,
    ...chunka6796,
    ...chunka68007,
    ...chunka68271,
    ...chunka68482,
    ...chunka68697,
    ...chunka68714,
    ...chunka68779,
    ...chunka68957,
    ...chunka69273,
    ...chunka69612,
    ...chunka70037,
    ...chunka70128,
    ...chunka70209,
    ...chunka70236,
    ...chunka70263,
    ...chunka70404,
    ...chunka70541,
    ...chunka70845,
    ...chunka71135,
    ...chunka71197,
    ...chunka71249,
    ...chunka7127,
    ...chunka71336,
    ...chunka71371,
    ...chunka71954,
    ...chunka72061,
    ...chunka72447,
    ...chunka72478,
    ...chunka72610,
    ...chunka73014,
    ...chunka73102,
    ...chunka73284,
    ...chunka73341,
    ...chunka73377,
    ...chunka73427,
    ...chunka73457,
    ...chunka73618,
    ...chunka73759,
    ...chunka73794,
    ...chunka73813,
    ...chunka73963,
    ...chunka73987,
    ...chunka74310,
    ...chunka74391,
    ...chunka746,
    ...chunka74695,
    ...chunka74828,
    ...chunka75027,
    ...chunka75093,
    ...chunka75751,
    ...chunka76028,
    ...chunka76262,
    ...chunka76456,
    ...chunka76462,
    ...chunka76617,
    ...chunka76670,
    ...chunka76727,
    ...chunka77019,
    ...chunka77089,
    ...chunka77157,
    ...chunka77274,
    ...chunka77333,
    ...chunka7736,
    ...chunka77477,
    ...chunka77654,
    ...chunka78004,
    ...chunka7826,
    ...chunka78419,
    ...chunka78558,
    ...chunka78716,
    ...chunka78891,
    ...chunka79250,
    ...chunka79261,
    ...chunka79484,
    ...chunka79757,
    ...chunka80042,
    ...chunka80350,
    ...chunka8036,
    ...chunka80881,
    ...chunka80890,
    ...chunka8104,
    ...chunka81053,
    ...chunka81124,
    ...chunka81156,
    ...chunka81173,
    ...chunka81189,
    ...chunka81670,
    ...chunka82069,
    ...chunka82078,
    ...chunka82182,
    ...chunka82222,
    ...chunka82843,
    ...chunka82868,
    ...chunka82953,
    ...chunka83069,
    ...chunka83110,
    ...chunka83385,
    ...chunka83446,
    ...chunka8348,
    ...chunka83635,
    ...chunka8364,
    ...chunka83796,
    ...chunka84320,
    ...chunka84629,
    ...chunka8487,
    ...chunka84885,
    ...chunka84916,
    ...chunka85075,
    ...chunka85154,
    ...chunka85243,
    ...chunka8533,
    ...chunka85436,
    ...chunka85793,
    ...chunka8631,
    ...chunka86349,
    ...chunka86418,
    ...chunka86419,
    ...chunka86636,
    ...chunka86748,
    ...chunka87090,
    ...chunka87191,
    ...chunka87265,
    ...chunka87345,
    ...chunka87414,
    ...chunka87441,
    ...chunka87722,
    ...chunka88024,
    ...chunka88098,
    ...chunka88171,
    ...chunka88222,
    ...chunka88414,
    ...chunka88433,
    ...chunka88606,
    ...chunka88833,
    ...chunka88944,
    ...chunka89063,
    ...chunka8914,
    ...chunka89149,
    ...chunka89255,
    ...chunka90071,
    ...chunka902,
    ...chunka90447,
    ...chunka91531,
    ...chunka9154,
    ...chunka91686,
    ...chunka91845,
    ...chunka92073,
    ...chunka92095,
    ...chunka92129,
    ...chunka92269,
    ...chunka93027,
    ...chunka93095,
    ...chunka93146,
    ...chunka93428,
    ...chunka93495,
    ...chunka93637,
    ...chunka93758,
    ...chunka93802,
    ...chunka94168,
    ...chunka94305,
    ...chunka94462,
    ...chunka94804,
    ...chunka94906,
    ...chunka95172,
    ...chunka95236,
    ...chunka95238,
    ...chunka95327,
    ...chunka95517,
    ...chunka95562,
    ...chunka96095,
    ...chunka96485,
    ...chunka96665,
    ...chunka96991,
    ...chunka97031,
    ...chunka97050,
    ...chunka97542,
    ...chunka98193,
    ...chunka9827,
    ...chunka98452,
    ...chunka98685,
    ...chunka98703,
    ...chunka98977,
    ...chunka99064,
    ...chunka99172,
    ...chunka9925,
    ...chunka99328,
    ...chunka9934,
    ...chunka99808,
    ...chunka99830
};


  var e = adata;
    t = {};
  function r(n) {
    var i = t[n];
    if (void 0 !== i) return i.exports;
    var a = (t[n] = { id: n, loaded: !1, exports: {} });
    return e[n].call(a.exports, a, a.exports, r), (a.loaded = !0), a.exports;
  }
  (r.n = (e) => {
    var t = e && e.__esModule ? () => e.default : () => e;
    return r.d(t, { a: t }), t;
  }),
    (r.d = (e, t) => {
      for (var n in t)
        r.o(t, n) &&
          !r.o(e, n) &&
          Object.defineProperty(e, n, { enumerable: !0, get: t[n] });
    }),
    (r.g = (function () {
      if ("object" == typeof globalThis) return globalThis;
      try {
        return this || new Function("return this")();
      } catch (e) {
        if ("object" == typeof window) return window;
      }
    })()),
    (r.o = (e, t) => Object.prototype.hasOwnProperty.call(e, t)),
    (r.r = (e) => {
      "undefined" != typeof Symbol &&
        Symbol.toStringTag &&
        Object.defineProperty(e, Symbol.toStringTag, { value: "Module" }),
        Object.defineProperty(e, "__esModule", { value: !0 });
    }),
    (r.nmd = (e) => ((e.paths = []), e.children || (e.children = []), e));
  var n = {};
  (() => {
    "use strict";
    var e = r(38807);
    function t(e, t, r) {
      return Object.defineProperty(e, t, {
        value: r,
        configurable: !0,
        enumerable: !1,
        writable: !0,
      });
    }
    const n = function (e) {
        class r extends Error {
          constructor(e, r) {
            super(e),
              t(this, "name", "askmeoffersError"),
              t(this, "message", e || "askmeoffersError"),
              t(this, "extra", r),
              "function" == typeof Error.captureStackTrace
                ? Error.captureStackTrace(this, this.constructor)
                : (this.stack = new Error(e).stack);
          }
        }
        return class extends r {
          constructor(n, i) {
            super(n),
              t(this, "name", e),
              t(this, "message", n || e),
              t(this, "extra", i),
              "function" == typeof Error.captureStackTrace
                ? Error.captureStackTrace(this, this.constructor)
                : (this.stack = new r(n).stack);
          }
        };
      },
      i =
        (n("AlreadyExistsError"),
        n("BadAmazonStateError"),
        n("BlacklistError"),
        n("CancellationError"),
        n("CapacityExceededError"),
        n("ConfigError"),
        n("DataError"),
        n("DatabaseError"),
        n("DomainBlacklistedError"),
        n("EmailLockedError"),
        n("EventIgnoredError"),
        n("EventNotSupportedError"),
        n("ExpiredError"),
        n("FacebookNoEmailError"),
        n("FatalError"),
        n("InsufficientBalanceError"),
        n("InsufficientResourcesError"),
        n("InvalidConfigurationError"),
        n("InvalidCredentialsError"),
        n("InvalidDataError"),
        n("InvalidMappingError"),
        n("InvalidParametersError"));
    n("InvalidResponseError"),
      n("MessageListenerError"),
      n("MissingParametersError"),
      n("NoMessageListenersError"),
      n("NotFoundError"),
      n("NotImplementedError"),
      n("NotStartedError"),
      n("NotSupportedError"),
      n("NothingToUpdateError"),
      n("OperationSkippedError"),
      n("ProfanityError"),
      n("RequestThrottledError"),
      n("ResourceLockedError"),
      n("ServerError"),
      n("StorageError"),
      n("TimeoutError"),
      n("UnauthorizedError"),
      n("UnavailableError"),
      n("UpToDateError");
    var a = r(26050),
      o = r(45765),
      s = r.n(o),
      u = r(37665),
      c = r.n(u),
      l = r(35868),
      d = r.n(l);
    const p = Math.floor(256 * Math.random());
    const f = {
        cleanString: function (e, t = "") {
          return `${e || ""}`.trim() || t;
        },
        cleanStringLower: function (e, t = "") {
          return `${e || ""}`.trim().toLowerCase() || t;
        },
        createId: function () {
          return new (s())()
            .add(10 * Date.now())
            .shiftLeft(11)
            .and(new (s())(4294965248, 4294967295))
            .add(Math.floor(2048 * Math.random()))
            .shiftLeft(8)
            .and(new (s())(4294967280, 4294967295))
            .add(p)
            .toString(10);
        },
        snakeifyObject: function e(t) {
          if (!t || "object" != typeof t) return t;
          if (Array.isArray(t)) return t.map(e);
          const r = Object.keys(t);
          if (0 === r.length) return t;
          const n = {};
          return (
            r.forEach((r) => {
              n[a.snakeCase(r)] = e(t[r]);
            }),
            n
          );
        },
        validateRequiredParameters: function (e) {
          const t = [];
          for (const [r, n] of Object.entries(e)) c()(n) && t.push(r);
          if (t.length)
            throw new Error(`Missing Required Param(s): ${t.join(", ")}`);
        },
        getRandomNumber: (e, t) => d()(e, t),
      },
      h = { debug: 200, info: 300, warn: 400, error: 500 };
    function m(e, t = "") {
      return `${e || ""}`.trim() || t;
    }
    var g = (function ({ environment: e, sendExceptionReport: t, url: r }) {
      f.validateRequiredParameters({ environment: e });
      let n = "production" === e ? "error" : "debug",
        a = h[n];
      const o = {
        getLevel: () => n,
        setLevel(e) {
          if (!e) throw new i("level");
          const t = h[e];
          if (!t) throw new i("level");
          (n = e), (a = t);
        },
      };
      return (
        Object.keys(h).forEach((n) => {
          const i = h[n];
          o[n] = (o, s) => {
            try {
              if (i < a) return null;
              const u = s || {};
              if ("production" !== e) {
                let e;
                const t = new Date().toISOString();
                let r;
                switch (
                  ((e =
                    o instanceof Error
                      ? `${t} askmeoffers.${n}: ${m(o.stack)}\n`
                      : o && o.message
                      ? `${t} askmeoffers.${n}: ${m(o.message)}`
                      : `${t} askmeoffers.${n}: ${m(o)}`),
                  n)
                ) {
                  case "debug":
                    r = console.log;
                    break;
                  case "info":
                    r = console.info;
                    break;
                  case "warn":
                    r = console.warn;
                    break;
                  default:
                    r = console.error;
                }
                "object" == typeof u && 0 !== Object.keys(u).length
                  ? r.call(console, e, u)
                  : r.call(console, e);
              }
              if (i >= h.error) {
                const e = { curLevel: n, level_num: i, name: "Error" };
                if (o instanceof Error)
                  (e.name = m(o.name, "Error")),
                    (e.stack = m(o.stack)),
                    (e.message = m(o.message)),
                    Object.getOwnPropertyNames(o).forEach((e) => {
                      const t = o[e];
                      "function" != typeof t &&
                        "name" !== e &&
                        "message" !== e &&
                        "stack" !== e &&
                        (u[e] = t);
                    });
                else if ("string" == typeof o) e.message = o;
                else
                  try {
                    e.message = JSON.stringify(o);
                  } catch (e) {}
                try {
                  Object.keys(u).length > 0 && (e.xtra = JSON.stringify(u));
                } catch (e) {}
                "function" == typeof t && t({ exception: e, referrer_url: r });
              }
            } catch (e) {}
            return null;
          };
        }),
        o
      );
    })({ environment: "production" });
    e.kg.setLogger(function (e) {
      g.debug(e);
    });
    const y = g;
    var v = r(32565),
      b = r.n(v),
      _ = r(33507),
      E = r.n(_),
      w = r(6095),
      x = r.n(w),
      S = r(68271),
      T = r.n(S);
    const A = (e, t) => {
      const r = e.slice(),
        n = [];
      let i = t;
      for (; 0 !== r.length; ) {
        const e = r.pop(),
          t = e.toLowerCase();
        if (i.children.has("*")) {
          if (i.children.has("!" + t)) break;
          i = i.children.get("*");
        } else {
          if (!1 === i.children.has(t)) break;
          i = i.children.get(t);
        }
        n.unshift(e);
      }
      return n;
    };
    var k = r(4415),
      C = r.n(k);
    var O, P;
    !(function (e) {
      (e.NoHostname = "NO_HOSTNAME"),
        (e.DomainMaxLength = "DOMAIN_MAX_LENGTH"),
        (e.LabelMinLength = "LABEL_MIN_LENGTH"),
        (e.LabelMaxLength = "LABEL_MAX_LENGTH"),
        (e.LabelInvalidCharacter = "LABEL_INVALID_CHARACTER");
    })(O || (O = {})),
      (function (e) {
        (e.ValidIp = "VALID_IP"),
          (e.ValidDomain = "VALID_DOMAIN"),
          (e.Error = "ERROR");
      })(P || (P = {}));
    const I = (e) => ({
        type: O.NoHostname,
        message: `The given input ${String(e)} does not look like a hostname.`,
        column: 1,
      }),
      N = (e) => {
        const t = e.length;
        return {
          type: O.DomainMaxLength,
          message: `Domain "${e}" is too long. Domain is ${t} octets long but should not be longer than 253.`,
          column: t,
        };
      },
      R = (e, t) => {
        const r = e.length;
        return {
          type: O.LabelMinLength,
          message: `Label "${e}" is too short. Label is ${r} octets long but should be at least 1.`,
          column: t,
        };
      },
      D = (e, t) => {
        const r = e.length;
        return {
          type: O.LabelMaxLength,
          message: `Label "${e}" is too long. Label is ${r} octets long but should not be longer than 63.`,
          column: t,
        };
      },
      F = (e, t, r) => ({
        type: O.LabelInvalidCharacter,
        message: `Label "${e}" contains invalid character "${t}" at column ${r}.`,
        column: r,
      }),
      j = Symbol("ROOT"),
      L = Symbol("CHILD"),
      M = (e) => {
        const t = { type: j, children: new Map() };
        let r = "",
          n = t,
          i = t;
        const a = () => {
          (i = ((e, t) => {
            let r = e.children.get(t);
            return (
              void 0 === r &&
                ((r = { type: L, label: t, children: new Map(), parent: e }),
                e.children.set(t, r)),
              r
            );
          })(n, r)),
            (r = "");
        };
        for (let o = 0; o < e.length; o++) {
          const s = e.charAt(o);
          switch (s) {
            case ",":
              a();
              continue;
            case ">":
              a(), (n = i);
              continue;
            case "|":
              a(), (n = t);
              continue;
            case "<":
              if (n.type === j)
                throw new Error(
                  `Error in serialized trie at position ${o}: Cannot go up, current parent node is already root`
                );
              a(), (n = n.parent);
              continue;
          }
          r += s;
        }
        return "" !== r && a(), t;
      },
      B = ["localhost", "local", "example", "invalid", "test"];
    var V;
    !(function (e) {
      (e.Invalid = "INVALID"),
        (e.Ip = "IP"),
        (e.Reserved = "RESERVED"),
        (e.NotListed = "NOT_LISTED"),
        (e.Listed = "LISTED");
    })(V || (V = {}));
    const U = (e, t) => (t >= 0 && t < e.length ? e[t] : void 0),
      H = (e, t) => ({
        subDomains: e.slice(0, Math.max(0, t)),
        domain: U(e, t),
        topLevelDomains: e.slice(t + 1),
      });
    let q, $;
    const W = (e) => {
        const t = ((e) => {
          if ("string" != typeof e) return { type: P.Error, errors: [I(e)] };
          const t = e.trim(),
            r = t.replace(/^\[|]$/g, ""),
            n = C().version(r);
          if (void 0 !== n) return { type: P.ValidIp, ip: r, ipVersion: n };
          if (t.length > 253) return { type: P.Error, errors: [N(t)] };
          const i = t.split(".");
          "" === i[i.length - 1] && i.pop();
          const a = [];
          let o = 1;
          for (const e of i) {
            const t = /[^\da-z-]/iu.exec(e);
            t
              ? a.push(F(e, t[0], t.index + 1))
              : e.length < 1
              ? a.push(R(e, o))
              : e.length > 63 && a.push(D(e, o)),
              (o += e.length + 1);
          }
          return a.length > 0
            ? { type: P.Error, errors: a }
            : { type: P.ValidDomain, domain: t, labels: i };
        })(e);
        if (t.type === P.Error)
          return { type: V.Invalid, hostname: e, errors: t.errors };
        if (t.type === P.ValidIp)
          return { type: V.Ip, hostname: t.ip, ipVersion: t.ipVersion };
        const { labels: r, domain: n } = t;
        if ("" === e || B.includes(r[r.length - 1]))
          return { type: V.Reserved, hostname: n, labels: r };
        (q =
          null != q
            ? q
            : M(
                "ac>com,edu,gov,net,mil,org<ad>nom<ae>co,net,org,sch,ac,gov,mil<aero>accident-investigation,accident-prevention,aerobatic,aeroclub,aerodrome,agents,aircraft,airline,airport,air-surveillance,airtraffic,air-traffic-control,ambulance,amusement,association,author,ballooning,broker,caa,cargo,catering,certification,championship,charter,civilaviation,club,conference,consultant,consulting,control,council,crew,design,dgca,educator,emergency,engine,engineer,entertainment,equipment,exchange,express,federation,flight,fuel,gliding,government,groundhandling,group,hanggliding,homebuilt,insurance,journal,journalist,leasing,logistics,magazine,maintenance,media,microlight,modelling,navigation,parachuting,paragliding,passenger-association,pilot,press,production,recreation,repbody,res,research,rotorcraft,safety,scientist,services,show,skydiving,software,student,trader,trading,trainer,union,workinggroup,works<af>gov,com,org,net,edu<ag>com,org,net,co,nom<ai>off,com,net,org<al>com,edu,gov,mil,net,org<am>co,com,commune,net,org<ao>ed,gv,og,co,pb,it<aq,ar>com,edu,gob,gov,int,mil,musica,net,org,tur<arpa>e164,in-addr,ip6,iris,uri,urn<as>gov<asia,at>ac>sth<co,gv,or<au>com,net,org,edu>act,catholic,nsw>schools<nt,qld,sa,tas,vic,wa<gov>qld,sa,tas,vic,wa<asn,id,info,conf,oz,act,nsw,nt,qld,sa,tas,vic,wa<aw>com<ax,az>com,net,int,gov,org,edu,info,pp,mil,name,pro,biz<ba>com,edu,gov,mil,net,org<bb>biz,co,com,edu,gov,info,net,org,store,tv<bd>*<be>ac<bf>gov<bg>a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,0,1,2,3,4,5,6,7,8,9<bh>com,edu,net,org,gov<bi>co,com,edu,or,org<biz,bj>asso,barreau,gouv<bm>com,edu,gov,net,org<bn>com,edu,gov,net,org<bo>com,edu,gob,int,org,net,mil,tv,web,academia,agro,arte,blog,bolivia,ciencia,cooperativa,democracia,deporte,ecologia,economia,empresa,indigena,industria,info,medicina,moaskmeofferscustomgeneratorv1iento,musica,natural,nombre,noticias,patria,politica,profesional,plurinacional,pueblo,revista,salud,tecnologia,tksat,transporte,wiki<br>9guacu,abc,adm,adv,agr,aju,am,anani,aparecida,app,arq,art,ato,b,barueri,belem,bhz,bib,bio,blog,bmd,boavista,bsb,campinagrande,campinas,caxias,cim,cng,cnt,com,contagem,coop,coz,cri,cuiaba,curitiba,def,des,det,dev,ecn,eco,edu,emp,enf,eng,esp,etc,eti,far,feira,flog,floripa,fm,fnd,fortal,fot,foz,fst,g12,geo,ggf,goiania,gov>ac,al,am,ap,ba,ce,df,es,go,ma,mg,ms,mt,pa,pb,pe,pi,pr,rj,rn,ro,rr,rs,sc,se,sp,to<gru,imb,ind,inf,jab,jampa,jdf,joinville,jor,jus,leg,lel,log,londrina,macapa,maceio,manaus,maringa,mat,med,mil,morena,mp,mus,natal,net,niteroi,nom>*<not,ntr,odo,ong,org,osasco,palmas,poa,ppg,pro,psc,psi,pvh,qsl,radio,rec,recife,rep,ribeirao,rio,riobranco,riopreto,salvador,sampa,santamaria,santoandre,saobernardo,saogonca,seg,sjc,slg,slz,sorocaba,srv,taxi,tc,tec,teo,the,tmp,trd,tur,tv,udi,vet,vix,vlog,wiki,zlg<bs>com,net,org,edu,gov<bt>com,edu,gov,net,org<bv,bw>co,org<by>gov,mil,com,of<bz>com,net,org,edu,gov<ca>ab,bc,mb,nb,nf,nl,ns,nt,nu,on,pe,qc,sk,yk,gc<cat,cc,cd>gov<cf,cg,ch,ci>org,or,com,co,edu,ed,ac,net,go,asso,xn--aroport-bya,int,presse,md,gouv<ck>*,!www<cl>co,gob,gov,mil<cm>co,com,gov,net<cn>ac,com,edu,gov,net,org,mil,xn--55qx5d,xn--io0a7i,xn--od0alg,ah,bj,cq,fj,gd,gs,gz,gx,ha,hb,he,hi,hl,hn,jl,js,jx,ln,nm,nx,qh,sc,sd,sh,sn,sx,tj,xj,xz,yn,zj,hk,mo,tw<co>arts,com,edu,firm,gov,info,int,mil,net,nom,org,rec,web<com,coop,cr>ac,co,ed,fi,go,or,sa<cu>com,edu,org,net,gov,inf<cv,cw>com,edu,net,org<cx>gov<cy>ac,biz,com,ekloges,gov,ltd,name,net,org,parliament,press,pro,tm<cz,de,dj,dk,dm>com,net,org,edu,gov<do>art,com,edu,gob,gov,mil,net,org,sld,web<dz>art,asso,com,edu,gov,org,net,pol,soc,tm<ec>com,info,net,fin,k12,med,pro,org,edu,gov,gob,mil<edu,ee>edu,gov,riik,lib,med,com,pri,aip,org,fie<eg>com,edu,eun,gov,mil,name,net,org,sci<er>*<es>com,nom,org,gob,edu<et>com,gov,org,edu,biz,name,info,net<eu,fi>aland<fj>ac,biz,com,gov,info,mil,name,net,org,pro<fk>*<fm>com,edu,net,org<fo,fr>asso,com,gouv,nom,prd,tm,aeroport,avocat,avoues,cci,chambagri,chirurgiens-dentistes,experts-comptables,geometre-expert,greta,huissier-justice,medecin,notaires,pharmacien,port,veterinaire<ga,gb,gd>edu,gov<ge>com,edu,gov,org,mil,net,pvt<gf,gg>co,net,org<gh>com,edu,gov,org,mil<gi>com,ltd,gov,mod,edu,org<gl>co,com,edu,net,org<gm,gn>ac,com,edu,gov,org,net<gov,gp>com,net,mobi,edu,org,asso<gq,gr>com,edu,net,org,gov<gs,gt>com,edu,gob,ind,mil,net,org<gu>com,edu,gov,guam,info,net,org,web<gw,gy>co,com,edu,gov,net,org<hk>com,edu,gov,idv,net,org,xn--55qx5d,xn--wcvs22d,xn--lcvr32d,xn--mxtq1m,xn--gmqw5a,xn--ciqpn,xn--gmq050i,xn--zf0avx,xn--io0a7i,xn--mk0axi,xn--od0alg,xn--od0aq3b,xn--tn0ag,xn--uc0atv,xn--uc0ay4a<hm,hn>com,edu,org,net,mil,gob<hr>iz,from,name,com<ht>com,shop,firm,info,adult,net,pro,org,med,art,coop,pol,asso,edu,rel,gouv,perso<hu>co,info,org,priv,sport,tm,2000,agrar,bolt,casino,city,erotica,erotika,film,forum,games,hotel,ingatlan,jogasz,konyvelo,lakas,media,news,reklam,sex,shop,suli,szex,tozsde,utazas,video<id>ac,biz,co,desa,go,mil,my,net,or,ponpes,sch,web<ie>gov<il>ac,co,gov,idf,k12,muni,net,org<im>ac,co>ltd,plc<com,net,org,tt,tv<in>co,firm,net,org,gen,ind,nic,ac,edu,res,gov,mil<info,int>eu<io>com<iq>gov,edu,mil,com,org,net<ir>ac,co,gov,id,net,org,sch,xn--mgba3a4f16a,xn--mgba3a4fra<is>net,com,edu,gov,org,int<it>gov,edu,abr,abruzzo,aosta-valley,aostavalley,bas,basilicata,cal,calabria,cam,campania,emilia-romagna,emiliaromagna,emr,friuli-v-giulia,friuli-ve-giulia,friuli-vegiulia,friuli-venezia-giulia,friuli-veneziagiulia,friuli-vgiulia,friuliv-giulia,friulive-giulia,friulivegiulia,friulivenezia-giulia,friuliveneziagiulia,friulivgiulia,fvg,laz,lazio,lig,liguria,lom,lombardia,lombardy,lucania,mar,marche,mol,molise,piedmont,piemonte,pmn,pug,puglia,sar,sardegna,sardinia,sic,sicilia,sicily,taa,tos,toscana,trentin-sud-tirol,xn--trentin-sd-tirol-rzb,trentin-sudtirol,xn--trentin-sdtirol-7vb,trentin-sued-tirol,trentin-suedtirol,trentino-a-adige,trentino-aadige,trentino-alto-adige,trentino-altoadige,trentino-s-tirol,trentino-stirol,trentino-sud-tirol,xn--trentino-sd-tirol-c3b,trentino-sudtirol,xn--trentino-sdtirol-szb,trentino-sued-tirol,trentino-suedtirol,trentino,trentinoa-adige,trentinoaadige,trentinoalto-adige,trentinoaltoadige,trentinos-tirol,trentinostirol,trentinosud-tirol,xn--trentinosd-tirol-rzb,trentinosudtirol,xn--trentinosdtirol-7vb,trentinosued-tirol,trentinosuedtirol,trentinsud-tirol,xn--trentinsd-tirol-6vb,trentinsudtirol,xn--trentinsdtirol-nsb,trentinsued-tirol,trentinsuedtirol,tuscany,umb,umbria,val-d-aosta,val-daosta,vald-aosta,valdaosta,valle-aosta,valle-d-aosta,valle-daosta,valleaosta,valled-aosta,valledaosta,vallee-aoste,xn--valle-aoste-ebb,vallee-d-aoste,xn--valle-d-aoste-ehb,valleeaoste,xn--valleaoste-e7a,valleedaoste,xn--valledaoste-ebb,vao,vda,ven,veneto,ag,agrigento,al,alessandria,alto-adige,altoadige,an,ancona,andria-barletta-trani,andria-trani-barletta,andriabarlettatrani,andriatranibarletta,ao,aosta,aoste,ap,aq,aquila,ar,arezzo,ascoli-piceno,ascolipiceno,asti,at,av,avellino,ba,balsan-sudtirol,xn--balsan-sdtirol-nsb,balsan-suedtirol,balsan,bari,barletta-trani-andria,barlettatraniandria,belluno,benevento,bergamo,bg,bi,biella,bl,bn,bo,bologna,bolzano-altoadige,bolzano,bozen-sudtirol,xn--bozen-sdtirol-2ob,bozen-suedtirol,bozen,br,brescia,brindisi,bs,bt,bulsan-sudtirol,xn--bulsan-sdtirol-nsb,bulsan-suedtirol,bulsan,bz,ca,cagliari,caltanissetta,campidano-medio,campidanomedio,campobasso,carbonia-iglesias,carboniaiglesias,carrara-massa,carraramassa,caserta,catania,catanzaro,cb,ce,cesena-forli,xn--cesena-forl-mcb,cesenaforli,xn--cesenaforl-i8a,ch,chieti,ci,cl,cn,co,como,cosenza,cr,cremona,crotone,cs,ct,cuneo,cz,dell-ogliastra,dellogliastra,en,enna,fc,fe,fermo,ferrara,fg,fi,firenze,florence,fm,foggia,forli-cesena,xn--forl-cesena-fcb,forlicesena,xn--forlcesena-c8a,fr,frosinone,ge,genoa,genova,go,gorizia,gr,grosseto,iglesias-carbonia,iglesiascarbonia,im,imperia,is,isernia,kr,la-spezia,laquila,laspezia,latina,lc,le,lecce,lecco,li,livorno,lo,lodi,lt,lu,lucca,macerata,mantova,massa-carrara,massacarrara,matera,mb,mc,me,medio-campidano,mediocampidano,messina,mi,milan,milano,mn,mo,modena,monza-brianza,monza-e-della-brianza,monza,monzabrianza,monzaebrianza,monzaedellabrianza,ms,mt,na,naples,napoli,no,novara,nu,nuoro,og,ogliastra,olbia-tempio,olbiatempio,or,oristano,ot,pa,padova,padua,palermo,parma,pavia,pc,pd,pe,perugia,pesaro-urbino,pesarourbino,pescara,pg,pi,piacenza,pisa,pistoia,pn,po,pordenone,potenza,pr,prato,pt,pu,pv,pz,ra,ragusa,ravenna,rc,re,reggio-calabria,reggio-emilia,reggiocalabria,reggioemilia,rg,ri,rieti,rimini,rm,rn,ro,roma,rome,rovigo,sa,salerno,sassari,savona,si,siena,siracusa,so,sondrio,sp,sr,ss,suedtirol,xn--sdtirol-n2a,sv,ta,taranto,te,tempio-olbia,tempioolbia,teramo,terni,tn,to,torino,tp,tr,trani-andria-barletta,trani-barletta-andria,traniandriabarletta,tranibarlettaandria,trapani,trento,treviso,trieste,ts,turin,tv,ud,udine,urbino-pesaro,urbinopesaro,va,varese,vb,vc,ve,venezia,venice,verbania,vercelli,verona,vi,vibo-valentia,vibovalentia,vicenza,viterbo,vr,vs,vt,vv<je>co,net,org<jm>*<jo>com,org,net,edu,sch,gov,mil,name<jobs,jp>ac,ad,co,ed,go,gr,lg,ne,or,aichi>aisai,ama,anjo,asuke,chiryu,chita,fuso,gamagori,handa,hazu,hekinan,higashiura,ichinomiya,inazawa,inuyama,isshiki,iwakura,kanie,kariya,kasugai,kira,kiyosu,komaki,konan,kota,mihama,miyoshi,nishio,nisshin,obu,oguchi,oharu,okazaki,owariasahi,seto,shikatsu,shinshiro,shitara,tahara,takahama,tobishima,toei,togo,tokai,tokoname,toyoake,toyohashi,toyokawa,toyone,toyota,tsushima,yatomi<akita>akita,daisen,fujisato,gojome,hachirogata,happou,higashinaruse,honjo,honjyo,ikawa,kamikoani,kamioka,katagami,kazuno,kitaakita,kosaka,kyowa,misato,mitane,moriyoshi,nikaho,noshiro,odate,oga,ogata,semboku,yokote,yurihonjo<aomori>aomori,gonohe,hachinohe,hashikami,hiranai,hirosaki,itayanagi,kuroishi,misawa,mutsu,nakadomari,noheji,oirase,owani,rokunohe,sannohe,shichinohe,shingo,takko,towada,tsugaru,tsuruta<chiba>abiko,asahi,chonan,chosei,choshi,chuo,funabashi,futtsu,hanamigawa,ichihara,ichikawa,ichinomiya,inzai,isumi,kamagaya,kamogawa,kashiwa,katori,katsuura,kimitsu,kisarazu,kozaki,kujukuri,kyonan,matsudo,midori,mihama,minamiboso,mobara,mutsuzawa,nagara,nagareyama,narashino,narita,noda,oamishirasato,omigawa,onjuku,otaki,sakae,sakura,shimofusa,shirako,shiroi,shisui,sodegaura,sosa,tako,tateyama,togane,tohnosho,tomisato,urayasu,yachimata,yachiyo,yokaichiba,yokoshibahikari,yotsukaido<ehime>ainan,honai,ikata,imabari,iyo,kamijima,kihoku,kumakogen,masaki,matsuno,matsuyama,namikata,niihama,ozu,saijo,seiyo,shikokuchuo,tobe,toon,uchiko,uwajima,yawatahama<fukui>echizen,eiheiji,fukui,ikeda,katsuyama,mihama,minamiechizen,obama,ohi,ono,sabae,sakai,takahama,tsuruga,wakasa<fukuoka>ashiya,buzen,chikugo,chikuho,chikujo,chikushino,chikuzen,chuo,dazaifu,fukuchi,hakata,higashi,hirokawa,hisayama,iizuka,inatsuki,kaho,kasuga,kasuya,kawara,keisen,koga,kurate,kurogi,kurume,minami,miyako,miyama,miyawaka,mizumaki,munakata,nakagawa,nakama,nishi,nogata,ogori,okagaki,okawa,oki,omuta,onga,onojo,oto,saigawa,sasaguri,shingu,shinyoshitomi,shonai,soeda,sue,tachiarai,tagawa,takata,toho,toyotsu,tsuiki,ukiha,umi,usui,yamada,yame,yanagawa,yukuhashi<fukushima>aizubange,aizumisato,aizuwakamatsu,asakawa,bandai,date,fukushima,furudono,futaba,hanawa,higashi,hirata,hirono,iitate,inawashiro,ishikawa,iwaki,izumizaki,kagamiishi,kaneyama,kawamata,kitakata,kitashiobara,koori,koriyama,kunimi,miharu,mishima,namie,nango,nishiaizu,nishigo,okuma,omotego,ono,otama,samegawa,shimogo,shirakawa,showa,soma,sukagawa,taishin,tamakawa,tanagura,tenei,yabuki,yamato,yamatsuri,yanaizu,yugawa<gifu>anpachi,ena,gifu,ginan,godo,gujo,hashima,hichiso,hida,higashishirakawa,ibigawa,ikeda,kakamigahara,kani,kasahara,kasamatsu,kawaue,kitagata,mino,minokamo,mitake,mizunami,motosu,nakatsugawa,ogaki,sakahogi,seki,sekigahara,shirakawa,tajimi,takayama,tarui,toki,tomika,wanouchi,yamagata,yaotsu,yoro<gunma>annaka,chiyoda,fujioka,higashiagatsuma,isesaki,itakura,kanna,kanra,katashina,kawaba,kiryu,kusatsu,maebashi,meiwa,midori,minakami,naganohara,nakanojo,nanmoku,numata,oizumi,ora,ota,shibukawa,shimonita,shinto,showa,takasaki,takayama,tamamura,tatebayashi,tomioka,tsukiyono,tsumagoi,ueno,yoshioka<hiroshima>asaminami,daiwa,etajima,fuchu,fukuyama,hatsukaichi,higashihiroshima,hongo,jinsekikogen,kaita,kui,kumano,kure,mihara,miyoshi,naka,onomichi,osakikamijima,otake,saka,sera,seranishi,shinichi,shobara,takehara<hokkaido>abashiri,abira,aibetsu,akabira,akkeshi,asahikawa,ashibetsu,ashoro,assabu,atsuma,bibai,biei,bifuka,bihoro,biratori,chippubetsu,chitose,date,ebetsu,embetsu,eniwa,erimo,esan,esashi,fukagawa,fukushima,furano,furubira,haboro,hakodate,hamatonbetsu,hidaka,higashikagura,higashikawa,hiroo,hokuryu,hokuto,honbetsu,horokanai,horonobe,ikeda,imakane,ishikari,iwamizawa,iwanai,kamifurano,kamikawa,kamishihoro,kamisunagawa,kamoenai,kayabe,kembuchi,kikonai,kimobetsu,kitahiroshima,kitami,kiyosato,koshimizu,kunneppu,kuriyama,kuromatsunai,kushiro,kutchan,kyowa,mashike,matsumae,mikasa,minamifurano,mombetsu,moseushi,mukawa,muroran,naie,nakagawa,nakasatsunai,nakatombetsu,nanae,nanporo,nayoro,nemuro,niikappu,niki,nishiokoppe,noboribetsu,numata,obihiro,obira,oketo,okoppe,otaru,otobe,otofuke,otoineppu,oumu,ozora,pippu,rankoshi,rebun,rikubetsu,rishiri,rishirifuji,saroma,sarufutsu,shakotan,shari,shibecha,shibetsu,shikabe,shikaoi,shimamaki,shimizu,shimokawa,shinshinotsu,shintoku,shiranuka,shiraoi,shiriuchi,sobetsu,sunagawa,taiki,takasu,takikawa,takinoue,teshikaga,tobetsu,tohma,tomakomai,tomari,toya,toyako,toyotomi,toyoura,tsubetsu,tsukigata,urakawa,urausu,uryu,utashinai,wakkanai,wassamu,yakumo,yoichi<hyogo>aioi,akashi,ako,amagasaki,aogaki,asago,ashiya,awaji,fukusaki,goshiki,harima,himeji,ichikawa,inagawa,itami,kakogawa,kamigori,kamikawa,kasai,kasuga,kawanishi,miki,minamiawaji,nishinomiya,nishiwaki,ono,sanda,sannan,sasayama,sayo,shingu,shinonsen,shiso,sumoto,taishi,taka,takarazuka,takasago,takino,tamba,tatsuno,toyooka,yabu,yashiro,yoka,yokawa<ibaraki>ami,asahi,bando,chikusei,daigo,fujishiro,hitachi,hitachinaka,hitachiomiya,hitachiota,ibaraki,ina,inashiki,itako,iwama,joso,kamisu,kasama,kashima,kasumigaura,koga,miho,mito,moriya,naka,namegata,oarai,ogawa,omitama,ryugasaki,sakai,sakuragawa,shimodate,shimotsuma,shirosato,sowa,suifu,takahagi,tamatsukuri,tokai,tomobe,tone,toride,tsuchiura,tsukuba,uchihara,ushiku,yachiyo,yamagata,yawara,yuki<ishikawa>anamizu,hakui,hakusan,kaga,kahoku,kanazawa,kawakita,komatsu,nakanoto,nanao,nomi,nonoichi,noto,shika,suzu,tsubata,tsurugi,uchinada,wajima<iwate>fudai,fujisawa,hanamaki,hiraizumi,hirono,ichinohe,ichinoseki,iwaizumi,iwate,joboji,kamaishi,kanegasaki,karumai,kawai,kitakami,kuji,kunohe,kuzumaki,miyako,mizusawa,morioka,ninohe,noda,ofunato,oshu,otsuchi,rikuzentakata,shiwa,shizukuishi,sumita,tanohata,tono,yahaba,yamada<kagawa>ayagawa,higashikagawa,kanonji,kotohira,manno,marugame,mitoyo,naoshima,sanuki,tadotsu,takamatsu,tonosho,uchinomi,utazu,zentsuji<kagoshima>akune,amami,hioki,isa,isen,izumi,kagoshima,kanoya,kawanabe,kinko,kouyama,makurazaki,matsumoto,minamitane,nakatane,nishinoomote,satsumasendai,soo,tarumizu,yusui<kanagawa>aikawa,atsugi,ayase,chigasaki,ebina,fujisawa,hadano,hakone,hiratsuka,isehara,kaisei,kamakura,kiyokawa,matsuda,minamiashigara,miura,nakai,ninomiya,odawara,oi,oiso,sagamihara,samukawa,tsukui,yamakita,yamato,yokosuka,yugawara,zama,zushi<kochi>aki,geisei,hidaka,higashitsuno,ino,kagami,kami,kitagawa,kochi,mihara,motoyama,muroto,nahari,nakamura,nankoku,nishitosa,niyodogawa,ochi,okawa,otoyo,otsuki,sakawa,sukumo,susaki,tosa,tosashimizu,toyo,tsuno,umaji,yasuda,yusuhara<kumamoto>amakusa,arao,aso,choyo,gyokuto,kamiamakusa,kikuchi,kumamoto,mashiki,mifune,minamata,minamioguni,nagasu,nishihara,oguni,ozu,sumoto,takamori,uki,uto,yamaga,yamato,yatsushiro<kyoto>ayabe,fukuchiyama,higashiyama,ide,ine,joyo,kameoka,kamo,kita,kizu,kumiyama,kyotamba,kyotanabe,kyotango,maizuru,minami,minamiyamashiro,miyazu,muko,nagaokakyo,nakagyo,nantan,oyamazaki,sakyo,seika,tanabe,uji,ujitawara,wazuka,yamashina,yawata<mie>asahi,inabe,ise,kameyama,kawagoe,kiho,kisosaki,kiwa,komono,kumano,kuwana,matsusaka,meiwa,mihama,minamiise,misugi,miyama,nabari,shima,suzuka,tado,taiki,taki,tamaki,toba,tsu,udono,ureshino,watarai,yokkaichi<miyagi>furukawa,higashimatsushima,ishinomaki,iwanuma,kakuda,kami,kawasaki,marumori,matsushima,minamisanriku,misato,murata,natori,ogawara,ohira,onagawa,osaki,rifu,semine,shibata,shichikashuku,shikama,shiogama,shiroishi,tagajo,taiwa,tome,tomiya,wakuya,watari,yamamoto,zao<miyazaki>aya,ebino,gokase,hyuga,kadogawa,kawaminami,kijo,kitagawa,kitakata,kitaura,kobayashi,kunitomi,kushima,mimata,miyakonojo,miyazaki,morotsuka,nichinan,nishimera,nobeoka,saito,shiiba,shintomi,takaharu,takanabe,takazaki,tsuno<nagano>achi,agematsu,anan,aoki,asahi,azumino,chikuhoku,chikuma,chino,fujimi,hakuba,hara,hiraya,iida,iijima,iiyama,iizuna,ikeda,ikusaka,ina,karuizawa,kawakami,kiso,kisofukushima,kitaaiki,komagane,komoro,matsukawa,matsumoto,miasa,minamiaiki,minamimaki,minamiminowa,minowa,miyada,miyota,mochizuki,nagano,nagawa,nagiso,nakagawa,nakano,nozawaonsen,obuse,ogawa,okaya,omachi,omi,ookuwa,ooshika,otaki,otari,sakae,sakaki,saku,sakuho,shimosuwa,shinanomachi,shiojiri,suwa,suzaka,takagi,takamori,takayama,tateshina,tatsuno,togakushi,togura,tomi,ueda,wada,yamagata,yamanouchi,yasaka,yasuoka<nagasaki>chijiwa,futsu,goto,hasami,hirado,iki,isahaya,kawatana,kuchinotsu,matsuura,nagasaki,obama,omura,oseto,saikai,sasebo,seihi,shimabara,shinkamigoto,togitsu,tsushima,unzen<nara>ando,gose,heguri,higashiyoshino,ikaruga,ikoma,kamikitayama,kanmaki,kashiba,kashihara,katsuragi,kawai,kawakami,kawanishi,koryo,kurotaki,mitsue,miyake,nara,nosegawa,oji,ouda,oyodo,sakurai,sango,shimoichi,shimokitayama,shinjo,soni,takatori,tawaramoto,tenkawa,tenri,uda,yamatokoriyama,yamatotakada,yamazoe,yoshino<niigata>aga,agano,gosen,itoigawa,izumozaki,joetsu,kamo,kariwa,kashiwazaki,minamiuonuma,mitsuke,muika,murakami,myoko,nagaoka,niigata,ojiya,omi,sado,sanjo,seiro,seirou,sekikawa,shibata,tagami,tainai,tochio,tokamachi,tsubame,tsunan,uonuma,yahiko,yoita,yuzawa<oita>beppu,bungoono,bungotakada,hasama,hiji,himeshima,hita,kamitsue,kokonoe,kuju,kunisaki,kusu,oita,saiki,taketa,tsukumi,usa,usuki,yufu<okayama>akaiwa,asakuchi,bizen,hayashima,ibara,kagamino,kasaoka,kibichuo,kumenan,kurashiki,maniwa,misaki,nagi,niimi,nishiawakura,okayama,satosho,setouchi,shinjo,shoo,soja,takahashi,tamano,tsuyama,wake,yakage<okinawa>aguni,ginowan,ginoza,gushikami,haebaru,higashi,hirara,iheya,ishigaki,ishikawa,itoman,izena,kadena,kin,kitadaito,kitanakagusuku,kumejima,kunigami,minamidaito,motobu,nago,naha,nakagusuku,nakijin,nanjo,nishihara,ogimi,okinawa,onna,shimoji,taketomi,tarama,tokashiki,tomigusuku,tonaki,urasoe,uruma,yaese,yomitan,yonabaru,yonaguni,zamami<osaka>abeno,chihayaakasaka,chuo,daito,fujiidera,habikino,hannan,higashiosaka,higashisumiyoshi,higashiyodogawa,hirakata,ibaraki,ikeda,izumi,izumiotsu,izumisano,kadoma,kaizuka,kanan,kashiwara,katano,kawachinagano,kishiwada,kita,kumatori,matsubara,minato,minoh,misaki,moriguchi,neyagawa,nishi,nose,osakasayama,sakai,sayama,sennan,settsu,shijonawate,shimamoto,suita,tadaoka,taishi,tajiri,takaishi,takatsuki,tondabayashi,toyonaka,toyono,yao<saga>ariake,arita,fukudomi,genkai,hamatama,hizen,imari,kamimine,kanzaki,karatsu,kashima,kitagata,kitahata,kiyama,kouhoku,kyuragi,nishiarita,ogi,omachi,ouchi,saga,shiroishi,taku,tara,tosu,yoshinogari<saitama>arakawa,asaka,chichibu,fujimi,fujimino,fukaya,hanno,hanyu,hasuda,hatogaya,hatoyama,hidaka,higashichichibu,higashimatsuyama,honjo,ina,iruma,iwatsuki,kamiizumi,kamikawa,kamisato,kasukabe,kawagoe,kawaguchi,kawajima,kazo,kitamoto,koshigaya,kounosu,kuki,kumagaya,matsubushi,minano,misato,miyashiro,miyoshi,moroyama,nagatoro,namegawa,niiza,ogano,ogawa,ogose,okegawa,omiya,otaki,ranzan,ryokami,saitama,sakado,satte,sayama,shiki,shiraoka,soka,sugito,toda,tokigawa,tokorozawa,tsurugashima,urawa,warabi,yashio,yokoze,yono,yorii,yoshida,yoshikawa,yoshimi<shiga>aisho,gamo,higashiomi,hikone,koka,konan,kosei,koto,kusatsu,maibara,moriyama,nagahama,nishiazai,notogawa,omihachiman,otsu,ritto,ryuoh,takashima,takatsuki,torahime,toyosato,yasu<shimane>akagi,ama,gotsu,hamada,higashiizumo,hikawa,hikimi,izumo,kakinoki,masuda,matsue,misato,nishinoshima,ohda,okinoshima,okuizumo,shimane,tamayu,tsuwano,unnan,yakumo,yasugi,yatsuka<shizuoka>arai,atami,fuji,fujieda,fujikawa,fujinomiya,fukuroi,gotemba,haibara,hamamatsu,higashiizu,ito,iwata,izu,izunokuni,kakegawa,kannami,kawanehon,kawazu,kikugawa,kosai,makinohara,matsuzaki,minamiizu,mishima,morimachi,nishiizu,numazu,omaezaki,shimada,shimizu,shimoda,shizuoka,susono,yaizu,yoshida<tochigi>ashikaga,bato,haga,ichikai,iwafune,kaminokawa,kanuma,karasuyama,kuroiso,mashiko,mibu,moka,motegi,nasu,nasushiobara,nikko,nishikata,nogi,ohira,ohtawara,oyama,sakura,sano,shimotsuke,shioya,takanezawa,tochigi,tsuga,ujiie,utsunomiya,yaita<tokushima>aizumi,anan,ichiba,itano,kainan,komatsushima,matsushige,mima,minami,miyoshi,mugi,nakagawa,naruto,sanagochi,shishikui,tokushima,wajiki<tokyo>aaskmeofferscustomrulesd1hi,akiruno,akishima,aogashima,arakawa,bunkyo,chiyoda,chofu,chuo,edogawa,fuchu,fussa,hachijo,hachioji,hamura,higashikurume,higashimurayama,higashiyamato,hino,hinode,hinohara,inagi,itabashi,katsushika,kita,kiyose,kodaira,koganei,kokubunji,komae,koto,kouzushima,kunitachi,machida,meguro,minato,mitaka,mizuho,musashimurayama,musashino,nakano,nerima,ogasawara,okutama,ome,oshima,ota,setagaya,shibuya,shinagawa,shinjuku,suginami,sumida,tachikawa,taito,tama,toshima<tottori>chizu,hino,kawahara,koge,kotoura,misasa,nanbu,nichinan,sakaiminato,tottori,wakasa,yazu,yonago<toyama>asahi,fuchu,fukumitsu,funahashi,himi,imizu,inami,johana,kamiichi,kurobe,nakaniikawa,namerikawa,nanto,nyuzen,oyabe,taira,takaoka,tateyama,toga,tonami,toyama,unazuki,uozu,yamada<wakayama>arida,aridagawa,gobo,hashimoto,hidaka,hirogawa,inami,iwade,kainan,kamitonda,katsuragi,kimino,kinokawa,kitayama,koya,koza,kozagawa,kudoyama,kushimoto,mihama,misato,nachikatsuura,shingu,shirahama,taiji,tanabe,wakayama,yuasa,yura<yamagata>asahi,funagata,higashine,iide,kahoku,kaminoyama,kaneyama,kawanishi,mamurogawa,mikawa,murayama,nagai,nakayama,nanyo,nishikawa,obanazawa,oe,oguni,ohkura,oishida,sagae,sakata,sakegawa,shinjo,shirataka,shonai,takahata,tendo,tozawa,tsuruoka,yamagata,yamanobe,yonezawa,yuza<yamaguchi>abu,hagi,hikari,hofu,iwakuni,kudamatsu,mitou,nagato,oshima,shimonoseki,shunan,tabuse,tokuyama,toyota,ube,yuu<yamanashi>chuo,doshi,fuefuki,fujikawa,fujikawaguchiko,fujiyoshida,hayakawa,hokuto,ichikawamisato,kai,kofu,koshu,kosuge,minami-alps,minobu,nakamichi,nanbu,narusawa,nirasaki,nishikatsura,oshino,otsuki,showa,tabayama,tsuru,uenohara,yamanakako,yamanashi<xn--4pvxs,xn--vgu402c,xn--c3s14m,xn--f6qx53a,xn--8pvr4u,xn--uist22h,xn--djrs72d6uy,xn--mkru45i,xn--0trq7p7nn,xn--8ltr62k,xn--2m4a15e,xn--efvn9s,xn--32vp30h,xn--4it797k,xn--1lqs71d,xn--5rtp49c,xn--5js045d,xn--ehqz56n,xn--1lqs03n,xn--qqqt11m,xn--kbrq7o,xn--pssu33l,xn--ntsq17g,xn--uisz3g,xn--6btw5a,xn--1ctwo,xn--6orx2r,xn--rht61e,xn--rht27z,xn--djty4k,xn--nit225k,xn--rht3d,xn--klty5x,xn--kltx9a,xn--kltp7d,xn--uuwu58a,xn--zbx025d,xn--ntso0iqx3a,xn--elqq16h,xn--4it168d,xn--klt787d,xn--rny31h,xn--7t0a264c,xn--5rtq34k,xn--k7yn95e,xn--tor131o,xn--d5qv7z876c,kawasaki>*,!city<kitakyushu>*,!city<kobe>*,!city<nagoya>*,!city<sapporo>*,!city<sendai>*,!city<yokohama>*,!city<<ke>ac,co,go,info,me,mobi,ne,or,sc<kg>org,net,com,edu,gov,mil<kh>*<ki>edu,biz,net,org,gov,info,com<km>org,nom,gov,prd,tm,edu,mil,ass,com,coop,asso,presse,medecin,notaires,pharmaciens,veterinaire,gouv<kn>net,org,edu,gov<kp>com,edu,gov,org,rep,tra<kr>ac,co,es,go,hs,kg,mil,ms,ne,or,pe,re,sc,busan,chungbuk,chungnam,daegu,daejeon,gangwon,gwangju,gyeongbuk,gyeonggi,gyeongnam,incheon,jeju,jeonbuk,jeonnam,seoul,ulsan<kw>com,edu,emb,gov,ind,net,org<ky>edu,gov,com,org,net<kz>org,edu,net,gov,mil,com<la>int,net,info,edu,gov,per,com,org<lb>com,edu,gov,net,org<lc>com,net,co,org,edu,gov<li,lk>gov,sch,net,int,com,org,edu,ngo,soc,web,ltd,assn,grp,hotel,ac<lr>com,edu,gov,org,net<ls>ac,biz,co,edu,gov,info,net,org,sc<lt>gov<lu,lv>com,edu,gov,org,mil,id,net,asn,conf<ly>com,net,gov,plc,edu,sch,med,org,id<ma>co,net,gov,org,ac,press<mc>tm,asso<md,me>co,net,org,edu,ac,gov,its,priv<mg>org,nom,gov,prd,tm,edu,mil,com,co<mh,mil,mk>com,org,net,edu,gov,inf,name<ml>com,edu,gouv,gov,net,org,presse<mm>*<mn>gov,edu,org<mo>com,net,org,edu,gov<mobi,mp,mq,mr>gov<ms>com,edu,gov,net,org<mt>com,edu,net,org<mu>com,net,org,gov,ac,co,or<museum>academy,agriculture,air,airguard,alabama,alaska,amber,ambulance,american,americana,americanantiques,americanart,amsterdam,and,annefrank,anthro,anthropology,antiques,aquarium,arboretum,archaeological,archaeology,architecture,art,artanddesign,artcenter,artdeco,arteducation,artgallery,arts,artsandcrafts,asmatart,assassination,assisi,association,astronomy,atlanta,austin,australia,automotive,aviation,axis,badajoz,baghdad,bahn,bale,baltimore,barcelona,baseball,basel,baths,bauern,beauxarts,beeldengeluid,bellevue,bergbau,berkeley,berlin,bern,bible,bilbao,bill,birdart,birthplace,bonn,boston,botanical,botanicalgarden,botanicgarden,botany,brandywinevalley,brasil,bristol,british,britishcolumbia,broadcast,brunel,brussel,brussels,bruxelles,building,burghof,bus,bushey,cadaques,california,cambridge,can,canada,capebreton,carrier,cartoonart,casadelamoneda,castle,castres,celtic,center,chattanooga,cheltenham,chesapeakebay,chicago,children,childrens,childrensgarden,chiropractic,chocolate,christiansburg,cincinnati,cinema,circus,civilisation,civilization,civilwar,clinton,clock,coal,coastaldefence,cody,coldwar,collection,colonialwilliamsburg,coloradoplateau,columbia,columbus,communication,communications,community,computer,computerhistory,xn--comunicaes-v6a2o,contemporary,contemporaryart,convent,copenhagen,corporation,xn--correios-e-telecomunicaes-ghc29a,corvette,costume,countryestate,county,crafts,cranbrook,creation,cultural,culturalcenter,culture,cyber,cymru,dali,dallas,database,ddr,decorativearts,delaware,delmenhorst,denmark,depot,design,detroit,dinosaur,discovery,dolls,donostia,durham,eastafrica,eastcoast,education,educational,egyptian,eisenbahn,elburg,elvendrell,embroidery,encyclopedic,england,entomology,environment,environmentalconservation,epilepsy,essex,estate,ethnology,exeter,exhibition,family,farm,farmequipment,farmers,farmstead,field,figueres,filatelia,film,fineart,finearts,finland,flanders,florida,force,fortmissoula,fortworth,foundation,francaise,frankfurt,franziskaner,freemasonry,freiburg,fribourg,frog,funaskmeofferscustomrulesd1io,furniture,gallery,garden,gateway,geelvinck,gemological,geology,georgia,giessen,glas,glass,gorge,grandrapids,graz,guernsey,halloffame,hamburg,handson,harvestcelebration,hawaii,health,heimatunduhren,hellas,helsinki,hembygdsforbund,heritage,histoire,historical,historicalsociety,historichouses,historisch,historisches,history,historyofscience,horology,house,humanities,illustration,imageandsound,indian,indiana,indianapolis,indianmarket,intelligence,interactive,iraq,iron,isleofman,jamison,jefferson,jerusalem,jewelry,jewish,jewishart,jfk,journalism,judaica,judygarland,juedisches,juif,karate,karikatur,kids,koebenhavn,koeln,kunst,kunstsammlung,kunstunddesign,labor,labour,lajolla,lancashire,landes,lans,xn--lns-qla,larsson,lewismiller,lincoln,linz,living,livinghistory,localhistory,london,losangeles,louvre,loyalist,lucerne,luxembourg,luzern,mad,madrid,mallorca,manchester,mansion,mansions,manx,marburg,maritime,maritimo,maryland,marylhurst,media,medical,medizinhistorisches,meeres,memorial,mesaverde,michigan,midatlantic,military,mill,miners,mining,minnesota,missile,missoula,modern,moma,money,monmouth,monticello,montreal,moscow,motorcycle,muenchen,muenster,mulhouse,muncie,museet,museumcenter,museumvereniging,music,national,nationalfirearms,nationalheritage,nativeamerican,naturalhistory,naturalhistorymuseum,naturalsciences,nature,naturhistorisches,natuurwetenschappen,naumburg,naval,nebraska,neues,newhampshire,newjersey,newmexico,newport,newspaper,newyork,niepce,norfolk,north,nrw,nyc,nyny,oceanographic,oceanographique,omaha,online,ontario,openair,oregon,oregontrail,otago,oxford,pacific,paderborn,palace,paleo,palmsprings,panama,paris,pasadena,pharmacy,philadelphia,philadelphiaarea,philately,phoenix,photography,pilots,pittsburgh,planetarium,plantation,plants,plaza,portal,portland,portlligat,posts-and-telecommunications,preservation,presidio,press,project,public,pubol,quebec,railroad,railway,research,resistance,riodejaneiro,rochester,rockart,roma,russia,saintlouis,salem,salvadordali,salzburg,sandiego,sanfrancisco,santabarbara,santacruz,santafe,saskatchewan,satx,savannahga,schlesisches,schoenbrunn,schokoladen,school,schweiz,science,scienceandhistory,scienceandindustry,sciencecenter,sciencecenters,science-fiction,sciencehistory,sciences,sciencesnaturelles,scotland,seaport,settlement,settlers,shell,sherbrooke,sibenik,silk,ski,skole,society,sologne,soundandvision,southcarolina,southwest,space,spy,square,stadt,stalbans,starnberg,state,stateofdelaware,station,steam,steiermark,stjohn,stockholm,stpetersburg,stuttgart,suisse,surgeonshall,surrey,svizzera,sweden,sydney,tank,tcm,technology,telekommunikation,television,texas,textile,theater,time,timekeeping,topology,torino,touch,town,transport,tree,trolley,trust,trustee,uhren,ulm,undersea,university,usa,usantiques,usarts,uscountryestate,usculture,usdecorativearts,usgarden,ushistory,ushuaia,uslivinghistory,utah,uvic,valley,vantaa,versailles,viking,village,virginia,virtual,virtuel,vlaanderen,volkenkunde,wales,wallonie,war,washingtondc,watchandclock,watch-and-clock,western,westfalen,whaling,wildlife,williamsburg,windmill,workshop,york,yorkshire,yosemite,youth,zoological,zoology,xn--9dbhblg6di,xn--h1aegh<mv>aero,biz,com,coop,edu,gov,info,int,mil,museum,name,net,org,pro<mw>ac,biz,co,com,coop,edu,gov,int,museum,net,org<mx>com,org,gob,edu,net<my>biz,com,edu,gov,mil,name,net,org<mz>ac,adv,co,edu,gov,mil,net,org<na>info,pro,name,school,or,dr,us,mx,ca,in,cc,tv,ws,mobi,co,com,org<name,nc>asso,nom<ne,net,nf>com,net,per,rec,web,arts,firm,info,other,store<ng>com,edu,gov,i,mil,mobi,name,net,org,sch<ni>ac,biz,co,com,edu,gob,in,info,int,mil,net,nom,org,web<nl,no>fhs,vgs,fylkesbibl,folkebibl,museum,idrett,priv,mil,stat,dep,kommune,herad,aa>gs<ah>gs<bu>gs<fm>gs<hl>gs<hm>gs<jan-mayen>gs<mr>gs<nl>gs<nt>gs<of>gs<ol>gs<oslo>gs<rl>gs<sf>gs<st>gs<svalbard>gs<tm>gs<tr>gs<va>gs<vf>gs<akrehamn,xn--krehamn-dxa,algard,xn--lgrd-poac,arna,brumunddal,bryne,bronnoysund,xn--brnnysund-m8ac,drobak,xn--drbak-wua,egersund,fetsund,floro,xn--flor-jra,fredrikstad,hokksund,honefoss,xn--hnefoss-q1a,jessheim,jorpeland,xn--jrpeland-54a,kirkenes,kopervik,krokstadelva,langevag,xn--langevg-jxa,leirvik,mjondalen,xn--mjndalen-64a,mo-i-rana,mosjoen,xn--mosjen-eya,nesoddtangen,orkanger,osoyro,xn--osyro-wua,raholt,xn--rholt-mra,sandnessjoen,xn--sandnessjen-ogb,skedsmokorset,slattum,spjelkavik,stathelle,stavern,stjordalshalsen,xn--stjrdalshalsen-sqb,tananger,tranby,vossevangen,afjord,xn--fjord-lra,agdenes,al,xn--l-1fa,alesund,xn--lesund-hua,alstahaug,alta,xn--lt-liac,alaheadju,xn--laheadju-7ya,alvdal,amli,xn--mli-tla,amot,xn--mot-tla,andebu,andoy,xn--andy-ira,andasuolo,ardal,xn--rdal-poa,aremark,arendal,xn--s-1fa,aseral,xn--seral-lra,asker,askim,askvoll,askoy,xn--asky-ira,asnes,xn--snes-poa,audnedaln,aukra,aure,aurland,aurskog-holand,xn--aurskog-hland-jnb,austevoll,austrheim,averoy,xn--avery-yua,balestrand,ballangen,balat,xn--blt-elab,balsfjord,bahccavuotna,xn--bhccavuotna-k7a,bamble,bardu,beardu,beiarn,bajddar,xn--bjddar-pta,baidar,xn--bidr-5nac,berg,bergen,berlevag,xn--berlevg-jxa,bearalvahki,xn--bearalvhki-y4a,bindal,birkenes,bjarkoy,xn--bjarky-fya,bjerkreim,bjugn,bodo,xn--bod-2na,badaddja,xn--bdddj-mrabd,budejju,bokn,bremanger,bronnoy,xn--brnny-wuac,bygland,bykle,barum,xn--brum-voa,telemark>bo,xn--b-5ga<nordland>bo,xn--b-5ga,heroy,xn--hery-ira<bievat,xn--bievt-0qa,bomlo,xn--bmlo-gra,batsfjord,xn--btsfjord-9za,bahcavuotna,xn--bhcavuotna-s4a,dovre,drammen,drangedal,dyroy,xn--dyry-ira,donna,xn--dnna-gra,eid,eidfjord,eidsberg,eidskog,eidsvoll,eigersund,elverum,enebakk,engerdal,etne,etnedal,evenes,evenassi,xn--eveni-0qa01ga,evje-og-hornnes,farsund,fauske,fuossko,fuoisku,fedje,fet,finnoy,xn--finny-yua,fitjar,fjaler,fjell,flakstad,flatanger,flekkefjord,flesberg,flora,fla,xn--fl-zia,folldal,forsand,fosnes,frei,frogn,froland,frosta,frana,xn--frna-woa,froya,xn--frya-hra,fusa,fyresdal,forde,xn--frde-gra,gamvik,gangaviika,xn--ggaviika-8ya47h,gaular,gausdal,gildeskal,xn--gildeskl-g0a,giske,gjemnes,gjerdrum,gjerstad,gjesdal,gjovik,xn--gjvik-wua,gloppen,gol,gran,grane,granvin,gratangen,grimstad,grong,kraanghke,xn--kranghke-b0a,grue,gulen,hadsel,halden,halsa,hamar,hamaroy,habmer,xn--hbmer-xqa,hapmir,xn--hpmir-xqa,hammerfest,hammarfeasta,xn--hmmrfeasta-s4ac,haram,hareid,harstad,hasvik,aknoluokta,xn--koluokta-7ya57h,hattfjelldal,aarborte,haugesund,hemne,hemnes,hemsedal,more-og-romsdal>heroy,sande<xn--mre-og-romsdal-qqb>xn--hery-ira,sande<hitra,hjartdal,hjelmeland,hobol,xn--hobl-ira,hof,hol,hole,holmestrand,holtalen,xn--holtlen-hxa,hornindal,horten,hurdal,hurum,hvaler,hyllestad,hagebostad,xn--hgebostad-g3a,hoyanger,xn--hyanger-q1a,hoylandet,xn--hylandet-54a,ha,xn--h-2fa,ibestad,inderoy,xn--indery-fya,iveland,jevnaker,jondal,jolster,xn--jlster-bya,karasjok,karasjohka,xn--krjohka-hwab49j,karlsoy,galsa,xn--gls-elac,karmoy,xn--karmy-yua,kautokeino,guovdageaidnu,klepp,klabu,xn--klbu-woa,kongsberg,kongsvinger,kragero,xn--krager-gya,kristiansand,kristiansund,krodsherad,xn--krdsherad-m8a,kvalsund,rahkkeravju,xn--rhkkervju-01af,kvam,kvinesdal,kvinnherad,kviteseid,kvitsoy,xn--kvitsy-fya,kvafjord,xn--kvfjord-nxa,giehtavuoatna,kvanangen,xn--kvnangen-k0a,navuotna,xn--nvuotna-hwa,kafjord,xn--kfjord-iua,gaivuotna,xn--givuotna-8ya,larvik,lavangen,lavagis,loabat,xn--loabt-0qa,lebesby,davvesiida,leikanger,leirfjord,leka,leksvik,lenvik,leangaviika,xn--leagaviika-52b,lesja,levanger,lier,lierne,lillehammer,lillesand,lindesnes,lindas,xn--linds-pra,lom,loppa,lahppi,xn--lhppi-xqa,lund,lunner,luroy,xn--lury-ira,luster,lyngdal,lyngen,ivgu,lardal,lerdal,xn--lrdal-sra,lodingen,xn--ldingen-q1a,lorenskog,xn--lrenskog-54a,loten,xn--lten-gra,malvik,masoy,xn--msy-ula0h,muosat,xn--muost-0qa,mandal,marker,marnardal,masfjorden,meland,meldal,melhus,meloy,xn--mely-ira,meraker,xn--merker-kua,moareke,xn--moreke-jua,midsund,midtre-gauldal,modalen,modum,molde,moskenes,moss,mosvik,malselv,xn--mlselv-iua,malatvuopmi,xn--mlatvuopmi-s4a,namdalseid,aejrie,namsos,namsskogan,naamesjevuemie,xn--nmesjevuemie-tcba,laakesvuemie,nannestad,narvik,narviika,naustdal,nedre-eiker,akershus>nes<buskerud>nes<nesna,nesodden,nesseby,unjarga,xn--unjrga-rta,nesset,nissedal,nittedal,nord-aurdal,nord-fron,nord-odal,norddal,nordkapp,davvenjarga,xn--davvenjrga-y4a,nordre-land,nordreisa,raisa,xn--risa-5na,nore-og-uvdal,notodden,naroy,xn--nry-yla5g,notteroy,xn--nttery-byae,odda,oksnes,xn--ksnes-uua,oppdal,oppegard,xn--oppegrd-ixa,orkdal,orland,xn--rland-uua,orskog,xn--rskog-uua,orsta,xn--rsta-fra,hedmark>os,valer,xn--vler-qoa<hordaland>os<osen,osteroy,xn--ostery-fya,ostre-toten,xn--stre-toten-zcb,overhalla,ovre-eiker,xn--vre-eiker-k8a,oyer,xn--yer-zna,oygarden,xn--ygarden-p1a,oystre-slidre,xn--ystre-slidre-ujb,porsanger,porsangu,xn--porsgu-sta26f,porsgrunn,radoy,xn--rady-ira,rakkestad,rana,ruovat,randaberg,rauma,rendalen,rennebu,rennesoy,xn--rennesy-v1a,rindal,ringebu,ringerike,ringsaker,rissa,risor,xn--risr-ira,roan,rollag,rygge,ralingen,xn--rlingen-mxa,rodoy,xn--rdy-0nab,romskog,xn--rmskog-bya,roros,xn--rros-gra,rost,xn--rst-0na,royken,xn--ryken-vua,royrvik,xn--ryrvik-bya,rade,xn--rde-ula,salangen,siellak,saltdal,salat,xn--slt-elab,xn--slat-5na,samnanger,vestfold>sande<sandefjord,sandnes,sandoy,xn--sandy-yua,sarpsborg,sauda,sauherad,sel,selbu,selje,seljord,sigdal,siljan,sirdal,skaun,skedsmo,ski,skien,skiptvet,skjervoy,xn--skjervy-v1a,skierva,xn--skierv-uta,skjak,xn--skjk-soa,skodje,skanland,xn--sknland-fxa,skanit,xn--sknit-yqa,smola,xn--smla-hra,snillfjord,snasa,xn--snsa-roa,snoasa,snaase,xn--snase-nra,sogndal,sokndal,sola,solund,songdalen,sortland,spydeberg,stange,stavanger,steigen,steinkjer,stjordal,xn--stjrdal-s1a,stokke,stor-elvdal,stord,stordal,storfjord,omasvuotna,strand,stranda,stryn,sula,suldal,sund,sunndal,surnadal,sveio,svelvik,sykkylven,sogne,xn--sgne-gra,somna,xn--smna-gra,sondre-land,xn--sndre-land-0cb,sor-aurdal,xn--sr-aurdal-l8a,sor-fron,xn--sr-fron-q1a,sor-odal,xn--sr-odal-q1a,sor-varanger,xn--sr-varanger-ggb,matta-varjjat,xn--mtta-vrjjat-k7af,sorfold,xn--srfold-bya,sorreisa,xn--srreisa-q1a,sorum,xn--srum-gra,tana,deatnu,time,tingvoll,tinn,tjeldsund,dielddanuorri,tjome,xn--tjme-hra,tokke,tolga,torsken,tranoy,xn--trany-yua,tromso,xn--troms-zua,tromsa,romsa,trondheim,troandin,trysil,trana,xn--trna-woa,trogstad,xn--trgstad-r1a,tvedestrand,tydal,tynset,tysfjord,divtasvuodna,divttasvuotna,tysnes,tysvar,xn--tysvr-vra,tonsberg,xn--tnsberg-q1a,ullensaker,ullensvang,ulvik,utsira,vadso,xn--vads-jra,cahcesuolo,xn--hcesuolo-7ya35b,vaksdal,valle,vang,vanylven,vardo,xn--vard-jra,varggat,xn--vrggt-xqad,vefsn,vaapste,vega,vegarshei,xn--vegrshei-c0a,vennesla,verdal,verran,vestby,vestnes,vestre-slidre,vestre-toten,vestvagoy,xn--vestvgy-ixa6o,vevelstad,vik,vikna,vindafjord,volda,voss,varoy,xn--vry-yla5g,vagan,xn--vgan-qoa,voagat,vagsoy,xn--vgsy-qoa0j,vaga,xn--vg-yiab,ostfold>valer<xn--stfold-9xa>xn--vler-qoa<<np>*<nr>biz,info,gov,edu,org,net,com<nu,nz>ac,co,cri,geek,gen,govt,health,iwi,kiwi,maori,mil,xn--mori-qsa,net,org,parliament,school<om>co,com,edu,gov,med,museum,net,org,pro<onion,org,pa>ac,gob,com,org,sld,edu,net,ing,abo,med,nom<pe>edu,gob,nom,mil,org,com,net<pf>com,org,edu<pg>*<ph>com,net,org,gov,edu,ngo,mil,i<pk>com,net,edu,org,fam,biz,web,gov,gob,gok,gon,gop,gos,info<pl>com,net,org,aid,agro,atm,auto,biz,edu,gmina,gsm,info,mail,miasta,media,mil,nieruchomosci,nom,pc,powiat,priv,realestate,rel,sex,shop,sklep,sos,szkola,targi,tm,tourism,travel,turystyka,gov>ap,ic,is,us,kmpsp,kppsp,kwpsp,psp,wskr,kwp,mw,ug,um,umig,ugim,upow,uw,starostwo,pa,po,psse,pup,rzgw,sa,so,sr,wsa,sko,uzs,wiih,winb,pinb,wios,witd,wzmiuw,piw,wiw,griw,wif,oum,sdn,zp,uppo,mup,wuoz,konsulat,oirm<augustow,babia-gora,bedzin,beskidy,bialowieza,bialystok,bielawa,bieszczady,boleslawiec,bydgoszcz,bytom,cieszyn,czeladz,czest,dlugoleka,elblag,elk,glogow,gniezno,gorlice,grajewo,ilawa,jaworzno,jelenia-gora,jgora,kalisz,kazimierz-dolny,karpacz,kartuzy,kaszuby,katowice,kepno,ketrzyn,klodzko,kobierzyce,kolobrzeg,konin,konskowola,kutno,lapy,lebork,legnica,lezajsk,limanowa,lomza,lowicz,lubin,lukow,malbork,malopolska,mazowsze,mazury,mielec,mielno,mragowo,naklo,nowaruda,nysa,olawa,olecko,olkusz,olsztyn,opoczno,opole,ostroda,ostroleka,ostrowiec,ostrowwlkp,pila,pisz,podhale,podlasie,polkowice,pomorze,pomorskie,prochowice,pruszkow,przeworsk,pulawy,radom,rawa-maz,rybnik,rzeszow,sanok,sejny,slask,slupsk,sosnowiec,stalowa-wola,skoczow,starachowice,stargard,suwalki,swidnica,swiebodzin,swinoujscie,szczecin,szczytno,tarnobrzeg,tgory,turek,tychy,ustka,walbrzych,warmia,warszawa,waw,wegrow,wielun,wlocl,wloclawek,wodzislaw,wolomin,wroclaw,zachpomor,zagan,zarow,zgora,zgorzelec<pm,pn>gov,co,org,edu,net<post,pr>com,net,org,gov,edu,isla,pro,biz,info,name,est,prof,ac<pro>aaa,aca,acct,avocat,bar,cpa,eng,jur,law,med,recht<ps>edu,gov,sec,plo,com,org,net<pt>net,gov,org,edu,int,publ,com,nome<pw>co,ne,or,ed,go,belau<py>com,coop,edu,gov,mil,net,org<qa>com,edu,gov,mil,name,net,org,sch<re>asso,com,nom<ro>arts,com,firm,info,nom,nt,org,rec,store,tm,www<rs>ac,co,edu,gov,in,org<ru,rw>ac,co,coop,gov,mil,net,org<sa>com,net,org,gov,med,pub,edu,sch<sb>com,edu,gov,net,org<sc>com,gov,net,org,edu<sd>com,net,org,edu,med,tv,gov,info<se>a,ac,b,bd,brand,c,d,e,f,fh,fhsk,fhv,g,h,i,k,komforb,kommunalforbund,komvux,l,lanbib,m,n,naturbruksgymn,o,org,p,parti,pp,press,r,s,t,tm,u,w,x,y,z<sg>com,net,org,gov,edu,per<sh>com,net,gov,org,mil<si,sj,sk,sl>com,net,edu,gov,org<sm,sn>art,com,edu,gouv,org,perso,univ<so>com,edu,gov,me,net,org<sr,ss>biz,com,edu,gov,me,net,org,sch<st>co,com,consulado,edu,embaixada,mil,net,org,principe,saotome,store<su,sv>com,edu,gob,org,red<sx>gov<sy>edu,gov,net,mil,com,org<sz>co,ac,org<tc,td,tel,tf,tg,th>ac,co,go,in,mi,net,or<tj>ac,biz,co,com,edu,go,gov,int,mil,name,net,nic,org,test,web<tk,tl>gov<tm>com,co,org,net,nom,gov,mil,edu<tn>com,ens,fin,gov,ind,intl,nat,net,org,info,perso,tourism,edunet,rnrt,rns,rnu,mincom,agrinet,defense,turen<to>com,gov,net,org,edu,mil<tr>av,bbs,bel,biz,com,dr,edu,gen,gov,info,mil,k12,kep,name,net,org,pol,tel,tsk,tv,web,nc>gov<<tt>co,com,org,net,biz,info,pro,int,coop,jobs,mobi,travel,museum,aero,name,gov,edu<tv,tw>edu,gov,mil,com,net,org,idv,game,ebiz,club,xn--zf0ao64a,xn--uc0atv,xn--czrw28b<tz>ac,co,go,hotel,info,me,mil,mobi,ne,or,sc,tv<ua>com,edu,gov,in,net,org,cherkassy,cherkasy,chernigov,chernihiv,chernivtsi,chernovtsy,ck,cn,cr,crimea,cv,dn,dnepropetrovsk,dnipropetrovsk,donetsk,dp,if,ivano-frankivsk,kh,kharkiv,kharkov,kherson,khmelnitskiy,khmelnytskyi,kiev,kirovograd,km,kr,krym,ks,kv,kyiv,lg,lt,lugansk,lutsk,lv,lviv,mk,mykolaiv,nikolaev,od,odesa,odessa,pl,poltava,rivne,rovno,rv,sb,sebastopol,sevastopol,sm,sumy,te,ternopil,uz,uzhgorod,vinnica,vinnytsia,vn,volyn,yalta,zaporizhzhe,zaporizhzhia,zhitomir,zhytomyr,zp,zt<ug>co,or,ac,sc,go,ne,com,org<uk>ac,co,gov,ltd,me,net,nhs,org,plc,police,sch>*<<us>dni,fed,isa,kids,nsn,ak>k12,cc,lib<al>k12,cc,lib<ar>k12,cc,lib<as>k12,cc,lib<az>k12,cc,lib<ca>k12,cc,lib<co>k12,cc,lib<ct>k12,cc,lib<dc>k12,cc,lib<de>k12,cc<fl>k12,cc,lib<ga>k12,cc,lib<gu>k12,cc,lib<hi>cc,lib<ia>k12,cc,lib<id>k12,cc,lib<il>k12,cc,lib<in>k12,cc,lib<ks>k12,cc,lib<ky>k12,cc,lib<la>k12,cc,lib<ma>k12>pvt,chtr,paroch<cc,lib<md>k12,cc,lib<me>k12,cc,lib<mi>k12,cc,lib,ann-arbor,cog,dst,eaton,gen,mus,tec,washtenaw<mn>k12,cc,lib<mo>k12,cc,lib<ms>k12,cc,lib<mt>k12,cc,lib<nc>k12,cc,lib<nd>cc,lib<ne>k12,cc,lib<nh>k12,cc,lib<nj>k12,cc,lib<nm>k12,cc,lib<nv>k12,cc,lib<ny>k12,cc,lib<oh>k12,cc,lib<ok>k12,cc,lib<or>k12,cc,lib<pa>k12,cc,lib<pr>k12,cc,lib<ri>cc,lib<sc>k12,cc,lib<sd>cc,lib<tn>k12,cc,lib<tx>k12,cc,lib<ut>k12,cc,lib<vi>k12,cc,lib<vt>k12,cc,lib<va>k12,cc,lib<wa>k12,cc,lib<wi>k12,cc,lib<wv>cc<wy>k12,cc,lib<<uy>com,edu,gub,mil,net,org<uz>co,com,net,org<va,vc>com,net,org,gov,mil,edu<ve>arts,bib,co,com,e12,edu,firm,gob,gov,info,int,mil,net,nom,org,rar,rec,store,tec,web<vg,vi>co,com,k12,net,org<vn>com,net,org,edu,gov,int,ac,biz,info,name,pro,health<vu>com,edu,net,org<wf,ws>com,net,org,gov,edu<yt,xn--mgbaam7a8h,xn--y9a3aq,xn--54b7fta0cc,xn--90ae,xn--mgbcpq6gpa1a,xn--90ais,xn--fiqs8s,xn--fiqz9s,xn--lgbbat1ad8j,xn--wgbh1c,xn--e1a4c,xn--qxa6a,xn--mgbah1a3hjkrd,xn--node,xn--qxam,xn--j6w193g>xn--55qx5d,xn--wcvs22d,xn--mxtq1m,xn--gmqw5a,xn--od0alg,xn--uc0atv<xn--2scrj9c,xn--3hcrj9c,xn--45br5cyl,xn--h2breg3eve,xn--h2brj9c8c,xn--mgbgu82a,xn--rvc1e0am3e,xn--h2brj9c,xn--mgbbh1a,xn--mgbbh1a71e,xn--fpcrj9c3d,xn--gecrj9c,xn--s9brj9c,xn--45brj9c,xn--xkc2dl3a5ee0h,xn--mgba3a4f16a,xn--mgba3a4fra,xn--mgbtx2b,xn--mgbayh7gpa,xn--3e0b707e,xn--80ao21a,xn--q7ce6a,xn--fzc2c9e2c,xn--xkc2al3hye2a,xn--mgbc0a9azcg,xn--d1alf,xn--l1acc,xn--mix891f,xn--mix082f,xn--mgbx4cd0ab,xn--mgb9awbf,xn--mgbai9azgqp6j,xn--mgbai9a5eva00b,xn--ygbi2ammx,xn--90a3ac>xn--o1ac,xn--c1avg,xn--90azh,xn--d1at,xn--o1ach,xn--80au<xn--p1ai,xn--wgbl6a,xn--mgberp4a5d4ar,xn--mgberp4a5d4a87g,xn--mgbqly7c0a67fbc,xn--mgbqly7cvafr,xn--mgbpl2fh,xn--yfro4i67o,xn--clchc0ea0b2g2a9gcd,xn--ogbpf8fl,xn--mgbtf8fl,xn--o3cw4h>xn--12c1fe0br,xn--12co0c3b4eva,xn--h3cuzk1di,xn--o3cyx2a,xn--m3ch0j3a,xn--12cfi8ixb8l<xn--pgbs0dh,xn--kpry57d,xn--kprw13d,xn--nnx388a,xn--j1amh,xn--mgb2ddes,xxx,ye>com,edu,gov,net,mil,org<za>ac,agric,alt,co,edu,gov,grondar,law,mil,net,ngo,nic,nis,nom,org,school,tm,web<zm>ac,biz,co,com,edu,gov,info,mil,net,org,sch<zw>ac,co,gov,mil,org<aaa,aarp,abarth,abb,abbott,abbvie,abc,able,abogado,abudhabi,academy,accenture,accountant,accountants,aco,actor,aaskmeofferscustomrulesd1,ads,adult,aeg,aetna,afamilycompany,afl,africa,agakhan,agency,aig,airbus,airforce,airtel,akdn,alfaromeo,alibaba,alipay,allfinanz,allstate,ally,alsace,alstom,amazon,americanexpress,americanfamily,amex,amfam,amica,amsterdam,analytics,android,anquan,anz,aol,apartments,app,apple,aquarelle,arab,aramco,archi,army,art,arte,asda,associates,athleta,attorney,auction,audi,audible,audio,auspost,author,auto,autos,avianca,aws,axa,azure,baby,baidu,banamex,bananarepublic,band,bank,bar,barcelona,barclaycard,barclays,barefoot,bargains,baseball,basketball,bauhaus,bayern,bbc,bbt,bbva,bcg,bcn,beats,beauty,beer,bentley,berlin,best,bestbuy,bet,bharti,bible,bid,bike,bing,bingo,bio,black,blackfriday,blockbuster,blog,bloomberg,blue,bms,bmw,bnpparibas,boats,boehringer,bofa,bom,bond,boo,book,booking,bosch,bostik,boston,bot,boutique,box,bradesco,bridgestone,broadway,broker,brother,brussels,budapest,bugatti,build,builders,business,buy,buzz,bzh,cab,cafe,cal,call,calvinklein,cam,camera,camp,cancerresearch,canon,capetown,capital,capitalone,car,caravan,cards,care,career,careers,cars,casa,case,cash,casino,catering,catholic,cba,cbn,cbre,cbs,center,ceo,cern,cfa,cfd,chanel,channel,charity,chase,chat,cheap,chintai,christmas,chrome,church,cipriani,circle,cisco,citadel,citi,citic,city,cityeats,claims,cleaning,click,clinic,clinique,clothing,cloud,club,clubmed,coach,codes,coffee,college,cologne,comcast,commbank,community,company,compare,computer,comsec,condos,construction,consulting,contact,contractors,cooking,cookingchannel,cool,corsica,country,coupon,coupons,courses,cpa,credit,creditcard,creditunion,cricket,crown,crs,cruise,cruises,csc,cuisinella,cymru,cyou,dabur,dad,dance,data,date,dating,datsun,day,dclk,dds,deal,dealer,deals,degree,delivery,dell,deloitte,delta,democrat,dental,dentist,desi,design,dev,dhl,diamonds,diet,digital,direct,directory,discount,discover,dish,diy,dnp,docs,doctor,dog,domains,dot,download,drive,dtv,dubai,duck,dunlop,dupont,durban,dvag,dvr,earth,eat,eco,edeka,education,email,emerck,energy,engineer,engineering,enterprises,epson,equipment,ericsson,erni,esq,estate,etisalat,eurovision,eus,events,exchange,expert,exposed,express,extraspace,fage,fail,fairwinds,faith,family,fan,fans,farm,farmers,fashion,fast,fedex,feedback,ferrari,ferrero,fiat,fidelity,fido,film,final,finance,financial,fire,firestone,firmdale,fish,fishing,fit,fitness,flickr,flights,flir,florist,flowers,fly,foo,food,foodnetwork,football,ford,forex,forsale,forum,foundation,fox,free,fresenius,frl,frogans,frontdoor,frontier,ftr,fujitsu,fun,fund,furniture,futbol,fyi,gal,gallery,gallo,gallup,game,games,gap,garden,gay,gbiz,gdn,gea,gent,genting,george,ggee,gift,gifts,gives,giving,glade,glass,gle,global,globo,gmail,gmbh,gmo,gmx,godaddy,bronze,bronzepoint,golf,goo,goodyear,goog,google,gop,got,grainger,graphics,gratis,green,gripe,grocery,group,guardian,gucci,guge,guide,guitars,guru,hair,hamburg,hangout,haus,hbo,hdfc,hdfcbank,health,healthcare,help,helsinki,here,hermes,hgtv,hiphop,hisamitsu,hitachi,hiv,hkt,hockey,holdings,holiday,homedepot,homegoods,homes,homesense,honda,horse,hospital,host,hosting,hot,hoteles,hotels,hotmail,house,how,hsbc,hughes,hyatt,hyundai,ibm,icbc,ice,icu,ieee,ifm,ikano,imamat,imdb,immo,immobilien,inc,industries,infiniti,ing,ink,institute,insurance,insure,international,intuit,investments,ipiranga,irish,ismaili,ist,istanbul,itau,itv,jaguar,java,jcb,jeep,jetzt,jewelry,jio,jll,jmp,jnj,joburg,jot,joy,jpmorgan,jprs,juegos,juniper,kaufen,kddi,kerryhotels,kerrylogistics,kerryproperties,kfh,kia,kids,kim,kinder,kindle,kitchen,kiwi,koeln,komatsu,kosher,kpmg,kpn,krd,kred,kuokgroup,kyoto,lacaixa,lamborghini,lamer,lancaster,lancia,land,landrover,lanxess,lasalle,lat,latino,latrobe,law,lawyer,lds,lease,leclerc,lefrak,legal,lego,lexus,lgbt,lidl,life,lifeinsurance,lifestyle,lighting,like,lilly,limited,limo,lincoln,linde,link,lipsy,live,living,lixil,llc,llp,loan,loans,locker,locus,loft,lol,london,lotte,lotto,love,lpl,lplfinancial,ltd,ltda,lundbeck,luxe,luxury,macys,madrid,maif,maison,makeup,man,management,mango,map,market,marketing,markets,marriott,marshalls,maserati,mattel,mba,mckinsey,med,media,meet,melbourne,meme,memorial,men,menu,merckmsd,miami,microsoft,mini,mint,mit,mitsubishi,mlb,mls,mma,mobile,moda,moe,moi,mom,monash,money,monster,mormon,mortgage,moscow,moto,motorcycles,mov,movie,msd,mtn,mtr,music,mutual,nab,nagoya,natura,navy,nba,nec,netbank,netflix,network,neustar,new,news,next,nextdirect,nexus,nfl,ngo,nhk,nico,nike,nikon,ninja,nissan,nissay,nokia,northwesternmutual,norton,now,nowruz,nowtv,nra,nrw,ntt,nyc,obi,observer,off,office,okinawa,olayan,olayangroup,oldnavy,ollo,omega,one,ong,onl,online,ooo,open,oracle,orange,organic,origins,osaka,otsuka,ott,ovh,page,panasonic,paris,pars,partners,parts,party,passagens,pay,pccw,pet,pfizer,pharmacy,phd,philips,phone,photo,photography,photos,physio,pics,pictet,pictures,pid,pin,ping,pink,pioneer,pizza,place,play,playstation,plumbing,plus,pnc,pohl,poker,politie,porn,pramerica,praxi,press,prime,prod,productions,prof,progressive,promo,properties,property,protection,pru,prudential,pub,pwc,qpon,quebec,quest,qvc,racing,radio,raid,read,realestate,realtor,realty,quantummeshs,red,redstone,redumbrella,rehab,reise,reisen,reit,reliance,ren,rent,rentals,repair,report,republican,rest,restaurant,review,reviews,rexroth,rich,richardli,ricoh,ril,rio,rip,rmit,rocher,rocks,rodeo,rogers,room,rsvp,rugby,ruhr,run,rwe,ryukyu,saarland,safe,safety,sakura,sale,salon,samsclub,samsung,sandvik,sandvikcoromant,sanofi,sap,sarl,sas,save,saxo,sbi,sbs,sca,scb,schaeffler,schmidt,scholarships,school,schule,schwarz,science,scjohnson,scot,search,seat,secure,security,seek,select,sener,services,ses,seven,sew,sex,sexy,sfr,shangrila,sharp,shaw,shell,shia,shiksha,shoes,shop,shopping,shouji,show,showtime,silk,sina,singles,site,ski,skin,sky,skype,sling,smart,smile,sncf,soccer,social,softbank,software,sohu,solar,solutions,song,sony,soy,spa,space,sport,spot,srl,stada,staples,star,statebank,statefarm,stc,stcgroup,stockholm,storage,store,stream,studio,study,style,sucks,supplies,supply,support,surf,surgery,suzuki,swatch,swiftcover,swiss,sydney,systems,tab,taipei,talk,taobao,target,tatamotors,tatar,tattoo,tax,taxi,tci,tdk,team,tech,technology,temasek,tennis,teva,thd,theater,theatre,tiaa,tickets,tienda,tiffany,tips,tires,tirol,tjmaxx,tjx,tkmaxx,tmall,today,tokyo,tools,top,toray,toshiba,total,tours,town,toyota,toys,trade,trading,training,travel,travelchannel,travelers,travelersinsurance,trust,trv,tube,tui,tunes,tushu,tvs,ubank,ubs,unicom,university,uno,uol,ups,vacations,vana,vanguard,vegas,ventures,verisign,versicherung,vet,viajes,video,vig,viking,villas,vin,vip,virgin,visa,vision,viva,vivo,vlaanderen,vodka,volkswagen,volvo,vote,voting,voto,voyage,vuelos,wales,walmart,walter,wang,wanggou,watch,watches,weather,weatherchannel,webcam,weber,website,wedding,weibo,weir,whoswho,wien,wiki,williamhill,win,windows,wine,winners,wme,wolterskluwer,woodside,work,works,world,wow,wtc,wtf,xbox,xerox,xfinity,xihuan,xin,xn--11b4c3d,xn--1ck2e1b,xn--1qqw23a,xn--30rr7y,xn--3bst00m,xn--3ds443g,xn--3oq18vl8pn36a,xn--3pxu8k,xn--42c2d9a,xn--45q11c,xn--4gbrim,xn--55qw42g,xn--55qx5d,xn--5su34j936bgsg,xn--5tzm5g,xn--6frz82g,xn--6qq986b3xl,xn--80adxhks,xn--80aqecdr1a,xn--80asehdb,xn--80aswg,xn--8y0a063a,xn--9dbq2a,xn--9et52u,xn--9krt00a,xn--b4w605ferd,xn--bck1b9a5dre4c,xn--c1avg,xn--c2br7g,xn--cck2b3b,xn--cckwcxetd,xn--cg4bki,xn--czr694b,xn--czrs0t,xn--czru2d,xn--d1acj3b,xn--eckvdtc9d,xn--efvy88h,xn--fct429k,xn--fhbei,xn--fiq228c5hs,xn--fiq64b,xn--fjq720a,xn--flw351e,xn--fzys8d69uvgm,xn--g2xx48c,xn--gckr3f0f,xn--gk3at1e,xn--hxt814e,xn--i1b6b1a6a2e,xn--imr513n,xn--io0a7i,xn--j1aef,xn--jlq480n2rg,xn--jlq61u9w7b,xn--jvr189m,xn--kcrx77d1x4a,xn--kput3i,xn--mgba3a3ejt,xn--mgba7c0bbn0a,xn--mgbaakc7dvf,xn--mgbab2bd,xn--mgbca7dzdo,xn--mgbi4ecexp,xn--mgbt3dhd,xn--mk1bu44c,xn--mxtq1m,xn--ngbc5azd,xn--ngbe9e0a,xn--ngbrx,xn--nqv7f,xn--nqv7fs00ema,xn--nyqy26a,xn--otu796d,xn--p1acf,xn--pssy2u,xn--q9jyb4c,xn--qcka1pmc,xn--rhqv96g,xn--rovu88b,xn--ses554g,xn--t60b56a,xn--tckwe,xn--tiq49xqyj,xn--unup4y,xn--vermgensberater-ctb,xn--vermgensberatung-pwb,xn--vhquv,xn--vuq861b,xn--w4r85el8fhu5dnra,xn--w4rs40l,xn--xhq521b,xn--zfr164b,xyz,yachts,yahoo,yamaxun,yandex,yodobashi,yoga,yokohama,you,youtube,yun,zappos,zara,zero,zip,zone,zuerich"
              )),
          ($ =
            null != $
              ? $
              : M(
                  "ua>cc,inf,ltd,cx,biz,co,pp,v<to>611,oya,rdv,vpnplus,quickconnect>direct<nyan<us>graphox,cloudns,drud,is-by,land-4-sale,stuff-4-sale,enscaled>phx<mircloud,freeddns,golffan,noip,pointto,platterp,de>lib<<com>devcdnaccesso>*<adobeaemcloud>dev>*<<kasserver,amazonaws>compute>*<compute-1>*<us-east-1>dualstack>s3<<elb>*<s3,s3-ap-northeast-1,s3-ap-northeast-2,s3-ap-south-1,s3-ap-southeast-1,s3-ap-southeast-2,s3-ca-central-1,s3-eu-central-1,s3-eu-west-1,s3-eu-west-2,s3-eu-west-3,s3-external-1,s3-fips-us-gov-west-1,s3-sa-east-1,s3-us-gov-west-1,s3-us-east-2,s3-us-west-1,s3-us-west-2,ap-northeast-2>s3,dualstack>s3<s3-website<ap-south-1>s3,dualstack>s3<s3-website<ca-central-1>s3,dualstack>s3<s3-website<eu-central-1>s3,dualstack>s3<s3-website<eu-west-2>s3,dualstack>s3<s3-website<eu-west-3>s3,dualstack>s3<s3-website<us-east-2>s3,dualstack>s3<s3-website<ap-northeast-1>dualstack>s3<<ap-southeast-1>dualstack>s3<<ap-southeast-2>dualstack>s3<<eu-west-1>dualstack>s3<<sa-east-1>dualstack>s3<<s3-website-us-east-1,s3-website-us-west-1,s3-website-us-west-2,s3-website-ap-northeast-1,s3-website-ap-southeast-1,s3-website-ap-southeast-2,s3-website-eu-west-1,s3-website-sa-east-1<elasticbeanstalk>ap-northeast-1,ap-northeast-2,ap-northeast-3,ap-south-1,ap-southeast-1,ap-southeast-2,ca-central-1,eu-central-1,eu-west-1,eu-west-2,eu-west-3,sa-east-1,us-east-1,us-east-2,us-gov-west-1,us-west-1,us-west-2<awsglobalaccelerator,appspacehosted,appspaceusercontent,on-aptible,myasustor,balena-devices,betainabox,boutir,bplaced,cafjs,br,cn,de,eu,jpn,mex,ru,sa,uk,us,za,ar,gb,hu,kr,no,qc,uy,africa,gr,co,jdevcloud,wpdevcloud,cloudcontrolled,cloudcontrolapp,trycloudflare,customer-oci>*,oci>*<ocp>*<ocs>*<<dattolocal,dattorelay,dattoweb,mydatto,builtwithdark,datadetect>demo,instance<ddns5,drayddns,dreamhosters,mydrobo,dyndns-at-home,dyndns-at-work,dyndns-blog,dyndns-free,dyndns-home,dyndns-ip,dyndns-mail,dyndns-office,dyndns-pics,dyndns-remote,dyndns-server,dyndns-web,dyndns-wiki,dyndns-work,blogdns,cechire,dnsalias,dnsdojo,doesntexist,dontexist,doomdns,dyn-o-saur,dynalias,est-a-la-maison,est-a-la-masion,est-le-patron,est-mon-blogueur,from-ak,from-al,from-ar,from-ca,from-ct,from-dc,from-de,from-fl,from-ga,from-hi,from-ia,from-id,from-il,from-in,from-ks,from-ky,from-ma,from-md,from-mi,from-mn,from-mo,from-ms,from-mt,from-nc,from-nd,from-ne,from-nh,from-nj,from-nm,from-nv,from-oh,from-ok,from-or,from-pa,from-pr,from-ri,from-sc,from-sd,from-tn,from-tx,from-ut,from-va,from-vt,from-wa,from-wi,from-wv,from-wy,getmyip,gotdns,hobby-site,homelinux,homeunix,iamallama,is-a-anarchist,is-a-blogger,is-a-bookkeeper,is-a-bulls-fan,is-a-caterer,is-a-chef,is-a-conservative,is-a-cpa,is-a-cubicle-slave,is-a-democrat,is-a-designer,is-a-doctor,is-a-financialadvisor,is-a-geek,is-a-green,is-a-guru,is-a-hard-worker,is-a-hunter,is-a-landscaper,is-a-lawyer,is-a-liberal,is-a-libertarian,is-a-llama,is-a-musician,is-a-nascarfan,is-a-nurse,is-a-painter,is-a-personaltrainer,is-a-photographer,is-a-player,is-a-republican,is-a-rockstar,is-a-socialist,is-a-student,is-a-teacher,is-a-techie,is-a-therapist,is-an-accountant,is-an-actor,is-an-actress,is-an-anarchist,is-an-artist,is-an-engineer,is-an-entertainer,is-certified,is-gone,is-into-anime,is-into-cars,is-into-cartoons,is-into-games,is-leet,is-not-certified,is-slick,is-uberleet,is-with-theband,isa-geek,isa-hockeynut,issmarterthanyou,likes-pie,likescandy,neat-url,saves-the-whales,selfip,sells-for-less,sells-for-u,servebbs,simple-url,space-to-rent,teaches-yoga,writesthisblog,ddnsfree,ddnsgeek,giize,gleeze,kozow,loseyourip,ooguy,theworkpc,elluciancrmadvance,elluciancrmadvise,elluciancrmrecruit,mytuleap,tuleap-partners,evennode>eu-1,eu-2,eu-3,eu-4,us-1,us-2,us-3,us-4<onfabrica,fbsbx>apps<fastly-terrarium,fastvps-server,mydobiss,firebaseapp,forgeblocks,framercanvas,freebox-os,freeboxos,freemyip,gentapps,gentlentapis,githubusercontent,0emm>*<appspot>r>*<<codespot,googleapis,googlecode,pagespeedmobilizer,publishproxy,withgoogle,withyoutube,blogspot,awsmppl,herokuapp,herokussl,myravendb,impertrixcdn,impertrix,smushcdn,wphostedmail,wpmucdn,pixolino,amscompute,clicketcloud,dopaas,hidora,hosted-by-previder>paas<hosteur>rag-cloud,rag-cloud-ch<ik-server>jcloud,jcloud-ver-jpc<jelastic>demo<kilatiron,massivegrid>paas<wafaicloud>jed,lon,ryd<joyent>cns>*<<lpusercontent,lmpm>app<linode>members,nodebalancer>*<<linodeobjects>*<barsycenter,barsyonline,mazeplay,miniserver,meteorapp>eu<hostedpi,mythic-beasts>customer,caracal,fentiger,lynx,ocelot,oncilla,onza,sphinx,vs,x,yali<4u,nfshost,001www,ddnslive,myiphost,blogsyte,ciscofreak,damnserver,ditchyourip,dnsiskinky,dynns,geekgalaxy,health-carereform,homesecuritymac,homesecuritypc,myactivedirectory,mysecuritycamera,net-freaks,onthewifi,point2this,quicksytes,securitytactics,serveexchange,servehumour,servep2p,servesarcasm,stufftoread,unusualperson,workisboring,3utilities,ddnsking,myvnc,servebeer,servecounterstrike,serveftp,servegame,servehalflife,servehttp,serveirc,servemp3,servepics,servequake,observableusercontent>static<orsites,operaunite,authgear-staging,authgearapps,skygearapp,outsystemscloud,ownprovider,pgfog,pagefrontapp,pagexl,paywhirl>*<gotpantheon,platter-app,pleskns,postman-echo,prgmr>xen<pythonanywhere>eu<qualifioapp,qbuser,qa2,dev-myqnapcloud,alpha-myqnapcloud,myqnapcloud,quipelements>*<rackmaze,rhcloud,render>app<onrender,logoip,scrysec,firewall-gateway,myshopblocks,myshopify,shopitsite,1kapp,appchizi,applinzi,sinaapp,vipsinaapp,bounty-full>alpha,beta<try-snowplow,stackhero-network,playstation-cloud,myspreadshop,stdlib>api<temp-dns,dsmynas,familyds,reservd,thingdustdata,bloxcms,townnews-staging,hk,wafflecell,idnblogger,indowapblog,reserve-online,hotelwithflight,remotewd,wiardweb>pages<woltlab-demo,wpenginepowered>js<wixsite,xnbay>u2,u2-local<yolasite<live>hlx<net>adobeaemcloud,alwaysdata,cloudfront,t3l3p0rt,appudo,atlassian-dev>prod>cdn<<myfritz,onavstack,blackbaudcdn,boomla,bplaced,square7,gb,hu,jp,se,uk,in,clic2000,clickrising,clouaskmeofferscustomrulesd1cess,cdn77-ssl,cdn77>r<feste-ip,knx-server,static-access,cryptonomic>*<dattolocal,mydatto,debian,bitbridge,at-band-camp,blogdns,broke-it,buyshouses,dnsalias,dnsdojo,does-it,dontexist,dynalias,dynathome,endofinternet,from-az,from-co,from-la,from-ny,gets-it,ham-radio-op,homeftp,homeip,homelinux,homeunix,in-the-band,is-a-chef,is-a-geek,isa-geek,kicks-ass,office-on-the,podzone,scrapper-site,selfip,sells-it,servebbs,serveftp,thruhere,webhop,definima,casacam,dynu,dynv6,twmail,ru,channelsdvr>u<fastlylb>map<fastly>freetls,map,prod>a,global<ssl>a,b,global<<edgeapp,flynnhosting,cdn-edges,cloudfunctions,moonscale,in-dsl,in-vpn,ipifony,iobb,cloudjiffy>fra1-de,west1-us<elastx>jls-sto1,jls-sto2,jls-sto3<faststacks,massivegrid>paas>fr-1,lon-1,lon-2,ny-1,ny-2,sg-1<<saveincloud>jelastic,nordeste-idc<scaleforce>j<tsukaeru>jelastic<kinghost,uni5,krellian,barsy,memset,azurewebsites,azure-mobile,cloudapp,azurestaticapps>centralus,eastasia,eastus2,westeurope,westus2<dnsup,hicam,now-dns,ownip,vpndns,eating-organic,mydissent,myeffect,mymediapc,mypsx,mysecuritycamera,nhlfan,no-ip,pgafan,privatizehealthinsurance,bounceme,ddns,redirectme,serveblog,serveminecraft,sytes,cloudycluster,ovh>webpaas>*<hosting>*<<bar0,bar1,bar2,rackmaze,schokokeks,firewall-gateway,seidat,senseering,siteleaf,vps-host>jelastic>atl,njs,ric<<myspreadshop,srcf>soc,user<supabase,dsmynas,familyds,torproject>pages<fastblog,reserve-online,community-pro,meinforum,yandexcloud>storage,website<za<page>hlx,hlx3,pdns,plesk,prvcy,magnet<pl>beep,ecommerce-shop,shoparena,homesklep,sdscloud,unicloud,krasnik,leczna,lubartow,lublin,poniatowa,swidnik,co,art,gliwice,krakow,poznan,wroc,zakopane,myspreadshop,gda,gdansk,gdynia,med,sopot<ca>barsy,awdev>*<co,blogspot,no-ip,myspreadshop<estate>compute>*<<network>alces>*<co,arvo,azimuth,tlon<org>altervista,amune>tele<pimienta,poivron,potager,sweetpepper,ae,us,certmgr,cdn77>c,rsc<cdn77-secure>origin>ssl<<cloudns,duckdns,tunk,dyndns>go,home<blogdns,blogsite,boldlygoingnowhere,dnsalias,dnsdojo,doesntexist,dontexist,doomdns,dvrdns,dynalias,endofinternet,endoftheinternet,from-me,game-host,gotdns,hobby-site,homedns,homeftp,homelinux,homeunix,is-a-bruinsfan,is-a-candidate,is-a-celticsfan,is-a-chef,is-a-geek,is-a-knight,is-a-linux-user,is-a-patsfan,is-a-soxfan,is-found,is-lost,is-saved,is-very-bad,is-very-evil,is-very-good,is-very-nice,is-very-sweet,isa-geek,kicks-ass,misconfused,podzone,readmyblog,selfip,sellsyourhome,servebbs,serveftp,servegame,stuff-4-sale,webhop,ddnss,accesscam,camdvr,freeddns,mywire,webredirect,eu>al,asso,at,au,be,bg,ca,cd,ch,cn,cy,cz,de,dk,edu,ee,es,fi,fr,gr,hr,hu,ie,il,in,int,is,it,jp,kr,lt,lu,lv,mc,me,mk,mt,my,net,ng,nl,no,nz,paris,pl,pt,q-a,ro,ru,se,si,sk,tr,uk,us<twmail,fedorainfracloud,fedorapeople,fedoraproject>cloud,os>app<stg>os>app<<<freedesktop,hepforge,in-dsl,in-vpn,js,barsy,mayfirst,mozilla-iot,bmoattachments,dynserv,now-dns,cable-modem,collegefan,couchpotatofries,mlbfan,mysecuritycamera,nflfan,read-books,ufcfan,hopto,myftp,no-ip,zapto,httpbin,pubtls,my-firewall,myfirewall,spdns,small-web,dsmynas,familyds,edugit,tuxfamily,diskstation,hk,wmflabs,toolforge,wmcloud,za<cn>com>amazonaws>compute>*<eb>cn-north-1,cn-northwest-1<elb>*<cn-north-1>s3<<<instantcloud<nl>amsw,virtueeldomein,co,hosting-cluster,blogspot,khplay,myspreadshop,transurl>*<cistron,demon<io>apigee,b-data,backplaneapp,banzaicloud>app,backyards>*<<bitbucket,bluebite,boxfuse,browsersafetymark,bigv>uk0<cleverapps,dappnode>dyndns<dedyn,drud,definima,fh-muenster,shw,forgerock>id<ghost,github,gitlab,lolipop,hasura-app,hostyhosting,moonscale>*<beebyte>paas<beebyteapp>sekd1<jele,unispace>cloud-fr1<webthings,loginline,barsy,azurecontainer>*<ngrok,nodeart>stage<nodum,nid,pantheonsite,dyn53,pstmn>mock<protonet,qoto,qcx>sys>*<<vaporcloud,vbrplsbx>g<on-k3s>*<on-rio>*<readthedocs,resindevice,resinstaging>devices<hzc,sandcats,shiftcrypto,shiftedit,mo-siemens,lair>apps<stolos>*<spacekit,utwente,s5y>*<telebit,thingdust>dev>cust,reservd<disrec>cust,reservd<prod>cust<testing>cust,reservd<<2038,wedeploy,editorx,basicserver,virtualserver<jp>ne>aseinet>user<gehirn<usercontent,blogspot<vc>gv>d<0e<eus>party>user<<ws>advisor>*<cloud66,dyndns,mypets<ba>rs,blogspot<cloud>banzai>*<elementor,statics>*<axarnet>es-1<diadem,jelastic>vip<jele,jenv-aruba>aruba>eur>it1<<it1<keliweb>cs<oxa>tn,uk<primetel>uk<reclaim>ca,uk,us<trendhosting>ch,de<jotelulu,kuleuven,linkyard,magentosite>*<perspecta,vapor,on-rancher>*<sensiosite>*<trafficplex,urown,voorloper<la>bnr,c<je>of<ch>square7,blogspot,flow>ae>alp1<appengine<linkyard-cloud,dnsking,gotdns,myspreadshop,firenet>*,svc>*<<12hp,2ix,4lima,lima-city<de>bplaced,square7,com,cosidns>dyn<dynamisches-dns,dnsupdater,internet-dns,l-o-g-i-n,dnshome,fuettertdasnetz,isteingeek,istmein,lebtimnetz,leitungsen,traeumtgerade,ddnss>dyn,dyndns<dyndns1,dyn-ip24,home-webserver>dyn<myhome-server,frusky>*<goip,blogspot,xn--gnstigbestellen-zvb,xn--gnstigliefern-wob,hs-heilbronn>it>pages<<dyn-berlin,in-berlin,in-brb,in-butter,in-dsl,in-vpn,mein-iserv,schulserver,test-iserv,keymachine,git-repos,lcube-server,svn-repos,barsy,logoip,firewall-gateway,my-gateway,my-router,spdns,speedpartner>customer<myspreadshop,taifun-dns,12hp,2ix,4lima,lima-city,dd-dns,dray-dns,draydns,dyn-vpn,dynvpn,mein-vigor,my-vigor,my-wan,syno-ds,synology-diskstation,synology-ds,uberspace>*<virtualuser,virtual-user,community-pro,diskussionsbereich<rs>brendly>shop<blogspot,ua,ox<uk>co>bytemark>dh,vm<blogspot,layershift>j<barsy,barsyonline,retrosnub>cust<nh-serv,no-ip,wellbeingzone,adimo,myspreadshop,gwiddle<conn,copro,hosp,gov>service,homeoffice<pymnt,org>glug,lug,lugs,affinitylottery,raffleentry,weeklylottery<barsy<eu>mycd,cloudns,dogado>jelastic<barsy,wellbeingzone,spdns,transurl>*<diskstation<ac>drr<ai>uwu<co>carrd,crd,otap>*<com>blogspot<leadpages,lpages,mypi,n4t,nodum,repl>id<supabase<mp>ju<se>com,blogspot,conf,iopsys,itcouldbewor,myspreadshop,paba>su<<bz>za,gsj<in>web,cloudns,blogspot,barsy,supabase<basketball>aus,nz<am>radio,blogspot,neko,nyaa<fm>radio<group>discourse<team>discourse,jelastic<app>clerk,clerkstage,wnext,platform0,ondigitalocean,edgecompute,fireweb,framer,run>a<web,hasura,loginline,netlify,developer>*<noop,northflank>*<telebit,vercel,bookonline<dev>lcl>*<lclstage>*<stg>*<stgstage>*<pages,workers,curv,deno,deno-staging,fly,githubpreview,gateway>*<iserv,loginline,mediatech,platter-app,shiftcrypto,vercel,webhare>*<<me>c66,daplie>localhost<edgestack,couk,ukco,filegear,filegear-au,filegear-de,filegear-gb,filegear-ie,filegear-jp,filegear-sg,glitch,ravendb,lohmus,barsy,mcpe,mcdir,soundcast,tcp4,brasilia,ddns,dnsfor,hopto,loginto,noip,webhop,vp4,diskstation,dscloud,i234,myds,synology,tbits,wbq,wedeploy,yombo,nohost<zone>cloud66,hs,triton>*<lima<host>clouaskmeofferscustomrulesd1cess,freesite,fastvps,myfast,tempurl,wpmudev,jele,mircloud,pcloud,half<site>cloudera>*<cyon,fnwk,folionetwork,fastvps,jele,lelux,loginline,barsy,mintere,omniwe,opensocial,platformsh>*<tst>*<byen,srht,novecore<cz>co,realm,e4,blogspot,metacentrum>cloud>*<custom<muni>cloud>flt,usr<<<asia>cloudns<biz>cloudns,jozi,dyndns,for-better,for-more,for-some,for-the,selfip,webhop,orx,mmafan,myftp,no-ip,dscloud<club>cloudns,jele,barsy,pony<cc>cloudns,ftpaccess,game-server,myphotos,scrapping,twmail,csx,fantasyleague<info>cloudns,dynamic-dns,dyndns,barrel-of-knowledge,barrell-of-knowledge,for-our,groks-the,groks-this,here-for-more,knowsitall,selfip,webhop,barsy,mayfirst,forumz,nsupdate,dvrcam,ilovecollege,no-ip,dnsupdate,v-info<pro>cloudns,dnstrace>bci<barsy<pw>cloudns,x443<gdn>cnpy<no>co,blogspot,myspreadshop<be>webhosting,blogspot,interhostsolutions>cloud<kuleuven>ezproxy<myspreadshop,transurl>*<<ru>ac,edu,gov,int,mil,test,eurodir,adygeya,bashkiria,bir,cbg,com,dagestan,grozny,kalmykia,kustanai,marine,mordovia,msk,mytis,nalchik,nov,pyatigorsk,spb,vladikavkaz,vladimir,blogspot,na4u,mircloud,regruhosting>jelastic<myjino>hosting>*<landing>*<spectrum>*<vps>*<<cldmail>hb<mcdir>vps<mcpre,net,org,pp,lk3,ras<is>cupcake,blogspot<link>cyon,mypep,dweb>*<<dk>biz,co,firm,reg,store,blogspot,myspreadshop<earth>dapps>*,bzz>*<<<id>my>rss>*<<flap,co>blogspot<forte,bloger,wblog<solutions>diher>*<<th>online,shop<sh>bip,hashbang,platform>bc,ent,eu,us<now,vxl,wedeploy<fi>dy,blogspot,xn--hkkinen-5wa,iki,cloudplatform>fi<datacenter>demo,paas<myspreadshop<tv>dyndns,better-than,on-the-web,worse-than<cx>ath,info<name>her>forgot<his>forgot<<nu>merseine,mine,shacknet,enterprisecloud<rocks>myddns,lima-city,webspace<xyz>blogsite,localzone,crafting,zapto,telebit>*<<online>eero,eero-stage,barsy<cool>elementor,de<fr>en-root,fbx-os,fbxos,freebox-os,freeboxos,blogspot,goupile,on-web,chirurgiens-dentistes-en-france,myspreadshop,ynh<one>onred>staging<service,for,under,homelink<tw>com>mymailer<url,blogspot<su>abkhazia,adygeya,aktyubinsk,arkhangelsk,armenia,ashgabad,azerbaijan,balashov,bashkiria,bryansk,bukhara,chimkent,dagestan,east-kazakhstan,exnet,georgia,grozny,ivanovo,jambyl,kalmykia,kaluga,karacol,karaganda,karelia,khakassia,krasnodar,kurgan,kustanai,lenug,mangyshlak,mordovia,msk,murmansk,nalchik,navoi,north-kazakhstan,nov,obninsk,penza,pokrovsk,sochi,spb,tashkent,termez,togliatti,troitsk,tselinograd,tula,tuva,vladikavkaz,vladimir,vologda<space>myfast,uber,xs4all<il>co>ravpage,blogspot,tabitorder<<at>funkfeuer>wien<futurecms>*,ex>*<in>*<<futurehosting,futuremailing,ortsinfo>ex>*<kunden>*<<co>blogspot<biz,info,priv,myspreadshop,12hp,2ix,4lima,lima-city<ms>lab,minisite<si>gitapp,gitpage,blogspot<community>nog,ravendb,myforum<ro>co,shop,blogspot,barsy<digital>cloudapps>london<<im>ro<goog>cloud,translate<ae>blogspot<al>blogspot<bg>blogspot,barsy<bj>blogspot<cf>blogspot<cl>blogspot<ke>co>blogspot<<nz>co>blogspot<<za>co>blogspot<<ar>com>blogspot<<au>com>blogspot,cloudlets>mel<myspreadshop<<br>com>blogspot,virtualcloud>scale>users<<<leg>ac,al,am,ap,ba,ce,df,es,go,ma,mg,ms,mt,pa,pb,pe,pi,pr,rj,rn,ro,rr,rs,sc,se,sp,to<<by>com>blogspot<mycloud,mediatech<cy>com>blogspot,scaleforce>j<<<ee>com>blogspot<<eg>com>blogspot<<es>com>blogspot<myspreadshop<mt>com>blogspot<<ng>com>blogspot<col,firm,gen,ltd,ngo<tr>com>blogspot<<uy>com>blogspot<<cv>blogspot<gr>blogspot<hk>blogspot,secaas,ltd,inc<hr>blogspot,free<hu>blogspot<ie>blogspot,myspreadshop<it>blogspot,neen>jc<tim>open>jelastic>cloud<<<16-b,32-b,64-b,myspreadshop,syncloud<kr>blogspot<li>blogspot,caa<lt>blogspot<lu>blogspot<md>blogspot,at,de,jp,to<mk>blogspot<mr>blogspot<mx>blogspot<my>blogspot<pe>blogspot<pt>blogspot<qa>blogspot<re>blogspot<sg>blogspot,enscaled<sk>blogspot<sn>blogspot<td>blogspot<ug>blogspot<vn>blogspot<ci>fin,nl<run>hs,development,ravendb,servers,code>*<repl<gl>biz,xx<scot>edu,gov>service<<so>sch<yt>org<kz>jcloud,kazteleport>upaas<<tn>orangecloud<gg>kaas,cya,panel>daemon<<systems>knightpoint<krd>co,edu<business>co<education>co<events>co<financial>co<place>co<technology>co<bs>we<services>loginline<menu>barsy<mobi>barsy,dscloud<pub>barsy<shop>barsy<support>barsy<vu>cn,blog,dev,me<health>hra<casa>nabu>ui<<fashion>of<london>in,of<marketing>from,with<men>for,repair<mom>and,for<sale>for<win>that<work>from,to<news>noticeable<top>now-dns,ntdll<ovh>nerdpol<mn>nyc<lol>omg<hosting>opencraft<pm>own<codes>owo>*<<lc>oy<bn>co<builders>cloudsite<edu>rit>git-pages<<xn--p1acf>xn--90amc,xn--j1aef,xn--j1ael8b,xn--h1ahn,xn--j1adp,xn--c1avg,xn--80aaa0cvac,xn--h1aliz,xn--90a1af,xn--41a<store>sellfy,shopware,storebase<land>static>dev,sites<<farm>storj<pictures>1337<rip>clan<management>router<ax>be,cat,es,eu,gg,mc,us,xy<gp>app<gt>blog,de,to<gy>be<hn>cc<kg>blog,io,jp,tv,uk,us<ls>de<porn>indie<tc>ch,me,we<vg>at<academy>official<faith>ybo<party>ybo<review>ybo<science>ybo<trade>ybo<st>noho<design>bss"
                ));
        const i = A(r, q),
          a = A(r, $);
        if (0 === i.length && 0 === a.length)
          return { type: V.NotListed, hostname: n, labels: r };
        const o = r.length - Math.max(a.length, i.length) - 1,
          s = r.length - i.length - 1;
        return Object.assign(
          { type: V.Listed, hostname: n, labels: r, icann: H(r, s) },
          H(r, o)
        );
      },
      z = /^[a-z][*+.a-z-]+:\/\//i,
      G = Symbol("NO_HOSTNAME"),
      K = JSON.parse(
        '["AlreadyExistsError","BadAmazonStateError","BlacklistError","CancellationError","CapacityExceededError","ConfigError","DataError","DatabaseError","DomainBlacklistedError","EmailLockedError","EventIgnoredError","EventNotSupportedError","ExpiredError","FacebookNoEmailError","FatalError","InsufficientBalanceError","InsufficientResourcesError","InvalidConfigurationError","InvalidCredentialsError","InvalidDataError","InvalidMappingError","InvalidParametersError","InvalidResponseError","MessageListenerError","MissingParametersError","NoMessageListenersError","NotFoundError","NotImplementedError","NotStartedError","NotSupportedError","NothingToUpdateError","OperationSkippedError","ProfanityError","RequestThrottledError","RequestThrottledError","ResourceLockedError","ServerError","StorageError","TimeoutError","UnauthorizedError","UnavailableError","UpToDateError"]'
      );
    function J(e) {
      return (
        (J =
          "function" == typeof Symbol && "symbol" == typeof Symbol.iterator
            ? function (e) {
                return typeof e;
              }
            : function (e) {
                return e &&
                  "function" == typeof Symbol &&
                  e.constructor === Symbol &&
                  e !== Symbol.prototype
                  ? "symbol"
                  : typeof e;
              }),
        J(e)
      );
    }
    function Y(e, t) {
      for (var r = 0; r < t.length; r++) {
        var n = t[r];
        (n.enumerable = n.enumerable || !1),
          (n.configurable = !0),
          "value" in n && (n.writable = !0),
          Object.defineProperty(
            e,
            ((i = n.key),
            (a = void 0),
            (a = (function (e, t) {
              if ("object" !== J(e) || null === e) return e;
              var r = e[Symbol.toPrimitive];
              if (void 0 !== r) {
                var n = r.call(e, t || "default");
                if ("object" !== J(n)) return n;
                throw new TypeError(
                  "@@toPrimitive must return a primitive value."
                );
              }
              return ("string" === t ? String : Number)(e);
            })(i, "string")),
            "symbol" === J(a) ? a : String(a)),
            n
          );
      }
      var i, a;
    }
    function Q(e, t, r) {
      return (
        t && Y(e.prototype, t),
        r && Y(e, r),
        Object.defineProperty(e, "prototype", { writable: !1 }),
        e
      );
    }
    function X(e, t) {
      if (!(e instanceof t))
        throw new TypeError("Cannot call a class as a function");
    }
    function Z(e, t) {
      if ("function" != typeof t && null !== t)
        throw new TypeError(
          "Super expression must either be null or a function"
        );
      (e.prototype = Object.create(t && t.prototype, {
        constructor: { value: e, writable: !0, configurable: !0 },
      })),
        Object.defineProperty(e, "prototype", { writable: !1 }),
        t && ae(e, t);
    }
    function ee(e) {
      var t = ie();
      return function () {
        var r,
          n = oe(e);
        if (t) {
          var i = oe(this).constructor;
          r = Reflect.construct(n, arguments, i);
        } else r = n.apply(this, arguments);
        return (function (e, t) {
          if (t && ("object" === J(t) || "function" == typeof t)) return t;
          if (void 0 !== t)
            throw new TypeError(
              "Derived constructors may only return object or undefined"
            );
          return te(e);
        })(this, r);
      };
    }
    function te(e) {
      if (void 0 === e)
        throw new ReferenceError(
          "this hasn't been initialised - super() hasn't been called"
        );
      return e;
    }
    function re(e) {
      var t = "function" == typeof Map ? new Map() : void 0;
      return (
        (re = function (e) {
          if (
            null === e ||
            !(function (e) {
              try {
                return (
                  -1 !== Function.toString.call(e).indexOf("[native code]")
                );
              } catch (t) {
                return "function" == typeof e;
              }
            })(e)
          )
            return e;
          if ("function" != typeof e)
            throw new TypeError(
              "Super expression must either be null or a function"
            );
          if (void 0 !== t) {
            if (t.has(e)) return t.get(e);
            t.set(e, r);
          }
          function r() {
            return ne(e, arguments, oe(this).constructor);
          }
          return (
            (r.prototype = Object.create(e.prototype, {
              constructor: {
                value: r,
                enumerable: !1,
                writable: !0,
                configurable: !0,
              },
            })),
            ae(r, e)
          );
        }),
        re(e)
      );
    }
    function ne(e, t, r) {
      return (
        (ne = ie()
          ? Reflect.construct.bind()
          : function (e, t, r) {
              var n = [null];
              n.push.apply(n, t);
              var i = new (Function.bind.apply(e, n))();
              return r && ae(i, r.prototype), i;
            }),
        ne.apply(null, arguments)
      );
    }
    function ie() {
      if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
      if (Reflect.construct.sham) return !1;
      if ("function" == typeof Proxy) return !0;
      try {
        return (
          Boolean.prototype.valueOf.call(
            Reflect.construct(Boolean, [], function () {})
          ),
          !0
        );
      } catch (e) {
        return !1;
      }
    }
    function ae(e, t) {
      return (
        (ae = Object.setPrototypeOf
          ? Object.setPrototypeOf.bind()
          : function (e, t) {
              return (e.__proto__ = t), e;
            }),
        ae(e, t)
      );
    }
    function oe(e) {
      return (
        (oe = Object.setPrototypeOf
          ? Object.getPrototypeOf.bind()
          : function (e) {
              return e.__proto__ || Object.getPrototypeOf(e);
            }),
        oe(e)
      );
    }
    function se(e, t, r) {
      return Object.defineProperty(e, t, {
        value: r,
        configurable: !0,
        enumerable: !1,
        writable: !0,
      });
    }
    var ue = (function (e) {
      Z(r, e);
      var t = ee(r);
      function r(e, n) {
        var i;
        return (
          X(this, r),
          se(te((i = t.call(this, e))), "name", "askmeoffersError"),
          se(te(i), "message", e || "askmeoffersError"),
          se(te(i), "extra", n),
          "function" == typeof Error.captureStackTrace
            ? Error.captureStackTrace(te(i), i.constructor)
            : (i.stack = new Error(e).stack),
          i
        );
      }
      return Q(r);
    })(re(Error));
    try {
      window.askmeoffersError = ue;
    } catch (e) {}
    var ce = { askmeoffersError: ue };
    K.forEach(function (e) {
      var t = (function (e) {
        return (function (t) {
          Z(n, t);
          var r = ee(n);
          function n(t, i) {
            var a;
            return (
              X(this, n),
              se(te((a = r.call(this, t))), "name", e),
              se(te(a), "message", t || e),
              se(te(a), "extra", i),
              "function" == typeof Error.captureStackTrace
                ? Error.captureStackTrace(te(a), a.constructor)
                : (a.stack = new ue(t).stack),
              a
            );
          }
          return Q(n);
        })(ue);
      })(e);
      try {
        window[e] = t;
      } catch (e) {}
      ce[e] = t;
    });
    const le = ce,
      de = JSON.parse(
        '{"AC":{"currencyCode":"USD","currencySymbol":"$","currencyName":"United States Dollar","currencyLanguage":"en"},"AD":{"currencyCode":"EUR","currencySymbol":"\u20ac","currencyName":"Euro","currencyLanguage":"it"},"AF":{"currencyCode":"AFN","currencySymbol":"\u060b","currencyName":"Afghanistan Afghani","currencyLanguage":"fa"},"AG":{"currencyCode":"XCD","currencySymbol":"$","currencyName":"East Caribbean Dollar","currencyLanguage":"ag"},"AI":{"currencyCode":"XCD","currencySymbol":"$","currencyName":"East Caribbean Dollar","currencyLanguage":"ai"},"AL":{"currencyCode":"ALL","currencySymbol":"Lek","currencyName":"Albania Lek","currencyLanguage":"sq"},"AR":{"currencyCode":"ARS","currencySymbol":"$","currencyName":"Argentina Peso","currencyLanguage":"es"},"AS":{"currencyCode":"USD","currencySymbol":"$","currencyName":"United States Dollar","currencyLanguage":"en"},"AT":{"currencyCode":"EUR","currencySymbol":"\u20ac","currencyName":"Euro","currencyLanguage":"of"},"AU":{"currencyCode":"AUD","currencySymbol":"$","currencyName":"Australia Dollar","currencyLanguage":"en"},"AW":{"currencyCode":"AWG","currencySymbol":"\u0192","currencyName":"Aruba Guilder","currencyLanguage":"nl"},"AZ":{"currencyCode":"AZN","currencySymbol":"\u043c\u0430\u043d","currencyName":"Azerbaijan New Manat","currencyLanguage":"az"},"BA":{"currencyCode":"BAM","currencySymbol":"KM","currencyName":"Bosnia and Herzegovina Convertible Marka","currencyLanguage":"bs"},"BB":{"currencyCode":"BBD","currencySymbol":"$","currencyName":"Barbados Dollar","currencyLanguage":"en"},"BE":{"currencyCode":"EUR","currencySymbol":"\u20ac","currencyName":"Euro","currencyLanguage":"nl"},"BG":{"currencyCode":"BGN","currencySymbol":"\u043b\u0432","currencyName":"Bulgaria Lev","currencyLanguage":"bg"},"BL":{"currencyCode":"EUR","currencySymbol":"\u20ac","currencyName":"Euro","currencyLanguage":"fr"},"BM":{"currencyCode":"BMD","currencySymbol":"$","currencyName":"Bermuda Dollar","currencyLanguage":"en"},"BN":{"currencyCode":"BND","currencySymbol":"$","currencyName":"Brunei Darussalam Dollar","currencyLanguage":"ms"},"BO":{"currencyCode":"BOB","currencySymbol":"$b","currencyName":"Bolivia Boliviano","currencyLanguage":"es"},"BQ":{"currencyCode":"USD","currencySymbol":"$","currencyName":"United States Dollar","currencyLanguage":"nl"},"BR":{"currencyCode":"BRL","currencySymbol":"R$","currencyName":"Brazil Real","currencyLanguage":"pt"},"BS":{"currencyCode":"BSD","currencySymbol":"$","currencyName":"Bahamas Dollar","currencyLanguage":"en"},"BT":{"currencyCode":"INR","currencySymbol":"\u20b9","currencyName":"India Rupee","currencyLanguage":"dz"},"BV":{"currencyCode":"NOK","currencySymbol":"kr","currencyName":"Norway Krone","currencyLanguage":"no"},"BW":{"currencyCode":"BWP","currencySymbol":"P","currencyName":"Botswana Pula","currencyLanguage":"bw"},"BY":{"currencyCode":"BYR","currencySymbol":"p.","currencyName":"Belarus Ruble","currencyLanguage":"be"},"BZ":{"currencyCode":"BZD","currencySymbol":"BZ$","currencyName":"Belize Dollar","currencyLanguage":"bzj"},"CA":{"currencyCode":"CAD","currencySymbol":"$","currencyName":"Canada Dollar","currencyLanguage":"en"},"CC":{"currencyCode":"AUD","currencySymbol":"$","currencyName":"Australia Dollar","currencyLanguage":"en"},"CH":{"currencyCode":"CHF","currencySymbol":"CHF","currencyName":"Switzerland Franc","currencyLanguage":"de"},"CK":{"currencyCode":"NZD","currencySymbol":"$","currencyName":"New Zealand Dollar","currencyLanguage":"nz"},"CL":{"currencyCode":"CLP","currencySymbol":"$","currencyName":"Chile Peso","currencyLanguage":"es"},"CN":{"currencyCode":"CNY","currencySymbol":"\xa5","currencyName":"China Yuan Renminbi","currencyLanguage":"zh-hans"},"CO":{"currencyCode":"COP","currencySymbol":"$","currencyName":"Colombia Peso","currencyLanguage":"es"},"CP":{"currencyCode":"EUR","currencySymbol":"\u20ac","currencyName":"Euro","currencyLanguage":"fr"},"CR":{"currencyCode":"CRC","currencySymbol":"\u20a1","currencyName":"Costa Rica Colon","currencyLanguage":"es"},"CU":{"currencyCode":"CUP","currencySymbol":"\u20b1","currencyName":"Cuba Peso","currencyLanguage":"es"},"CW":{"currencyCode":"ANG","currencySymbol":"\u0192","currencyName":"Netherlands Antilles Guilder","currencyLanguage":"nl"},"CX":{"currencyCode":"AUD","currencySymbol":"$","currencyName":"Australia Dollar","currencyLanguage":"en"},"CY":{"currencyCode":"EUR","currencySymbol":"\u20ac","currencyName":"Euro","currencyLanguage":"el"},"CZ":{"currencyCode":"CZK","currencySymbol":"K\u010d","currencyName":"Czech Republic Koruna","currencyLanguage":"cs"},"DE":{"currencyCode":"EUR","currencySymbol":"\u20ac","currencyName":"Euro","currencyLanguage":"de"},"DG":{"currencyCode":"USD","currencySymbol":"$","currencyName":"United States Dollar","currencyLanguage":"en"},"DK":{"currencyCode":"DKK","currencySymbol":"kr","currencyName":"Denmark Krone","currencyLanguage":"da"},"DM":{"currencyCode":"XCD","currencySymbol":"$","currencyName":"East Caribbean Dollar","currencyLanguage":"en"},"DO":{"currencyCode":"DOP","currencySymbol":"RD$","currencyName":"Dominican Republic Peso","currencyLanguage":"es"},"EA":{"currencyCode":"EUR","currencySymbol":"\u20ac","currencyName":"Euro","currencyLanguage":"es"},"EC":{"currencyCode":"USD","currencySymbol":"$","currencyName":"United States Dollar","currencyLanguage":"es"},"EE":{"currencyCode":"EUR","currencySymbol":"\u20ac","currencyName":"Euro","currencyLanguage":"and"},"EG":{"currencyCode":"EGP","currencySymbol":"\xa3","currencyName":"Egypt Pound","currencyLanguage":"ar"},"ES":{"currencyCode":"EUR","currencySymbol":"\u20ac","currencyName":"Euro","currencyLanguage":"ast"},"EU":{"currencyCode":"EUR","currencySymbol":"\u20ac","currencyName":"Euro","currencyLanguage":"in"},"FI":{"currencyCode":"EUR","currencySymbol":"\u20ac","currencyName":"Euro","currencyLanguage":"fi"},"FJ":{"currencyCode":"FJD","currencySymbol":"$","currencyName":"Fiji Dollar","currencyLanguage":"fj"},"FK":{"currencyCode":"FKP","currencySymbol":"\xa3","currencyName":"Falkland Islands (Malvinas) Pound","currencyLanguage":"fkp"},"FM":{"currencyCode":"USD","currencySymbol":"$","currencyName":"United States Dollar","currencyLanguage":"en"},"FO":{"currencyCode":"DKK","currencySymbol":"kr","currencyName":"Denmark Krone","currencyLanguage":"fo"},"FR":{"currencyCode":"EUR","currencySymbol":"\u20ac","currencyName":"Euro","currencyLanguage":"fr"},"FX":{"currencyCode":"EUR","currencySymbol":"\u20ac","currencyName":"Euro","currencyLanguage":"fr"},"GB":{"currencyCode":"GBP","currencySymbol":"\xa3","currencyName":"United Kingdom Pound","currencyLanguage":"en-GB"},"GD":{"currencyCode":"XCD","currencySymbol":"$","currencyName":"East Caribbean Dollar","currencyLanguage":"en"},"GF":{"currencyCode":"EUR","currencySymbol":"\u20ac","currencyName":"Euro","currencyLanguage":"fr"},"GG":{"currencyCode":"GBP","currencySymbol":"\xa3","currencyName":"United Kingdom Pound","currencyLanguage":"en-GB"},"GI":{"currencyCode":"GIP","currencySymbol":"\xa3","currencyName":"Gibraltar Pound","currencyLanguage":"en"},"GL":{"currencyCode":"DKK","currencySymbol":"kr","currencyName":"Denmark Krone","currencyLanguage":"kl"},"GP":{"currencyCode":"EUR","currencySymbol":"\u20ac","currencyName":"Euro","currencyLanguage":"fr"},"GR":{"currencyCode":"EUR","currencySymbol":"\u20ac","currencyName":"Euro","currencyLanguage":"el"},"GS":{"currencyCode":"GBP","currencySymbol":"\xa3","currencyName":"United Kingdom Pound","currencyLanguage":"en-GB"},"GT":{"currencyCode":"GTQ","currencySymbol":"Q","currencyName":"Guatemala Quetzal","currencyLanguage":"es"},"GU":{"currencyCode":"USD","currencySymbol":"$","currencyName":"United States Dollar","currencyLanguage":"ch"},"GY":{"currencyCode":"GYD","currencySymbol":"$","currencyName":"Guyana Dollar","currencyLanguage":"en"},"HK":{"currencyCode":"HKD","currencySymbol":"$","currencyName":"Hong Kong Dollar","currencyLanguage":"zh-hant"},"HM":{"currencyCode":"AUD","currencySymbol":"$","currencyName":"Australia Dollar","currencyLanguage":"en"},"HN":{"currencyCode":"HNL","currencySymbol":"L","currencyName":"Honduras Lempira","currencyLanguage":"es"},"HR":{"currencyCode":"HRK","currencySymbol":"kn","currencyName":"Croatia Kuna","currencyLanguage":"hr"},"HU":{"currencyCode":"HUF","currencySymbol":"Ft","currencyName":"Hungary Forint","currencyLanguage":"hu"},"IC":{"currencyCode":"EUR","currencySymbol":"\u20ac","currencyName":"Euro","currencyLanguage":"es"},"ID":{"currencyCode":"IDR","currencySymbol":"Rp","currencyName":"Indonesia Rupiah","currencyLanguage":"id"},"IE":{"currencyCode":"EUR","currencySymbol":"\u20ac","currencyName":"Euro","currencyLanguage":"en"},"IL":{"currencyCode":"ILS","currencySymbol":"\u20aa","currencyName":"Israel Shekel","currencyLanguage":"he"},"IM":{"currencyCode":"GBP","currencySymbol":"\xa3","currencyName":"United Kingdom Pound","currencyLanguage":"en-GB"},"IN":{"currencyCode":"INR","currencySymbol":"\u20b9","currencyName":"India Rupee","currencyLanguage":"hi"},"IO":{"currencyCode":"USD","currencySymbol":"$","currencyName":"United States Dollar","currencyLanguage":"en"},"IR":{"currencyCode":"IRR","currencySymbol":"\ufdfc","currencyName":"Iran Rial","currencyLanguage":"fa"},"IS":{"currencyCode":"ISK","currencySymbol":"kr","currencyName":"Iceland Krona","currencyLanguage":"is"},"IT":{"currencyCode":"EUR","currencySymbol":"\u20ac","currencyName":"Euro","currencyLanguage":"it"},"JE":{"currencyCode":"GBP","currencySymbol":"\xa3","currencyName":"United Kingdom Pound","currencyLanguage":"fr"},"JM":{"currencyCode":"JMD","currencySymbol":"J$","currencyName":"Jamaica Dollar","currencyLanguage":"jam"},"JP":{"currencyCode":"JPY","currencySymbol":"\xa5","currencyName":"Japan Yen","currencyLanguage":"ja"},"KG":{"currencyCode":"KGS","currencySymbol":"\u043b\u0432","currencyName":"Kyrgyzstan Som","currencyLanguage":"ky"},"KH":{"currencyCode":"KHR","currencySymbol":"\u17db","currencyName":"Cambodia Riel","currencyLanguage":"km"},"KI":{"currencyCode":"AUD","currencySymbol":"$","currencyName":"Australia Dollar","currencyLanguage":"en"},"KN":{"currencyCode":"XCD","currencySymbol":"$","currencyName":"East Caribbean Dollar","currencyLanguage":"en"},"KP":{"currencyCode":"KPW","currencySymbol":"\u20a9","currencyName":"Korea (North) Won","currencyLanguage":"ko"},"KR":{"currencyCode":"KRW","currencySymbol":"\u20a9","currencyName":"Korea (South) Won","currencyLanguage":"ko"},"KY":{"currencyCode":"KYD","currencySymbol":"$","currencyName":"Cayman Islands Dollar","currencyLanguage":"en"},"KZ":{"currencyCode":"KZT","currencySymbol":"\u043b\u0432","currencyName":"Kazakhstan Tenge","currencyLanguage":"kk"},"LA":{"currencyCode":"LAK","currencySymbol":"\u20ad","currencyName":"Laos Kip","currencyLanguage":"lo"},"LB":{"currencyCode":"LBP","currencySymbol":"\xa3","currencyName":"Lebanon Pound","currencyLanguage":"ar"},"LC":{"currencyCode":"XCD","currencySymbol":"$","currencyName":"East Caribbean Dollar","currencyLanguage":"en"},"LI":{"currencyCode":"CHF","currencySymbol":"CHF","currencyName":"Switzerland Franc","currencyLanguage":"of"},"LK":{"currencyCode":"LKR","currencySymbol":"\u20a8","currencyName":"Sri Lanka Rupee","currencyLanguage":"if"},"LR":{"currencyCode":"LRD","currencySymbol":"$","currencyName":"Liberia Dollar","currencyLanguage":"en"},"LT":{"currencyCode":"LTL","currencySymbol":"Lt","currencyName":"Lithuania Litas","currencyLanguage":"lt"},"LU":{"currencyCode":"EUR","currencySymbol":"\u20ac","currencyName":"Euro","currencyLanguage":"de-lu"},"LV":{"currencyCode":"LVL","currencySymbol":"Ls","currencyName":"Latvia Lat","currencyLanguage":"lv"},"MC":{"currencyCode":"EUR","currencySymbol":"\u20ac","currencyName":"Euro","currencyLanguage":"fr"},"ME":{"currencyCode":"EUR","currencySymbol":"\u20ac","currencyName":"Euro","currencyLanguage":"srp"},"MF":{"currencyCode":"EUR","currencySymbol":"\u20ac","currencyName":"Euro","currencyLanguage":"fr"},"MH":{"currencyCode":"USD","currencySymbol":"$","currencyName":"United States Dollar","currencyLanguage":"en"},"MK":{"currencyCode":"MKD","currencySymbol":"\u0434\u0435\u043d","currencyName":"Macedonia Denar","currencyLanguage":"mk"},"MN":{"currencyCode":"MNT","currencySymbol":"\u20ae","currencyName":"Mongolia Tughrik","currencyLanguage":"mn"},"MP":{"currencyCode":"USD","currencySymbol":"$","currencyName":"United States Dollar","currencyLanguage":"en"},"MQ":{"currencyCode":"EUR","currencySymbol":"\u20ac","currencyName":"Euro","currencyLanguage":"fr"},"MS":{"currencyCode":"XCD","currencySymbol":"$","currencyName":"East Caribbean Dollar","currencyLanguage":"en"},"MT":{"currencyCode":"EUR","currencySymbol":"\u20ac","currencyName":"Euro","currencyLanguage":"mt"},"MU":{"currencyCode":"MUR","currencySymbol":"\u20a8","currencyName":"Mauritius Rupee","currencyLanguage":"mfe"},"MX":{"currencyCode":"MXN","currencySymbol":"$","currencyName":"Mexico Peso","currencyLanguage":"mx"},"MY":{"currencyCode":"MYR","currencySymbol":"RM","currencyName":"Malaysia Ringgit","currencyLanguage":"ms"},"MZ":{"currencyCode":"MZN","currencySymbol":"MT","currencyName":"Mozambique Metical","currencyLanguage":"pt"},"NA":{"currencyCode":"NAD","currencySymbol":"$","currencyName":"Namibia Dollar","currencyLanguage":"en"},"NF":{"currencyCode":"AUD","currencySymbol":"$","currencyName":"Australia Dollar","currencyLanguage":"en"},"NG":{"currencyCode":"NGN","currencySymbol":"\u20a6","currencyName":"Nigeria Naira","currencyLanguage":"ngn"},"NI":{"currencyCode":"NIO","currencySymbol":"C$","currencyName":"Nicaragua Cordoba","currencyLanguage":"es"},"NL":{"currencyCode":"EUR","currencySymbol":"\u20ac","currencyName":"Euro","currencyLanguage":"nl"},"NO":{"currencyCode":"NOK","currencySymbol":"kr","currencyName":"Norway Krone","currencyLanguage":"nb"},"NP":{"currencyCode":"NPR","currencySymbol":"\u20a8","currencyName":"Nepal Rupee","currencyLanguage":"ne"},"NR":{"currencyCode":"AUD","currencySymbol":"$","currencyName":"Australia Dollar","currencyLanguage":"na"},"NU":{"currencyCode":"NZD","currencySymbol":"$","currencyName":"New Zealand Dollar","currencyLanguage":"niu"},"NZ":{"currencyCode":"NZD","currencySymbol":"$","currencyName":"New Zealand Dollar","currencyLanguage":"mi"},"OM":{"currencyCode":"OMR","currencySymbol":"\ufdfc","currencyName":"Oman Rial","currencyLanguage":"ar"},"PA":{"currencyCode":"PAB","currencySymbol":"B/.","currencyName":"Panama Balboa","currencyLanguage":"es"},"PE":{"currencyCode":"PEN","currencySymbol":"S/.","currencyName":"Peru Nuevo Sol","currencyLanguage":"es"},"PH":{"currencyCode":"PHP","currencySymbol":"\u20b1","currencyName":"Philippines Peso","currencyLanguage":"php"},"PK":{"currencyCode":"PKR","currencySymbol":"\u20a8","currencyName":"Pakistan Rupee","currencyLanguage":"pkr"},"PL":{"currencyCode":"PLN","currencySymbol":"z\u0142","currencyName":"Poland Zloty","currencyLanguage":"pl"},"PM":{"currencyCode":"EUR","currencySymbol":"\u20ac","currencyName":"Euro","currencyLanguage":"fr"},"PN":{"currencyCode":"NZD","currencySymbol":"$","currencyName":"New Zealand Dollar","currencyLanguage":"nzd"},"PR":{"currencyCode":"USD","currencySymbol":"$","currencyName":"United States Dollar","currencyLanguage":"es"},"PT":{"currencyCode":"EUR","currencySymbol":"\u20ac","currencyName":"Euro","currencyLanguage":"pt"},"PW":{"currencyCode":"USD","currencySymbol":"$","currencyName":"United States Dollar","currencyLanguage":"en"},"PY":{"currencyCode":"PYG","currencySymbol":"Gs","currencyName":"Paraguay Guarani","currencyLanguage":"es"},"QA":{"currencyCode":"QAR","currencySymbol":"\ufdfc","currencyName":"Qatar Riyal","currencyLanguage":"ar"},"RE":{"currencyCode":"EUR","currencySymbol":"\u20ac","currencyName":"Euro","currencyLanguage":"fr"},"RO":{"currencyCode":"RON","currencySymbol":"lei","currencyName":"Romania New Leu","currencyLanguage":"ro"},"RS":{"currencyCode":"RSD","currencySymbol":"\u0414\u0438\u043d.","currencyName":"Serbia Dinar","currencyLanguage":"sr"},"RU":{"currencyCode":"RUB","currencySymbol":"\u0440\u0443\u0431","currencyName":"Russia Ruble","currencyLanguage":"ru"},"SA":{"currencyCode":"SAR","currencySymbol":"\ufdfc","currencyName":"Saudi Arabia Riyal","currencyLanguage":"ar"},"SB":{"currencyCode":"SBD","currencySymbol":"$","currencyName":"Solomon Islands Dollar","currencyLanguage":"sbd"},"SC":{"currencyCode":"SCR","currencySymbol":"\u20a8","currencyName":"Seychelles Rupee","currencyLanguage":"fr"},"SE":{"currencyCode":"SEK","currencySymbol":"kr","currencyName":"Sweden Krona","currencyLanguage":"sv"},"SG":{"currencyCode":"SGD","currencySymbol":"$","currencyName":"Singapore Dollar","currencyLanguage":"zh-hans"},"SH":{"currencyCode":"SHP","currencySymbol":"\xa3","currencyName":"Saint Helena Pound","currencyLanguage":"shp"},"SI":{"currencyCode":"EUR","currencySymbol":"\u20ac","currencyName":"Euro","currencyLanguage":"sl"},"SJ":{"currencyCode":"NOK","currencySymbol":"kr","currencyName":"Norway Krone","currencyLanguage":"no"},"SK":{"currencyCode":"EUR","currencySymbol":"\u20ac","currencyName":"Euro","currencyLanguage":"sk"},"SM":{"currencyCode":"EUR","currencySymbol":"\u20ac","currencyName":"Euro","currencyLanguage":"it"},"SO":{"currencyCode":"SOS","currencySymbol":"S","currencyName":"Somalia Shilling","currencyLanguage":"so"},"SR":{"currencyCode":"SRD","currencySymbol":"$","currencyName":"Suriname Dollar","currencyLanguage":"nl"},"SU":{"currencyCode":"RUB","currencySymbol":"\u0440\u0443\u0431","currencyName":"Russia Ruble","currencyLanguage":"ru"},"SV":{"currencyCode":"USD","currencySymbol":"$","currencyName":"United States Dollar","currencyLanguage":"es"},"SX":{"currencyCode":"ANG","currencySymbol":"\u0192","currencyName":"Netherlands Antilles Guilder","currencyLanguage":"nl"},"SY":{"currencyCode":"SYP","currencySymbol":"\xa3","currencyName":"Syria Pound","currencyLanguage":"ar"},"TA":{"currencyCode":"GBP","currencySymbol":"\xa3","currencyName":"United Kingdom Pound","currencyLanguage":"en-GB"},"TC":{"currencyCode":"USD","currencySymbol":"$","currencyName":"United States Dollar","currencyLanguage":"en"},"TF":{"currencyCode":"EUR","currencySymbol":"\u20ac","currencyName":"Euro","currencyLanguage":"fr"},"TH":{"currencyCode":"THB","currencySymbol":"\u0e3f","currencyName":"Thailand Baht","currencyLanguage":"th"},"TK":{"currencyCode":"NZD","currencySymbol":"$","currencyName":"New Zealand Dollar","currencyLanguage":"tkl"},"TL":{"currencyCode":"USD","currencySymbol":"$","currencyName":"United States Dollar","currencyLanguage":"pt"},"TR":{"currencyCode":"TRY","currencySymbol":"\u20ba","currencyName":"Turkey Lira","currencyLanguage":"tr"},"TT":{"currencyCode":"TTD","currencySymbol":"TT$","currencyName":"Trinidad and Tobago Dollar","currencyLanguage":"ttd"},"TV":{"currencyCode":"AUD","currencySymbol":"$","currencyName":"Australia Dollar","currencyLanguage":"en"},"TW":{"currencyCode":"TWD","currencySymbol":"NT$","currencyName":"Taiwan New Dollar","currencyLanguage":"zh-hant"},"UA":{"currencyCode":"UAH","currencySymbol":"\u20b4","currencyName":"Ukraine Hryvnia","currencyLanguage":"uk"},"UK":{"currencyCode":"GBP","currencySymbol":"\xa3","currencyName":"United Kingdom Pound","currencyLanguage":"en-GB"},"UM":{"currencyCode":"USD","currencySymbol":"$","currencyName":"United States Dollar","currencyLanguage":"en"},"US":{"currencyCode":"USD","currencySymbol":"$","currencyName":"United States Dollar","currencyLanguage":"en"},"UY":{"currencyCode":"UYU","currencySymbol":"$U","currencyName":"Uruguay Peso","currencyLanguage":"es"},"UZ":{"currencyCode":"UZS","currencySymbol":"\u043b\u0432","currencyName":"Uzbekistan Som","currencyLanguage":"uz"},"VA":{"currencyCode":"EUR","currencySymbol":"\u20ac","currencyName":"Euro","currencyLanguage":"en"},"VC":{"currencyCode":"XCD","currencySymbol":"$","currencyName":"East Caribbean Dollar","currencyLanguage":"xcd"},"VE":{"currencyCode":"VEF","currencySymbol":"Bs","currencyName":"Venezuela Bolivar","currencyLanguage":"es"},"VG":{"currencyCode":"USD","currencySymbol":"$","currencyName":"United States Dollar","currencyLanguage":"en"},"VI":{"currencyCode":"USD","currencySymbol":"$","currencyName":"United States Dollar","currencyLanguage":"en"},"VN":{"currencyCode":"VND","currencySymbol":"\u20ab","currencyName":"Viet Nam Dong","currencyLanguage":"vi"},"YE":{"currencyCode":"YER","currencySymbol":"\ufdfc","currencyName":"Yemen Rial","currencyLanguage":"ar"},"YT":{"currencyCode":"EUR","currencySymbol":"\u20ac","currencyName":"Euro","currencyLanguage":"fr"},"ZA":{"currencyCode":"ZAR","currencySymbol":"R","currencyName":"South Africa Rand","currencyLanguage":"zar"},"ZW":{"currencyCode":"USD","currencySymbol":"$","currencyName":"United States Dollar","currencyLanguage":"en"}}'
      );
    function pe(e) {
      return (
        (pe =
          "function" == typeof Symbol && "symbol" == typeof Symbol.iterator
            ? function (e) {
                return typeof e;
              }
            : function (e) {
                return e &&
                  "function" == typeof Symbol &&
                  e.constructor === Symbol &&
                  e !== Symbol.prototype
                  ? "symbol"
                  : typeof e;
              }),
        pe(e)
      );
    }
    function fe(e, t) {
      return (
        (function (e) {
          if (Array.isArray(e)) return e;
        })(e) ||
        (function (e, t) {
          var r =
            null == e
              ? null
              : ("undefined" != typeof Symbol && e[Symbol.iterator]) ||
                e["@@iterator"];
          if (null != r) {
            var n,
              i,
              a,
              o,
              s = [],
              u = !0,
              c = !1;
            try {
              if (((a = (r = r.call(e)).next), 0 === t)) {
                if (Object(r) !== r) return;
                u = !1;
              } else
                for (
                  ;
                  !(u = (n = a.call(r)).done) &&
                  (s.push(n.value), s.length !== t);
                  u = !0
                );
            } catch (e) {
              (c = !0), (i = e);
            } finally {
              try {
                if (
                  !u &&
                  null != r.return &&
                  ((o = r.return()), Object(o) !== o)
                )
                  return;
              } finally {
                if (c) throw i;
              }
            }
            return s;
          }
        })(e, t) ||
        he(e, t) ||
        (function () {
          throw new TypeError(
            "Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."
          );
        })()
      );
    }
    function he(e, t) {
      if (e) {
        if ("string" == typeof e) return me(e, t);
        var r = Object.prototype.toString.call(e).slice(8, -1);
        return (
          "Object" === r && e.constructor && (r = e.constructor.name),
          "Map" === r || "Set" === r
            ? Array.from(e)
            : "Arguments" === r ||
              /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(r)
            ? me(e, t)
            : void 0
        );
      }
    }
    function me(e, t) {
      (null == t || t > e.length) && (t = e.length);
      for (var r = 0, n = new Array(t); r < t; r++) n[r] = e[r];
      return n;
    }
    var ge,
      ye,
      ve = Math.floor(256 * Math.random()),
      be = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789",
      _e = /(^-?\.?[\d+]?[,.\s\d+]+)/,
      Ee = /([,.\s\d]+)(\.(?:\d{1,2})|,(?:\d{1,2}))\b/,
      we = {},
      xe = !1;
    function Se(e) {
      var t =
        arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0;
      return parseInt(e, 10) || t;
    }
    function Te(e) {
      var t =
        arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0;
      return parseFloat(e, 10) || t;
    }
    const Ae = {
      addCommas: function (e) {
        var t = "number" == typeof e ? e : parseInt(e, 10);
        return Number.isNaN(t)
          ? NaN
          : e.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
      },
      buildTargetUrl: function (e, t, r) {
        var n = e;
        try {
          (r || []).forEach(function (t) {
            var r = e.match("[?&;](".concat(t, "=[^&#]*?(?=([#&;]|$).*?))"));
            r &&
              r.length > 1 &&
              (n =
                r[0].indexOf("?") >= 0
                  ? n.replace(r[1], "")
                  : n.replace(r[0], ""));
          }),
            (t || []).forEach(function (t) {
              if (t.includes("=")) {
                var r = fe(t.split("="), 1)[0],
                  i = e.match("[?&;](".concat(r, "=[^&#]*?(?=([#&;]|$).*?))"));
                i && i.length
                  ? (n = n.replace(i[1], t))
                  : n.indexOf("?") > 0
                  ? (n += "&".concat(t))
                  : (n += "?".concat(t));
              }
            });
        } catch (e) {
          return n;
        }
        return n;
      },
      camelifyObject: function e(t) {
        if (!t || "object" !== pe(t)) return t;
        if (Array.isArray(t)) return t.map(e);
        var r = Object.keys(t);
        if (0 === r.length) return t;
        var n = {};
        return (
          r.forEach(function (r) {
            n[a.camelCase(r)] = e(t[r]);
          }),
          n
        );
      },
      cleanPrice: function (e) {
        var t = this.cleanString(e);
        t.length >= 3 &&
          "(" === t[0] &&
          ")" === t.substr(-1) &&
          (t = "-".concat(t.substr(1, t.length - 2)));
        var r = t.search(/\d/),
          n = t.substr(0, r);
        (t = t.substr(r)),
          n.includes("-") && (t = "-".concat(t)),
          t.split(".").length > 1 &&
            t.split(",").length - 1 == 0 &&
            (t.match(Ee) || (t += ",00"));
        var i = t.match(_e);
        return (
          i && (t = i[1].trim()),
          Number(E().unformat(t, this.decimalSeparator(t)))
        );
      },
      cleanString: function (e) {
        var t =
          arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "";
        return "".concat(e || "").trim() || t;
      },
      cleanStringLower: function (e) {
        var t =
          arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "";
        return (
          ""
            .concat(e || "")
            .trim()
            .toLowerCase() || t
        );
      },
      cleanStringUpper: function (e) {
        var t =
          arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "";
        return (
          ""
            .concat(e || "")
            .trim()
            .toUpperCase() || t
        );
      },
      cleanUp: function (e) {
        try {
          var t = T()("#undefined")[0];
          t && document.body.removeChild(t);
          var r = T()("#".concat(e))[0];
          r && document.body.removeChild(r);
        } catch (e) {}
      },
      createId: function () {
        return new (s())()
          .add(10 * x()().valueOf())
          .shiftLeft(11)
          .and(new (s())(4294965248, 4294967295))
          .add(Math.floor(2048 * Math.random()))
          .shiftLeft(8)
          .and(new (s())(4294967280, 4294967295))
          .add(ve)
          .toString(10);
      },
      decimalSeparator: function (e) {
        var t = e.match(Ee);
        return t
          ? t[2].substring(0, 1) || "."
          : e.split(".").length > 1 || e.split(" ").length > 1
          ? ","
          : ".";
      },
      execTopFrameJS: function () {
        return b().resolve();
      },
      getCountryCurrency: function (e) {
        if (e && "string" == typeof e) {
          var t = de[e.toUpperCase()];
          if (t) return t.currencySymbol;
        }
        return "$";
      },
      getCountryCurrencyCode: function (e) {
        if (e && "string" == typeof e) {
          var t = de[e.toUpperCase()];
          if (t) return t.currencyCode;
        }
        return "USD";
      },
      getCountryLanguage: function (e) {
        if (e && "string" == typeof e) {
          var t = de[e.toUpperCase()];
          if (t) return t.currencyLanguage;
        }
        return "en-US";
      },
      getCurrentPageHtml: function () {
        return document.documentElement.innerHTML;
      },
      getDomain: function (e) {
        var t =
            arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {},
          r = t.useTopLevelDomain,
          n = void 0 !== r && r,
          i = t.useSubDomain,
          a = void 0 !== i && i,
          o = W(
            ((e) => {
              if ("function" != typeof URL)
                throw new Error(
                  "Looks like the new URL() constructor is not globally available in your environment. Please make sure to use a polyfill."
                );
              if ("string" != typeof e) return G;
              const t = e.startsWith("//")
                ? `http:${e}`
                : e.startsWith("/") || z.test(e)
                ? e
                : `http://${e}`;
              try {
                return new URL(t).hostname;
              } catch (e) {
                return G;
              }
            })(e)
          );
        if (o.type === V.NotListed) return "";
        var s = o.domain;
        if (o.type === V.Invalid || !s) return "";
        var u = s;
        if (n) {
          var c = o.topLevelDomains,
            l = void 0 === c ? [] : c;
          l.length && (u = "".concat(s, ".").concat(l.join(".")));
        }
        if (a) {
          var d = o.subDomains,
            p = void 0 === d ? [] : d;
          if (p.length) {
            var f = p.filter(function (e) {
              return !e.includes("www") && !e.includes("style");
            });
            f.length && (u = "".concat(f.join("."), ".").concat(u));
          }
        }
        return u;
      },
      getProperty: function (e, t, r) {
        return t.split(".").reduce(function (e, t) {
          return e && e[t] ? e && e[t] : r;
        }, e);
      },
      getTitleCase: function (e) {
        return e
          .split(" ")
          .map(function (e) {
            return e.charAt(0).toUpperCase() + e.slice(1);
          })
          .join(" ");
      },
      injectAbsentaskmeoffersCSS: function () {
        [
          "".concat("https://cdn.askmeoffers.com/extassets/fonts_main.css"),
        ].forEach(function (e) {
          document.querySelector("link[href='".concat(e, "']")) ||
            T()("head").append(
              '<link href="'.concat(e, '" rel="stylesheet" type="text/css"/>')
            );
        });
      },
      keyArrayBy: function () {
        var e =
            arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : [],
          t =
            arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "",
          r = {};
        return Array.isArray(e) &&
          e.length > 0 &&
          "string" == typeof t &&
          t.length > 0
          ? (e.forEach(function (e) {
              r[e[t]] = e;
            }),
            r)
          : e;
      },
      locallyScopeErrors: function () {
        var e =
          arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : le;
        Object.keys(e).forEach(function (t) {
          r.g[t] = e[t];
        });
      },
      lowerClone: function (e) {
        var t = this,
          r = {};
        return e && "object" === pe(e)
          ? (Object.keys(e).forEach(function (n) {
              r[n] = t.lowerClone(e[n]);
            }),
            r)
          : e;
      },
      parseFloat: Te,
      parseInt: Se,
      parsePositiveFloat: function (e) {
        var t =
          arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0;
        return Math.max(0, Te(e, 0)) || t;
      },
      parsePositiveInt: function (e) {
        var t =
          arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0;
        return Math.max(0, Se(e, 0)) || t;
      },
      parseQuery: function (e) {
        var t,
          r = {},
          n = decodeURIComponent(e),
          i = (function (e, t) {
            var r =
              ("undefined" != typeof Symbol && e[Symbol.iterator]) ||
              e["@@iterator"];
            if (!r) {
              if (
                Array.isArray(e) ||
                (r = he(e)) ||
                (t && e && "number" == typeof e.length)
              ) {
                r && (e = r);
                var n = 0,
                  i = function () {};
                return {
                  s: i,
                  n: function () {
                    return n >= e.length
                      ? { done: !0 }
                      : { done: !1, value: e[n++] };
                  },
                  e: function (e) {
                    throw e;
                  },
                  f: i,
                };
              }
              throw new TypeError(
                "Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."
              );
            }
            var a,
              o = !0,
              s = !1;
            return {
              s: function () {
                r = r.call(e);
              },
              n: function () {
                var e = r.next();
                return (o = e.done), e;
              },
              e: function (e) {
                (s = !0), (a = e);
              },
              f: function () {
                try {
                  o || null == r.return || r.return();
                } finally {
                  if (s) throw a;
                }
              },
            };
          })(new URLSearchParams(n));
        try {
          for (i.s(); !(t = i.n()).done; ) {
            var a = fe(t.value, 2),
              o = a[0],
              s = a[1];
            r[o] = s;
          }
        } catch (e) {
          i.e(e);
        } finally {
          i.f();
        }
        return r;
      },
      randomString: function (e) {
        return Array(e)
          .fill(0)
          .map(function () {
            return be.charAt(Math.floor(62 * Math.random()));
          })
          .join("");
      },
      replaceAll: function (e, t, r) {
        var n =
          t instanceof RegExp
            ? t
            : new RegExp(t.replace(/([.*+?^=!:${}()|[]\/\\])/g, "\\$1"), "g");
        return e.replace(n, r);
      },
      retainFocus: function (e) {
        var t = e || window.event,
          r = t.path || (t.composedPath && t.composedPath());
        return r && r[0] ? (r[0].focus(), t.stopPropagation(), t) : null;
      },
      round: function (e, t) {
        var r = Math.pow(10, Math.max(0, t) || 0);
        return Math.round(e * r) / r;
      },
      sleep: function () {
        var e =
          arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 2e3;
        return new (b())(function (t) {
          return setTimeout(t, e);
        });
      },
      snakeifyObject: function e(t) {
        if (!t || "object" !== pe(t)) return t;
        if (Array.isArray(t)) return t.map(e);
        var r = Object.keys(t);
        if (0 === r.length) return t;
        var n = {};
        return (
          r.forEach(function (r) {
            n[a.snakeCase(r)] = e(t[r]);
          }),
          n
        );
      },
      waitForElement: function (e) {
        var t =
          arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        if (we[e]) return we[e].promise;
        (ge = 200), (ye = 0);
        var r = {};
        if (
          ((r.promise = new (b())(function (e) {
            r.resolve = e;
          })),
          (we[e] = r),
          !xe)
        ) {
          setTimeout(function n() {
            for (var i = 0, a = Object.entries(we); i < a.length; i++) {
              var o = fe(a[i], 2),
                s = o[0],
                u = o[1],
                c = T()(s);
              if (c.length > 0) {
                var l = u.resolve;
                l && l(c), delete we[s];
              }
            }
            if (t.timeout && t.timeout < ye)
              return (xe = !1), r.resolve(null), void delete we[e];
            0 !== Object.keys(we).length
              ? ((ye += ge), ge < 2500 && (ge += 200), setTimeout(n, ge))
              : (xe = !1);
          }, ge),
            (xe = !0);
        }
        return r.promise;
      },
      waitForEvent: function (e) {
        var t = e.container,
          r = e.selector,
          n = e.event;
        return new (b())(function (e, i) {
          "string" == typeof r && "string" == typeof n
            ? "string" == typeof t
              ? T()(t).on(n, r, function (t) {
                  e(t);
                })
              : T()(r).on(n, function (t) {
                  e(t);
                })
            : i(
                new Error(
                  "Selector and Event are required and should be strings, " +
                    "received selector: ".concat(r, " and event: ").concat(n)
                )
              );
        });
      },
      XOR: function (e, t) {
        return e ? !t : !!t;
      },
    };
    const ke = {
      detectGoogle: function () {
        var e = {
          service: "messages:cs",
          type: "page:detect_google",
          content: JSON.stringify({
            action: "initializeSearchEngineIntegrationOnTab",
          }),
          dest: { allTabs: !1, background: !0, ignoreResponse: !1 },
        };
        return new Promise(function (t) {
          chrome.runtime.sendMessage(e, null, function (e) {
            chrome.runtime.lastError ? t() : e.success ? t(e.data) : t();
          });
        });
      },
      detectStore: function (e, t, r) {
        var n = {
          service: "messages:cs",
          type: "page:detect_store",
          content: JSON.stringify({ url: e, isShopify: t, isShopPay: r }),
          dest: { allTabs: !1, background: !0, ignoreResponse: !1 },
        };
        return new Promise(function (e) {
          chrome.runtime.sendMessage(n, null, function (t) {
            chrome.runtime.lastError ? e() : t.success ? e(t.data) : e();
          });
        });
      },
    };
    var Ce = [
      "1",
      "2",
      "95396",
      "428",
      "1219",
    ];
    function Oe(e, t, r) {
      ke.detectStore(e, t, r).then(function (e) {
        var t,
          r = e && e.id,
          n = !!r,
          i = Ce.includes(r),
          a = e && e.adblockState && e.adblockState.mayNeedWhitelist,
          o = e && e.dataInfo && e.dataInfo.tagInSameTab;
        n &&
          !i &&
          !o &&
          a &&
          (((t = document.createElement("a")).className = "hss-abp-subscribe"),
          (t.href =
            "abp:subscribe?location=https://askmeoffersscience.github.io/allowlist/askmeoffers-smart-shopping.txt&title=Askmeoffers-Smart-Shopping"),
          (t.style.position = "fixed"),
          (t.style.display = "block"),
          t.style.left,
          (t.style.opacity = 0),
          (t.style.zIndex = 2147483647),
          document.body.appendChild(t));
      });
    }
    function Pe() {
      var e = window.location.href,
        t = !1,
        r = "shop.app" === window.location.hostname;
      Promise.any([
        Ae.waitForElement('[name="shopify-checkout-api-token"]', {
          timeout: 1e3,
        }),
        Ae.waitForElement('[name="shopify-checkout-authorization-token"]', {
          timeout: 1e3,
        }),
        Ae.waitForElement('[data-serialized-id="shopify-checkout-api-token"]', {
          timeout: 1e3,
        }),
        Ae.waitForElement('[name="serialized-shopify-checkout-api-token"]', {
          timeout: 1e3,
        }),
        Ae.waitForElement(
          'meta[name="serialized-public-path"][content*=shopify]',
          { timeout: 1e3 }
        ),
      ])
        .then(function (e) {
          e && (t = !0);
        })
        .catch(function (e) {
          y.debug("detectStore: Not Shopify", e), (t = !1);
        })
        .then(function () {
          r
            ? Promise.any([
                Ae.waitForElement(
                  'p.layout-flex__item span[aria-hidden="true"] + a',
                  { timeout: 1e3 }
                ),
                Ae.waitForElement(".iAaAu", { timeout: 1e3 }),
                Ae.waitForElement(".JXMCh", { timeout: 1e3 }),
                Ae.waitForElement('meta[name="store"]', { timeout: 1e3 }),
                Ae.waitForElement(".s2kwpi3", { timeout: 1e3 }),
              ])
                .then(function (t) {
                  t && t[0] && t[0].href
                    ? Oe((e = t[0].href), !1, r)
                    : t &&
                      t[0] &&
                      t[0].content &&
                      Oe((e = JSON.parse(t[0].content).url), !1, r);
                })
                .catch(function (e) {
                  return y.debug("Could not find Shopify element", e);
                })
            : (Oe(e, t, !1),
              ["shopping.google.com", "www.google.com"].includes(
                window.location.hostname
              ) && ke.detectGoogle());
        });
    }
    Pe();
  })();
})();
