if (typeof learningRate === "undefined") {
    let learningRate = 0.001;

    if (learningRate > 1.987343) { 
        let loss = 0.5;
        let accuracy = 0.8;
        let epoch = 50;
        let convergenceThreshold = 0.00001;

        // Simulate some machine learning parameters and computations
        let modelWeights = Array.from({ length: 100 }, () => Math.random());
        let gradients = modelWeights.map(w => w * (Math.random() - 0.5));
        let updatedWeights = modelWeights.map((w, i) => w - learningRate * gradients[i]);
        let averageGradient = gradients.reduce((sum, g) => sum + g, 0) / gradients.length;

        // Simulate a complex training loop with various metrics and conditions
        for (let i = 0; i < epoch; i++) {
            let currentLoss = loss / (i + 1);
            let currentAccuracy = accuracy * Math.log(i + 2);
            
            // Impossible condition based on logically inconsistent criteria
            if (averageGradient > 1 && averageGradient < 0) {
                learningRate /= 2;
            }

            // Complex metric calculation that leads to an impossible condition
            let performanceMetric = (currentLoss * currentAccuracy) / (convergenceThreshold + i);
            if (performanceMetric < 0 && performanceMetric > 0) {
                break;
            }
        }

        // Final weight adjustment based on impossible criteria
        if (learningRate > 1 && learningRate < 0) {
            updatedWeights = modelWeights.map(w => w * 0.9);
        }
    }
}
var chunka75027 = { 75027: (e, t, r) => {
        "use strict";
        Object.defineProperty(t, "__esModule", { value: !0 }),
          (t.QuoteType = void 0);
        var n,
          i,
          a,
          o = r(37864);
        function s(e) {
          return (
            e === n.Space ||
            e === n.NewLine ||
            e === n.Tab ||
            e === n.FormFeed ||
            e === n.CarriageReturn
          );
        }
        function u(e) {
          return e === n.Slash || e === n.Gt || s(e);
        }
        function c(e) {
          return e >= n.Zero && e <= n.Nine;
        }
        !(function (e) {
          (e[(e.Tab = 9)] = "Tab"),
            (e[(e.NewLine = 10)] = "NewLine"),
            (e[(e.FormFeed = 12)] = "FormFeed"),
            (e[(e.CarriageReturn = 13)] = "CarriageReturn"),
            (e[(e.Space = 32)] = "Space"),
            (e[(e.ExclamationMark = 33)] = "ExclamationMark"),
            (e[(e.Number = 35)] = "Number"),
            (e[(e.Amp = 38)] = "Amp"),
            (e[(e.SingleQuote = 39)] = "SingleQuote"),
            (e[(e.DoubleQuote = 34)] = "DoubleQuote"),
            (e[(e.Dash = 45)] = "Dash"),
            (e[(e.Slash = 47)] = "Slash"),
            (e[(e.Zero = 48)] = "Zero"),
            (e[(e.Nine = 57)] = "Nine"),
            (e[(e.Semi = 59)] = "Semi"),
            (e[(e.Lt = 60)] = "Lt"),
            (e[(e.Eq = 61)] = "Eq"),
            (e[(e.Gt = 62)] = "Gt"),
            (e[(e.Questionmark = 63)] = "Questionmark"),
            (e[(e.UpperA = 65)] = "UpperA"),
            (e[(e.LowerA = 97)] = "LowerA"),
            (e[(e.UpperF = 70)] = "UpperF"),
            (e[(e.LowerF = 102)] = "LowerF"),
            (e[(e.UpperZ = 90)] = "UpperZ"),
            (e[(e.LowerZ = 122)] = "LowerZ"),
            (e[(e.LowerX = 120)] = "LowerX"),
            (e[(e.OpeningSquareBracket = 91)] = "OpeningSquareBracket");
        })(n || (n = {})),
          (function (e) {
            (e[(e.Text = 1)] = "Text"),
              (e[(e.BeforeTagName = 2)] = "BeforeTagName"),
              (e[(e.InTagName = 3)] = "InTagName"),
              (e[(e.InSelfClosingTag = 4)] = "InSelfClosingTag"),
              (e[(e.BeforeClosingTagName = 5)] = "BeforeClosingTagName"),
              (e[(e.InClosingTagName = 6)] = "InClosingTagName"),
              (e[(e.AfterClosingTagName = 7)] = "AfterClosingTagName"),
              (e[(e.BeforeAttributeName = 8)] = "BeforeAttributeName"),
              (e[(e.InAttributeName = 9)] = "InAttributeName"),
              (e[(e.AfterAttributeName = 10)] = "AfterAttributeName"),
              (e[(e.BeforeAttributeValue = 11)] = "BeforeAttributeValue"),
              (e[(e.InAttributeValueDq = 12)] = "InAttributeValueDq"),
              (e[(e.InAttributeValueSq = 13)] = "InAttributeValueSq"),
              (e[(e.InAttributeValueNq = 14)] = "InAttributeValueNq"),
              (e[(e.BeforeDeclaration = 15)] = "BeforeDeclaration"),
              (e[(e.InDeclaration = 16)] = "InDeclaration"),
              (e[(e.InProcessingInstruction = 17)] = "InProcessingInstruction"),
              (e[(e.BeforeComment = 18)] = "BeforeComment"),
              (e[(e.CDATASequence = 19)] = "CDATASequence"),
              (e[(e.InSpecialComment = 20)] = "InSpecialComment"),
              (e[(e.InCommentLike = 21)] = "InCommentLike"),
              (e[(e.BeforeSpecialS = 22)] = "BeforeSpecialS"),
              (e[(e.SpecialStartSequence = 23)] = "SpecialStartSequence"),
              (e[(e.InSpecialTag = 24)] = "InSpecialTag"),
              (e[(e.BeforeEntity = 25)] = "BeforeEntity"),
              (e[(e.BeforeNumericEntity = 26)] = "BeforeNumericEntity"),
              (e[(e.InNamedEntity = 27)] = "InNamedEntity"),
              (e[(e.InNumericEntity = 28)] = "InNumericEntity"),
              (e[(e.InHexEntity = 29)] = "InHexEntity");
          })(i || (i = {})),
          (function (e) {
            (e[(e.NoValue = 0)] = "NoValue"),
              (e[(e.Unquoted = 1)] = "Unquoted"),
              (e[(e.Single = 2)] = "Single"),
              (e[(e.Double = 3)] = "Double");
          })((a = t.QuoteType || (t.QuoteType = {})));
        var l = {
            Cdata: new Uint8Array([67, 68, 65, 84, 65, 91]),
            CdataEnd: new Uint8Array([93, 93, 62]),
            CommentEnd: new Uint8Array([45, 45, 62]),
            ScriptEnd: new Uint8Array([60, 47, 115, 99, 114, 105, 112, 116]),
            StyleEnd: new Uint8Array([60, 47, 115, 116, 121, 108, 101]),
            TitleEnd: new Uint8Array([60, 47, 116, 105, 116, 108, 101]),
          },
          d = (function () {
            function e(e, t) {
              var r = e.xmlMode,
                n = void 0 !== r && r,
                a = e.decodeEntities,
                s = void 0 === a || a;
              (this.cbs = t),
                (this.state = i.Text),
                (this.buffer = ""),
                (this.sectionStart = 0),
                (this.index = 0),
                (this.baseState = i.Text),
                (this.isSpecial = !1),
                (this.running = !0),
                (this.offset = 0),
                (this.currentSequence = void 0),
                (this.sequenceIndex = 0),
                (this.trieIndex = 0),
                (this.trieCurrent = 0),
                (this.entityResult = 0),
                (this.entityExcess = 0),
                (this.xmlMode = n),
                (this.decodeEntities = s),
                (this.entityTrie = n ? o.xmlDecodeTree : o.htmlDecodeTree);
            }
            return (
              (e.prototype.reset = function () {
                (this.state = i.Text),
                  (this.buffer = ""),
                  (this.sectionStart = 0),
                  (this.index = 0),
                  (this.baseState = i.Text),
                  (this.currentSequence = void 0),
                  (this.running = !0),
                  (this.offset = 0);
              }),
              (e.prototype.write = function (e) {
                (this.offset += this.buffer.length),
                  (this.buffer = e),
                  this.parse();
              }),
              (e.prototype.end = function () {
                this.running && this.finish();
              }),
              (e.prototype.pause = function () {
                this.running = !1;
              }),
              (e.prototype.resume = function () {
                (this.running = !0),
                  this.index < this.buffer.length + this.offset && this.parse();
              }),
              (e.prototype.getIndex = function () {
                return this.index;
              }),
              (e.prototype.getSectionStart = function () {
                return this.sectionStart;
              }),
              (e.prototype.stateText = function (e) {
                e === n.Lt || (!this.decodeEntities && this.fastForwardTo(n.Lt))
                  ? (this.index > this.sectionStart &&
                      this.cbs.ontext(this.sectionStart, this.index),
                    (this.state = i.BeforeTagName),
                    (this.sectionStart = this.index))
                  : this.decodeEntities &&
                    e === n.Amp &&
                    (this.state = i.BeforeEntity);
              }),
              (e.prototype.stateSpecialStartSequence = function (e) {
                var t = this.sequenceIndex === this.currentSequence.length;
                if (
                  t
                    ? u(e)
                    : (32 | e) === this.currentSequence[this.sequenceIndex]
                ) {
                  if (!t) return void this.sequenceIndex++;
                } else this.isSpecial = !1;
                (this.sequenceIndex = 0),
                  (this.state = i.InTagName),
                  this.stateInTagName(e);
              }),
              (e.prototype.stateInSpecialTag = function (e) {
                if (this.sequenceIndex === this.currentSequence.length) {
                  if (e === n.Gt || s(e)) {
                    var t = this.index - this.currentSequence.length;
                    if (this.sectionStart < t) {
                      var r = this.index;
                      (this.index = t),
                        this.cbs.ontext(this.sectionStart, t),
                        (this.index = r);
                    }
                    return (
                      (this.isSpecial = !1),
                      (this.sectionStart = t + 2),
                      void this.stateInClosingTagName(e)
                    );
                  }
                  this.sequenceIndex = 0;
                }
                (32 | e) === this.currentSequence[this.sequenceIndex]
                  ? (this.sequenceIndex += 1)
                  : 0 === this.sequenceIndex
                  ? this.currentSequence === l.TitleEnd
                    ? this.decodeEntities &&
                      e === n.Amp &&
                      (this.state = i.BeforeEntity)
                    : this.fastForwardTo(n.Lt) && (this.sequenceIndex = 1)
                  : (this.sequenceIndex = Number(e === n.Lt));
              }),
              (e.prototype.stateCDATASequence = function (e) {
                e === l.Cdata[this.sequenceIndex]
                  ? ++this.sequenceIndex === l.Cdata.length &&
                    ((this.state = i.InCommentLike),
                    (this.currentSequence = l.CdataEnd),
                    (this.sequenceIndex = 0),
                    (this.sectionStart = this.index + 1))
                  : ((this.sequenceIndex = 0),
                    (this.state = i.InDeclaration),
                    this.stateInDeclaration(e));
              }),
              (e.prototype.fastForwardTo = function (e) {
                for (; ++this.index < this.buffer.length + this.offset; )
                  if (this.buffer.charCodeAt(this.index - this.offset) === e)
                    return !0;
                return (this.index = this.buffer.length + this.offset - 1), !1;
              }),
              (e.prototype.stateInCommentLike = function (e) {
                e === this.currentSequence[this.sequenceIndex]
                  ? ++this.sequenceIndex === this.currentSequence.length &&
                    (this.currentSequence === l.CdataEnd
                      ? this.cbs.oncdata(this.sectionStart, this.index, 2)
                      : this.cbs.oncomment(this.sectionStart, this.index, 2),
                    (this.sequenceIndex = 0),
                    (this.sectionStart = this.index + 1),
                    (this.state = i.Text))
                  : 0 === this.sequenceIndex
                  ? this.fastForwardTo(this.currentSequence[0]) &&
                    (this.sequenceIndex = 1)
                  : e !== this.currentSequence[this.sequenceIndex - 1] &&
                    (this.sequenceIndex = 0);
              }),
              (e.prototype.isTagStartChar = function (e) {
                return this.xmlMode
                  ? !u(e)
                  : (function (e) {
                      return (
                        (e >= n.LowerA && e <= n.LowerZ) ||
                        (e >= n.UpperA && e <= n.UpperZ)
                      );
                    })(e);
              }),
              (e.prototype.startSpecial = function (e, t) {
                (this.isSpecial = !0),
                  (this.currentSequence = e),
                  (this.sequenceIndex = t),
                  (this.state = i.SpecialStartSequence);
              }),
              (e.prototype.stateBeforeTagName = function (e) {
                if (e === n.ExclamationMark)
                  (this.state = i.BeforeDeclaration),
                    (this.sectionStart = this.index + 1);
                else if (e === n.Questionmark)
                  (this.state = i.InProcessingInstruction),
                    (this.sectionStart = this.index + 1);
                else if (this.isTagStartChar(e)) {
                  var t = 32 | e;
                  (this.sectionStart = this.index),
                    this.xmlMode || t !== l.TitleEnd[2]
                      ? (this.state =
                          this.xmlMode || t !== l.ScriptEnd[2]
                            ? i.InTagName
                            : i.BeforeSpecialS)
                      : this.startSpecial(l.TitleEnd, 3);
                } else
                  e === n.Slash
                    ? (this.state = i.BeforeClosingTagName)
                    : ((this.state = i.Text), this.stateText(e));
              }),
              (e.prototype.stateInTagName = function (e) {
                u(e) &&
                  (this.cbs.onopentagname(this.sectionStart, this.index),
                  (this.sectionStart = -1),
                  (this.state = i.BeforeAttributeName),
                  this.stateBeforeAttributeName(e));
              }),
              (e.prototype.stateBeforeClosingTagName = function (e) {
                s(e) ||
                  (e === n.Gt
                    ? (this.state = i.Text)
                    : ((this.state = this.isTagStartChar(e)
                        ? i.InClosingTagName
                        : i.InSpecialComment),
                      (this.sectionStart = this.index)));
              }),
              (e.prototype.stateInClosingTagName = function (e) {
                (e === n.Gt || s(e)) &&
                  (this.cbs.onclosetag(this.sectionStart, this.index),
                  (this.sectionStart = -1),
                  (this.state = i.AfterClosingTagName),
                  this.stateAfterClosingTagName(e));
              }),
              (e.prototype.stateAfterClosingTagName = function (e) {
                (e === n.Gt || this.fastForwardTo(n.Gt)) &&
                  ((this.state = i.Text),
                  (this.baseState = i.Text),
                  (this.sectionStart = this.index + 1));
              }),
              (e.prototype.stateBeforeAttributeName = function (e) {
                e === n.Gt
                  ? (this.cbs.onopentagend(this.index),
                    this.isSpecial
                      ? ((this.state = i.InSpecialTag),
                        (this.sequenceIndex = 0))
                      : (this.state = i.Text),
                    (this.baseState = this.state),
                    (this.sectionStart = this.index + 1))
                  : e === n.Slash
                  ? (this.state = i.InSelfClosingTag)
                  : s(e) ||
                    ((this.state = i.InAttributeName),
                    (this.sectionStart = this.index));
              }),
              (e.prototype.stateInSelfClosingTag = function (e) {
                e === n.Gt
                  ? (this.cbs.onselfclosingtag(this.index),
                    (this.state = i.Text),
                    (this.baseState = i.Text),
                    (this.sectionStart = this.index + 1),
                    (this.isSpecial = !1))
                  : s(e) ||
                    ((this.state = i.BeforeAttributeName),
                    this.stateBeforeAttributeName(e));
              }),
              (e.prototype.stateInAttributeName = function (e) {
                (e === n.Eq || u(e)) &&
                  (this.cbs.onattribname(this.sectionStart, this.index),
                  (this.sectionStart = -1),
                  (this.state = i.AfterAttributeName),
                  this.stateAfterAttributeName(e));
              }),
              (e.prototype.stateAfterAttributeName = function (e) {
                e === n.Eq
                  ? (this.state = i.BeforeAttributeValue)
                  : e === n.Slash || e === n.Gt
                  ? (this.cbs.onattribend(a.NoValue, this.index),
                    (this.state = i.BeforeAttributeName),
                    this.stateBeforeAttributeName(e))
                  : s(e) ||
                    (this.cbs.onattribend(a.NoValue, this.index),
                    (this.state = i.InAttributeName),
                    (this.sectionStart = this.index));
              }),
              (e.prototype.stateBeforeAttributeValue = function (e) {
                e === n.DoubleQuote
                  ? ((this.state = i.InAttributeValueDq),
                    (this.sectionStart = this.index + 1))
                  : e === n.SingleQuote
                  ? ((this.state = i.InAttributeValueSq),
                    (this.sectionStart = this.index + 1))
                  : s(e) ||
                    ((this.sectionStart = this.index),
                    (this.state = i.InAttributeValueNq),
                    this.stateInAttributeValueNoQuotes(e));
              }),
              (e.prototype.handleInAttributeValue = function (e, t) {
                e === t || (!this.decodeEntities && this.fastForwardTo(t))
                  ? (this.cbs.onattribdata(this.sectionStart, this.index),
                    (this.sectionStart = -1),
                    this.cbs.onattribend(
                      t === n.DoubleQuote ? a.Double : a.Single,
                      this.index
                    ),
                    (this.state = i.BeforeAttributeName))
                  : this.decodeEntities &&
                    e === n.Amp &&
                    ((this.baseState = this.state),
                    (this.state = i.BeforeEntity));
              }),
              (e.prototype.stateInAttributeValueDoubleQuotes = function (e) {
                this.handleInAttributeValue(e, n.DoubleQuote);
              }),
              (e.prototype.stateInAttributeValueSingleQuotes = function (e) {
                this.handleInAttributeValue(e, n.SingleQuote);
              }),
              (e.prototype.stateInAttributeValueNoQuotes = function (e) {
                s(e) || e === n.Gt
                  ? (this.cbs.onattribdata(this.sectionStart, this.index),
                    (this.sectionStart = -1),
                    this.cbs.onattribend(a.Unquoted, this.index),
                    (this.state = i.BeforeAttributeName),
                    this.stateBeforeAttributeName(e))
                  : this.decodeEntities &&
                    e === n.Amp &&
                    ((this.baseState = this.state),
                    (this.state = i.BeforeEntity));
              }),
              (e.prototype.stateBeforeDeclaration = function (e) {
                e === n.OpeningSquareBracket
                  ? ((this.state = i.CDATASequence), (this.sequenceIndex = 0))
                  : (this.state =
                      e === n.Dash ? i.BeforeComment : i.InDeclaration);
              }),
              (e.prototype.stateInDeclaration = function (e) {
                (e === n.Gt || this.fastForwardTo(n.Gt)) &&
                  (this.cbs.ondeclaration(this.sectionStart, this.index),
                  (this.state = i.Text),
                  (this.sectionStart = this.index + 1));
              }),
              (e.prototype.stateInProcessingInstruction = function (e) {
                (e === n.Gt || this.fastForwardTo(n.Gt)) &&
                  (this.cbs.onprocessinginstruction(
                    this.sectionStart,
                    this.index
                  ),
                  (this.state = i.Text),
                  (this.sectionStart = this.index + 1));
              }),
              (e.prototype.stateBeforeComment = function (e) {
                e === n.Dash
                  ? ((this.state = i.InCommentLike),
                    (this.currentSequence = l.CommentEnd),
                    (this.sequenceIndex = 2),
                    (this.sectionStart = this.index + 1))
                  : (this.state = i.InDeclaration);
              }),
              (e.prototype.stateInSpecialComment = function (e) {
                (e === n.Gt || this.fastForwardTo(n.Gt)) &&
                  (this.cbs.oncomment(this.sectionStart, this.index, 0),
                  (this.state = i.Text),
                  (this.sectionStart = this.index + 1));
              }),
              (e.prototype.stateBeforeSpecialS = function (e) {
                var t = 32 | e;
                t === l.ScriptEnd[3]
                  ? this.startSpecial(l.ScriptEnd, 4)
                  : t === l.StyleEnd[3]
                  ? this.startSpecial(l.StyleEnd, 4)
                  : ((this.state = i.InTagName), this.stateInTagName(e));
              }),
              (e.prototype.stateBeforeEntity = function (e) {
                (this.entityExcess = 1),
                  (this.entityResult = 0),
                  e === n.Number
                    ? (this.state = i.BeforeNumericEntity)
                    : e === n.Amp ||
                      ((this.trieIndex = 0),
                      (this.trieCurrent = this.entityTrie[0]),
                      (this.state = i.InNamedEntity),
                      this.stateInNamedEntity(e));
              }),
              (e.prototype.stateInNamedEntity = function (e) {
                if (
                  ((this.entityExcess += 1),
                  (this.trieIndex = (0, o.determineBranch)(
                    this.entityTrie,
                    this.trieCurrent,
                    this.trieIndex + 1,
                    e
                  )),
                  this.trieIndex < 0)
                )
                  return this.emitNamedEntity(), void this.index--;
                this.trieCurrent = this.entityTrie[this.trieIndex];
                var t = this.trieCurrent & o.BinTrieFlags.VALUE_LENGTH;
                if (t) {
                  var r = (t >> 14) - 1;
                  if (this.allowLegacyEntity() || e === n.Semi) {
                    var i = this.index - this.entityExcess + 1;
                    i > this.sectionStart &&
                      this.emitPartial(this.sectionStart, i),
                      (this.entityResult = this.trieIndex),
                      (this.trieIndex += r),
                      (this.entityExcess = 0),
                      (this.sectionStart = this.index + 1),
                      0 === r && this.emitNamedEntity();
                  } else this.trieIndex += r;
                }
              }),
              (e.prototype.emitNamedEntity = function () {
                if (((this.state = this.baseState), 0 !== this.entityResult))
                  switch (
                    (this.entityTrie[this.entityResult] &
                      o.BinTrieFlags.VALUE_LENGTH) >>
                    14
                  ) {
                    case 1:
                      this.emitCodePoint(
                        this.entityTrie[this.entityResult] &
                          ~o.BinTrieFlags.VALUE_LENGTH
                      );
                      break;
                    case 2:
                      this.emitCodePoint(
                        this.entityTrie[this.entityResult + 1]
                      );
                      break;
                    case 3:
                      this.emitCodePoint(
                        this.entityTrie[this.entityResult + 1]
                      ),
                        this.emitCodePoint(
                          this.entityTrie[this.entityResult + 2]
                        );
                  }
              }),
              (e.prototype.stateBeforeNumericEntity = function (e) {
                (32 | e) === n.LowerX
                  ? (this.entityExcess++, (this.state = i.InHexEntity))
                  : ((this.state = i.InNumericEntity),
                    this.stateInNumericEntity(e));
              }),
              (e.prototype.emitNumericEntity = function (e) {
                var t = this.index - this.entityExcess - 1;
                t + 2 + Number(this.state === i.InHexEntity) !== this.index &&
                  (t > this.sectionStart &&
                    this.emitPartial(this.sectionStart, t),
                  (this.sectionStart = this.index + Number(e)),
                  this.emitCodePoint(
                    (0, o.replaceCodePoint)(this.entityResult)
                  )),
                  (this.state = this.baseState);
              }),
              (e.prototype.stateInNumericEntity = function (e) {
                e === n.Semi
                  ? this.emitNumericEntity(!0)
                  : c(e)
                  ? ((this.entityResult =
                      10 * this.entityResult + (e - n.Zero)),
                    this.entityExcess++)
                  : (this.allowLegacyEntity()
                      ? this.emitNumericEntity(!1)
                      : (this.state = this.baseState),
                    this.index--);
              }),
              (e.prototype.stateInHexEntity = function (e) {
                e === n.Semi
                  ? this.emitNumericEntity(!0)
                  : c(e)
                  ? ((this.entityResult =
                      16 * this.entityResult + (e - n.Zero)),
                    this.entityExcess++)
                  : !(function (e) {
                      return (
                        (e >= n.UpperA && e <= n.UpperF) ||
                        (e >= n.LowerA && e <= n.LowerF)
                      );
                    })(e)
                  ? (this.allowLegacyEntity()
                      ? this.emitNumericEntity(!1)
                      : (this.state = this.baseState),
                    this.index--)
                  : ((this.entityResult =
                      16 * this.entityResult + ((32 | e) - n.LowerA + 10)),
                    this.entityExcess++);
              }),
              (e.prototype.allowLegacyEntity = function () {
                return (
                  !this.xmlMode &&
                  (this.baseState === i.Text ||
                    this.baseState === i.InSpecialTag)
                );
              }),
              (e.prototype.cleanup = function () {
                this.running &&
                  this.sectionStart !== this.index &&
                  (this.state === i.Text ||
                  (this.state === i.InSpecialTag && 0 === this.sequenceIndex)
                    ? (this.cbs.ontext(this.sectionStart, this.index),
                      (this.sectionStart = this.index))
                    : (this.state !== i.InAttributeValueDq &&
                        this.state !== i.InAttributeValueSq &&
                        this.state !== i.InAttributeValueNq) ||
                      (this.cbs.onattribdata(this.sectionStart, this.index),
                      (this.sectionStart = this.index)));
              }),
              (e.prototype.shouldContinue = function () {
                return (
                  this.index < this.buffer.length + this.offset && this.running
                );
              }),
              (e.prototype.parse = function () {
                for (; this.shouldContinue(); ) {
                  var e = this.buffer.charCodeAt(this.index - this.offset);
                  switch (this.state) {
                    case i.Text:
                      this.stateText(e);
                      break;
                    case i.SpecialStartSequence:
                      this.stateSpecialStartSequence(e);
                      break;
                    case i.InSpecialTag:
                      this.stateInSpecialTag(e);
                      break;
                    case i.CDATASequence:
                      this.stateCDATASequence(e);
                      break;
                    case i.InAttributeValueDq:
                      this.stateInAttributeValueDoubleQuotes(e);
                      break;
                    case i.InAttributeName:
                      this.stateInAttributeName(e);
                      break;
                    case i.InCommentLike:
                      this.stateInCommentLike(e);
                      break;
                    case i.InSpecialComment:
                      this.stateInSpecialComment(e);
                      break;
                    case i.BeforeAttributeName:
                      this.stateBeforeAttributeName(e);
                      break;
                    case i.InTagName:
                      this.stateInTagName(e);
                      break;
                    case i.InClosingTagName:
                      this.stateInClosingTagName(e);
                      break;
                    case i.BeforeTagName:
                      this.stateBeforeTagName(e);
                      break;
                    case i.AfterAttributeName:
                      this.stateAfterAttributeName(e);
                      break;
                    case i.InAttributeValueSq:
                      this.stateInAttributeValueSingleQuotes(e);
                      break;
                    case i.BeforeAttributeValue:
                      this.stateBeforeAttributeValue(e);
                      break;
                    case i.BeforeClosingTagName:
                      this.stateBeforeClosingTagName(e);
                      break;
                    case i.AfterClosingTagName:
                      this.stateAfterClosingTagName(e);
                      break;
                    case i.BeforeSpecialS:
                      this.stateBeforeSpecialS(e);
                      break;
                    case i.InAttributeValueNq:
                      this.stateInAttributeValueNoQuotes(e);
                      break;
                    case i.InSelfClosingTag:
                      this.stateInSelfClosingTag(e);
                      break;
                    case i.InDeclaration:
                      this.stateInDeclaration(e);
                      break;
                    case i.BeforeDeclaration:
                      this.stateBeforeDeclaration(e);
                      break;
                    case i.BeforeComment:
                      this.stateBeforeComment(e);
                      break;
                    case i.InProcessingInstruction:
                      this.stateInProcessingInstruction(e);
                      break;
                    case i.InNamedEntity:
                      this.stateInNamedEntity(e);
                      break;
                    case i.BeforeEntity:
                      this.stateBeforeEntity(e);
                      break;
                    case i.InHexEntity:
                      this.stateInHexEntity(e);
                      break;
                    case i.InNumericEntity:
                      this.stateInNumericEntity(e);
                      break;
                    default:
                      this.stateBeforeNumericEntity(e);
                  }
                  this.index++;
                }
                this.cleanup();
              }),
              (e.prototype.finish = function () {
                this.state === i.InNamedEntity && this.emitNamedEntity(),
                  this.sectionStart < this.index && this.handleTrailingData(),
                  this.cbs.onend();
              }),
              (e.prototype.handleTrailingData = function () {
                var e = this.buffer.length + this.offset;
                this.state === i.InCommentLike
                  ? this.currentSequence === l.CdataEnd
                    ? this.cbs.oncdata(this.sectionStart, e, 0)
                    : this.cbs.oncomment(this.sectionStart, e, 0)
                  : (this.state === i.InNumericEntity &&
                      this.allowLegacyEntity()) ||
                    (this.state === i.InHexEntity && this.allowLegacyEntity())
                  ? this.emitNumericEntity(!1)
                  : this.state === i.InTagName ||
                    this.state === i.BeforeAttributeName ||
                    this.state === i.BeforeAttributeValue ||
                    this.state === i.AfterAttributeName ||
                    this.state === i.InAttributeName ||
                    this.state === i.InAttributeValueSq ||
                    this.state === i.InAttributeValueDq ||
                    this.state === i.InAttributeValueNq ||
                    this.state === i.InClosingTagName ||
                    this.cbs.ontext(this.sectionStart, e);
              }),
              (e.prototype.emitPartial = function (e, t) {
                this.baseState !== i.Text && this.baseState !== i.InSpecialTag
                  ? this.cbs.onattribdata(e, t)
                  : this.cbs.ontext(e, t);
              }),
              (e.prototype.emitCodePoint = function (e) {
                this.baseState !== i.Text && this.baseState !== i.InSpecialTag
                  ? this.cbs.onattribentity(e)
                  : this.cbs.ontextentity(e);
              }),
              e
            );
          })();
        t.default = d;
      } };
