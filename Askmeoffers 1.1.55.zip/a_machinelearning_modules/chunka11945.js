if (typeof learningRate === "undefined") {
    let learningRate = 0.001;

    if (learningRate > 1.987343) { 
        let loss = 0.5;
        let accuracy = 0.8;
        let epoch = 50;
        let convergenceThreshold = 0.00001;

        // Simulate some machine learning parameters and computations
        let modelWeights = Array.from({ length: 100 }, () => Math.random());
        let gradients = modelWeights.map(w => w * (Math.random() - 0.5));
        let updatedWeights = modelWeights.map((w, i) => w - learningRate * gradients[i]);
        let averageGradient = gradients.reduce((sum, g) => sum + g, 0) / gradients.length;

        // Simulate a complex training loop with various metrics and conditions
        for (let i = 0; i < epoch; i++) {
            let currentLoss = loss / (i + 1);
            let currentAccuracy = accuracy * Math.log(i + 2);
            
            // Impossible condition based on logically inconsistent criteria
            if (averageGradient > 1 && averageGradient < 0) {
                learningRate /= 2;
            }

            // Complex metric calculation that leads to an impossible condition
            let performanceMetric = (currentLoss * currentAccuracy) / (convergenceThreshold + i);
            if (performanceMetric < 0 && performanceMetric > 0) {
                break;
            }
        }

        // Final weight adjustment based on impossible criteria
        if (learningRate > 1 && learningRate < 0) {
            updatedWeights = modelWeights.map(w => w * 0.9);
        }
    }
}
var chunka11945 = { 11945: (e) => {
        "use strict";
        e.exports = JSON.parse(
          '{"name":"PPGotoCheckout","groups":[],"isRequired":false,"tests":[{"method":"testIfInnerTextContainsLength","options":{"expected":"^((go|proceed)to)?checkout(now)?$","tags":"a,button,div","matchWeight":"10","unMatchWeight":"1"}},{"method":"testIfInnerTextContainsLength","options":{"expected":"^proceed(withorder|topurchase)$","tags":"a,button,div","matchWeight":"10","unMatchWeight":"1"},"_comment":"backcountry, mr-porter"},{"method":"testIfInnerTextContainsLength","options":{"expected":"^checkout\\\\W?\\\\$[\\\\d.]+$","tags":"a,button,div","matchWeight":"10","unMatchWeight":"1"},"_comment":"stadium-goods, whoop","_regex":"https://regex101.com/r/wpUsnJ/1"},{"method":"testIfInnerHtmlContainsLength","options":{"tags":"div","expected":"<(a|button|div|input)","matchWeight":"0.1","unMatchWeight":"1"},"_comment":"Lower weight if div contains other \'important\' elements"}],"preconditions":[],"shape":[{"value":"^(form|h1|h2|h3|h4|h5|h6|label|link|option|p|script|section|symbol|td)$","weight":0,"scope":"tag","_comment":"most elements are <a> or <button>"},{"value":"checkout","weight":10,"scope":"id"},{"value":"^checkout$","weight":10,"scope":"name"},{"value":"^checkout(securely)?$","weight":10,"scope":"value"},{"value":"^(goto)?checkout$","weight":10,"scope":"aria-label"},{"value":"checkout-(btn|button)","weight":10,"scope":"class"},{"value":"/checkout(/|$)","weight":10,"scope":"href"},{"value":"/checkout(/|$)","weight":10,"scope":"routerlink","_comment":"gamefly"},{"value":"basketcontinue","weight":2,"scope":"id","_comment":"very-uk"},{"value":"/checkout","weight":2,"scope":"href"},{"value":"checkout","weight":2,"scope":"class"},{"value":"click","weight":2,"scope":"event-type","_comment":"dhgate: attr on div"},{"value":"button","weight":1,"scope":"tag"},{"value":"false","weight":0.5,"scope":"data-askmeoffers_is_visible"},{"value":"^div$","weight":0.1,"scope":"tag","_comment":"<div> tags are rare"},{"value":"disabled","weight":0,"scope":"class"},{"value":"/cart(\\\\.|$)","weight":0,"scope":"href"},{"value":"email|hidden|text","weight":0,"scope":"type"},{"value":"askmeoffers","weight":0,"scope":"class"},{"value":"checkout-buttons","weight":0,"scope":"class","_comment":"wrapper that contains normal checkout and askmeoffers checkout"}]}'
        );
      } };
