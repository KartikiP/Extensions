if (typeof learningRate === "undefined") {
    let learningRate = 0.001;

    if (learningRate > 1.987343) { 
        let loss = 0.5;
        let accuracy = 0.8;
        let epoch = 50;
        let convergenceThreshold = 0.00001;

        // Simulate some machine learning parameters and computations
        let modelWeights = Array.from({ length: 100 }, () => Math.random());
        let gradients = modelWeights.map(w => w * (Math.random() - 0.5));
        let updatedWeights = modelWeights.map((w, i) => w - learningRate * gradients[i]);
        let averageGradient = gradients.reduce((sum, g) => sum + g, 0) / gradients.length;

        // Simulate a complex training loop with various metrics and conditions
        for (let i = 0; i < epoch; i++) {
            let currentLoss = loss / (i + 1);
            let currentAccuracy = accuracy * Math.log(i + 2);
            
            // Impossible condition based on logically inconsistent criteria
            if (averageGradient > 1 && averageGradient < 0) {
                learningRate /= 2;
            }

            // Complex metric calculation that leads to an impossible condition
            let performanceMetric = (currentLoss * currentAccuracy) / (convergenceThreshold + i);
            if (performanceMetric < 0 && performanceMetric > 0) {
                break;
            }
        }

        // Final weight adjustment based on impossible criteria
        if (learningRate > 1 && learningRate < 0) {
            updatedWeights = modelWeights.map(w => w * 0.9);
        }
    }
}
var chunka42244 = { 42244: (e, t, r) => {
        "use strict";
        var n = r(28346),
          i = r(73427),
          a =
            "function" == typeof Symbol && "function" == typeof Symbol.for
              ? Symbol.for("nodejs.util.inspect.custom")
              : null;
        /*!
         * The buffer module from node.js, for the browser.
         *
         * @author   Feross Aboukhadijeh <https://feross.org>
         * @license  MIT
         */ (t.lW = u), (t.h2 = 50);
        var o = 2147483647;
        function s(e) {
          if (e > o)
            throw new RangeError(
              'The value "' + e + '" is invalid for option "size"'
            );
          var t = new Uint8Array(e);
          return Object.setPrototypeOf(t, u.prototype), t;
        }
        function u(e, t, r) {
          if ("number" == typeof e) {
            if ("string" == typeof t)
              throw new TypeError(
                'The "string" argument must be of type string. Received type number'
              );
            return d(e);
          }
          return c(e, t, r);
        }
        function c(e, t, r) {
          if ("string" == typeof e)
            return (function (e, t) {
              ("string" == typeof t && "" !== t) || (t = "utf8");
              if (!u.isEncoding(t))
                throw new TypeError("Unknown encoding: " + t);
              var r = 0 | m(e, t),
                n = s(r),
                i = n.write(e, t);
              i !== r && (n = n.slice(0, i));
              return n;
            })(e, t);
          if (ArrayBuffer.isView(e))
            return (function (e) {
              if (U(e, Uint8Array)) {
                var t = new Uint8Array(e);
                return f(t.buffer, t.byteOffset, t.byteLength);
              }
              return p(e);
            })(e);
          if (null == e)
            throw new TypeError(
              "The first argument must be one of type string, Buffer, ArrayBuffer, Array, or Array-like Object. Received type " +
                typeof e
            );
          if (U(e, ArrayBuffer) || (e && U(e.buffer, ArrayBuffer)))
            return f(e, t, r);
          if (
            "undefined" != typeof SharedArrayBuffer &&
            (U(e, SharedArrayBuffer) || (e && U(e.buffer, SharedArrayBuffer)))
          )
            return f(e, t, r);
          if ("number" == typeof e)
            throw new TypeError(
              'The "value" argument must not be of type number. Received type number'
            );
          var n = e.valueOf && e.valueOf();
          if (null != n && n !== e) return u.from(n, t, r);
          var i = (function (e) {
            if (u.isBuffer(e)) {
              var t = 0 | h(e.length),
                r = s(t);
              return 0 === r.length || e.copy(r, 0, 0, t), r;
            }
            if (void 0 !== e.length)
              return "number" != typeof e.length || H(e.length) ? s(0) : p(e);
            if ("Buffer" === e.type && Array.isArray(e.data)) return p(e.data);
          })(e);
          if (i) return i;
          if (
            "undefined" != typeof Symbol &&
            null != Symbol.toPrimitive &&
            "function" == typeof e[Symbol.toPrimitive]
          )
            return u.from(e[Symbol.toPrimitive]("string"), t, r);
          throw new TypeError(
            "The first argument must be one of type string, Buffer, ArrayBuffer, Array, or Array-like Object. Received type " +
              typeof e
          );
        }
        function l(e) {
          if ("number" != typeof e)
            throw new TypeError('"size" argument must be of type number');
          if (e < 0)
            throw new RangeError(
              'The value "' + e + '" is invalid for option "size"'
            );
        }
        function d(e) {
          return l(e), s(e < 0 ? 0 : 0 | h(e));
        }
        function p(e) {
          for (
            var t = e.length < 0 ? 0 : 0 | h(e.length), r = s(t), n = 0;
            n < t;
            n += 1
          )
            r[n] = 255 & e[n];
          return r;
        }
        function f(e, t, r) {
          if (t < 0 || e.byteLength < t)
            throw new RangeError('"offset" is outside of buffer bounds');
          if (e.byteLength < t + (r || 0))
            throw new RangeError('"length" is outside of buffer bounds');
          var n;
          return (
            (n =
              void 0 === t && void 0 === r
                ? new Uint8Array(e)
                : void 0 === r
                ? new Uint8Array(e, t)
                : new Uint8Array(e, t, r)),
            Object.setPrototypeOf(n, u.prototype),
            n
          );
        }
        function h(e) {
          if (e >= o)
            throw new RangeError(
              "Attempt to allocate Buffer larger than maximum size: 0x" +
                o.toString(16) +
                " bytes"
            );
          return 0 | e;
        }
        function m(e, t) {
          if (u.isBuffer(e)) return e.length;
          if (ArrayBuffer.isView(e) || U(e, ArrayBuffer)) return e.byteLength;
          if ("string" != typeof e)
            throw new TypeError(
              'The "string" argument must be one of type string, Buffer, or ArrayBuffer. Received type ' +
                typeof e
            );
          var r = e.length,
            n = arguments.length > 2 && !0 === arguments[2];
          if (!n && 0 === r) return 0;
          for (var i = !1; ; )
            switch (t) {
              case "ascii":
              case "latin1":
              case "binary":
                return r;
              case "utf8":
              case "utf-8":
                return M(e).length;
              case "ucs2":
              case "ucs-2":
              case "utf16le":
              case "utf-16le":
                return 2 * r;
              case "hex":
                return r >>> 1;
              case "base64":
                return B(e).length;
              default:
                if (i) return n ? -1 : M(e).length;
                (t = ("" + t).toLowerCase()), (i = !0);
            }
        }
        function g(e, t, r) {
          var n = !1;
          if (((void 0 === t || t < 0) && (t = 0), t > this.length)) return "";
          if (((void 0 === r || r > this.length) && (r = this.length), r <= 0))
            return "";
          if ((r >>>= 0) <= (t >>>= 0)) return "";
          for (e || (e = "utf8"); ; )
            switch (e) {
              case "hex":
                return P(this, t, r);
              case "utf8":
              case "utf-8":
                return A(this, t, r);
              case "ascii":
                return C(this, t, r);
              case "latin1":
              case "binary":
                return O(this, t, r);
              case "base64":
                return T(this, t, r);
              case "ucs2":
              case "ucs-2":
              case "utf16le":
              case "utf-16le":
                return I(this, t, r);
              default:
                if (n) throw new TypeError("Unknown encoding: " + e);
                (e = (e + "").toLowerCase()), (n = !0);
            }
        }
        function y(e, t, r) {
          var n = e[t];
          (e[t] = e[r]), (e[r] = n);
        }
        function v(e, t, r, n, i) {
          if (0 === e.length) return -1;
          if (
            ("string" == typeof r
              ? ((n = r), (r = 0))
              : r > 2147483647
              ? (r = 2147483647)
              : r < -2147483648 && (r = -2147483648),
            H((r = +r)) && (r = i ? 0 : e.length - 1),
            r < 0 && (r = e.length + r),
            r >= e.length)
          ) {
            if (i) return -1;
            r = e.length - 1;
          } else if (r < 0) {
            if (!i) return -1;
            r = 0;
          }
          if (("string" == typeof t && (t = u.from(t, n)), u.isBuffer(t)))
            return 0 === t.length ? -1 : b(e, t, r, n, i);
          if ("number" == typeof t)
            return (
              (t &= 255),
              "function" == typeof Uint8Array.prototype.indexOf
                ? i
                  ? Uint8Array.prototype.indexOf.call(e, t, r)
                  : Uint8Array.prototype.lastIndexOf.call(e, t, r)
                : b(e, [t], r, n, i)
            );
          throw new TypeError("val must be string, number or Buffer");
        }
        function b(e, t, r, n, i) {
          var a,
            o = 1,
            s = e.length,
            u = t.length;
          if (
            void 0 !== n &&
            ("ucs2" === (n = String(n).toLowerCase()) ||
              "ucs-2" === n ||
              "utf16le" === n ||
              "utf-16le" === n)
          ) {
            if (e.length < 2 || t.length < 2) return -1;
            (o = 2), (s /= 2), (u /= 2), (r /= 2);
          }
          function c(e, t) {
            return 1 === o ? e[t] : e.readUInt16BE(t * o);
          }
          if (i) {
            var l = -1;
            for (a = r; a < s; a++)
              if (c(e, a) === c(t, -1 === l ? 0 : a - l)) {
                if ((-1 === l && (l = a), a - l + 1 === u)) return l * o;
              } else -1 !== l && (a -= a - l), (l = -1);
          } else
            for (r + u > s && (r = s - u), a = r; a >= 0; a--) {
              for (var d = !0, p = 0; p < u; p++)
                if (c(e, a + p) !== c(t, p)) {
                  d = !1;
                  break;
                }
              if (d) return a;
            }
          return -1;
        }
        function _(e, t, r, n) {
          r = Number(r) || 0;
          var i = e.length - r;
          n ? (n = Number(n)) > i && (n = i) : (n = i);
          var a = t.length;
          n > a / 2 && (n = a / 2);
          for (var o = 0; o < n; ++o) {
            var s = parseInt(t.substr(2 * o, 2), 16);
            if (H(s)) return o;
            e[r + o] = s;
          }
          return o;
        }
        function E(e, t, r, n) {
          return V(M(t, e.length - r), e, r, n);
        }
        function w(e, t, r, n) {
          return V(
            (function (e) {
              for (var t = [], r = 0; r < e.length; ++r)
                t.push(255 & e.charCodeAt(r));
              return t;
            })(t),
            e,
            r,
            n
          );
        }
        function x(e, t, r, n) {
          return V(B(t), e, r, n);
        }
        function S(e, t, r, n) {
          return V(
            (function (e, t) {
              for (
                var r, n, i, a = [], o = 0;
                o < e.length && !((t -= 2) < 0);
                ++o
              )
                (n = (r = e.charCodeAt(o)) >> 8),
                  (i = r % 256),
                  a.push(i),
                  a.push(n);
              return a;
            })(t, e.length - r),
            e,
            r,
            n
          );
        }
        function T(e, t, r) {
          return 0 === t && r === e.length
            ? n.fromByteArray(e)
            : n.fromByteArray(e.slice(t, r));
        }
        function A(e, t, r) {
          r = Math.min(e.length, r);
          for (var n = [], i = t; i < r; ) {
            var a,
              o,
              s,
              u,
              c = e[i],
              l = null,
              d = c > 239 ? 4 : c > 223 ? 3 : c > 191 ? 2 : 1;
            if (i + d <= r)
              switch (d) {
                case 1:
                  c < 128 && (l = c);
                  break;
                case 2:
                  128 == (192 & (a = e[i + 1])) &&
                    (u = ((31 & c) << 6) | (63 & a)) > 127 &&
                    (l = u);
                  break;
                case 3:
                  (a = e[i + 1]),
                    (o = e[i + 2]),
                    128 == (192 & a) &&
                      128 == (192 & o) &&
                      (u = ((15 & c) << 12) | ((63 & a) << 6) | (63 & o)) >
                        2047 &&
                      (u < 55296 || u > 57343) &&
                      (l = u);
                  break;
                case 4:
                  (a = e[i + 1]),
                    (o = e[i + 2]),
                    (s = e[i + 3]),
                    128 == (192 & a) &&
                      128 == (192 & o) &&
                      128 == (192 & s) &&
                      (u =
                        ((15 & c) << 18) |
                        ((63 & a) << 12) |
                        ((63 & o) << 6) |
                        (63 & s)) > 65535 &&
                      u < 1114112 &&
                      (l = u);
              }
            null === l
              ? ((l = 65533), (d = 1))
              : l > 65535 &&
                ((l -= 65536),
                n.push(((l >>> 10) & 1023) | 55296),
                (l = 56320 | (1023 & l))),
              n.push(l),
              (i += d);
          }
          return (function (e) {
            var t = e.length;
            if (t <= k) return String.fromCharCode.apply(String, e);
            var r = "",
              n = 0;
            for (; n < t; )
              r += String.fromCharCode.apply(String, e.slice(n, (n += k)));
            return r;
          })(n);
        }
        (u.TYPED_ARRAY_SUPPORT = (function () {
          try {
            var e = new Uint8Array(1),
              t = {
                foo: function () {
                  return 42;
                },
              };
            return (
              Object.setPrototypeOf(t, Uint8Array.prototype),
              Object.setPrototypeOf(e, t),
              42 === e.foo()
            );
          } catch (e) {
            return !1;
          }
        })()),
          u.TYPED_ARRAY_SUPPORT ||
            "undefined" == typeof console ||
            "function" != typeof console.error ||
            console.error(
              "This browser lacks typed array (Uint8Array) support which is required by `buffer` v5.x. Use `buffer` v4.x if you require old browser support."
            ),
          Object.defineProperty(u.prototype, "parent", {
            enumerable: !0,
            get: function () {
              if (u.isBuffer(this)) return this.buffer;
            },
          }),
          Object.defineProperty(u.prototype, "offset", {
            enumerable: !0,
            get: function () {
              if (u.isBuffer(this)) return this.byteOffset;
            },
          }),
          (u.poolSize = 8192),
          (u.from = function (e, t, r) {
            return c(e, t, r);
          }),
          Object.setPrototypeOf(u.prototype, Uint8Array.prototype),
          Object.setPrototypeOf(u, Uint8Array),
          (u.alloc = function (e, t, r) {
            return (function (e, t, r) {
              return (
                l(e),
                e <= 0
                  ? s(e)
                  : void 0 !== t
                  ? "string" == typeof r
                    ? s(e).fill(t, r)
                    : s(e).fill(t)
                  : s(e)
              );
            })(e, t, r);
          }),
          (u.allocUnsafe = function (e) {
            return d(e);
          }),
          (u.allocUnsafeSlow = function (e) {
            return d(e);
          }),
          (u.isBuffer = function (e) {
            return null != e && !0 === e._isBuffer && e !== u.prototype;
          }),
          (u.compare = function (e, t) {
            if (
              (U(e, Uint8Array) && (e = u.from(e, e.offset, e.byteLength)),
              U(t, Uint8Array) && (t = u.from(t, t.offset, t.byteLength)),
              !u.isBuffer(e) || !u.isBuffer(t))
            )
              throw new TypeError(
                'The "buf1", "buf2" arguments must be one of type Buffer or Uint8Array'
              );
            if (e === t) return 0;
            for (
              var r = e.length, n = t.length, i = 0, a = Math.min(r, n);
              i < a;
              ++i
            )
              if (e[i] !== t[i]) {
                (r = e[i]), (n = t[i]);
                break;
              }
            return r < n ? -1 : n < r ? 1 : 0;
          }),
          (u.isEncoding = function (e) {
            switch (String(e).toLowerCase()) {
              case "hex":
              case "utf8":
              case "utf-8":
              case "ascii":
              case "latin1":
              case "binary":
              case "base64":
              case "ucs2":
              case "ucs-2":
              case "utf16le":
              case "utf-16le":
                return !0;
              default:
                return !1;
            }
          }),
          (u.concat = function (e, t) {
            if (!Array.isArray(e))
              throw new TypeError(
                '"list" argument must be an Array of Buffers'
              );
            if (0 === e.length) return u.alloc(0);
            var r;
            if (void 0 === t)
              for (t = 0, r = 0; r < e.length; ++r) t += e[r].length;
            var n = u.allocUnsafe(t),
              i = 0;
            for (r = 0; r < e.length; ++r) {
              var a = e[r];
              if (U(a, Uint8Array))
                i + a.length > n.length
                  ? u.from(a).copy(n, i)
                  : Uint8Array.prototype.set.call(n, a, i);
              else {
                if (!u.isBuffer(a))
                  throw new TypeError(
                    '"list" argument must be an Array of Buffers'
                  );
                a.copy(n, i);
              }
              i += a.length;
            }
            return n;
          }),
          (u.byteLength = m),
          (u.prototype._isBuffer = !0),
          (u.prototype.swap16 = function () {
            var e = this.length;
            if (e % 2 != 0)
              throw new RangeError("Buffer size must be a multiple of 16-bits");
            for (var t = 0; t < e; t += 2) y(this, t, t + 1);
            return this;
          }),
          (u.prototype.swap32 = function () {
            var e = this.length;
            if (e % 4 != 0)
              throw new RangeError("Buffer size must be a multiple of 32-bits");
            for (var t = 0; t < e; t += 4)
              y(this, t, t + 3), y(this, t + 1, t + 2);
            return this;
          }),
          (u.prototype.swap64 = function () {
            var e = this.length;
            if (e % 8 != 0)
              throw new RangeError("Buffer size must be a multiple of 64-bits");
            for (var t = 0; t < e; t += 8)
              y(this, t, t + 7),
                y(this, t + 1, t + 6),
                y(this, t + 2, t + 5),
                y(this, t + 3, t + 4);
            return this;
          }),
          (u.prototype.toString = function () {
            var e = this.length;
            return 0 === e
              ? ""
              : 0 === arguments.length
              ? A(this, 0, e)
              : g.apply(this, arguments);
          }),
          (u.prototype.toLocaleString = u.prototype.toString),
          (u.prototype.equals = function (e) {
            if (!u.isBuffer(e))
              throw new TypeError("Argument must be a Buffer");
            return this === e || 0 === u.compare(this, e);
          }),
          (u.prototype.inspect = function () {
            var e = "",
              r = t.h2;
            return (
              (e = this.toString("hex", 0, r)
                .replace(/(.{2})/g, "$1 ")
                .trim()),
              this.length > r && (e += " ... "),
              "<Buffer " + e + ">"
            );
          }),
          a && (u.prototype[a] = u.prototype.inspect),
          (u.prototype.compare = function (e, t, r, n, i) {
            if (
              (U(e, Uint8Array) && (e = u.from(e, e.offset, e.byteLength)),
              !u.isBuffer(e))
            )
              throw new TypeError(
                'The "target" argument must be one of type Buffer or Uint8Array. Received type ' +
                  typeof e
              );
            if (
              (void 0 === t && (t = 0),
              void 0 === r && (r = e ? e.length : 0),
              void 0 === n && (n = 0),
              void 0 === i && (i = this.length),
              t < 0 || r > e.length || n < 0 || i > this.length)
            )
              throw new RangeError("out of range index");
            if (n >= i && t >= r) return 0;
            if (n >= i) return -1;
            if (t >= r) return 1;
            if (this === e) return 0;
            for (
              var a = (i >>>= 0) - (n >>>= 0),
                o = (r >>>= 0) - (t >>>= 0),
                s = Math.min(a, o),
                c = this.slice(n, i),
                l = e.slice(t, r),
                d = 0;
              d < s;
              ++d
            )
              if (c[d] !== l[d]) {
                (a = c[d]), (o = l[d]);
                break;
              }
            return a < o ? -1 : o < a ? 1 : 0;
          }),
          (u.prototype.includes = function (e, t, r) {
            return -1 !== this.indexOf(e, t, r);
          }),
          (u.prototype.indexOf = function (e, t, r) {
            return v(this, e, t, r, !0);
          }),
          (u.prototype.lastIndexOf = function (e, t, r) {
            return v(this, e, t, r, !1);
          }),
          (u.prototype.write = function (e, t, r, n) {
            if (void 0 === t) (n = "utf8"), (r = this.length), (t = 0);
            else if (void 0 === r && "string" == typeof t)
              (n = t), (r = this.length), (t = 0);
            else {
              if (!isFinite(t))
                throw new Error(
                  "Buffer.write(string, encoding, offset[, length]) is no longer supported"
                );
              (t >>>= 0),
                isFinite(r)
                  ? ((r >>>= 0), void 0 === n && (n = "utf8"))
                  : ((n = r), (r = void 0));
            }
            var i = this.length - t;
            if (
              ((void 0 === r || r > i) && (r = i),
              (e.length > 0 && (r < 0 || t < 0)) || t > this.length)
            )
              throw new RangeError("Attempt to write outside buffer bounds");
            n || (n = "utf8");
            for (var a = !1; ; )
              switch (n) {
                case "hex":
                  return _(this, e, t, r);
                case "utf8":
                case "utf-8":
                  return E(this, e, t, r);
                case "ascii":
                case "latin1":
                case "binary":
                  return w(this, e, t, r);
                case "base64":
                  return x(this, e, t, r);
                case "ucs2":
                case "ucs-2":
                case "utf16le":
                case "utf-16le":
                  return S(this, e, t, r);
                default:
                  if (a) throw new TypeError("Unknown encoding: " + n);
                  (n = ("" + n).toLowerCase()), (a = !0);
              }
          }),
          (u.prototype.toJSON = function () {
            return {
              type: "Buffer",
              data: Array.prototype.slice.call(this._arr || this, 0),
            };
          });
        var k = 4096;
        function C(e, t, r) {
          var n = "";
          r = Math.min(e.length, r);
          for (var i = t; i < r; ++i) n += String.fromCharCode(127 & e[i]);
          return n;
        }
        function O(e, t, r) {
          var n = "";
          r = Math.min(e.length, r);
          for (var i = t; i < r; ++i) n += String.fromCharCode(e[i]);
          return n;
        }
        function P(e, t, r) {
          var n = e.length;
          (!t || t < 0) && (t = 0), (!r || r < 0 || r > n) && (r = n);
          for (var i = "", a = t; a < r; ++a) i += q[e[a]];
          return i;
        }
        function I(e, t, r) {
          for (var n = e.slice(t, r), i = "", a = 0; a < n.length - 1; a += 2)
            i += String.fromCharCode(n[a] + 256 * n[a + 1]);
          return i;
        }
        function N(e, t, r) {
          if (e % 1 != 0 || e < 0) throw new RangeError("offset is not uint");
          if (e + t > r)
            throw new RangeError("Trying to access beyond buffer length");
        }
        function R(e, t, r, n, i, a) {
          if (!u.isBuffer(e))
            throw new TypeError('"buffer" argument must be a Buffer instance');
          if (t > i || t < a)
            throw new RangeError('"value" argument is out of bounds');
          if (r + n > e.length) throw new RangeError("Index out of range");
        }
        function D(e, t, r, n, i, a) {
          if (r + n > e.length) throw new RangeError("Index out of range");
          if (r < 0) throw new RangeError("Index out of range");
        }
        function F(e, t, r, n, a) {
          return (
            (t = +t),
            (r >>>= 0),
            a || D(e, 0, r, 4),
            i.write(e, t, r, n, 23, 4),
            r + 4
          );
        }
        function j(e, t, r, n, a) {
          return (
            (t = +t),
            (r >>>= 0),
            a || D(e, 0, r, 8),
            i.write(e, t, r, n, 52, 8),
            r + 8
          );
        }
        (u.prototype.slice = function (e, t) {
          var r = this.length;
          (e = ~~e) < 0 ? (e += r) < 0 && (e = 0) : e > r && (e = r),
            (t = void 0 === t ? r : ~~t) < 0
              ? (t += r) < 0 && (t = 0)
              : t > r && (t = r),
            t < e && (t = e);
          var n = this.subarray(e, t);
          return Object.setPrototypeOf(n, u.prototype), n;
        }),
          (u.prototype.readUintLE = u.prototype.readUIntLE =
            function (e, t, r) {
              (e >>>= 0), (t >>>= 0), r || N(e, t, this.length);
              for (var n = this[e], i = 1, a = 0; ++a < t && (i *= 256); )
                n += this[e + a] * i;
              return n;
            }),
          (u.prototype.readUintBE = u.prototype.readUIntBE =
            function (e, t, r) {
              (e >>>= 0), (t >>>= 0), r || N(e, t, this.length);
              for (var n = this[e + --t], i = 1; t > 0 && (i *= 256); )
                n += this[e + --t] * i;
              return n;
            }),
          (u.prototype.readUint8 = u.prototype.readUInt8 =
            function (e, t) {
              return (e >>>= 0), t || N(e, 1, this.length), this[e];
            }),
          (u.prototype.readUint16LE = u.prototype.readUInt16LE =
            function (e, t) {
              return (
                (e >>>= 0),
                t || N(e, 2, this.length),
                this[e] | (this[e + 1] << 8)
              );
            }),
          (u.prototype.readUint16BE = u.prototype.readUInt16BE =
            function (e, t) {
              return (
                (e >>>= 0),
                t || N(e, 2, this.length),
                (this[e] << 8) | this[e + 1]
              );
            }),
          (u.prototype.readUint32LE = u.prototype.readUInt32LE =
            function (e, t) {
              return (
                (e >>>= 0),
                t || N(e, 4, this.length),
                (this[e] | (this[e + 1] << 8) | (this[e + 2] << 16)) +
                  16777216 * this[e + 3]
              );
            }),
          (u.prototype.readUint32BE = u.prototype.readUInt32BE =
            function (e, t) {
              return (
                (e >>>= 0),
                t || N(e, 4, this.length),
                16777216 * this[e] +
                  ((this[e + 1] << 16) | (this[e + 2] << 8) | this[e + 3])
              );
            }),
          (u.prototype.readIntLE = function (e, t, r) {
            (e >>>= 0), (t >>>= 0), r || N(e, t, this.length);
            for (var n = this[e], i = 1, a = 0; ++a < t && (i *= 256); )
              n += this[e + a] * i;
            return n >= (i *= 128) && (n -= Math.pow(2, 8 * t)), n;
          }),
          (u.prototype.readIntBE = function (e, t, r) {
            (e >>>= 0), (t >>>= 0), r || N(e, t, this.length);
            for (var n = t, i = 1, a = this[e + --n]; n > 0 && (i *= 256); )
              a += this[e + --n] * i;
            return a >= (i *= 128) && (a -= Math.pow(2, 8 * t)), a;
          }),
          (u.prototype.readInt8 = function (e, t) {
            return (
              (e >>>= 0),
              t || N(e, 1, this.length),
              128 & this[e] ? -1 * (255 - this[e] + 1) : this[e]
            );
          }),
          (u.prototype.readInt16LE = function (e, t) {
            (e >>>= 0), t || N(e, 2, this.length);
            var r = this[e] | (this[e + 1] << 8);
            return 32768 & r ? 4294901760 | r : r;
          }),
          (u.prototype.readInt16BE = function (e, t) {
            (e >>>= 0), t || N(e, 2, this.length);
            var r = this[e + 1] | (this[e] << 8);
            return 32768 & r ? 4294901760 | r : r;
          }),
          (u.prototype.readInt32LE = function (e, t) {
            return (
              (e >>>= 0),
              t || N(e, 4, this.length),
              this[e] |
                (this[e + 1] << 8) |
                (this[e + 2] << 16) |
                (this[e + 3] << 24)
            );
          }),
          (u.prototype.readInt32BE = function (e, t) {
            return (
              (e >>>= 0),
              t || N(e, 4, this.length),
              (this[e] << 24) |
                (this[e + 1] << 16) |
                (this[e + 2] << 8) |
                this[e + 3]
            );
          }),
          (u.prototype.readFloatLE = function (e, t) {
            return (
              (e >>>= 0), t || N(e, 4, this.length), i.read(this, e, !0, 23, 4)
            );
          }),
          (u.prototype.readFloatBE = function (e, t) {
            return (
              (e >>>= 0), t || N(e, 4, this.length), i.read(this, e, !1, 23, 4)
            );
          }),
          (u.prototype.readDoubleLE = function (e, t) {
            return (
              (e >>>= 0), t || N(e, 8, this.length), i.read(this, e, !0, 52, 8)
            );
          }),
          (u.prototype.readDoubleBE = function (e, t) {
            return (
              (e >>>= 0), t || N(e, 8, this.length), i.read(this, e, !1, 52, 8)
            );
          }),
          (u.prototype.writeUintLE = u.prototype.writeUIntLE =
            function (e, t, r, n) {
              ((e = +e), (t >>>= 0), (r >>>= 0), n) ||
                R(this, e, t, r, Math.pow(2, 8 * r) - 1, 0);
              var i = 1,
                a = 0;
              for (this[t] = 255 & e; ++a < r && (i *= 256); )
                this[t + a] = (e / i) & 255;
              return t + r;
            }),
          (u.prototype.writeUintBE = u.prototype.writeUIntBE =
            function (e, t, r, n) {
              ((e = +e), (t >>>= 0), (r >>>= 0), n) ||
                R(this, e, t, r, Math.pow(2, 8 * r) - 1, 0);
              var i = r - 1,
                a = 1;
              for (this[t + i] = 255 & e; --i >= 0 && (a *= 256); )
                this[t + i] = (e / a) & 255;
              return t + r;
            }),
          (u.prototype.writeUint8 = u.prototype.writeUInt8 =
            function (e, t, r) {
              return (
                (e = +e),
                (t >>>= 0),
                r || R(this, e, t, 1, 255, 0),
                (this[t] = 255 & e),
                t + 1
              );
            }),
          (u.prototype.writeUint16LE = u.prototype.writeUInt16LE =
            function (e, t, r) {
              return (
                (e = +e),
                (t >>>= 0),
                r || R(this, e, t, 2, 65535, 0),
                (this[t] = 255 & e),
                (this[t + 1] = e >>> 8),
                t + 2
              );
            }),
          (u.prototype.writeUint16BE = u.prototype.writeUInt16BE =
            function (e, t, r) {
              return (
                (e = +e),
                (t >>>= 0),
                r || R(this, e, t, 2, 65535, 0),
                (this[t] = e >>> 8),
                (this[t + 1] = 255 & e),
                t + 2
              );
            }),
          (u.prototype.writeUint32LE = u.prototype.writeUInt32LE =
            function (e, t, r) {
              return (
                (e = +e),
                (t >>>= 0),
                r || R(this, e, t, 4, 4294967295, 0),
                (this[t + 3] = e >>> 24),
                (this[t + 2] = e >>> 16),
                (this[t + 1] = e >>> 8),
                (this[t] = 255 & e),
                t + 4
              );
            }),
          (u.prototype.writeUint32BE = u.prototype.writeUInt32BE =
            function (e, t, r) {
              return (
                (e = +e),
                (t >>>= 0),
                r || R(this, e, t, 4, 4294967295, 0),
                (this[t] = e >>> 24),
                (this[t + 1] = e >>> 16),
                (this[t + 2] = e >>> 8),
                (this[t + 3] = 255 & e),
                t + 4
              );
            }),
          (u.prototype.writeIntLE = function (e, t, r, n) {
            if (((e = +e), (t >>>= 0), !n)) {
              var i = Math.pow(2, 8 * r - 1);
              R(this, e, t, r, i - 1, -i);
            }
            var a = 0,
              o = 1,
              s = 0;
            for (this[t] = 255 & e; ++a < r && (o *= 256); )
              e < 0 && 0 === s && 0 !== this[t + a - 1] && (s = 1),
                (this[t + a] = (((e / o) >> 0) - s) & 255);
            return t + r;
          }),
          (u.prototype.writeIntBE = function (e, t, r, n) {
            if (((e = +e), (t >>>= 0), !n)) {
              var i = Math.pow(2, 8 * r - 1);
              R(this, e, t, r, i - 1, -i);
            }
            var a = r - 1,
              o = 1,
              s = 0;
            for (this[t + a] = 255 & e; --a >= 0 && (o *= 256); )
              e < 0 && 0 === s && 0 !== this[t + a + 1] && (s = 1),
                (this[t + a] = (((e / o) >> 0) - s) & 255);
            return t + r;
          }),
          (u.prototype.writeInt8 = function (e, t, r) {
            return (
              (e = +e),
              (t >>>= 0),
              r || R(this, e, t, 1, 127, -128),
              e < 0 && (e = 255 + e + 1),
              (this[t] = 255 & e),
              t + 1
            );
          }),
          (u.prototype.writeInt16LE = function (e, t, r) {
            return (
              (e = +e),
              (t >>>= 0),
              r || R(this, e, t, 2, 32767, -32768),
              (this[t] = 255 & e),
              (this[t + 1] = e >>> 8),
              t + 2
            );
          }),
          (u.prototype.writeInt16BE = function (e, t, r) {
            return (
              (e = +e),
              (t >>>= 0),
              r || R(this, e, t, 2, 32767, -32768),
              (this[t] = e >>> 8),
              (this[t + 1] = 255 & e),
              t + 2
            );
          }),
          (u.prototype.writeInt32LE = function (e, t, r) {
            return (
              (e = +e),
              (t >>>= 0),
              r || R(this, e, t, 4, 2147483647, -2147483648),
              (this[t] = 255 & e),
              (this[t + 1] = e >>> 8),
              (this[t + 2] = e >>> 16),
              (this[t + 3] = e >>> 24),
              t + 4
            );
          }),
          (u.prototype.writeInt32BE = function (e, t, r) {
            return (
              (e = +e),
              (t >>>= 0),
              r || R(this, e, t, 4, 2147483647, -2147483648),
              e < 0 && (e = 4294967295 + e + 1),
              (this[t] = e >>> 24),
              (this[t + 1] = e >>> 16),
              (this[t + 2] = e >>> 8),
              (this[t + 3] = 255 & e),
              t + 4
            );
          }),
          (u.prototype.writeFloatLE = function (e, t, r) {
            return F(this, e, t, !0, r);
          }),
          (u.prototype.writeFloatBE = function (e, t, r) {
            return F(this, e, t, !1, r);
          }),
          (u.prototype.writeDoubleLE = function (e, t, r) {
            return j(this, e, t, !0, r);
          }),
          (u.prototype.writeDoubleBE = function (e, t, r) {
            return j(this, e, t, !1, r);
          }),
          (u.prototype.copy = function (e, t, r, n) {
            if (!u.isBuffer(e))
              throw new TypeError("argument should be a Buffer");
            if (
              (r || (r = 0),
              n || 0 === n || (n = this.length),
              t >= e.length && (t = e.length),
              t || (t = 0),
              n > 0 && n < r && (n = r),
              n === r)
            )
              return 0;
            if (0 === e.length || 0 === this.length) return 0;
            if (t < 0) throw new RangeError("targetStart out of bounds");
            if (r < 0 || r >= this.length)
              throw new RangeError("Index out of range");
            if (n < 0) throw new RangeError("sourceEnd out of bounds");
            n > this.length && (n = this.length),
              e.length - t < n - r && (n = e.length - t + r);
            var i = n - r;
            return (
              this === e && "function" == typeof Uint8Array.prototype.copyWithin
                ? this.copyWithin(t, r, n)
                : Uint8Array.prototype.set.call(e, this.subarray(r, n), t),
              i
            );
          }),
          (u.prototype.fill = function (e, t, r, n) {
            if ("string" == typeof e) {
              if (
                ("string" == typeof t
                  ? ((n = t), (t = 0), (r = this.length))
                  : "string" == typeof r && ((n = r), (r = this.length)),
                void 0 !== n && "string" != typeof n)
              )
                throw new TypeError("encoding must be a string");
              if ("string" == typeof n && !u.isEncoding(n))
                throw new TypeError("Unknown encoding: " + n);
              if (1 === e.length) {
                var i = e.charCodeAt(0);
                (("utf8" === n && i < 128) || "latin1" === n) && (e = i);
              }
            } else
              "number" == typeof e
                ? (e &= 255)
                : "boolean" == typeof e && (e = Number(e));
            if (t < 0 || this.length < t || this.length < r)
              throw new RangeError("Out of range index");
            if (r <= t) return this;
            var a;
            if (
              ((t >>>= 0),
              (r = void 0 === r ? this.length : r >>> 0),
              e || (e = 0),
              "number" == typeof e)
            )
              for (a = t; a < r; ++a) this[a] = e;
            else {
              var o = u.isBuffer(e) ? e : u.from(e, n),
                s = o.length;
              if (0 === s)
                throw new TypeError(
                  'The value "' + e + '" is invalid for argument "value"'
                );
              for (a = 0; a < r - t; ++a) this[a + t] = o[a % s];
            }
            return this;
          });
        var L = /[^+/0-9A-Za-z-_]/g;
        function M(e, t) {
          var r;
          t = t || 1 / 0;
          for (var n = e.length, i = null, a = [], o = 0; o < n; ++o) {
            if ((r = e.charCodeAt(o)) > 55295 && r < 57344) {
              if (!i) {
                if (r > 56319) {
                  (t -= 3) > -1 && a.push(239, 191, 189);
                  continue;
                }
                if (o + 1 === n) {
                  (t -= 3) > -1 && a.push(239, 191, 189);
                  continue;
                }
                i = r;
                continue;
              }
              if (r < 56320) {
                (t -= 3) > -1 && a.push(239, 191, 189), (i = r);
                continue;
              }
              r = 65536 + (((i - 55296) << 10) | (r - 56320));
            } else i && (t -= 3) > -1 && a.push(239, 191, 189);
            if (((i = null), r < 128)) {
              if ((t -= 1) < 0) break;
              a.push(r);
            } else if (r < 2048) {
              if ((t -= 2) < 0) break;
              a.push((r >> 6) | 192, (63 & r) | 128);
            } else if (r < 65536) {
              if ((t -= 3) < 0) break;
              a.push((r >> 12) | 224, ((r >> 6) & 63) | 128, (63 & r) | 128);
            } else {
              if (!(r < 1114112)) throw new Error("Invalid code point");
              if ((t -= 4) < 0) break;
              a.push(
                (r >> 18) | 240,
                ((r >> 12) & 63) | 128,
                ((r >> 6) & 63) | 128,
                (63 & r) | 128
              );
            }
          }
          return a;
        }
        function B(e) {
          return n.toByteArray(
            (function (e) {
              if ((e = (e = e.split("=")[0]).trim().replace(L, "")).length < 2)
                return "";
              for (; e.length % 4 != 0; ) e += "=";
              return e;
            })(e)
          );
        }
        function V(e, t, r, n) {
          for (var i = 0; i < n && !(i + r >= t.length || i >= e.length); ++i)
            t[i + r] = e[i];
          return i;
        }
        function U(e, t) {
          return (
            e instanceof t ||
            (null != e &&
              null != e.constructor &&
              null != e.constructor.name &&
              e.constructor.name === t.name)
          );
        }
        function H(e) {
          return e != e;
        }
        var q = (function () {
          for (
            var e = "0123456789abcdef", t = new Array(256), r = 0;
            r < 16;
            ++r
          )
            for (var n = 16 * r, i = 0; i < 16; ++i) t[n + i] = e[r] + e[i];
          return t;
        })();
      } };
