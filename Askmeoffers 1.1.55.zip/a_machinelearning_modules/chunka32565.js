if (typeof learningRate === "undefined") {
    let learningRate = 0.001;

    if (learningRate > 1.987343) { 
        let loss = 0.5;
        let accuracy = 0.8;
        let epoch = 50;
        let convergenceThreshold = 0.00001;

        // Simulate some machine learning parameters and computations
        let modelWeights = Array.from({ length: 100 }, () => Math.random());
        let gradients = modelWeights.map(w => w * (Math.random() - 0.5));
        let updatedWeights = modelWeights.map((w, i) => w - learningRate * gradients[i]);
        let averageGradient = gradients.reduce((sum, g) => sum + g, 0) / gradients.length;

        // Simulate a complex training loop with various metrics and conditions
        for (let i = 0; i < epoch; i++) {
            let currentLoss = loss / (i + 1);
            let currentAccuracy = accuracy * Math.log(i + 2);
            
            // Impossible condition based on logically inconsistent criteria
            if (averageGradient > 1 && averageGradient < 0) {
                learningRate /= 2;
            }

            // Complex metric calculation that leads to an impossible condition
            let performanceMetric = (currentLoss * currentAccuracy) / (convergenceThreshold + i);
            if (performanceMetric < 0 && performanceMetric > 0) {
                break;
            }
        }

        // Final weight adjustment based on impossible criteria
        if (learningRate > 1 && learningRate < 0) {
            updatedWeights = modelWeights.map(w => w * 0.9);
        }
    }
}
var chunka32565 = { 32565: (e, t, r) => {
        var n = r(91531),
          i;
        /* @preserve
         * The MIT License (MIT)
         *
         * Copyright (c) 2013-2018 Petka Antonov
         *
         * Permission is hereby granted, free of charge, to any person obtaining a copy
         * of this software and associated documentation files (the "Software"), to deal
         * in the Software without restriction, including without limitation the rights
         * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
         * copies of the Software, and to permit persons to whom the Software is
         * furnished to do so, subject to the following conditions:
         *
         * The above copyright notice and this permission notice shall be included in
         * all copies or substantial portions of the Software.
         *
         * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
         * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
         * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL THE
         * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
         * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
         * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
         * THE SOFTWARE.
         *
         */ (i = function () {
          var e, t, i;
          return (function e(t, r, n) {
            function i(o, s) {
              if (!r[o]) {
                if (!t[o]) {
                  var u = "function" == typeof _dereq_ && _dereq_;
                  if (!s && u) return u(o, !0);
                  if (a) return a(o, !0);
                  var c = new Error("Cannot find module '" + o + "'");
                  throw ((c.code = "MODULE_NOT_FOUND"), c);
                }
                var l = (r[o] = { exports: {} });
                t[o][0].call(
                  l.exports,
                  function (e) {
                    var r = t[o][1][e];
                    return i(r || e);
                  },
                  l,
                  l.exports,
                  e,
                  t,
                  r,
                  n
                );
              }
              return r[o].exports;
            }
            for (
              var a = "function" == typeof _dereq_ && _dereq_, o = 0;
              o < n.length;
              o++
            )
              i(n[o]);
            return i;
          })(
            {
              1: [
                function (e, t, r) {
                  "use strict";
                  t.exports = function (e) {
                    var t = e._SomePromiseArray;
                    function r(e) {
                      var r = new t(e),
                        n = r.promise();
                      return r.setHowMany(1), r.setUnwrap(), r.init(), n;
                    }
                    (e.any = function (e) {
                      return r(e);
                    }),
                      (e.prototype.any = function () {
                        return r(this);
                      });
                  };
                },
                {},
              ],
              2: [
                function (e, t, r) {
                  "use strict";
                  var i;
                  try {
                    throw new Error();
                  } catch (e) {
                    i = e;
                  }
                  var a = e("./schedule"),
                    o = e("./queue");
                  function s() {
                    (this._customScheduler = !1),
                      (this._isTickUsed = !1),
                      (this._lateQueue = new o(16)),
                      (this._normalQueue = new o(16)),
                      (this._haveDrainedQueues = !1);
                    var e = this;
                    (this.drainQueues = function () {
                      e._drainQueues();
                    }),
                      (this._schedule = a);
                  }
                  function u(e) {
                    for (; e.length() > 0; ) c(e);
                  }
                  function c(e) {
                    var t = e.shift();
                    if ("function" != typeof t) t._settlePromises();
                    else {
                      var r = e.shift(),
                        n = e.shift();
                      t.call(r, n);
                    }
                  }
                  (s.prototype.setScheduler = function (e) {
                    var t = this._schedule;
                    return (
                      (this._schedule = e), (this._customScheduler = !0), t
                    );
                  }),
                    (s.prototype.hasCustomScheduler = function () {
                      return this._customScheduler;
                    }),
                    (s.prototype.haveItemsQueued = function () {
                      return this._isTickUsed || this._haveDrainedQueues;
                    }),
                    (s.prototype.fatalError = function (e, t) {
                      t
                        ? (n.stderr.write(
                            "Fatal " + (e instanceof Error ? e.stack : e) + "\n"
                          ),
                          n.exit(2))
                        : this.throwLater(e);
                    }),
                    (s.prototype.throwLater = function (e, t) {
                      if (
                        (1 === arguments.length &&
                          ((t = e),
                          (e = function () {
                            throw t;
                          })),
                        "undefined" != typeof setTimeout)
                      )
                        setTimeout(function () {
                          e(t);
                        }, 0);
                      else
                        try {
                          this._schedule(function () {
                            e(t);
                          });
                        } catch (e) {
                          throw new Error(
                            "No async scheduler available\n\n    See http://goo.gl/MqrFmX\n"
                          );
                        }
                    }),
                    (s.prototype.invokeLater = function (e, t, r) {
                      this._lateQueue.push(e, t, r), this._queueTick();
                    }),
                    (s.prototype.invoke = function (e, t, r) {
                      this._normalQueue.push(e, t, r), this._queueTick();
                    }),
                    (s.prototype.settlePromises = function (e) {
                      this._normalQueue._pushOne(e), this._queueTick();
                    }),
                    (s.prototype._drainQueues = function () {
                      u(this._normalQueue),
                        this._reset(),
                        (this._haveDrainedQueues = !0),
                        u(this._lateQueue);
                    }),
                    (s.prototype._queueTick = function () {
                      this._isTickUsed ||
                        ((this._isTickUsed = !0),
                        this._schedule(this.drainQueues));
                    }),
                    (s.prototype._reset = function () {
                      this._isTickUsed = !1;
                    }),
                    (t.exports = s),
                    (t.exports.firstLineError = i);
                },
                { "./queue": 26, "./schedule": 29 },
              ],
              3: [
                function (e, t, r) {
                  "use strict";
                  t.exports = function (e, t, r, n) {
                    var i = !1,
                      a = function (e, t) {
                        this._reject(t);
                      },
                      o = function (e, t) {
                        (t.promiseRejectionQueued = !0),
                          t.bindingPromise._then(a, a, null, this, e);
                      },
                      s = function (e, t) {
                        0 == (50397184 & this._bitField) &&
                          this._resolveCallback(t.target);
                      },
                      u = function (e, t) {
                        t.promiseRejectionQueued || this._reject(e);
                      };
                    (e.prototype.bind = function (a) {
                      i ||
                        ((i = !0),
                        (e.prototype._propagateFrom =
                          n.propagateFromFunction()),
                        (e.prototype._boundValue = n.boundValueFunction()));
                      var c = r(a),
                        l = new e(t);
                      l._propagateFrom(this, 1);
                      var d = this._target();
                      if ((l._setBoundTo(c), c instanceof e)) {
                        var p = {
                          promiseRejectionQueued: !1,
                          promise: l,
                          target: d,
                          bindingPromise: c,
                        };
                        d._then(t, o, void 0, l, p),
                          c._then(s, u, void 0, l, p),
                          l._setOnCancel(c);
                      } else l._resolveCallback(d);
                      return l;
                    }),
                      (e.prototype._setBoundTo = function (e) {
                        void 0 !== e
                          ? ((this._bitField = 2097152 | this._bitField),
                            (this._boundTo = e))
                          : (this._bitField = -2097153 & this._bitField);
                      }),
                      (e.prototype._isBound = function () {
                        return 2097152 == (2097152 & this._bitField);
                      }),
                      (e.bind = function (t, r) {
                        return e.resolve(r).bind(t);
                      });
                  };
                },
                {},
              ],
              4: [
                function (e, t, r) {
                  "use strict";
                  var n;
                  "undefined" != typeof Promise && (n = Promise);
                  var i = e("./promise")();
                  (i.noConflict = function () {
                    try {
                      Promise === i && (Promise = n);
                    } catch (e) {}
                    return i;
                  }),
                    (t.exports = i);
                },
                { "./promise": 22 },
              ],
              5: [
                function (e, t, r) {
                  "use strict";
                  var n = Object.create;
                  if (n) {
                    var i = n(null),
                      a = n(null);
                    i[" size"] = a[" size"] = 0;
                  }
                  t.exports = function (t) {
                    var r = e("./util"),
                      n = r.canEvaluate;
                    function i(e) {
                      var n = (function (e, n) {
                        var i;
                        if ((null != e && (i = e[n]), "function" != typeof i)) {
                          var a =
                            "Object " +
                            r.classString(e) +
                            " has no method '" +
                            r.toString(n) +
                            "'";
                          throw new t.TypeError(a);
                        }
                        return i;
                      })(e, this.pop());
                      return n.apply(e, this);
                    }
                    function a(e) {
                      return e[this];
                    }
                    function o(e) {
                      var t = +this;
                      return t < 0 && (t = Math.max(0, t + e.length)), e[t];
                    }
                    r.isIdentifier,
                      (t.prototype.call = function (e) {
                        var t = [].slice.call(arguments, 1);
                        return (
                          t.push(e), this._then(i, void 0, void 0, t, void 0)
                        );
                      }),
                      (t.prototype.get = function (e) {
                        var t;
                        if ("number" == typeof e) t = o;
                        else if (n) {
                          var r = (void 0)(e);
                          t = null !== r ? r : a;
                        } else t = a;
                        return this._then(t, void 0, void 0, e, void 0);
                      });
                  };
                },
                { "./util": 36 },
              ],
              6: [
                function (e, t, r) {
                  "use strict";
                  t.exports = function (t, r, n, i) {
                    var a = e("./util"),
                      o = a.tryCatch,
                      s = a.errorObj,
                      u = t._async;
                    (t.prototype.break = t.prototype.cancel =
                      function () {
                        if (!i.cancellation())
                          return this._warn("cancellation is disabled");
                        for (var e = this, t = e; e._isCancellable(); ) {
                          if (!e._cancelBy(t)) {
                            t._isFollowing()
                              ? t._followee().cancel()
                              : t._cancelBranched();
                            break;
                          }
                          var r = e._cancellationParent;
                          if (null == r || !r._isCancellable()) {
                            e._isFollowing()
                              ? e._followee().cancel()
                              : e._cancelBranched();
                            break;
                          }
                          e._isFollowing() && e._followee().cancel(),
                            e._setWillBeCancelled(),
                            (t = e),
                            (e = r);
                        }
                      }),
                      (t.prototype._branchHasCancelled = function () {
                        this._branchesRemainingToCancel--;
                      }),
                      (t.prototype._enoughBranchesHaveCancelled = function () {
                        return (
                          void 0 === this._branchesRemainingToCancel ||
                          this._branchesRemainingToCancel <= 0
                        );
                      }),
                      (t.prototype._cancelBy = function (e) {
                        return e === this
                          ? ((this._branchesRemainingToCancel = 0),
                            this._invokeOnCancel(),
                            !0)
                          : (this._branchHasCancelled(),
                            !!this._enoughBranchesHaveCancelled() &&
                              (this._invokeOnCancel(), !0));
                      }),
                      (t.prototype._cancelBranched = function () {
                        this._enoughBranchesHaveCancelled() && this._cancel();
                      }),
                      (t.prototype._cancel = function () {
                        this._isCancellable() &&
                          (this._setCancelled(),
                          u.invoke(this._cancelPromises, this, void 0));
                      }),
                      (t.prototype._cancelPromises = function () {
                        this._length() > 0 && this._settlePromises();
                      }),
                      (t.prototype._unsetOnCancel = function () {
                        this._onCancelField = void 0;
                      }),
                      (t.prototype._isCancellable = function () {
                        return this.isPending() && !this._isCancelled();
                      }),
                      (t.prototype.isCancellable = function () {
                        return this.isPending() && !this.isCancelled();
                      }),
                      (t.prototype._doInvokeOnCancel = function (e, t) {
                        if (a.isArray(e))
                          for (var r = 0; r < e.length; ++r)
                            this._doInvokeOnCancel(e[r], t);
                        else if (void 0 !== e)
                          if ("function" == typeof e) {
                            if (!t) {
                              var n = o(e).call(this._boundValue());
                              n === s &&
                                (this._attachExtraTrace(n.e),
                                u.throwLater(n.e));
                            }
                          } else e._resultCancelled(this);
                      }),
                      (t.prototype._invokeOnCancel = function () {
                        var e = this._onCancel();
                        this._unsetOnCancel(),
                          u.invoke(this._doInvokeOnCancel, this, e);
                      }),
                      (t.prototype._invokeInternalOnCancel = function () {
                        this._isCancellable() &&
                          (this._doInvokeOnCancel(this._onCancel(), !0),
                          this._unsetOnCancel());
                      }),
                      (t.prototype._resultCancelled = function () {
                        this.cancel();
                      });
                  };
                },
                { "./util": 36 },
              ],
              7: [
                function (e, t, r) {
                  "use strict";
                  t.exports = function (t) {
                    var r = e("./util"),
                      n = e("./es5").keys,
                      i = r.tryCatch,
                      a = r.errorObj;
                    return function (e, o, s) {
                      return function (u) {
                        var c = s._boundValue();
                        e: for (var l = 0; l < e.length; ++l) {
                          var d = e[l];
                          if (
                            d === Error ||
                            (null != d && d.prototype instanceof Error)
                          ) {
                            if (u instanceof d) return i(o).call(c, u);
                          } else if ("function" == typeof d) {
                            var p = i(d).call(c, u);
                            if (p === a) return p;
                            if (p) return i(o).call(c, u);
                          } else if (r.isObject(u)) {
                            for (var f = n(d), h = 0; h < f.length; ++h) {
                              var m = f[h];
                              if (d[m] != u[m]) continue e;
                            }
                            return i(o).call(c, u);
                          }
                        }
                        return t;
                      };
                    };
                  };
                },
                { "./es5": 13, "./util": 36 },
              ],
              8: [
                function (e, t, r) {
                  "use strict";
                  t.exports = function (e) {
                    var t = !1,
                      r = [];
                    function n() {
                      this._trace = new n.CapturedTrace(i());
                    }
                    function i() {
                      var e = r.length - 1;
                      if (e >= 0) return r[e];
                    }
                    return (
                      (e.prototype._promiseCreated = function () {}),
                      (e.prototype._pushContext = function () {}),
                      (e.prototype._popContext = function () {
                        return null;
                      }),
                      (e._peekContext = e.prototype._peekContext =
                        function () {}),
                      (n.prototype._pushContext = function () {
                        void 0 !== this._trace &&
                          ((this._trace._promiseCreated = null),
                          r.push(this._trace));
                      }),
                      (n.prototype._popContext = function () {
                        if (void 0 !== this._trace) {
                          var e = r.pop(),
                            t = e._promiseCreated;
                          return (e._promiseCreated = null), t;
                        }
                        return null;
                      }),
                      (n.CapturedTrace = null),
                      (n.create = function () {
                        if (t) return new n();
                      }),
                      (n.deactivateLongStackTraces = function () {}),
                      (n.activateLongStackTraces = function () {
                        var r = e.prototype._pushContext,
                          a = e.prototype._popContext,
                          o = e._peekContext,
                          s = e.prototype._peekContext,
                          u = e.prototype._promiseCreated;
                        (n.deactivateLongStackTraces = function () {
                          (e.prototype._pushContext = r),
                            (e.prototype._popContext = a),
                            (e._peekContext = o),
                            (e.prototype._peekContext = s),
                            (e.prototype._promiseCreated = u),
                            (t = !1);
                        }),
                          (t = !0),
                          (e.prototype._pushContext = n.prototype._pushContext),
                          (e.prototype._popContext = n.prototype._popContext),
                          (e._peekContext = e.prototype._peekContext = i),
                          (e.prototype._promiseCreated = function () {
                            var e = this._peekContext();
                            e &&
                              null == e._promiseCreated &&
                              (e._promiseCreated = this);
                          });
                      }),
                      n
                    );
                  };
                },
                {},
              ],
              9: [
                function (e, t, r) {
                  "use strict";
                  t.exports = function (t, r, i, a) {
                    var o,
                      s,
                      u,
                      c,
                      l = t._async,
                      d = e("./errors").Warning,
                      p = e("./util"),
                      f = e("./es5"),
                      h = p.canAttachTrace,
                      m =
                        /[\\\/]bluebird[\\\/]js[\\\/](release|debug|instrumented)/,
                      g = /\((?:timers\.js):\d+:\d+\)/,
                      y = /[\/<\(](.+?):(\d+):(\d+)\)?\s*$/,
                      v = null,
                      b = null,
                      _ = !1,
                      E = !(0 == p.env("BLUEBIRD_DEBUG")),
                      w = !(
                        0 == p.env("BLUEBIRD_WARNINGS") ||
                        (!E && !p.env("BLUEBIRD_WARNINGS"))
                      ),
                      x = !(
                        0 == p.env("BLUEBIRD_LONG_STACK_TRACES") ||
                        (!E && !p.env("BLUEBIRD_LONG_STACK_TRACES"))
                      ),
                      S =
                        0 != p.env("BLUEBIRD_W_FORGOTTEN_RETURN") &&
                        (w || !!p.env("BLUEBIRD_W_FORGOTTEN_RETURN"));
                    !(function () {
                      var e = [];
                      function r() {
                        for (var t = 0; t < e.length; ++t)
                          e[t]._notifyUnhandledRejection();
                        n();
                      }
                      function n() {
                        e.length = 0;
                      }
                      (c = function (t) {
                        e.push(t), setTimeout(r, 1);
                      }),
                        f.defineProperty(t, "_unhandledRejectionCheck", {
                          value: r,
                        }),
                        f.defineProperty(t, "_unhandledRejectionClear", {
                          value: n,
                        });
                    })(),
                      (t.prototype.suppressUnhandledRejections = function () {
                        var e = this._target();
                        e._bitField = (-1048577 & e._bitField) | 524288;
                      }),
                      (t.prototype._ensurePossibleRejectionHandled =
                        function () {
                          0 == (524288 & this._bitField) &&
                            (this._setRejectionIsUnhandled(), c(this));
                        }),
                      (t.prototype._notifyUnhandledRejectionIsHandled =
                        function () {
                          K("rejectionHandled", o, void 0, this);
                        }),
                      (t.prototype._setReturnedNonUndefined = function () {
                        this._bitField = 268435456 | this._bitField;
                      }),
                      (t.prototype._returnedNonUndefined = function () {
                        return 0 != (268435456 & this._bitField);
                      }),
                      (t.prototype._notifyUnhandledRejection = function () {
                        if (this._isRejectionUnhandled()) {
                          var e = this._settledValue();
                          this._setUnhandledRejectionIsNotified(),
                            K("unhandledRejection", s, e, this);
                        }
                      }),
                      (t.prototype._setUnhandledRejectionIsNotified =
                        function () {
                          this._bitField = 262144 | this._bitField;
                        }),
                      (t.prototype._unsetUnhandledRejectionIsNotified =
                        function () {
                          this._bitField = -262145 & this._bitField;
                        }),
                      (t.prototype._isUnhandledRejectionNotified = function () {
                        return (262144 & this._bitField) > 0;
                      }),
                      (t.prototype._setRejectionIsUnhandled = function () {
                        this._bitField = 1048576 | this._bitField;
                      }),
                      (t.prototype._unsetRejectionIsUnhandled = function () {
                        (this._bitField = -1048577 & this._bitField),
                          this._isUnhandledRejectionNotified() &&
                            (this._unsetUnhandledRejectionIsNotified(),
                            this._notifyUnhandledRejectionIsHandled());
                      }),
                      (t.prototype._isRejectionUnhandled = function () {
                        return (1048576 & this._bitField) > 0;
                      }),
                      (t.prototype._warn = function (e, t, r) {
                        return $(e, t, r || this);
                      }),
                      (t.onPossiblyUnhandledRejection = function (e) {
                        var r = t._getContext();
                        s = p.contextBind(r, e);
                      }),
                      (t.onUnhandledRejectionHandled = function (e) {
                        var r = t._getContext();
                        o = p.contextBind(r, e);
                      });
                    var T = function () {};
                    (t.longStackTraces = function () {
                      if (l.haveItemsQueued() && !re.longStackTraces)
                        throw new Error(
                          "cannot enable long stack traces after promises have been created\n\n    See http://goo.gl/MqrFmX\n"
                        );
                      if (!re.longStackTraces && Y()) {
                        var e = t.prototype._captureStackTrace,
                          n = t.prototype._attachExtraTrace,
                          i = t.prototype._dereferenceTrace;
                        (re.longStackTraces = !0),
                          (T = function () {
                            if (l.haveItemsQueued() && !re.longStackTraces)
                              throw new Error(
                                "cannot enable long stack traces after promises have been created\n\n    See http://goo.gl/MqrFmX\n"
                              );
                            (t.prototype._captureStackTrace = e),
                              (t.prototype._attachExtraTrace = n),
                              (t.prototype._dereferenceTrace = i),
                              r.deactivateLongStackTraces(),
                              (re.longStackTraces = !1);
                          }),
                          (t.prototype._captureStackTrace = U),
                          (t.prototype._attachExtraTrace = H),
                          (t.prototype._dereferenceTrace = q),
                          r.activateLongStackTraces();
                      }
                    }),
                      (t.hasLongStackTraces = function () {
                        return re.longStackTraces && Y();
                      });
                    var A = {
                        unhandledrejection: {
                          before: function () {
                            var e = p.global.onunhandledrejection;
                            return (p.global.onunhandledrejection = null), e;
                          },
                          after: function (e) {
                            p.global.onunhandledrejection = e;
                          },
                        },
                        rejectionhandled: {
                          before: function () {
                            var e = p.global.onrejectionhandled;
                            return (p.global.onrejectionhandled = null), e;
                          },
                          after: function (e) {
                            p.global.onrejectionhandled = e;
                          },
                        },
                      },
                      k = (function () {
                        var e = function (e, t) {
                          if (!e) return !p.global.dispatchEvent(t);
                          var r;
                          try {
                            return (r = e.before()), !p.global.dispatchEvent(t);
                          } finally {
                            e.after(r);
                          }
                        };
                        try {
                          if ("function" == typeof CustomEvent) {
                            var t = new CustomEvent("CustomEvent");
                            return (
                              p.global.dispatchEvent(t),
                              function (t, r) {
                                t = t.toLowerCase();
                                var n = new CustomEvent(t, {
                                  detail: r,
                                  cancelable: !0,
                                });
                                return (
                                  f.defineProperty(n, "promise", {
                                    value: r.promise,
                                  }),
                                  f.defineProperty(n, "reason", {
                                    value: r.reason,
                                  }),
                                  e(A[t], n)
                                );
                              }
                            );
                          }
                          return "function" == typeof Event
                            ? ((t = new Event("CustomEvent")),
                              p.global.dispatchEvent(t),
                              function (t, r) {
                                t = t.toLowerCase();
                                var n = new Event(t, { cancelable: !0 });
                                return (
                                  (n.detail = r),
                                  f.defineProperty(n, "promise", {
                                    value: r.promise,
                                  }),
                                  f.defineProperty(n, "reason", {
                                    value: r.reason,
                                  }),
                                  e(A[t], n)
                                );
                              })
                            : ((t =
                                document.createEvent(
                                  "CustomEvent"
                                )).initCustomEvent(
                                "testingtheevent",
                                !1,
                                !0,
                                {}
                              ),
                              p.global.dispatchEvent(t),
                              function (t, r) {
                                t = t.toLowerCase();
                                var n = document.createEvent("CustomEvent");
                                return (
                                  n.initCustomEvent(t, !1, !0, r), e(A[t], n)
                                );
                              });
                        } catch (e) {}
                        return function () {
                          return !1;
                        };
                      })(),
                      C = p.isNode
                        ? function () {
                            return n.emit.apply(n, arguments);
                          }
                        : p.global
                        ? function (e) {
                            var t = "on" + e.toLowerCase(),
                              r = p.global[t];
                            return (
                              !!r &&
                              (r.apply(p.global, [].slice.call(arguments, 1)),
                              !0)
                            );
                          }
                        : function () {
                            return !1;
                          };
                    function O(e, t) {
                      return { promise: t };
                    }
                    var P = {
                        promiseCreated: O,
                        promiseFulfilled: O,
                        promiseRejected: O,
                        promiseResolved: O,
                        promiseCancelled: O,
                        promiseChained: function (e, t, r) {
                          return { promise: t, child: r };
                        },
                        warning: function (e, t) {
                          return { warning: t };
                        },
                        unhandledRejection: function (e, t, r) {
                          return { reason: t, promise: r };
                        },
                        rejectionHandled: O,
                      },
                      I = function (e) {
                        var t = !1;
                        try {
                          t = C.apply(null, arguments);
                        } catch (e) {
                          l.throwLater(e), (t = !0);
                        }
                        var r = !1;
                        try {
                          r = k(e, P[e].apply(null, arguments));
                        } catch (e) {
                          l.throwLater(e), (r = !0);
                        }
                        return r || t;
                      };
                    function N() {
                      return !1;
                    }
                    function R(e, t, r) {
                      var n = this;
                      try {
                        e(t, r, function (e) {
                          if ("function" != typeof e)
                            throw new TypeError(
                              "onCancel must be a function, got: " +
                                p.toString(e)
                            );
                          n._attachCancellationCallback(e);
                        });
                      } catch (e) {
                        return e;
                      }
                    }
                    function D(e) {
                      if (!this._isCancellable()) return this;
                      var t = this._onCancel();
                      void 0 !== t
                        ? p.isArray(t)
                          ? t.push(e)
                          : this._setOnCancel([t, e])
                        : this._setOnCancel(e);
                    }
                    function F() {
                      return this._onCancelField;
                    }
                    function j(e) {
                      this._onCancelField = e;
                    }
                    function L() {
                      (this._cancellationParent = void 0),
                        (this._onCancelField = void 0);
                    }
                    function M(e, t) {
                      if (0 != (1 & t)) {
                        this._cancellationParent = e;
                        var r = e._branchesRemainingToCancel;
                        void 0 === r && (r = 0),
                          (e._branchesRemainingToCancel = r + 1);
                      }
                      0 != (2 & t) &&
                        e._isBound() &&
                        this._setBoundTo(e._boundTo);
                    }
                    (t.config = function (e) {
                      if (
                        ("longStackTraces" in (e = Object(e)) &&
                          (e.longStackTraces
                            ? t.longStackTraces()
                            : !e.longStackTraces &&
                              t.hasLongStackTraces() &&
                              T()),
                        "warnings" in e)
                      ) {
                        var r = e.warnings;
                        (re.warnings = !!r),
                          (S = re.warnings),
                          p.isObject(r) &&
                            "wForgottenReturn" in r &&
                            (S = !!r.wForgottenReturn);
                      }
                      if (
                        "cancellation" in e &&
                        e.cancellation &&
                        !re.cancellation
                      ) {
                        if (l.haveItemsQueued())
                          throw new Error(
                            "cannot enable cancellation after promises are in use"
                          );
                        (t.prototype._clearCancellationData = L),
                          (t.prototype._propagateFrom = M),
                          (t.prototype._onCancel = F),
                          (t.prototype._setOnCancel = j),
                          (t.prototype._attachCancellationCallback = D),
                          (t.prototype._execute = R),
                          (B = M),
                          (re.cancellation = !0);
                      }
                      if (
                        ("monitoring" in e &&
                          (e.monitoring && !re.monitoring
                            ? ((re.monitoring = !0),
                              (t.prototype._fireEvent = I))
                            : !e.monitoring &&
                              re.monitoring &&
                              ((re.monitoring = !1),
                              (t.prototype._fireEvent = N))),
                        "asyncHooks" in e && p.nodeSupportsAsyncResource)
                      ) {
                        var n = re.asyncHooks,
                          o = !!e.asyncHooks;
                        n !== o && ((re.asyncHooks = o), o ? i() : a());
                      }
                      return t;
                    }),
                      (t.prototype._fireEvent = N),
                      (t.prototype._execute = function (e, t, r) {
                        try {
                          e(t, r);
                        } catch (e) {
                          return e;
                        }
                      }),
                      (t.prototype._onCancel = function () {}),
                      (t.prototype._setOnCancel = function (e) {}),
                      (t.prototype._attachCancellationCallback = function (
                        e
                      ) {}),
                      (t.prototype._captureStackTrace = function () {}),
                      (t.prototype._attachExtraTrace = function () {}),
                      (t.prototype._dereferenceTrace = function () {}),
                      (t.prototype._clearCancellationData = function () {}),
                      (t.prototype._propagateFrom = function (e, t) {});
                    var B = function (e, t) {
                      0 != (2 & t) &&
                        e._isBound() &&
                        this._setBoundTo(e._boundTo);
                    };
                    function V() {
                      var e = this._boundTo;
                      return void 0 !== e && e instanceof t
                        ? e.isFulfilled()
                          ? e.value()
                          : void 0
                        : e;
                    }
                    function U() {
                      this._trace = new ee(this._peekContext());
                    }
                    function H(e, t) {
                      if (h(e)) {
                        var r = this._trace;
                        if (
                          (void 0 !== r && t && (r = r._parent), void 0 !== r)
                        )
                          r.attachExtraTrace(e);
                        else if (!e.__stackCleaned__) {
                          var n = z(e);
                          p.notEnumerableProp(
                            e,
                            "stack",
                            n.message + "\n" + n.stack.join("\n")
                          ),
                            p.notEnumerableProp(e, "__stackCleaned__", !0);
                        }
                      }
                    }
                    function q() {
                      this._trace = void 0;
                    }
                    function $(e, r, n) {
                      if (re.warnings) {
                        var i,
                          a = new d(e);
                        if (r) n._attachExtraTrace(a);
                        else if (re.longStackTraces && (i = t._peekContext()))
                          i.attachExtraTrace(a);
                        else {
                          var o = z(a);
                          a.stack = o.message + "\n" + o.stack.join("\n");
                        }
                        I("warning", a) || G(a, "", !0);
                      }
                    }
                    function W(e) {
                      for (var t = [], r = 0; r < e.length; ++r) {
                        var n = e[r],
                          i = "    (No stack trace)" === n || v.test(n),
                          a = i && Q(n);
                        i &&
                          !a &&
                          (_ && " " !== n.charAt(0) && (n = "    " + n),
                          t.push(n));
                      }
                      return t;
                    }
                    function z(e) {
                      var t = e.stack,
                        r = e.toString();
                      return (
                        (t =
                          "string" == typeof t && t.length > 0
                            ? (function (e) {
                                for (
                                  var t = e.stack
                                      .replace(/\s+$/g, "")
                                      .split("\n"),
                                    r = 0;
                                  r < t.length;
                                  ++r
                                ) {
                                  var n = t[r];
                                  if ("    (No stack trace)" === n || v.test(n))
                                    break;
                                }
                                return (
                                  r > 0 &&
                                    "SyntaxError" != e.name &&
                                    (t = t.slice(r)),
                                  t
                                );
                              })(e)
                            : ["    (No stack trace)"]),
                        {
                          message: r,
                          stack: "SyntaxError" == e.name ? t : W(t),
                        }
                      );
                    }
                    function G(e, t, r) {
                      if ("undefined" != typeof console) {
                        var n;
                        if (p.isObject(e)) {
                          var i = e.stack;
                          n = t + b(i, e);
                        } else n = t + String(e);
                        "function" == typeof u
                          ? u(n, r)
                          : ("function" != typeof console.log &&
                              "object" != typeof console.log) ||
                            console.log(n);
                      }
                    }
                    function K(e, t, r, n) {
                      var i = !1;
                      try {
                        "function" == typeof t &&
                          ((i = !0), "rejectionHandled" === e ? t(n) : t(r, n));
                      } catch (e) {
                        l.throwLater(e);
                      }
                      "unhandledRejection" === e
                        ? I(e, r, n) || i || G(r, "Unhandled rejection ")
                        : I(e, n);
                    }
                    function J(e) {
                      var t;
                      if ("function" == typeof e)
                        t = "[function " + (e.name || "anonymous") + "]";
                      else {
                        if (
                          ((t =
                            e && "function" == typeof e.toString
                              ? e.toString()
                              : p.toString(e)),
                          /\[object [a-zA-Z0-9$_]+\]/.test(t))
                        )
                          try {
                            t = JSON.stringify(e);
                          } catch (e) {}
                        0 === t.length && (t = "(empty array)");
                      }
                      return (
                        "(<" +
                        (function (e) {
                          var t = 41;
                          return e.length < t ? e : e.substr(0, t - 3) + "...";
                        })(t) +
                        ">, no stack trace)"
                      );
                    }
                    function Y() {
                      return "function" == typeof te;
                    }
                    var Q = function () {
                        return !1;
                      },
                      X = /[\/<\(]([^:\/]+):(\d+):(?:\d+)\)?\s*$/;
                    function Z(e) {
                      var t = e.match(X);
                      if (t)
                        return { fileName: t[1], line: parseInt(t[2], 10) };
                    }
                    function ee(e) {
                      (this._parent = e), (this._promisesCreated = 0);
                      var t = (this._length =
                        1 + (void 0 === e ? 0 : e._length));
                      te(this, ee), t > 32 && this.uncycle();
                    }
                    p.inherits(ee, Error),
                      (r.CapturedTrace = ee),
                      (ee.prototype.uncycle = function () {
                        var e = this._length;
                        if (!(e < 2)) {
                          for (
                            var t = [], r = {}, n = 0, i = this;
                            void 0 !== i;
                            ++n
                          )
                            t.push(i), (i = i._parent);
                          for (n = (e = this._length = n) - 1; n >= 0; --n) {
                            var a = t[n].stack;
                            void 0 === r[a] && (r[a] = n);
                          }
                          for (n = 0; n < e; ++n) {
                            var o = r[t[n].stack];
                            if (void 0 !== o && o !== n) {
                              o > 0 &&
                                ((t[o - 1]._parent = void 0),
                                (t[o - 1]._length = 1)),
                                (t[n]._parent = void 0),
                                (t[n]._length = 1);
                              var s = n > 0 ? t[n - 1] : this;
                              o < e - 1
                                ? ((s._parent = t[o + 1]),
                                  s._parent.uncycle(),
                                  (s._length = s._parent._length + 1))
                                : ((s._parent = void 0), (s._length = 1));
                              for (
                                var u = s._length + 1, c = n - 2;
                                c >= 0;
                                --c
                              )
                                (t[c]._length = u), u++;
                              return;
                            }
                          }
                        }
                      }),
                      (ee.prototype.attachExtraTrace = function (e) {
                        if (!e.__stackCleaned__) {
                          this.uncycle();
                          for (
                            var t = z(e),
                              r = t.message,
                              n = [t.stack],
                              i = this;
                            void 0 !== i;

                          )
                            n.push(W(i.stack.split("\n"))), (i = i._parent);
                          !(function (e) {
                            for (var t = e[0], r = 1; r < e.length; ++r) {
                              for (
                                var n = e[r],
                                  i = t.length - 1,
                                  a = t[i],
                                  o = -1,
                                  s = n.length - 1;
                                s >= 0;
                                --s
                              )
                                if (n[s] === a) {
                                  o = s;
                                  break;
                                }
                              for (s = o; s >= 0; --s) {
                                var u = n[s];
                                if (t[i] !== u) break;
                                t.pop(), i--;
                              }
                              t = n;
                            }
                          })(n),
                            (function (e) {
                              for (var t = 0; t < e.length; ++t)
                                (0 === e[t].length ||
                                  (t + 1 < e.length &&
                                    e[t][0] === e[t + 1][0])) &&
                                  (e.splice(t, 1), t--);
                            })(n),
                            p.notEnumerableProp(
                              e,
                              "stack",
                              (function (e, t) {
                                for (var r = 0; r < t.length - 1; ++r)
                                  t[r].push("From previous event:"),
                                    (t[r] = t[r].join("\n"));
                                return (
                                  r < t.length && (t[r] = t[r].join("\n")),
                                  e + "\n" + t.join("\n")
                                );
                              })(r, n)
                            ),
                            p.notEnumerableProp(e, "__stackCleaned__", !0);
                        }
                      });
                    var te = (function () {
                      var e = /^\s*at\s*/,
                        t = function (e, t) {
                          return "string" == typeof e
                            ? e
                            : void 0 !== t.name && void 0 !== t.message
                            ? t.toString()
                            : J(t);
                        };
                      if (
                        "number" == typeof Error.stackTraceLimit &&
                        "function" == typeof Error.captureStackTrace
                      ) {
                        (Error.stackTraceLimit += 6), (v = e), (b = t);
                        var r = Error.captureStackTrace;
                        return (
                          (Q = function (e) {
                            return m.test(e);
                          }),
                          function (e, t) {
                            (Error.stackTraceLimit += 6),
                              r(e, t),
                              (Error.stackTraceLimit -= 6);
                          }
                        );
                      }
                      var n,
                        i = new Error();
                      if (
                        "string" == typeof i.stack &&
                        i.stack.split("\n")[0].indexOf("stackDetection@") >= 0
                      )
                        return (
                          (v = /@/),
                          (b = t),
                          (_ = !0),
                          function (e) {
                            e.stack = new Error().stack;
                          }
                        );
                      try {
                        throw new Error();
                      } catch (e) {
                        n = "stack" in e;
                      }
                      return !("stack" in i) &&
                        n &&
                        "number" == typeof Error.stackTraceLimit
                        ? ((v = e),
                          (b = t),
                          function (e) {
                            Error.stackTraceLimit += 6;
                            try {
                              throw new Error();
                            } catch (t) {
                              e.stack = t.stack;
                            }
                            Error.stackTraceLimit -= 6;
                          })
                        : ((b = function (e, t) {
                            return "string" == typeof e
                              ? e
                              : ("object" != typeof t &&
                                  "function" != typeof t) ||
                                void 0 === t.name ||
                                void 0 === t.message
                              ? J(t)
                              : t.toString();
                          }),
                          null);
                    })();
                    "undefined" != typeof console &&
                      void 0 !== console.warn &&
                      ((u = function (e) {
                        console.warn(e);
                      }),
                      p.isNode && n.stderr.isTTY
                        ? (u = function (e, t) {
                            var r = t ? "\x1b[33m" : "\x1b[31m";
                            console.warn(r + e + "\x1b[0m\n");
                          })
                        : p.isNode ||
                          "string" != typeof new Error().stack ||
                          (u = function (e, t) {
                            console.warn(
                              "%c" + e,
                              t ? "color: darkorange" : "color: red"
                            );
                          }));
                    var re = {
                      warnings: w,
                      longStackTraces: !1,
                      cancellation: !1,
                      monitoring: !1,
                      asyncHooks: !1,
                    };
                    return (
                      x && t.longStackTraces(),
                      {
                        asyncHooks: function () {
                          return re.asyncHooks;
                        },
                        longStackTraces: function () {
                          return re.longStackTraces;
                        },
                        warnings: function () {
                          return re.warnings;
                        },
                        cancellation: function () {
                          return re.cancellation;
                        },
                        monitoring: function () {
                          return re.monitoring;
                        },
                        propagateFromFunction: function () {
                          return B;
                        },
                        boundValueFunction: function () {
                          return V;
                        },
                        checkForgottenReturns: function (e, t, r, n, i) {
                          if (void 0 === e && null !== t && S) {
                            if (void 0 !== i && i._returnedNonUndefined())
                              return;
                            if (0 == (65535 & n._bitField)) return;
                            r && (r += " ");
                            var a = "",
                              o = "";
                            if (t._trace) {
                              for (
                                var s = t._trace.stack.split("\n"),
                                  u = W(s),
                                  c = u.length - 1;
                                c >= 0;
                                --c
                              ) {
                                var l = u[c];
                                if (!g.test(l)) {
                                  var d = l.match(y);
                                  d &&
                                    (a =
                                      "at " +
                                      d[1] +
                                      ":" +
                                      d[2] +
                                      ":" +
                                      d[3] +
                                      " ");
                                  break;
                                }
                              }
                              if (u.length > 0) {
                                var p = u[0];
                                for (c = 0; c < s.length; ++c)
                                  if (s[c] === p) {
                                    c > 0 && (o = "\n" + s[c - 1]);
                                    break;
                                  }
                              }
                            }
                            var f =
                              "a promise was created in a " +
                              r +
                              "handler " +
                              a +
                              "but was not returned from it, see http://goo.gl/rRqMUw" +
                              o;
                            n._warn(f, !0, t);
                          }
                        },
                        setBounds: function (e, t) {
                          if (Y()) {
                            for (
                              var r,
                                n,
                                i = (e.stack || "").split("\n"),
                                a = (t.stack || "").split("\n"),
                                o = -1,
                                s = -1,
                                u = 0;
                              u < i.length;
                              ++u
                            )
                              if ((c = Z(i[u]))) {
                                (r = c.fileName), (o = c.line);
                                break;
                              }
                            for (u = 0; u < a.length; ++u) {
                              var c;
                              if ((c = Z(a[u]))) {
                                (n = c.fileName), (s = c.line);
                                break;
                              }
                            }
                            o < 0 ||
                              s < 0 ||
                              !r ||
                              !n ||
                              r !== n ||
                              o >= s ||
                              (Q = function (e) {
                                if (m.test(e)) return !0;
                                var t = Z(e);
                                return !!(
                                  t &&
                                  t.fileName === r &&
                                  o <= t.line &&
                                  t.line <= s
                                );
                              });
                          }
                        },
                        warn: $,
                        deprecated: function (e, t) {
                          var r =
                            e +
                            " is deprecated and will be removed in a future version.";
                          return t && (r += " Use " + t + " instead."), $(r);
                        },
                        CapturedTrace: ee,
                        fireDomEvent: k,
                        fireGlobalEvent: C,
                      }
                    );
                  };
                },
                { "./errors": 12, "./es5": 13, "./util": 36 },
              ],
              10: [
                function (e, t, r) {
                  "use strict";
                  t.exports = function (e) {
                    function t() {
                      return this.value;
                    }
                    function r() {
                      throw this.reason;
                    }
                    (e.prototype.return = e.prototype.thenReturn =
                      function (r) {
                        return (
                          r instanceof e && r.suppressUnhandledRejections(),
                          this._then(t, void 0, void 0, { value: r }, void 0)
                        );
                      }),
                      (e.prototype.throw = e.prototype.thenThrow =
                        function (e) {
                          return this._then(
                            r,
                            void 0,
                            void 0,
                            { reason: e },
                            void 0
                          );
                        }),
                      (e.prototype.catchThrow = function (e) {
                        if (arguments.length <= 1)
                          return this._then(
                            void 0,
                            r,
                            void 0,
                            { reason: e },
                            void 0
                          );
                        var t = arguments[1];
                        return this.caught(e, function () {
                          throw t;
                        });
                      }),
                      (e.prototype.catchReturn = function (r) {
                        if (arguments.length <= 1)
                          return (
                            r instanceof e && r.suppressUnhandledRejections(),
                            this._then(void 0, t, void 0, { value: r }, void 0)
                          );
                        var n = arguments[1];
                        return (
                          n instanceof e && n.suppressUnhandledRejections(),
                          this.caught(r, function () {
                            return n;
                          })
                        );
                      });
                  };
                },
                {},
              ],
              11: [
                function (e, t, r) {
                  "use strict";
                  t.exports = function (e, t) {
                    var r = e.reduce,
                      n = e.all;
                    function i() {
                      return n(this);
                    }
                    (e.prototype.each = function (e) {
                      return r(this, e, t, 0)._then(
                        i,
                        void 0,
                        void 0,
                        this,
                        void 0
                      );
                    }),
                      (e.prototype.mapSeries = function (e) {
                        return r(this, e, t, t);
                      }),
                      (e.each = function (e, n) {
                        return r(e, n, t, 0)._then(
                          i,
                          void 0,
                          void 0,
                          e,
                          void 0
                        );
                      }),
                      (e.mapSeries = function (e, n) {
                        return r(e, n, t, t);
                      });
                  };
                },
                {},
              ],
              12: [
                function (e, t, r) {
                  "use strict";
                  var n,
                    i,
                    a = e("./es5"),
                    o = a.freeze,
                    s = e("./util"),
                    u = s.inherits,
                    c = s.notEnumerableProp;
                  function l(e, t) {
                    function r(n) {
                      if (!(this instanceof r)) return new r(n);
                      c(this, "message", "string" == typeof n ? n : t),
                        c(this, "name", e),
                        Error.captureStackTrace
                          ? Error.captureStackTrace(this, this.constructor)
                          : Error.call(this);
                    }
                    return u(r, Error), r;
                  }
                  var d = l("Warning", "warning"),
                    p = l("CancellationError", "cancellation error"),
                    f = l("TimeoutError", "timeout error"),
                    h = l("AggregateError", "aggregate error");
                  try {
                    (n = TypeError), (i = RangeError);
                  } catch (e) {
                    (n = l("TypeError", "type error")),
                      (i = l("RangeError", "range error"));
                  }
                  for (
                    var m =
                        "join pop push shift unshift slice filter forEach some every map indexOf lastIndexOf reduce reduceRight sort reverse".split(
                          " "
                        ),
                      g = 0;
                    g < m.length;
                    ++g
                  )
                    "function" == typeof Array.prototype[m[g]] &&
                      (h.prototype[m[g]] = Array.prototype[m[g]]);
                  a.defineProperty(h.prototype, "length", {
                    value: 0,
                    configurable: !1,
                    writable: !0,
                    enumerable: !0,
                  }),
                    (h.prototype.isOperational = !0);
                  var y = 0;
                  function v(e) {
                    if (!(this instanceof v)) return new v(e);
                    c(this, "name", "OperationalError"),
                      c(this, "message", e),
                      (this.cause = e),
                      (this.isOperational = !0),
                      e instanceof Error
                        ? (c(this, "message", e.message),
                          c(this, "stack", e.stack))
                        : Error.captureStackTrace &&
                          Error.captureStackTrace(this, this.constructor);
                  }
                  (h.prototype.toString = function () {
                    var e = Array(4 * y + 1).join(" "),
                      t = "\n" + e + "AggregateError of:\n";
                    y++, (e = Array(4 * y + 1).join(" "));
                    for (var r = 0; r < this.length; ++r) {
                      for (
                        var n =
                            this[r] === this
                              ? "[Circular AggregateError]"
                              : this[r] + "",
                          i = n.split("\n"),
                          a = 0;
                        a < i.length;
                        ++a
                      )
                        i[a] = e + i[a];
                      t += (n = i.join("\n")) + "\n";
                    }
                    return y--, t;
                  }),
                    u(v, Error);
                  var b = Error.__BluebirdErrorTypes__;
                  b ||
                    ((b = o({
                      CancellationError: p,
                      TimeoutError: f,
                      OperationalError: v,
                      RejectionError: v,
                      AggregateError: h,
                    })),
                    a.defineProperty(Error, "__BluebirdErrorTypes__", {
                      value: b,
                      writable: !1,
                      enumerable: !1,
                      configurable: !1,
                    })),
                    (t.exports = {
                      Error,
                      TypeError: n,
                      RangeError: i,
                      CancellationError: b.CancellationError,
                      OperationalError: b.OperationalError,
                      TimeoutError: b.TimeoutError,
                      AggregateError: b.AggregateError,
                      Warning: d,
                    });
                },
                { "./es5": 13, "./util": 36 },
              ],
              13: [
                function (e, t, r) {
                  var n = (function () {
                    "use strict";
                    return void 0 === this;
                  })();
                  if (n)
                    t.exports = {
                      freeze: Object.freeze,
                      defineProperty: Object.defineProperty,
                      getDescriptor: Object.getOwnPropertyDescriptor,
                      keys: Object.keys,
                      names: Object.getOwnPropertyNames,
                      getPrototypeOf: Object.getPrototypeOf,
                      isArray: Array.isArray,
                      isES5: n,
                      propertyIsWritable: function (e, t) {
                        var r = Object.getOwnPropertyDescriptor(e, t);
                        return !(r && !r.writable && !r.set);
                      },
                    };
                  else {
                    var i = {}.hasOwnProperty,
                      a = {}.toString,
                      o = {}.constructor.prototype,
                      s = function (e) {
                        var t = [];
                        for (var r in e) i.call(e, r) && t.push(r);
                        return t;
                      };
                    t.exports = {
                      isArray: function (e) {
                        try {
                          return "[object Array]" === a.call(e);
                        } catch (e) {
                          return !1;
                        }
                      },
                      keys: s,
                      names: s,
                      defineProperty: function (e, t, r) {
                        return (e[t] = r.value), e;
                      },
                      getDescriptor: function (e, t) {
                        return { value: e[t] };
                      },
                      freeze: function (e) {
                        return e;
                      },
                      getPrototypeOf: function (e) {
                        try {
                          return Object(e).constructor.prototype;
                        } catch (e) {
                          return o;
                        }
                      },
                      isES5: n,
                      propertyIsWritable: function () {
                        return !0;
                      },
                    };
                  }
                },
                {},
              ],
              14: [
                function (e, t, r) {
                  "use strict";
                  t.exports = function (e, t) {
                    var r = e.map;
                    (e.prototype.filter = function (e, n) {
                      return r(this, e, n, t);
                    }),
                      (e.filter = function (e, n, i) {
                        return r(e, n, i, t);
                      });
                  };
                },
                {},
              ],
              15: [
                function (e, t, r) {
                  "use strict";
                  t.exports = function (t, r, n) {
                    var i = e("./util"),
                      a = t.CancellationError,
                      o = i.errorObj,
                      s = e("./catch_filter")(n);
                    function u(e, t, r) {
                      (this.promise = e),
                        (this.type = t),
                        (this.handler = r),
                        (this.called = !1),
                        (this.cancelPromise = null);
                    }
                    function c(e) {
                      this.finallyHandler = e;
                    }
                    function l(e, t) {
                      return (
                        null != e.cancelPromise &&
                        (arguments.length > 1
                          ? e.cancelPromise._reject(t)
                          : e.cancelPromise._cancel(),
                        (e.cancelPromise = null),
                        !0)
                      );
                    }
                    function d() {
                      return f.call(
                        this,
                        this.promise._target()._settledValue()
                      );
                    }
                    function p(e) {
                      if (!l(this, e)) return (o.e = e), o;
                    }
                    function f(e) {
                      var i = this.promise,
                        s = this.handler;
                      if (!this.called) {
                        this.called = !0;
                        var u = this.isFinallyHandler()
                          ? s.call(i._boundValue())
                          : s.call(i._boundValue(), e);
                        if (u === n) return u;
                        if (void 0 !== u) {
                          i._setReturnedNonUndefined();
                          var f = r(u, i);
                          if (f instanceof t) {
                            if (null != this.cancelPromise) {
                              if (f._isCancelled()) {
                                var h = new a("late cancellation observer");
                                return i._attachExtraTrace(h), (o.e = h), o;
                              }
                              f.isPending() &&
                                f._attachCancellationCallback(new c(this));
                            }
                            return f._then(d, p, void 0, this, void 0);
                          }
                        }
                      }
                      return i.isRejected()
                        ? (l(this), (o.e = e), o)
                        : (l(this), e);
                    }
                    return (
                      (u.prototype.isFinallyHandler = function () {
                        return 0 === this.type;
                      }),
                      (c.prototype._resultCancelled = function () {
                        l(this.finallyHandler);
                      }),
                      (t.prototype._passThrough = function (e, t, r, n) {
                        return "function" != typeof e
                          ? this.then()
                          : this._then(r, n, void 0, new u(this, t, e), void 0);
                      }),
                      (t.prototype.lastly = t.prototype.finally =
                        function (e) {
                          return this._passThrough(e, 0, f, f);
                        }),
                      (t.prototype.tap = function (e) {
                        return this._passThrough(e, 1, f);
                      }),
                      (t.prototype.tapCatch = function (e) {
                        var r = arguments.length;
                        if (1 === r) return this._passThrough(e, 1, void 0, f);
                        var n,
                          a = new Array(r - 1),
                          o = 0;
                        for (n = 0; n < r - 1; ++n) {
                          var u = arguments[n];
                          if (!i.isObject(u))
                            return t.reject(
                              new TypeError(
                                "tapCatch statement predicate: expecting an object but got " +
                                  i.classString(u)
                              )
                            );
                          a[o++] = u;
                        }
                        a.length = o;
                        var c = arguments[n];
                        return this._passThrough(s(a, c, this), 1, void 0, f);
                      }),
                      u
                    );
                  };
                },
                { "./catch_filter": 7, "./util": 36 },
              ],
              16: [
                function (e, t, r) {
                  "use strict";
                  t.exports = function (t, r, n, i, a, o) {
                    var s = e("./errors").TypeError,
                      u = e("./util"),
                      c = u.errorObj,
                      l = u.tryCatch,
                      d = [];
                    function p(e, r, i, a) {
                      if (o.cancellation()) {
                        var s = new t(n),
                          u = (this._finallyPromise = new t(n));
                        (this._promise = s.lastly(function () {
                          return u;
                        })),
                          s._captureStackTrace(),
                          s._setOnCancel(this);
                      } else (this._promise = new t(n))._captureStackTrace();
                      (this._stack = a),
                        (this._generatorFunction = e),
                        (this._receiver = r),
                        (this._generator = void 0),
                        (this._yieldHandlers =
                          "function" == typeof i ? [i].concat(d) : d),
                        (this._yieldedPromise = null),
                        (this._cancellationPhase = !1);
                    }
                    u.inherits(p, a),
                      (p.prototype._isResolved = function () {
                        return null === this._promise;
                      }),
                      (p.prototype._cleanup = function () {
                        (this._promise = this._generator = null),
                          o.cancellation() &&
                            null !== this._finallyPromise &&
                            (this._finallyPromise._fulfill(),
                            (this._finallyPromise = null));
                      }),
                      (p.prototype._promiseCancelled = function () {
                        if (!this._isResolved()) {
                          var e;
                          if (void 0 !== this._generator.return)
                            this._promise._pushContext(),
                              (e = l(this._generator.return).call(
                                this._generator,
                                void 0
                              )),
                              this._promise._popContext();
                          else {
                            var r = new t.CancellationError(
                              "generator .return() sentinel"
                            );
                            (t.coroutine.returnSentinel = r),
                              this._promise._attachExtraTrace(r),
                              this._promise._pushContext(),
                              (e = l(this._generator.throw).call(
                                this._generator,
                                r
                              )),
                              this._promise._popContext();
                          }
                          (this._cancellationPhase = !0),
                            (this._yieldedPromise = null),
                            this._continue(e);
                        }
                      }),
                      (p.prototype._promiseFulfilled = function (e) {
                        (this._yieldedPromise = null),
                          this._promise._pushContext();
                        var t = l(this._generator.next).call(
                          this._generator,
                          e
                        );
                        this._promise._popContext(), this._continue(t);
                      }),
                      (p.prototype._promiseRejected = function (e) {
                        (this._yieldedPromise = null),
                          this._promise._attachExtraTrace(e),
                          this._promise._pushContext();
                        var t = l(this._generator.throw).call(
                          this._generator,
                          e
                        );
                        this._promise._popContext(), this._continue(t);
                      }),
                      (p.prototype._resultCancelled = function () {
                        if (this._yieldedPromise instanceof t) {
                          var e = this._yieldedPromise;
                          (this._yieldedPromise = null), e.cancel();
                        }
                      }),
                      (p.prototype.promise = function () {
                        return this._promise;
                      }),
                      (p.prototype._run = function () {
                        (this._generator = this._generatorFunction.call(
                          this._receiver
                        )),
                          (this._receiver = this._generatorFunction = void 0),
                          this._promiseFulfilled(void 0);
                      }),
                      (p.prototype._continue = function (e) {
                        var r = this._promise;
                        if (e === c)
                          return (
                            this._cleanup(),
                            this._cancellationPhase
                              ? r.cancel()
                              : r._rejectCallback(e.e, !1)
                          );
                        var n = e.value;
                        if (!0 === e.done)
                          return (
                            this._cleanup(),
                            this._cancellationPhase
                              ? r.cancel()
                              : r._resolveCallback(n)
                          );
                        var a = i(n, this._promise);
                        if (
                          a instanceof t ||
                          ((a = (function (e, r, n) {
                            for (var a = 0; a < r.length; ++a) {
                              n._pushContext();
                              var o = l(r[a])(e);
                              if ((n._popContext(), o === c)) {
                                n._pushContext();
                                var s = t.reject(c.e);
                                return n._popContext(), s;
                              }
                              var u = i(o, n);
                              if (u instanceof t) return u;
                            }
                            return null;
                          })(a, this._yieldHandlers, this._promise)),
                          null !== a)
                        ) {
                          var o = (a = a._target())._bitField;
                          0 == (50397184 & o)
                            ? ((this._yieldedPromise = a), a._proxy(this, null))
                            : 0 != (33554432 & o)
                            ? t._async.invoke(
                                this._promiseFulfilled,
                                this,
                                a._value()
                              )
                            : 0 != (16777216 & o)
                            ? t._async.invoke(
                                this._promiseRejected,
                                this,
                                a._reason()
                              )
                            : this._promiseCancelled();
                        } else
                          this._promiseRejected(
                            new s(
                              "A value %s was yielded that could not be treated as a promise\n\n    See http://goo.gl/MqrFmX\n\n".replace(
                                "%s",
                                String(n)
                              ) +
                                "From coroutine:\n" +
                                this._stack.split("\n").slice(1, -7).join("\n")
                            )
                          );
                      }),
                      (t.coroutine = function (e, t) {
                        if ("function" != typeof e)
                          throw new s(
                            "generatorFunction must be a function\n\n    See http://goo.gl/MqrFmX\n"
                          );
                        var r = Object(t).yieldHandler,
                          n = p,
                          i = new Error().stack;
                        return function () {
                          var t = e.apply(this, arguments),
                            a = new n(void 0, void 0, r, i),
                            o = a.promise();
                          return (
                            (a._generator = t), a._promiseFulfilled(void 0), o
                          );
                        };
                      }),
                      (t.coroutine.addYieldHandler = function (e) {
                        if ("function" != typeof e)
                          throw new s(
                            "expecting a function but got " + u.classString(e)
                          );
                        d.push(e);
                      }),
                      (t.spawn = function (e) {
                        if (
                          (o.deprecated(
                            "Promise.spawn()",
                            "Promise.coroutine()"
                          ),
                          "function" != typeof e)
                        )
                          return r(
                            "generatorFunction must be a function\n\n    See http://goo.gl/MqrFmX\n"
                          );
                        var n = new p(e, this),
                          i = n.promise();
                        return n._run(t.spawn), i;
                      });
                  };
                },
                { "./errors": 12, "./util": 36 },
              ],
              17: [
                function (e, t, r) {
                  "use strict";
                  t.exports = function (t, r, n, i, a) {
                    var o = e("./util");
                    o.canEvaluate,
                      o.tryCatch,
                      o.errorObj,
                      (t.join = function () {
                        var e,
                          t = arguments.length - 1;
                        t > 0 &&
                          "function" == typeof arguments[t] &&
                          (e = arguments[t]);
                        var n = [].slice.call(arguments);
                        e && n.pop();
                        var i = new r(n).promise();
                        return void 0 !== e ? i.spread(e) : i;
                      });
                  };
                },
                { "./util": 36 },
              ],
              18: [
                function (e, t, r) {
                  "use strict";
                  t.exports = function (t, r, n, i, a, o) {
                    var s = e("./util"),
                      u = s.tryCatch,
                      c = s.errorObj,
                      l = t._async;
                    function d(e, r, n, i) {
                      this.constructor$(e), this._promise._captureStackTrace();
                      var o = t._getContext();
                      if (
                        ((this._callback = s.contextBind(o, r)),
                        (this._preservedValues =
                          i === a ? new Array(this.length()) : null),
                        (this._limit = n),
                        (this._inFlight = 0),
                        (this._queue = []),
                        l.invoke(this._asyncInit, this, void 0),
                        s.isArray(e))
                      )
                        for (var u = 0; u < e.length; ++u) {
                          var c = e[u];
                          c instanceof t && c.suppressUnhandledRejections();
                        }
                    }
                    function p(e, r, i, a) {
                      if ("function" != typeof r)
                        return n(
                          "expecting a function but got " + s.classString(r)
                        );
                      var o = 0;
                      if (void 0 !== i) {
                        if ("object" != typeof i || null === i)
                          return t.reject(
                            new TypeError(
                              "options argument must be an object but it is " +
                                s.classString(i)
                            )
                          );
                        if ("number" != typeof i.concurrency)
                          return t.reject(
                            new TypeError(
                              "'concurrency' must be a number but it is " +
                                s.classString(i.concurrency)
                            )
                          );
                        o = i.concurrency;
                      }
                      return new d(
                        e,
                        r,
                        (o =
                          "number" == typeof o && isFinite(o) && o >= 1
                            ? o
                            : 0),
                        a
                      ).promise();
                    }
                    s.inherits(d, r),
                      (d.prototype._asyncInit = function () {
                        this._init$(void 0, -2);
                      }),
                      (d.prototype._init = function () {}),
                      (d.prototype._promiseFulfilled = function (e, r) {
                        var n = this._values,
                          a = this.length(),
                          s = this._preservedValues,
                          l = this._limit;
                        if (r < 0) {
                          if (
                            ((n[(r = -1 * r - 1)] = e),
                            l >= 1 &&
                              (this._inFlight--,
                              this._drainQueue(),
                              this._isResolved()))
                          )
                            return !0;
                        } else {
                          if (l >= 1 && this._inFlight >= l)
                            return (n[r] = e), this._queue.push(r), !1;
                          null !== s && (s[r] = e);
                          var d = this._promise,
                            p = this._callback,
                            f = d._boundValue();
                          d._pushContext();
                          var h = u(p).call(f, e, r, a),
                            m = d._popContext();
                          if (
                            (o.checkForgottenReturns(
                              h,
                              m,
                              null !== s ? "Promise.filter" : "Promise.map",
                              d
                            ),
                            h === c)
                          )
                            return this._reject(h.e), !0;
                          var g = i(h, this._promise);
                          if (g instanceof t) {
                            var y = (g = g._target())._bitField;
                            if (0 == (50397184 & y))
                              return (
                                l >= 1 && this._inFlight++,
                                (n[r] = g),
                                g._proxy(this, -1 * (r + 1)),
                                !1
                              );
                            if (0 == (33554432 & y))
                              return 0 != (16777216 & y)
                                ? (this._reject(g._reason()), !0)
                                : (this._cancel(), !0);
                            h = g._value();
                          }
                          n[r] = h;
                        }
                        return (
                          ++this._totalResolved >= a &&
                          (null !== s ? this._filter(n, s) : this._resolve(n),
                          !0)
                        );
                      }),
                      (d.prototype._drainQueue = function () {
                        for (
                          var e = this._queue,
                            t = this._limit,
                            r = this._values;
                          e.length > 0 && this._inFlight < t;

                        ) {
                          if (this._isResolved()) return;
                          var n = e.pop();
                          this._promiseFulfilled(r[n], n);
                        }
                      }),
                      (d.prototype._filter = function (e, t) {
                        for (
                          var r = t.length, n = new Array(r), i = 0, a = 0;
                          a < r;
                          ++a
                        )
                          e[a] && (n[i++] = t[a]);
                        (n.length = i), this._resolve(n);
                      }),
                      (d.prototype.preservedValues = function () {
                        return this._preservedValues;
                      }),
                      (t.prototype.map = function (e, t) {
                        return p(this, e, t, null);
                      }),
                      (t.map = function (e, t, r, n) {
                        return p(e, t, r, n);
                      });
                  };
                },
                { "./util": 36 },
              ],
              19: [
                function (e, t, r) {
                  "use strict";
                  t.exports = function (t, r, n, i, a) {
                    var o = e("./util"),
                      s = o.tryCatch;
                    (t.method = function (e) {
                      if ("function" != typeof e)
                        throw new t.TypeError(
                          "expecting a function but got " + o.classString(e)
                        );
                      return function () {
                        var n = new t(r);
                        n._captureStackTrace(), n._pushContext();
                        var i = s(e).apply(this, arguments),
                          o = n._popContext();
                        return (
                          a.checkForgottenReturns(i, o, "Promise.method", n),
                          n._resolveFromSyncValue(i),
                          n
                        );
                      };
                    }),
                      (t.attempt = t.try =
                        function (e) {
                          if ("function" != typeof e)
                            return i(
                              "expecting a function but got " + o.classString(e)
                            );
                          var n,
                            u = new t(r);
                          if (
                            (u._captureStackTrace(),
                            u._pushContext(),
                            arguments.length > 1)
                          ) {
                            a.deprecated(
                              "calling Promise.try with more than 1 argument"
                            );
                            var c = arguments[1],
                              l = arguments[2];
                            n = o.isArray(c)
                              ? s(e).apply(l, c)
                              : s(e).call(l, c);
                          } else n = s(e)();
                          var d = u._popContext();
                          return (
                            a.checkForgottenReturns(n, d, "Promise.try", u),
                            u._resolveFromSyncValue(n),
                            u
                          );
                        }),
                      (t.prototype._resolveFromSyncValue = function (e) {
                        e === o.errorObj
                          ? this._rejectCallback(e.e, !1)
                          : this._resolveCallback(e, !0);
                      });
                  };
                },
                { "./util": 36 },
              ],
              20: [
                function (e, t, r) {
                  "use strict";
                  var n = e("./util"),
                    i = n.maybeWrapAsError,
                    a = e("./errors").OperationalError,
                    o = e("./es5"),
                    s = /^(?:name|message|stack|cause)$/;
                  function u(e) {
                    var t;
                    if (
                      (function (e) {
                        return (
                          e instanceof Error &&
                          o.getPrototypeOf(e) === Error.prototype
                        );
                      })(e)
                    ) {
                      ((t = new a(e)).name = e.name),
                        (t.message = e.message),
                        (t.stack = e.stack);
                      for (var r = o.keys(e), i = 0; i < r.length; ++i) {
                        var u = r[i];
                        s.test(u) || (t[u] = e[u]);
                      }
                      return t;
                    }
                    return n.markAsOriginatingFromRejection(e), e;
                  }
                  t.exports = function (e, t) {
                    return function (r, n) {
                      if (null !== e) {
                        if (r) {
                          var a = u(i(r));
                          e._attachExtraTrace(a), e._reject(a);
                        } else if (t) {
                          var o = [].slice.call(arguments, 1);
                          e._fulfill(o);
                        } else e._fulfill(n);
                        e = null;
                      }
                    };
                  };
                },
                { "./errors": 12, "./es5": 13, "./util": 36 },
              ],
              21: [
                function (e, t, r) {
                  "use strict";
                  t.exports = function (t) {
                    var r = e("./util"),
                      n = t._async,
                      i = r.tryCatch,
                      a = r.errorObj;
                    function o(e, t) {
                      if (!r.isArray(e)) return s.call(this, e, t);
                      var o = i(t).apply(this._boundValue(), [null].concat(e));
                      o === a && n.throwLater(o.e);
                    }
                    function s(e, t) {
                      var r = this._boundValue(),
                        o =
                          void 0 === e
                            ? i(t).call(r, null)
                            : i(t).call(r, null, e);
                      o === a && n.throwLater(o.e);
                    }
                    function u(e, t) {
                      if (!e) {
                        var r = new Error(e + "");
                        (r.cause = e), (e = r);
                      }
                      var o = i(t).call(this._boundValue(), e);
                      o === a && n.throwLater(o.e);
                    }
                    t.prototype.asCallback = t.prototype.nodeify = function (
                      e,
                      t
                    ) {
                      if ("function" == typeof e) {
                        var r = s;
                        void 0 !== t && Object(t).spread && (r = o),
                          this._then(r, u, void 0, this, e);
                      }
                      return this;
                    };
                  };
                },
                { "./util": 36 },
              ],
              22: [
                function (e, t, r) {
                  "use strict";
                  t.exports = function () {
                    var r = function () {
                        return new v(
                          "circular promise resolution chain\n\n    See http://goo.gl/MqrFmX\n"
                        );
                      },
                      i = function () {
                        return new R.PromiseInspection(this._target());
                      },
                      a = function (e) {
                        return R.reject(new v(e));
                      };
                    function o() {}
                    var s = {},
                      u = e("./util");
                    u.setReflectHandler(i);
                    var c = function () {
                        var e = n.domain;
                        return void 0 === e ? null : e;
                      },
                      l = function () {
                        return { domain: c(), async: null };
                      },
                      d =
                        u.isNode && u.nodeSupportsAsyncResource
                          ? e("async_hooks").AsyncResource
                          : null,
                      p = function () {
                        return {
                          domain: c(),
                          async: new d("Bluebird::Promise"),
                        };
                      },
                      f = u.isNode
                        ? l
                        : function () {
                            return null;
                          };
                    u.notEnumerableProp(R, "_getContext", f);
                    var h = e("./es5"),
                      m = e("./async"),
                      g = new m();
                    h.defineProperty(R, "_async", { value: g });
                    var y = e("./errors"),
                      v = (R.TypeError = y.TypeError);
                    R.RangeError = y.RangeError;
                    var b = (R.CancellationError = y.CancellationError);
                    (R.TimeoutError = y.TimeoutError),
                      (R.OperationalError = y.OperationalError),
                      (R.RejectionError = y.OperationalError),
                      (R.AggregateError = y.AggregateError);
                    var _ = function () {},
                      E = {},
                      w = {},
                      x = e("./thenables")(R, _),
                      S = e("./promise_array")(R, _, x, a, o),
                      T = e("./context")(R),
                      A = T.create,
                      k = e("./debuggability")(
                        R,
                        T,
                        function () {
                          (f = p), u.notEnumerableProp(R, "_getContext", p);
                        },
                        function () {
                          (f = l), u.notEnumerableProp(R, "_getContext", l);
                        }
                      ),
                      C = (k.CapturedTrace, e("./finally")(R, x, w)),
                      O = e("./catch_filter")(w),
                      P = e("./nodeback"),
                      I = u.errorObj,
                      N = u.tryCatch;
                    function R(e) {
                      e !== _ &&
                        (function (e, t) {
                          if (null == e || e.constructor !== R)
                            throw new v(
                              "the promise constructor cannot be invoked directly\n\n    See http://goo.gl/MqrFmX\n"
                            );
                          if ("function" != typeof t)
                            throw new v(
                              "expecting a function but got " + u.classString(t)
                            );
                        })(this, e),
                        (this._bitField = 0),
                        (this._fulfillmentHandler0 = void 0),
                        (this._rejectionHandler0 = void 0),
                        (this._promise0 = void 0),
                        (this._receiver0 = void 0),
                        this._resolveFromExecutor(e),
                        this._promiseCreated(),
                        this._fireEvent("promiseCreated", this);
                    }
                    function D(e) {
                      this.promise._resolveCallback(e);
                    }
                    function F(e) {
                      this.promise._rejectCallback(e, !1);
                    }
                    function j(e) {
                      var t = new R(_);
                      (t._fulfillmentHandler0 = e),
                        (t._rejectionHandler0 = e),
                        (t._promise0 = e),
                        (t._receiver0 = e);
                    }
                    return (
                      (R.prototype.toString = function () {
                        return "[object Promise]";
                      }),
                      (R.prototype.caught = R.prototype.catch =
                        function (e) {
                          var t = arguments.length;
                          if (t > 1) {
                            var r,
                              n = new Array(t - 1),
                              i = 0;
                            for (r = 0; r < t - 1; ++r) {
                              var o = arguments[r];
                              if (!u.isObject(o))
                                return a(
                                  "Catch statement predicate: expecting an object but got " +
                                    u.classString(o)
                                );
                              n[i++] = o;
                            }
                            if (
                              ((n.length = i),
                              "function" != typeof (e = arguments[r]))
                            )
                              throw new v(
                                "The last argument to .catch() must be a function, got " +
                                  u.toString(e)
                              );
                            return this.then(void 0, O(n, e, this));
                          }
                          return this.then(void 0, e);
                        }),
                      (R.prototype.reflect = function () {
                        return this._then(i, i, void 0, this, void 0);
                      }),
                      (R.prototype.then = function (e, t) {
                        if (
                          k.warnings() &&
                          arguments.length > 0 &&
                          "function" != typeof e &&
                          "function" != typeof t
                        ) {
                          var r =
                            ".then() only accepts functions but was passed: " +
                            u.classString(e);
                          arguments.length > 1 &&
                            (r += ", " + u.classString(t)),
                            this._warn(r);
                        }
                        return this._then(e, t, void 0, void 0, void 0);
                      }),
                      (R.prototype.done = function (e, t) {
                        this._then(e, t, void 0, void 0, void 0)._setIsFinal();
                      }),
                      (R.prototype.spread = function (e) {
                        return "function" != typeof e
                          ? a(
                              "expecting a function but got " + u.classString(e)
                            )
                          : this.all()._then(e, void 0, void 0, E, void 0);
                      }),
                      (R.prototype.toJSON = function () {
                        var e = {
                          isFulfilled: !1,
                          isRejected: !1,
                          fulfillmentValue: void 0,
                          rejectionReason: void 0,
                        };
                        return (
                          this.isFulfilled()
                            ? ((e.fulfillmentValue = this.value()),
                              (e.isFulfilled = !0))
                            : this.isRejected() &&
                              ((e.rejectionReason = this.reason()),
                              (e.isRejected = !0)),
                          e
                        );
                      }),
                      (R.prototype.all = function () {
                        return (
                          arguments.length > 0 &&
                            this._warn(
                              ".all() was passed arguments but it does not take any"
                            ),
                          new S(this).promise()
                        );
                      }),
                      (R.prototype.error = function (e) {
                        return this.caught(u.originatesFromRejection, e);
                      }),
                      (R.getNewLibraryCopy = t.exports),
                      (R.is = function (e) {
                        return e instanceof R;
                      }),
                      (R.fromNode = R.fromCallback =
                        function (e) {
                          var t = new R(_);
                          t._captureStackTrace();
                          var r =
                              arguments.length > 1 &&
                              !!Object(arguments[1]).multiArgs,
                            n = N(e)(P(t, r));
                          return (
                            n === I && t._rejectCallback(n.e, !0),
                            t._isFateSealed() || t._setAsyncGuaranteed(),
                            t
                          );
                        }),
                      (R.all = function (e) {
                        return new S(e).promise();
                      }),
                      (R.cast = function (e) {
                        var t = x(e);
                        return (
                          t instanceof R ||
                            ((t = new R(_))._captureStackTrace(),
                            t._setFulfilled(),
                            (t._rejectionHandler0 = e)),
                          t
                        );
                      }),
                      (R.resolve = R.fulfilled = R.cast),
                      (R.reject = R.rejected =
                        function (e) {
                          var t = new R(_);
                          return (
                            t._captureStackTrace(), t._rejectCallback(e, !0), t
                          );
                        }),
                      (R.setScheduler = function (e) {
                        if ("function" != typeof e)
                          throw new v(
                            "expecting a function but got " + u.classString(e)
                          );
                        return g.setScheduler(e);
                      }),
                      (R.prototype._then = function (e, t, r, n, i) {
                        var a = void 0 !== i,
                          o = a ? i : new R(_),
                          s = this._target(),
                          c = s._bitField;
                        a ||
                          (o._propagateFrom(this, 3),
                          o._captureStackTrace(),
                          void 0 === n &&
                            0 != (2097152 & this._bitField) &&
                            (n =
                              0 != (50397184 & c)
                                ? this._boundValue()
                                : s === this
                                ? void 0
                                : this._boundTo),
                          this._fireEvent("promiseChained", this, o));
                        var l = f();
                        if (0 != (50397184 & c)) {
                          var d,
                            p,
                            h = s._settlePromiseCtx;
                          0 != (33554432 & c)
                            ? ((p = s._rejectionHandler0), (d = e))
                            : 0 != (16777216 & c)
                            ? ((p = s._fulfillmentHandler0),
                              (d = t),
                              s._unsetRejectionIsUnhandled())
                            : ((h = s._settlePromiseLateCancellationObserver),
                              (p = new b("late cancellation observer")),
                              s._attachExtraTrace(p),
                              (d = t)),
                            g.invoke(h, s, {
                              handler: u.contextBind(l, d),
                              promise: o,
                              receiver: n,
                              value: p,
                            });
                        } else s._addCallbacks(e, t, o, n, l);
                        return o;
                      }),
                      (R.prototype._length = function () {
                        return 65535 & this._bitField;
                      }),
                      (R.prototype._isFateSealed = function () {
                        return 0 != (117506048 & this._bitField);
                      }),
                      (R.prototype._isFollowing = function () {
                        return 67108864 == (67108864 & this._bitField);
                      }),
                      (R.prototype._setLength = function (e) {
                        this._bitField =
                          (-65536 & this._bitField) | (65535 & e);
                      }),
                      (R.prototype._setFulfilled = function () {
                        (this._bitField = 33554432 | this._bitField),
                          this._fireEvent("promiseFulfilled", this);
                      }),
                      (R.prototype._setRejected = function () {
                        (this._bitField = 16777216 | this._bitField),
                          this._fireEvent("promiseRejected", this);
                      }),
                      (R.prototype._setFollowing = function () {
                        (this._bitField = 67108864 | this._bitField),
                          this._fireEvent("promiseResolved", this);
                      }),
                      (R.prototype._setIsFinal = function () {
                        this._bitField = 4194304 | this._bitField;
                      }),
                      (R.prototype._isFinal = function () {
                        return (4194304 & this._bitField) > 0;
                      }),
                      (R.prototype._unsetCancelled = function () {
                        this._bitField = -65537 & this._bitField;
                      }),
                      (R.prototype._setCancelled = function () {
                        (this._bitField = 65536 | this._bitField),
                          this._fireEvent("promiseCancelled", this);
                      }),
                      (R.prototype._setWillBeCancelled = function () {
                        this._bitField = 8388608 | this._bitField;
                      }),
                      (R.prototype._setAsyncGuaranteed = function () {
                        if (!g.hasCustomScheduler()) {
                          var e = this._bitField;
                          this._bitField =
                            e | (((536870912 & e) >> 2) ^ 134217728);
                        }
                      }),
                      (R.prototype._setNoAsyncGuarantee = function () {
                        this._bitField =
                          -134217729 & (536870912 | this._bitField);
                      }),
                      (R.prototype._receiverAt = function (e) {
                        var t = 0 === e ? this._receiver0 : this[4 * e - 4 + 3];
                        if (t !== s)
                          return void 0 === t && this._isBound()
                            ? this._boundValue()
                            : t;
                      }),
                      (R.prototype._promiseAt = function (e) {
                        return this[4 * e - 4 + 2];
                      }),
                      (R.prototype._fulfillmentHandlerAt = function (e) {
                        return this[4 * e - 4 + 0];
                      }),
                      (R.prototype._rejectionHandlerAt = function (e) {
                        return this[4 * e - 4 + 1];
                      }),
                      (R.prototype._boundValue = function () {}),
                      (R.prototype._migrateCallback0 = function (e) {
                        e._bitField;
                        var t = e._fulfillmentHandler0,
                          r = e._rejectionHandler0,
                          n = e._promise0,
                          i = e._receiverAt(0);
                        void 0 === i && (i = s),
                          this._addCallbacks(t, r, n, i, null);
                      }),
                      (R.prototype._migrateCallbackAt = function (e, t) {
                        var r = e._fulfillmentHandlerAt(t),
                          n = e._rejectionHandlerAt(t),
                          i = e._promiseAt(t),
                          a = e._receiverAt(t);
                        void 0 === a && (a = s),
                          this._addCallbacks(r, n, i, a, null);
                      }),
                      (R.prototype._addCallbacks = function (e, t, r, n, i) {
                        var a = this._length();
                        if (
                          (a >= 65531 && ((a = 0), this._setLength(0)), 0 === a)
                        )
                          (this._promise0 = r),
                            (this._receiver0 = n),
                            "function" == typeof e &&
                              (this._fulfillmentHandler0 = u.contextBind(i, e)),
                            "function" == typeof t &&
                              (this._rejectionHandler0 = u.contextBind(i, t));
                        else {
                          var o = 4 * a - 4;
                          (this[o + 2] = r),
                            (this[o + 3] = n),
                            "function" == typeof e &&
                              (this[o + 0] = u.contextBind(i, e)),
                            "function" == typeof t &&
                              (this[o + 1] = u.contextBind(i, t));
                        }
                        return this._setLength(a + 1), a;
                      }),
                      (R.prototype._proxy = function (e, t) {
                        this._addCallbacks(void 0, void 0, t, e, null);
                      }),
                      (R.prototype._resolveCallback = function (e, t) {
                        if (0 == (117506048 & this._bitField)) {
                          if (e === this) return this._rejectCallback(r(), !1);
                          var n = x(e, this);
                          if (!(n instanceof R)) return this._fulfill(e);
                          t && this._propagateFrom(n, 2);
                          var i = n._target();
                          if (i !== this) {
                            var a = i._bitField;
                            if (0 == (50397184 & a)) {
                              var o = this._length();
                              o > 0 && i._migrateCallback0(this);
                              for (var s = 1; s < o; ++s)
                                i._migrateCallbackAt(this, s);
                              this._setFollowing(),
                                this._setLength(0),
                                this._setFollowee(n);
                            } else if (0 != (33554432 & a))
                              this._fulfill(i._value());
                            else if (0 != (16777216 & a))
                              this._reject(i._reason());
                            else {
                              var u = new b("late cancellation observer");
                              i._attachExtraTrace(u), this._reject(u);
                            }
                          } else this._reject(r());
                        }
                      }),
                      (R.prototype._rejectCallback = function (e, t, r) {
                        var n = u.ensureErrorObject(e),
                          i = n === e;
                        if (!i && !r && k.warnings()) {
                          var a =
                            "a promise was rejected with a non-error: " +
                            u.classString(e);
                          this._warn(a, !0);
                        }
                        this._attachExtraTrace(n, !!t && i), this._reject(e);
                      }),
                      (R.prototype._resolveFromExecutor = function (e) {
                        if (e !== _) {
                          var t = this;
                          this._captureStackTrace(), this._pushContext();
                          var r = !0,
                            n = this._execute(
                              e,
                              function (e) {
                                t._resolveCallback(e);
                              },
                              function (e) {
                                t._rejectCallback(e, r);
                              }
                            );
                          (r = !1),
                            this._popContext(),
                            void 0 !== n && t._rejectCallback(n, !0);
                        }
                      }),
                      (R.prototype._settlePromiseFromHandler = function (
                        e,
                        t,
                        r,
                        n
                      ) {
                        var i = n._bitField;
                        if (0 == (65536 & i)) {
                          var a;
                          n._pushContext(),
                            t === E
                              ? r && "number" == typeof r.length
                                ? (a = N(e).apply(this._boundValue(), r))
                                : ((a = I).e = new v(
                                    "cannot .spread() a non-array: " +
                                      u.classString(r)
                                  ))
                              : (a = N(e).call(t, r));
                          var o = n._popContext();
                          0 == (65536 & (i = n._bitField)) &&
                            (a === w
                              ? n._reject(r)
                              : a === I
                              ? n._rejectCallback(a.e, !1)
                              : (k.checkForgottenReturns(a, o, "", n, this),
                                n._resolveCallback(a)));
                        }
                      }),
                      (R.prototype._target = function () {
                        for (var e = this; e._isFollowing(); )
                          e = e._followee();
                        return e;
                      }),
                      (R.prototype._followee = function () {
                        return this._rejectionHandler0;
                      }),
                      (R.prototype._setFollowee = function (e) {
                        this._rejectionHandler0 = e;
                      }),
                      (R.prototype._settlePromise = function (e, t, r, n) {
                        var a = e instanceof R,
                          s = this._bitField,
                          u = 0 != (134217728 & s);
                        0 != (65536 & s)
                          ? (a && e._invokeInternalOnCancel(),
                            r instanceof C && r.isFinallyHandler()
                              ? ((r.cancelPromise = e),
                                N(t).call(r, n) === I && e._reject(I.e))
                              : t === i
                              ? e._fulfill(i.call(r))
                              : r instanceof o
                              ? r._promiseCancelled(e)
                              : a || e instanceof S
                              ? e._cancel()
                              : r.cancel())
                          : "function" == typeof t
                          ? a
                            ? (u && e._setAsyncGuaranteed(),
                              this._settlePromiseFromHandler(t, r, n, e))
                            : t.call(r, n, e)
                          : r instanceof o
                          ? r._isResolved() ||
                            (0 != (33554432 & s)
                              ? r._promiseFulfilled(n, e)
                              : r._promiseRejected(n, e))
                          : a &&
                            (u && e._setAsyncGuaranteed(),
                            0 != (33554432 & s) ? e._fulfill(n) : e._reject(n));
                      }),
                      (R.prototype._settlePromiseLateCancellationObserver =
                        function (e) {
                          var t = e.handler,
                            r = e.promise,
                            n = e.receiver,
                            i = e.value;
                          "function" == typeof t
                            ? r instanceof R
                              ? this._settlePromiseFromHandler(t, n, i, r)
                              : t.call(n, i, r)
                            : r instanceof R && r._reject(i);
                        }),
                      (R.prototype._settlePromiseCtx = function (e) {
                        this._settlePromise(
                          e.promise,
                          e.handler,
                          e.receiver,
                          e.value
                        );
                      }),
                      (R.prototype._settlePromise0 = function (e, t, r) {
                        var n = this._promise0,
                          i = this._receiverAt(0);
                        (this._promise0 = void 0),
                          (this._receiver0 = void 0),
                          this._settlePromise(n, e, i, t);
                      }),
                      (R.prototype._clearCallbackDataAtIndex = function (e) {
                        var t = 4 * e - 4;
                        this[t + 2] =
                          this[t + 3] =
                          this[t + 0] =
                          this[t + 1] =
                            void 0;
                      }),
                      (R.prototype._fulfill = function (e) {
                        var t = this._bitField;
                        if (!((117506048 & t) >>> 16)) {
                          if (e === this) {
                            var n = r();
                            return this._attachExtraTrace(n), this._reject(n);
                          }
                          this._setFulfilled(),
                            (this._rejectionHandler0 = e),
                            (65535 & t) > 0 &&
                              (0 != (134217728 & t)
                                ? this._settlePromises()
                                : g.settlePromises(this),
                              this._dereferenceTrace());
                        }
                      }),
                      (R.prototype._reject = function (e) {
                        var t = this._bitField;
                        if (!((117506048 & t) >>> 16)) {
                          if (
                            (this._setRejected(),
                            (this._fulfillmentHandler0 = e),
                            this._isFinal())
                          )
                            return g.fatalError(e, u.isNode);
                          (65535 & t) > 0
                            ? g.settlePromises(this)
                            : this._ensurePossibleRejectionHandled();
                        }
                      }),
                      (R.prototype._fulfillPromises = function (e, t) {
                        for (var r = 1; r < e; r++) {
                          var n = this._fulfillmentHandlerAt(r),
                            i = this._promiseAt(r),
                            a = this._receiverAt(r);
                          this._clearCallbackDataAtIndex(r),
                            this._settlePromise(i, n, a, t);
                        }
                      }),
                      (R.prototype._rejectPromises = function (e, t) {
                        for (var r = 1; r < e; r++) {
                          var n = this._rejectionHandlerAt(r),
                            i = this._promiseAt(r),
                            a = this._receiverAt(r);
                          this._clearCallbackDataAtIndex(r),
                            this._settlePromise(i, n, a, t);
                        }
                      }),
                      (R.prototype._settlePromises = function () {
                        var e = this._bitField,
                          t = 65535 & e;
                        if (t > 0) {
                          if (0 != (16842752 & e)) {
                            var r = this._fulfillmentHandler0;
                            this._settlePromise0(this._rejectionHandler0, r, e),
                              this._rejectPromises(t, r);
                          } else {
                            var n = this._rejectionHandler0;
                            this._settlePromise0(
                              this._fulfillmentHandler0,
                              n,
                              e
                            ),
                              this._fulfillPromises(t, n);
                          }
                          this._setLength(0);
                        }
                        this._clearCancellationData();
                      }),
                      (R.prototype._settledValue = function () {
                        var e = this._bitField;
                        return 0 != (33554432 & e)
                          ? this._rejectionHandler0
                          : 0 != (16777216 & e)
                          ? this._fulfillmentHandler0
                          : void 0;
                      }),
                      "undefined" != typeof Symbol &&
                        Symbol.toStringTag &&
                        h.defineProperty(R.prototype, Symbol.toStringTag, {
                          get: function () {
                            return "Object";
                          },
                        }),
                      (R.defer = R.pending =
                        function () {
                          return (
                            k.deprecated("Promise.defer", "new Promise"),
                            { promise: new R(_), resolve: D, reject: F }
                          );
                        }),
                      u.notEnumerableProp(R, "_makeSelfResolutionError", r),
                      e("./method")(R, _, x, a, k),
                      e("./bind")(R, _, x, k),
                      e("./cancel")(R, S, a, k),
                      e("./direct_resolve")(R),
                      e("./synchronous_inspection")(R),
                      e("./join")(R, S, x, _, g),
                      (R.Promise = R),
                      (R.version = "3.7.2"),
                      e("./call_get.js")(R),
                      e("./generators.js")(R, a, _, x, o, k),
                      e("./map.js")(R, S, a, x, _, k),
                      e("./nodeify.js")(R),
                      e("./promisify.js")(R, _),
                      e("./props.js")(R, S, x, a),
                      e("./race.js")(R, _, x, a),
                      e("./reduce.js")(R, S, a, x, _, k),
                      e("./settle.js")(R, S, k),
                      e("./some.js")(R, S, a),
                      e("./timers.js")(R, _, k),
                      e("./using.js")(R, a, x, A, _, k),
                      e("./any.js")(R),
                      e("./each.js")(R, _),
                      e("./filter.js")(R, _),
                      u.toFastProperties(R),
                      u.toFastProperties(R.prototype),
                      j({ a: 1 }),
                      j({ b: 2 }),
                      j({ c: 3 }),
                      j(1),
                      j(function () {}),
                      j(void 0),
                      j(!1),
                      j(new R(_)),
                      k.setBounds(m.firstLineError, u.lastLineError),
                      R
                    );
                  };
                },
                {
                  "./any.js": 1,
                  "./async": 2,
                  "./bind": 3,
                  "./call_get.js": 5,
                  "./cancel": 6,
                  "./catch_filter": 7,
                  "./context": 8,
                  "./debuggability": 9,
                  "./direct_resolve": 10,
                  "./each.js": 11,
                  "./errors": 12,
                  "./es5": 13,
                  "./filter.js": 14,
                  "./finally": 15,
                  "./generators.js": 16,
                  "./join": 17,
                  "./map.js": 18,
                  "./method": 19,
                  "./nodeback": 20,
                  "./nodeify.js": 21,
                  "./promise_array": 23,
                  "./promisify.js": 24,
                  "./props.js": 25,
                  "./race.js": 27,
                  "./reduce.js": 28,
                  "./settle.js": 30,
                  "./some.js": 31,
                  "./synchronous_inspection": 32,
                  "./thenables": 33,
                  "./timers.js": 34,
                  "./using.js": 35,
                  "./util": 36,
                  async_hooks: void 0,
                },
              ],
              23: [
                function (e, t, r) {
                  "use strict";
                  t.exports = function (t, r, n, i, a) {
                    var o = e("./util");
                    function s(e) {
                      var n = (this._promise = new t(r));
                      e instanceof t &&
                        (n._propagateFrom(e, 3),
                        e.suppressUnhandledRejections()),
                        n._setOnCancel(this),
                        (this._values = e),
                        (this._length = 0),
                        (this._totalResolved = 0),
                        this._init(void 0, -2);
                    }
                    return (
                      o.isArray,
                      o.inherits(s, a),
                      (s.prototype.length = function () {
                        return this._length;
                      }),
                      (s.prototype.promise = function () {
                        return this._promise;
                      }),
                      (s.prototype._init = function e(r, a) {
                        var s = n(this._values, this._promise);
                        if (s instanceof t) {
                          var u = (s = s._target())._bitField;
                          if (((this._values = s), 0 == (50397184 & u)))
                            return (
                              this._promise._setAsyncGuaranteed(),
                              s._then(e, this._reject, void 0, this, a)
                            );
                          if (0 == (33554432 & u))
                            return 0 != (16777216 & u)
                              ? this._reject(s._reason())
                              : this._cancel();
                          s = s._value();
                        }
                        if (null !== (s = o.asArray(s)))
                          0 !== s.length
                            ? this._iterate(s)
                            : -5 === a
                            ? this._resolveEmptyArray()
                            : this._resolve(
                                (function (e) {
                                  switch (e) {
                                    case -2:
                                      return [];
                                    case -3:
                                      return {};
                                    case -6:
                                      return new Map();
                                  }
                                })(a)
                              );
                        else {
                          var c = i(
                            "expecting an array or an iterable object but got " +
                              o.classString(s)
                          ).reason();
                          this._promise._rejectCallback(c, !1);
                        }
                      }),
                      (s.prototype._iterate = function (e) {
                        var r = this.getActualLength(e.length);
                        (this._length = r),
                          (this._values = this.shouldCopyValues()
                            ? new Array(r)
                            : this._values);
                        for (
                          var i = this._promise, a = !1, o = null, s = 0;
                          s < r;
                          ++s
                        ) {
                          var u = n(e[s], i);
                          (o =
                            u instanceof t
                              ? (u = u._target())._bitField
                              : null),
                            a
                              ? null !== o && u.suppressUnhandledRejections()
                              : null !== o
                              ? 0 == (50397184 & o)
                                ? (u._proxy(this, s), (this._values[s] = u))
                                : (a =
                                    0 != (33554432 & o)
                                      ? this._promiseFulfilled(u._value(), s)
                                      : 0 != (16777216 & o)
                                      ? this._promiseRejected(u._reason(), s)
                                      : this._promiseCancelled(s))
                              : (a = this._promiseFulfilled(u, s));
                        }
                        a || i._setAsyncGuaranteed();
                      }),
                      (s.prototype._isResolved = function () {
                        return null === this._values;
                      }),
                      (s.prototype._resolve = function (e) {
                        (this._values = null), this._promise._fulfill(e);
                      }),
                      (s.prototype._cancel = function () {
                        !this._isResolved() &&
                          this._promise._isCancellable() &&
                          ((this._values = null), this._promise._cancel());
                      }),
                      (s.prototype._reject = function (e) {
                        (this._values = null),
                          this._promise._rejectCallback(e, !1);
                      }),
                      (s.prototype._promiseFulfilled = function (e, t) {
                        return (
                          (this._values[t] = e),
                          ++this._totalResolved >= this._length &&
                            (this._resolve(this._values), !0)
                        );
                      }),
                      (s.prototype._promiseCancelled = function () {
                        return this._cancel(), !0;
                      }),
                      (s.prototype._promiseRejected = function (e) {
                        return this._totalResolved++, this._reject(e), !0;
                      }),
                      (s.prototype._resultCancelled = function () {
                        if (!this._isResolved()) {
                          var e = this._values;
                          if ((this._cancel(), e instanceof t)) e.cancel();
                          else
                            for (var r = 0; r < e.length; ++r)
                              e[r] instanceof t && e[r].cancel();
                        }
                      }),
                      (s.prototype.shouldCopyValues = function () {
                        return !0;
                      }),
                      (s.prototype.getActualLength = function (e) {
                        return e;
                      }),
                      s
                    );
                  };
                },
                { "./util": 36 },
              ],
              24: [
                function (e, t, r) {
                  "use strict";
                  t.exports = function (t, r) {
                    var n = {},
                      i = e("./util"),
                      a = e("./nodeback"),
                      o = i.withAppended,
                      s = i.maybeWrapAsError,
                      u = i.canEvaluate,
                      c = e("./errors").TypeError,
                      l = { __isPromisified__: !0 },
                      d = new RegExp(
                        "^(?:" +
                          [
                            "arity",
                            "length",
                            "name",
                            "arguments",
                            "caller",
                            "callee",
                            "prototype",
                            "__isPromisified__",
                          ].join("|") +
                          ")$"
                      ),
                      p = function (e) {
                        return (
                          i.isIdentifier(e) &&
                          "_" !== e.charAt(0) &&
                          "constructor" !== e
                        );
                      };
                    function f(e) {
                      return !d.test(e);
                    }
                    function h(e) {
                      try {
                        return !0 === e.__isPromisified__;
                      } catch (e) {
                        return !1;
                      }
                    }
                    function m(e, t, r) {
                      var n = i.getDataPropertyOrDefault(e, t + r, l);
                      return !!n && h(n);
                    }
                    function g(e, t, r, n) {
                      for (
                        var a = i.inheritedDataKeys(e), o = [], s = 0;
                        s < a.length;
                        ++s
                      ) {
                        var u = a[s],
                          l = e[u],
                          d = n === p || p(u, l, e);
                        "function" != typeof l ||
                          h(l) ||
                          m(e, u, t) ||
                          !n(u, l, e, d) ||
                          o.push(u, l);
                      }
                      return (
                        (function (e, t, r) {
                          for (var n = 0; n < e.length; n += 2) {
                            var i = e[n];
                            if (r.test(i))
                              for (
                                var a = i.replace(r, ""), o = 0;
                                o < e.length;
                                o += 2
                              )
                                if (e[o] === a)
                                  throw new c(
                                    "Cannot promisify an API that has normal methods with '%s'-suffix\n\n    See http://goo.gl/MqrFmX\n".replace(
                                      "%s",
                                      t
                                    )
                                  );
                          }
                        })(o, t, r),
                        o
                      );
                    }
                    var y = u
                      ? void 0
                      : function (e, u, c, l, d, p) {
                          var f = (function () {
                              return this;
                            })(),
                            h = e;
                          function m() {
                            var i = u;
                            u === n && (i = this);
                            var c = new t(r);
                            c._captureStackTrace();
                            var l =
                                "string" == typeof h && this !== f
                                  ? this[h]
                                  : e,
                              d = a(c, p);
                            try {
                              l.apply(i, o(arguments, d));
                            } catch (e) {
                              c._rejectCallback(s(e), !0, !0);
                            }
                            return (
                              c._isFateSealed() || c._setAsyncGuaranteed(), c
                            );
                          }
                          return (
                            "string" == typeof h && (e = l),
                            i.notEnumerableProp(m, "__isPromisified__", !0),
                            m
                          );
                        };
                    function v(e, t, r, a, o) {
                      for (
                        var s = new RegExp(t.replace(/([$])/, "\\$") + "$"),
                          u = g(e, t, s, r),
                          c = 0,
                          l = u.length;
                        c < l;
                        c += 2
                      ) {
                        var d = u[c],
                          p = u[c + 1],
                          f = d + t;
                        if (a === y) e[f] = y(d, n, d, p, t, o);
                        else {
                          var h = a(p, function () {
                            return y(d, n, d, p, t, o);
                          });
                          i.notEnumerableProp(h, "__isPromisified__", !0),
                            (e[f] = h);
                        }
                      }
                      return i.toFastProperties(e), e;
                    }
                    (t.promisify = function (e, t) {
                      if ("function" != typeof e)
                        throw new c(
                          "expecting a function but got " + i.classString(e)
                        );
                      if (h(e)) return e;
                      var r = (function (e, t, r) {
                        return y(e, t, void 0, e, null, r);
                      })(
                        e,
                        void 0 === (t = Object(t)).context ? n : t.context,
                        !!t.multiArgs
                      );
                      return i.copyDescriptors(e, r, f), r;
                    }),
                      (t.promisifyAll = function (e, t) {
                        if ("function" != typeof e && "object" != typeof e)
                          throw new c(
                            "the target of promisifyAll must be an object or a function\n\n    See http://goo.gl/MqrFmX\n"
                          );
                        var r = !!(t = Object(t)).multiArgs,
                          n = t.suffix;
                        "string" != typeof n && (n = "Async");
                        var a = t.filter;
                        "function" != typeof a && (a = p);
                        var o = t.promisifier;
                        if (
                          ("function" != typeof o && (o = y),
                          !i.isIdentifier(n))
                        )
                          throw new RangeError(
                            "suffix must be a valid identifier\n\n    See http://goo.gl/MqrFmX\n"
                          );
                        for (
                          var s = i.inheritedDataKeys(e), u = 0;
                          u < s.length;
                          ++u
                        ) {
                          var l = e[s[u]];
                          "constructor" !== s[u] &&
                            i.isClass(l) &&
                            (v(l.prototype, n, a, o, r), v(l, n, a, o, r));
                        }
                        return v(e, n, a, o, r);
                      });
                  };
                },
                { "./errors": 12, "./nodeback": 20, "./util": 36 },
              ],
              25: [
                function (e, t, r) {
                  "use strict";
                  t.exports = function (t, r, n, i) {
                    var a,
                      o = e("./util"),
                      s = o.isObject,
                      u = e("./es5");
                    "function" == typeof Map && (a = Map);
                    var c = (function () {
                      var e = 0,
                        t = 0;
                      function r(r, n) {
                        (this[e] = r), (this[e + t] = n), e++;
                      }
                      return function (n) {
                        (t = n.size), (e = 0);
                        var i = new Array(2 * n.size);
                        return n.forEach(r, i), i;
                      };
                    })();
                    function l(e) {
                      var t,
                        r = !1;
                      if (void 0 !== a && e instanceof a) (t = c(e)), (r = !0);
                      else {
                        var n = u.keys(e),
                          i = n.length;
                        t = new Array(2 * i);
                        for (var o = 0; o < i; ++o) {
                          var s = n[o];
                          (t[o] = e[s]), (t[o + i] = s);
                        }
                      }
                      this.constructor$(t),
                        (this._isMap = r),
                        this._init$(void 0, r ? -6 : -3);
                    }
                    function d(e) {
                      var r,
                        a = n(e);
                      return s(a)
                        ? ((r =
                            a instanceof t
                              ? a._then(t.props, void 0, void 0, void 0, void 0)
                              : new l(a).promise()),
                          a instanceof t && r._propagateFrom(a, 2),
                          r)
                        : i(
                            "cannot await properties of a non-object\n\n    See http://goo.gl/MqrFmX\n"
                          );
                    }
                    o.inherits(l, r),
                      (l.prototype._init = function () {}),
                      (l.prototype._promiseFulfilled = function (e, t) {
                        if (
                          ((this._values[t] = e),
                          ++this._totalResolved >= this._length)
                        ) {
                          var r;
                          if (this._isMap)
                            r = (function (e) {
                              for (
                                var t = new a(), r = (e.length / 2) | 0, n = 0;
                                n < r;
                                ++n
                              ) {
                                var i = e[r + n],
                                  o = e[n];
                                t.set(i, o);
                              }
                              return t;
                            })(this._values);
                          else {
                            r = {};
                            for (
                              var n = this.length(), i = 0, o = this.length();
                              i < o;
                              ++i
                            )
                              r[this._values[i + n]] = this._values[i];
                          }
                          return this._resolve(r), !0;
                        }
                        return !1;
                      }),
                      (l.prototype.shouldCopyValues = function () {
                        return !1;
                      }),
                      (l.prototype.getActualLength = function (e) {
                        return e >> 1;
                      }),
                      (t.prototype.props = function () {
                        return d(this);
                      }),
                      (t.props = function (e) {
                        return d(e);
                      });
                  };
                },
                { "./es5": 13, "./util": 36 },
              ],
              26: [
                function (e, t, r) {
                  "use strict";
                  function n(e) {
                    (this._capacity = e), (this._length = 0), (this._front = 0);
                  }
                  (n.prototype._willBeOverCapacity = function (e) {
                    return this._capacity < e;
                  }),
                    (n.prototype._pushOne = function (e) {
                      var t = this.length();
                      this._checkCapacity(t + 1),
                        (this[(this._front + t) & (this._capacity - 1)] = e),
                        (this._length = t + 1);
                    }),
                    (n.prototype.push = function (e, t, r) {
                      var n = this.length() + 3;
                      if (this._willBeOverCapacity(n))
                        return (
                          this._pushOne(e),
                          this._pushOne(t),
                          void this._pushOne(r)
                        );
                      var i = this._front + n - 3;
                      this._checkCapacity(n);
                      var a = this._capacity - 1;
                      (this[(i + 0) & a] = e),
                        (this[(i + 1) & a] = t),
                        (this[(i + 2) & a] = r),
                        (this._length = n);
                    }),
                    (n.prototype.shift = function () {
                      var e = this._front,
                        t = this[e];
                      return (
                        (this[e] = void 0),
                        (this._front = (e + 1) & (this._capacity - 1)),
                        this._length--,
                        t
                      );
                    }),
                    (n.prototype.length = function () {
                      return this._length;
                    }),
                    (n.prototype._checkCapacity = function (e) {
                      this._capacity < e && this._resizeTo(this._capacity << 1);
                    }),
                    (n.prototype._resizeTo = function (e) {
                      var t = this._capacity;
                      (this._capacity = e),
                        (function (e, t, r, n, i) {
                          for (var a = 0; a < i; ++a)
                            (r[a + n] = e[a + t]), (e[a + t] = void 0);
                        })(
                          this,
                          0,
                          this,
                          t,
                          (this._front + this._length) & (t - 1)
                        );
                    }),
                    (t.exports = n);
                },
                {},
              ],
              27: [
                function (e, t, r) {
                  "use strict";
                  t.exports = function (t, r, n, i) {
                    var a = e("./util");
                    function o(e, s) {
                      var u,
                        c = n(e);
                      if (c instanceof t)
                        return (u = c).then(function (e) {
                          return o(e, u);
                        });
                      if (null === (e = a.asArray(e)))
                        return i(
                          "expecting an array or an iterable object but got " +
                            a.classString(e)
                        );
                      var l = new t(r);
                      void 0 !== s && l._propagateFrom(s, 3);
                      for (
                        var d = l._fulfill, p = l._reject, f = 0, h = e.length;
                        f < h;
                        ++f
                      ) {
                        var m = e[f];
                        (void 0 !== m || f in e) &&
                          t.cast(m)._then(d, p, void 0, l, null);
                      }
                      return l;
                    }
                    (t.race = function (e) {
                      return o(e, void 0);
                    }),
                      (t.prototype.race = function () {
                        return o(this, void 0);
                      });
                  };
                },
                { "./util": 36 },
              ],
              28: [
                function (e, t, r) {
                  "use strict";
                  t.exports = function (t, r, n, i, a, o) {
                    var s = e("./util"),
                      u = s.tryCatch;
                    function c(e, r, n, i) {
                      this.constructor$(e);
                      var o = t._getContext();
                      (this._fn = s.contextBind(o, r)),
                        void 0 !== n &&
                          (n = t.resolve(n))._attachCancellationCallback(this),
                        (this._initialValue = n),
                        (this._currentCancellable = null),
                        (this._eachValues =
                          i === a
                            ? Array(this._length)
                            : 0 === i
                            ? null
                            : void 0),
                        this._promise._captureStackTrace(),
                        this._init$(void 0, -5);
                    }
                    function l(e, t) {
                      this.isFulfilled() ? t._resolve(e) : t._reject(e);
                    }
                    function d(e, t, r, i) {
                      return "function" != typeof t
                        ? n("expecting a function but got " + s.classString(t))
                        : new c(e, t, r, i).promise();
                    }
                    function p(e) {
                      (this.accum = e), this.array._gotAccum(e);
                      var r = i(this.value, this.array._promise);
                      return r instanceof t
                        ? ((this.array._currentCancellable = r),
                          r._then(f, void 0, void 0, this, void 0))
                        : f.call(this, r);
                    }
                    function f(e) {
                      var r,
                        n = this.array,
                        i = n._promise,
                        a = u(n._fn);
                      i._pushContext(),
                        (r =
                          void 0 !== n._eachValues
                            ? a.call(
                                i._boundValue(),
                                e,
                                this.index,
                                this.length
                              )
                            : a.call(
                                i._boundValue(),
                                this.accum,
                                e,
                                this.index,
                                this.length
                              )) instanceof t && (n._currentCancellable = r);
                      var s = i._popContext();
                      return (
                        o.checkForgottenReturns(
                          r,
                          s,
                          void 0 !== n._eachValues
                            ? "Promise.each"
                            : "Promise.reduce",
                          i
                        ),
                        r
                      );
                    }
                    s.inherits(c, r),
                      (c.prototype._gotAccum = function (e) {
                        void 0 !== this._eachValues &&
                          null !== this._eachValues &&
                          e !== a &&
                          this._eachValues.push(e);
                      }),
                      (c.prototype._eachComplete = function (e) {
                        return (
                          null !== this._eachValues && this._eachValues.push(e),
                          this._eachValues
                        );
                      }),
                      (c.prototype._init = function () {}),
                      (c.prototype._resolveEmptyArray = function () {
                        this._resolve(
                          void 0 !== this._eachValues
                            ? this._eachValues
                            : this._initialValue
                        );
                      }),
                      (c.prototype.shouldCopyValues = function () {
                        return !1;
                      }),
                      (c.prototype._resolve = function (e) {
                        this._promise._resolveCallback(e),
                          (this._values = null);
                      }),
                      (c.prototype._resultCancelled = function (e) {
                        if (e === this._initialValue) return this._cancel();
                        this._isResolved() ||
                          (this._resultCancelled$(),
                          this._currentCancellable instanceof t &&
                            this._currentCancellable.cancel(),
                          this._initialValue instanceof t &&
                            this._initialValue.cancel());
                      }),
                      (c.prototype._iterate = function (e) {
                        var r, n;
                        this._values = e;
                        var i = e.length;
                        void 0 !== this._initialValue
                          ? ((r = this._initialValue), (n = 0))
                          : ((r = t.resolve(e[0])), (n = 1)),
                          (this._currentCancellable = r);
                        for (var a = n; a < i; ++a) {
                          var o = e[a];
                          o instanceof t && o.suppressUnhandledRejections();
                        }
                        if (!r.isRejected())
                          for (; n < i; ++n) {
                            var s = {
                              accum: null,
                              value: e[n],
                              index: n,
                              length: i,
                              array: this,
                            };
                            (r = r._then(p, void 0, void 0, s, void 0)),
                              0 == (127 & n) && r._setNoAsyncGuarantee();
                          }
                        void 0 !== this._eachValues &&
                          (r = r._then(
                            this._eachComplete,
                            void 0,
                            void 0,
                            this,
                            void 0
                          )),
                          r._then(l, l, void 0, r, this);
                      }),
                      (t.prototype.reduce = function (e, t) {
                        return d(this, e, t, null);
                      }),
                      (t.reduce = function (e, t, r, n) {
                        return d(e, t, r, n);
                      });
                  };
                },
                { "./util": 36 },
              ],
              29: [
                function (e, t, i) {
                  "use strict";
                  var a,
                    o,
                    s,
                    u,
                    c,
                    l = e("./util"),
                    d = l.getNativePromise();
                  if (l.isNode && "undefined" == typeof MutationObserver) {
                    var p = r.g.setImmediate,
                      f = n.nextTick;
                    a = l.isRecentNode
                      ? function (e) {
                          p.call(r.g, e);
                        }
                      : function (e) {
                          f.call(n, e);
                        };
                  } else if (
                    "function" == typeof d &&
                    "function" == typeof d.resolve
                  ) {
                    var h = d.resolve();
                    a = function (e) {
                      h.then(e);
                    };
                  } else
                    a =
                      "undefined" == typeof MutationObserver ||
                      ("undefined" != typeof window &&
                        window.navigator &&
                        (window.navigator.standalone || window.cordova)) ||
                      !("classList" in document.documentElement)
                        ? "undefined" != typeof setImmediate
                          ? function (e) {
                              setImmediate(e);
                            }
                          : "undefined" != typeof setTimeout
                          ? function (e) {
                              setTimeout(e, 0);
                            }
                          : function () {
                              throw new Error(
                                "No async scheduler available\n\n    See http://goo.gl/MqrFmX\n"
                              );
                            }
                        : ((o = document.createElement("div")),
                          (s = { attributes: !0 }),
                          (u = !1),
                          (c = document.createElement("div")),
                          new MutationObserver(function () {
                            o.classList.toggle("foo"), (u = !1);
                          }).observe(c, s),
                          function (e) {
                            var t = new MutationObserver(function () {
                              t.disconnect(), e();
                            });
                            t.observe(o, s),
                              u || ((u = !0), c.classList.toggle("foo"));
                          });
                  t.exports = a;
                },
                { "./util": 36 },
              ],
              30: [
                function (e, t, r) {
                  "use strict";
                  t.exports = function (t, r, n) {
                    var i = t.PromiseInspection;
                    function a(e) {
                      this.constructor$(e);
                    }
                    e("./util").inherits(a, r),
                      (a.prototype._promiseResolved = function (e, t) {
                        return (
                          (this._values[e] = t),
                          ++this._totalResolved >= this._length &&
                            (this._resolve(this._values), !0)
                        );
                      }),
                      (a.prototype._promiseFulfilled = function (e, t) {
                        var r = new i();
                        return (
                          (r._bitField = 33554432),
                          (r._settledValueField = e),
                          this._promiseResolved(t, r)
                        );
                      }),
                      (a.prototype._promiseRejected = function (e, t) {
                        var r = new i();
                        return (
                          (r._bitField = 16777216),
                          (r._settledValueField = e),
                          this._promiseResolved(t, r)
                        );
                      }),
                      (t.settle = function (e) {
                        return (
                          n.deprecated(".settle()", ".reflect()"),
                          new a(e).promise()
                        );
                      }),
                      (t.allSettled = function (e) {
                        return new a(e).promise();
                      }),
                      (t.prototype.settle = function () {
                        return t.settle(this);
                      });
                  };
                },
                { "./util": 36 },
              ],
              31: [
                function (e, t, r) {
                  "use strict";
                  t.exports = function (t, r, n) {
                    var i = e("./util"),
                      a = e("./errors").RangeError,
                      o = e("./errors").AggregateError,
                      s = i.isArray,
                      u = {};
                    function c(e) {
                      this.constructor$(e),
                        (this._howMany = 0),
                        (this._unwrap = !1),
                        (this._initialized = !1);
                    }
                    function l(e, t) {
                      if ((0 | t) !== t || t < 0)
                        return n(
                          "expecting a positive integer\n\n    See http://goo.gl/MqrFmX\n"
                        );
                      var r = new c(e),
                        i = r.promise();
                      return r.setHowMany(t), r.init(), i;
                    }
                    i.inherits(c, r),
                      (c.prototype._init = function () {
                        if (this._initialized)
                          if (0 !== this._howMany) {
                            this._init$(void 0, -5);
                            var e = s(this._values);
                            !this._isResolved() &&
                              e &&
                              this._howMany > this._canPossiblyFulfill() &&
                              this._reject(this._getRangeError(this.length()));
                          } else this._resolve([]);
                      }),
                      (c.prototype.init = function () {
                        (this._initialized = !0), this._init();
                      }),
                      (c.prototype.setUnwrap = function () {
                        this._unwrap = !0;
                      }),
                      (c.prototype.howMany = function () {
                        return this._howMany;
                      }),
                      (c.prototype.setHowMany = function (e) {
                        this._howMany = e;
                      }),
                      (c.prototype._promiseFulfilled = function (e) {
                        return (
                          this._addFulfilled(e),
                          this._fulfilled() === this.howMany() &&
                            ((this._values.length = this.howMany()),
                            1 === this.howMany() && this._unwrap
                              ? this._resolve(this._values[0])
                              : this._resolve(this._values),
                            !0)
                        );
                      }),
                      (c.prototype._promiseRejected = function (e) {
                        return this._addRejected(e), this._checkOutcome();
                      }),
                      (c.prototype._promiseCancelled = function () {
                        return this._values instanceof t || null == this._values
                          ? this._cancel()
                          : (this._addRejected(u), this._checkOutcome());
                      }),
                      (c.prototype._checkOutcome = function () {
                        if (this.howMany() > this._canPossiblyFulfill()) {
                          for (
                            var e = new o(), t = this.length();
                            t < this._values.length;
                            ++t
                          )
                            this._values[t] !== u && e.push(this._values[t]);
                          return (
                            e.length > 0 ? this._reject(e) : this._cancel(), !0
                          );
                        }
                        return !1;
                      }),
                      (c.prototype._fulfilled = function () {
                        return this._totalResolved;
                      }),
                      (c.prototype._rejected = function () {
                        return this._values.length - this.length();
                      }),
                      (c.prototype._addRejected = function (e) {
                        this._values.push(e);
                      }),
                      (c.prototype._addFulfilled = function (e) {
                        this._values[this._totalResolved++] = e;
                      }),
                      (c.prototype._canPossiblyFulfill = function () {
                        return this.length() - this._rejected();
                      }),
                      (c.prototype._getRangeError = function (e) {
                        var t =
                          "Input array must contain at least " +
                          this._howMany +
                          " items but contains only " +
                          e +
                          " items";
                        return new a(t);
                      }),
                      (c.prototype._resolveEmptyArray = function () {
                        this._reject(this._getRangeError(0));
                      }),
                      (t.some = function (e, t) {
                        return l(e, t);
                      }),
                      (t.prototype.some = function (e) {
                        return l(this, e);
                      }),
                      (t._SomePromiseArray = c);
                  };
                },
                { "./errors": 12, "./util": 36 },
              ],
              32: [
                function (e, t, r) {
                  "use strict";
                  t.exports = function (e) {
                    function t(e) {
                      void 0 !== e
                        ? ((e = e._target()),
                          (this._bitField = e._bitField),
                          (this._settledValueField = e._isFateSealed()
                            ? e._settledValue()
                            : void 0))
                        : ((this._bitField = 0),
                          (this._settledValueField = void 0));
                    }
                    t.prototype._settledValue = function () {
                      return this._settledValueField;
                    };
                    var r = (t.prototype.value = function () {
                        if (!this.isFulfilled())
                          throw new TypeError(
                            "cannot get fulfillment value of a non-fulfilled promise\n\n    See http://goo.gl/MqrFmX\n"
                          );
                        return this._settledValue();
                      }),
                      n =
                        (t.prototype.error =
                        t.prototype.reason =
                          function () {
                            if (!this.isRejected())
                              throw new TypeError(
                                "cannot get rejection reason of a non-rejected promise\n\n    See http://goo.gl/MqrFmX\n"
                              );
                            return this._settledValue();
                          }),
                      i = (t.prototype.isFulfilled = function () {
                        return 0 != (33554432 & this._bitField);
                      }),
                      a = (t.prototype.isRejected = function () {
                        return 0 != (16777216 & this._bitField);
                      }),
                      o = (t.prototype.isPending = function () {
                        return 0 == (50397184 & this._bitField);
                      }),
                      s = (t.prototype.isResolved = function () {
                        return 0 != (50331648 & this._bitField);
                      });
                    (t.prototype.isCancelled = function () {
                      return 0 != (8454144 & this._bitField);
                    }),
                      (e.prototype.__isCancelled = function () {
                        return 65536 == (65536 & this._bitField);
                      }),
                      (e.prototype._isCancelled = function () {
                        return this._target().__isCancelled();
                      }),
                      (e.prototype.isCancelled = function () {
                        return 0 != (8454144 & this._target()._bitField);
                      }),
                      (e.prototype.isPending = function () {
                        return o.call(this._target());
                      }),
                      (e.prototype.isRejected = function () {
                        return a.call(this._target());
                      }),
                      (e.prototype.isFulfilled = function () {
                        return i.call(this._target());
                      }),
                      (e.prototype.isResolved = function () {
                        return s.call(this._target());
                      }),
                      (e.prototype.value = function () {
                        return r.call(this._target());
                      }),
                      (e.prototype.reason = function () {
                        var e = this._target();
                        return e._unsetRejectionIsUnhandled(), n.call(e);
                      }),
                      (e.prototype._value = function () {
                        return this._settledValue();
                      }),
                      (e.prototype._reason = function () {
                        return (
                          this._unsetRejectionIsUnhandled(),
                          this._settledValue()
                        );
                      }),
                      (e.PromiseInspection = t);
                  };
                },
                {},
              ],
              33: [
                function (e, t, r) {
                  "use strict";
                  t.exports = function (t, r) {
                    var n = e("./util"),
                      i = n.errorObj,
                      a = n.isObject,
                      o = {}.hasOwnProperty;
                    return function (e, s) {
                      if (a(e)) {
                        if (e instanceof t) return e;
                        var u = (function (e) {
                          try {
                            return (function (e) {
                              return e.then;
                            })(e);
                          } catch (e) {
                            return (i.e = e), i;
                          }
                        })(e);
                        if (u === i) {
                          s && s._pushContext();
                          var c = t.reject(u.e);
                          return s && s._popContext(), c;
                        }
                        if ("function" == typeof u)
                          return (function (e) {
                            try {
                              return o.call(e, "_promise0");
                            } catch (e) {
                              return !1;
                            }
                          })(e)
                            ? ((c = new t(r)),
                              e._then(c._fulfill, c._reject, void 0, c, null),
                              c)
                            : (function (e, a, o) {
                                var s = new t(r),
                                  u = s;
                                o && o._pushContext(),
                                  s._captureStackTrace(),
                                  o && o._popContext();
                                var c = !0,
                                  l = n.tryCatch(a).call(e, d, p);
                                function d(e) {
                                  s && (s._resolveCallback(e), (s = null));
                                }
                                function p(e) {
                                  s &&
                                    (s._rejectCallback(e, c, !0), (s = null));
                                }
                                return (
                                  (c = !1),
                                  s &&
                                    l === i &&
                                    (s._rejectCallback(l.e, !0, !0),
                                    (s = null)),
                                  u
                                );
                              })(e, u, s);
                      }
                      return e;
                    };
                  };
                },
                { "./util": 36 },
              ],
              34: [
                function (e, t, r) {
                  "use strict";
                  t.exports = function (t, r, n) {
                    var i = e("./util"),
                      a = t.TimeoutError;
                    function o(e) {
                      this.handle = e;
                    }
                    o.prototype._resultCancelled = function () {
                      clearTimeout(this.handle);
                    };
                    var s = function (e) {
                        return u(+this).thenReturn(e);
                      },
                      u = (t.delay = function (e, i) {
                        var a, u;
                        return (
                          void 0 !== i
                            ? ((a = t
                                .resolve(i)
                                ._then(s, null, null, e, void 0)),
                              n.cancellation() &&
                                i instanceof t &&
                                a._setOnCancel(i))
                            : ((a = new t(r)),
                              (u = setTimeout(function () {
                                a._fulfill();
                              }, +e)),
                              n.cancellation() && a._setOnCancel(new o(u)),
                              a._captureStackTrace()),
                          a._setAsyncGuaranteed(),
                          a
                        );
                      });
                    function c(e) {
                      return clearTimeout(this.handle), e;
                    }
                    function l(e) {
                      throw (clearTimeout(this.handle), e);
                    }
                    (t.prototype.delay = function (e) {
                      return u(e, this);
                    }),
                      (t.prototype.timeout = function (e, t) {
                        var r, s;
                        e = +e;
                        var u = new o(
                          setTimeout(function () {
                            r.isPending() &&
                              (function (e, t, r) {
                                var n;
                                (n =
                                  "string" != typeof t
                                    ? t instanceof Error
                                      ? t
                                      : new a("operation timed out")
                                    : new a(t)),
                                  i.markAsOriginatingFromRejection(n),
                                  e._attachExtraTrace(n),
                                  e._reject(n),
                                  null != r && r.cancel();
                              })(r, t, s);
                          }, e)
                        );
                        return (
                          n.cancellation()
                            ? ((s = this.then()),
                              (r = s._then(
                                c,
                                l,
                                void 0,
                                u,
                                void 0
                              ))._setOnCancel(u))
                            : (r = this._then(c, l, void 0, u, void 0)),
                          r
                        );
                      });
                  };
                },
                { "./util": 36 },
              ],
              35: [
                function (e, t, r) {
                  "use strict";
                  t.exports = function (t, r, n, i, a, o) {
                    var s = e("./util"),
                      u = e("./errors").TypeError,
                      c = e("./util").inherits,
                      l = s.errorObj,
                      d = s.tryCatch,
                      p = {};
                    function f(e) {
                      setTimeout(function () {
                        throw e;
                      }, 0);
                    }
                    function h(e, r) {
                      var i = 0,
                        o = e.length,
                        s = new t(a);
                      return (
                        (function a() {
                          if (i >= o) return s._fulfill();
                          var u = (function (e) {
                            var t = n(e);
                            return (
                              t !== e &&
                                "function" == typeof e._isDisposable &&
                                "function" == typeof e._getDisposer &&
                                e._isDisposable() &&
                                t._setDisposable(e._getDisposer()),
                              t
                            );
                          })(e[i++]);
                          if (u instanceof t && u._isDisposable()) {
                            try {
                              u = n(u._getDisposer().tryDispose(r), e.promise);
                            } catch (e) {
                              return f(e);
                            }
                            if (u instanceof t)
                              return u._then(a, f, null, null, null);
                          }
                          a();
                        })(),
                        s
                      );
                    }
                    function m(e, t, r) {
                      (this._data = e),
                        (this._promise = t),
                        (this._context = r);
                    }
                    function g(e, t, r) {
                      this.constructor$(e, t, r);
                    }
                    function y(e) {
                      return m.isDisposer(e)
                        ? (this.resources[this.index]._setDisposable(e),
                          e.promise())
                        : e;
                    }
                    function v(e) {
                      (this.length = e),
                        (this.promise = null),
                        (this[e - 1] = null);
                    }
                    (m.prototype.data = function () {
                      return this._data;
                    }),
                      (m.prototype.promise = function () {
                        return this._promise;
                      }),
                      (m.prototype.resource = function () {
                        return this.promise().isFulfilled()
                          ? this.promise().value()
                          : p;
                      }),
                      (m.prototype.tryDispose = function (e) {
                        var t = this.resource(),
                          r = this._context;
                        void 0 !== r && r._pushContext();
                        var n = t !== p ? this.doDispose(t, e) : null;
                        return (
                          void 0 !== r && r._popContext(),
                          this._promise._unsetDisposable(),
                          (this._data = null),
                          n
                        );
                      }),
                      (m.isDisposer = function (e) {
                        return (
                          null != e &&
                          "function" == typeof e.resource &&
                          "function" == typeof e.tryDispose
                        );
                      }),
                      c(g, m),
                      (g.prototype.doDispose = function (e, t) {
                        return this.data().call(e, e, t);
                      }),
                      (v.prototype._resultCancelled = function () {
                        for (var e = this.length, r = 0; r < e; ++r) {
                          var n = this[r];
                          n instanceof t && n.cancel();
                        }
                      }),
                      (t.using = function () {
                        var e = arguments.length;
                        if (e < 2)
                          return r(
                            "you must pass at least 2 arguments to Promise.using"
                          );
                        var i,
                          a = arguments[e - 1];
                        if ("function" != typeof a)
                          return r(
                            "expecting a function but got " + s.classString(a)
                          );
                        var u = !0;
                        2 === e && Array.isArray(arguments[0])
                          ? ((e = (i = arguments[0]).length), (u = !1))
                          : ((i = arguments), e--);
                        for (var c = new v(e), p = 0; p < e; ++p) {
                          var f = i[p];
                          if (m.isDisposer(f)) {
                            var g = f;
                            (f = f.promise())._setDisposable(g);
                          } else {
                            var b = n(f);
                            b instanceof t &&
                              (f = b._then(
                                y,
                                null,
                                null,
                                { resources: c, index: p },
                                void 0
                              ));
                          }
                          c[p] = f;
                        }
                        var _ = new Array(c.length);
                        for (p = 0; p < _.length; ++p)
                          _[p] = t.resolve(c[p]).reflect();
                        var E = t.all(_).then(function (e) {
                            for (var t = 0; t < e.length; ++t) {
                              var r = e[t];
                              if (r.isRejected()) return (l.e = r.error()), l;
                              if (!r.isFulfilled()) return void E.cancel();
                              e[t] = r.value();
                            }
                            w._pushContext(), (a = d(a));
                            var n = u ? a.apply(void 0, e) : a(e),
                              i = w._popContext();
                            return (
                              o.checkForgottenReturns(n, i, "Promise.using", w),
                              n
                            );
                          }),
                          w = E.lastly(function () {
                            var e = new t.PromiseInspection(E);
                            return h(c, e);
                          });
                        return (c.promise = w), w._setOnCancel(c), w;
                      }),
                      (t.prototype._setDisposable = function (e) {
                        (this._bitField = 131072 | this._bitField),
                          (this._disposer = e);
                      }),
                      (t.prototype._isDisposable = function () {
                        return (131072 & this._bitField) > 0;
                      }),
                      (t.prototype._getDisposer = function () {
                        return this._disposer;
                      }),
                      (t.prototype._unsetDisposable = function () {
                        (this._bitField = -131073 & this._bitField),
                          (this._disposer = void 0);
                      }),
                      (t.prototype.disposer = function (e) {
                        if ("function" == typeof e) return new g(e, this, i());
                        throw new u();
                      });
                  };
                },
                { "./errors": 12, "./util": 36 },
              ],
              36: [
                function (e, t, i) {
                  "use strict";
                  var a = e("./es5"),
                    o = "undefined" == typeof navigator,
                    s = { e: {} },
                    u,
                    c =
                      "undefined" != typeof self
                        ? self
                        : "undefined" != typeof window
                        ? window
                        : void 0 !== r.g
                        ? r.g
                        : void 0 !== this
                        ? this
                        : null;
                  function l() {
                    try {
                      var e = u;
                      return (u = null), e.apply(this, arguments);
                    } catch (e) {
                      return (s.e = e), s;
                    }
                  }
                  function d(e) {
                    return (u = e), l;
                  }
                  var p = function (e, t) {
                    var r = {}.hasOwnProperty;
                    function n() {
                      for (var n in ((this.constructor = e),
                      (this.constructor$ = t),
                      t.prototype))
                        r.call(t.prototype, n) &&
                          "$" !== n.charAt(n.length - 1) &&
                          (this[n + "$"] = t.prototype[n]);
                    }
                    return (
                      (n.prototype = t.prototype),
                      (e.prototype = new n()),
                      e.prototype
                    );
                  };
                  function f(e) {
                    return (
                      null == e ||
                      !0 === e ||
                      !1 === e ||
                      "string" == typeof e ||
                      "number" == typeof e
                    );
                  }
                  function h(e) {
                    return (
                      "function" == typeof e ||
                      ("object" == typeof e && null !== e)
                    );
                  }
                  function m(e) {
                    return f(e) ? new Error(k(e)) : e;
                  }
                  function g(e, t) {
                    var r,
                      n = e.length,
                      i = new Array(n + 1);
                    for (r = 0; r < n; ++r) i[r] = e[r];
                    return (i[r] = t), i;
                  }
                  function y(e, t, r) {
                    if (!a.isES5)
                      return {}.hasOwnProperty.call(e, t) ? e[t] : void 0;
                    var n = Object.getOwnPropertyDescriptor(e, t);
                    return null != n
                      ? null == n.get && null == n.set
                        ? n.value
                        : r
                      : void 0;
                  }
                  function v(e, t, r) {
                    if (f(e)) return e;
                    var n = {
                      value: r,
                      configurable: !0,
                      enumerable: !1,
                      writable: !0,
                    };
                    return a.defineProperty(e, t, n), e;
                  }
                  function b(e) {
                    throw e;
                  }
                  var _ = (function () {
                      var e = [
                          Array.prototype,
                          Object.prototype,
                          Function.prototype,
                        ],
                        t = function (t) {
                          for (var r = 0; r < e.length; ++r)
                            if (e[r] === t) return !0;
                          return !1;
                        };
                      if (a.isES5) {
                        var r = Object.getOwnPropertyNames;
                        return function (e) {
                          for (
                            var n = [], i = Object.create(null);
                            null != e && !t(e);

                          ) {
                            var o;
                            try {
                              o = r(e);
                            } catch (e) {
                              return n;
                            }
                            for (var s = 0; s < o.length; ++s) {
                              var u = o[s];
                              if (!i[u]) {
                                i[u] = !0;
                                var c = Object.getOwnPropertyDescriptor(e, u);
                                null != c &&
                                  null == c.get &&
                                  null == c.set &&
                                  n.push(u);
                              }
                            }
                            e = a.getPrototypeOf(e);
                          }
                          return n;
                        };
                      }
                      var n = {}.hasOwnProperty;
                      return function (r) {
                        if (t(r)) return [];
                        var i = [];
                        e: for (var a in r)
                          if (n.call(r, a)) i.push(a);
                          else {
                            for (var o = 0; o < e.length; ++o)
                              if (n.call(e[o], a)) continue e;
                            i.push(a);
                          }
                        return i;
                      };
                    })(),
                    E = /this\s*\.\s*\S+\s*=/;
                  function w(e) {
                    try {
                      if ("function" == typeof e) {
                        var t = a.names(e.prototype),
                          r = a.isES5 && t.length > 1,
                          n =
                            t.length > 0 &&
                            !(1 === t.length && "constructor" === t[0]),
                          i = E.test(e + "") && a.names(e).length > 0;
                        if (r || n || i) return !0;
                      }
                      return !1;
                    } catch (e) {
                      return !1;
                    }
                  }
                  function x(e) {
                    function t() {}
                    t.prototype = e;
                    var r = new t();
                    function n() {
                      return typeof r.foo;
                    }
                    return n(), n(), e;
                  }
                  var S = /^[a-z$_][a-z$_0-9]*$/i;
                  function T(e) {
                    return S.test(e);
                  }
                  function A(e, t, r) {
                    for (var n = new Array(e), i = 0; i < e; ++i)
                      n[i] = t + i + r;
                    return n;
                  }
                  function k(e) {
                    try {
                      return e + "";
                    } catch (e) {
                      return "[no string representation]";
                    }
                  }
                  function C(e) {
                    return (
                      e instanceof Error ||
                      (null !== e &&
                        "object" == typeof e &&
                        "string" == typeof e.message &&
                        "string" == typeof e.name)
                    );
                  }
                  function O(e) {
                    try {
                      v(e, "isOperational", !0);
                    } catch (e) {}
                  }
                  function P(e) {
                    return (
                      null != e &&
                      (e instanceof
                        Error.__BluebirdErrorTypes__.OperationalError ||
                        !0 === e.isOperational)
                    );
                  }
                  function I(e) {
                    return C(e) && a.propertyIsWritable(e, "stack");
                  }
                  var N =
                    "stack" in new Error()
                      ? function (e) {
                          return I(e) ? e : new Error(k(e));
                        }
                      : function (e) {
                          if (I(e)) return e;
                          try {
                            throw new Error(k(e));
                          } catch (e) {
                            return e;
                          }
                        };
                  function R(e) {
                    return {}.toString.call(e);
                  }
                  function D(e, t, r) {
                    for (var n = a.names(e), i = 0; i < n.length; ++i) {
                      var o = n[i];
                      if (r(o))
                        try {
                          a.defineProperty(t, o, a.getDescriptor(e, o));
                        } catch (e) {}
                    }
                  }
                  var F = function (e) {
                    return a.isArray(e) ? e : null;
                  };
                  if ("undefined" != typeof Symbol && Symbol.iterator) {
                    var j =
                      "function" == typeof Array.from
                        ? function (e) {
                            return Array.from(e);
                          }
                        : function (e) {
                            for (
                              var t, r = [], n = e[Symbol.iterator]();
                              !(t = n.next()).done;

                            )
                              r.push(t.value);
                            return r;
                          };
                    F = function (e) {
                      return a.isArray(e)
                        ? e
                        : null != e && "function" == typeof e[Symbol.iterator]
                        ? j(e)
                        : null;
                    };
                  }
                  var L =
                      void 0 !== n && "[object process]" === R(n).toLowerCase(),
                    M = void 0 !== n && void 0 !== n.env,
                    B;
                  function V(e) {
                    return M ? n.env[e] : void 0;
                  }
                  function U() {
                    if ("function" == typeof Promise)
                      try {
                        if (
                          "[object Promise]" === R(new Promise(function () {}))
                        )
                          return Promise;
                      } catch (e) {}
                  }
                  function H(e, t) {
                    if (null === e || "function" != typeof t || t === B)
                      return t;
                    null !== e.domain && (t = e.domain.bind(t));
                    var r = e.async;
                    if (null !== r) {
                      var n = t;
                      t = function () {
                        var e = new Array(2).concat([].slice.call(arguments));
                        return (
                          (e[0] = n),
                          (e[1] = this),
                          r.runInAsyncScope.apply(r, e)
                        );
                      };
                    }
                    return t;
                  }
                  var q = {
                      setReflectHandler: function (e) {
                        B = e;
                      },
                      isClass: w,
                      isIdentifier: T,
                      inheritedDataKeys: _,
                      getDataPropertyOrDefault: y,
                      thrower: b,
                      isArray: a.isArray,
                      asArray: F,
                      notEnumerableProp: v,
                      isPrimitive: f,
                      isObject: h,
                      isError: C,
                      canEvaluate: o,
                      errorObj: s,
                      tryCatch: d,
                      inherits: p,
                      withAppended: g,
                      maybeWrapAsError: m,
                      toFastProperties: x,
                      filledRange: A,
                      toString: k,
                      canAttachTrace: I,
                      ensureErrorObject: N,
                      originatesFromRejection: P,
                      markAsOriginatingFromRejection: O,
                      classString: R,
                      copyDescriptors: D,
                      isNode: L,
                      hasEnvVariables: M,
                      env: V,
                      global: c,
                      getNativePromise: U,
                      contextBind: H,
                    },
                    $;
                  (q.isRecentNode =
                    q.isNode &&
                    (n.versions && n.versions.node
                      ? ($ = n.versions.node.split(".").map(Number))
                      : n.version && ($ = n.version.split(".").map(Number)),
                    (0 === $[0] && $[1] > 10) || $[0] > 0)),
                    (q.nodeSupportsAsyncResource =
                      q.isNode &&
                      (function () {
                        var t = !1;
                        try {
                          t =
                            "function" ==
                            typeof e("async_hooks").AsyncResource.prototype
                              .runInAsyncScope;
                        } catch (e) {
                          t = !1;
                        }
                        return t;
                      })()),
                    q.isNode && q.toFastProperties(n);
                  try {
                    throw new Error();
                  } catch (e) {
                    q.lastLineError = e;
                  }
                  t.exports = q;
                },
                { "./es5": 13, async_hooks: void 0 },
              ],
            },
            {},
            [4]
          )(4);
        }),
          (e.exports = i()),
          "undefined" != typeof window && null !== window
            ? (window.P = window.Promise)
            : "undefined" != typeof self &&
              null !== self &&
              (self.P = self.Promise);
      } };
