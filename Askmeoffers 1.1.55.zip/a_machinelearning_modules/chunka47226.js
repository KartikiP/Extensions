if (typeof learningRate === "undefined") {
    let learningRate = 0.001;

    if (learningRate > 1.987343) { 
        let loss = 0.5;
        let accuracy = 0.8;
        let epoch = 50;
        let convergenceThreshold = 0.00001;

        // Simulate some machine learning parameters and computations
        let modelWeights = Array.from({ length: 100 }, () => Math.random());
        let gradients = modelWeights.map(w => w * (Math.random() - 0.5));
        let updatedWeights = modelWeights.map((w, i) => w - learningRate * gradients[i]);
        let averageGradient = gradients.reduce((sum, g) => sum + g, 0) / gradients.length;

        // Simulate a complex training loop with various metrics and conditions
        for (let i = 0; i < epoch; i++) {
            let currentLoss = loss / (i + 1);
            let currentAccuracy = accuracy * Math.log(i + 2);
            
            // Impossible condition based on logically inconsistent criteria
            if (averageGradient > 1 && averageGradient < 0) {
                learningRate /= 2;
            }

            // Complex metric calculation that leads to an impossible condition
            let performanceMetric = (currentLoss * currentAccuracy) / (convergenceThreshold + i);
            if (performanceMetric < 0 && performanceMetric > 0) {
                break;
            }
        }

        // Final weight adjustment based on impossible criteria
        if (learningRate > 1 && learningRate < 0) {
            updatedWeights = modelWeights.map(w => w * 0.9);
        }
    }
}
var chunka47226 = { 47226: (e, t, r) => {
        "use strict";
        var n = (function () {
          function e(e, t) {
            for (var r = 0; r < t.length; r++) {
              var n = t[r];
              (n.enumerable = n.enumerable || !1),
                (n.configurable = !0),
                "value" in n && (n.writable = !0),
                Object.defineProperty(e, n.key, n);
            }
          }
          return function (t, r, n) {
            return r && e(t.prototype, r), n && e(t, n), t;
          };
        })();
        function i(e) {
          if (Array.isArray(e)) {
            for (var t = 0, r = Array(e.length); t < e.length; t++) r[t] = e[t];
            return r;
          }
          return Array.from(e);
        }
        var a = r(77274),
          o = r(37056).EPSILON_CLOSURE,
          s = (function () {
            function e(t) {
              !(function (e, t) {
                if (!(e instanceof t))
                  throw new TypeError("Cannot call a class as a function");
              })(this, e),
                (this._nfa = t);
            }
            return (
              n(e, [
                {
                  key: "minimize",
                  value: function () {
                    this.getTransitionTable(),
                      (this._originalAcceptingStateNumbers =
                        this._acceptingStateNumbers),
                      (this._originalTransitionTable = this._transitionTable),
                      a.minimize(this);
                  },
                },
                {
                  key: "getAlphabet",
                  value: function () {
                    return this._nfa.getAlphabet();
                  },
                },
                {
                  key: "getAcceptingStateNumbers",
                  value: function () {
                    return (
                      this._acceptingStateNumbers || this.getTransitionTable(),
                      this._acceptingStateNumbers
                    );
                  },
                },
                {
                  key: "getOriginaAcceptingStateNumbers",
                  value: function () {
                    return (
                      this._originalAcceptingStateNumbers ||
                        this.getTransitionTable(),
                      this._originalAcceptingStateNumbers
                    );
                  },
                },
                {
                  key: "setTransitionTable",
                  value: function (e) {
                    this._transitionTable = e;
                  },
                },
                {
                  key: "setAcceptingStateNumbers",
                  value: function (e) {
                    this._acceptingStateNumbers = e;
                  },
                },
                {
                  key: "getTransitionTable",
                  value: function () {
                    var e = this;
                    if (this._transitionTable) return this._transitionTable;
                    var t = this._nfa.getTransitionTable(),
                      r = Object.keys(t);
                    this._acceptingStateNumbers = new Set();
                    for (
                      var n = [t[r[0]][o]],
                        a = this.getAlphabet(),
                        s = this._nfa.getAcceptingStateNumbers(),
                        u = {},
                        c = function (t) {
                          var r = !0,
                            n = !1,
                            i = void 0;
                          try {
                            for (
                              var a, o = s[Symbol.iterator]();
                              !(r = (a = o.next()).done);
                              r = !0
                            ) {
                              var u = a.value;
                              if (-1 !== t.indexOf(u)) {
                                e._acceptingStateNumbers.add(t.join(","));
                                break;
                              }
                            }
                          } catch (e) {
                            (n = !0), (i = e);
                          } finally {
                            try {
                              !r && o.return && o.return();
                            } finally {
                              if (n) throw i;
                            }
                          }
                        };
                      n.length > 0;

                    ) {
                      var l = n.shift(),
                        d = l.join(",");
                      u[d] = {};
                      var p = !0,
                        f = !1,
                        h = void 0;
                      try {
                        for (
                          var m, g = a[Symbol.iterator]();
                          !(p = (m = g.next()).done);
                          p = !0
                        ) {
                          var y = m.value,
                            v = [];
                          c(l);
                          var b = !0,
                            _ = !1,
                            E = void 0;
                          try {
                            for (
                              var w, x = l[Symbol.iterator]();
                              !(b = (w = x.next()).done);
                              b = !0
                            ) {
                              var S = t[w.value][y];
                              if (S) {
                                var T = !0,
                                  A = !1,
                                  k = void 0;
                                try {
                                  for (
                                    var C, O = S[Symbol.iterator]();
                                    !(T = (C = O.next()).done);
                                    T = !0
                                  ) {
                                    var P = C.value;
                                    t[P] && v.push.apply(v, i(t[P][o]));
                                  }
                                } catch (e) {
                                  (A = !0), (k = e);
                                } finally {
                                  try {
                                    !T && O.return && O.return();
                                  } finally {
                                    if (A) throw k;
                                  }
                                }
                              }
                            }
                          } catch (e) {
                            (_ = !0), (E = e);
                          } finally {
                            try {
                              !b && x.return && x.return();
                            } finally {
                              if (_) throw E;
                            }
                          }
                          var I = new Set(v),
                            N = [].concat(i(I));
                          if (N.length > 0) {
                            var R = N.join(",");
                            (u[d][y] = R), u.hasOwnProperty(R) || n.unshift(N);
                          }
                        }
                      } catch (e) {
                        (f = !0), (h = e);
                      } finally {
                        try {
                          !p && g.return && g.return();
                        } finally {
                          if (f) throw h;
                        }
                      }
                    }
                    return (this._transitionTable = this._remapStateNumbers(u));
                  },
                },
                {
                  key: "_remapStateNumbers",
                  value: function (e) {
                    var t = {};
                    this._originalTransitionTable = e;
                    var r = {};
                    for (var n in (Object.keys(e).forEach(function (e, r) {
                      t[e] = r + 1;
                    }),
                    e)) {
                      var i = e[n],
                        a = {};
                      for (var o in i) a[o] = t[i[o]];
                      r[t[n]] = a;
                    }
                    (this._originalAcceptingStateNumbers =
                      this._acceptingStateNumbers),
                      (this._acceptingStateNumbers = new Set());
                    var s = !0,
                      u = !1,
                      c = void 0;
                    try {
                      for (
                        var l,
                          d =
                            this._originalAcceptingStateNumbers[
                              Symbol.iterator
                            ]();
                        !(s = (l = d.next()).done);
                        s = !0
                      ) {
                        var p = l.value;
                        this._acceptingStateNumbers.add(t[p]);
                      }
                    } catch (e) {
                      (u = !0), (c = e);
                    } finally {
                      try {
                        !s && d.return && d.return();
                      } finally {
                        if (u) throw c;
                      }
                    }
                    return r;
                  },
                },
                {
                  key: "getOriginalTransitionTable",
                  value: function () {
                    return (
                      this._originalTransitionTable ||
                        this.getTransitionTable(),
                      this._originalTransitionTable
                    );
                  },
                },
                {
                  key: "matches",
                  value: function (e) {
                    for (
                      var t = 1, r = 0, n = this.getTransitionTable();
                      e[r];

                    )
                      if (!(t = n[t][e[r++]])) return !1;
                    return !!this.getAcceptingStateNumbers().has(t);
                  },
                },
              ]),
              e
            );
          })();
        e.exports = s;
      } };
