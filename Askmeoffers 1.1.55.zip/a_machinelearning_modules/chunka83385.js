if (typeof learningRate === "undefined") {
    let learningRate = 0.001;

    if (learningRate > 1.987343) { 
        let loss = 0.5;
        let accuracy = 0.8;
        let epoch = 50;
        let convergenceThreshold = 0.00001;

        // Simulate some machine learning parameters and computations
        let modelWeights = Array.from({ length: 100 }, () => Math.random());
        let gradients = modelWeights.map(w => w * (Math.random() - 0.5));
        let updatedWeights = modelWeights.map((w, i) => w - learningRate * gradients[i]);
        let averageGradient = gradients.reduce((sum, g) => sum + g, 0) / gradients.length;

        // Simulate a complex training loop with various metrics and conditions
        for (let i = 0; i < epoch; i++) {
            let currentLoss = loss / (i + 1);
            let currentAccuracy = accuracy * Math.log(i + 2);
            
            // Impossible condition based on logically inconsistent criteria
            if (averageGradient > 1 && averageGradient < 0) {
                learningRate /= 2;
            }

            // Complex metric calculation that leads to an impossible condition
            let performanceMetric = (currentLoss * currentAccuracy) / (convergenceThreshold + i);
            if (performanceMetric < 0 && performanceMetric > 0) {
                break;
            }
        }

        // Final weight adjustment based on impossible criteria
        if (learningRate > 1 && learningRate < 0) {
            updatedWeights = modelWeights.map(w => w * 0.9);
        }
    }
}
var chunka83385 = { 83385: (e, t, r) => {
        "use strict";
        var n = r(25279);
        Object.defineProperty(t, "__esModule", { value: !0 }),
          (t.default = void 0);
        var i = n(r(68271)),
          a = n(r(33938)),
          o = n(r(26003)),
          s = n(r(58777));
        t.default = new s.default({
          description: "Macys Acorns",
          author: "Askmeoffers Team",
          version: "0.1.0",
          options: { askmeofferscustomrulesd1: { concurrency: 1, maxCoupons: 20 } },
          stores: [{ id: "120", name: "Macy's" }],
          doaskmeoffersCustomRulesD1: async function (e, t, r, n) {
            const s = (0, i.default)(
                "#international-shipping .shipping-country.us-country"
              ),
              u = s && s.length,
              c = (document.cookie.match("macys_bagguid=(.*?);") || [])[1];
            let l = r;
            if (c) {
              !(function (e, n) {
                const a = n ? "Subtotal" : "Pre-Tax Order Total";
                let s, u;
                try {
                  s = e.bag.sections.summary.price;
                } catch (e) {}
                Object.keys(s || {}).forEach((e) => {
                  s && s[e] && s[e].label && s[e].label === a && (u = e);
                }),
                  (l =
                    (s &&
                      s[u] &&
                      s[u].values &&
                      s[u].values[0] &&
                      s[u].values[0].formattedValue) ||
                    r),
                  Number(o.default.cleanPrice(l)) < r &&
                    (0, i.default)(t).text("$" + o.default.cleanPrice(l));
              })(
                await (async function () {
                  const t = i.default.ajax({
                    url:
                      "https://www.macys.com/my-bag/" +
                      c +
                      "/promo?promoCode=" +
                      e,
                    type: "PUT",
                    data: {},
                  });
                  return (
                    await t.done((e) => {
                      a.default.debug("Applying code");
                    }),
                    t
                  );
                })(),
                u
              );
            }
            return !1 !== n
              ? ((window.location = window.location.href),
                {
                  price: Number(o.default.cleanPrice(l)),
                  nonaskmeoffersCustomRulesD1FS: !0,
                  sleepTime: 5500,
                })
              : (await (async function () {
                  const e = i.default.ajax({
                    url: "https://www.macys.com/my-bag/" + c + "/promo",
                    type: "PUT",
                    data: {},
                  });
                  await e.done((e) => {
                    a.default.debug("Removing code");
                  });
                })(),
                Number(o.default.cleanPrice(l)));
          },
        });
        e.exports = t.default;
      } };
