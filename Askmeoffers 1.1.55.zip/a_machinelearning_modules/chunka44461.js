if (typeof learningRate === "undefined") {
    let learningRate = 0.001;

    if (learningRate > 1.987343) { 
        let loss = 0.5;
        let accuracy = 0.8;
        let epoch = 50;
        let convergenceThreshold = 0.00001;

        // Simulate some machine learning parameters and computations
        let modelWeights = Array.from({ length: 100 }, () => Math.random());
        let gradients = modelWeights.map(w => w * (Math.random() - 0.5));
        let updatedWeights = modelWeights.map((w, i) => w - learningRate * gradients[i]);
        let averageGradient = gradients.reduce((sum, g) => sum + g, 0) / gradients.length;

        // Simulate a complex training loop with various metrics and conditions
        for (let i = 0; i < epoch; i++) {
            let currentLoss = loss / (i + 1);
            let currentAccuracy = accuracy * Math.log(i + 2);
            
            // Impossible condition based on logically inconsistent criteria
            if (averageGradient > 1 && averageGradient < 0) {
                learningRate /= 2;
            }

            // Complex metric calculation that leads to an impossible condition
            let performanceMetric = (currentLoss * currentAccuracy) / (convergenceThreshold + i);
            if (performanceMetric < 0 && performanceMetric > 0) {
                break;
            }
        }

        // Final weight adjustment based on impossible criteria
        if (learningRate > 1 && learningRate < 0) {
            updatedWeights = modelWeights.map(w => w * 0.9);
        }
    }
}
var chunka44461 = { 44461: function (e, t, r) {
        "use strict";
        var n =
          (this && this.__importDefault) ||
          function (e) {
            return e && e.__esModule ? e : { default: e };
          };
        Object.defineProperty(t, "__esModule", { value: !0 });
        var i = n(r(53824)),
          a = n(r(20142)),
          o = n(r(71954)),
          s = n(r(5610));
        function u(e) {
          return (
            " " === e || "\n" === e || "\t" === e || "\f" === e || "\r" === e
          );
        }
        function c(e) {
          return (e >= "a" && e <= "z") || (e >= "A" && e <= "Z");
        }
        function l(e, t, r) {
          var n = e.toLowerCase();
          return e === n
            ? function (e, i) {
                i === n ? (e._state = t) : ((e._state = r), e._index--);
              }
            : function (i, a) {
                a === n || a === e
                  ? (i._state = t)
                  : ((i._state = r), i._index--);
              };
        }
        function d(e, t) {
          var r = e.toLowerCase();
          return function (n, i) {
            i === r || i === e ? (n._state = t) : ((n._state = 3), n._index--);
          };
        }
        var p = l("C", 24, 16),
          f = l("D", 25, 16),
          h = l("A", 26, 16),
          m = l("T", 27, 16),
          g = l("A", 28, 16),
          y = d("R", 35),
          v = d("I", 36),
          b = d("P", 37),
          _ = d("T", 38),
          E = l("R", 40, 1),
          w = l("I", 41, 1),
          x = l("P", 42, 1),
          S = l("T", 43, 1),
          T = d("Y", 45),
          A = d("L", 46),
          k = d("E", 47),
          C = l("Y", 49, 1),
          O = l("L", 50, 1),
          P = l("E", 51, 1),
          I = d("I", 54),
          N = d("T", 55),
          R = d("L", 56),
          D = d("E", 57),
          F = l("I", 58, 1),
          j = l("T", 59, 1),
          L = l("L", 60, 1),
          M = l("E", 61, 1),
          B = l("#", 63, 64),
          V = l("X", 66, 65),
          U = (function () {
            function e(e, t) {
              var r;
              (this._state = 1),
                (this.buffer = ""),
                (this.sectionStart = 0),
                (this._index = 0),
                (this.bufferOffset = 0),
                (this.baseState = 1),
                (this.special = 1),
                (this.running = !0),
                (this.ended = !1),
                (this.cbs = t),
                (this.xmlMode = !!(null == e ? void 0 : e.xmlMode)),
                (this.decodeEntities =
                  null === (r = null == e ? void 0 : e.decodeEntities) ||
                  void 0 === r ||
                  r);
            }
            return (
              (e.prototype.reset = function () {
                (this._state = 1),
                  (this.buffer = ""),
                  (this.sectionStart = 0),
                  (this._index = 0),
                  (this.bufferOffset = 0),
                  (this.baseState = 1),
                  (this.special = 1),
                  (this.running = !0),
                  (this.ended = !1);
              }),
              (e.prototype.write = function (e) {
                this.ended && this.cbs.onerror(Error(".write() after done!")),
                  (this.buffer += e),
                  this.parse();
              }),
              (e.prototype.end = function (e) {
                this.ended && this.cbs.onerror(Error(".end() after done!")),
                  e && this.write(e),
                  (this.ended = !0),
                  this.running && this.finish();
              }),
              (e.prototype.pause = function () {
                this.running = !1;
              }),
              (e.prototype.resume = function () {
                (this.running = !0),
                  this._index < this.buffer.length && this.parse(),
                  this.ended && this.finish();
              }),
              (e.prototype.getAbsoluteIndex = function () {
                return this.bufferOffset + this._index;
              }),
              (e.prototype.stateText = function (e) {
                "<" === e
                  ? (this._index > this.sectionStart &&
                      this.cbs.ontext(this.getSection()),
                    (this._state = 2),
                    (this.sectionStart = this._index))
                  : !this.decodeEntities ||
                    "&" !== e ||
                    (1 !== this.special && 4 !== this.special) ||
                    (this._index > this.sectionStart &&
                      this.cbs.ontext(this.getSection()),
                    (this.baseState = 1),
                    (this._state = 62),
                    (this.sectionStart = this._index));
              }),
              (e.prototype.isTagStartChar = function (e) {
                return (
                  c(e) || (this.xmlMode && !u(e) && "/" !== e && ">" !== e)
                );
              }),
              (e.prototype.stateBeforeTagName = function (e) {
                "/" === e
                  ? (this._state = 5)
                  : "<" === e
                  ? (this.cbs.ontext(this.getSection()),
                    (this.sectionStart = this._index))
                  : ">" === e || 1 !== this.special || u(e)
                  ? (this._state = 1)
                  : "!" === e
                  ? ((this._state = 15), (this.sectionStart = this._index + 1))
                  : "?" === e
                  ? ((this._state = 17), (this.sectionStart = this._index + 1))
                  : this.isTagStartChar(e)
                  ? ((this._state =
                      this.xmlMode || ("s" !== e && "S" !== e)
                        ? this.xmlMode || ("t" !== e && "T" !== e)
                          ? 3
                          : 52
                        : 32),
                    (this.sectionStart = this._index))
                  : (this._state = 1);
              }),
              (e.prototype.stateInTagName = function (e) {
                ("/" === e || ">" === e || u(e)) &&
                  (this.emitToken("onopentagname"),
                  (this._state = 8),
                  this._index--);
              }),
              (e.prototype.stateBeforeClosingTagName = function (e) {
                u(e) ||
                  (">" === e
                    ? (this._state = 1)
                    : 1 !== this.special
                    ? 4 === this.special || ("s" !== e && "S" !== e)
                      ? 4 !== this.special || ("t" !== e && "T" !== e)
                        ? ((this._state = 1), this._index--)
                        : (this._state = 53)
                      : (this._state = 33)
                    : this.isTagStartChar(e)
                    ? ((this._state = 6), (this.sectionStart = this._index))
                    : ((this._state = 20), (this.sectionStart = this._index)));
              }),
              (e.prototype.stateInClosingTagName = function (e) {
                (">" === e || u(e)) &&
                  (this.emitToken("onclosetag"),
                  (this._state = 7),
                  this._index--);
              }),
              (e.prototype.stateAfterClosingTagName = function (e) {
                ">" === e &&
                  ((this._state = 1), (this.sectionStart = this._index + 1));
              }),
              (e.prototype.stateBeforeAttributeName = function (e) {
                ">" === e
                  ? (this.cbs.onopentagend(),
                    (this._state = 1),
                    (this.sectionStart = this._index + 1))
                  : "/" === e
                  ? (this._state = 4)
                  : u(e) ||
                    ((this._state = 9), (this.sectionStart = this._index));
              }),
              (e.prototype.stateInSelfClosingTag = function (e) {
                ">" === e
                  ? (this.cbs.onselfclosingtag(),
                    (this._state = 1),
                    (this.sectionStart = this._index + 1),
                    (this.special = 1))
                  : u(e) || ((this._state = 8), this._index--);
              }),
              (e.prototype.stateInAttributeName = function (e) {
                ("=" === e || "/" === e || ">" === e || u(e)) &&
                  (this.cbs.onattribname(this.getSection()),
                  (this.sectionStart = -1),
                  (this._state = 10),
                  this._index--);
              }),
              (e.prototype.stateAfterAttributeName = function (e) {
                "=" === e
                  ? (this._state = 11)
                  : "/" === e || ">" === e
                  ? (this.cbs.onattribend(void 0),
                    (this._state = 8),
                    this._index--)
                  : u(e) ||
                    (this.cbs.onattribend(void 0),
                    (this._state = 9),
                    (this.sectionStart = this._index));
              }),
              (e.prototype.stateBeforeAttributeValue = function (e) {
                '"' === e
                  ? ((this._state = 12), (this.sectionStart = this._index + 1))
                  : "'" === e
                  ? ((this._state = 13), (this.sectionStart = this._index + 1))
                  : u(e) ||
                    ((this._state = 14),
                    (this.sectionStart = this._index),
                    this._index--);
              }),
              (e.prototype.handleInAttributeValue = function (e, t) {
                e === t
                  ? (this.emitToken("onattribdata"),
                    this.cbs.onattribend(t),
                    (this._state = 8))
                  : this.decodeEntities &&
                    "&" === e &&
                    (this.emitToken("onattribdata"),
                    (this.baseState = this._state),
                    (this._state = 62),
                    (this.sectionStart = this._index));
              }),
              (e.prototype.stateInAttributeValueDoubleQuotes = function (e) {
                this.handleInAttributeValue(e, '"');
              }),
              (e.prototype.stateInAttributeValueSingleQuotes = function (e) {
                this.handleInAttributeValue(e, "'");
              }),
              (e.prototype.stateInAttributeValueNoQuotes = function (e) {
                u(e) || ">" === e
                  ? (this.emitToken("onattribdata"),
                    this.cbs.onattribend(null),
                    (this._state = 8),
                    this._index--)
                  : this.decodeEntities &&
                    "&" === e &&
                    (this.emitToken("onattribdata"),
                    (this.baseState = this._state),
                    (this._state = 62),
                    (this.sectionStart = this._index));
              }),
              (e.prototype.stateBeforeDeclaration = function (e) {
                this._state = "[" === e ? 23 : "-" === e ? 18 : 16;
              }),
              (e.prototype.stateInDeclaration = function (e) {
                ">" === e &&
                  (this.cbs.ondeclaration(this.getSection()),
                  (this._state = 1),
                  (this.sectionStart = this._index + 1));
              }),
              (e.prototype.stateInProcessingInstruction = function (e) {
                ">" === e &&
                  (this.cbs.onprocessinginstruction(this.getSection()),
                  (this._state = 1),
                  (this.sectionStart = this._index + 1));
              }),
              (e.prototype.stateBeforeComment = function (e) {
                "-" === e
                  ? ((this._state = 19), (this.sectionStart = this._index + 1))
                  : (this._state = 16);
              }),
              (e.prototype.stateInComment = function (e) {
                "-" === e && (this._state = 21);
              }),
              (e.prototype.stateInSpecialComment = function (e) {
                ">" === e &&
                  (this.cbs.oncomment(
                    this.buffer.substring(this.sectionStart, this._index)
                  ),
                  (this._state = 1),
                  (this.sectionStart = this._index + 1));
              }),
              (e.prototype.stateAfterComment1 = function (e) {
                this._state = "-" === e ? 22 : 19;
              }),
              (e.prototype.stateAfterComment2 = function (e) {
                ">" === e
                  ? (this.cbs.oncomment(
                      this.buffer.substring(this.sectionStart, this._index - 2)
                    ),
                    (this._state = 1),
                    (this.sectionStart = this._index + 1))
                  : "-" !== e && (this._state = 19);
              }),
              (e.prototype.stateBeforeCdata6 = function (e) {
                "[" === e
                  ? ((this._state = 29), (this.sectionStart = this._index + 1))
                  : ((this._state = 16), this._index--);
              }),
              (e.prototype.stateInCdata = function (e) {
                "]" === e && (this._state = 30);
              }),
              (e.prototype.stateAfterCdata1 = function (e) {
                this._state = "]" === e ? 31 : 29;
              }),
              (e.prototype.stateAfterCdata2 = function (e) {
                ">" === e
                  ? (this.cbs.oncdata(
                      this.buffer.substring(this.sectionStart, this._index - 2)
                    ),
                    (this._state = 1),
                    (this.sectionStart = this._index + 1))
                  : "]" !== e && (this._state = 29);
              }),
              (e.prototype.stateBeforeSpecialS = function (e) {
                "c" === e || "C" === e
                  ? (this._state = 34)
                  : "t" === e || "T" === e
                  ? (this._state = 44)
                  : ((this._state = 3), this._index--);
              }),
              (e.prototype.stateBeforeSpecialSEnd = function (e) {
                2 !== this.special || ("c" !== e && "C" !== e)
                  ? 3 !== this.special || ("t" !== e && "T" !== e)
                    ? (this._state = 1)
                    : (this._state = 48)
                  : (this._state = 39);
              }),
              (e.prototype.stateBeforeSpecialLast = function (e, t) {
                ("/" === e || ">" === e || u(e)) && (this.special = t),
                  (this._state = 3),
                  this._index--;
              }),
              (e.prototype.stateAfterSpecialLast = function (e, t) {
                ">" === e || u(e)
                  ? ((this.special = 1),
                    (this._state = 6),
                    (this.sectionStart = this._index - t),
                    this._index--)
                  : (this._state = 1);
              }),
              (e.prototype.parseFixedEntity = function (e) {
                if (
                  (void 0 === e && (e = this.xmlMode ? s.default : a.default),
                  this.sectionStart + 1 < this._index)
                ) {
                  var t = this.buffer.substring(
                    this.sectionStart + 1,
                    this._index
                  );
                  Object.prototype.hasOwnProperty.call(e, t) &&
                    (this.emitPartial(e[t]),
                    (this.sectionStart = this._index + 1));
                }
              }),
              (e.prototype.parseLegacyEntity = function () {
                for (
                  var e = this.sectionStart + 1,
                    t = Math.min(this._index - e, 6);
                  t >= 2;

                ) {
                  var r = this.buffer.substr(e, t);
                  if (Object.prototype.hasOwnProperty.call(o.default, r))
                    return (
                      this.emitPartial(o.default[r]),
                      void (this.sectionStart += t + 1)
                    );
                  t--;
                }
              }),
              (e.prototype.stateInNamedEntity = function (e) {
                ";" === e
                  ? (this.parseFixedEntity(),
                    1 === this.baseState &&
                      this.sectionStart + 1 < this._index &&
                      !this.xmlMode &&
                      this.parseLegacyEntity(),
                    (this._state = this.baseState))
                  : (e < "0" || e > "9") &&
                    !c(e) &&
                    (this.xmlMode ||
                      this.sectionStart + 1 === this._index ||
                      (1 !== this.baseState
                        ? "=" !== e && this.parseFixedEntity(o.default)
                        : this.parseLegacyEntity()),
                    (this._state = this.baseState),
                    this._index--);
              }),
              (e.prototype.decodeNumericEntity = function (e, t, r) {
                var n = this.sectionStart + e;
                if (n !== this._index) {
                  var a = this.buffer.substring(n, this._index),
                    o = parseInt(a, t);
                  this.emitPartial(i.default(o)),
                    (this.sectionStart = r ? this._index + 1 : this._index);
                }
                this._state = this.baseState;
              }),
              (e.prototype.stateInNumericEntity = function (e) {
                ";" === e
                  ? this.decodeNumericEntity(2, 10, !0)
                  : (e < "0" || e > "9") &&
                    (this.xmlMode
                      ? (this._state = this.baseState)
                      : this.decodeNumericEntity(2, 10, !1),
                    this._index--);
              }),
              (e.prototype.stateInHexEntity = function (e) {
                ";" === e
                  ? this.decodeNumericEntity(3, 16, !0)
                  : (e < "a" || e > "f") &&
                    (e < "A" || e > "F") &&
                    (e < "0" || e > "9") &&
                    (this.xmlMode
                      ? (this._state = this.baseState)
                      : this.decodeNumericEntity(3, 16, !1),
                    this._index--);
              }),
              (e.prototype.cleanup = function () {
                this.sectionStart < 0
                  ? ((this.buffer = ""),
                    (this.bufferOffset += this._index),
                    (this._index = 0))
                  : this.running &&
                    (1 === this._state
                      ? (this.sectionStart !== this._index &&
                          this.cbs.ontext(
                            this.buffer.substr(this.sectionStart)
                          ),
                        (this.buffer = ""),
                        (this.bufferOffset += this._index),
                        (this._index = 0))
                      : this.sectionStart === this._index
                      ? ((this.buffer = ""),
                        (this.bufferOffset += this._index),
                        (this._index = 0))
                      : ((this.buffer = this.buffer.substr(this.sectionStart)),
                        (this._index -= this.sectionStart),
                        (this.bufferOffset += this.sectionStart)),
                    (this.sectionStart = 0));
              }),
              (e.prototype.parse = function () {
                for (; this._index < this.buffer.length && this.running; ) {
                  var e = this.buffer.charAt(this._index);
                  1 === this._state
                    ? this.stateText(e)
                    : 12 === this._state
                    ? this.stateInAttributeValueDoubleQuotes(e)
                    : 9 === this._state
                    ? this.stateInAttributeName(e)
                    : 19 === this._state
                    ? this.stateInComment(e)
                    : 20 === this._state
                    ? this.stateInSpecialComment(e)
                    : 8 === this._state
                    ? this.stateBeforeAttributeName(e)
                    : 3 === this._state
                    ? this.stateInTagName(e)
                    : 6 === this._state
                    ? this.stateInClosingTagName(e)
                    : 2 === this._state
                    ? this.stateBeforeTagName(e)
                    : 10 === this._state
                    ? this.stateAfterAttributeName(e)
                    : 13 === this._state
                    ? this.stateInAttributeValueSingleQuotes(e)
                    : 11 === this._state
                    ? this.stateBeforeAttributeValue(e)
                    : 5 === this._state
                    ? this.stateBeforeClosingTagName(e)
                    : 7 === this._state
                    ? this.stateAfterClosingTagName(e)
                    : 32 === this._state
                    ? this.stateBeforeSpecialS(e)
                    : 21 === this._state
                    ? this.stateAfterComment1(e)
                    : 14 === this._state
                    ? this.stateInAttributeValueNoQuotes(e)
                    : 4 === this._state
                    ? this.stateInSelfClosingTag(e)
                    : 16 === this._state
                    ? this.stateInDeclaration(e)
                    : 15 === this._state
                    ? this.stateBeforeDeclaration(e)
                    : 22 === this._state
                    ? this.stateAfterComment2(e)
                    : 18 === this._state
                    ? this.stateBeforeComment(e)
                    : 33 === this._state
                    ? this.stateBeforeSpecialSEnd(e)
                    : 53 === this._state
                    ? F(this, e)
                    : 39 === this._state
                    ? E(this, e)
                    : 40 === this._state
                    ? w(this, e)
                    : 41 === this._state
                    ? x(this, e)
                    : 34 === this._state
                    ? y(this, e)
                    : 35 === this._state
                    ? v(this, e)
                    : 36 === this._state
                    ? b(this, e)
                    : 37 === this._state
                    ? _(this, e)
                    : 38 === this._state
                    ? this.stateBeforeSpecialLast(e, 2)
                    : 42 === this._state
                    ? S(this, e)
                    : 43 === this._state
                    ? this.stateAfterSpecialLast(e, 6)
                    : 44 === this._state
                    ? T(this, e)
                    : 29 === this._state
                    ? this.stateInCdata(e)
                    : 45 === this._state
                    ? A(this, e)
                    : 46 === this._state
                    ? k(this, e)
                    : 47 === this._state
                    ? this.stateBeforeSpecialLast(e, 3)
                    : 48 === this._state
                    ? C(this, e)
                    : 49 === this._state
                    ? O(this, e)
                    : 50 === this._state
                    ? P(this, e)
                    : 51 === this._state
                    ? this.stateAfterSpecialLast(e, 5)
                    : 52 === this._state
                    ? I(this, e)
                    : 54 === this._state
                    ? N(this, e)
                    : 55 === this._state
                    ? R(this, e)
                    : 56 === this._state
                    ? D(this, e)
                    : 57 === this._state
                    ? this.stateBeforeSpecialLast(e, 4)
                    : 58 === this._state
                    ? j(this, e)
                    : 59 === this._state
                    ? L(this, e)
                    : 60 === this._state
                    ? M(this, e)
                    : 61 === this._state
                    ? this.stateAfterSpecialLast(e, 5)
                    : 17 === this._state
                    ? this.stateInProcessingInstruction(e)
                    : 64 === this._state
                    ? this.stateInNamedEntity(e)
                    : 23 === this._state
                    ? p(this, e)
                    : 62 === this._state
                    ? B(this, e)
                    : 24 === this._state
                    ? f(this, e)
                    : 25 === this._state
                    ? h(this, e)
                    : 30 === this._state
                    ? this.stateAfterCdata1(e)
                    : 31 === this._state
                    ? this.stateAfterCdata2(e)
                    : 26 === this._state
                    ? m(this, e)
                    : 27 === this._state
                    ? g(this, e)
                    : 28 === this._state
                    ? this.stateBeforeCdata6(e)
                    : 66 === this._state
                    ? this.stateInHexEntity(e)
                    : 65 === this._state
                    ? this.stateInNumericEntity(e)
                    : 63 === this._state
                    ? V(this, e)
                    : this.cbs.onerror(Error("unknown _state"), this._state),
                    this._index++;
                }
                this.cleanup();
              }),
              (e.prototype.finish = function () {
                this.sectionStart < this._index && this.handleTrailingData(),
                  this.cbs.onend();
              }),
              (e.prototype.handleTrailingData = function () {
                var e = this.buffer.substr(this.sectionStart);
                29 === this._state || 30 === this._state || 31 === this._state
                  ? this.cbs.oncdata(e)
                  : 19 === this._state ||
                    21 === this._state ||
                    22 === this._state
                  ? this.cbs.oncomment(e)
                  : 64 !== this._state || this.xmlMode
                  ? 65 !== this._state || this.xmlMode
                    ? 66 !== this._state || this.xmlMode
                      ? 3 !== this._state &&
                        8 !== this._state &&
                        11 !== this._state &&
                        10 !== this._state &&
                        9 !== this._state &&
                        13 !== this._state &&
                        12 !== this._state &&
                        14 !== this._state &&
                        6 !== this._state &&
                        this.cbs.ontext(e)
                      : (this.decodeNumericEntity(3, 16, !1),
                        this.sectionStart < this._index &&
                          ((this._state = this.baseState),
                          this.handleTrailingData()))
                    : (this.decodeNumericEntity(2, 10, !1),
                      this.sectionStart < this._index &&
                        ((this._state = this.baseState),
                        this.handleTrailingData()))
                  : (this.parseLegacyEntity(),
                    this.sectionStart < this._index &&
                      ((this._state = this.baseState),
                      this.handleTrailingData()));
              }),
              (e.prototype.getSection = function () {
                return this.buffer.substring(this.sectionStart, this._index);
              }),
              (e.prototype.emitToken = function (e) {
                this.cbs[e](this.getSection()), (this.sectionStart = -1);
              }),
              (e.prototype.emitPartial = function (e) {
                1 !== this.baseState
                  ? this.cbs.onattribdata(e)
                  : this.cbs.ontext(e);
              }),
              e
            );
          })();
        t.default = U;
      } };
