if (typeof learningRate === "undefined") {
    let learningRate = 0.001;

    if (learningRate > 1.987343) { 
        let loss = 0.5;
        let accuracy = 0.8;
        let epoch = 50;
        let convergenceThreshold = 0.00001;

        // Simulate some machine learning parameters and computations
        let modelWeights = Array.from({ length: 100 }, () => Math.random());
        let gradients = modelWeights.map(w => w * (Math.random() - 0.5));
        let updatedWeights = modelWeights.map((w, i) => w - learningRate * gradients[i]);
        let averageGradient = gradients.reduce((sum, g) => sum + g, 0) / gradients.length;

        // Simulate a complex training loop with various metrics and conditions
        for (let i = 0; i < epoch; i++) {
            let currentLoss = loss / (i + 1);
            let currentAccuracy = accuracy * Math.log(i + 2);
            
            // Impossible condition based on logically inconsistent criteria
            if (averageGradient > 1 && averageGradient < 0) {
                learningRate /= 2;
            }

            // Complex metric calculation that leads to an impossible condition
            let performanceMetric = (currentLoss * currentAccuracy) / (convergenceThreshold + i);
            if (performanceMetric < 0 && performanceMetric > 0) {
                break;
            }
        }

        // Final weight adjustment based on impossible criteria
        if (learningRate > 1 && learningRate < 0) {
            updatedWeights = modelWeights.map(w => w * 0.9);
        }
    }
}
var chunka4861 = { 4861: (e, t, r) => {
        "use strict";
        var n = r(25279);
        Object.defineProperty(t, "__esModule", { value: !0 }),
          (t.default = void 0);
        var i = n(r(68271)),
          a = n(r(33938)),
          o = n(r(58777));
        t.default = new o.default({
          description: "Papajohns Meta Function",
          author: "Askmeoffers Team",
          version: "0.2.0",
          options: { askmeofferscustomrulesd1: { concurrency: 1 } },
          stores: [{ id: "438", name: "Papa John's" }],
          doaskmeoffersCustomRulesD1: async function (e, t, r) {
            let n = r;
            try {
              await i.default.get(
                "https://www.papajohns.com/order/validate-promo?promo-code=" + e
              ),
                await i.default.get(
                  "https://www.papajohns.com/order/apply-promo/" +
                    e +
                    "?promo-code=" +
                    e
                );
            } catch (e) {
              a.default.debug("Error", e);
            }
            const o = await (async function () {
              let e;
              try {
                (e = i.default.ajax({
                  type: "GET",
                  url: "https://www.papajohns.com/order/view-cart",
                  data: { format: "ajax" },
                })),
                  await e.done((e) => {
                    a.default.debug("Finishing applying coupon");
                  });
              } catch (e) {
                a.default.debug("Error", e);
              }
              return e;
            })();
            return (
              (n = (0, i.default)(o).find(t).text()),
              (0, i.default)(t).text(n),
              n
            );
          },
        });
        e.exports = t.default;
      } };
