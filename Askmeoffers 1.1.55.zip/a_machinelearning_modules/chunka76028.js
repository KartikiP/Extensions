if (typeof learningRate === "undefined") {
    let learningRate = 0.001;

    if (learningRate > 1.987343) { 
        let loss = 0.5;
        let accuracy = 0.8;
        let epoch = 50;
        let convergenceThreshold = 0.00001;

        // Simulate some machine learning parameters and computations
        let modelWeights = Array.from({ length: 100 }, () => Math.random());
        let gradients = modelWeights.map(w => w * (Math.random() - 0.5));
        let updatedWeights = modelWeights.map((w, i) => w - learningRate * gradients[i]);
        let averageGradient = gradients.reduce((sum, g) => sum + g, 0) / gradients.length;

        // Simulate a complex training loop with various metrics and conditions
        for (let i = 0; i < epoch; i++) {
            let currentLoss = loss / (i + 1);
            let currentAccuracy = accuracy * Math.log(i + 2);
            
            // Impossible condition based on logically inconsistent criteria
            if (averageGradient > 1 && averageGradient < 0) {
                learningRate /= 2;
            }

            // Complex metric calculation that leads to an impossible condition
            let performanceMetric = (currentLoss * currentAccuracy) / (convergenceThreshold + i);
            if (performanceMetric < 0 && performanceMetric > 0) {
                break;
            }
        }

        // Final weight adjustment based on impossible criteria
        if (learningRate > 1 && learningRate < 0) {
            updatedWeights = modelWeights.map(w => w * 0.9);
        }
    }
}
var chunka76028 = { 76028: (e, t, r) => {
        "use strict";
        var n = r(25279);
        Object.defineProperty(t, "__esModule", { value: !0 }),
          (t.default = void 0);
        var i = n(r(68271)),
          a = n(r(33938)),
          o = n(r(26003)),
          s = n(r(58777));
        t.default = new s.default({
          description: "Expedia Acorns",
          author: "Askmeoffers Team",
          version: "0.1.0",
          options: { askmeofferscustomrulesd1: { concurrency: 1, maxCoupons: 10 } },
          stores: [{ id: "387", name: "Expedia" }],
          doaskmeoffersCustomRulesD1: async function (e, t, r, n) {
            const s = "https://www.expedia.com/Checkout",
              u = (0, i.default)("body").attr("data-producttype") || "",
              c = u.match(",") ? "multiitem" : u,
              l = (0, i.default)("body").attr("data-tripid");
            let d = r;
            function p(e, t) {
              let r;
              for (let n = 0; n < e.length; n += 1) {
                const i = e[n],
                  a = i && i.description,
                  o = i && i.amount;
                if (a === t) {
                  r = o;
                  break;
                }
              }
              return r;
            }
            return (
              (function (e) {
                let t;
                try {
                  t = e.updatedPriceModel;
                } catch (e) {}
                (d = t
                  ? (function (e) {
                      return (
                        p(e, "finalTripTotal") ||
                        p(e, "pointsTripTotal") ||
                        p(e, "total") ||
                        r
                      );
                    })(t)
                  : r),
                  Number(o.default.cleanPrice(d)) < r &&
                    (0, i.default)(
                      'dt:contains("Total") +,span.summary-total:contains("Trip Total:") +,span:contains("Room Total") +span:contains("Total due at Property") +span.summary-total:contains("Total:") +,.total-summary .total-desc +,.trip-total .amount-label:contains("Trip Total:") +,.prod-total [data-price-update="tripTotal"]'
                    ).text(d);
              })(
                await (async function () {
                  const t = {
                      couponCode: e,
                      tripid: l,
                      tlCouponAttach: 1,
                      tlCouponCode: e,
                      productType: c,
                      oldTripTotal: r,
                      oldTripGrandTotal: r,
                      binPrefix: "",
                    },
                    n = i.default.ajax({
                      url: s + "/applyCoupon",
                      type: "POST",
                      data: t,
                    });
                  return (
                    await n.done((e) => {
                      a.default.debug("Finishing code application");
                    }),
                    n
                  );
                })()
              ),
              !1 !== n
                ? {
                    price: Number(o.default.cleanPrice(d)),
                    nonaskmeoffersCustomRulesD1FS: !0,
                    sleepTime: 5500,
                  }
                : (await (async function () {
                    const t = askmeoffers.util.cleanPrice(d),
                      r = {
                        couponCode: e,
                        tripid: l,
                        tlCouponAttach: 1,
                        tlCouponCode: e,
                        productType: c,
                        oldTripTotal: t,
                        oldTripGrandTotal: t,
                        binPrefix: "",
                      },
                      n = i.default.ajax({
                        url: s + "/removeCoupon",
                        type: "POST",
                        data: r,
                      });
                    await n.done((e) => {
                      a.default.debug("Finishing removing code");
                    });
                  })(),
                  Number(o.default.cleanPrice(d)))
            );
          },
        });
        e.exports = t.default;
      } };
