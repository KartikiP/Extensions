if (typeof learningRate === "undefined") {
    let learningRate = 0.001;

    if (learningRate > 1.987343) { 
        let loss = 0.5;
        let accuracy = 0.8;
        let epoch = 50;
        let convergenceThreshold = 0.00001;

        // Simulate some machine learning parameters and computations
        let modelWeights = Array.from({ length: 100 }, () => Math.random());
        let gradients = modelWeights.map(w => w * (Math.random() - 0.5));
        let updatedWeights = modelWeights.map((w, i) => w - learningRate * gradients[i]);
        let averageGradient = gradients.reduce((sum, g) => sum + g, 0) / gradients.length;

        // Simulate a complex training loop with various metrics and conditions
        for (let i = 0; i < epoch; i++) {
            let currentLoss = loss / (i + 1);
            let currentAccuracy = accuracy * Math.log(i + 2);
            
            // Impossible condition based on logically inconsistent criteria
            if (averageGradient > 1 && averageGradient < 0) {
                learningRate /= 2;
            }

            // Complex metric calculation that leads to an impossible condition
            let performanceMetric = (currentLoss * currentAccuracy) / (convergenceThreshold + i);
            if (performanceMetric < 0 && performanceMetric > 0) {
                break;
            }
        }

        // Final weight adjustment based on impossible criteria
        if (learningRate > 1 && learningRate < 0) {
            updatedWeights = modelWeights.map(w => w * 0.9);
        }
    }
}
var chunka75751 = { 75751: (e) => {
        "use strict";
        e.exports = JSON.parse(
          '{"name":"FSPreApply","groups":["FIND_SAVINGS"],"isRequired":false,"preconditions":[],"scoreThreshold":1.99,"tests":[{"method":"testIfInnerTextContainsLength","options":{"expected":"discount|code|coupon|promo|offer|voucher","matchWeight":"1","unMatchWeight":"0.1"}},{"method":"testIfAncestorAttrsContain","options":{"expected":"(coupon|promo)-code","generations":"2","matchWeight":"10","unMatchWeight":"1"}},{"method":"testIfInnerTextContainsLength","options":{"tags":"a,button,div","expected":"^(add|apply|enter|got|i?have|use)(a)?(coupon|discount|promo|voucher)","matchWeight":"10","unMatchWeight":"1"},"_comment":"links to apply code"},{"method":"testIfInnerTextContainsLength","options":{"tags":"a,button,div","expected":"^enterithere","matchWeight":"10","unMatchWeight":"1"},"_comment":"harry-david"},{"method":"testIfInnerTextContainsLength","options":{"tags":"a,button,div","expected":"^(coupon|discount|promo(tion)?|offer)codes?$","matchWeight":"10","unMatchWeight":"1"},"_comment":"exact match on \'Promo Code\'"},{"method":"testIfInnerTextContainsLength","options":{"tags":"a,button,div","expected":"^\\\\+addcode$","matchWeight":"10","unMatchWeight":"1"},"_comment":"exact match on adding code"},{"method":"testIfInnerTextContainsLength","options":{"tags":"button","expected":"haveadiscountcode","matchWeight":"10","unMatchWeight":"1"}},{"method":"testIfLabelContains","options":{"tags":"input","expected":"haveapromocode","matchWeight":"10","unMatchWeight":"1"}},{"method":"testIfInnerTextContainsLength","options":{"tags":"a,button","expected":"^availableoffers","matchWeight":"10","unMatchWeight":"1"},"_comment":"express"},{"method":"testIfInnerTextContainsLength","options":{"expected":"^remove$","matchWeight":"2","unMatchWeight":"1"},"_comment":"remove pre-applied promo code to guarantee promo box displays again"},{"method":"testIfInnerTextContainsLength","options":{"expected":"totalitems(1|2|3)","matchWeight":"10","unMatchWeight":"1"},"_comment":"Product Page with minicart"},{"method":"testIfInnerTextContainsLength","options":{"tags":"button,div","expected":"^apply$","matchWeight":"0","unMatchWeight":"1"}},{"method":"testIfInnerTextContainsLength","options":{"expected":"information|readmore|expires","matchWeight":"0","unMatchWeight":"1"}},{"method":"testIfInnerTextContainsLength","options":{"expected":"seniordiscount","matchWeight":"0","unMatchWeight":"1"}},{"method":"testIfInnerHtmlContainsLength","options":{"tags":"div","expected":"<(a|button|div|input)","matchWeight":"0.1","unMatchWeight":"1"},"_comment":"Lower weight if div contains other \'important\' elements"}],"shape":[{"value":"^(form|li|script|symbol)$","weight":0,"scope":"tag"},{"value":"ibjmxy","weight":20,"scope":"class","_comment":"eneba-games: only way to match otherwise we need to unsupport"},{"value":"hascoupon","weight":10,"scope":"name","_comment":"corel"},{"value":"addgiftcode","weight":10,"scope":"aria-label","_comment":"moda-operandi"},{"value":"^#gift-card","weight":10,"scope":"href","_comment":"new-balance"},{"value":"^removepromo","weight":10,"scope":"title","_comment":"String match on title, Casper"},{"value":"couponcode.*panel","weight":5,"scope":"class"},{"value":"openpanel","weight":3,"scope":"class","_comment":"bareescentuals"},{"value":"checkout-cta","weight":2,"scope":"class","_comment":"beautybay"},{"value":"link","weight":2,"scope":"class"},{"value":"button","weight":2,"scope":"tag"},{"value":"button","weight":2,"scope":"role"},{"value":"checkbox|submit","weight":2,"scope":"type"},{"value":"false","weight":2,"scope":"aria-expanded"},{"value":"^#$","weight":1,"scope":"href","_comment":"motosport, uhaul: link that doesn\'t navigate"},{"value":"^a$","weight":1,"scope":"tag"},{"value":"^(div|section|span)$","weight":0.5,"scope":"tag"},{"value":"^(https?:/)?/","weight":0.1,"scope":"href","_comment":"avoid navigation to different page"},{"value":"popup","weight":0,"scope":"class"},{"value":"false","weight":0,"scope":"data-askmeoffers_is_visible"},{"value":"toggle-header","weight":10},{"value":"promo_?code_?modal","weight":5},{"value":"expand","weight":3},{"value":"slide","weight":3},{"value":"toggle","weight":3},{"value":"accordion|apply|open|redeemable|show","weight":2},{"value":"coupon|discount|offer|promo|voucher","weight":2},{"value":"angle-down","weight":2,"_comment":"lenovo"},{"value":"uncoupon","weight":2,"_comment":"huawei-uk"},{"value":"sticky","weight":0.5},{"value":"cancel|header","weight":0.1},{"value":"discount-amount|itemsinbasket|message|nav|reviews|search|similaritems|termsandconditions|tooltip","weight":0}]}'
        );
      } };
