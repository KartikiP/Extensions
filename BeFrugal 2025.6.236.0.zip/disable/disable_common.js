var isChrome = true;

/**
 * Automatically decodes the URI component for the specified query parameters in the URI, then returns the data.
 * @param {string} key - The key name of the query parameter.
 * @returns {any}
 */
var disableParams = (function (input) {
	if (input == "")
		return {};
	var output = {};
	for (var i = 0; i < input.length; ++i) {
		var params = input[i].split('=', 2);
		if (params.length == 1)
			output[params[0]] = "";
		else
			output[params[0]] = decodeURIComponent(params[1].replace(/\+/g, " "));
	}
	return output;
})(window.location.search.substr(1).split('&'));

var hasLocalParent = disableParams["localparent"] && disableParams["localparent"] == "1";

function _sendDisablingMessage(action, data, callback) {
	let alldata = !data ? "" : data;
	if (!callback)
		callback = function (any) { };

	if (isChrome) {
		let lastErrorHandler = function (responseData) {
			if (chrome.runtime.lastError) {
				console.debug(options, chrome.runtime.lastError.message);
			}
			if (responseData) {
				callback(responseData);
			}
			else {
				callback();
			}
		};
		if (!hasLocalParent) {
			chrome.runtime.sendMessage({
				targetScript: "disableBackgroundApp.js",
				action: action,
				data: alldata
			}, lastErrorHandler);
		}
		else {
			parent._BlankSendMessage("disableBackgroundApp.js", action, alldata, lastErrorHandler);
		};
	}
	else {
		if (!hasLocalParent) {
			browser.runtime.sendMessage({
				targetScript: "disableBackgroundApp.js",
				action: action,
				data: alldata,
				callback: callback
			}).then(callback);
		}
		else {
			parent._BlankSendMessage("disableBackgroundApp.js", action, alldata, callback);
		};
	}
}

function closeButtonListener(event) {
	//NOTE(Thompson): This is how we invoke calls from the parent document when inside an iframe.
	if (hasLocalParent)
		parent.closeTab();
	else {
		_sendDisablingMessage("CloseDialog");
	}
}

var closeButton = document.getElementById('bfrl_closeButton');
closeButton.addEventListener("click", closeButtonListener);

var browseStoresButton = document.querySelector("#bfrl_browseStoresButton");
if (browseStoresButton) {
	browseStoresButton.addEventListener("click", (event) => {
		_sendDisablingMessage("OpenBonusCashbackStoresTab");
	});
}