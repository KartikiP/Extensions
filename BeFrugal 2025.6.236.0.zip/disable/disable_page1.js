var disableButton = document.getElementById("bfrl_disableExtensionsButton");
var disclaimerInfo = document.querySelector("#bfrl_disableDisclaimerInfo");
var disclaimerInfoText = document.querySelector("#bfrl_disableDisclaimerInfoText");
var disableDisclaimerCloseButton = document.querySelector("#bfrl_disableDisclaimerCloseButton");

disableButton.addEventListener("click", function (event) {
	_sendDisablingMessage("getAllExtensions", null, function (results) {
		//Make sure the returned parameter is an array of results. If it's not a type of Array, we ignore.
		if (Array.isArray(results) && results.length > 0) {
			let json = JSON.stringify(results);
			json = encodeURIComponent(json);
			_sendDisablingMessage("OpenDialog", {
				newURL: "disable/disable_page2.html?q=" + json + "&localparent=" + disableParams["localparent"],
				newWidth: 400,
				newHeight: 552,
				results: results,
				isUnknown: false
			});
		}
		else {
			_sendDisablingMessage("OpenDialog", {
				newWidth: 400,
				newHeight: 235,
				newURL: "disable/disable_page3.html" + "?localparent=" + disableParams["localparent"],
				isUnknown: false
			});
		}
	});
});

disclaimerInfo.addEventListener("click", function(event) {
	disclaimerInfoText.style.display = "inline-block";
});

disableDisclaimerCloseButton.addEventListener("click", function(event) {
	disclaimerInfoText.style.display = "none";
});
