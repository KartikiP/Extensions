var deeplinkURL = document.getElementById("bfrl_deeplink");
var closeButton = document.getElementById("bfrl_closeButton");
let isCouponsTesting = false;
var fromEmbedded = false;

function CloseEveryDialogs(event) {
	if (!event) {
		event = window.event;
	}
	event.stopPropagation();
	event.stopImmediatePropagation();
	event.preventDefault();
	event.cancelBubble = true;

	chrome.runtime.sendMessage({
	    targetScript: "autoApplyApp.js",
	    action: "iframeClose",
	    data: { type: "6" }
	}, function () {
        if (chrome.runtime.lastError) {
            console.debug(chrome.runtime.lastError.message);
        }
    });
    
    chrome.runtime.sendMessage({
        targetScript: "autoApplyApp.js",
        action: "iframeClose",
        data: { type: "report" }
    }, function () {
        if (chrome.runtime.lastError) {
            console.debug(chrome.runtime.lastError.message);
        }
    });
}

function ReturnToAutoApply(event) {
	if (!event) {
		event = window.event;
	}
	event.stopPropagation();
	event.stopImmediatePropagation();
	event.preventDefault();
	event.cancelBubble = true;

	if (isCouponsTesting) {
		chrome.runtime.sendMessage({
			targetScript: "autoApplyApp.js",
			action: "iframeClose",
			data: { type: "6" }
		}, function () {
			if (chrome.runtime.lastError) {
				console.debug(chrome.runtime.lastError.message);
			}
		});

		chrome.runtime.sendMessage({
			targetScript: "autoApplyApp.js",
			action: "OpenApplyCouponDialog"
		}, function () {
			if (chrome.runtime.lastError) {
				console.debug(chrome.runtime.lastError.message);
			}
		});
	}
    
    //Report iframe needs to be closed last, in order for the script to continue running for callbacks.
    chrome.runtime.sendMessage({
        targetScript: "autoApplyApp.js",
        action: "iframeClose",
        data: { type: "report" }
    }, function () {
        if (chrome.runtime.lastError) {
            console.debug(chrome.runtime.lastError.message);
        }
    });
}

window.addEventListener("DOMContentLoaded", function (loadedEvent) {
	DataTransfer(resultProblemSearch["couponsTesting"], resultProblemSearch["fromEmbedded"]);

	if (fromEmbedded) {
		deeplinkURL.innerText = "Close";
	}
	deeplinkURL.addEventListener("click", function(event) {
		CloseEveryDialogs(event);
	});
	closeButton.addEventListener("click", function(event) {
		CloseEveryDialogs(event);
	});
});

var resultProblemSearch = (function (input) {
	if (input == "")
		return {};
	var output = {};
	for (var i = 0; i < input.length; ++i) {
		var params = input[i].split('=', 2);
		if (params.length == 1)
			output[params[0]] = "";
		else
			output[params[0]] = decodeURIComponent(params[1].replace(/\+/g, " "));
	}
	return output;
})(window.location.search.substr(1).split('&'));

function DataTransfer(couponsTesting, fromEmb) {
	isCouponsTesting = couponsTesting === "true";
	fromEmbedded = fromEmb;
}
