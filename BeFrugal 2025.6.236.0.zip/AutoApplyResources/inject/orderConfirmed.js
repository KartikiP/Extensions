﻿let closeButton = document.getElementById("bfrl_closeButton");
let turnOnNotificationsButton = document.getElementById("turnOnNotificationsButton");
let bfrl_cashbackRateBold = document.getElementById("bfrl_cashbackRateBold");
let cashbackTimeText = document.getElementById("cashbackTimeText");
let cashbackAddedTextContainer = document.getElementById("cashbackAddedTextContainer");
let cashbackAddedText = document.getElementById("cashbackAddedText");
let cashbackActionMessage = document.getElementById("cashbackActionMessage");
let flagBannerImg = document.getElementById("flagBannerImg");

let isWhenRetailerNotifiesUsDelay = false;

let resultShareUrlSearch = (function (input) {
	if (input === "")
		return {};
	var output = {};
	for (var i = 0; i < input.length; ++i) {
		var params = input[i].split('=', 2);
		if (params.length === 1)
			output[params[0]] = "";
		else
			output[params[0]] = decodeURIComponent(params[1].replace(/\+/g, " "));
	}
	return output;
})(window.location.search.substr(1).split('&'));

window.addEventListener("DOMContentLoaded", function (event) {
	let cbRate = resultShareUrlSearch["cashbackRate"];
	if (cbRate.indexOf("up") > -1) cbRate = cbRate.replace("up", "Up");
	bfrl_cashbackRateBold.innerText = cbRate;

	let avgReportingDelay = resultShareUrlSearch["averageReportingDelay"];
	let avgReportingDelayText;

	switch (avgReportingDelay) {
		case "-1":
			avgReportingDelayText = "when the retailer notifies us."
			cashbackAddedTextContainer.style.paddingInline = "30px";
			cashbackTimeText.style.fontWeight = "100";
			isWhenRetailerNotifiesUsDelay = true;
			break;
		case "0":
			avgReportingDelayText = "today.";
			break;
		case "1":
			avgReportingDelayText = "by tomorrow.";
			break;
		default:
			avgReportingDelayText = `within ${avgReportingDelay} days.`
			break;
	}

	cashbackTimeText.innerText = avgReportingDelayText;


	closeButton.addEventListener("click", closePopup);
	turnOnNotificationsButton.addEventListener("click", requestPermissions);

	chrome.permissions.contains({ permissions: ["notifications"] }, (isGranted) => {
		// behavior for when notifications are added to extension
		/*if (isGranted) {
			chrome.runtime.sendMessage({
				targetScript: "autoApplyApp.js",
				action: "iframeResize",
				data: {
					newWidth: 345,
					newHeight: 365,
					centered: false,
					move: true,
					newTop: 20,
					newRight: 30,
				}
			}, function () {
				if (chrome.runtime.lastError) {
					console.debug(chrome.runtime.lastError.message);
				}
				setNotificationsGrantedPopup();
			});
		}*/

		chrome.runtime.sendMessage({
			targetScript: "autoApplyApp.js",
			action: "iframeResize",
			data: {
				newWidth: 345,
				newHeight: 365,
				centered: false,
				move: true,
				newTop: 20,
				newRight: 30,
			}
		}, function () {
			if (chrome.runtime.lastError) {
				console.debug(chrome.runtime.lastError.message);
			}
			setNotificationsGrantedPopup();
		});
	});
});

function requestPermissions() {
	chrome.permissions.request({
		permissions: ["notifications"]
	}, function (isGranted) { // close afterwards
		closePopup();
	});
}

function closePopup() {
	chrome.runtime.sendMessage({
		targetScript: "autoApplyApp.js",
		sourceScript: "orderConfirmed.js",
		action: "iframeClose",
		data: { type: "6" }
	});
}

function setLastDisableExtensionsNotificationDate() {
	chrome.runtime.sendMessage({
		action: "Preference Manager",
		data: {
			pref: "Settings"
		}
	}, (settings) => {
		if (chrome.runtime.lastError) {
			console.debug(chrome.runtime.lastError.message);
		}
		settings.LastDisableExtensionsNotificationDate = new Date();
		chrome.runtime.sendMessage({
			action: "Preference Manager",
			data: {
				pref: "Settings",
				value: settings
			}
		}, () => {
			if (chrome.runtime.lastError) {
				console.debug(chrome.runtime.lastError.message);
			}
			chrome.windows.getCurrent((window) => {
				let center = window.width / 2;
				let iframeWidth = 455;

				chrome.runtime.sendMessage({
					targetScript: "autoApplyApp.js",
					action: "iframeResize",
					data: {
						newWidth: iframeWidth,
						newHeight: 365,
						centered: false,
						move: true,
						newTop: 180,
						newRight: center - (iframeWidth / 2),
						newLeft: 0
					}
				}, function () {
					if (chrome.runtime.lastError) {
						console.debug(chrome.runtime.lastError.message);
					}
					chrome.runtime.sendMessage({
						targetScript: "autoApplyApp.js",
						action: "iframeSetURL",
						newURL: "AutoApplyResources/inject/allowPermissions.html",
						applyBlackout: true,
						centered: false,
						resize: false,
						clearWrapper: true
					});
				});
			});
		});
	});
}

function disableExtensions() {
	chrome.runtime.sendMessage({
		action: "popupWorkaround",
		targetScript: "disableBackgroundApp.js",
	}, () => {
		if (chrome.runtime.lastError) {
			console.debug(chrome.runtime.lastError.message);
		}
		setLastDisableExtensionsNotificationDate();
	});
}

// One might argue that the notifications granted popup could also be called the disable extensions popup
function setNotificationsGrantedPopup() {
	flagBannerImg.src = "img/flagBannerWide.png";
	flagBannerImg.style.marginTop = "6px";
	document.getElementById("getNotifiedDiv").innerText = "Ensure your cash back!";
	cashbackActionMessage.innerText = "To guarantee your Cash Back earnings, disable conflicting extensions.";
	turnOnNotificationsButton.innerText = "Disable conflicting extensions";
	turnOnNotificationsButton.classList.remove("bfrl_blue_bg");
	turnOnNotificationsButton.classList.add("bfrl_orange_bg");

	cashbackAddedTextContainer.style.paddingInline = isWhenRetailerNotifiesUsDelay ? "30px" : "50px";
	document.getElementById("getNotifiedDiv").style.fontSize = "22px";

	let brElem1 = document.createElement("br");
	let brElem2 = document.createElement("br");
	cashbackAddedText.insertBefore(brElem1, cashbackActionMessage);
	cashbackAddedText.insertBefore(brElem2, cashbackActionMessage);
	

	turnOnNotificationsButton.removeEventListener("click", requestPermissions)
	turnOnNotificationsButton.addEventListener('click', disableExtensions);

	closeButton.removeEventListener("click", closePopup);
	closeButton.addEventListener("click", setLastDisableExtensionsNotificationDate);
}