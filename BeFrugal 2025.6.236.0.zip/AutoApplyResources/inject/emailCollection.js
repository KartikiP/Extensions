﻿const BrowserType = function () {
	return {
		NONE: -1,
		Chrome: 0,
		Firefox: 1,
		Edge: 2,
		Get: function () {
			//Isolated namespace checking when we can't even access the background script.
			var result = BrowserType.NONE;
			if (typeof browser === "undefined") {
				result = BrowserType.Chrome;
				return result;
			}
			let supportsPromises = false;
			try {
				supportsPromises = browser.runtime.getPlatformInfo() instanceof Promise;
			}
			catch (e) {
				supportsPromises = false;
			}
			if (!supportsPromises)
				result = BrowserType.Edge;
			else
				result = BrowserType.Firefox;
			return result;
		}
	};
}();

window.namespace = (BrowserType.Get() === BrowserType.Chrome ? chrome : browser);

function setUpBeFrugalRegister(allowedToSubscribe) {
	let validateEmail = function (email) {
		return /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/i.test(email);
	}

	let testForLogin = function () {
		if (typeof chrome === "undefined") return;
		chrome.runtime.sendMessage({
			sourceScript: "emailCollection.js",
			targetScript: "shoptoolbar.js",
			action: "signedUp"
		}, function (results) {
			if (chrome.runtime.lastError) {
				console.debug(chrome.runtime.lastError.message);
			}
			if (results) {
				// Close popup?
				closeIframe();
			}
		});
	};

	let txtEmailAddress = document.getElementById("bfrl_txtEmailAddress");
	txtEmailAddress.addEventListener("keydown", function () {
		let redText = document.getElementById("bfrl_invalidEmail");
		if (redText.style.visibility === "visible") {
			redText.style.visibility = "hidden";
		}
	});

	txtEmailAddress.addEventListener('keyup', (event) => {
		if (event.key != null && event.key === "Enter") {
			document.getElementById("bfrl_btnEmailAddress").dispatchEvent(new Event("click"));
		}
	});


	let emailButtonOnClick = function () {
		if (!validateEmail(txtEmailAddress.value)) {
			document.getElementById("bfrl_invalidEmail").style.visibility = "visible";
			return;
		}

		if (typeof chrome === "undefined") return;

		chrome.runtime.sendMessage({
			sourceScript: "emailCollection.js",
			targetScript: "shoptoolbar.js",
			action: "signUp",
			email: txtEmailAddress.value,
			declineNewsletters: !(document.getElementById("bfrl_chkSubscriber").checked)
		}, function (results) {
			if (chrome.runtime.lastError) {
				console.debug(chrome.runtime.lastError.message);
			}
			if (results) {
				// Possible close popup
				closeIframe();
			}
		});
	}

	let openWindow;

	let appleOnClick = function () {
		let y = window.outerHeight / 2 + window.screenY - 205;
		let x = window.outerWidth / 2 + window.screenX - 175;
		let chkSubscribe = document.getElementById("bfrl_chkSubscriber").checked;
		openWindow = window.open("https://www.befrugal.com/addon/signup/?login=apple&subscribe=" + chkSubscribe, '_blank', 'toolbar=no,scrollbars=0,location=0,statusbar=0,menubar=0,resizable=0,width=400,height=425,top=' + y + ', left=' + x);
		let timer = setInterval(function () {
			if (openWindow.closed) {
				clearInterval(timer);
				testForLogin();
			}
		}, 1000);
	};

	let googleOnClick = function () {
		let y = window.outerHeight / 2 + window.screenY - 205;
		let x = window.outerWidth / 2 + window.screenX - 175;
		let chkSubscribe = document.getElementById("bfrl_chkSubscriber").checked;
		openWindow = window.open("https://www.befrugal.com/addon/signup/?login=google&subscribe=" + chkSubscribe, '_blank', 'toolbar=0,scrollbars=0,location=0,statusbar=0,menubar=0,resizable=0,width=400,height=425,top=' + y + ', left=' + x);
		setBodyListener();
		let timer = setInterval(function () {
			if (openWindow.closed) {
				clearInterval(timer);
				testForLogin();
			}
		}, 1000);
	};

	let facebookOnClick = function () {
		let y = window.outerHeight / 2 + window.screenY - 205;
		let x = window.outerWidth / 2 + window.screenX - 175;
		let chkSubscribe = document.getElementById("bfrl_chkSubscriber").checked;
		openWindow = window.open("https://www.befrugal.com/addon/signup/?login=facebook&subscribe=" + chkSubscribe, '_blank', 'toolbar=0,scrollbars=0,location=0,statusbar=0,menubar=0,resizable=0,width=400,height=425,top=' + y + ', left=' + x);
		setBodyListener();
		let timer = setInterval(function () {
			if (openWindow.closed) {
				clearInterval(timer);
				testForLogin();
			}
		}, 1000);
	};


	let appleButton = document.getElementById("bfrl_appleButton");
	let googleButton = document.getElementById("bfrl_googleButton");
	let facebookButton = document.getElementById("bfrl_facebookButton2");
	let socialsButtons = [appleButton, googleButton, facebookButton];

	let emailInput = document.getElementById("bfrl_txtEmailAddress");
	let emailButton = document.getElementById("bfrl_btnEmailAddress");

	let enableRegistrationElements = function () {
		emailButton.addEventListener("click", emailButtonOnClick);
		emailInput.removeAttribute("disabled");
		emailInput.classList = "";
		emailButton.classList = "bfrl_orangeEmailButton";
		document.getElementById("orText").classList.remove("disabled");

		appleButton.addEventListener("click", appleOnClick);
		googleButton.addEventListener("click", googleOnClick);
		facebookButton.addEventListener("click", facebookOnClick);
		socialsButtons.forEach((ele) => {
			ele.classList = "bfrl_signInButtons bfrl_white";
		});
	}

	let disableRegistrationElements = function () {
		emailInput.removeEventListener("click", emailButtonOnClick);
		emailInput.setAttribute("disabled", "true");
		emailInput.classList = "disabled";
		emailButton.classList = "bfrl_orangeEmailButtonDisabled disabled";
		document.getElementById("orText").classList.add("disabled");

		appleButton.removeEventListener("click", appleOnClick);
		googleButton.removeEventListener("click", googleOnClick);
		facebookButton.removeEventListener("click", facebookOnClick);
		socialsButtons.forEach((ele) => {
			ele.classList = "bfrl_signInButtonsDisabled bfrl_white disabled";
		});
	}

	document.getElementById("bfrl_alreadyMemeber").addEventListener("click", function () {
		event.preventDefault();
		event.stopPropagation();
		event.stopImmediatePropagation();
		event.preventDefault();
		event.cancelBubble = true;
		let y = window.outerHeight / 2 + window.screenY - 275;
		let x = window.outerWidth / 2 + window.screenX - 175;
		let chkSubscribe = document.getElementById("bfrl_chkSubscriber").checked;
		openWindow = window.open("https://www.befrugal.com/addon/signup/?show=login&subscribe=" + chkSubscribe, '_blank', 'toolbar=0,scrollbars=0,location=0,statusbar=0,menubar=0,resizable=0,width=350,height=550,top=' + y + ', left=' + x);
		setBodyListener();
		let timer = setInterval(function () {
			if (openWindow.closed) {
				clearInterval(timer);
				testForLogin();
			}
		}, 1000);
		return false;
	});

	document.getElementById("bfrl_chkSubscriber").addEventListener("click", () => {
		if (document.getElementById("bfrl_chkSubscriber").checked) {
			enableRegistrationElements();
		} else {
			disableRegistrationElements();
		}
	})

	document.getElementById("closeIframeButton").addEventListener("click", function () {
		/*event.preventDefault();
		event.stopPropagation();
		event.stopImmediatePropagation();
		event.preventDefault();
		event.cancelBubble = true;*/
		closeIframe();
	})

    // GDPR
	if (allowedToSubscribe) {
		enableRegistrationElements();
	} else {
		document.getElementById("bfrl_chkSubscriber").checked = false;
		document.getElementById("bfrl_chkBestDeals").checked = false;
		document.getElementById("termsAndPolicyStatement").style.display = "none";
		disableRegistrationElements();
		showCheckboxes();
	}

	let setBodyListener = () => {
		document.body.addEventListener('click', e => openWindow.focus());
	}
};

function showCheckboxes() {
	document.getElementById("bfrl_dvSubscriber").style.display = "flex";
}

function DataTransfer(retailerName, cashbackRate, imageUrl, allowedToSubscribe) {
	document.getElementById("registrationRetailerLogo").setAttribute("src", "https://" + imageUrl);
	document.getElementById("cashbackRate").innerText = ` ${cashbackRate} from ${retailerName}!`;
	setUpBeFrugalRegister(allowedToSubscribe === "true"); // convert allowedToSubscribe to a boolean
	if (true) {
		guestMode = true;
	}
}

window.addEventListener("DOMContentLoaded", function (event) {
	DataTransfer(resultShareUrlSearch["retailer"], resultShareUrlSearch["cashbackRate"], resultShareUrlSearch["imageUrl"], resultShareUrlSearch["allowedToSubscribe"]);
});

var resultShareUrlSearch = (function (input) {
	if (input === "")
		return {};
	var output = {};
	for (var i = 0; i < input.length; ++i) {
		var params = input[i].split('=', 2);
		if (params.length === 1)
			output[params[0]] = "";
		else
			output[params[0]] = decodeURIComponent(params[1].replace(/\+/g, " "));
	}
	return output;
})(window.location.search.substr(1).split('&'));

function closeIframe() {
	chrome.runtime.sendMessage({
		sourceScript: "emailCollection.js",
		targetScript: "autoApplyApp.js",
		intendedTargetScript: "autoApplyContent.js",
		action: "iframeClose",
		data: { type: "7" }
	}, function () {
		if (chrome.runtime.lastError) {
			console.debug(chrome.runtime.lastError.message);
		}
	});
}