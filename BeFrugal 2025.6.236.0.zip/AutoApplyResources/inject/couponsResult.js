const BrowserType = function () {
    return {
        NONE: -1,
        Chrome: 0,
        Firefox: 1,
        Edge: 2,
        Get: function () {
            //Isolated namespace checking when we can't even access the background script.
            var result = BrowserType.NONE;
            if (typeof browser === "undefined") {
                result = BrowserType.Chrome;
                return result;
            }
            let supportsPromises = false;
            try {
                supportsPromises = browser.runtime.getPlatformInfo() instanceof Promise;
            }
            catch (e) {
                supportsPromises = false;
            }
            if (!supportsPromises)
                result = BrowserType.Edge;
            else
                result = BrowserType.Firefox;
            return result;
        }
    };
}();

window.namespace = (BrowserType.Get() === BrowserType.Chrome ? chrome : browser);

var totalSavedData = document.querySelector("#totalSavedMessage #bfrl_totalSaved");
var totalSavedDataNoCodes = document.querySelector("#noCodesWithCBMessage #bfrl_totalSaved");
var cashbackRateText = document.getElementById("bfrl_cashbackRate");
var activatedSuffix = document.getElementById("bfrl_activatedSuffix");
var checkoutButton = document.getElementById("bfrl_continueToCheckoutButton");
var reportProblem = document.getElementById("bfrl_reportProblem");
var closeButton1 = document.querySelector(".sidePanel_close #bfrl_closeButton");
var closeButton2 = document.querySelector(".sidePanel_open #bfrl_closeButton");
var bonusCashbackRateTexts = document.querySelectorAll("span.bfrl_bonusCashback");
var bonusFriendGetsTexts = document.querySelectorAll("span.bfrl_bonusFriendGets");
var bonusRemove = document.querySelectorAll(".bfrl_ref");
var appliedCodeText = document.querySelector("#bfrl_codesList");
var appliedCodeTextNoCB = document.getElementById("bfrl_codesList_noCB");
var shareUsLink = document.getElementById("bfrl_shareUsLink");
var facebookButton = document.getElementById("bfrl_facebookButton");
var twitterButton = document.getElementById("bfrl_twitterButton");
var copyButton = document.getElementById("bfrl_copyTextButton");
var rafLinkInputBox = document.getElementById("bfrl_rafLinkInputBox");
var discountAmountBox = document.getElementById("discountAmount");
var cashbackAmountBox = document.getElementById("cashbackAmount");
var cashbackTermsLink = document.getElementById("bfrl_terms");
var cashbackTermsLinkNoCodes = document.getElementById("bfrl_terms_nocodes");
var rateUsLink = document.getElementById("bfrl_rateUsLink");
var codesText = document.querySelector("#codesNoCB #bfrl_codesText");
let openWindow;


var guestMode = false;
var sidePanelOpenFlag = false;
var disableCopyGuard = false;
var extraCodesLength = 0;
var loggedIn = false;

function _cashbackTermsHandler(evt) {
	chrome.runtime.sendMessage({
		targetScript: "autoApplyApp.js",
		action: "openTerms",
		data: {
			cbTerms: cashbackTermsLink.cbTerms
		}
	}, function () {
		if (chrome.runtime.lastError) {
			console.debug(chrome.runtime.lastError.message);
		}
	});
}


function toggleRAFSidePanel(isGuest, isCB) {
	//TODO(Thompson): Need access to the parent element, in order to resize and re-center the dialogs when the link is clicked.
	if (!sidePanelOpenFlag) {
		chrome.runtime.sendMessage({
			targetScript: "autoApplyApp.js",
			action: "iframeResize",
			data: {
				newWidth: 736,
				centered: true,
				extraCodesLength: extraCodesLength
			}
		}, function () {
		    if (chrome.runtime.lastError) {
		        console.debug(chrome.runtime.lastError.message);
		    }
		});
        document.querySelector(".sidePanel_open").style.display = "block";
        document.querySelector(".sidePanel_close").style.display = "none";
		document.querySelector("#bfrl_rightSection").style.display = "block";
		sidePanelOpenFlag = true;
	}
	else {
		if (!isGuest || !isCB || loggedIn) {
			document.querySelector(".sidePanel_open").style.display = "none";
			document.querySelector(".sidePanel_close").style.display = "block";
			document.querySelector("#bfrl_rightSection").style.display = "none";
			chrome.runtime.sendMessage({
				targetScript: "autoApplyApp.js",
				action: "iframeResize",
				data: {
					newWidth: 428,
					centered: true,
					extraCodesLength: extraCodesLength
				}
			}, function () {
				if (chrome.runtime.lastError) {
					console.debug(chrome.runtime.lastError.message);
				}
			});
			sidePanelOpenFlag = false;
		}
		else {
			if (document.getElementById("bfrl_registerGroup").style.display == "none") {
				document.getElementById("bfrl_registerGroup").style.display = "block";
				document.getElementById("bfrl_shareGroup").style.display = "none";
			}
			else {
				document.getElementById("bfrl_registerGroup").style.display = "none";
				document.getElementById("bfrl_shareGroup").style.display = "block";
			}

			document.querySelector(".sidePanel_open").style.display = "block";
			document.querySelector(".sidePanel_close").style.display = "none";
			sidePanelOpenFlag = true;
		}
	}
}

function setSelectionRange(input, selectionStart, selectionEnd) {
	if (input.setSelectionRange) {
		input.focus();
		input.setSelectionRange(selectionStart, selectionEnd);
	}
	else if (input.createTextRange) {
		var range = input.createTextRange();
		range.collapse(true);
		range.moveEnd('character', selectionEnd);
		range.moveStart('character', selectionStart);
		range.select();
	}
}

function setUpBeFrugalRegister(allowedToSubscribe, share) {
	let validateEmail = function (email) {
		return /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/i.test(email);
	}

	let testForLogin = function () {
		if (typeof chrome === "undefined") return;
		chrome.runtime.sendMessage({
			sourceScript: "couponsResultShare.js",
			targetScript: "shoptoolbar.js",
			action: "signedUp"
		}, function (results) {
			if (chrome.runtime.lastError) {
				console.debug(chrome.runtime.lastError.message);
			}
			if (results) {
				if(share)
					document.getElementById("bfrl_shareGroup").style.display = "block";
				document.getElementById("bfrl_registerGroup").style.display = "none";
				shareUsLink.click();
			}
		});
	};

	let txtEmailAddress = document.getElementById("bfrl_txtEmailAddress");
	txtEmailAddress.addEventListener("keydown", function () {
		let redText = document.getElementById("bfrl_invalidEmail");
		if (redText.style.visibility === "visible") {
			redText.style.visibility = "hidden";
        }
	});

	txtEmailAddress.addEventListener('keyup', (event) => {
		if (event.key != null && event.key === "Enter") {
			document.getElementById("bfrl_btnEmailAddress").dispatchEvent(new Event("click"));
		}
	});


	let emailButtonOnClick = function () {

		if (!validateEmail(txtEmailAddress.value)) {
			document.getElementById("bfrl_invalidEmail").style.visibility = "visible";
			return;
		}

		if (typeof chrome === "undefined") return;

		chrome.runtime.sendMessage({
			sourceScript: "couponsResult.js",
			targetScript: "shoptoolbar.js",
			action: "signUp",
			email: txtEmailAddress.value,
			declineNewsletters: !(document.getElementById("bfrl_chkSubscriber").checked)
		}, function (results) {
			if (chrome.runtime.lastError) {
				console.debug(chrome.runtime.lastError.message);
			}
			if (results) {
				if (share) {
					document.getElementById("bfrl_shareGroup").style.display = "block";
					shareUsLink.click();
				}
				else
					document.getElementById("bfrl_downloadAppGroup").style.display = "block";

				document.getElementById("bfrl_registerGroup").style.display = "none";

				loggedIn = true;
			}
		});
	}

	let appleOnClick = function () {
		let y = window.outerHeight / 2 + window.screenY - 205;
		let x = window.outerWidth / 2 + window.screenX - 175;
		let chkSubscribe = document.getElementById("bfrl_chkSubscriber").checked;
		openWindow = window.open("https://www.befrugal.com/addon/signup/?login=apple&subscribe=" + chkSubscribe, '_blank', 'toolbar=no,scrollbars=0,location=0,statusbar=0,menubar=0,resizable=0,width=400,height=425,top=' + y + ', left=' + x);
		let timer = setInterval(function () {
			if (openWindow.closed) {
				clearInterval(timer);
				testForLogin();
			}
		}, 1000);
	};

	let googleOnClick = function () {
		let y = window.outerHeight / 2 + window.screenY - 205;
		let x = window.outerWidth / 2 + window.screenX - 175;
		let chkSubscribe = document.getElementById("bfrl_chkSubscriber").checked;
		openWindow = window.open("https://www.befrugal.com/addon/signup/?login=google&subscribe=" + chkSubscribe, '_blank', 'toolbar=0,scrollbars=0,location=0,statusbar=0,menubar=0,resizable=0,width=400,height=425,top=' + y + ', left=' + x);
		setBodyListener();
		let timer = setInterval(function () {
			if (openWindow.closed) {
				clearInterval(timer);
				testForLogin();
			}
		}, 1000);
	};

	let facebookOnClick = function () {
		let y = window.outerHeight / 2 + window.screenY - 205;
		let x = window.outerWidth / 2 + window.screenX - 175;
		let chkSubscribe = document.getElementById("bfrl_chkSubscriber").checked;
		openWindow = window.open("https://www.befrugal.com/addon/signup/?login=facebook&subscribe=" + chkSubscribe, '_blank', 'toolbar=0,scrollbars=0,location=0,statusbar=0,menubar=0,resizable=0,width=400,height=425,top=' + y + ', left=' + x);
		setBodyListener();
		let timer = setInterval(function () {
			if (openWindow.closed) {
				clearInterval(timer);
				testForLogin();
			}
		}, 1000);
	};

	let appleButton = document.getElementById("bfrl_appleButton");
	let googleButton = document.getElementById("bfrl_googleButton");
	let facebookButton = document.getElementById("bfrl_facebookButton2");
	let socialsButtons = [appleButton, googleButton, facebookButton];

	let emailInput = document.getElementById("bfrl_txtEmailAddress");
	let emailButton = document.getElementById("bfrl_btnEmailAddress");

	let enableRegistrationElements = function () {
		emailButton.addEventListener("click", emailButtonOnClick);
		emailInput.removeAttribute("disabled");
		emailInput.classList = "";
		emailButton.classList = "bfrl_orangeEmailButton";

		appleButton.addEventListener("click", appleOnClick);
		googleButton.addEventListener("click", googleOnClick);
		facebookButton.addEventListener("click", facebookOnClick);
		socialsButtons.forEach((ele) => {
			ele.classList = "bfrl_signInButtons bfrl_white";
		});
	}

	let disableRegistrationElements = function () {
		emailInput.removeEventListener("click", emailButtonOnClick);
		emailInput.setAttribute("disabled", "true");
		emailInput.classList = "disabled";
		emailButton.classList = "bfrl_orangeEmailButtonDisabled disabled";

		appleButton.removeEventListener("click", appleOnClick);
		googleButton.removeEventListener("click", googleOnClick);
		facebookButton.removeEventListener("click", facebookOnClick);
		socialsButtons.forEach((ele) => {
			ele.classList = "bfrl_signInButtonsDisabled bfrl_white disabled";
		});
	}

	document.getElementById("bfrl_chkSubscriber").addEventListener("click", () => {
		if (document.getElementById("bfrl_chkSubscriber").checked) {
			enableRegistrationElements();
		} else {
			disableRegistrationElements();
		}
	})

	if (allowedToSubscribe) {
		enableRegistrationElements();
	} else {
		document.getElementById("bfrl_chkSubscriber").checked = false;
		document.getElementById("bfrl_chkBestDeals").checked = false;
		document.getElementById("termsAndPolicyStatement").style.display = "none";
		disableRegistrationElements();
		showCheckboxes();
	}

	let setBodyListener = () => {
		document.body.addEventListener('click', e => openWindow.focus());
	}

	/*document.getElementById("bfrl_alreadyMemeber").addEventListener("click", function () {
		event.preventDefault();
		event.stopPropagation();
		event.stopImmediatePropagation();
		event.preventDefault();
		event.cancelBubble = true;
		let y = window.outerHeight / 2 + window.screenY - 275;
		let x = window.outerWidth / 2 + window.screenX - 175;
		let chkSubscribe = document.getElementById("bfrl_chkSubscriber").checked;
		openWindow = window.open("https://www.befrugal.com/addon/signup/?show=login&subscribe=" + chkSubscribe, '_blank', 'toolbar=0,scrollbars=0,location=0,statusbar=0,menubar=0,resizable=0,width=350,height=550,top=' + y + ', left=' + x);
		let timer = setInterval(function () {
			if (openWindow.closed) {
				clearInterval(timer);
				testForLogin();
			}
		}, 1000);
		return false;
	});*/
};

function showCheckboxes() {
	document.getElementById("bfrl_dvSubscriber").style.display = "flex";
}

function setupShareSpecifics(isGuest, isCB) {
	document.getElementById("shareFooter").style.display = "block";
	document.getElementById("message_div").style.margin = "0";
	document.getElementById("bfrl_footnote").style.top = "-15px";

	chrome.runtime.sendMessage({
		action: "ReferAFriendTerms",
	}, (rafTerms) => {
		let referAFriendContentElem = document.querySelector(".referAFriendContent");
		referAFriendContentElem.innerHTML = DOMPurify.sanitize(rafTerms, { ADD_ATTR: ['target'] });
	});

	document.getElementById("referAFriendLink").addEventListener("click", (e) => {
		document.querySelector(".referAFriendPopupContainer").style.display = "block";
	});

	document.querySelector(".referAFriendClose").addEventListener("click", (e) => {
		document.querySelector(".referAFriendPopupContainer").style.display = "none";
	});

	chrome.runtime.sendMessage({
		targetScript: "buttonApp.js",
		action: "getReferralLinks"
	}, function (data) {

		if (chrome.runtime.lastError) {
			console.debug(chrome.runtime.lastError.message);
		}

		//It's only when referral links are there, do we then set the event listeners to the buttons.
		facebookButton.addEventListener("click", function (e) {
			window.open(data.Facebook, 'targetWindow', 'toolbar=no,location=0,status=no,menubar=no,scrollbars=yes,resizable=yes,width=600,height=400');
			return false;
		});

		twitterButton.addEventListener("click", function (e) {
			window.open(data.Twitter, 'targetWindow', 'toolbar=no,location=0,status=no,menubar=no,scrollbars=yes,resizable=yes,width=600,height=400');
			return false;
		});

		copyButton.addEventListener("click", function (e) {
			try {
				if (disableCopyGuard)
					return;
				disableCopyGuard = true;
				var copyButtonText = copyButton.querySelector("span");

				//TODO(Thompson): Add the correct referral link instead of the template URL.
				setSelectionRange(rafLinkInputBox, 0, rafLinkInputBox.value.length);
				var isSupported = document.execCommand("copy", false, null);
				if (!isSupported) {
					throw "document.execCommand() - Copy command is not supported.";
				}

				setSelectionRange(rafLinkInputBox, 0, 0);
				rafLinkInputBox.scrollLeft = "0px";

				//NOTE(Thompson): Displays the "Copied" text underneath the Copy button for 4 seconds, then hide it, if the copy action is successful.
				copyButtonText.innerText = "Copied";
				copyButton.classList.add("btncopied");
				setTimeout(function () {
					copyButtonText.innerText = "Copy Link";
					copyButton.classList.remove("btncopied");
					copyButton.classList.add("btncopy");
					disableCopyGuard = false;
				}, 4000);
			}
			catch (e) {
				console.debug("(couponsResultShare.js) Error -", e);
			}
		});

		rafLinkInputBox.value = data.Copy.substr(12);

		let rightClose = document.querySelector(".bfrl_closeButtonContainer.sidePanel_open");
		if (rightClose)
			rightClose.style.right = "-5px";
	});

	shareUsLink.addEventListener("click", function (e) {
		toggleRAFSidePanel(isGuest, isCB);

		document.getElementById("bfrl_closeButton").style.margin = "0 0 0 0";
	});

	if (isGuest && isCB) {
		document.querySelector("#bfrl_rightSection").style.display = "block";
		document.querySelector("#bfrl_registerGroup").style.display = "block";
		document.querySelector("#bfrl_shareGroup").style.display = "none";
		chrome.runtime.sendMessage({
			targetScript: "autoApplyApp.js",
			action: "iframeResize",
			data: {
				newWidth: 736,
				centered: true,
				extraCodesLength: extraCodesLength
			}
		}, function () {
			if (chrome.runtime.lastError) {
				console.debug(chrome.runtime.lastError.message);
			}
		});
		sidePanelOpenFlag = true;
	}
	else {
		document.querySelector("#bfrl_rightSection").style.display = "block";
		document.querySelector("#bfrl_registerGroup").style.display = "none";
		document.querySelector("#bfrl_shareGroup").style.display = "block";
	}
	if (!sidePanelOpenFlag && window.innerWidth > 500)
		sidePanelOpenFlag = true;
	if (sidePanelOpenFlag) {
		document.querySelector(".sidePanel_open").style.display = "block";
		document.querySelector(".sidePanel_close").style.display = "none";
	}
	else {
		document.querySelector(".sidePanel_open").style.display = "none";
		document.querySelector(".sidePanel_close").style.display = "block";
	}

}

function setupRateSpecifics(isGuest, isCB) {
	document.getElementById("rateFooter").style.display = "block";
	document.getElementById("message_div").style.margin = "10px 0 0 0";
	document.getElementById("bfrl_footnote").style.top = "-25px";

	if (!isCB) {
		document.querySelector(".sidePanel_open").style.display = "none";
		document.querySelector(".sidePanel_close").style.display = "block";
	}

	rateUsLink.addEventListener("click", function () {
		if (!isGuest || !isCB || sidePanelOpenFlag) {
			chrome.runtime.sendMessage({
				targetScript: "autoApplyApp.js",
				action: "setRateUsFlag"
			}, function () {
				if (chrome.runtime.lastError) {
					console.debug(chrome.runtime.lastError.message);
				}
			});
			chrome.runtime.sendMessage({
				targetScript: "autoApplyApp.js",
				action: "openNewRateUsTab"
			}, function () {
				if (chrome.runtime.lastError) {
					console.debug(chrome.runtime.lastError.message);
				}
			});
		}
		else if(isCB) {
			document.querySelector("#bfrl_rightSection").style.display = "block";
			document.querySelector(".sidePanel_open").style.display = "block";
			document.querySelector(".sidePanel_close").style.display = "none";
			document.getElementById("bfrl_registerGroup").style.display = "block";
			document.getElementById("bfrl_shareGroup").style.display = "none";

			chrome.runtime.sendMessage({
				targetScript: "autoApplyApp.js",
				action: "iframeResize",
				data: {
					newWidth: 736,
					centered: true,
					extraCodesLength: extraCodesLength
				}
			}, function () {
				if (chrome.runtime.lastError) {
					console.debug(chrome.runtime.lastError.message);
				}
			});
			sidePanelOpenFlag = true;
		}
	});
}

function setupCashbackSpecifics() {
	document.getElementById("tableCBRow").style.display = "inline-table";
	document.getElementById("codesListRow").style.display = "inline-table";
	document.getElementById("totalSavedMessage").style.display = "block";
	document.getElementById("bfrl_logo").style.display = "block";
}

function setupNoCashbackSpecifics() {
	document.getElementById("tableCBRow").style.display = "none";
	document.getElementById("codesListRow").style.display = "initial";
	document.getElementById("detailsTable").style.display = "none";
	document.getElementById("totalSavedMessage").style.display = "block";
	document.getElementById("codesNoCB").style.display = "inline-flex";
	document.getElementById("bfrl_logo").style.display = "block";
}

function setupNoWorkingCodesCBSpecifics(isGuest) {
	document.getElementById("noCodesWithCBMessage").style.display = "block";
	document.getElementById("youSaved").style.display = "none";
	document.getElementById("detailsTable").style.display = "none";
	document.getElementById("bfrl_logo").style.display = "block";

	if (!isGuest) {
		document.getElementById("bfrl_downloadAppGroup").style.display = "block";
		document.getElementById("bfrl_registerGroup").style.display = "none";
	}
	else {
		document.getElementById("bfrl_downloadAppGroup").style.display = "none";
		document.getElementById("bfrl_registerGroup").style.display = "block";
	}

	document.querySelector(".sidePanel_open").style.display = "block";
	document.querySelector(".sidePanel_close").style.display = "none";
	document.getElementById("bfrl_shareGroup").style.display = "none";
	document.querySelector("#bfrl_rightSection").style.display = "block";

	document.getElementById("bfrl_continueToCheckoutButton").style.margin = "40px 0 0 0";
}

function setupNoWorkingCodesNoCBSpecifics() {
	document.getElementById("detailsTable").style.display = "none";
	document.getElementById("noCodesFooter").style.display = "block";
	document.getElementById("youSaved").style.display = "none";
	document.getElementById("bfrl_logo").style.display = "block";
	document.getElementById("report_div").style.margin = "30px 0 0 0";
	document.getElementById("message_div").style.margin = "40px 0 0 0";

	document.getElementById("bfrl_downloadAppGroup").style.display = "block";
	document.getElementById("bfrl_registerGroup").style.display = "none";
	document.querySelector(".sidePanel_open").style.display = "block";
	document.querySelector(".sidePanel_close").style.display = "none";
	document.getElementById("bfrl_shareGroup").style.display = "none";
	document.querySelector("#bfrl_rightSection").style.display = "block";

	document.getElementById("bfrl_continueToCheckoutButton").style.margin = "20px 0 0 0";
	document.getElementById("report_div").style.margin = "70px 0 0 0";
}

function setupTryMore() {
	document.getElementById("tryMoreDiv").style.display = "flex";
	document.getElementById("bfrl_continueToCheckoutButton").style.margin = "20px 0px 0px";

	let tryMoreLink = document.getElementById("tryMoreCodes");
	tryMoreLink.addEventListener("click", function () {
		chrome.runtime.sendMessage({
			targetScript: "autoApplyApp.js",
			action: "testPrepareCoupons",
			data: {
				tryMore: true
			}
		}, function () {
			if (chrome.runtime.lastError) {
				console.debug(chrome.runtime.lastError.message);
			}
		});
	});
}

function DataTransfer(bonusCashback, bonusFriendGets, appliedCode, discount, cashbackrate, currentURL, redirectURL, rafToken, toolbarType, originalSubTotal, cbTerms, isGuest, subscribe, resultState, noUser, extraCodes) {

	isGuest = isGuest === "true"; //Convert to boolean for ease
	noUser = noUser === "true"; //Convert to boolean for ease
	extraCodes = extraCodes === "true";

	if (/true/i.test(isGuest)) {
		guestMode = true;
		document.getElementById("bfrl_shareGroup").style.display = "none";
		document.getElementById("bfrl_registerGroup").style.display = "block";
		document.getElementById("bfrl_leftSection").style.boxShadow = "none";
		document.getElementById("bfrl_chkSubscriber").checked = /true/i.test(subscribe);
        document.querySelector(".sidePanel_close").style.display = "none";
		//setUpBeFrugalRegister(subscribe === "true");
	}

	resultState = Number(resultState);
	switch (resultState) {
		case 0: //Succes, Share
			setupCashbackSpecifics();
			if (isGuest)
				setUpBeFrugalRegister(subscribe === "true", true);
			if (!noUser)
				setupShareSpecifics(isGuest, true);
			else {
				document.querySelector(".sidePanel_open").style.display = "none";
				document.querySelector(".sidePanel_close").style.display = "block";
			}
			break;
		case 1: //Success, Rate
			setupCashbackSpecifics();
			if (isGuest) {
				setUpBeFrugalRegister(subscribe === "true", false);
				document.getElementById("bfrl_rightSection").style.height = "550px";
				closeButton2.style.right = "-5px";

				chrome.runtime.sendMessage({
				targetScript: "autoApplyApp.js",
				action: "iframeResize",
				data: {
					newWidth: 736,
					centered: true,
					extraCodesLength: extraCodesLength
					}
				}, function () {
					if (chrome.runtime.lastError) {
						console.debug(chrome.runtime.lastError.message);
					}
				});
				sidePanelOpenFlag = true;
			}
			setupRateSpecifics(isGuest, true);
			break;
		case 2: //Success, No CB, Share
			if (!noUser)
				setupShareSpecifics(isGuest, false);
			else {
				document.querySelector(".sidePanel_open").style.display = "none";
				document.querySelector(".sidePanel_close").style.display = "block";
			}
				
			setupNoCashbackSpecifics();
			break;
		case 3: //Success, No CB, Rate
			setupNoCashbackSpecifics();
			setupRateSpecifics(isGuest, false);
			break;
		case 4: //No codes, CB
			setupNoWorkingCodesCBSpecifics(isGuest);
			if (isGuest)
				setUpBeFrugalRegister(subscribe === "true", false);
			if (extraCodes)
				setupTryMore();
			break;
		case 5: //No codes, No CB
			setupNoWorkingCodesNoCBSpecifics();
			if (extraCodes)
				setupTryMore();
			break;
	}


	cashbackTermsLink.cbTerms = cbTerms;
	cashbackTermsLink.addEventListener("click", _cashbackTermsHandler);
	cashbackTermsLinkNoCodes.addEventListener("click", _cashbackTermsHandler);
    var cashbackArr = cashbackrate.split(" ");
    var soloRate;
    var soloAmount;
    for (var i = 0; i < cashbackArr.length; i++) {
        if(cashbackArr[i].includes("%")){
            soloRate = cashbackArr[i].replace("%","");
        } if (cashbackArr[i].includes("$")) {
            soloAmount = cashbackArr[i].replace("$", "");
		}
	}
    if (discount === "" || discount == null) {
		discount = "$0.00";
    }
    if (discount.replace) {
		discount = discount.replace("-", "");
		discount = discount.replace("$", "");
		var numOriginalSubTotal = parseFloat(originalSubTotal);
		var numDiscount = parseFloat(discount.replace(",", ""));
		var amountToBeDiscounted = numOriginalSubTotal - numDiscount;
		var cashbackAmount = 0;
		if (soloRate) {
		    cashbackAmount = amountToBeDiscounted * (parseFloat(soloRate) / 100);
		}else if (soloAmount) {
		    cashbackAmount = parseFloat(soloAmount);
		}

		var totalSaved = parseFloat(discount.replace(",", "")) + parseFloat(cashbackAmount);

		//NOTE(Thompson): Converts floating points to USD currency format.
		totalSaved = "$" + totalSaved.toFixed(2).toString();
	}

	let codes = appliedCode ? appliedCode.split(",") : new Array(0);

	let andMoreNeeded = (codes.length > 3);
	if (andMoreNeeded)
		codes = codes.slice(0, 3);

	cashbackRateText.innerText = cashbackrate;
	cashbackRateText.style.fontSize = "15px";
	activatedSuffix.style.fontSize = "15px";
	if (cashbackrate.length > 17) {
		activatedSuffix.style.display = "none";
	}
	discountAmountBox.innerText = "$" + discount;
	if (cashbackAmount)
		cashbackAmountBox.innerText = (/up to/i.test(cashbackrate) ? "up to $" : "$") + cashbackAmount.toFixed(2);
	totalSavedData.innerText = totalSaved;
	totalSavedDataNoCodes.innerText = totalSaved;

	let child = appliedCodeText.lastElementChild;
	while (child) {
	    appliedCodeText.removeChild(child);
	    child = appliedCodeText.lastElementChild;
	}

	child = appliedCodeTextNoCB.lastElementChild;
	while (child) {
		appliedCodeTextNoCB.removeChild(child);
		child = appliedCodeTextNoCB.lastElementChild;
	}

	extraCodesLength = 0;
	for (let y = 0; y < codes.length && y < 3; y++) {
		let spn = document.createElement("span");
		spn.classList = "bfrl_couponCode_small bfrl_lightGray";
		spn.innerText += codes[y];
		appliedCodeText.appendChild(spn);
		let spn2 = document.createElement("span");
		spn2.classList = "bfrl_couponCode_small bfrl_lightGray";
		spn2.innerText += codes[y];
		appliedCodeTextNoCB.appendChild(spn2);
		extraCodesLength += codes[y].length;
	}

	if (codes.length > 1)
		codesText.innerText = "codes";
	else
		codesText.innerText = "code";

	//adjust line-height since possible 2 lines of codes
	if (codes.length > 2) {
		if (resultState == 0 || resultState == 1) {
			document.getElementById("bfrl_rightSection").style.height = "550px";

			chrome.runtime.sendMessage({
				targetScript: "autoApplyApp.js",
				action: "iframeResize",
				data: {
					extraCodesLength: extraCodesLength,
					centered: true,
					newWidth: isGuest ? 736 : 428
				}
			}, function () {
				if (chrome.runtime.lastError) {
					console.debug(chrome.runtime.lastError.message);
				}
			});
			if (isGuest)
				sidePanelOpenFlag = true;
		}
	}

	
	if (bonusCashback && bonusCashback.length > 0) {
		for (let i = 0; i < bonusCashbackRateTexts.length; i++) {
			bonusCashbackRateTexts[i].innerText = bonusCashback;
		}
	}
	else {
		for (let i = 0; i < bonusRemove.length; i++) {
			bonusRemove[i].style.display = "none";
		}
    }

	if (bonusFriendGets && bonusFriendGets.length > 0) {
		for (let i = 0; i < bonusCashbackRateTexts.length; i++) {
			bonusFriendGetsTexts[i].innerText = bonusFriendGets;
		}
	}

	let _appClick = function (evt) {
		chrome.runtime.sendMessage({
			targetScript: "autoApplyApp.js",
			action: "openAppTab"
		});
	}
	document.getElementById("bfrl_downloadAppGroup").addEventListener("click", _appClick);

	//NOTE(Thompson): Keep the commented code in, in case situations arise where we would really have to .
	if (discount.length > 10) {
		let newSize = 72;
		switch (discount.length) {
			case 11:
			case 12:
			case 13:
			case 14:
			case 15:
				newSize *= 0.9;
				break;
			case 16:
			case 17:
			case 18:
			case 19:
			case 20:
				newSize *= 0.8;
				break;
			case 21:
			case 22:
			case 23:
			case 24:
			case 25:
			case 26:
			case 27:
			case 28:
				newSize *= 0.7;
				break;
			default:
				newSize *= 0.6;
				break;
		}
		totalSavedData.style.fontSize = Math.round(newSize).toString() + "px";
		totalSavedDataNoCodes.style.fontSize = Math.round(newSize).toString() + "px";
	}
	else {
		totalSavedData.style.fontSize = "72px";
		totalSavedDataNoCodes.style.fontSize = "72px";
	}

	checkoutButton.addEventListener("click", function() {
		chrome.runtime.sendMessage({
			targetScript: "autoApplyApp.js",
			action: "iframeClose",
			data: {
				type: "7"
			}
		}, function () {
		    if (chrome.runtime.lastError) {
		        console.debug(chrome.runtime.lastError.message);
		    }
		});
	});

	document.getElementById("bfrl_leftSection").style.display = "block";
	document.getElementById("bfrl_rightSection").style.display = "block";
}

var resultUrlSearch = (function(input) {
	if (input === "")
		return {};
	var output = {};
	for (var i = 0; i < input.length; ++i) {
		var params = input[i].split('=', 2);
		if (params.length === 1)
			output[params[0]] = "";
		else
			output[params[0]] = decodeURIComponent(params[1].replace(/\+/g, " "));
	}
	return output;
})(window.location.search.substr(1).split('&'));

window.addEventListener("DOMContentLoaded", function(event) {
	DataTransfer(resultUrlSearch["bonusCashback"], resultUrlSearch['bonusFriendGets'], resultUrlSearch["appliedCode"], resultUrlSearch["discount"], resultUrlSearch["cashbackRate"], resultUrlSearch["currentURL"], resultUrlSearch["redirectUrl"], resultUrlSearch["RAFToken"], resultUrlSearch["ToolbarType"], resultUrlSearch["originalSubtotal"], resultUrlSearch["cbTerms"], resultUrlSearch["isGuest"], resultUrlSearch["subscribe"], resultUrlSearch["resultState"], resultUrlSearch["noUser"], resultUrlSearch["extraCodes"]);

	function closeHandler() {
		chrome.runtime.sendMessage({
			sourceScript: "couponsnotfound.js",
			targetScript: "autoApplyApp.js",
			intendedTargetScript: "autoApplyContent.js",
			action: "iframeClose",
			data: {
				type: "2"
			}
		}, function () {
		    if (chrome.runtime.lastError) {
		        console.debug(chrome.runtime.lastError.message);
		    }
		});
	}
	closeButton1.addEventListener("click", closeHandler);
	closeButton2.addEventListener("click", closeHandler);

	

	new Promise((resolve) => {
		setTimeout(function() {
			resolve();
		}, 60 * 1000);
	}).then(() => {
		//Should the Promise resolves, this prevents the Promise from resetting the coupon state by checking to see if the checkout button exists on the document.
		if (document.getElementById("bfrl_continueToCheckoutButton")) {
			chrome.runtime.sendMessage({
				targetScript: "autoApplyApp.js",
				action: "setCouponState",
				data: "PAGE_LOAD"
			}, function () {
			    if (chrome.runtime.lastError) {
			        console.debug(chrome.runtime.lastError.message);
			    }
			});
		}
		return;
	}).catch((e) => {
		console.debug("(couponsResultRate.js) Error - ", e);
	});

	reportProblem.addEventListener("click", function() {
		chrome.runtime.sendMessage({
			targetScript: "autoApplyApp.js",
			action: "iframeReportSetURL",
			data: "AutoApplyResources/report/reportProblem.html"
		}, function () {
		    if (chrome.runtime.lastError) {
		        console.debug(chrome.runtime.lastError.message);
		    }
		});
	});
});
