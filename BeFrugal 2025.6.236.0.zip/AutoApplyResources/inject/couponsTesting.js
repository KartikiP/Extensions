var progressBar = document.getElementById("bfrl_progressBar");
var completionBar = document.getElementById("bfrl_completionBar");
completionBar.style.width = "0";
completionBar.style.height = "48px";
completionBar.style.backgroundColor = "#F9591E";
var count = 0;
var output = document.getElementById("bfrl_output");
var codeString = document.getElementById("bfrl_couponCodeString");
var reportProblem = document.getElementById("bfrl_reportProblem");
var closeButton = document.getElementById("bfrl_closeButton");

let befrugalLogoImage = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADAAAAAwCAYAAABXAvmHAAAACXBIWXMAAAsTAAALEwEAmpwYAAAKT2lDQ1BQaG90b3Nob3AgSUNDIHByb2ZpbGUAAHjanVNnVFPpFj333vRCS4iAlEtvUhUIIFJCi4AUkSYqIQkQSoghodkVUcERRUUEG8igiAOOjoCMFVEsDIoK2AfkIaKOg6OIisr74Xuja9a89+bN/rXXPues852zzwfACAyWSDNRNYAMqUIeEeCDx8TG4eQuQIEKJHAAEAizZCFz/SMBAPh+PDwrIsAHvgABeNMLCADATZvAMByH/w/qQplcAYCEAcB0kThLCIAUAEB6jkKmAEBGAYCdmCZTAKAEAGDLY2LjAFAtAGAnf+bTAICd+Jl7AQBblCEVAaCRACATZYhEAGg7AKzPVopFAFgwABRmS8Q5ANgtADBJV2ZIALC3AMDOEAuyAAgMADBRiIUpAAR7AGDIIyN4AISZABRG8lc88SuuEOcqAAB4mbI8uSQ5RYFbCC1xB1dXLh4ozkkXKxQ2YQJhmkAuwnmZGTKBNA/g88wAAKCRFRHgg/P9eM4Ors7ONo62Dl8t6r8G/yJiYuP+5c+rcEAAAOF0ftH+LC+zGoA7BoBt/qIl7gRoXgugdfeLZrIPQLUAoOnaV/Nw+H48PEWhkLnZ2eXk5NhKxEJbYcpXff5nwl/AV/1s+X48/Pf14L7iJIEyXYFHBPjgwsz0TKUcz5IJhGLc5o9H/LcL//wd0yLESWK5WCoU41EScY5EmozzMqUiiUKSKcUl0v9k4t8s+wM+3zUAsGo+AXuRLahdYwP2SycQWHTA4vcAAPK7b8HUKAgDgGiD4c93/+8//UegJQCAZkmScQAAXkQkLlTKsz/HCAAARKCBKrBBG/TBGCzABhzBBdzBC/xgNoRCJMTCQhBCCmSAHHJgKayCQiiGzbAdKmAv1EAdNMBRaIaTcA4uwlW4Dj1wD/phCJ7BKLyBCQRByAgTYSHaiAFiilgjjggXmYX4IcFIBBKLJCDJiBRRIkuRNUgxUopUIFVIHfI9cgI5h1xGupE7yAAygvyGvEcxlIGyUT3UDLVDuag3GoRGogvQZHQxmo8WoJvQcrQaPYw2oefQq2gP2o8+Q8cwwOgYBzPEbDAuxsNCsTgsCZNjy7EirAyrxhqwVqwDu4n1Y8+xdwQSgUXACTYEd0IgYR5BSFhMWE7YSKggHCQ0EdoJNwkDhFHCJyKTqEu0JroR+cQYYjIxh1hILCPWEo8TLxB7iEPENyQSiUMyJ7mQAkmxpFTSEtJG0m5SI+ksqZs0SBojk8naZGuyBzmULCAryIXkneTD5DPkG+Qh8lsKnWJAcaT4U+IoUspqShnlEOU05QZlmDJBVaOaUt2ooVQRNY9aQq2htlKvUYeoEzR1mjnNgxZJS6WtopXTGmgXaPdpr+h0uhHdlR5Ol9BX0svpR+iX6AP0dwwNhhWDx4hnKBmbGAcYZxl3GK+YTKYZ04sZx1QwNzHrmOeZD5lvVVgqtip8FZHKCpVKlSaVGyovVKmqpqreqgtV81XLVI+pXlN9rkZVM1PjqQnUlqtVqp1Q61MbU2epO6iHqmeob1Q/pH5Z/YkGWcNMw09DpFGgsV/jvMYgC2MZs3gsIWsNq4Z1gTXEJrHN2Xx2KruY/R27iz2qqaE5QzNKM1ezUvOUZj8H45hx+Jx0TgnnKKeX836K3hTvKeIpG6Y0TLkxZVxrqpaXllirSKtRq0frvTau7aedpr1Fu1n7gQ5Bx0onXCdHZ4/OBZ3nU9lT3acKpxZNPTr1ri6qa6UbobtEd79up+6Ynr5egJ5Mb6feeb3n+hx9L/1U/W36p/VHDFgGswwkBtsMzhg8xTVxbzwdL8fb8VFDXcNAQ6VhlWGX4YSRudE8o9VGjUYPjGnGXOMk423GbcajJgYmISZLTepN7ppSTbmmKaY7TDtMx83MzaLN1pk1mz0x1zLnm+eb15vft2BaeFostqi2uGVJsuRaplnutrxuhVo5WaVYVVpds0atna0l1rutu6cRp7lOk06rntZnw7Dxtsm2qbcZsOXYBtuutm22fWFnYhdnt8Wuw+6TvZN9un2N/T0HDYfZDqsdWh1+c7RyFDpWOt6azpzuP33F9JbpL2dYzxDP2DPjthPLKcRpnVOb00dnF2e5c4PziIuJS4LLLpc+Lpsbxt3IveRKdPVxXeF60vWdm7Obwu2o26/uNu5p7ofcn8w0nymeWTNz0MPIQ+BR5dE/C5+VMGvfrH5PQ0+BZ7XnIy9jL5FXrdewt6V3qvdh7xc+9j5yn+M+4zw33jLeWV/MN8C3yLfLT8Nvnl+F30N/I/9k/3r/0QCngCUBZwOJgUGBWwL7+Hp8Ib+OPzrbZfay2e1BjKC5QRVBj4KtguXBrSFoyOyQrSH355jOkc5pDoVQfujW0Adh5mGLw34MJ4WHhVeGP45wiFga0TGXNXfR3ENz30T6RJZE3ptnMU85ry1KNSo+qi5qPNo3ujS6P8YuZlnM1VidWElsSxw5LiquNm5svt/87fOH4p3iC+N7F5gvyF1weaHOwvSFpxapLhIsOpZATIhOOJTwQRAqqBaMJfITdyWOCnnCHcJnIi/RNtGI2ENcKh5O8kgqTXqS7JG8NXkkxTOlLOW5hCepkLxMDUzdmzqeFpp2IG0yPTq9MYOSkZBxQqohTZO2Z+pn5mZ2y6xlhbL+xW6Lty8elQfJa7OQrAVZLQq2QqboVFoo1yoHsmdlV2a/zYnKOZarnivN7cyzytuQN5zvn//tEsIS4ZK2pYZLVy0dWOa9rGo5sjxxedsK4xUFK4ZWBqw8uIq2Km3VT6vtV5eufr0mek1rgV7ByoLBtQFr6wtVCuWFfevc1+1dT1gvWd+1YfqGnRs+FYmKrhTbF5cVf9go3HjlG4dvyr+Z3JS0qavEuWTPZtJm6ebeLZ5bDpaql+aXDm4N2dq0Dd9WtO319kXbL5fNKNu7g7ZDuaO/PLi8ZafJzs07P1SkVPRU+lQ27tLdtWHX+G7R7ht7vPY07NXbW7z3/T7JvttVAVVN1WbVZftJ+7P3P66Jqun4lvttXa1ObXHtxwPSA/0HIw6217nU1R3SPVRSj9Yr60cOxx++/p3vdy0NNg1VjZzG4iNwRHnk6fcJ3/ceDTradox7rOEH0x92HWcdL2pCmvKaRptTmvtbYlu6T8w+0dbq3nr8R9sfD5w0PFl5SvNUyWna6YLTk2fyz4ydlZ19fi753GDborZ752PO32oPb++6EHTh0kX/i+c7vDvOXPK4dPKy2+UTV7hXmq86X23qdOo8/pPTT8e7nLuarrlca7nuer21e2b36RueN87d9L158Rb/1tWeOT3dvfN6b/fF9/XfFt1+cif9zsu72Xcn7q28T7xf9EDtQdlD3YfVP1v+3Njv3H9qwHeg89HcR/cGhYPP/pH1jw9DBY+Zj8uGDYbrnjg+OTniP3L96fynQ89kzyaeF/6i/suuFxYvfvjV69fO0ZjRoZfyl5O/bXyl/erA6xmv28bCxh6+yXgzMV70VvvtwXfcdx3vo98PT+R8IH8o/2j5sfVT0Kf7kxmTk/8EA5jz/GMzLdsAAAAgY0hSTQAAeiUAAICDAAD5/wAAgOkAAHUwAADqYAAAOpgAABdvkl/FRgAACghJREFUeNrsmluMXVUZx39r7du5zXSGtkxv08tAqwVaUgRFI5qIgCLBYqLG+GCiMQY1xmhMMIgx6ItGwZDw5IMoaiKJBqJIRC3BECS2IoVA2xRa2tLS6cx0zpwzs8/ZZ++1lw/f2nPO9DpDC5WElUzmXNas/V3+/++2RllreTsvzdt8vaPAhV4+f/gVrFwDSQuSGFotaMcw3YR4Bkx29lM8L8L316PVRjxvDcZcAXaELF+GoorNNZCSqzqaQ8BLoPYAr6LYRZYdJj8NFwMfKlUoVSAqQ7kCqB4FwlIZrfuAKSBZoAE2AreSpVfTbl3HxMQQhw7DkSNiBJO6Z2kINETRMKXyJsqlm+mrweBSWLz4v1Srz6C9J8ntX4H6QgRQ9muf/jE33HoTy1fNUJ94glbrQdrxnrN4YDPwdeCjRNE6u30H+S8fxjrbaECFQB9QCaFSgb4+qFahXAY/gNCT376GdRtgaGWKyXYCvwZ+CxyfjweU/eDwHpav2sAnPgfDa6FRH6UV30c8fR/xzPQJCqwFvgp8GRhw8IHGFPapp2DRAGp4FfQPQDmS77wAPED58lwLkMtpJodOh9lzZFngOeAnwCMEfuvMCnzs8knayQB9/XDTVli5Fpp1SJKHSOJvkmavu72fAb4PXH4KDkCtCrmBzIAxIhyAzZnFt3YPzk8IIflpc9GDBP59VKo7KVXSUytw85XTBGGVNIFaH3zoRli0GBp1MNnvMeY7wGeBHwDV04LROqlUb2BTXaNa0/1MLSD4aXWISu1ZqrUHiMqPUa4kcxXYes0Ynr8EP4Q0gSVLYfPV8qA0zYHdwKVAuCB6GyOWXrMO+gchnobJcaiPO7gsSAnoH5xmYPGDRNEdoBrdPBBGBwkjCELo64dWGw7tL9yqgcvmL7wST5hUwnJzEhqTsGgAlq+A9ZfB0LDjwQKNUZ+skbRuR/l344eOWwGaMNpOFEIQQBQJ4+MZCYNdYs1P+CyTXBLPQJJApwWv7IHR18QwaQcuXiaENOkCjtZgMzj2OqTJFwnD6wlDCEM0UbQTP4KwBH4JohA8H1rxwlyctmCmLoK2Y2jNiEKNSTh0UMidJBKWvWDhRYDyxKvHjvSh1G0EAQQBGj98gajUIHIeCCOISvJ6IStHLNxsiqBJG9oJxDGMH4VOIlDIsnOoG3wxyPhoP9oDCz5++Cyhvw3tbSXwAU8ST7kmD5yX8FaU9peAHYfxMdEot6LI5Di0piEM5cwiYr2h0i2Hwwc2MDm2BjigKUUxYfQYUTklLEmmrPR1oaHV/M8PSzC0ApYuEyjNNCBLoD4B0425MHqjZaTSkCXvYXLiBhp1NNU+iEoPE0UvEAZCYk9jFXSCCKv0qS2mlZC8V8HCY8tXwtoRSByk4hjaLTAdUciYOclo4Up4Pn7wKZRerLEWUMfw/XsJy9OSVSts2/sy195xN0/vOwDV2klJy3oethy5CHECnEwGy1bC+ndDuw1ZKns6mXjAGs7D2gRcpSlVBDZB+CeCcDtKg8npDyMuHeinFgQne6BaYcfL+9n8je/xzL4DEAUncyLLYHgdrFsvgcELJIq0WvK9OudWpAZ8wKdWLR4aAUsAaLW5Zt1qHrrrW9BJxWra6xLTWMq+x/CifkJ1BmJ7wLuugPpxyNpg7Pz6i/mtPuAjyt57V/HBauA5rBmUJNQBjLje9114LQvuC6z7nhAzt2fOEbMF3HkfIBz0JfUbsHYLxpRIE7BKhO9kjoAxdNpQXSS10sBF8udnE/7Mleb5WDXfvbiFPL+fUlSmf8AltFAihXHEO3oE9u+BsSMSJldf4vYYLuDyfGAjnr6HqLxSaqJI3K480D6UajAYSN88sh62PwUHXpF657LN4IXSB1yYlWmUvg0vXC+6qK5Fi87Jmi7xlg3DjVulBXztVdi7W/ZcmNmGlUwM70cpJ7uB0cOQpkJc5bqtJIGJUeFCpQbX3wJLV4gnJselXXzrVxN4XM92WV4gsXv0GKQGPNeeh5GUArufhzyVpHTxctjyPqlzjh2Ft2o8WQScLIW00yBpb/PR6jWpeYCsI3W65won7RJYPCN1jXUeSTvCiTCCyYk3l8hFT10Ibxys83wHWm/XKL1dPKBlQ+h6A5tLtlQIdKKafA4SZv2wq9C51DWntXIH0rYry1uuz2hL35HEKWn6EFD30fpRtP4Kub2cap8QNAxFa1+JcHkOg0skQgGEAcQN8cTQMlEizxZOQdUjsLXyHJO70sW4zN37nXFBJf87nnoUk+ID+0DdibUPUK4MEEayOQC088rqS6BUksODsnjmP0/LsGpoeGHJqoBEbuQ5s9BwfUJe7CkiYO8+CzAG/AzlNchFAYBHQH0J+BFptnEOLKwV0oahyw0KnvwLHNwHW94r5XeantnShTDWdoXFWTXPXH3Vg2+k3nJYd7/dICyefpww/EfRr/fGvz8CL6H1F9DqBrRegVJDeJ4my6QlTGLYuwte3Q9XXQuDF0mxd1orp46AtseSplvUFfsKmFinRF7ApsdTGJiJ4fj4/l64nhjAd5PzXXx+juevJetcx/Gx20k7I8w0u43+piuFxEniKlRn6llYOAFzB4tZy9vuZwXWc9OD8+IMV0QW3+VWFJhuZlg7ilKnVaBYo2g1ShzvYGJsC5oRmRsNCi9yIz1ucXBqRZHMOPLhIJD1WL0gp5U8MwuVXPalefc9jgNpJud5YTGG8VEqdnH+dAq4VnFqCibGQrQXkrqpuw4E7yafCwlruxEj7xEkz7pYL0g6J5bbHm/0eC/NJIyGoWR+gFYK8DpaPz/3guOkhrkFY7HEXHKNokKWQbMho+7ADelSIwLOJhrThQkFLOjiuRsCu1a2PeTNHZw6HVG6f5GEbmMhbgLsBL4N7DhBAUeyHJiadBPm1CUoLyK3AyhPBJ2qy8PCAPxIsncnFWFmJ9IFgQsB0y62TcGVtAspayWfdDqgbUb/RT7LV0GpKgOAZrMJ/Aa4B3j55CumYj6ftOaOy52dgdHu1FlLJJo6Lu8rlSZaxRgzJJZ2ZWmedznR66H8hFBaKKj0GAODu1i+6ncMrVxMnn+cmWnIzIvusuMZJ8sp7sjOXvHdCUwAn0SzdLZ0jqdg7MhOVo/8kCVDP6U+tYmZJph2T7Shm0ULjGe5K8/zw8AOOsmLrFj7BJds+BdKz1AqQ7N5rxiB9tn60PnUwbuA24FfuBuaQRQl8BLarZdYNPBPVgwfpVrbRGMKmtPCo1bLDbGMQCTL/gY8gjXHgUngGLAXSxOtBFKeLSYgrfnfUs6z8wH+7X66Q6xyDap9AcaMoJU0/cZCoiD3JOS2Y0gxkP8ZuP//457YWpliX/thaWzSbOcszmc9PmeW5CHV1ZtwT/xGlsnl0mLpMilt5dLvMeDzbmJWdZpkwH5gm9RbgFLntQFS7/yzxzsKnNv63wBSnF10gndMhwAAAABJRU5ErkJggg==";
var logoArea = document.querySelector("#bfrl_logo");
if (logoArea) {
	logoArea.src = befrugalLogoImage;
}

var couponTestingUrlSearch = (function(input) {
	if (input === "")
		return {};
	var output = {};
	for (var i = 0; i < input.length; ++i) {
		var params = input[i].split('=', 2);
		if (params.length === 1)
			output[params[0]] = "";
		else
			output[params[0]] = decodeURIComponent(params[1].replace(/\+/g, " "));
	}
	return output;
})(window.location.search.substr(1).split('&'));


window.addEventListener("DOMContentLoaded", function (event) {
	switch (couponTestingUrlSearch["action"]) {
		case "updateProgress":
			try {
				completionBar.style.width = ((parseInt(couponTestingUrlSearch["index"]) / parseInt(couponTestingUrlSearch["total"])) * 100).toString() + "%";
				completionBar.style.height = "48px";
				output.innerText = "Trying code " + couponTestingUrlSearch["index"];
				codeString.innerText = couponTestingUrlSearch["code"];
				chrome.runtime.sendMessage({
					targetScript: "autoApplyApp.js",
					action: "applyCouponBackground_testApplyCoupon"
				}, function () {
					if (chrome.runtime.lastError) {
						console.debug(chrome.runtime.lastError.message);
					}
				});
			}
			catch (e) {
				console.debug("(couponsTesting.js) Error -", e);
			}
			break;
		case "prepareProgress":
			try {
				completionBar.style.width = "0%";
				completionBar.style.height = "48px";
				output.innerText = "Preparing...  ";
				codeString.innerText = couponTestingUrlSearch["data"];
			}
			catch (e) {
				console.debug(e);
			}
			break;
		case "output":
			output.innerText = couponTestingUrlSearch["text"];
			break;
		case "applyingMax":
			let maxComboCount = false;
			/*			let maxComboCount = couponTestingUrlSearch["maxComboCount"];*/
			output.innerText = maxComboCount ? `Calculating maximum savings.\nTesting coupon combo ${maxComboCount}` : "Calculating maximum savings.";
			codeString.style.display = "none";
			break;
	}

	closeButton.addEventListener("click", function() {
		chrome.runtime.sendMessage({
			targetScript: "autoApplyApp.js",
			sourceScript: "couponsTesting.js",
			action: "iframeClose",
			data: { type: "7" }
		}, function () {
			if (chrome.runtime.lastError) {
				console.debug(chrome.runtime.lastError.message);
			}
		});
	});

	reportProblem.addEventListener("click", function() {
		chrome.runtime.sendMessage({
			targetScript: "autoApplyApp.js",
			action: "iframeReportSetURL",
			data: "AutoApplyResources/report/reportProblem.html",
			couponsTesting: true
		}, function () {
			if (chrome.runtime.lastError) {
				console.debug(chrome.runtime.lastError.message);
			}
		});
	});
});
//Why do we have both?  initial load.
var adjustProgress = function (event, sender, sendResponse) {
	if (event.action == 'iframeAdjustProgress') {
		switch (event.message.action) {
			case "updateProgress":
				try {
					completionBar.style.width = ((parseInt(event.message.index) / parseInt(event.message.total)) * 100).toString() + "%";
					completionBar.style.height = "48px";
					output.innerText = "Trying code " + event.message.index;
					codeString.innerText = decodeURIComponent(event.message.code);
					chrome.runtime.sendMessage({
						targetScript: "autoApplyApp.js",
						action: "applyCouponBackground_testApplyCoupon"
					}, function () {
						if (chrome.runtime.lastError) {
							console.debug(chrome.runtime.lastError.message);
						}
					});
				}
				catch (e) {
					console.debug("(couponsTesting.js) Error -", e);
				}
				break;
			case "prepareProgress":
				try {
					completionBar.style.width = "0%";
					completionBar.style.height = "48px";
					output.innerText = "Preparing...  ";
					codeString.innerText = event.message.data;
				}
				catch (e) {
					console.error(e);
				}
				break;
			case "applyingMax":
				let maxComboCount = false;
				/*				let maxComboCount = event.message.maxComboCount;*/
				output.innerText = maxComboCount ? `Calculating maximum savings\nTesting combination ${maxComboCount}` : "Calculating maximum savings";
				codeString.style.display = "none";
				break;
			case "output":
				output.innerText = event.message.text;
				break;
		}
		sendResponse();
		return true;
	} else {
		return false;
	}
};

try{
	chrome.runtime.onMessage.addListener(adjustProgress);
} catch (e) {
	try {
		browser.runtime.onMessage.addListener(adjustProgress);
	} catch (e) { }
}