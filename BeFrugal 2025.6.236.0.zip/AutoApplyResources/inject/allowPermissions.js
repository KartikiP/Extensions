﻿window.addEventListener("DOMContentLoaded", function (event) {
	chrome.runtime.sendMessage({
		targetScript: "autoApplyApp.js",
		action: "iframeRestyle",
		newProperties: {
			backgroundColor: "",
			boxShadow: "",
		}
	}, function () {
		if (chrome.runtime.lastError) {
			console.debug(chrome.runtime.lastError.message);
		}

		document.getElementById("clickHereArrow").src = chrome.runtime.getURL("AutoApplyResources/inject/img/arrow_03.png");
	});
})

function closePopup() {
	chrome.runtime.sendMessage({
		targetScript: "autoApplyApp.js",
		sourceScript: "allowPermissions.js",
		action: "iframeClose",
		data: { type: "6" }
	});
}