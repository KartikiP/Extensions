function getClassicCookie() {
	var value = "; " + document.cookie;
	var parts = value.split("; " + "ToolbarPage.WelcomePageStyle" + "=");
	var isClassic = false;
	var isNoTour = false;

	if (parts.length == 2) {
		let cookieVal = parts.pop().split(";").shift();
		if (cookieVal != null) {
			isClassic = true;
			let parsed = JSON.parse(decodeURIComponent(cookieVal));
			if (parsed != null && parsed.PageStyleType && parsed.PageStyleType === "Tourless")
				isNoTour = true;
		}
	}

	return {
		Classic: isClassic && (!localStorage["ButtonLpDownloadFlow"] || localStorage["ButtonLpDownloadFlow"] === "false"),
		NoTour: isNoTour
	}
}

getClassicCookie();