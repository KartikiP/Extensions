var dependenciesObj = {};
dependenciesObj.jQuery = (typeof jQuery === 'undefined');
dependenciesObj.DOMPurify = (typeof DOMPurify === 'undefined');
dependenciesObj.NotifyBar = (typeof NotifyBarSettings === 'undefined');
dependenciesObj