var startX;
var startY;
var curW;
var curH;
var divHeight = document.body.clientHeight;
var divWidth = document.body.clientWidth;
var toolbarVersion;
var userToken;

let dvpopup = document.createElement("div");
dvpopup.id = "popupDiv";
dvpopup.style = "height:100%;width:100%;z-index:2000;position:fixed;top:0px;left:0px;display:none;background:rgba(50,50,50,0.7)";
let iframepop = document.createElement("iframe");
iframepop.id = "popupFrame";
iframepop.src = chrome.runtime.getURL("ratepopup/popup-loveus.html");
iframepop.style = "display:block;margin: auto; border: none;width:100%; height: 100%";
dvpopup.appendChild(iframepop);
document.body.insertAdjacentElement("afterbegin", dvpopup);

//Firefox doesn't seem to notice what's going on in a hidden div, so we wait x seconds and set the div to block anyways.
setTimeout(function () {
    document.getElementById('popupDiv').style.display='block';
},1000);

function _SendBgScriptMessage(backgroundScriptName, action, data, callback) {
	let alldata = !data ? "" : data;
	if (isChrome) {
		window.namespace.runtime.sendMessage({
			targetScript: backgroundScriptName,
			action: action,
			data: alldata
		}, function (response) {
			if (callback) callback(response);
		});
	}
	else {
		window.namespace.runtime.sendMessage({
			targetScript: backgroundScriptName,
			action: action,
			data: alldata
		}).then(function (response) {
			if (callback) callback(response);
		});
	}
}

window.addEventListener("message", function(event) {
	if (event.data === "close") {
		dvpopup.parentNode.removeChild(dvpopup);
	}
	else if (event.data.indexOf("alldone") !== -1) {
		var dataSplit = event.data.split("$$");
		var feedback = dataSplit[1];
		var userEmail = dataSplit[2];

		let iframeAllDone = document.createElement("iframe");
		iframeAllDone.id = "popupFrameAllDone";
		iframeAllDone.src = chrome.runtime.getURL("ratepopup/popup-alldone.html");
		iframeAllDone.style = "position: fixed;top: 17px;left: calc(50% - 235px);width: 571px;height: 100%; border: none;";
		document.getElementById("popupDiv").appendChild(iframeAllDone);
		dvpopup.removeChild(iframepop);

		_SendBgScriptMessage("autoApplyApp.js", "sendFeedback", { email: userEmail, body: feedback, from: "RateUs" });
	}
	else if (event.data.startsWith("setPref")) {
		chrome.runtime.sendMessage("kcdcneeneoifbeenbbnjodcflhdbaggp", event.data);
		chrome.runtime.sendMessage("nlnfijkcnmdgbdeomehkhhlonpffgfbj", event.data);
	}
	else {
	    var args = event.data.split(",");
	    if (args.length === 3 && args[0] === "SIZE") {
		    var frame = document.getElementById("popupFrame");
			if (frame) {
				frame.width = (args[1] * 1) + 6 + "px";
				frame.height = (args[2] * 1) + 6 + "px";
				frame.style.display = "block";
				frame.style.margin = "margin: auto;"
				frame.style.height = "100%";
				document.getElementById("popupDiv").style.display = "block";
			}
		}
	}
});


chrome.runtime.onMessage.addListener(function (request, sender, sendResponse) {
	if (!request.targetScript || (request.targetScript && request.targetScript !== "generateRatePopup.js")) {
		return false;
	}
	switch (request.action) {
		case "setRateUs":
			toolbarVersion = request.data.toolbarVersion;
			userToken = request.data.userToken;
			return true;
	}
	return false;
});