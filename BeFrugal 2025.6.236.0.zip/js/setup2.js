let thismatch = document.cookie.match(new RegExp('(^| )' + "ToolbarPage.WelcomePageStyle" + '=([^;]+)'));
if (thismatch)
    thismatch[2];
else false