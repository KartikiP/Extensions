var BfrlTool = BfrlTool || {};
BfrlTool._RetailerList = {
	_AddRetailer: function (digest, url, properties, retailerID) {
		digest.RetailerIDs.push(retailerID);

		if (!digest.RetailerMap[url]) {
			//The URL in the properties from the digest may have HTTP and not HTTPS. Replace HTTP with HTTPS
			if ("URL" in properties) {
				let newProperties = [Object.assign({}, properties)];
				properties.URL = properties.URL.replace(/https?\:\/\//i, "");
				newProperties.push(properties);
				properties = newProperties;
			}

			digest.RetailerMap[url] = properties;
		}
		else if (properties && properties.URL) {
			//Append the new properties of the matching url key to the existing url key as an array.
			//Detecting the value of the matching url key as an array should be easier to filter out which retailer matches
			//the full URL appropriately when getting the retailer.
			let existingProperties = digest.RetailerMap[url];
			if (!Array.isArray(existingProperties)) {
				if (!existingProperties.URL) {
				    existingProperties.URL = existingProperties.Domain;
				}
				existingProperties = [existingProperties];
			}

			//The URL in the properties from the digest may have HTTP and not HTTPS. Replace HTTP with HTTPS
			existingProperties.push(Object.assign({}, properties));
			properties.URL = properties.URL.replace(/https?\:\/\//i, "");
			existingProperties.push(properties);
			existingProperties.sort((left, right) => {
				return left.URL.length - right.URL.length || left.URL.localeCompare(right.URL);
			});
			digest.RetailerMap[url] = existingProperties;
		}
	},
	_GetRetailer: function (digest, url) {
		if (!digest.RetailerMap) return null;
		let retailer = digest.RetailerMap[url];
		if (retailer != null) {
			return retailer;
		}
		else
			return BfrlTool._RetailerList._GetRestaurant(digest, url);
	},
	_GetRetailerById: function (digest, retailerID) {
		if (!digest || !digest.RetailerMap) return null;
		let digestFound = Object.keys(digest.RetailerMap).filter(s => {
			let entry = digest.RetailerMap[s];
			if (Array.isArray(entry)) {
				for (let q = 0; q < entry.length; q++) {
					if (entry[q].RetailerID === retailerID) return true;
				}
				return false;
			}
			else {
				return entry.RetailerID == retailerID;
			}
		});
		if (digestFound) {
			let entry = digest.RetailerMap[digestFound];
			if (Array.isArray(entry)) {
				for (let q = 0; q < entry.length; q++) {
					if (entry[q].RetailerID === retailerID)
						return entry[q];
				}
            }
			else return entry;
		}
		else return null;
	},
	_AddRestaurant: function (digest, url, properties, retailerID) {
		digest.RestaurantIDs.push(retailerID);
		digest.RestaurantMap[url] = properties;
	},
	_GetRestaurant: function (digest, url) {
		if (!digest.RestaurantMap) return null;
		let restaurant = digest.RestaurantMap[url];
		if (restaurant != null)
			return restaurant;
		return null;
	},
	_ContainsRetailer: function (digest, retailerID) {
		return (digest.RetailerIDs.indexOf(retailerID) >= 0);
	},
	_ContainsRestaurant: function (digest, retailerID) {
		return (digest.RestaurantIDs.indexOf(retailerID) >= 0);
	}
};
