
chrome.webRequest.onBeforeRequest.addListener(function onBeforeRequest(details) {
	shoptoolbar._AutoRedirectFlow(details);
}, {
	urls: ["*://*/*"]
});

chrome.webRequest.onBeforeSendHeaders.addListener(function onBeforeSendHeaders(details) {
	if (details && details.type == "main_frame") {
		Promise.all([BfrlTool.BrowserStorage.Settings, BfrlTool.BrowserStorage.IsClassic, BfrlTool.BrowserStorage.TourInfo]).then(function ([settings, isClassic, tourInfo]) {
			let befrugalsite = new RegExp(/^([^(r\.)](.*\.))?befrugal.com$/i);
			let parsedUrl = parseUriWrapper.CleanUrl(details.url);
			if (befrugalsite.test(parsedUrl)) {
				let installCompletePage = new RegExp("installationcomplete", "i");
				if (installCompletePage.test(details.url)) {
					browserAdapter.GetAllTabs(function (tabs) {
						let regex = new RegExp("(chrome|chromewebstore).google.com/(webstore|detail).*/(logldmlncddmdfcjaaljjjkajcnacigc||pcoojlbcellolmkdcoilhdolbaemmpmc)", "i");
						let foundTabs = tabs.filter(s => regex.test(s.url));
						for (let q = 0; q < foundTabs.length; q++) {
							browserAdapter.CloseTab(foundTabs[q].id);
						}
					});
					if (!isClassic || (tourInfo && tourInfo.NoTour)) {
						BfrlTool.BrowserStorage.TourShown = "shown";
					}
					else {
						BfrlTool.BrowserStorage.BeFrugalInstallTabs.then(function (befrugalInstallTabs) {
							befrugalInstallTabs.push(details.tabId);
							BfrlTool.BrowserStorage.BeFrugalInstallTabs = befrugalInstallTabs;
						});
					}
					if (isClassic && settings && settings.Config && (settings.Config.UpdateRequired || settings.Config.DailyUpdateReminder)) {
						if (shoptoolbar._Browser === shoptoolbar.Browsers.Chrome) {
							//log the update
							Promise.all([BfrlTool.BrowserStorage.UserToken, shoptoolbar.ToolbarVersionPromise]).then(function ([userToken, toolbarVersion]) {
								let url = shoptoolbar.APISite + '/wssimple.asmx/SendCriticalUpdateSuccess';
								shoptoolbar.FetchJsonPost(url, {
									method: "POST",
									headers: {
										'Content-Type': 'application/x-www-form-urlencoded'
									},
									body: shoptoolbar.Format("&UserToken={0}&toolbarversion={1}", userToken, toolbarVersion)
								}).then(() => {
									if (settings.Config.UpdateRequired && (!isClassic || shoptoolbar._IsBF)) {
										chrome.runtime.setUninstallURL("", function () { chrome.management.uninstallSelf(); });
									}
									else {
										settings.Config.UpdateRequired = false;
										settings.Config.DailyUpdateReminder = false;
										BfrlTool.BrowserStorage.Settings = settings;
									}
								});
							});
						}
					}
				}

				//installCompletePage = new RegExp("befrugal.com/toolbar/dropdownmenu/installed.html\\?rwdin", "i");
				//if (installCompletePage.test(details.url) && tourInfo && tourInfo.RewardsFlow && tourInfo.RewardsFlow.ButtonTabId && tourInfo.RewardsFlow.ButtonTabId !== 0) {
				//	browserAdapter._SendTabMessage(tourInfo.RewardsFlow.ButtonTabId, {
				//		action: 'rewardsDialog',
				//		targetScript: 'rewardsDialog.js',
				//		data: decodeURIComponent(details.url.split("?rwdin=")[1])
				//	});
				//	browserAdapter.CloseTab(details.tabId);
				//	browserAdapter.ActivateTab(tourInfo.RewardsFlow.ButtonTabId);
				//	//tourInfo.RewardsFlow.RewardsTabId = 0;
				//	//tourInfo.RewardsFlow.ButtonTabId = 0;
				//	//BfrlTool.BrowserStorage.TourInfo = tourInfo;
				//	return;
				//}
			}
			else if (isClassic && settings && settings.Config && !settings.Config.UpdateRequired && /surveymonkey\.com\/r\/78NXQF9$/i.test(details.url)) {
				let url = shoptoolbar.APISite + '/wssimple.asmx/RemoveToolbarCookies';
				shoptoolbar.FetchJsonPost(url, {
					method: "POST",
					headers: {
						'Content-Type': 'application/x-www-form-urlencoded'
					},
					body: 'UserToken=&toolbarversion=&addonType=BeFrugalButton'
				}).then((json) => {
					if (json) shoptoolbar._GetApplicationSettings(true);
				});
			}
		});
	}
}, {
	urls: ["*://*/*"]
}, ["requestHeaders"]);

