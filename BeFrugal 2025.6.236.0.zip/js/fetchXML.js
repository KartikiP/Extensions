chrome.runtime.onMessage.addListener(function (request, sender, sendResponse) {
	if (!request.targetScript || (request.targetScript && request.targetScript !== "fetchXML.js")) {
		return false;
	}

	let GetNodeFactory = function (xmlDoc) {
		return function (xpath) {
			var tmp = xmlDoc.evaluate(xpath, xmlDoc.documentElement, function () {
				return 'http://tempuri.org/';
			}, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue;
			if (tmp === null) return null;
			return tmp;
		};
	};
	let GetNodeTextContentFactory = function (xmlDoc) {
		return function (xpath) {
			var tmp = GetNodeFactory(xmlDoc)(xpath);
			if (tmp === null) return null;
			return tmp.textContent;
		};
	};

	switch (request.action) {
		case "fetch":
			fetch(request.data.url, request.data.params).then(response => response.text()).then(txt => { sendResponse(new window.DOMParser().parseFromString(txt, "text/xml")); });
			return true;
		case "fetchAutoApply":
			{
				fetch(request.data.url).then(response => response.text()).then(txt => new window.DOMParser().parseFromString(txt, "text/xml")).then(xmldoc => {
					let GetNodeTextContent = GetNodeTextContentFactory(xmldoc);
					let booleanRegex = new RegExp("true", "i");
					let versions = request.data.versions;
					let version = versions[0];
					let GetNode = GetNodeFactory(xmldoc);
					for (let i = 0; i < request.data.versions.length; i++) {
						let retailerNode = GetNode('/x:Stores/x:Retailer[@id=' + request.data.retailerid + ']/x:Overrides[@version="' + versions[i] + '"]');
						if (retailerNode) {
							version = request.data.versions[i];
						}
					}

					let rootPrefix = '/x:Stores/x:Retailer[@id=' + request.data.retailerid + ']/x:Overrides[@version="' + version + '"]';

					let regexData = function (prefix) {
						return {
							showActivateCashBack: {
								key: GetNodeTextContent(prefix + '/x:ShowActivateCashBack/x:Key'),
								value: GetNodeTextContent(prefix + '/x:ShowActivateCashBack/x:Value')
							},
							expropriate: !booleanRegex.test(GetNodeTextContent(prefix + '/x:DisableExpropriation')),
							showCoupons: {
								copyToClipboard: booleanRegex.test(GetNodeTextContent(prefix + '/x:ShowCoupons/x:CopyToClipboard')),
								showUrl: {
									key: GetNodeTextContent(prefix + '/x:ShowCoupons/x:ShowURL/x:Key'),
									value: GetNodeTextContent(prefix + '/x:ShowCoupons/x:ShowURL/x:Value')
								},
								readyToCopyIndicator: {
									value: GetNodeTextContent(prefix + '/x:ShowCoupons/x:ReadyToCopyIndicator/x:Value'),
									action: GetNodeTextContent(prefix + '/x:ShowCoupons/x:ReadyToCopyIndicator/x:Action')
								}
							},
							multipleCouponSupport: booleanRegex.test(GetNodeTextContent(prefix + '/x:MultipleCouponSupport')),
							sameTab: booleanRegex.test(GetNodeTextContent(prefix + '/x:SameTab')),
							noReload: booleanRegex.test(GetNodeTextContent(prefix + '/x:DoNotReload')),
							disableCheckoutDetection: booleanRegex.test(GetNodeTextContent(prefix + "/x:DisableCheckoutDetection")),
							maxCodesCount: GetNodeTextContent(prefix + '/x:MaxCodesCount'),
							postData: {
								submit: {
									verb: GetNodeTextContent(prefix + '/x:Post/x:Submit/x:Verb'),
									url: GetNodeTextContent(prefix + '/x:Post/x:Submit/x:Url'),
									params: GetNodeTextContent(prefix + '/x:Post/x:Submit/x:Params'),
									format: GetNodeTextContent(prefix + '/x:Post/x:Submit/x:Format'),
									headers: GetNodeTextContent(prefix + '/x:Post/x:Submit/x:Headers'),
									additionalHeaders: GetNodeTextContent(prefix + '/x:Post/x:Submit/x:AdditionalHeaders'),
									action: GetNodeTextContent(prefix + '/x:Post/x:Submit/x:Action'),
									reloadAfter: GetNodeTextContent(prefix + '/x:Post/x:Submit/x:ReloadAfter')
								},
								cancel: {
									verb: GetNodeTextContent(prefix + '/x:Post/x:Cancel/x:Verb'),
									url: GetNodeTextContent(prefix + '/x:Post/x:Cancel/x:Url'),
									params: GetNodeTextContent(prefix + '/x:Post/x:Cancel/x:Params'),
									format: GetNodeTextContent(prefix + '/x:Post/x:Cancel/x:Format'),
									headers: GetNodeTextContent(prefix + '/x:Post/x:Cancel/x:Headers'),
									additionalHeaders: GetNodeTextContent(prefix + '/x:Post/x:Submit/x:AdditionalHeaders'),
									action: GetNodeTextContent(prefix + '/x:Post/x:Cancel/x:Action'),
									lookup: GetNodeTextContent(prefix + '/x:Post/x:Cancel/x:Lookup'),
									lookupattribute: GetNodeTextContent(prefix + '/x:Post/x:Cancel/x:LookupAttribute')
								},
								read: {
									verb: GetNodeTextContent(prefix + '/x:Post/x:Read/x:Verb'),
									url: GetNodeTextContent(prefix + '/x:Post/x:Read/x:Url'),
									params: GetNodeTextContent(prefix + '/x:Post/x:Read/x:Params'),
									format: GetNodeTextContent(prefix + '/x:Post/x:Read/x:Format'),
									headers: GetNodeTextContent(prefix + '/x:Post/x:Read/x:Headers'),
									action: GetNodeTextContent(prefix + '/x:Post/x:Read/x:Action'),
									appliedCouponId: GetNodeTextContent(prefix + '/x:Post/x:Read/x:AppliedCouponId'),
									regexLookup: GetNodeTextContent(prefix + '/x:Post/x:Read/x:RegexLookup'),
									propertyLookup: GetNodeTextContent(prefix + '/x:Post/x:Read/x:PropertyLookup'),
									propertyType: GetNodeTextContent(prefix + '/x:Post/x:Read/x:PropertyType'),
									listLookup: GetNodeTextContent(prefix + '/x:Post/x:Read/x:ListLookup')
								}
							},
							checkoutUrl: {
								key: GetNodeTextContent(prefix + '/x:CheckoutURL/x:Key'),
								value: GetNodeTextContent(prefix + '/x:CheckoutURL/x:Value')
							},
							readyToApplyIndicator: {
								value: GetNodeTextContent(prefix + '/x:ReadyToApplyIndicator/x:Value'),
								shadowdomselector: GetNodeTextContent(prefix + '/x:ReadyToApplyIndicator/x:ShadowDomSelector'),
								action: GetNodeTextContent(prefix + '/x:ReadyToApplyIndicator/x:Action')
							},
							inputbox: {
								value: GetNodeTextContent(prefix + '/x:InputBox/x:Value'),
								shadowdomselector: GetNodeTextContent(prefix + '/x:InputBox/x:ShadowDomSelector'),
								action: GetNodeTextContent(prefix + '/x:InputBox/x:Action')
							},
							submit: {
								value: GetNodeTextContent(prefix + '/x:SubmitButton/x:Value'),
								shadowdomselector: GetNodeTextContent(prefix + '/x:SubmitButton/x:ShadowDomSelector'),
								action: GetNodeTextContent(prefix + '/x:SubmitButton/x:Action')
							},
							cancel: {
								value: GetNodeTextContent(prefix + '/x:Cancel/x:Value'),
								shadowdomselector: GetNodeTextContent(prefix + '/x:Cancel/x:ShadowDomSelector'),
								action: GetNodeTextContent(prefix + '/x:Cancel/x:Action')
							},
							reset: {
								value: GetNodeTextContent(prefix + '/x:Reset/x:Value'),
								shadowdomselector: GetNodeTextContent(prefix + '/x:Reset/x:ShadowDomSelector'),
								action: GetNodeTextContent(prefix + '/x:Reset/x:Action')
							},
							subtotal: {
								value: GetNodeTextContent(prefix + '/x:Subtotal/x:Value'),
								shadowdomselector: GetNodeTextContent(prefix + '/x:Subtotal/x:ShadowDomSelector'),
								action: GetNodeTextContent(prefix + '/x:Subtotal/x:Action')
							},
							couponAppliedIndicator: {
								value: GetNodeTextContent(prefix + '/x:CouponAppliedIndicator/x:Value'),
								shadowdomselector: GetNodeTextContent(prefix + '/x:CouponAppliedIndicator/x:ShadowDomSelector'),
								action: GetNodeTextContent(prefix + '/x:CouponAppliedIndicator/x:Action')
							},
							couponFailedIndicator: {
								value: GetNodeTextContent(prefix + '/x:CouponFailedIndicator/x:Value'),
								shadowdomselector: GetNodeTextContent(prefix + '/x:CouponFailedIndicator/x:ShadowDomSelector'),
								action: GetNodeTextContent(prefix + '/x:CouponFailedIndicator/x:Action')
							},
							couponRemovedIndicator: {
								value: GetNodeTextContent(prefix + '/x:CouponRemovedIndicator/x:Value'),
								shadowdomselector: GetNodeTextContent(prefix + '/x:CouponRemovedIndicator/x:ShadowDomSelector'),
								action: GetNodeTextContent(prefix + '/x:CouponRemovedIndicator/x:Action')
							}
						};
					}

					let returnData = regexData(rootPrefix);
					returnData._ParentURL = [];

					if (GetNode(rootPrefix + '/x:ParentURL') == null) {
						let key;
						if (!(key = GetNodeTextContent(rootPrefix + '/x:CheckoutURL/x:Value'))) {
							key = GetNodeTextContent(rootPrefix + '/x:ShowCoupons/x:ShowURL/x:Value');
						}

						if (key) {
							returnData._ParentURL[key] = regexData(rootPrefix);
						}
					} else {
						let notIDsuffix = '';
						let notIDsuffixFormat = function (id) { return '[not(@id="' + id + '")]'; }
						let parentURLNode;
						let parentURLurl;
						while (parentURLNode = GetNode(rootPrefix + '/x:ParentURL' + notIDsuffix)) {
							parentURLurl = parentURLNode.id;
							returnData._ParentURL[parentURLurl] = regexData(rootPrefix + '/x:ParentURL[@id="' + parentURLurl + '"]');
							returnData._ParentURL[parentURLurl].showOrApply = parentURLNode.attributes.show_or_apply.value;
							notIDsuffix += notIDsuffixFormat(parentURLurl);
						}
					}

					sendResponse(returnData);
				});
				return true;
			}
		case "parseTerms":
			{
				let xmlParsed = new window.DOMParser().parseFromString(request.data.xml, "text/xml");
				let GetNodeTextContentFunction = GetNodeTextContentFactory(xmlParsed);
				cbTerms = GetNodeTextContentFunction("/x:string");
				cbTerms = cbTerms.replaceAll("/help/cashback/", "/addon/howitworks/");
				cbTerms = cbTerms.replaceAll("href", "target='_blank' href");
				cbTerms = cbTerms.replaceAll("href='/", "href='https:www.befrugal.com/");
				cbTerms = cbTerms.replaceAll('href="/', 'href="https:www.befrugal.com/');
				sendResponse(cbTerms);
			}
		case "parseRAF":
			{
				let rafDoc = new DOMParser().parseFromString(request.data.html, "text/html");
				try {
					sendResponse(rafDoc.querySelector(".raf-terms-txt").innerHTML);
				}
				catch (exception) { }
			}
	}
	return false;
});