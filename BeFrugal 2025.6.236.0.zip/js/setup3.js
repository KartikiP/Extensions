try {
	function _EdgiumCheck() {
		if (_IsEdgium()) {
			return "Edgium";
		}
		else return "Chrome";
	};

	function _IsEdgium() {
		let hasUserAgent = typeof window !== 'undefined' && typeof window.navigator !== 'undefined' && typeof window.navigator.userAgent !== 'undefined';
		return (hasUserAgent && window && window.Navigator && window.navigator.userAgent && /edg/i.test(window.navigator.userAgent));
	};

	_EdgiumCheck();
}
catch (ex) { }