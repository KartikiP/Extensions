var bf_rwd_firefox_install_check_counter = 0;

// Create the main container
let dvFirefoxRwdInstall = document.createElement('div');
dvFirefoxRwdInstall.id = 'dvFirefoxRwdInstall';

// Create the background element
let dvFirefoxRwdInstall_bhInstructionFF_backgroundElement = document.createElement('div');
dvFirefoxRwdInstall_bhInstructionFF_backgroundElement.id = 'dvFirefoxRwdInstall_bhInstructionFF_backgroundElement';
dvFirefoxRwdInstall_bhInstructionFF_backgroundElement.style.setProperty("position", 'fixed', "important");
dvFirefoxRwdInstall_bhInstructionFF_backgroundElement.style.setProperty("left", '0px', "important");
dvFirefoxRwdInstall_bhInstructionFF_backgroundElement.style.setProperty("top", '0px', "important");
dvFirefoxRwdInstall_bhInstructionFF_backgroundElement.style.setProperty("z-index", '2147483647', "important");
dvFirefoxRwdInstall_bhInstructionFF_backgroundElement.style.setProperty("width", '100%', "important");
dvFirefoxRwdInstall_bhInstructionFF_backgroundElement.style.setProperty("height", '100%', "important");
dvFirefoxRwdInstall_bhInstructionFF_backgroundElement.style.setProperty("background-color", '#555', "important");
dvFirefoxRwdInstall_bhInstructionFF_backgroundElement.style.setProperty("filter", 'alpha("opacity" = 90)', "important");
dvFirefoxRwdInstall_bhInstructionFF_backgroundElement.style.setProperty("opacity", '0.9', "important");

// Create the conf detector element
let confDetector = document.createElement('div');
confDetector.id = 'confDetector';
confDetector.style.setProperty("height", '85px', "important");
confDetector.style.setProperty("width", '300px', "important");
confDetector.style.setProperty("position", 'relative', "important");
confDetector.style.setProperty("left", '320px', "important");

// Create the thanks span
let thanksSpan = document.createElement('span');
thanksSpan.style.setProperty("visibility", 'hidden', "important");
thanksSpan.style.setProperty("font-family", '\'Roboto\', Arial', "important");
thanksSpan.style.setProperty("font-size", '26px', "important");
thanksSpan.style.setProperty("line-height", 'initial', "important");
thanksSpan.textContent = 'Thanks';

// Append the thanks span to the conf detector element
confDetector.appendChild(thanksSpan);

// Append the conf detector element to the background element
dvFirefoxRwdInstall_bhInstructionFF_backgroundElement.appendChild(confDetector);

// Append the background element to the main container
dvFirefoxRwdInstall.appendChild(dvFirefoxRwdInstall_bhInstructionFF_backgroundElement);

// Create the FF almost done element
let dvFirefoxRwdInstall_FFAlmostDone = document.createElement('div');
dvFirefoxRwdInstall_FFAlmostDone.id = 'dvFirefoxRwdInstall_FFAlmostDone';
dvFirefoxRwdInstall_FFAlmostDone.style.setProperty("z-index", '2147483647', "important");
dvFirefoxRwdInstall_FFAlmostDone.style.setProperty("position", 'fixed', "important");
dvFirefoxRwdInstall_FFAlmostDone.style.setProperty("top", '312px', "important");
dvFirefoxRwdInstall_FFAlmostDone.style.setProperty("right",'300px', "important");
dvFirefoxRwdInstall_FFAlmostDone.style.setProperty("background",'#FFFFFF', "important");
dvFirefoxRwdInstall_FFAlmostDone.style.setProperty("border-radius",'12px', "important");
dvFirefoxRwdInstall_FFAlmostDone.style.setProperty("line-height", 'initial', "important");
dvFirefoxRwdInstall_FFAlmostDone.style.setProperty("margin", 'initial', "important");
dvFirefoxRwdInstall_FFAlmostDone.style.setProperty("padding", 'initial', "important");

// Create the table element
let table = document.createElement('table');
table.border = '0';
table.cellPadding = '0';
table.cellSpacing = '0';
table.style.setProperty("width", '720px', "important");
table.style.setProperty("height", '120px', "important");
table.style.setProperty("margin", '10px 0', "important");
table.style.setProperty("border", 'none', "important");

// Create the table body element
let tbody = document.createElement('tbody');
tbody.style.setProperty("border", 'none', "important");

// Create the table row element
let tr = document.createElement('tr');
tr.style.setProperty("border", 'none', "important");

// Create the first table data element
let td1 = document.createElement('td');
td1.style.setProperty("vertical-align",'middle', "important");
td1.style.setProperty("font",'26px/36px \'Roboto\'', "important");
td1.style.setProperty("text-align",'left', "important");
td1.style.setProperty("width", '560px', "important");
td1.style.setProperty("border", 'none', "important");

// Create the div element for the first table data
let div1 = document.createElement('div');
div1.style.setProperty("display",'inline-block', "important");
div1.style.setProperty("padding", '5px', "important");
div1.style.setProperty("position", 'relative', "important");
div1.style.setProperty("top", '-12px', "important");
div1.style.setProperty("left", '25px', "important");
div1.style.setProperty("width", '610px', "important");
div1.style.setProperty("vertical-align", 'initial', "important");

// Create the points div element
let pointsDiv = document.createElement('div');
pointsDiv.style.setProperty("position", 'relative', "important");
pointsDiv.style.setProperty("left", '11px', "important");
pointsDiv.style.setProperty("height", '100px', "important");
pointsDiv.style.setProperty("width", '100px', "important");
pointsDiv.style.setProperty("display",'inline-block', "important");
pointsDiv.style.setProperty("color",'#fa5b2b', "important");
pointsDiv.style.setProperty("background-color", '#fff4f1', "important");
pointsDiv.style.setProperty("border-radius", '75px', "important");
pointsDiv.style.setProperty("vertical-align", 'initial', "important");

// Create the points inner div element
let pointsInnerDiv = document.createElement('div');
pointsInnerDiv.style.setProperty("position", 'relative', "important");
pointsInnerDiv.style.setProperty("top", '22px', "important");
pointsInnerDiv.style.setProperty("left", '17px', "important");

// Create the points text div element
let pointsTextDiv = document.createElement('div');
pointsTextDiv.style.setProperty("font-size", '28px', "important");
pointsTextDiv.style.setProperty("font-weight", 'bold', "important");
pointsTextDiv.style.setProperty("position", 'relative', "important");
pointsTextDiv.style.setProperty("left", '-2px', "important");
pointsTextDiv.style.setProperty("font-family", '\'Roboto\', Arial', "important");
pointsTextDiv.style.setProperty("line-height", 'initial', "important");
pointsTextDiv.textContent = '+350';

// Create the points label div element
let pointsLabelDiv = document.createElement('div');
pointsLabelDiv.style.setProperty("font-size", '18px', "important");
pointsLabelDiv.style.setProperty("position", 'relative', "important");
pointsLabelDiv.style.setProperty("top", '-8px', "important");
pointsLabelDiv.style.setProperty("font-family", '\'Roboto\', Arial', "important");
pointsLabelDiv.style.setProperty("line-height", 'initial', "important");
pointsLabelDiv.textContent = 'POINTS';

// Append the points label div to the points inner div
pointsInnerDiv.appendChild(pointsTextDiv);
pointsInnerDiv.appendChild(pointsLabelDiv);

// Append the points inner div to the points div
pointsDiv.appendChild(pointsInnerDiv);

// Create the instruction div element
let instructionDiv = document.createElement('div');
instructionDiv.style.setProperty("margin-left", '38px', "important");
instructionDiv.style.setProperty("padding-left", '38px', "important");
instructionDiv.style.setProperty("margin-top", '29px', "important");
instructionDiv.style.setProperty("border-left", '1px solid lightgrey', "important");
instructionDiv.style.setProperty("position", 'relative', "important");
instructionDiv.style.setProperty("top", '22px', "important");
instructionDiv.style.setProperty("display",'inline-block', "important");
instructionDiv.style.setProperty("width", '430px', "important");
instructionDiv.style.setProperty("vertical-align", 'initial', "important");
instructionDiv.style.setProperty("font-size", '26px', "important");
instructionDiv.style.setProperty("line-height", '36px', "important");
instructionDiv.style.setProperty("font-family", '\'Roboto\', Arial', "important");

// Create the instruction text span element
let instructionTextSpan = document.createElement('span');
instructionTextSpan.id = 'spnContinue';
instructionTextSpan.style.setProperty("font-weight",'500', "important");
instructionTextSpan.style.setProperty("color", '#0694f2', "important");
instructionTextSpan.style.setProperty("font-family", '\'Roboto\', Arial', "important");
instructionTextSpan.style.setProperty("line-height", 'initial', "important");
instructionTextSpan.style.setProperty("font-size", '26px', "important");
instructionTextSpan.textContent = 'Continue';

// Create the instruction text
let instructionText = document.createTextNode('Click ');
let instructionText2 = document.createTextNode(', then click ');
let instructionText3 = document.createTextNode(' to get Reward Points');
let instructionTextSpan2 = document.createElement('span');
instructionTextSpan2.style.setProperty("font-weight", '500', "important");
instructionTextSpan2.style.setProperty("color", '#0694f2', "important");
instructionTextSpan2.style.setProperty("font-family", '\'Roboto\', Arial', "important");
instructionTextSpan2.style.setProperty("line-height", 'initial', "important");
instructionTextSpan2.style.setProperty("font-size", '26px', "important");
instructionTextSpan2.textContent = 'Add';

// Append the instruction text to the instruction div
instructionDiv.appendChild(instructionText);
instructionDiv.appendChild(instructionTextSpan);
instructionDiv.appendChild(instructionText2);
instructionDiv.appendChild(instructionTextSpan2);
instructionDiv.appendChild(document.createElement('br'));
instructionDiv.appendChild(instructionText3);

// Append the points div and instruction div to the first div
div1.appendChild(pointsDiv);
div1.appendChild(instructionDiv);

// Append the first div to the first table data
td1.appendChild(div1);

// Create the second table data element
let td2 = document.createElement('td');
td2.style.setProperty("width", '80px', "important");
td2.style.setProperty("position", 'relative', "important");
td2.style.setProperty("border", 'none', "important");

// Create the image div element
let imageDiv = document.createElement('div');
imageDiv.style.setProperty("position", 'absolute', "important");
imageDiv.style.setProperty("top", '-30px', "important");
imageDiv.style.setProperty("left", '20px', "important");

// Create the image element
let image = document.createElement('img');
image.src = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGUAAABaCAYAAAChUJi3AAAK6klEQVR4Xu2de4xcVR3Hv/fOmZnd2dlXt6/dwvYB2PKKKVAehaiBCrXyatPyKpaKaEFigiRQNFiDJKJGitEoEEVAqVDEYmpJG2qRSAGBKpgILdRiW2m32+2+Oo+d173H3x+/E05OMpms23vndjnf5Jt75m7a2ZnP/L7n3Jnz23Gg61GJusr3boQbu5bH63GbeJp/Itnq95SIolY5OBZyEQkxEMddBuByMllei4cGVwBIsuPkGNmhB+9gHMuNEJAlcJwroeSKyxGLL8X9u1cCSJNT5IQOxkIJHshimEo2LUJT+2Ksfo3AoJXcxFUjFBgLJajI0oGYaupYgAnTr8IdW78EoC0oMBaKGVm11NZ1ISafvAjfeGE5gPbxDsaNSGTVVseMCzB1zkLc/qcbxnvFiDpG1pUYrSbOOg9Ek8AAP7/idwaACoHh5bKFEkhkVQczcx4g/fEMRkQ1smpXDDBewYjoRZaNMhG9yLJRJqIXWTbKRPQiy0aZiF5k2SgT0YssG2UiepFlo0xEL7JslInoRZaNMhG9yLJRJqIXWTbKRPQiy0aZiF5k2SgT0YssG2UiepFlo0xEL7JslInoRZaNMhG9yLJRJqIXWTbKRPQiy0aZiF5k2SgT0YssG2UiSpFlo8yE8nAlIpFlo0xoQK4jIF/UAFgwTkzUA4xLdngOMYFYdUw/G12nLwQhIreF1LjEleJXtqBSegn5QR/ZI0lk+5rp2Ir8UBsKmVaUR9L08xT8ShK+JyClC4B/IcnHKlq29nQErVd+uQ897+VBguPo/ZG1BUfyQMJxfLixClxRRKKxgNSEAhKpIRAecpldIXt8H15wUL6e+BWABnKaf4Ep5KnsSUYXVYyBkGtowZ3dCEvbfnIQgKfZB3kUgKT2RBfJOfIwuY+cZufIeXKJ4QQ60btcknFygq1+ViaPkD0GoqqktuLJdoQjyU9SiV0klzVAGAUYn8GUyGUtURLsuHoegoSix4+jPcAiOcu386OpEJaDZHoSwpN68eTIWR6rV7QkYwwVU2TossrzdcyhSLZPLnFVHCVLHidGUSFmv2IXQpHUI2eAfVRFjQFl1BXDYDIaaF/BCzK+fKM6PBMIRi8HzZNPQyl/BInURASpKZ9qAlBmCEPkw+R+BlMcw4Ssgxlhq6rxA51TjHKV6tUxxux08ciSdfhF6VYErURTzIjcQfIRPuYVlDGCqTD4krb6QvCVwkc9rsZ4DdQIKUsIWl5ZRU2ZXNBWTkM8rsDQGOLMVw4SilRg2FAwxgaFJ0G/sh9ITEWQmtCdVni0VViR4yZ/LKAYx+DfZmFJuqOPx2MUX+1WIOURBK3G1gQW3jMLW37Qo8WtZPv0uDzbR6+DLuV3I2g1NMchpcNAYkb8knVZKD4qhY8QiqTDMATIOhiuWguFM1dCygzCUKq9QasSoY1tpRiSIfaktGhvh8R57LJ1WSiIxX343gCCVmtnCoCoFmEWiq67u55FfnArglbLlBS+8O3ZAOJsUf39OhtfPirFQwhaU2a3QyRUhcRrzSsWSil/AGGosa2BgSQMMK62ArNQeAWWRzmEpXHXaR244r4zq3/2YaEoeVgz+1mUcrsQtE79/CxIT/CnqI3kpAnGQtHf7Mz2v4UwlJrQbEBJ6H89z0JRF5BAheKrF2HonGvOwFX3z2MoDEbNLbpspXgQCQ9DBzaGcL3SglR7C4AmdqP5YZ2FonaIfPfU9ejf9yrC0EnzZ2HJD+cDSDOUBgbDqzALRVVLGSJZQaYv+LnlxLndEMlmhpI2qsVC0eYVD98/5/cY2P83hKFzb5iPZQ9+FoCCw9cwWrXYSuF9WZXCIeT6g18eN09qxdQ5s7D84csYTMoE80mHItWuEPzoovU4tGsbwtAZi86HaOjgHZ4t+l5gWyn6vAIUUC72INO3E2HoghWL8eUnFwNo0+YXQY5xtXwSofC8okN56JLn8J83/ogw5LgOzrnuGqx84moA7RxlDIZjLIpQQo8wIId4Qx4fvLwOYUgkEjhv+S24feONuOPF6xSYqM4v4X790yrH5UxPkztw64YVmDFvCdpPmIOw9N+3n0Nu8B2q1t9qW1G5vYGrOoivf3pULofvJfnrrS6lChXm/mU1dhGijM3jOdpBuYFibBsqpRGEpRPnLsXMc2/D3dtvwb1v38RX/YlAqoZAgLrk8Ij3LQAPEJDHQEDgV17hlSDZ+GorcpiVYlZLE3kCuRM3PX495q+8FWEr07cd+YGX4cR68J1T1mntDz5ZjrZqCKiqCAeOcyLgzDN7SFHI/BpHe/9O9/e82XbB9uoBRW0FauRsn4ivPnMj3NgMnLV0GeqhcmE3Svl36LgDbmwAIunhm+3rzMajKpAUhC4ApwLOp2k8F6a88i7073sa+cEcHjh3szpLLqjN4wpOmFDMaokzmDbyFFq2Xg/f76KKWYZ6S/pD8L33ybsB2QvHdcmSW/c8GncCTjeAk+hcZ83rnszhDejZuQMPfu4ldZ2kVUiWuwOyDKhUHyhcLUaMTcaKx64FMA0X3nw1xoO8ch/+vf0J5IfKNH9uZyDC6GwYJg/q/TQuwpeKAY9c1pqUBvCbrzwP3zuE1x7fRGWewfEqKX0cfHcTdqx/Cmsv3kFAdgHo1PpHU3rHgxGTUqC+UmDyahcKnvraRgCdyPYXMefis9F91gwcTzq063V8+PpOPHnzm1wZXWRXW3mOaCvQArvE53xtSVy3ajH7K4e4G7cXf7hrC3Zu3YE31r2J40G9H+zEiz9+Bv/c+BEB2c8wVGU0MBiVDBnyUXaOwSgoYCh1BeNrYDLcr9hL7sGGezZj6MBebLpvM3b/9UNEUXtefQ+bvvcC3np6L72QerFhdY/27XpxRlbSXnT95CN8HObzRW0pzrlWbzCrHLUSMRuVfHqQLwCYDMetYP/bh9A99wSc8plu1FOZvize3bIH/XuzKOU96ovp46pPG63jBfKw1lU2qN3OGR3MHgOQAtGRr80v0ujKKmHjmq0AOnD5mvPxr817MeeS6TTndBMsJ6RlsiQQB7BzWy9I+PPafdoEnSCXjSjOqJUVe0irjLwWWZ6aS+rz3lftZTIZ6oo/yRHQykvmieQOdju5BZetPhPNk9I4+aJOtE1Lo/2EJhwr0TIWfXty6H0/SyupLIrZCl766QEAnt6YarTy5bT5YsiAkWEYqjo8NhSQKEExwUDrMUny8rGZc3oCu52tPupN4dK7ZiMmEmjtbEJ6UiOmndmKjhlpJJsEaqk84mH/P4Zx8L0MilkP+cEyQangLz/rUdWgQJjxxDDy2kXgsH5k6zDKDEOyWdGEYsJxtc3ajVw1LVw5bexWBtOsbydix7HgzpmAdCClq6006TadM0RVcBCA1KLEM6uCbcLg6iAzGDXWYBQ1GH6t3h0H0ZXDjjGYBMNJs5vJLWxz50qDAsMWbLdKL6Rk+zoIA0aRrYBkyTl2lp3TQBQMGEZUVVcM0ZevT/z6E6Siw3BOf3Jq2Px3WfZRY8U0oC1l+8iH2X18bkC9VaJP5EZ1yP/vQ67oV41rVE5S2zec4qPupOaEVjGOsl4lZh++4YI6Gi6yy2zPAEFmBQAlinCEAsQ2Iejn42yz5Q4GFJ43NFc5V+UPs5lzBsY7FLPCXQMQQ9KPXCEMhF1tTvHYZWXtdsWwqga/GojQoEQfEEOqbq606nNXFfuGZRUQFkoVQI4RdY4CotmUVDaiSLJrQLBQRgeq9lhWH4ev/wGGFKsk+M5UlwAAAABJRU5ErkJggg==';
image.style.setProperty("width", '96px', "important");
image.style.setProperty("height", '81px', "important");
image.style.setProperty("display", 'inline-block', "important");
image.style.setProperty("transform", 'scaleX(-1)', "important");
image.style.setProperty("max-width", 'initial', "important");

// Append the image to the image div
imageDiv.appendChild(image);

// Append the image div to the second table data
td2.appendChild(imageDiv);

// Append the first and second table data to the table row
tr.appendChild(td1);
tr.appendChild(td2);

// Append the table row to the table body
tbody.appendChild(tr);

// Append the table body to the table
table.appendChild(tbody);

// Append the table to the FF almost done element
dvFirefoxRwdInstall_FFAlmostDone.appendChild(table);

// Create the instruction pop div element
let instructionPopDiv = document.createElement('div');
instructionPopDiv.id = 'dvFirefoxRwdInstall_instructionPop_instrPopByClickingAllow';
instructionPopDiv.style.setProperty("position", 'absolute', "important");
instructionPopDiv.style.setProperty("bottom", '0px', "important");
instructionPopDiv.style.setProperty("right",'16px', "important");

// Create the restart div element
let restartDiv = document.createElement('div');
restartDiv.id = 'dvFirefoxRwdInstall_instructionPop_dvRestart';
restartDiv.style.setProperty("padding-bottom", '10px', "important");
restartDiv.style.setProperty("width", '100%', "important");
restartDiv.style.setProperty("text-align",'"left"', "important");
restartDiv.addEventListener("click", function () {
    window.open("https://www.befrugal.com/toolbar/download/?source=28", "_self");
});

// Create the restart link element
let restartLink = document.createElement('a');
restartLink.style.setProperty("font-family", '\'Roboto\', Arial', "important");
restartLink.style.setProperty("line-height", 'initial', "important");
restartLink.style.setProperty("textDecoration", 'underline', "important");
restartLink.style.setProperty("color",'#7f7f7f', "important");
restartLink.style.setProperty("cursor", 'pointer', "important");
restartLink.style.setProperty("font-size", '14px', "important");
restartLink.style.setProperty("margin-left", '15px', "important");
restartLink.textContent = 'Restart Download';

// Append the restart link to the restart div
restartDiv.appendChild(restartLink);

// Append the restart div to the instruction pop div
instructionPopDiv.appendChild(restartDiv);

// Append the instruction pop div to the FF almost done element
dvFirefoxRwdInstall_FFAlmostDone.appendChild(instructionPopDiv);

// Create the close button span element
let closeButtonSpan = document.createElement('span');
closeButtonSpan.id = 'dvFirefoxRwdInstall_bfrl_closeButton';
closeButtonSpan.style.setProperty("cursor", 'pointer', "important");
closeButtonSpan.style.setProperty("position", 'absolute', "important");
closeButtonSpan.style.setProperty("top", '1px', "important");
closeButtonSpan.style.setProperty("left", '10px', "important");
closeButtonSpan.style.setProperty("font-size", '22px', "important");
closeButtonSpan.style.setProperty("color", '#7f7f7f', "important");
closeButtonSpan.style.setProperty("font-weight", 'initial', "important");
closeButtonSpan.style.setProperty("font-family", '\'Roboto\', Arial', "important");
closeButtonSpan.style.setProperty("line-height", 'initial', "important");
closeButtonSpan.style.setProperty("font-size", '26px', "important");
closeButtonSpan.textContent = '\u00D7';
closeButtonSpan.addEventListener("click", function () {
    dvFirefoxRwdInstall.style.setProperty("display", "none", "important");
});
// Append the close button span to the FF almost done element
dvFirefoxRwdInstall_FFAlmostDone.appendChild(closeButtonSpan);

// Append the FF almost done element to the main container
dvFirefoxRwdInstall.appendChild(dvFirefoxRwdInstall_FFAlmostDone);

// Create the keep changes element
let dvFirefoxRwdInstall_ffKeepChanges = document.createElement('div');
dvFirefoxRwdInstall_ffKeepChanges.id = 'dvFirefoxRwdInstall_ffKeepChanges';
dvFirefoxRwdInstall_ffKeepChanges.style.setProperty("display",'none', "important");
dvFirefoxRwdInstall_ffKeepChanges.style.setProperty("z-index", '2147483647', "important");
dvFirefoxRwdInstall_ffKeepChanges.style.setProperty("position", 'fixed', "important");
dvFirefoxRwdInstall_ffKeepChanges.style.setProperty("top", '180px', "important");
dvFirefoxRwdInstall_ffKeepChanges.style.setProperty("left", '10%', "important");
dvFirefoxRwdInstall_ffKeepChanges.style.setProperty("background",'#FFFFFF', "important");
dvFirefoxRwdInstall_ffKeepChanges.style.setProperty("border-radius",'12px', "important");

// Create the keep changes table element
let keepChangesTable = document.createElement('table');
keepChangesTable.border = '0';
keepChangesTable.cellPadding = '0';
keepChangesTable.cellSpacing = '0';
keepChangesTable.style.setProperty("width", '400px', "important");
keepChangesTable.style.setProperty("height", '120px', "important");
keepChangesTable.style.setProperty("margin", '10px 0', "important");
keepChangesTable.style.setProperty("border", 'none', "important");

// Create the keep changes table body element
let keepChangesTbody = document.createElement('tbody');

// Create the keep changes table row element
let keepChangesTr = document.createElement('tr');

// Create the first keep changes table data element
let keepChangesTd1 = document.createElement('td');
keepChangesTd1.style.setProperty("vertical-align",'middle', "important");
keepChangesTd1.style.setProperty("font-family", '\'Roboto\', Arial', "important");
keepChangesTd1.style.setProperty("line-height", 'initial', "important");
keepChangesTd1.style.setProperty("font-size", '26px', "important");
keepChangesTd1.style.setProperty("text-align",'"left"', "important");
keepChangesTd1.style.setProperty("width", '343px', "important");
keepChangesTd1.style.setProperty("border", 'none', "important");

// Create the keep changes div element
let keepChangesDiv = document.createElement('div');
keepChangesDiv.style.setProperty("position", 'relative', "important");
keepChangesDiv.style.setProperty("top", '2px', "important");
keepChangesDiv.style.setProperty("display",'inline-block', "important");
keepChangesDiv.style.setProperty("width", '245px', "important");
keepChangesDiv.style.setProperty("margin-left", '69px', "important");

// Create the keep changes text span element
let keepChangesTextSpan = document.createElement('span');
keepChangesTextSpan.id = 'spnContinue';
keepChangesTextSpan.style.setProperty("font-weight",'500', "important");
keepChangesTextSpan.style.setProperty("color", '#0694f2', "important");
keepChangesTextSpan.style.setProperty("font-family", '\'Roboto\', Arial', "important");
keepChangesTextSpan.style.setProperty("line-height", 'initial', "important");
keepChangesTextSpan.style.setProperty("font-size", '26px', "important");
keepChangesTextSpan.textContent = 'Yes';

// Create the keep changes text
let keepChangesText = document.createTextNode('Click ');
let keepChangesText2 = document.createTextNode(' to continue');

// Append the keep changes text to the keep changes div
keepChangesDiv.appendChild(keepChangesText);
keepChangesDiv.appendChild(keepChangesTextSpan);
keepChangesDiv.appendChild(keepChangesText2);

// Append the keep changes div to the first keep changes table data
keepChangesTd1.appendChild(keepChangesDiv);

// Create the second keep changes table data element
let keepChangesTd2 = document.createElement('td');
keepChangesTd2.style.setProperty("width", '80px', "important");
keepChangesTd2.style.setProperty("position", 'relative', "important");
keepChangesTd2.style.setProperty("border", 'none', "important");

// Create the keep changes image div element
let keepChangesImageDiv = document.createElement('div');
keepChangesImageDiv.style.setProperty("position", 'absolute', "important");
keepChangesImageDiv.style.setProperty("top", '-30px', "important");
keepChangesImageDiv.style.setProperty("left", '-40px', "important");

// Create the keep changes image element
let keepChangesImage = document.createElement('img');
keepChangesImage.src = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGUAAABaCAYAAAChUJi3AAAK6klEQVR4Xu2de4xcVR3Hv/fOmZnd2dlXt6/dwvYB2PKKKVAehaiBCrXyatPyKpaKaEFigiRQNFiDJKJGitEoEEVAqVDEYmpJG2qRSAGBKpgILdRiW2m32+2+Oo+d173H3x+/E05OMpms23vndjnf5Jt75m7a2ZnP/L7n3Jnz23Gg61GJusr3boQbu5bH63GbeJp/Itnq95SIolY5OBZyEQkxEMddBuByMllei4cGVwBIsuPkGNmhB+9gHMuNEJAlcJwroeSKyxGLL8X9u1cCSJNT5IQOxkIJHshimEo2LUJT+2Ksfo3AoJXcxFUjFBgLJajI0oGYaupYgAnTr8IdW78EoC0oMBaKGVm11NZ1ISafvAjfeGE5gPbxDsaNSGTVVseMCzB1zkLc/qcbxnvFiDpG1pUYrSbOOg9Ek8AAP7/idwaACoHh5bKFEkhkVQczcx4g/fEMRkQ1smpXDDBewYjoRZaNMhG9yLJRJqIXWTbKRPQiy0aZiF5k2SgT0YssG2UiepFlo0xEL7JslInoRZaNMhG9yLJRJqIXWTbKRPQiy0aZiF5k2SgT0YssG2UiepFlo0xEL7JslInoRZaNMhG9yLJRJqIXWTbKRPQiy0aZiF5k2SgT0YssG2UiSpFlo8yE8nAlIpFlo0xoQK4jIF/UAFgwTkzUA4xLdngOMYFYdUw/G12nLwQhIreF1LjEleJXtqBSegn5QR/ZI0lk+5rp2Ir8UBsKmVaUR9L08xT8ShK+JyClC4B/IcnHKlq29nQErVd+uQ897+VBguPo/ZG1BUfyQMJxfLixClxRRKKxgNSEAhKpIRAecpldIXt8H15wUL6e+BWABnKaf4Ep5KnsSUYXVYyBkGtowZ3dCEvbfnIQgKfZB3kUgKT2RBfJOfIwuY+cZufIeXKJ4QQ60btcknFygq1+ViaPkD0GoqqktuLJdoQjyU9SiV0klzVAGAUYn8GUyGUtURLsuHoegoSix4+jPcAiOcu386OpEJaDZHoSwpN68eTIWR6rV7QkYwwVU2TossrzdcyhSLZPLnFVHCVLHidGUSFmv2IXQpHUI2eAfVRFjQFl1BXDYDIaaF/BCzK+fKM6PBMIRi8HzZNPQyl/BInURASpKZ9qAlBmCEPkw+R+BlMcw4Ssgxlhq6rxA51TjHKV6tUxxux08ciSdfhF6VYErURTzIjcQfIRPuYVlDGCqTD4krb6QvCVwkc9rsZ4DdQIKUsIWl5ZRU2ZXNBWTkM8rsDQGOLMVw4SilRg2FAwxgaFJ0G/sh9ITEWQmtCdVni0VViR4yZ/LKAYx+DfZmFJuqOPx2MUX+1WIOURBK3G1gQW3jMLW37Qo8WtZPv0uDzbR6+DLuV3I2g1NMchpcNAYkb8knVZKD4qhY8QiqTDMATIOhiuWguFM1dCygzCUKq9QasSoY1tpRiSIfaktGhvh8R57LJ1WSiIxX343gCCVmtnCoCoFmEWiq67u55FfnArglbLlBS+8O3ZAOJsUf39OhtfPirFQwhaU2a3QyRUhcRrzSsWSil/AGGosa2BgSQMMK62ArNQeAWWRzmEpXHXaR244r4zq3/2YaEoeVgz+1mUcrsQtE79/CxIT/CnqI3kpAnGQtHf7Mz2v4UwlJrQbEBJ6H89z0JRF5BAheKrF2HonGvOwFX3z2MoDEbNLbpspXgQCQ9DBzaGcL3SglR7C4AmdqP5YZ2FonaIfPfU9ejf9yrC0EnzZ2HJD+cDSDOUBgbDqzALRVVLGSJZQaYv+LnlxLndEMlmhpI2qsVC0eYVD98/5/cY2P83hKFzb5iPZQ9+FoCCw9cwWrXYSuF9WZXCIeT6g18eN09qxdQ5s7D84csYTMoE80mHItWuEPzoovU4tGsbwtAZi86HaOjgHZ4t+l5gWyn6vAIUUC72INO3E2HoghWL8eUnFwNo0+YXQY5xtXwSofC8okN56JLn8J83/ogw5LgOzrnuGqx84moA7RxlDIZjLIpQQo8wIId4Qx4fvLwOYUgkEjhv+S24feONuOPF6xSYqM4v4X790yrH5UxPkztw64YVmDFvCdpPmIOw9N+3n0Nu8B2q1t9qW1G5vYGrOoivf3pULofvJfnrrS6lChXm/mU1dhGijM3jOdpBuYFibBsqpRGEpRPnLsXMc2/D3dtvwb1v38RX/YlAqoZAgLrk8Ij3LQAPEJDHQEDgV17hlSDZ+GorcpiVYlZLE3kCuRM3PX495q+8FWEr07cd+YGX4cR68J1T1mntDz5ZjrZqCKiqCAeOcyLgzDN7SFHI/BpHe/9O9/e82XbB9uoBRW0FauRsn4ivPnMj3NgMnLV0GeqhcmE3Svl36LgDbmwAIunhm+3rzMajKpAUhC4ApwLOp2k8F6a88i7073sa+cEcHjh3szpLLqjN4wpOmFDMaokzmDbyFFq2Xg/f76KKWYZ6S/pD8L33ybsB2QvHdcmSW/c8GncCTjeAk+hcZ83rnszhDejZuQMPfu4ldZ2kVUiWuwOyDKhUHyhcLUaMTcaKx64FMA0X3nw1xoO8ch/+vf0J5IfKNH9uZyDC6GwYJg/q/TQuwpeKAY9c1pqUBvCbrzwP3zuE1x7fRGWewfEqKX0cfHcTdqx/Cmsv3kFAdgHo1PpHU3rHgxGTUqC+UmDyahcKnvraRgCdyPYXMefis9F91gwcTzq063V8+PpOPHnzm1wZXWRXW3mOaCvQArvE53xtSVy3ajH7K4e4G7cXf7hrC3Zu3YE31r2J40G9H+zEiz9+Bv/c+BEB2c8wVGU0MBiVDBnyUXaOwSgoYCh1BeNrYDLcr9hL7sGGezZj6MBebLpvM3b/9UNEUXtefQ+bvvcC3np6L72QerFhdY/27XpxRlbSXnT95CN8HObzRW0pzrlWbzCrHLUSMRuVfHqQLwCYDMetYP/bh9A99wSc8plu1FOZvize3bIH/XuzKOU96ovp46pPG63jBfKw1lU2qN3OGR3MHgOQAtGRr80v0ujKKmHjmq0AOnD5mvPxr817MeeS6TTndBMsJ6RlsiQQB7BzWy9I+PPafdoEnSCXjSjOqJUVe0irjLwWWZ6aS+rz3lftZTIZ6oo/yRHQykvmieQOdju5BZetPhPNk9I4+aJOtE1Lo/2EJhwr0TIWfXty6H0/SyupLIrZCl766QEAnt6YarTy5bT5YsiAkWEYqjo8NhSQKEExwUDrMUny8rGZc3oCu52tPupN4dK7ZiMmEmjtbEJ6UiOmndmKjhlpJJsEaqk84mH/P4Zx8L0MilkP+cEyQangLz/rUdWgQJjxxDDy2kXgsH5k6zDKDEOyWdGEYsJxtc3ajVw1LVw5bexWBtOsbydix7HgzpmAdCClq6006TadM0RVcBCA1KLEM6uCbcLg6iAzGDXWYBQ1GH6t3h0H0ZXDjjGYBMNJs5vJLWxz50qDAsMWbLdKL6Rk+zoIA0aRrYBkyTl2lp3TQBQMGEZUVVcM0ZevT/z6E6Siw3BOf3Jq2Px3WfZRY8U0oC1l+8iH2X18bkC9VaJP5EZ1yP/vQ67oV41rVE5S2zec4qPupOaEVjGOsl4lZh++4YI6Gi6yy2zPAEFmBQAlinCEAsQ2Iejn42yz5Q4GFJ43NFc5V+UPs5lzBsY7FLPCXQMQQ9KPXCEMhF1tTvHYZWXtdsWwqga/GojQoEQfEEOqbq606nNXFfuGZRUQFkoVQI4RdY4CotmUVDaiSLJrQLBQRgeq9lhWH4ev/wGGFKsk+M5UlwAAAABJRU5ErkJggg==';
keepChangesImage.style.setProperty("width", '96px', "important");
keepChangesImage.style.setProperty("height", '81px', "important");
keepChangesImage.style.setProperty("transform", 'scaleX(-1)', "important");

// Append the keep changes image to the keep changes image div
keepChangesImageDiv.appendChild(keepChangesImage);

// Append the keep changes image div to the second keep changes table data
keepChangesTd2.appendChild(keepChangesImageDiv);

// Append the first and second keep changes table data to the keep changes table row
keepChangesTr.appendChild(keepChangesTd1);
keepChangesTr.appendChild(keepChangesTd2);

// Append the keep changes table row to the keep changes table body
keepChangesTbody.appendChild(keepChangesTr);

// Append the keep changes table body to the keep changes table
keepChangesTable.appendChild(keepChangesTbody);

// Append the keep changes table to the keep changes element
dvFirefoxRwdInstall_ffKeepChanges.appendChild(keepChangesTable);

// Append the keep changes element to the main container
dvFirefoxRwdInstall.appendChild(dvFirefoxRwdInstall_ffKeepChanges);

//Shadow Host Container
const host = document.createElement("div");
host.style.setProperty("position", 'fixed', "important");
host.style.setProperty("left", '0px', "important");
host.style.setProperty("top", '0px', "important");
host.style.setProperty("z-index", '2147483647', "important");
host.style.setProperty("width", '100%', "important");
host.style.setProperty("height", '100%', "important");

//Shadow on Host
const shadow = host.attachShadow({ mode: "closed" });
shadow.appendChild(dvFirefoxRwdInstall);

// Append the main container to the body
document.body.appendChild(host);

function bf_rewards_ff_step_two() {
	bf_rwd_firefox_install_check_counter = 0;
	var mousePosition = { x: 0, y: 0 };
	var incrementInstallCheckBfRwdCounter = function () {
		if (bf_rwd_firefox_install_check_counter < 10) {
			bf_rwd_firefox_install_check_counter = bf_rwd_firefox_install_check_counter + 1;
			setTimeout(incrementInstallCheckBfRwdCounter, 1000)
		}
	}; 
	setTimeout(incrementInstallCheckBfRwdCounter, 1000);

	if (document.readyState == 'complete' || document.readyState == "interactive") {
		dvFirefoxRwdInstall_FFAlmostDone.style.setProperty("display", "none", "important");
		dvFirefoxRwdInstall_ffKeepChanges.style.setProperty("display", "block", "important");

		function searchExtRefocused() {
			let whereClicked = (window.innerWidth - mousePosition.x) / window.innerWidth;
			if (whereClicked < 0.35) return;
			whereClicked = (window.innerHeight - mousePosition.y) / window.innerHeight;
			if (whereClicked < 0.70) return;
			window.removeEventListener('focus', searchExtRefocused);
			if (bf_rwd_firefox_install_check_counter >= 6) {
				dvFirefoxRwdInstall.style.setProperty("display", "none", "important");
				dvFirefoxRwdInstall_ffKeepChanges.style.setProperty("display", "block", "important");
			}
			else {
				setTimeout(function () {
					dvFirefoxRwdInstall.style.setProperty("display", "none", "important");
					dvFirefoxRwdInstall_ffKeepChanges.style.setProperty("display", "block", "important");
				}, (6 - bf_rwd_firefox_install_check_counter) * 1000);
			}
		};

		window.addEventListener('focus', searchExtRefocused);
		window.addEventListener('mousemove', function (e) { mousePosition.x = e.pageX; mousePosition.y = e.pageY; });

		var evt = document.createEvent('Event');
		evt.initEvent('applyRewardSearchConversion', true, false);
		document.dispatchEvent(evt);
	}
	else {
		document.onload = function () {
			dvFirefoxRwdInstall_FFAlmostDone.style.setProperty("display", "none", "important");
			dvFirefoxRwdInstall_ffKeepChanges.style.setProperty("display", "block", "important");

			function searchExtRefocused() {
				let whereClicked = (window.innerWidth - mousePosition.x) / window.innerWidth;
				if (whereClicked < 0.35) return;
				whereClicked = (window.innerHeight - mousePosition.y) / window.innerHeight;
				if (whereClicked < 0.70) return;
				window.removeEventListener('focus', searchExtRefocused);
				if (bf_rwd_firefox_install_check_counter >= 6) {
					dvFirefoxRwdInstall.style.setProperty("display", "none", "important");
					dvFirefoxRwdInstall_ffKeepChanges.style.setProperty("display", "block", "important");
				}
				else {
					setTimeout(function () {
						dvFirefoxRwdInstall.style.setProperty("display", "none", "important");
						dvFirefoxRwdInstall_ffKeepChanges.style.setProperty("display", "block", "important");
					}, (6 - bf_rwd_firefox_install_check_counter)* 1000);
				}
			};

			window.addEventListener('focus', searchExtRefocused);
			document.body.addEventListener('mouseenter', function (e) { mousePosition.x = e.pageX; mousePosition.y = e.pageY; });

			var evt = document.createEvent('Event');
			evt.initEvent('applyRewardSearchConversion', true, false);
			document.dispatchEvent(evt);
		}
	}
}

function bf_rwd_ff_check_installed(callback) {
	let extCheckApi = "https://www.befrugal.com/ServicePages/BefrugalSiteWs/?handler=IsBeFrugalRewardSearchInstalled";
	browser.runtime.sendMessage({
		action: "FetchJson",
		targetScript: "shoptoolbar.js",
		data: { url: extCheckApi }
	}).then(function (response) {
		if (response) {
			browser.runtime.sendMessage({
				action: "Preference Manager",
				data: { pref: "Settings" }
			}).then(function (settings) {
				settings.Config.IsRewardsInstalled = true;
				browser.runtime.sendMessage({
					action: "Preference Manager",
					data: { pref: "Settings", value: settings }
				});
			});
		}
		callback(response);
	});
}

var installCounterLocked = false;
window.addEventListener('mousemove', function (e) {
	if (!installCounterLocked){
		installCounterLocked = true;
		bf_rwd_ff_check_installed(function (rwdInstalled) {
			if (rwdInstalled) {
				bf_rewards_ff_step_two();
			}
			else if (bf_rwd_firefox_install_check_counter < 30) {
				bf_rwd_firefox_install_check_counter = bf_rwd_firefox_install_check_counter + 1;
				setTimeout(function () {
					installCounterLocked = false;
				}, 1000);
			}
		});
	};
});