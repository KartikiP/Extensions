var instructionsWrapper = function () {
	return {
		IsChrome: true,
		IsFirefox: false,
		IsSafari: false,
		IsEdge: false,
		curElems: [],
		retailerName: "",
		pageType: "",
		viewportRatio: 1,
		IsEdgium: function () {
			let hasUserAgent = typeof window !== 'undefined' && typeof window.navigator !== 'undefined' && typeof window.navigator.userAgent !== 'undefined';
			return (hasUserAgent && window && window.Navigator && window.navigator.userAgent && /edg/i.test(window.navigator.userAgent));
		},
		getCookie: function (name) {
			var value = "; " + document.cookie;
			var parts = value.split("; " + name + "=");
			if (parts.length == 2) return parts.pop().split(";").shift();
		},
		sendMessage: function (options, responseCallback) {
			if (isChrome) {
				let lastErrorHandler = function (responseData) {
					if (chrome.runtime.lastError) {
						console.debug(options, chrome.runtime.lastError.message);
					}
					if (responseCallback) {
						if (responseData) {
							responseCallback(responseData);
						}
						else {
							responseCallback();
						}
					}
				};
				chrome.runtime.sendMessage(options, lastErrorHandler);
			}
			else
				browser.runtime.sendMessage(options).then(responseCallback);
		},
		addOverlay: function () {
			if (document.getElementById("instructionOverlay") == null) {
				var elemDiv = document.createElement('div');
				elemDiv.id = "instructionOverlay";
				elemDiv.style.cssText = 'position:absolute;width:100%;height:100%;z-index:2001;background:rgba(0, 0, 0, 0.8);top: 0;';

				let svgClose = document.createElementNS("http://www.w3.org/2000/svg", 'svg');
				svgClose.setAttribute("viewBox", "0 0 25 25");
				svgClose.setAttribute("style", "fill: grey;width:20px;float: right; position: relative; right: 30px; top: 30px;cursor:pointer;");
				let svgPath = document.createElementNS("http://www.w3.org/2000/svg", 'path');
				svgPath.setAttribute("d", "M23.954 21.03l-9.184-9.095 9.092-9.174-2.832-2.807-9.09 9.179-9.176-9.088-2.81 2.81 9.186 9.105-9.095 9.184 2.81 2.81 9.112-9.192 9.18 9.1z");
				svgClose.appendChild(svgPath);
				svgClose.addEventListener("click", function () {
					instructionsWrapper.sendMessage({
						request: "TourFinished",
						targetScript: "instructionsInject.js"
					});
				});

				elemDiv.appendChild(svgClose);
				window.document.body.insertBefore(elemDiv, window.document.body.firstChild);
			}
			else
				document.getElementById("instructionOverlay").style.display = "block";
		},
		createImageElem: function (imageName, width, height) {
			var imagePath = chrome.runtime.getURL("/instructionImages/" + imageName);
			var img = document.createElement('img');
			img.src = imagePath;
			img.style.zIndex = "1002";
			img.style.width = width + "px";
			img.style.height = height + "px";
			return img;
		},
		createTextElem: function (text) {
			var span = document.createElement('span');
			span.innerText = text;
			span.style.color = "white";
			span.style.zIndex = "1002";
			span.style.fontFamily = "Kalam";
			return span;
		},
		createTableElem: function (rows, cols) {
			var table = document.createElement('div');
			table.style.zIndex = "1002";
			table.style.marginTop = "0px";
			table.style.position = "absolute";
			table.style.display = "table";

			for (var i = 0; i < rows; i++) {
				var row = document.createElement('div');
				row.id = "row" + (i + 1);
				row.style.paddingTop = 10 * instructionsWrapper.viewportRatio + "px";
				row.style.paddingBottom = 10 * instructionsWrapper.viewportRatio + "px";
				row.style.display = "table-row";
				row.style.width = "100%";
				row.style.textAlign = "start";

				for (var j = 0; j < cols; j++) {
					var col = document.createElement('div');
					col.id = row.id + "col" + (j + 1);
					col.style.display = "table-cell";
					row.appendChild(col);
				}

				table.appendChild(row);
			}
			return table;
		},
		clearElems: function () {
			while (instructionsWrapper.curElems.length > 0) {
				var cur = instructionsWrapper.curElems[0];
				cur.parentNode.removeChild(cur);
				instructionsWrapper.curElems.splice(0, 1);
			}
		},
		getInternalFromCookie: function (cookie) {
			if (cookie != null && cookie.indexOf("store") != -1) {
				var firstBit = "/store/";
				var endBit = "-coupons/";
				var name = cookie.replace(firstBit, "").replace(endBit, "");
				return name;
			}
			else
				return null;
		},
		closeTour: function () {
			//We revert the scrollbar behaviors here when exiting the Tour Mode.
			document.body.style.overflow = "auto";

			instructionsWrapper.clearElems();
			var overlay = document.getElementById("instructionOverlay");
			overlay.style.display = "none";

			var rstTour = document.getElementById("popupTour");
			if (rstTour) rstTour.style.display = "none";
		},
		initialize: function () {
			instructionsWrapper.viewportRatio = (window.innerWidth / window.outerWidth);
			//FF Replace begin
			var viewportHandler = function () {
				instructionsWrapper.viewportRatio = (window.innerWidth / window.outerWidth);
			}
			window.visualViewport.addEventListener('resize', viewportHandler);
			//FF Replace end

			var elemLink = document.createElement("link");
			elemLink.href = "https://fonts.googleapis.com/css?family=Kalam";
			elemLink.rel = "stylesheet";
			window.document.head.insertBefore(elemLink, window.document.head.firstChild);

			chrome.runtime.onMessage.addListener(function (message, sender, sendResponse) {
				if (message.instruction == "Get internal") {
					var cookie = instructionsWrapper.getCookie("ToolbarPage.WelcomePageStyle");
					var parsed = null;
					if (cookie != null)
						parsed = JSON.parse(decodeURIComponent(cookie));
					if (parsed != null)
						sendResponse({ internalName: parsed.Name, type: parsed.PageStyleType });
					else
						sendResponse({ internalName: "mcdonalds", type: "Restaurant" });
				}
				else if (message.instruction == "Step one") {
					setTimeout(function () {
						instructionsWrapper.retailerName = message.retailerName;
						instructionsWrapper.stepOne(message);
					}, 500);
				}
				else if (message.instruction == "PopupOpened")
					instructionsWrapper.stepTwo();
				else if (message.instruction == "ClickedRestaurants")
					instructionsWrapper.stepThree(message);
				else if (message.instruction == "OpeningCoupons")
					instructionsWrapper.stepFour(message.OneStepRST);
				else if (message.instruction == "CloseTour")
					instructionsWrapper.closeTour();
				else if (message.instruction == "TourFinished")
					instructionsWrapper.closeTour();
			});


		},
		stepOne: function (message) {
			let pageType = message.pageType;
			let OneStepRST = message.OneStepRST;
			let isRestaurant = (pageType === "Restaurant");
			instructionsWrapper.pageType = pageType;

			instructionsWrapper.clearElems();

			let oldOverlay = document.querySelector(".modalBackgroundDark:not([style*='display'])");
			if (oldOverlay) oldOverlay.style.display = "none";

			//We hide the scrollbar to prevent users from scrolling out of the view of the Tour Mode.
			document.body.style.overflow = "hidden";

			instructionsWrapper.addOverlay();
			var overlay = document.getElementById("instructionOverlay");
			document.body.scrollTop = "0";
			window.scrollTo(0, 0);

			if (OneStepRST && isRestaurant) {
				instructionsWrapper.stepFour(true);
				return;
			}

			var table = instructionsWrapper.createTableElem(3, 2);

			if (instructionsWrapper.IsFirefox) {
				table.style.right = (115 * instructionsWrapper.viewportRatio) + "px";
				table.style.top = (20 * instructionsWrapper.viewportRatio) + "px";
			}
			else if (instructionsWrapper.IsEdgium()) {
			    table.style.right = (275 * instructionsWrapper.viewportRatio) + "px";
			    table.style.top = (40 * instructionsWrapper.viewportRatio) + "px";	
			}
            else if (instructionsWrapper.IsSafari){
                table.style.left = (425 * instructionsWrapper.viewportRatio) + "px";
                table.style.top = (160 * instructionsWrapper.viewportRatio) + "px";
            }
			else {
				table.style.right = (400 * instructionsWrapper.viewportRatio) + "px";
				table.style.top = (75 * instructionsWrapper.viewportRatio) + "px";	
			}

			overlay.appendChild(table);
			instructionsWrapper.curElems.push(table);

			var row1col1 = document.getElementById("row1col1");
			var row1col2 = document.getElementById("row1col2");
			var row2col1 = document.getElementById("row2col1");
			var row2col2 = document.getElementById("row2col2");
			var row3col1 = document.getElementById("row3col1");
			var row3col2 = document.getElementById("row3col2");

			var upArrow = instructionsWrapper.createImageElem("arrow_01.png", 83, 83);
			var icon = instructionsWrapper.createImageElem("bf_icon.png", 66, 66);
            if(instructionsWrapper.IsSafari){
                upArrow.style.transform = "scaleX(-1)";
                upArrow.style.position = "relative";
                upArrow.style.right = "20px";
                upArrow.style.top = -(30 * instructionsWrapper.viewportRatio + 10) + "px";
                icon.style.marginBottom = (30 * instructionsWrapper.viewportRatio) + "px";
                row1col1.style.paddingLeft = (70 * instructionsWrapper.viewportRatio) + "px";
                row1col1.appendChild(upArrow);
                row1col1.appendChild(icon);
            }
            else {
                upArrow.style.cssFloat = "right";
                icon.style.cssFloat = "right";
                icon.style.marginTop = (40 * instructionsWrapper.viewportRatio) + "px";
				icon.style.marginRight = (15 * instructionsWrapper.viewportRatio) + "px";
				row1col2.style.position = "relative";
				row1col2.style.top = "140px";
				row1col2.appendChild(upArrow);
                row1col2.appendChild(icon);
			}

			var stepSpan = instructionsWrapper.createTextElem("Step 1 of " + (isRestaurant ? "4" : "3"));
			stepSpan.style.fontSize = "14pt";
			stepSpan.style.textDecoration = "underline";
			stepSpan.style.marginTop = (30 * instructionsWrapper.viewportRatio) + "px";
			row2col1.appendChild(stepSpan);


			var clickSpan;
			if (instructionsWrapper.IsChrome || instructionsWrapper.IsEdge) {
				clickSpan = instructionsWrapper.createTextElem("Please click on the Jigsaw ");
				let jigsawImg = instructionsWrapper.createImageElem((instructionsWrapper.IsEdge || instructionsWrapper.IsEdgium() ? "jigsaw-edge.png" : "jigsaw.png"), 30, 31);
				jigsawImg.style.position = "relative";
				jigsawImg.style.top = "7px";
				clickSpan.appendChild(jigsawImg);
				clickSpan.appendChild(instructionsWrapper.createTextElem(" icon above,"));
			}
			else {
				clickSpan = instructionsWrapper.createTextElem("Please click on the BeFrugal button above to view");
            }
			var clickSpanLineTwo = instructionsWrapper.createTextElem("then select the BeFrugal button");
			clickSpan.style.fontSize = clickSpanLineTwo.style.fontSize = "20pt";
			clickSpan.style.fontWeight = clickSpanLineTwo.style.fontWeight = "900";
			row3col1.appendChild(clickSpan);
			row3col1.appendChild(document.createElement('br'));
			if (instructionsWrapper.IsChrome || instructionsWrapper.IsEdge) {
				row3col1.appendChild(clickSpanLineTwo);
				row3col1.appendChild(document.createElement('br'));
			}
			let resTxt = (pageType === "WeeklyAd" ? " Weekly Ad Circular" : " Coupons");
			let resSpan = instructionsWrapper.createTextElem(instructionsWrapper.retailerName);
			resSpan.style.fontSize = "38pt";
			resSpan.style.fontWeight = "900";
			resSpan.style.color = "rgb(144,216,255)";
			let selectSpanView = instructionsWrapper.createTextElem("to view ");
			let selectSpan = instructionsWrapper.createTextElem(resTxt);
			selectSpanView.style.fontSize = selectSpan.style.fontSize = "20pt";
			selectSpanView.style.fontWeight = selectSpan.style.fontWeight = "900";
			if (instructionsWrapper.IsChrome || instructionsWrapper.IsEdge) {
				row3col1.appendChild(selectSpanView);
            }
			row3col1.appendChild(resSpan);
			row3col1.appendChild(selectSpan);
		},
		stepTwo: function () {
			instructionsWrapper.clearElems();
			if (!instructionsWrapper.pageType) {
				instructionsWrapper.pageType = "Restaurant"
            }
			var isRestaurant = (instructionsWrapper.pageType === "Restaurant");
			let isWeeklyAds = (instructionsWrapper.pageType === "WeeklyAd");

			var overlay = document.getElementById("instructionOverlay");
			overlay.style.display = "block";

			var table = instructionsWrapper.createTableElem(3, 1);
			if (instructionsWrapper.IsFirefox) {
				table.style.right = (520 * instructionsWrapper.viewportRatio) + "px";
			}
			else if (instructionsWrapper.IsEdgium()) {
			    table.style.right = (690 * instructionsWrapper.viewportRatio) + "px";
			}
            else if (instructionsWrapper.IsSafari){
                table.style.left = (625 * instructionsWrapper.viewportRatio) + "px";
                table.style.top = ((isRestaurant ? 500 : 375) * instructionsWrapper.viewportRatio) + "px";
            }
			else {
				table.style.right = (745 * instructionsWrapper.viewportRatio) + "px";
			}
            
            if(!instructionsWrapper.IsSafari){
                table.style.top = ((isRestaurant ? 425 : 300) * instructionsWrapper.viewportRatio) + "px";
            }

			overlay.appendChild(table);
			instructionsWrapper.curElems.push(table);

			var row1col1 = document.getElementById("row1col1");
			var row2col1 = document.getElementById("row2col1");
			var row3col1 = document.getElementById("row3col1");

			var stepSpan = instructionsWrapper.createTextElem("Step 2 of " + (isRestaurant ? "4": "3"));
			stepSpan.style.fontSize = "14pt";
			stepSpan.style.textDecoration = "underline";
			row1col1.appendChild(stepSpan);

			var selectSpanInnerOne = document.createElement('span');
			selectSpanInnerOne.innerText = "Please select";
			var selectSpanInnerTwo = document.createElement('span');
			selectSpanInnerTwo.style = "font-weight:900;font-size:38pt;color:rgb(144,216,255);" + (isRestaurant ? "margin-left: 8px;" : "display:block;");
			selectSpanInnerTwo.innerText = (isWeeklyAds ? "Weekly Ad Circulars" : instructionsWrapper.pageType + " Coupons");

			var selectSpan =  instructionsWrapper.createTextElem("");
			selectSpan.style.fontSize = "20pt";
			selectSpan.style.fontWeight = "900";
			selectSpan.appendChild(selectSpanInnerOne);
			selectSpan.appendChild(selectSpanInnerTwo);
			row2col1.appendChild(selectSpan);

			var arrow = instructionsWrapper.createImageElem("arrow_05.png", 110, 25);
            if (instructionsWrapper.IsSafari){
                arrow.style.transform = "scaleX(-1)";
                arrow.style.top = isRestaurant ? "-160px" : "-200px";
                arrow.style.left = "-15px";
                arrow.style.position = "relative";
            }
            else{
                arrow.style.marginRight = ((-40) * instructionsWrapper.viewportRatio) + "px";
                arrow.style.float = "right";
                arrow.style.position = "relative";
                arrow.style.top = "-130px";
                arrow.style.left = "-30px";
            }
			row3col1.appendChild(arrow);
		},
		stepThree: function (message) {
			instructionsWrapper.clearElems();
			if (!instructionsWrapper.pageType) {
				instructionsWrapper.pageType = "Restaurant"
			}
			var isRestaurant = (instructionsWrapper.pageType === "Restaurant");
			let isWeeklyAds = (instructionsWrapper.pageType === "WeeklyAd");
			var overlay = document.getElementById("instructionOverlay");
			var table = instructionsWrapper.createTableElem(4, 1);
			if (instructionsWrapper.IsFirefox) {
				table.style.right = (530 * instructionsWrapper.viewportRatio) + "px";
			}
			else if (instructionsWrapper.IsEdgium()) {
			    table.style.right = (705 * instructionsWrapper.viewportRatio) + "px";
			}
            else if (instructionsWrapper.IsSafari) {
                table.style.left = (625 * instructionsWrapper.viewportRatio) + "px";
            }
			else {
				table.style.right = (770 * instructionsWrapper.viewportRatio) + "px";				
			}
			if (isRestaurant) {
				table.style.top = (130 * instructionsWrapper.viewportRatio) + "px";
			}
			else if (instructionsWrapper.IsFirefox) {
				table.style.top = (290 * instructionsWrapper.viewportRatio) + "px";
			}
			else {
				table.style.top = (240 * instructionsWrapper.viewportRatio) + "px";
            }

			overlay.appendChild(table);
			instructionsWrapper.curElems.push(table);

			var row1col1 = document.getElementById("row1col1");
			var row2col1 = document.getElementById("row2col1");
			var row3col1 = document.getElementById("row3col1");
			var row4col1 = document.getElementById("row4col1");

			var stepSpan = instructionsWrapper.createTextElem("Step 3 of " + (isRestaurant ? "4": "3"));
			stepSpan.style.fontSize = "14pt";
			stepSpan.style.textDecoration = "underline";
			row1col1.appendChild(stepSpan);

			if (isRestaurant) {
				var selectSpan = instructionsWrapper.createTextElem("Find and click on");
				selectSpan.style.fontSize = "20pt";
				selectSpan.style.fontWeight = "900";
				row2col1.appendChild(selectSpan);

				var nameSpan = instructionsWrapper.createTextElem(instructionsWrapper.retailerName);
				nameSpan.style.fontWeight = "900";
				nameSpan.style.fontSize = "38pt";
				nameSpan.style.color = "rgb(144,216,255)";
				row3col1.appendChild(nameSpan);

				var arrow = instructionsWrapper.createImageElem("arrow_03.png", 112, 25);
                if(!instructionsWrapper.IsSafari){
                    arrow.style.float = "right";
                    arrow.style.marginRight = ((-30) * instructionsWrapper.viewportRatio) + "px";
                }
                else{
                    arrow.style.transform = "scaleX(-1)";
                }
				row4col1.appendChild(arrow);
			}
			else {

				var createSpanTypeOne = function (inputText, bold, fontSize, lineheight) {
					let selectSpan = instructionsWrapper.createTextElem(inputText);
					selectSpan.style.fontSize = fontSize ? fontSize + "pt" : "20pt";
					selectSpan.style.lineHeight = (lineheight ? lineheight : (fontSize ? (fontSize + 2) : "22")) + "pt";
					if (bold) selectSpan.style.fontWeight = "900";
					return selectSpan;
				};

				var createSpanTypeTwo = function (inputText) {
					let selectSpan = instructionsWrapper.createTextElem(inputText);
					selectSpan.style.fontWeight = "900";
					selectSpan.style.fontSize = "38pt";
					selectSpan.style.lineHeight= "40pt"
					selectSpan.style.color = "rgb(144,216,255)";
					return selectSpan;
				};

				if (isWeeklyAds) {
					table.style.marginTop = "70px";

					var selectSpan = instructionsWrapper.createTextElem("Find and click on");
					selectSpan.style.fontSize = "20pt";
					selectSpan.style.fontWeight = "900";
					row2col1.appendChild(selectSpan);

					var nameSpan = instructionsWrapper.createTextElem(instructionsWrapper.retailerName);
					nameSpan.style.fontWeight = "900";
					nameSpan.style.fontSize = "38pt";
					nameSpan.style.color = "rgb(144,216,255)";
					nameSpan.style.position = "relative";
					nameSpan.style.top = "10px";

					var arrow = instructionsWrapper.createImageElem("arrow_03.png", 112, 25);
					if (instructionsWrapper.IsFirefox) {
						arrow.style.marginTop = "-90px";
					}
					else {
						arrow.style.marginBottom = "-80px";
                    }
                    
                    if(instructionsWrapper.IsSafari){
                        arrow.style.transform = "scaleX(-1)";
                        row3col1.appendChild(arrow);
                        row4col1.appendChild(nameSpan);
                    }
                    else{
                        arrow.style.float = "right";
                        arrow.style.marginRight = ((-30) * instructionsWrapper.viewportRatio) + "px";
                        row3col1.appendChild(nameSpan);
                        row4col1.appendChild(arrow);
                    }
				}
				else {
					let smallbr = document.createElement('br');
					smallbr.style.fontSize = "5px";
					row2col1.appendChild(smallbr);
					row2col1.appendChild(createSpanTypeOne("There!", true));
					row2col1.appendChild(document.createElement('br'));
					row2col1.appendChild(createSpanTypeOne("Search for ", true));
					row2col1.appendChild(createSpanTypeTwo(instructionsWrapper.retailerName));
					row2col1.appendChild(createSpanTypeOne(" Coupons or", true));
					row2col1.appendChild(document.createElement('br'));
					row2col1.appendChild(createSpanTypeOne("browse by ", true));
					row2col1.appendChild(createSpanTypeTwo("Category"));
					row2col1.appendChild(createSpanTypeOne(" or ", true));
					row2col1.appendChild(createSpanTypeTwo("Brand"));

					row3col1.appendChild(document.createElement('br'));
					var arrow = instructionsWrapper.createImageElem("arrow_03.png", 112, 25);
                    if(!instructionsWrapper.IsSafari){
                        arrow.style.float = "right";
                        arrow.style.marginRight = ((-30) * instructionsWrapper.viewportRatio) + "px";
                    }
                    else{
                        arrow.style.transform = "scaleX(-1)";
                    }
					row3col1.appendChild(arrow);
                }

				//(2/8/21) Removed !message.NoCashBack check that prevented firefox from going in to below
				if (message.Guest || instructionsWrapper.IsFirefox || message.Balance > 0) {
					var bonusAmount = message.Balance > 0 ? message.Balance : "10";
					row3col1.appendChild(document.createElement('br'));
					row4col1.appendChild(document.createElement('br'));
					row4col1.appendChild(createSpanTypeOne("A Welcome Gift For You!", false, 18));
					row4col1.appendChild(document.createElement('br'));
					row4col1.appendChild(createSpanTypeOne("Find", false, 18));
					row4col1.appendChild(createSpanTypeOne(" $" + bonusAmount + " Bonus ", true, 20, 20));
					row4col1.appendChild(createSpanTypeOne("in your account.", false, 18));
					row4col1.appendChild(document.createElement('br'));
					row4col1.appendChild(createSpanTypeOne("Terms apply. New members only", false, 11));
				}
			}
		},
		stepFour: function (isRestaurantOneStep) {
			instructionsWrapper.clearElems();

			instructionsWrapper.addOverlay();
			var overlay = document.getElementById("instructionOverlay");

			var table = instructionsWrapper.createTableElem(4, 1);
			var rstoffset = isRestaurantOneStep ? 150 : 0;
			if (instructionsWrapper.IsFirefox) {
				table.style.right = ((530 + rstoffset) * instructionsWrapper.viewportRatio) + "px";
			}
			else if (instructionsWrapper.IsEdgium()) {
				table.style.right = ((705 + rstoffset) * instructionsWrapper.viewportRatio) + "px";
			}
			else if (!isRestaurantOneStep && instructionsWrapper.IsSafari) {
				table.style.left = ((625 + rstoffset) * instructionsWrapper.viewportRatio) + "px";
            }
			else {
				table.style.right = ((625 + rstoffset) * instructionsWrapper.viewportRatio) + "px";
			}
            
            table.style.top = (140 * instructionsWrapper.viewportRatio) + "px";

			overlay.appendChild(table);
			instructionsWrapper.curElems.push(table);

			var row1col1 = document.getElementById("row1col1");
			var row2col1 = document.getElementById("row2col1");
			var row3col1 = document.getElementById("row3col1");
			var row4col1 = document.getElementById("row4col1");

			if (isRestaurantOneStep) row2col1.style.paddingTop = "25px";

			var stepSpan = instructionsWrapper.createTextElem((isRestaurantOneStep ? "" : "Step 4 of 4"));
			stepSpan.style.fontSize = "14pt";
			stepSpan.style.textDecoration = "underline";

			var arrow = instructionsWrapper.createImageElem("arrow_04.png", 112, 25);
			if(isRestaurantOneStep || !instructionsWrapper.IsSafari){
				arrow.style.float = "right";
				arrow.style.marginRight = ((-30) * instructionsWrapper.viewportRatio) + "px";
			}
			else{
				arrow.style.transform = "scaleX(-1)";
				arrow.style.marginBottom = "30px";
			}

			if (!isRestaurantOneStep && instructionsWrapper.IsSafari){
				row1col1.appendChild(arrow);
				row2col1.appendChild(stepSpan);
			}
			else{
				row1col1.appendChild(stepSpan);
				row2col1.appendChild(arrow);
			}

			var browseSpan = instructionsWrapper.createTextElem("");
			var selectSpanInnerOne = document.createElement('span');
			selectSpanInnerOne.innerText = "Browse ";
			var selectSpanInnerTwo = document.createElement('span');
			selectSpanInnerTwo.style = "font-size:38pt;font-weight:900;color:rgb(144,216,255)";
			selectSpanInnerTwo.innerText =  instructionsWrapper.retailerName;
			var selectSpanInnerThree = document.createElement('span');
			selectSpanInnerThree.innerText =  " coupons";
			browseSpan.style.fontSize = "20pt";
			browseSpan.style.fontWeight = "900";
			browseSpan.appendChild(selectSpanInnerOne);
			browseSpan.appendChild(selectSpanInnerTwo);
			browseSpan.appendChild(selectSpanInnerThree);
			row3col1.appendChild(browseSpan);

			var clickSpan = instructionsWrapper.createTextElem("Click on a coupon to get the offer");
			clickSpan.style.fontWeight = "900";
			clickSpan.style.fontSize = "20pt";
			row4col1.appendChild(clickSpan);

			if (window.innerWidth < 1100) {
				row3col1.style.maxWidth = "600px";
				row4col1.style.maxWidth = "600px";
				row4col1.parentNode.style.maxWidth = "600px";
			}
			else if (window.innerWidth < 1250) {
				row3col1.style.maxWidth = "700px";
				row4col1.style.maxWidth = "700px";
				row4col1.parentNode.style.maxWidth = "700px";
			}

		}
	};
}();

instructionsWrapper.initialize();

