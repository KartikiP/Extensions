var isChrome = true;

function _sendMessage(options, responseCallback) {
	if (isChrome) {
		let lastErrorHandler = function (responseData) {
			if (chrome.runtime.lastError) {
				console.debug(options, chrome.runtime.lastError.message);
			}
			if (responseCallback) {
				if (responseData) {
					responseCallback(responseData);
				}
				else {
					responseCallback();
				}
			}
		};
		chrome.runtime.sendMessage(options, lastErrorHandler);
	}
	else
		browser.runtime.sendMessage(options).then(responseCallback);
}

_sendMessage({
	action: "Preference Manager",
	targetScript: "shoptoolbar.js",
	data: { pref: "Settings" }
}, function (settings) {
	if (settings && settings.disablePageDataPoint) {
		settings.disablePageDataPoint.isUnknown = false;
		_sendMessage({
			action: "OpenDialog",
			targetScript: "disableBackgroundApp.js",
			data: settings.disablePageDataPoint
		});
		_sendMessage({
			action: "Preference Manager",
			targetScript: "shoptoolbar.js",
			data: { pref: "Settings", value: settings }
		});
	} else {
		_sendMessage({
			action: "OpenDialog",
			targetScript: "disableBackgroundApp.js",
			data: { newWidth: 400, newHeight: 320, newURL: "disable/disable_page1.html?localparent=1", isUnknown: false }
		});
	}
});

//NOTE(Thompson): This is for the iframes.
function _BlankSendMessage(target, action, alldata, callback) {
	chrome.runtime.sendMessage({
		targetScript: target,
		action: action,
		data: alldata
	}, function (results) {
		if (chrome.runtime.lastError) {
			console.debug(chrome.runtime.lastError.message);
		}
		callback(results);
	});
}

function closeTab() {
	chrome.tabs.getCurrent(function (tab) {
		chrome.tabs.remove(tab.id, function () { });
	});
}
