chrome.runtime.onMessage.addListener(function (request, sender, sendResponse) {
	if (!request.targetScript || (request.targetScript && request.targetScript !== "cashbackToast.js")) {
		return false;
	}
	switch (request.action) {
		case "setToast":
			let div = document.getElementById('toast_div');
			if (!div) {
				div = document.createElement('div');
				div.setAttribute('id', 'toast_div');
				document.body.insertBefore(div, document.body.firstChild);
			}

			if (!document.querySelector("link[href*=Roboto\\.css]")) {
				let notifyCss = document.createElement('link');
				notifyCss.setAttribute('rel', 'stylesheet');
				notifyCss.setAttribute('href', chrome.runtime.getURL("/fonts/Roboto.css"));
				notifyCss.setAttribute('type', 'text/css');
				let head = document.querySelector('head');
				head.insertBefore(notifyCss, head.firstChild);
			}

			div.setAttribute('xcb', request.data.msg);
			div.setAttribute('xlogo', chrome.runtime.getURL("icon_cb.png"));
			div.innerHTML = DOMPurify.sanitize(request.data.toast, { FORCE_BODY: true });

			var svg_check = div.querySelector("#toast_svg_check");
			var close = div.querySelector('#toast_svg_close');
			var logo = div.querySelector('#toast_logo');
			var span = div.querySelector("#toast_cbText");

			//Initializing variables.
			var cashback = div.getAttribute("xcb");
			var maxOpacity = 1.0;
			var opacitySpeed = 0.04;	//NOTE(Thompson): Variable width takes into account the positioning of the toast message, so only tweak this variable, and don't touch the CSS.
			var svgWidth = 32;
			var logoWidth = 32;

			//Initializing close button actions.
			close.addEventListener("click", function () {
				var div = document.getElementById("toast_div");
				div.style.opacity = 0.0;
				document.body.removeChild(div);
			});

			//If cashback rate contains "Up to...", then we need to increase the width to accommodate the extra letters.
			if (cashback && cashback.toLowerCase().indexOf("up") > -1) {
				cashback = cashback.replace("Cash Back", "");
			}

			logo.setAttribute("src", div.getAttribute("xlogo"));

			svg_check.style.width = (svgWidth + "px");
			svg_check.style.height = (svgWidth + "px");

			if (cashback.toLowerCase().indexOf("activated") > -1)
				span.innerText = cashback.slice(0, -1 * " Activated".length);
			else
				span.innerText = cashback;

			//NOTE(Thompson): Handles the animation part. Pretty bad though, since the fade-in animation is not as smooth as the fade-out animation.
			setTimeout(() => {
				var animation = setInterval(() => {
					var div = document.getElementById("toast_div");
					if (!div) {
						clearInterval(animation);
						return;
					}
					var opacity = Number(div.style.opacity);
					if (opacity < maxOpacity) {
						opacity += opacitySpeed;
						div.style.opacity = opacity.toString();
					}
					else {
						clearInterval(animation);
						setTimeout(() => {
							var div = document.getElementById("toast_div");
							if (div)
								document.body.removeChild(div);
						}, 3000);
					}
				}, 1);
			}, 500);
			return true;
	}
	return false;
});