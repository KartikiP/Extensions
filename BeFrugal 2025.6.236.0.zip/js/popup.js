//Copyright © 2011-2018 Capital Intellect Inc. All Rights Reserved 
//Patents Pending 
var browserAdapter = browserAdapter || (function () {

	return {
		get _BrowserBadgeBackgroundColor() {
			return {
				Default: "#d93025",
				CashbackActive: "#0c7a00",
				Event: "#2196f3"
			};
		},
		_MetricMap(metric) {
			switch (metric) {
				case "TrackPop": return 1;
				case "TestPrepareCoupons": return 2;
				case "SnoozeAutoApply": return 3;
				case "ReportProblemClick": return 4;
				case "ReportCompetitorDialog": return 5;
				case "OrderConfirmation": return 6;
				case "LoginGate": return 7;
				case "EmailCollectionShown": return 8;
				case "CashbackLost": return 9;
				case "CashbackActivated_Upstream": return 10;
				case "CashbackActivated_Manual": return 11;
				case "AutoApplySuccess": return 12;
				case "AutoApplyDialog": return 13;
				case "SyncInstall": return 14;
				case "SyncInstallGuest": return 15;
				case "RetailerInfo": return 16;
				case "PromoteRewardsClick": return 17;
				case "PromoteRewardsClickMetric": return 18;
				case "EasyActivationShown": return 19;
				case "RateUs": return 20;
				case "DisableNotificationsAdd": return 21;
				case "ClickToActivate_Upstream": return 22;
				case "ClickToActivate_Manual": return 23;
				case "ClickToActivate_CartNoCoupons": return 24;
				case "CashbackInjectionEnabled": return 25;
				case "CashbackInjectionClick": return 26;
				case "CashbackInjection": return 27;
				case "Cashback": return 28;
				case "BrowserInitated": return 29;
				case "BefrugalSiteClickout": return 30;
				case "SnoozeShowCoupons": return 31;
				case "ShowCouponsDialog": return 32;
				case "ShowCouponsClicked": return 33;
				case "CloseShowCoupons": return 34;
				case "CloseShowCoupons_Tot": return 35;
				case "CloseAutoApply": return 36;
				case "CloseAutoApply_Tot": return 37;
				case "CloseRewardsPromo": return 38;
				case "CloseActivateCBDialog": return 39;
				case "PopupClickout": return 40;
				case "DisableNotificationsRemove": return 41;
				case "UpstreamSnoozeAndActivate": return 42;
				case "EmbeddedActivateShown": return 43;
				case "EmbeddedActivateClick": return 44;
				case "EmbeddedActivateHideOnSite": return 45;
				case "EmbeddedActivateSnooze": return 46;
				case "EmbeddedAutoApplyShown": return 47;
				case "EmbeddedAutoApplyClick": return 48;
				case "EmbeddedAutoApplySnooze": return 49;
				case "EmbeddedCodeDropdownSnooze": return 50;
				case "EmbeddedCodeDropdownClick": return 51;
				case "EmbeddedCodeDropdownShown": return 52;
				case "EmbeddedAutoApplyHideOnSite": return 53;
				case "SideTabShown": return 54;
				case "SideTabClick": return 55;
				case "SideTabSnooze": return 56;
			}
			return metric;
		},
		_TourExecute(tab) {
			if (shoptoolbar._Browser === shoptoolbar.Browsers.iOS) return;
			BfrlTool.BrowserStorage.TourInfo.then(function (tourInfo) {
				tourInfo = tourInfo || {};
				tourInfo.WelcomeScreenId = tab.id;
				BfrlTool.BrowserStorage.TourInfo = tourInfo;
			
				browserAdapter._ExecuteScript(tab.id, "js/instructionsInject.js", function (result) {
					var tourCallback = function (response) {
						//restaurant tour
						if (response && response.type === "Restaurant") {
							if (shoptoolbar._Browser === shoptoolbar.Browsers.Firefox)
								browser.tabs.setZoom(tab.id, 1);
							else if (shoptoolbar._Browser === shoptoolbar.Browsers.Chrome)
								chrome.tabs.setZoom(tab.id, 1, function () { });
							shoptoolbar._GetInstallStoreInfo(response.internalName, function (retailerName, retailerId, imageUrl) {
								tourInfo.TourRetailer = tourInfo.TourRetailer || {};
								tourInfo.TourRetailer.retailerId = retailerId;
								tourInfo.TourRetailer.retailerName = retailerName;
								tourInfo.TourRetailer.imageUrl = imageUrl;
								tourInfo.TourRetailer.pageType = response.type;
								tourInfo.OneStepRST = (response.type === "Restaurant");
								BfrlTool.BrowserStorage.TourInfo = tourInfo;
								browserAdapter._SendTabMessage(tab.id, {
									instruction: "Step one", retailerName: retailerName, pageType: response.type, OneStepRST: tourInfo.OneStepRST
								}, function () {
									if (tourInfo.OneStepRST) {
										browserAdapter._SendTabMessage(tab.id, {
											action: "popupIframe",
											targetScript: "autoApplyContent.js",
											browser: shoptoolbar._Browser
										});
									}
								});
							});
						}
						//Grocery Tour
						else if (response && response.type === "Grocery") {
							tourInfo.TourRetailer = tourInfo.TourRetailer || {};
							tourInfo.TourRetailer.retailerName = response.internalName;
							tourInfo.TourRetailer.pageType = response.type;
							BfrlTool.BrowserStorage.TourInfo = tourInfo;
							browserAdapter._SendTabMessage(tab.id, {
								instruction: "Step one", retailerName: response.internalName, pageType: response.type
							});
						}
						//Weekly Tour
						else if (response && response.type === "WeeklyAd") {
							shoptoolbar._GetInstallStoreInfo(response.internalName, function (retailerName, retailerId, imageUrl) {
								tourInfo.TourRetailer = tourInfo.TourRetailer || {};
								tourInfo.TourRetailer.retailerId = retailerId;
								tourInfo.TourRetailer.retailerName = retailerName;
								tourInfo.TourRetailer.imageUrl = imageUrl;
								tourInfo.TourRetailer.pageType = response.type;
								BfrlTool.BrowserStorage.TourInfo = tourInfo;
								browserAdapter._SendTabMessage(tab.id, {
									instruction: "Step one", retailerName: retailerName, pageType: response.type
								});
							});
						}
						else {
							tourInfo.TourMode = false;
							BfrlTool.BrowserStorage.TourInfo = tourInfo;
							tabDataCollection._Get(tab.id).then(function (tabData) {
								tabData[tab.id]._WelcomePage = true;
								BfrlTool.BrowserStorage.SetTabData(tabData).then(function () {
									browserAdapter._ExecuteScript(tab.id, shoptoolbar._Browser === shoptoolbar.Browsers.Mac ? "js/iframeInjectMac.js" : "js/iframeInject.js");
								});
							})
						}
					};

					browserAdapter._SendTabMessage(tab.id, {
						instruction: "Get internal"
					}, tourCallback);
				});
			});
		},
		_ShowWelcomePage() {
			if (shoptoolbar._Browser === shoptoolbar.Browsers.iOS || BfrlTool.BrowserStorage.LocalCache["MacInstalling"]) return;

		    BfrlTool.BrowserStorage.TourShown = "shown";
			var tourPage = "";
			IsBeFrugalButtonOrClassic(function (isClassic) {
				Promise.all([BfrlTool.BrowserStorage.TourInfo, shoptoolbar.ToolbarVersionPromise, BfrlTool.BrowserStorage.InstallType]).then(function ([tourInfo, toolbarVersion, installType]) {
					if (installType === "Sync")
						return;
					tourInfo = tourInfo || {};
					tourInfo.TourMode = isClassic && !tourInfo.NoTour;
					BfrlTool.BrowserStorage.TourInfo = tourInfo;
					tourPage = "https://" + shoptoolbar.Site + "/addon/installationcomplete/?signup=1&toolbarversion=" + toolbarVersion;

					if (shoptoolbar._Browser === shoptoolbar.Browsers.Chrome) {
						browserAdapter.CreateTab(tourPage, function (tabinfo) {
							browserAdapter.ActivateTab(tabinfo.id);
						});
					}
					else if (shoptoolbar._Browser === shoptoolbar.Browsers.Edge) {
						browser.tabs.query({ currentWindow: true }, (tabs) => {
							for (var i = 0; i < tabs.length; i++) {
								if (tabs[i].url.indexOf("www.befrugal.com/lp/") > -1) {
									browser.tabs.update(tabs[i].id, { "active": true, url: tourPage });
									return;
								}
							}
							browser.tabs.create({ url: tourPage });
						});
					}
					else {
						browserAdapter.CreateTab(tourPage, function (tabinfo) {
							browserAdapter.ActivateTab(tabinfo.id);
						});
					}
				});
			});
		},
		_SendTabMessage(tabId, message, callback) {            
			if (!callback) callback = function () { };
			let newcallback = function (data) {
				if (chrome.runtime.lastError) {
					console.debug(chrome.runtime.lastError.message);
				}
				callback(data);
			};
		    if (shoptoolbar._Browser === shoptoolbar.Browsers.Chrome) {
		        chrome.tabs.sendMessage(tabId, message, newcallback);
		    }
			else if (shoptoolbar._Browser === shoptoolbar.Browsers.Edge) {
		        browser.tabs.sendMessage(tabId, message, callback);
			}
			else {
				browser.tabs.sendMessage(tabId, message).then(newcallback).catch(() => {});
			}
		},
		_ExecuteScript(tabId, filePath, callback) {
			if (BfrlTool.BrowserStorage.LocalCache["MacInstalling"]) return;
			if (!callback) callback = function () { };

			let lastErrorHandler = function (responseData) {
				if (chrome.runtime.lastError) {
					console.debug(chrome.runtime.lastError.message);
				}
				if (callback) {
					if (responseData) {
						callback(responseData);
					}
					else {
						callback();
					}
				}
			};

			if (shoptoolbar._Browser === shoptoolbar.Browsers.Chrome)
				chrome.scripting.executeScript({
					target: { tabId: tabId },
					files: [filePath]
				}, lastErrorHandler);
			else if (shoptoolbar._Browser === shoptoolbar.Browsers.Edge) {
				browser.tabs.executeScript(tabId, { file: filePath }, callback);
			}
			else {
				var executing = browser.tabs.executeScript(tabId, { file: filePath });
				executing.then(lastErrorHandler).catch((error) => { console.debug("error: " + error); return 0; });
			}
		},
		_GetURL(path) {
			if (!path)
				path = "";
			if (shoptoolbar._Browser === shoptoolbar.Browsers.Chrome)
				return chrome.runtime.getURL(path);
			else
				return browser.runtime.getURL(path);
		},
		_InsertCSS(tabId, details, callback) {
			if (shoptoolbar._Browser === shoptoolbar.Browsers.Chrome)
				chrome.tabs.insertCSS(tabId, details, callback);
			else if(shoptoolbar._Browser === shoptoolbar.Browsers.Edge)
				browser.tabs.insertCSS(tabId, details, callback);
			else {
				var executing = browser.tabs.insertCSS(tabId, details);
				executing.then(callback).catch(function (error) { console.debug("error: " + error); });
			}
		},
		_SetIcon(icon) {
			if (shoptoolbar._Browser === shoptoolbar.Browsers.Chrome)
				chrome.action.setIcon({
					path: icon
				});
			else if (shoptoolbar._Browser === shoptoolbar.Browsers.Edge) {
				browser.browserAction.setIcon({
					path: icon
				});
			}
			else if (shoptoolbar._Browser === shoptoolbar.Browsers.Mac) {
				if (icon === shoptoolbar.ActiveIcon) {
					shoptoolbar.GetCurrentABrowser(function (aBrowser) {
						if (aBrowser && aBrowser._CashbackActivated && (aBrowser._RetailerInfo.CashbackRate && aBrowser._RetailerInfo.CashbackRate.length > 0)) {
							icon = shoptoolbar.ActivatedIcon
						}
						browser.browserAction.setIcon({
							path: icon
						});
					});
				}
				else {
					browser.browserAction.setIcon({
						path: icon
					});
                }
            }
			else
				browser.browserAction.setIcon({
					path: icon
				});
		},
		_SetBadgeText(text) {
			if (!text) {
				text = '';
            }
			if (shoptoolbar._Browser === shoptoolbar.Browsers.Chrome) {
				chrome.action.setBadgeText({ text: text });
			}
			else {
				browser.browserAction.setBadgeText({ text: text });
			}
		},
		_GetBadgetext(callback) {
			if (shoptoolbar._Browser === shoptoolbar.Browsers.Chrome) {
				chrome.action.getBadgeText({}, callback);
			}
			else {
				browser.browserAction.getBadgeText({}).then(callback)
			}
		},
		_SetIconBackgroundColorEvent() {
			if (shoptoolbar._Browser === shoptoolbar.Browsers.Chrome)
				chrome.action.setBadgeBackgroundColor({ color: browserAdapter._BrowserBadgeBackgroundColor.Event });
			else
				browser.browserAction.setBadgeBackgroundColor({ color: browserAdapter._BrowserBadgeBackgroundColor.Event });
		},
		//NOTE: setBadgeBackgroundColor() doesn't support callback functions.
		_SetIconBackgroundColor(isCashbackActivated) {
			//couponviewer is no longer ctivating cash back for the user
			BfrlTool.BrowserStorage.NoCashBackExtension.then(function (cashbackdisabled) {
				let stringHexColor = (isCashbackActivated && !cashbackdisabled) ? browserAdapter._BrowserBadgeBackgroundColor.CashbackActive : browserAdapter._BrowserBadgeBackgroundColor.Default;
				if (shoptoolbar._Browser === shoptoolbar.Browsers.Chrome)
					chrome.action.setBadgeBackgroundColor({ color: stringHexColor });
				else
					browser.browserAction.setBadgeBackgroundColor({ color: stringHexColor });
			});
		},
		_SetUninstallURL(lastActions) {
			var browserType = shoptoolbar._Browser === shoptoolbar.Browsers.Chrome ? chrome : browser;
			BfrlTool.BrowserStorage.UserToken.then(function (userToken) {
				IsBeFrugalButtonOrClassic(function (isClassic) {
					var uninstallURL = "https://befrugal.com/toolbar/uninstall/?extension=" + (isClassic ? "2" : "1") + "&bfuser=" + encodeURIComponent(userToken);
					if (!shoptoolbar._IsBF)
						uninstallURL = "https://www.surveymonkey.com/r/799BBS7";
					else if (lastActions) {
						let s_last_actions = lastActions.map((s) => browserAdapter._MetricMap(s.Key) + "." + s.Value + "." + s.Time).join();
						while ((s_last_actions.length + uninstallURL.length + 4) > 1023) {
							lastActions = lastActions.slice(0, -1);
							s_last_actions = lastActions.map((s) => browserAdapter._MetricMap(s.Key) + "." + s.Value + "." + s.Time).join();
						}
						uninstallURL = uninstallURL + "&la=" + s_last_actions;
					}
					browserType.runtime.setUninstallURL(uninstallURL);
				});
			});
		},
		_GetDomainFromUrl: function (url) {
			var hostname;
			//find & remove protocol (http, ftp, etc.) and get hostname

			if (url.indexOf("://") > -1)
				hostname = url.split('/')[2];
			else
				hostname = url.split('/')[0];

			//find & remove port number
			hostname = hostname.split(':')[0];
			//find & remove "?"
			hostname = hostname.split('?')[0];

			if (hostname.startsWith("www"))
				hostname = hostname.substring(4);

			return hostname;
		},
		UpdateWindow: function (windowId, updateInfo, callback) {
		    if (!windowId) return;
		    if (!callback)
		        callback = function (tab) { };
		    if (shoptoolbar._Browser === shoptoolbar.Browsers.Chrome) {
		        chrome.windows.update(windowId, updateInfo, callback);
		    }
			else if (shoptoolbar._Browser === shoptoolbar.Browsers.Edge) {
		        browser.windows.update(windowId, updateInfo, callback);
			}
			else {
				browser.windows.update(windowId, updateInfo).then(callback);
			}
		},
		GetWindow: function (windowId, queryOptions, callback) {
			if (!windowId) return;
			if (!queryOptions) queryOptions = {};
			if (!callback)
				callback = function (tab) { };

			if (shoptoolbar._Browser === shoptoolbar.Browsers.Chrome) {
				chrome.windows.get(windowId, queryOptions, callback);
			}
			else if (shoptoolbar._Browser === shoptoolbar.Browsers.Edge) {
				browser.windows.get(windowId, queryOptions, callback);
			}
			else {
				browser.windows.get(windowId, queryOptions).then(callback);
			}
		},
		CurrentWindow: function (queryOptions, callback) {
			if (!queryOptions) queryOptions = {};
			if (!callback)
				callback = function (tab) { };

			if (shoptoolbar._Browser === shoptoolbar.Browsers.Chrome) {
				chrome.windows.getCurrent(queryOptions, callback);
			}
			else if (shoptoolbar._Browser === shoptoolbar.Browsers.Edge) {
				browser.windows.getCurrent(queryOptions, callback);
			}
			else {
				browser.windows.getCurrent(queryOptions).then(callback);
			}
		},
		CreateTab: function (navUri, callback, backgroundTab, tabindex) {
		    let active = true;
		    if (backgroundTab) active = false;
			let tabInfo = {
			    active: active,
				url: navUri
			};
			if (tabindex) tabInfo.index = tabindex;
			if (!callback)
				callback = function (tab) { };
			if (shoptoolbar._Browser === shoptoolbar.Browsers.Chrome && chrome && chrome.tabs) {
				chrome.tabs.create(tabInfo, callback);
			}
			else if (shoptoolbar._Browser === shoptoolbar.Browsers.Edge && browser && browser.tabs) {
				browser.tabs.create(tabInfo, callback);
			}
			else if (browser && browser.tabs) {
				browser.tabs.create(tabInfo).then(callback);
			}
			else {
				window.open(navUri);
			}
		},
		UpdateTab: function (tabId, navUri, callback) {
		    let tabInfo = {
		        active: true,
				url: navUri
			};
			if (!tabId)
				tabId = null;
			if (!callback)
				callback = function (tab) {};
			if (shoptoolbar._Browser === shoptoolbar.Browsers.Chrome) {
				chrome.tabs.update(tabId, tabInfo, callback);
			}
			else if (shoptoolbar._Browser === shoptoolbar.Browsers.Edge) {
				browser.tabs.update(tabId, tabInfo, callback);
			}
			else {
				browser.tabs.update(tabId, tabInfo).then(callback);
			}
		},
		GetTab: function (tabId, callback) {
			if (BfrlTool.BrowserStorage.LocalCache["MacInstalling"]) return;
            
			if (shoptoolbar._Browser === shoptoolbar.Browsers.Chrome) {
				let newcallback = function (data) {
					if (chrome.runtime.lastError) {
						if (chrome.runtime.lastError.message == "Tabs cannot be edited right now (user may be dragging a tab).") {
							setTimeout(function () { browserAdapter.GetTab(tabId, callback); }, 100);
						}
						else {
							console.debug(chrome.runtime.lastError.message);
						}
					}
					callback(data);
				};
				chrome.tabs.get(tabId, newcallback);
			}
			else if (shoptoolbar._Browser === shoptoolbar.Browsers.Edge){
				browser.tabs.get(tabId, callback);
			}
			else {
				browser.tabs.get(tabId).then(callback);
			}
		},
		ActivateTab: function (tabId) {
		    if (shoptoolbar._Browser === shoptoolbar.Browsers.Chrome) {
		        chrome.tabs.update(tabId, {
		            active: true
				});
		    }
		    else {
		        browser.tabs.update(tabId, {
                    active: true
                });
		    }
		},
		ReloadTab: function (tabId) {
			if (shoptoolbar._Browser === shoptoolbar.Browsers.Chrome) {
				chrome.tabs.reload(tabId);
			}
			else {
				browser.tabs.reload(tabId);
			}
		},
		GetActiveTab: function (useCurrentWindow, callback) {
			if (BfrlTool.BrowserStorage.LocalCache["MacInstalling"]) return;
            
			var query = { active: true };
			if (useCurrentWindow)
				query.currentWindow = true;
			else
				query.windowType = "normal";
			if (shoptoolbar._Browser === shoptoolbar.Browsers.Chrome)
				chrome.tabs.query(query, (tabs) => {
					if (chrome.runtime.lastError) {
						if (chrome.runtime.lastError.message == "Tabs cannot be queried right now (user may be dragging a tab).") {
							setTimeout(function () { browserAdapter.GetActiveTab(useCurrentWindow, callback); }, 100);
						}
						else {
							console.debug(chrome.runtime.lastError.message);
						}
					}
					if (tabs && tabs.length > 0)
						callback(tabs[0]);
					else
						callback(null);
				});
			else if (shoptoolbar._Browser === shoptoolbar.Browsers.Edge) {
				browser.tabs.query(query, (tabs) => {
					if (tabs && tabs.length > 0)
						callback(tabs[0]);
					else
						callback(null);
				});
			}
			else {
				browser.tabs.query(query).then((tabs) => {
					if (tabs && tabs.length > 0)
						callback(tabs[0]);
					else
						callback(null);
				});
			}
		},
		GetAllTabs: function (callback) {
			if (BfrlTool.BrowserStorage.LocalCache["MacInstalling"]) return;
            
			if (shoptoolbar._Browser === shoptoolbar.Browsers.Chrome && chrome && chrome.tabs) {
				chrome.tabs.query({}, (tabs) => {
					if (chrome.runtime.lastError) {
						if (chrome.runtime.lastError.message == "Tabs cannot be queried right now (user may be dragging a tab).") {
							setTimeout(function () { browserAdapter.GetAllTabs(callback); }, 100);
						}
						else {
							console.debug(chrome.runtime.lastError.message);
						}
					}
					callback(tabs);
				});
			}
			else if (shoptoolbar._Browser === shoptoolbar.Browsers.Edge && browser && browser.tabs) {
				browser.tabs.query({}, (tabs) => {
					callback(tabs);
				});
			}
			else if (browser && browser.tabs) {
				browser.tabs.query({}).then((tabs) => {
					callback(tabs);
				});
			}
			else {
				callback([])
			}
		},
		CloseTab: function (tabId, callback) {
		    if (!callback) callback = function () { };
		    if (shoptoolbar._Browser === shoptoolbar.Browsers.Chrome) {
		        chrome.tabs.remove(tabId, callback);
		    }
		    else if (shoptoolbar._Browser === shoptoolbar.Browsers.Edge) {
		        browser.tabs.remove(tabId, callback);
		    }
		    else {
		        browser.tabs.remove(tabId).then(callback);
		    }
		},
		CreateNewWindow: function (createData,callback) {
		    if (!callback) callback = function () { };
		    if (shoptoolbar._Browser === shoptoolbar.Browsers.Chrome) {
		        chrome.windows.create(createData,callback);
		    }
		    else if (shoptoolbar._Browser === shoptoolbar.Browsers.Edge) {
		        browser.windows.create(createData, callback);
		    }
		    else {
		        browser.windows.create(createData).then(callback);
		    }
		}
	};
})();
//Copyright © 2011-2018 Capital Intellect Inc. All Rights Reserved 
//Patents Pending 

var BfrlTool = {
    BrowserStorage: {
        LocalCache: { MacInstalling: false }
    }
};

var Browsers = {
    Chrome: 0,
    Firefox: 1,
    Edge: 2,
    Mac: 3,
    iOS: 4
};

var Stores= {
    Chrome: 0,
    Firefox: 1,
    Microsoft: 2,
    Mac: 3
};


var macHide = true;
var shoptoolbar = { _Browser: Browsers.Chrome, Browsers: Browsers };
var isChrome = shoptoolbar._Browser === Browsers.Chrome;
var Site = 'www.befrugal.com';
var APISite = 'https://tbwsjs.befrugal.com';
var CDNSite = 'https://tbwsjsan.bfrl.us';
var isBF = true;

var Format = function (str) {
    var args = Array.prototype.slice.call(arguments, 1);
    return str.replace(/{(\d+)}/g, function (match, number) {
        return typeof args[number] !== 'undefined' ? args[number] : "";
    });
};

var settings;
var userToken;
var isShopper;
var notallowed;
var declinedDate;
var autoApplyData;
var isSuppressed;
var activeTab;
var isButton;
var nocashback;
var runTimeId;
var toolbarVersion;
var defaultPreferences;
var storeSource;
var tourInfo;
var skin;
var bsGuest;
var noUser = false;

const MaxStoresPerSection = 6;
const MaxDeals = 12;
const MaxStoresTotal = 50;
const bfSite = "www.befrugal.com";
const guidePage = isButton ? "https://www.befrugal.com/toolbar/lp/buttonguide.aspx" : "https://www.befrugal.com/toolbar/lp/addonguide.aspx";
const MOUSE_BUTTON_MAIN = 0;
const ENABLE_BANNER_SCROLL = true;
const ENABLE_BANNER_TITLE = false;

const SearchInputEventState = {
    KEY_PRESS: 1,
    MOUSE: 2
};

const _PopupContentEnum = {
    Retailer: "retailerContent",
    Homepage: "homeContent",
    Settings: "settingsContent",
    Help: "helpContent",
    SearchDeals: "searchEngineDealsContent"
};

var searchInputValue = "";
var currentSearchInputState = SearchInputEventState.MOUSE;

var currentCashbackrate;

var isTour = false;

var isAnonymous;
var recentDeclined;

if (window.screen.width < 750){
    document.body.style.setProperty("width", "100%")
}

function noCookCheck() {
    return (noUser && storeSource === Stores.Mac) || isAnonymous;
};

function GetAnonymity(callback) {
    if (!settings || !settings.Config || !settings.Config.PrivacyPrompt) {
        callback(false);
    }
    else if (typeof isAnonymous !== "undefined" && (isAnonymous === true || isAnonymous === false)) {
        callback(isAnonymous);
    }
    else {
        //they declined within X days
        if (settings.Config.PrivacyPrompt.CounterEnabled && notallowed && declinedDate && declinedDate.length > 0) {
            let date = Date.now();
            let DENIEDSPAN = 1000 * 60 * 60 * 24 * settings.Config.PrivacyPrompt.Days; //Ten days
            recentDeclined = ((date - declinedDate) / DENIEDSPAN < 1.0);
        }
        else recentDeclined = false;

        if (notallowed) isAnonymous = true;
        else isAnonymous = false;
        callback(isAnonymous);
    }
}

function _sendMessage(options, responseCallback) {

    if (options && !options.activeTab) {
        options.activeTab = activeTab;
    }

    if (isChrome) {
        let lastErrorHandler = function (responseData) {
            if (chrome.runtime.lastError) {
                console.debug(options, chrome.runtime.lastError.message);
            }
            if (responseCallback) {
                if (responseData) {
                    responseCallback(responseData);
                }
                else {
                    responseCallback();
                }
            }
        };
        chrome.runtime.sendMessage(options, lastErrorHandler);
    }
    else
        browser.runtime.sendMessage(options).then(responseCallback);
}

function _FetchJsonPost(url, callback) {
    _FetchJsonPostCustom(url, Format("UserToken={0}&toolbarversion={1}", encodeURIComponent(userToken), toolbarVersion), callback);
}

function _FetchJsonPostCustom(url, body, callback) {
    _sendMessage({
        action: "FetchJsonPost",
        targetScript: "shoptoolbar.js",
        data: {
            url: url,
            params: {
                method: "POST",
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded'
                },
                body: body
            }
        }
    }, callback);
}

function GetBadgetext(callback) {
    if (isChrome) {
        chrome.action.getBadgeText({}, callback);
    }
    else {
        browser.browserAction.getBadgeText({}).then(callback)
    }
};

function _applyCouponsHandler(event) {
    let handleButtonClick = function () {
        if (autoApplyData.ShowCouponsApp.IsShowingCoupons) {
            _sendMessage({
                request: "TourFinished",
                targetScript: "instructionsInject.js",
                data: { tabId: activeTab.id }
            }, function () {
                _closePopup();
            });
        }
        else {
            _sendMessage({
                action: "manualTestPrepareCoupons",
                targetScript: "autoApplyApp.js",
                data: { tabId: activeTab.id }
            }, function () {
                _closePopup();
            });
        }
    };
    GetAnonymity(function (notallowed) {
        if (!currentCashbackrate || (notallowed && !recentDeclined && !nocashback)) {
            privacyDialog(true, function (allowed) {
                handleButtonClick();
            });
        }
        else {
            handleButtonClick();
        }
    });
}

function searchSuggestionOnNavigateHandler(event) {
    let searchSuggestionList = document.querySelector("#newSearchSuggestions");
    if (searchSuggestionList.style.display === "block" && (event.key === "ArrowUp" || event.key === "ArrowDown")) {
        if (currentSearchInputState !== SearchInputEventState.KEY_PRESS) {
            currentSearchInputState = SearchInputEventState.KEY_PRESS;
            let mouseHighlightedItem = searchSuggestionList.querySelector("#newSuggestionsList li.mouseHighlighted");
            if (mouseHighlightedItem) {
                if (mouseHighlightedItem.classList.contains("mouseHighlighted")) {
                    mouseHighlightedItem.classList.remove("mouseHighlighted");
                }
            }
        }

        let highlightedItem = searchSuggestionList.querySelector("#newSuggestionsList li.highlighted");
        let checkIfHighlighted = highlightedItem != null;
        let itemAboveHighlighted = null;
        let itemBelowHighlighted = null;
        if (checkIfHighlighted) {
            //Previously, there exists a highlighted item.
            itemAboveHighlighted = highlightedItem.previousElementSibling;
            itemBelowHighlighted = highlightedItem.nextElementSibling;

            if (event.key === "ArrowUp") {
                if (itemAboveHighlighted != null) {
                    itemAboveHighlighted.classList.add("highlighted");
                    let endText = itemAboveHighlighted.querySelector(".newSuggestionEndText");
                    if (endText.innerText.toLowerCase().indexOf("cash back") > -1) {
                        itemAboveHighlighted.classList.add("cb");
                    }
                    highlightedItem.classList.remove("highlighted");
                    if (highlightedItem.classList.contains("cb") && !highlightedItem.classList.contains("mouseHighlighted")) {
                        highlightedItem.classList.remove("cb");
                    }
                }
            }
            else if (event.key === "ArrowDown") {
                if (itemBelowHighlighted != null) {
                    itemBelowHighlighted.classList.add("highlighted");
                    let endText = itemBelowHighlighted.querySelector(".newSuggestionEndText");
                    if (endText.innerText.toLowerCase().indexOf("cash back") > -1) {
                        itemBelowHighlighted.classList.add("cb");
                    }
                    highlightedItem.classList.remove("highlighted");
                    if (highlightedItem.classList.contains("cb") && !highlightedItem.classList.contains("mouseHighlighted")) {
                        highlightedItem.classList.remove("cb");
                    }
                }
            }
        }
        else {
            //No highlighted item was found, most likely the start of navigating.
            let selectedItem = searchSuggestionList.querySelectorAll("#newSuggestionsList li")[0];
            if (selectedItem && selectedItem.style.visibility === "visible") {
                selectedItem.classList.add("highlighted");
                let endText = selectedItem.querySelector(".newSuggestionEndText");
                if (endText.innerText.toLowerCase().indexOf("cash back") > -1) {
                    selectedItem.classList.add("cb");
                }
            }
        }
    }
    else {
        let highlightedItems = searchSuggestionList.querySelector("#newSuggestionsList li.highlighted[style*='visible']");
        if (Array.isArray(highlightedItems) && highlightedItems.length > 0) {
            for (let i = 0; i < highlightedItems.length; i++) {
                highlightedItems.classList.remove("highlighted");
                if (highlightedItems.classList.contains("cb")) {
                    highlightedItems.classList.remove("cb");
                }
            }
        }
    }
}

/**
 * Closes the browserAction popup window when triggered after 100 milliseconds. 
 */
function _closeBrowserActionPopups() {
    let popups;
    if (isChrome)
        popups = chrome.extension.getViews({
            type: "popup"
        });
    else
        popups = browser.extension.getViews({
            type: "popup"
        });
    if (popups && popups.length) {
        setTimeout(() => {
            for (let i = 0; i < popups.length; i++)
                popups[i].close();
        }, 100);
    }
}

function _openLinkUrlMatch(tabUrl, targetUrl) {
    return ((tabUrl === targetUrl || tabUrl === targetUrl + "/") && tabUrl.indexOf(Site + "/coupons/search/") < 0);
}

/**
 * Opens a new tab in the current browser window. If such a tab with the specified link is found, it will set that tab to be the active tab.
 * @param {string} targetUrl - The intended URL to open.
 */
function _openLink(targetUrl, reloadWhenAlreadyPresent) {
    if (isTour && (!tourInfo || !tourInfo.OneStepRST)) {
        _sendMessage({
            request: "TourFinished",
            targetScript: "instructionsInject.js"
        }, function () {
            isTour = false;
            _openLink(targetUrl);
            return;
        });
    }
    else {
        browserAdapter.GetAllTabs(function (tabs) {
            //make tab that has same url as active
            let hasTabs = (tabs && tabs.length > 0);
            if (hasTabs) {
                let foundTabs = tabs.filter(s => _openLinkUrlMatch(s.url.toLowerCase(), targetUrl.toLowerCase()));
                if (foundTabs.length > 0) {
                    browserAdapter.ActivateTab(foundTabs[0].id);
                    if (reloadWhenAlreadyPresent) {
                        browserAdapter.ReloadTab(foundTabs[0].id);
                    }
                    _closePopup();
                }
                else hasTabs = false;
            }
            //else navigate this tab to url
            if (!hasTabs) {
                browserAdapter.CreateTab(targetUrl, () => { _closePopup(); }, false);
            }
        });
    }
}

function _openLinkInCurrentTab(targetUrl) {
    if (isTour) {
        _sendMessage({
            request: "TourFinished",
            targetScript: "instructionsInject.js"
        }, function () {
            isTour = false;
            _openLinkInCurrentTab(targetUrl);
            return;
        });
    }
    else {
        //navigate this tab to url
        browserAdapter.UpdateTab(null,targetUrl);
    }
}

function _closePopup() {
    let namespace = isChrome ? chrome : browser;
    let popupWindows = namespace.extension.getViews({ type: "popup" });
    for (let i = 0; i < popupWindows.length; i++)
        popupWindows[i].close();
}

function _suggestionListen(elem, id, uri, internalName, internalId, nocashback) {

    if (popup._SearchListeners[id])
        elem.removeEventListener("click", popup._SearchListeners[id]);

    var listener = function () {
        //try to redirect to retailer through redirector
        if (internalName || (internalId && ((typeof internalId === "string" && internalId !== "-1") || internalId > -1))) {

            let redirectToRetailer = function () {
                //if we know internalid redirect to store without any more lookups
                if (internalId && ((typeof internalId === "string" && internalId !== "-1") || internalId > -1)) {
                    _sendMessage({
                        action: "GetSearchRetailerRedirectURL",
                        targetScript: "shoptoolbar.js",
                        data: { internalId: internalId, internalName: internalName }
                    }, function (results) {
                        _sendMessage({
                            action: "AddMetricData",
                            targetScript: "shoptoolbar.js",
                            data: { Metric: "PopupClickout", Value: internalId }
                        });
                        let redirectUrl = results[0];
                        let exists = results[1];
                        if (exists) {
                            _openLink(redirectUrl);
                            _closeBrowserActionPopups();
                        }
                        else {
                            _sendMessage({
                                action: "sptool",
                                targetScript: "shoptoolbar.js",
                                data: { function: "GetRetailerInfo", args: [internalId, true] }
                            }, function (retailer) {
                                if (!retailer) {
                                    _openLink(redirectUrl);
                                }
                                else {
                                    _preRedirectMessaging(redirectUrl, retailer);
                                }
                            });
                        }
                    });
                }
                else {
                    //If we only have internal name, lookup id
                    _sendMessage({
                        action: "sptool",
                        targetScript: "shoptoolbar.js",
                        data: { function: "GetRetailerInfoSearch", args: [reinternalNametailerid] }
                    }, function (retailer) {
                        if (retailer && retailer.RetailerInfo && retailer.RetailerInfo.RetailerID) {
                            _sendMessage({
                                action: "GetSearchRetailerRedirectURL",
                                targetScript: "shoptoolbar.js",
                                data: { internalId: retailer.RetailerInfo.RetailerID, internalName: item.InternalName }
                            }, function (results) {
                                _sendMessage({
                                    action: "AddMetricData",
                                    targetScript: "shoptoolbar.js",
                                    data: { Metric: "PopupClickout", Value: retailer.RetailerInfo.RetailerID }
                                });
                                let redirectUrl = results[0];
                                let exists = results[1];
                                if (exists) {
                                    _openLink(redirectUrl);
                                    _closeBrowserActionPopups();
                                } else {
                                    _preRedirectMessaging(redirectUrl, retailer.RetailerInfo);
                                }
                            });
                        }
                        //no internal id, go to befrugal retailer page
                        else {
                            _openLink(Format("https://{0}{1}", Site, uri));
                            _closeBrowserActionPopups();
                        }
                    });
                }
                document.getElementById("newSearchSuggestions").style.display = "none";
                document.getElementById('newSearchBar').value = "";
            };

            GetAnonymity(function (notallowed) {
                if (!nocashback && notallowed && !recentDeclined) {
                    privacyDialog(true, function (allowed) {
                        if (allowed || recentDeclined) {
                            redirectToRetailer();
                        }
                        else {
                            //refocus the search suggestions and text box to put them back
                            document.getElementById("newSearchBar").focus();         
                            document.getElementById("newSearchSuggestions").style.display = "block";
                        }
                    });
                }
                else {
                    redirectToRetailer();
                }
            });
        }
        //no internal id, go to befrugal page (grocery, merchant, weekly ad link, etc.)
        else {
            _openLink(Format("https://{0}{1}", Site, uri));
            _closeBrowserActionPopups();
        }
    };
    elem.addEventListener("click", listener);
    popup._SearchListeners[id] = listener;
}

function _preRedirectMessaging(redirectUrl, rInfo) {
    let logoSRC = 'https:' + rInfo.ImgUrl;
    let rName = rInfo.RetailerName;
    let retailerHeader = document.getElementById('retailerSpecific');
    let fillerHolder = document.getElementById('retailerOffersContainer');
    let reTitle = document.getElementById('headerRetailerName');
    let nonretailerHeader = document.getElementById("nonretailer");
    let imgContainer = document.getElementById('headerRetailerImage');
    let dealsOrOffers = document.getElementById('dealsOrOffersDiv');

    //Hides the deals or offers links if they're there.
    dealsOrOffers.style.display = 'none';

    let allActionButtons = document.getElementById('headerActionButtonsContainer').getElementsByClassName('clearFloat');
    let actionButton = document.getElementById('headerRetailerActivateCB');
    for (let iterator = 0; iterator < allActionButtons.length; iterator++) {
        allActionButtons[iterator].style.display = 'none';
    }
    //Initializes the Add to Favorites button.
    let retailerid = rInfo.RetailerID;
    let addFavoriteButton = document.querySelector("#headerRetailerAddFavorites");
    if (noUser) {
        addFavoriteButton.style.visibility = "hidden";
    }
    let favoritesCheck = popup._FavoritesList.filter(x => x && x.retailerID === parseInt(retailerid)).length > 0;
    if (!favoritesCheck) {
        //It's removed.
        if (popup._FavoritesList.length < MaxStoresTotal) {
            addFavoriteButton.style.color = "#d0d0d0";
        }
        else addFavoriteButton.style.display = "none";
    }
    else {
        //It's added.
        addFavoriteButton.style.color = "#ed1c24";
    }
    addFavoriteButton.onclick = function (e) {
        FavoriteIt(retailerid, addFavoriteButton);
        e.preventDefault();
        return false;
    }
    actionButton.style.display = 'flex';
    actionButton.style.height = '54px';
    actionButton.style.lineHeight = '20px';
    actionButton.style.paddingTop = '7px';
    actionButton.style.fontSize = '14px';
    actionButton.style.top = '9px';
    actionButton.innerText = "";
    if (shoptoolbar._Browser === Browsers.iOS) {
        actionButton.style.width = '100%';
        actionButton.style.borderRadius = '27px';
        actionButton.style.paddingLeft = '15px';
        actionButton.style.paddingRight = '15px';
    }
    else {
        actionButton.appendChild(document.createTextNode("Go to BeFrugal site"));
    }
    let fillerText = "Coupons are only available directly through the store page on BeFrugal.com site.";
    if (rInfo.CashbackRate != null) {
        fillerText = "Cash Back and " + fillerText;
        if (shoptoolbar._Browser === Browsers.iOS) {
            actionButton.appendChild(document.createTextNode("Activate " + rInfo.CashbackRate));
            actionButton.appendChild(document.createElement("br"));
            actionButton.appendChild(document.createTextNode("on BeFrugal Site"));
        }
        else {
            actionButton.appendChild(document.createTextNode(" to"));
            actionButton.appendChild(document.createElement("br"));
            actionButton.appendChild(document.createTextNode("Activate " + rInfo.CashbackRate));
        }
    } else {
        actionButton.appendChild(document.createElement("br"));
        actionButton.appendChild(document.createTextNode("to shop at this store"));
    }

    reTitle.innerText = rName;
    if (shoptoolbar._Browser !== Browsers.iOS) {
        nonretailerHeader.classList.remove("show");
    }
    retailerHeader.classList.add("show");
    _ToggleHeaderForIOS(true);
    
    imgContainer.src = logoSRC;
    fillerHolder.classList.add('activationNotice');
    fillerHolder.style.fontStyle = 'italic';
    fillerHolder.innerText = fillerText;
    let miniListener = function () {
        _openLink(redirectUrl);
        _closeBrowserActionPopups();
    };
    // TODO make a new div for the minilistener... later.
    actionButton.onclick = miniListener;
    popup._CurrentPopupContent = _PopupContentEnum.Retailer;
    popup._EnableContent();
}

/**
 * Handles "mouseover" and "mouseout" events as the mouse cursor moves over each search suggestion items in the
 * search suggestion box after the user enters in a search query. It refreshes the "mouseover" and "mouseout"
 * listeners whenever a new search query is entered in.
 * @param {HTMLElement} elem - HTML element to apply the event listeners to.
 * @param {Number} index - The index of the search suggestion, from top to bottom.
 * @param {HTMLElement} endText - The text that shows the cashback rate
 * @param {Object[]} row - The entire row.
 * @param {String} normalText - The string to append to the search suggestion item.
 */
function _endTextMouseOverListen(elem, index, endText, row, normalText) {
    const UpperCaseMaxLength = 25;

    if (popup._EndTextListeners[index])
        elem.removeEventListener("mouseover", popup._EndTextListeners[index]);
    if (popup._EndTextOutListeners[index])
        elem.removeEventListener("mouseout", popup._EndTextOutListeners[index]);

    var clearKeyPressHighlighted = function () {
        currentSearchInputState = SearchInputEventState.MOUSE;
        let highlightedItem = document.querySelector("#newSuggestionsList li.highlighted");
        if (highlightedItem) {
            highlightedItem.classList.remove("highlighted");
            highlightedItem.classList.remove("cb");
        }
        let searchSuggestionItems = document.querySelectorAll("#newSuggestionsList li");
        for (let i = 0; i < searchSuggestionItems.length; i++) {
            searchSuggestionItems[i].classList.remove("previousHighlighted");
        }
    };

    var listenerStore = function () {
        if (currentSearchInputState === SearchInputEventState.MOUSE) {
            clearKeyPressHighlighted();
            elem.classList.add("mouseHighlighted");
            if (endText.innerText.toLowerCase().indexOf("cash back") > -1)
                elem.classList.add("cb");
        }
    };

    var listenerOthers = function () {
        if (currentSearchInputState === SearchInputEventState.MOUSE) {
            clearKeyPressHighlighted();
            elem.classList.add("mouseHighlighted");
            if (endText.innerText.toLowerCase().indexOf("cash back") > -1)
                elem.classList.add("cb");
        }
    };

    var mouseOut = function () {
        currentSearchInputState = SearchInputEventState.MOUSE;
        elem.classList.remove("mouseHighlighted");
        if (endText.innerText.toLowerCase().indexOf("cash back") > -1)
            elem.classList.remove("cb");
    };

    if(shoptoolbar._Browser !== Browsers.Mac)
    {
        if (row.TemplateName === "Store" && row.TemplateParameters[5] !== "" && row.URL.indexOf("restaurant") === -1) {
            elem.addEventListener("mouseover", listenerStore, false);
            elem.addEventListener("mouseout", mouseOut, false);
            popup._EndTextListeners[index] = listenerStore;
            popup._EndTextOutListeners[index] = mouseOut;
        }
        else {
            elem.addEventListener("mouseover", listenerOthers, false);
            elem.addEventListener("mouseout", mouseOut, false);
            popup._EndTextListeners[index] = listenerOthers;
            popup._EndTextOutListeners[index] = mouseOut;
        }
    }
}

function _cashbackTermsHandler(evt) {
    let elementTarget = evt.target;
    let retailerIdString = elementTarget.getAttribute("rid");
    let retailerIdKeyString = "key_" + retailerIdString;

    let rContent = document.querySelector("#retailerContent .ss-content");
    if (rContent) rContent.scrollTop = 0;

    //Terms are stored in JSON to prevent dead object in firefox when dom is altered
    var mappedTerms = popup.CashbackTerms.get(retailerIdKeyString);
    if (mappedTerms) mappedTerms = JSON.parse(mappedTerms);

    //Caching the retailer store's cashback terms to prevent extensive API calls.
    if (!mappedTerms || !mappedTerms.terms || ((new Date().getTime() - mappedTerms.date) > 1000 * 60 * 60 * 6)) {
        //Obfuscation purposes, intentionally written this way.
        let url = "https://" + Site + "/BefrugalSiteWS.asmx/ShowTermsForRetailerMobile";
        let params = "retailerid=" + retailerIdString;
        let uri = url + "?" + params;
        fetch(uri).then(response => response.text()).then(txt => new window.DOMParser().parseFromString(txt, "text/xml")).then((xmlResult) => {
            let GetNodeFactory = function (xmlDoc) {
                return function (xpath) {
                    var tmp = xmlDoc.evaluate(xpath, xmlDoc.documentElement, function () {
                        return 'http://tempuri.org/';
                    }, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue;
                    if (tmp === null) return null;
                    return tmp;
                };
            };
            let GetNodeTextContentFactory = function (xmlDoc) {
                return function (xpath) {
                    var tmp = GetNodeFactory(xmlDoc)(xpath);
                    if (tmp === null) return null;
                    return tmp.textContent;
                };
            };

            let cbTermsContainer = document.querySelector("#retailerCBTermsContainer");
            var GetNodeTextContentFunction = GetNodeTextContentFactory(xmlResult);
            var stringOutput = GetNodeTextContentFunction("/x:string");

            stringOutput = stringOutput.replaceAll("/help/cashback/", "/addon/howitworks/");
            stringOutput = stringOutput.replaceAll("href", "target='_blank' href");
            stringOutput = stringOutput.replaceAll("href='/", "href='https:www.befrugal.com/");
            stringOutput = stringOutput.replaceAll('href="/', 'href="https:www.befrugal.com/');

            cbTermsContainer.innerHTML = DOMPurify.sanitize(stringOutput, { ADD_ATTR: ['target'] });

            //Override the CSS property after the terms CSS <style> has been loaded.
            let div = cbTermsContainer.querySelector(".merchant-terms-active");
            div.style.boxShadow = "rgba(0, 0, 0, 0.3) 2px 2px 3px 0px";
            if (shoptoolbar._Browser !== Browsers.iOS) {
                div.style.width = "380px";
                div.style.margin = "0 auto";
            }
            div.style.position = "relative";
            div.style.border = "1px solid #ccc";

            let termsAndExclusions = cbTermsContainer.querySelector("#cbTerms_TermsAndExclusionsList");
            if ((!termsAndExclusions) || (termsAndExclusions && termsAndExclusions.innerText.length <= 0)) {
                //Only when the terms and exclusions are empty, or it doesn't exist, do we then add padding to it.
                //By default, we fetch the terms from the API "ShowTermsForRetailerNoLinks". "NoLinks" refers to
                //the empty div cashback link: None is given.
                let divCashbackLink = cbTermsContainer.querySelector("#cbTerms_dvCashBack");
                if (divCashbackLink) {
                    divCashbackLink.style.paddingBottom = "30px";
                }
            }

            //Display the results.
            let retailerCBTerms = document.querySelector("#retailerCBTerms");
            retailerCBTerms.classList.remove("cbTerms_hide");
            retailerCBTerms.classList.add("cbTerms_show");

            //close window when a link is clicked
            let anchorTags = retailerCBTerms.querySelectorAll("a");
            for (let r = 0; r < anchorTags.length; r++) {
                anchorTags[r].addEventListener("click", function () {
                    setTimeout(function () { _closePopup(); }, 500);
                });
            }

            //Store in to the cache.
            popup.CashbackTerms.set(retailerIdKeyString, JSON.stringify({ terms: stringOutput, date: new Date().getTime() }));
        });
    }
    else {
        let cbTermsContainer = document.querySelector("#retailerCBTermsContainer");
        cbTermsContainer.innerHTML = DOMPurify.sanitize(mappedTerms.terms, { ADD_ATTR: ['target'] });
        //Override the CSS property after the terms CSS <style> has been loaded.
        let div = cbTermsContainer.querySelector(".merchant-terms-active");
        div.style.boxShadow = "rgba(0, 0, 0, 0.3) 2px 2px 3px 0px";
        if (shoptoolbar._Browser !== Browsers.iOS) {
            div.style.width = "380px";
            div.style.margin = "0 auto";
        }
        else {
            div.style.width = "100%";
        }
        div.style.position = "relative";
        div.style.border = "1px solid #ccc";

        //Display the results.
        let retailerCBTerms = document.querySelector("#retailerCBTerms");
        retailerCBTerms.classList.remove("cbTerms_hide");
        retailerCBTerms.classList.add("cbTerms_show");

        //close window when a link is clicked
        let anchorTags = retailerCBTerms.querySelectorAll("a");
        for (let r = 0; r < anchorTags.length; r++) {
            anchorTags[r].addEventListener("click", function () {
                setTimeout(function () { _closePopup(); }, 500);
            });
        }
    }
}

function _autoCompleteHandler(searchBar, searchSuggestions) {
    if (searchBar.value.length > 0) {
        _sendMessage({
            action: "sptool",
            targetScript: "shoptoolbar.js",
            data: { function: "GetSearchAutoComplete", args: [searchBar.value] }
        }, function (rows) {
            if (rows !== null && rows.length > 0) {
                searchSuggestions.style.display = "block";
                let i;
                for (i = 0; i < rows.length && i < 10; i++) {

                    let internalId = (rows[i].SearchInternalID) ? rows[i].SearchInternalID : null;

                    var suggText = rows[i].SearchFriendlyName;
                    if (rows[i].TemplateName === "Category") {
                        suggText = rows[i].TemplateParameters[0];
                    }

                    if (suggText.length > 36) {
                        suggText = suggText.substring(0, 33) + "...";
                    }

                    let searchSuggestion = document.getElementById("newSearchSuggestion" + i);
                    searchSuggestion.style.visibility = "visible";
                    searchSuggestion.style.display = "list-item";
                    searchSuggestion.classList.remove("highlighted");
                    searchSuggestion.classList.remove("cb");

                    let suggestionText = document.getElementById("newSuggestionText" + i);
                    suggestionText.innerText = suggText;
                    suggestionText.title = rows[i].SearchFriendlyName;

                    let suggestionEndText = document.getElementById("newEndText" + i);

                    _endTextMouseOverListen(searchSuggestion, i, suggestionEndText, rows[i], rows[i].TemplateParameters[5]);

                    if (rows[i].TemplateName === "Store") {
                        if (rows[i].TemplateParameters[5] === "" || nocashback) {
                            suggestionEndText.innerText = rows[i].TemplateParameters[7];
                            suggestionEndText.style.color = "#424242";
                            suggestionEndText.style.fontWeight = 400;
                        }
                        else {
                            suggestionEndText.innerText = rows[i].TemplateParameters[5];
                            suggestionEndText.style.color = "#129500";
                            suggestionEndText.style.fontWeight = 600;
                        }
                        _suggestionListen(searchSuggestion, i, rows[i].URL, rows[i].SearchInternalName, internalId, nocashback);
                    }
                    else if (rows[i].TemplateName === "Grocery") {
                        if (parseInt(rows[i].TemplateParameters[1]) > 1)
                            suggestionEndText.innerText = rows[i].TemplateParameters[1] + " grocery coupons";
                        else
                            suggestionEndText.innerText = rows[i].TemplateParameters[1] + " grocery coupon";
                        suggestionEndText.style.color = "#424242";
                        suggestionEndText.style.fontWeight = 400;

                        _suggestionListen(searchSuggestion, i, rows[i].URL);
                    }
                    else if (rows[i].TemplateName === "Category") {
                        suggestionEndText.innerText = "Category";
                        suggestionEndText.style.color = "#424242";
                        //_suggestionListen(searchSuggestion, index, rows[i].URL);
                    }
                }
                for (; i < 10; i++) {
                    let suggestionText = document.getElementById("newSuggestionText" + i);
                    suggestionText.innerText = "";
                    suggestionText.title = "";

                    let searchSuggestion = document.getElementById("newSearchSuggestion" + i);
                    searchSuggestion.style.visibility = "hidden";
                    searchSuggestion.style.display = "none";
                    searchSuggestion.style.backgroundColor = "";
                    searchSuggestion.style.padding = "0px";
                    searchSuggestion.classList.remove("highlighted");
                    searchSuggestion.classList.remove("cb");

                    document.getElementById("newEndText" + i).innerText = "";
                }
            }
            else {
                searchSuggestions.style.display = "none";
            }
        });
    }
    else {
        //We show a list of pre-defined, hardcoded list of stores to the user.
        //TODO(Thompson): Scott will be making a new API call that will populate the search suggestions list with hardcoded retailers.
        searchSuggestions.style.display = "none";
    }
}

function _searchButtonHandler(searchInputValue) {
    let SearchUrlCleanup = function(link) {
        return link.replace(/&/g, "[and]").replace(/%26/g, "[and]").replace(/\*/g, "[ast]").replace(/\+/g, "[plus]").replace(/\?/g, "[ques]").replace(/@/g, "[em]")
            .replace(/%/g, "[percent]").replace(/:/g, "[colon]").replace(/</g, "[openang]").replace(/>/g, "[closeang]").replace(/\//g, "[slash]").replace(/\\/g, "[backslash]")
            .replace(/[\u2018\u2019]/g, "'")/*this is called out seperately, since this is a keyboard dependant apostraphe*/.replace(/[\u{0080}-\u{FFFFF}]/gu, "");
    }
    if (searchInputValue.length > 0) {
        _openLink("https://" + Site + "/coupons/search/" + SearchUrlCleanup(searchInputValue) + "/");
    }
}

/**
 * (IMPORTANT) Do make sure the aBrowser._CashbackActivated and/or AutoApplyApp.CheckoutPageReady flags are both ready.
 * This is a private function, used for toggling the various cashback activation buttons to display to the user. 
 * @param {boolean} cashbackActivated - True, if cashback is activated. False, if otherwise.
 * @param {HTMLElement} activateCashbackButton - The button to activate cashbacks.
 * @param {HTMLElement} applyButton - The button to start AutoApply Coupons.
 * @param {HTMLElement} cashbackTermsLink - Cashback terms link.
 * @param {HTMLElement} cashbackRateText - The element that stores the cashback rate.
 * @param {HTMLElement} noDiscountsText - The element that displays, "No Discounts".
 * @param {HTMLElement} couponsOnlyText - The element that displays, "Coupons Only".
 * @param {boolean} hasCashbackRates
 * @param {boolean} hasCouponOffers
 */
function _UpdateActionButton(cashbackActivated, activateCashbackButton, applyButton, cashbackTermsLink, cashbackRateText, noDiscountsText, couponsOnlyText, hasCashbackRates, hasCouponOffers) {
    //First, we need to check if the retailer has cashback rates and if retailer has coupon offers available.
    if (hasCashbackRates) {
        //We only have cashback rates, but no coupon offers.
        noDiscountsText.style.display = "none";
        couponsOnlyText.style.display = "none";
        applyButton.style.display = "none";

        //Check if cashback is activated or not.
        if (cashbackActivated) {
            //Cashback is activated.
            activateCashbackButton.style.display = "none";
            cashbackRateText.style.display = "block";

            //Cashback Terms handling
            cashbackTermsLink.addEventListener("click", _cashbackTermsHandler);
        }
        else {
            //Cashback is NOT activated.
            activateCashbackButton.style.display = "flex";
            cashbackRateText.style.display = "none";
        }
    }
    else if (hasCouponOffers) {
        //Only coupon offers, but no cashback rates
        noDiscountsText.style.display = "none";
        cashbackRateText.style.display = "none";

        if (activateCashbackButton)
            activateCashbackButton.style.display = "none";

        // Apply button is now off the table, will clean up... eventually
        applyButton.style.display = "none";
        couponsOnlyText.style.display = "block";
    }
    else {
        //No discounts at all
        noDiscountsText.style.display = "none";

        cashbackRateText.style.display = "none";
        activateCashbackButton.style.display = "none";
        couponsOnlyText.style.display = "block";
        applyButton.style.display = "none";
    }
}

function PopulateOffers(json, retailerOffersContainer, retailerDealsContainer, activateCashbackButton, applyButton, cashbackTermsLink, cashbackRateText, noDiscountsText, couponsOnlyText, dbRow) {
    let shouldPopulateOffers = false;
    let shouldAddFoundCouponCodes = false;
    let isRestaurant = json.RetailerInfo.IsRestaurant;
    let offerCodes = [];
    let offersCount = 0;
    let dealsCount = 0;
    let noCodeOffers = 0;

    _sendMessage({
        action: "sptool",
        targetScript: "shoptoolbar.js",
        data: { function: "GetCurrentABrowser" }
    }, function (aBrowser) {
        let statusCheck = aBrowser && aBrowser.requestStatus && /complete/i.test(aBrowser.requestStatus) && !isSuppressed;
        let hasdata = autoApplyData && autoApplyData.AllCouponCodes && autoApplyData.ShowCouponsApp;
        if (statusCheck && hasdata && autoApplyData.AllCouponCodes.length > 0 && autoApplyData.AutoApplyCheckoutPage && !autoApplyData.ShowCouponsApp.IsShowingCoupons) {
            new Promise(function (resolve) {
                if (autoApplyData.CheckoutPageReady) {
                    resolve(true);
                }
                else {
                    _sendMessage({
                        action: "readyCheck",
                        targetScript: "autoApplyApp.js",
                        data: { tabId: activeTab.id }
                    }, function (isValid) {
                        resolve(isValid);
                    });
                }
            }).then(function (isValid) {
                if (!isValid || autoApplyData.ShowCouponsApp.IsShowingCoupons) return;

                currentCashbackrate = aBrowser._RetailerInfo.CashbackRate !== "" ? true : false;

                let uniqueCouponCount = autoApplyData.AllCouponCodes.length + autoApplyData.ExtraCodes.length;
                if (autoApplyData.AllCouponCodesTryMore) {
                    uniqueCouponCount = autoApplyData.AllCouponCodes.length + autoApplyData.AllCouponCodesTryMore.length;
                }

                let foundMessage = "COUPON CODE" + (uniqueCouponCount > 1 ? "S" : '');
                let showApplyMessage = "Apply Coupon" + (uniqueCouponCount > 1 ? 's' : "");

                let couponTotal = document.createElement("div");
                couponTotal.id = "overallCheckoutContainer";
                couponTotal.style = "width: 100%; background-color: #fff; display: 'block'; border: 1px solid #efefef; padding-top: 10px; padding-bottom: 10px;";

                let dvfoundCouponsButton = document.createElement("div");
                dvfoundCouponsButton.classList = "messageContent";
                dvfoundCouponsButton.style = "margin: 0 0 0 0 !important;";

                let dvtotalTwo = document.createElement("div");
                dvtotalTwo.classList = "group textCenter";
                dvtotalTwo.style = "margin: 0 0 0 0 !important;";

                let spnCouponTotalOne = document.createElement("span");
                spnCouponTotalOne.classList = "bfrl_boldface orange";
                spnCouponTotalOne.style = "line-height: 1; font-size: 54px !important; vertical-align: middle !important; margin-right: 15px !important;";
                spnCouponTotalOne.id = "couponTotal";
                spnCouponTotalOne.innerText = uniqueCouponCount.toString();

                let spnCouponTotalTwo = document.createElement("span");
                spnCouponTotalTwo.classList = "bfrl_boldface orange";
                spnCouponTotalTwo.style = "font-size: 20px !important; font-weight: 400 !important; vertical-align: middle !important;";
                spnCouponTotalTwo.id = "couponTotalMessage";
                spnCouponTotalTwo.innerText = foundMessage;

                dvtotalTwo.appendChild(spnCouponTotalOne);
                dvtotalTwo.appendChild(spnCouponTotalTwo);
                dvfoundCouponsButton.appendChild(dvtotalTwo);

                let dvButtonContainer = document.createElement("div");
                dvButtonContainer.classList = "buttonContainer";
                dvButtonContainer.id = "buttonContainer";

                let btnButton = document.createElement("button");
                btnButton.classList = "bfrl_boldface textCenter bfrl_bigButton orange_bg";
                btnButton.id = "couponButton";
                btnButton.setAttribute("type", "button");
                btnButton.addEventListener("click", _applyCouponsHandler);

                let spnButton = document.createElement("span");
                spnButton.classList = "showApplyText";
                spnButton.style = "line-height:'1.5';";
                spnButton.id = "couponTotalMessage";
                spnButton.innerText = showApplyMessage;

                btnButton.appendChild(spnButton);
                dvButtonContainer.appendChild(btnButton);

                couponTotal.appendChild(dvfoundCouponsButton);
                couponTotal.appendChild(dvButtonContainer);


                if (retailerOffersContainer.childNodes && retailerOffersContainer.childNodes.length > 0) {
                    retailerOffersContainer.insertBefore(couponTotal, retailerOffersContainer.childNodes[0]);
                }
                else {
                    retailerOffersContainer.appendChild(couponTotal);
                }
            });
        }

        let populateOffersArea = function (addSubmitReceipt) {
            if (json.Offers && json.Offers.length > 0) {
                shouldPopulateOffers = true;
                if (addSubmitReceipt) {
                    _sendMessage({
                        action: "sptool",
                        targetScript: "shoptoolbar.js",
                        data: { function: "GetReferralLinks" }
                    }, function (refLinks) {
                        let qs = "?rid=" + json.RetailerInfo.RetailerID + '&bfuser=' + encodeURIComponent(userToken) + ' & toolbarversion=' + toolbarVersion;
                        let fakeOffer = {
                            OfferPageURL: 'https://www.befrugal.com/toolbar/submitreceipt/' + qs,
                            RetailerID: json.RetailerInfo.RetailerID,
                            OfferName: (refLinks.SignupBonus ? (refLinks.SignupBonus + " ") : "") + "Restaurant Bonus for " + json.RetailerInfo.RetailerName,
                            OfferDescription: "Offer valid once per customer.",
                            OfferCode: "",
                            EndDateUTC: "9998-12-31T05:00:00Z",
                            TodayOnly: false,
                            Classification: 150,
                            MobileClassification: { Name: "OnlineCoupon", Value: 0 },
                            OfferId: 0,
                            RedirectUrl: 'https://www.befrugal.com/toolbar/submitreceipt/' + qs,
                        };
                        let fakeHTML = popup._FormatOfferLink(fakeOffer, [], activateCashbackButton, applyButton, cashbackTermsLink, cashbackRateText, noDiscountsText, couponsOnlyText, isRestaurant, dbRow);
                        let fakeTitle = fakeHTML.querySelector('.itemTitle');
                        fakeTitle.classList.remove('itemTitle');
                        fakeTitle.classList.add('itemTitleOrange');
                        retailerOffersContainer.prepend(fakeHTML);
                    });
                    offersCount++;
                }

                //reorder codes so ones with offers are on top while preserving ordering
                let offersWithCodes = json.Offers.filter(s => s.OfferCode);
                let offersWithoutCodes = json.Offers.filter(s => !s.OfferCode);
                json.Offers = offersWithCodes.concat(offersWithoutCodes);

                let duplicates = [];
                let offerNames = [];
                let deals = [];
                for (let i = 0; i < json.Offers.length; i++) {
                    let offer = json.Offers[i];
                    //Override the default rows count, in case we want to show more deals/offers in the future.
                    //add offercodes to list to skip duplicates
                    if (offer.isMerged) {
                        continue;
                    }
                    if (offer.OfferCode && offer.OfferCode.length > 0) {
                        let upperOffer = offer.OfferCode.toUpperCase();
                        let offerName = offer.OfferName;
                        if (duplicates.indexOf(upperOffer) >= 0 && offerNames.indexOf(offerName) >= 0) {
                            continue;
                        }
                        else {
                            if (!offer.NameModified && offer.MobileClassification.Value !== 800) {
                                //fetch all duplicates
                                let duplicateOffers = json.Offers.filter(s => s.OfferCode && s.OfferCode.toUpperCase() === upperOffer && s.Classification !== 800 && !s.NameModified);
                                for (let j = 1; j < duplicateOffers.length; j++) {
                                    if (json.Offers.indexOf(duplicateOffers[j]) >= 0) {
                                        json.Offers[json.Offers.indexOf(duplicateOffers[j])].isMerged = true;
                                    }
                                }
                                //combine name
                                if (duplicateOffers.length > 1) {
                                    offer.matchingOffers = duplicateOffers;
                                    offer.NameModified = true;
                                }
                            }
                            //add so it skips from now on
                            duplicates.push(upperOffer);
                            offerNames.push(offerName);
                        }
                    }

                    let dealOrOfferHTML;
                    if (offer.MobileClassification.Value == 800) {
                        deals.push([offer, new Date(offer.CreatedDateUTC)]);
                    }
                    else {
                        dealOrOfferHTML = popup._FormatOfferLink(offer, offerCodes, activateCashbackButton, applyButton, cashbackTermsLink, cashbackRateText, noDiscountsText, couponsOnlyText, isRestaurant, dbRow);
                        offersCount++;
                        if (dealOrOfferHTML.classList.contains("itemGetOffer")) {
                            noCodeOffers++;
                        }
                        retailerOffersContainer.appendChild(dealOrOfferHTML);
                    }
                }

                deals.sort(function (a, b) {
                    return a[1] - b[1];
                }).reverse();
                for (let i = 0; i < deals.length; i++) {
                    let offer = deals[i][0];
                    offer.OfferPrice = offer.OfferDealPrice;
                    offer.RetailerName = '';
                    dealOrOfferHTML = popup._FormatDealLink(offer, dealsCount);
                    retailerDealsContainer.appendChild(dealOrOfferHTML);
                    dealsCount++;
                }

                retailerDealsContainer.style.gridTemplateRows = "repeat(" + (json.length / 2) + ", 1fr)";
            }
        };

        let populateAdditionalCodesArea = function () {
            let dealCodes = ((json.Offers && json.Offers.length > 0) ? json.Offers.filter(s => s.MobileClassification.Value === 800 && s.OfferCode && s.OfferCode.length > 0).map(s => s.OfferCode) : []);
            if ((Array.isArray(json.CouponBlob.AdditionalCodes) && json.CouponBlob.AdditionalCodes.length > 0) || dealCodes.length > 0) {

                //return if already present
                if (document.getElementById("publicCodes")) return;

                shouldAddFoundCouponCodes = true;
                let additionalCodes = [];
                let offerCodes = ((json.Offers && json.Offers.length > 0) ? json.Offers.filter(s => s.MobileClassification.Value !== 800 && s.OfferCode && s.OfferCode.length > 0).map(s => s.OfferCode.trim()) : []);   
                for (let r = 0; r < dealCodes.length; r++) {
                    let dealUpper = dealCodes[r].trim().toUpperCase();
                    if (offerCodes.indexOf(dealUpper) < 0 && additionalCodes.map(s => s.toUpperCase()).indexOf(dealUpper) < 0) {
                        additionalCodes.push(dealCodes[r]);
                    }
                }
                if (json.CouponBlob.AdditionalCodes) {
                    for (let t = 0; t < json.CouponBlob.AdditionalCodes.length; t++) {
                        if (additionalCodes.map(s => s.toUpperCase()).indexOf(json.CouponBlob.AdditionalCodes[t].toUpperCase()) < 0) {
                            additionalCodes.push(json.CouponBlob.AdditionalCodes[t]);
                        }
                    }
                }

                if (additionalCodes.length > 0) {
                    let totalCouponCodes = additionalCodes.length;

                    let anchor = document.createElement("a");
                    anchor.id = "publicCodes";
                    anchor.classList.add("itemContainer");
                    anchor.style.setProperty("padding", "10px 20px");

                    //Disables right-clicking in the browser popup and hides the option to open things we never intended to be opened in a new tab.
                    anchor.removeAttribute("href");

                    let dvOffer = document.createElement("div");
                    dvOffer.id = "publicTitle";
                    dvOffer.style = "font-size: 16px;cursor:pointer; text-align: center; margin: 0 auto; padding-top: 7px;";

                    let spnOfferOne = document.createElement("span");
                    spnOfferOne.style = "font-weight: 600; font-size: 16px;color:rgb(242, 138, 98);";
                    spnOfferOne.innerText = totalCouponCodes + " " + (totalCouponCodes !== 1 ? "coupon codes" : "coupon code");
                    let spnOfferTwo = document.createElement("span");
                    spnOfferTwo.innerText = " submitted by members";
                    spnOfferTwo.style = "font-size:16px;";

                    dvOffer.appendChild(spnOfferOne);
                    dvOffer.appendChild(spnOfferTwo);

                    let dvViewButton = document.createElement("div");
                    dvViewButton.id = "viewButton";
                    dvViewButton.style = "font-size: 16px; color: #2196f3; width: 100%; text-align: center; margin: 0 auto;";

                    let spnViewOne = document.createElement("span");
                    spnViewOne.innerText = "View ";
                    spnViewOne.style = "font-weight: 600; font-size:16px;";
                    let spnViewTwo = document.createElement("span");
                    spnViewTwo.classList = "icon-chevron-right";
                    spnViewTwo.id = "publuciChevron";
                    spnViewTwo.style = "position: relative; top: 1px; font-size: 14px;";

                    dvViewButton.appendChild(spnViewOne);
                    dvViewButton.appendChild(spnViewTwo);

                    let dvPublicCouponListContainer = document.createElement("div");
                    dvPublicCouponListContainer.id = "publicCouponsListContainer";
                    dvPublicCouponListContainer.classList = "custom-scrollable";

                    let dvPublicCouponTable = document.createElement("table");
                    dvPublicCouponTable.id = "publicCouponsList";

                    dvPublicCouponListContainer.appendChild(dvPublicCouponTable);

                    let dvpublicItem = document.createElement("div");
                    dvpublicItem.id = "publicItem";
                    dvpublicItem.classList = "itemTextContent";
                    dvpublicItem.style = "font-size: 16px; line-height: 32px;";

                    dvpublicItem.appendChild(dvOffer);
                    dvpublicItem.appendChild(dvViewButton);
                    dvpublicItem.appendChild(dvPublicCouponListContainer);

                    anchor.appendChild(dvpublicItem);

                    let AddUnderlineHandler = function (e) {
                        let viewButton = anchor.querySelector("#viewButton");
                        viewButton.style.textDecoration = "underline";
                        viewButton.style.color = "#0a6ebd";
                    };
                    let removeUnderlineHandler = function (e) {
                        let viewButton = anchor.querySelector("#viewButton");
                        viewButton.style.textDecoration = "none";
                        viewButton.style.color = "#2196f3";
                    };

                    let title = anchor.querySelector("#publicTitle");
                    title.addEventListener("mouseover", AddUnderlineHandler);
                    title.addEventListener("mouseout", removeUnderlineHandler);

                    let itemTextContent = anchor.querySelector("div.itemTextContent");

                    let viewButton = anchor.querySelector("#viewButton");
                    viewButton.classList.add("itemCursor");
                    viewButton.addEventListener("mouseover", AddUnderlineHandler);
                    viewButton.addEventListener("mouseout", removeUnderlineHandler);


                    //Click event for copying the promo code, if code exists.
                    let onCopyHandler = function (e) {
                        e.preventDefault();
                        e.stopPropagation();
                        let copyFrom = document.createElement("textarea");
                        let copyCell = e.target.parentElement;
                        let copyCode = e.target;
                        let divCopied = copyCell.querySelector("div.itemCopied");

                        //copy text
                        copyFrom.textContent = (copyCode && copyCode.getAttribute("code")) || e.target.innerText;
                        document.body.appendChild(copyFrom);
                        copyFrom.select();
                        document.execCommand('copy');
                        copyFrom.blur();
                        document.body.removeChild(copyFrom);

                        //Activate cashback       
                        _sendMessage({
                            action: "activateCashBack",
                            targetScript: "buttonApp.js",
                            data: { retailerId: dbRow.RetailerID, tabId: activeTab.id, deeplink: false, HideButton: false }
                        }, function (activated) {
                            if (activated) {
                                _UpdateActionButton(true, activateCashbackButton, applyButton, cashbackTermsLink, cashbackRateText, noDiscountsText, couponsOnlyText, (dbRow.CashbackRate != null), (dbRow.CouponCount > 0));
                            }
                        });

                        //show copied text for some time
                        divCopied.style.display = "inline-block";
                        copyCode.style.display = "none";
                        setTimeout(() => {
                            divCopied.style.display = "none";
                            copyCode.style.display = "inline-block";
                        }, 2000);
                        return false;
                    };
                    let onHoverHandler = function (e) {
                        e.target.style.backgroundColor = "#ffe9bc";
                        e.target.style.color = "#f28a62";
                        e.target.style.fontWeight = "600";
                    };
                    let onLeaveHandler = function (e) {
                        e.target.style.backgroundColor = "#fff6e3";
                        e.target.style.color = "#f28a62";
                        e.target.style.fontWeight = "600";
                    };

                    let publicCouponsList = anchor.querySelector("#publicCouponsList");
                    publicCouponsList.style.width = "100%";
                    publicCouponsList.style.textAlign = "center";
                    publicCouponsList.style.margin = "0 auto";
                    publicCouponsList.style.tableLayout = "fixed";
                    publicCouponsList.style.display = "none";
                    let rowIterator = 0;
                    let currentRow = null;
                    let currentCell = null;
                    let tableCellWidth = "140px";

                    for (let i = 0; i < additionalCodes.length; i++) {
                        let code = additionalCodes[i];

                        let dvTableCell = document.createElement("div");
                        dvTableCell.id = ("code" + code);
                        dvTableCell.innerText = code;
                        dvTableCell.style = "background-color: #fff6e3; font-weight:bold; text-align: center; font-size:16px; margin: 0 auto; color: #f28a62; text-transform: uppercase; white-space: nowrap; text-overflow: ellipsis; overflow: hidden;border-radius: 5px;";

                        let dvItemCopied = document.createElement("div");
                        dvItemCopied.classList = "itemCopied bfslider_clearFix";
                        dvItemCopied.style = "display: none; position: unset !important; padding: 0 !important; text-align: center;";

                        let spnCopied = document.createElement("span");
                        spnCopied.classList = "icon-checkmark-full-small";
                        let spnCopiedText = document.createElement("span");
                        spnCopiedText.innerText = "Copied";

                        dvItemCopied.appendChild(spnCopied);
                        dvItemCopied.appendChild(spnCopiedText);

                        if (i % 2 === 0) {
                            //Odd
                            currentRow = publicCouponsList.insertRow(-1);
                            currentRow.id = "row" + rowIterator;
                            currentRow.addEventListener("click", (e) => {
                                e.preventDefault();
                                return false;
                            });
                            currentCell = currentRow.insertCell(-1);
                            rowIterator++;
                        }
                        else {
                            //Even
                            currentCell = currentRow.insertCell(-1);
                        }
                        currentCell.appendChild(dvTableCell);
                        currentCell.appendChild(dvItemCopied);
                        let divCell = currentCell.querySelector('div[id*="code"]');

                        currentCell.id = "cell" + i;
                        currentCell.style.cursor = "default";
                        currentCell.style.textAlign = "center";
                        currentCell.style.margin = "0";
                        currentCell.style.padding = "3px 13px";
                        currentCell.style.display = "table-cell";

                        divCell.style.width = tableCellWidth;
                        divCell.style.display = "inline-block";
                        divCell.style.cursor = "pointer";
                        divCell.setAttribute("code", code);
                        divCell.addEventListener("click", onCopyHandler);
                        divCell.addEventListener("mouseover", onHoverHandler);
                        divCell.addEventListener("mouseout", onLeaveHandler);

                        offersCount++;
                    }
                    if (additionalCodes.length === 1) {
                        //To handle special cases.
                        currentCell.style.margin = "0 auto";
                        let divCell = currentCell.querySelector('div[id*="code"]');
                        divCell.style.display = "inline-block";
                        divCell.style.width = tableCellWidth;
                    }

                    //Click event for copying the promo code, if code exists.
                    let onClickHandler = function (e) {
                        e.preventDefault();
                        e.stopPropagation();
                        let spanArrow = viewButton.querySelector("#publuciChevron");
                        if (publicCouponsList.style.display && publicCouponsList.style.display.indexOf("none") >= 0) {
                            publicCouponsList.style.display = "table";
                            spanArrow.setAttribute("class", "icon-chevron-down");
                        }
                        else {
                            publicCouponsList.style.display = "none";
                            spanArrow.setAttribute("class", "icon-chevron-right");
                        }
                        return false;
                    };
                    title.addEventListener("click", onClickHandler);
                    viewButton.addEventListener("click", onClickHandler);

                    //Clicking on the main anchor should redirect you to the offer link redirect URL.
                    anchor.addEventListener("click", (e) => {
                        e.preventDefault();
                        e.stopPropagation();
                        return true;
                    });
                    //Inserts public offers after coupons with codes but before the rest
                    //If firstItemGetOffer is undefined, insertBefore will insert anchor at the end of retailerOffersContainer's child nodes.
                    let firstItemGetOffer = document.getElementsByClassName("itemContainer itemCursor itemGetOffer")[0];
                    retailerOffersContainer.insertBefore(anchor, firstItemGetOffer);
                }
            }
        };

        let genericStyling = function () {
            let sectionCount = 0;
            if (offersCount > 0) {
                sectionCount++;
            } else {
                retailerOffersContainer.classList.remove('active');
                retailerOffersContainer.classList.remove('show');
            }

            if (dealsCount > 0) {
                sectionCount++;
                if (offersCount == 0) {
                    retailerDealsContainer.classList.add('active');
                    retailerDealsContainer.classList.add('show');
                }
            }

            if (sectionCount == 2) {
                document.querySelector('#dealsOrOffersDiv').style.display = 'block';
                let ocDiv = document.querySelector('#offerCount div');
                let couponCount = offersCount - noCodeOffers;
                if (couponCount > 0) {
                    browserAdapter._GetBadgetext(function (badgeText) {
                        //sync coupon count with badge count
                        var starttext = "";
                        if (/^\d+$/.test(badgeText)) {
                            starttext = 'Coupons (' + badgeText + ')';
                            ocDiv.innerText = starttext;
                        }
                        else {
                            starttext = 'Coupons (' + couponCount + ')';
                            ocDiv.innerText = starttext;
                        }
                        if (noCodeOffers > 0) {
                            ocDiv.innerText = starttext + ' & Offers (' + noCodeOffers + ')';
                        }
                    });
                } else {
                    ocDiv.innerText = 'Offers (' + noCodeOffers + ')';
                }
                ocDiv.classList.add('active');
                ocDiv.classList.add('show');
                document.querySelector('#dealCount div').innerText = 'Deals (' + dealsCount + ')';
            }

            if (!shouldPopulateOffers && !shouldAddFoundCouponCodes) {

                let div = document.createElement("div");
                div.innerText = "No coupons available.";
                div.style.color = "#d4d4d4";
                div.style.fontStyle = "italic";
                div.style.fontSize = "16px";
                div.style.fontWeight = 500;
                div.style.textAlign = "center";
                div.style.paddingTop = "8px";

                retailerOffersContainer.appendChild(div);
            }
        };

        let generateContent = function (addSubmitReceipt) {
            populateOffersArea(addSubmitReceipt);
            populateAdditionalCodesArea();
            genericStyling();
        };

        _sendMessage({
            action: "Preference Manager",
            targetScript: "shoptoolbar.js",
            data: { pref:  "BonusEligibility" }
        }, function (eligibleRetailerID) {
            if (isRestaurant && settings.Config.BonustRSTCouponStickyRewards && !isButton && !settings.Config.IsRewardsInstalled) {
                let extCheckApi = "https://" + Site + '/ServicePages/BefrugalSiteWs/?handler=IsBeFrugalRewardSearchInstalled';
                _sendMessage({
                    action: "FetchJson",
                    targetScript: "shoptoolbar.js",
                    data: { url: extCheckApi }
                }, function (response) {
                    if (response) {
                        settings.Config.IsRewardsInstalled = true;
                        _sendMessage({
                            action: "Preference Manager",
                            targetScript: "shoptoolbar.js",
                            data: { pref: "Settings", value: settings }
                        });
                        generateContent(false);
                    }
                    else {
                        generateContent(true);
                    }
                });
            }
            else if (isRestaurant && eligibleRetailerID && eligibleRetailerID > 0 && (!settings.Config.RSTCouponRetailerLevel || eligibleRetailerID === json.RetailerInfo.RetailerID)) {
                _sendMessage({
                    action: "sptool",
                    targetScript: "shoptoolbar.js",
                    data: { function: "_GetRestaurantBonusEligibility" }
                }, function (eligibility) {
                    if (eligibility && eligibility.Eligible && (!settings.Config.RSTCouponRetailerLevel || eligibility.RetailerID === json.RetailerInfo.RetailerID)) {
                        generateContent(true);
                    }
                    else {
                        if (eligibility && !eligibility.Eligible) {
                            _sendMessage({
                                action: "Preference Manager",
                                targetScript: "shoptoolbar.js",
                                data: { pref: "BonusEligibility", value: 0 }
                            });
                        }
                        generateContent(false);
                    }
                });
            }
            else {
                generateContent(false);
            }
        });
    });
}

/**
 * Loads all of the default tab contents in the popup that are not specific to any retailers.
 */
function _LoadNonRetailerContents() {
    //Initializing variables if variables are non-existent.
    var activateCashbackButton = activateCashbackButton || document.querySelector("#headerRetailerActivateCB");
    var applyButton = applyButton || document.querySelector("#headerRetailerApplyCoupons");
    var cashbackRateText = cashbackRateText || document.querySelector("#headerRetailerCashbackRates");
    var nonretailerHeader = nonretailerHeader || document.getElementById("nonretailer");
    var retailerHeader = retailerHeader || document.getElementById("retailerSpecific");
    var searchBar = document.getElementById('newSearchBar');

    //Initializes the specific parts.
    if (shoptoolbar._Browser === Browsers.iOS) {
        let rafClick = function (e) {
            _openLink("https://www.befrugal.com/account/member/refer-a-friend/");
            e.preventDefault();
            return true;
        }
        let headerRAF = document.getElementById('headerRAF');
        headerRAF.addEventListener("click", rafClick);
    }
    
    if (shoptoolbar._Browser !== Browsers.iOS) {
        nonretailerHeader.style.display = "block";
    }
    retailerHeader.style.display = "block";

    //Set the flag to the popup to know we're on the default layout. By default, it should show the Homepage.
    popup._CurrentPopupContent = _PopupContentEnum.Homepage;

    //...And show the homepage.
    popup._EnableContent();

    if (!nocashback) {
        //show the favorite placeholders
        if (popup._FavoritesList.length === 0) {
            GetAnonymity(function (isanon) {
                let do_fallbacks = function () {
                    if (macHide && storeSource === Stores.Mac && (bsGuest || noUser)) {
                        document.getElementById("myAccount").style.visibility = "hidden";
                        document.getElementById("myBalance").style.visibility = "hidden";
                        document.getElementById("newMemberNeedAccount").style.visibility = "hidden";
                        document.querySelector("#newEmailSection > div").style.display = "none";
                    }
                    _sendMessage({
                        action: "sptool",
                        targetScript: "shoptoolbar.js",
                        data: { function: "_GetFeaturedRetailers" }
                    }, function (featuredRetailers) {
                        if (featuredRetailers.length > 9) {
                            popup._SetFavoriteStores(null, featuredRetailers.slice(0, 9));
                        }
                        else {
                            popup._SetFavoriteStores(null, featuredRetailers);
                        }
                    });
                };

                if (!isanon && !noUser && !(bsGuest && storeSource === Stores.Mac)) {
                    popup._GetFavoriteStores(function (resp) {
                        if (!resp || (!resp.Favorites && !resp.RecommendedFavorites)) {
                            noUser = true;
                            do_fallbacks();
                        }
                    });
                }
                else {
                    do_fallbacks();
                }
            });
        }
    }

    //Controls what specific parts of the header should be displayed.
    if (shoptoolbar._Browser !== Browsers.iOS) {
        nonretailerHeader.classList.add("show");
        retailerHeader.classList.remove("show");
    }
    else {
        retailerHeader.classList.add("show");
        _ToggleHeaderForIOS(false);
    }

    //Setting up
    if (shoptoolbar._Browser !== Browsers.iOS) {
        let bfLogo = document.querySelector("img[id*='PopupLogo']");
        if (!macHide || storeSource !== Stores.Mac || (!bsGuest && !noUser)) {
            bfLogo.addEventListener("click", (e) => {
                _openLink("https://" + bfSite);
            });
        }
        else {
            bfLogo.style.cursor = "initial";
        }
        document.querySelector("div[id*='SearchButton']").addEventListener("click", (e) => {
            _searchButtonHandler(searchBar.value);
        });
    }
    //Search and search suggestions
    var searchSuggestions = document.getElementById("newSearchSuggestions");
    if (searchBar !== null) {
        //Aims to reduce the amount of times it does heavy loading when fetching request for search autocompletion.
        var inputSearchTimeoutHandle = 0;
        searchBar.addEventListener('keyup', (event) => {
            if (event.key != null && event.key === "Enter") {
                //Enter key
                let mouseSelectedItem = searchSuggestions.querySelector("li.mouseHighlighted");
                let highlightedItem = searchSuggestions.querySelector("li.highlighted");
                if (highlightedItem != null) {
                    highlightedItem.classList.remove("highlighted");
                    if (highlightedItem.classList.contains("cb") && !highlightedItem.classList.contains("mouseHighlighted")) {
                        highlightedItem.classList.remove("cb");
                    }
                    highlightedItem.dispatchEvent(new Event("click"));
                    return true;
                }
                else if (mouseSelectedItem != null) {
                    mouseSelectedItem.classList.remove("mouseHighlighted");
                    if (mouseSelectedItem.classList.contains("cb")) {
                        mouseSelectedItem.classList.remove("cb");
                    }
                    mouseSelectedItem.dispatchEvent(new Event("click"));
                    return true;
                }
                else {
                    _searchButtonHandler(searchBar.value);
                }
            }
            else if (event.key != null && (event.key !== "ArrowUp" && event.key !== "ArrowDown" && event.key !== "ArrowLeft" && event.key !== "ArrowRight")) {
                if (inputSearchTimeoutHandle)
                    clearTimeout(inputSearchTimeoutHandle);
                inputSearchTimeoutHandle = setTimeout(() => {
                    _autoCompleteHandler(searchBar, searchSuggestions);
                }, 200);
            }
        });

        //When the user clicks inside of the textbox...
        searchBar.addEventListener("focus", (event) => {
            searchBar.style.backgroundImage = "none";
            _autoCompleteHandler(searchBar, searchSuggestions);
        });

        //When the user clicks outside of the textbox...
        searchBar.addEventListener("blur", (event) => {
            setTimeout(() => {
                //searchBar.style.background = "url(magnifying-glass.png) no-repeat white";
                //searchBar.style.backgroundPosition = "calc(100% - 5px) center";
                searchBar.setAttribute("placeholder", "Search Stores, Deals & Restaurants");
                //searchBar.value = "";
                searchSuggestions.style.display = "none";
            }, 200);
        });

        searchBar.addEventListener("input", () => {
            searchInputValue = searchBar.value;
        });
    }
}

function FavoriteIt(retailerid, heartIcon, callback) {
    GetAnonymity(function (isanon) {
        let favoriteStore = function (addedWhileAnon) {
            let results = popup._FavoritesList.filter(x => x && x.retailerID === parseInt(retailerid)).length > 0;
            if (results) {
                //don't remove if added while anonymous and it was already a favorite, just color in
                if (addedWhileAnon) {
                    heartIcon.style.color = "#ed1c24";
                }
                else {
                    //It exists. We remove it from favorites.
                    heartIcon.style.color = "#d0d0d0";
                    popup._RemoveFavoriteStore(retailerid, null);
                }
            }
            else {
                //It doesn't exist. We add it to favorites.
                heartIcon.style.color = "#ed1c24";
                popup._AddFavoriteStore(retailerid, null);
            }
            if(callback) callback(true);
        };

        if (isanon) {
            privacyDialog(false, function (allowed) {
                if (allowed) {
                    popup._GetFavoriteStores(() => {
                        favoriteStore(true);
                    });
                }
                else if (callback) {
                    callback(false);
                }
            });
        }
        else {
            favoriteStore();
        }
    });
}

function _SetRetailerFavoriteIcon(retailerid) {
    var addFavoriteButton = document.querySelector("#headerRetailerAddFavorites");
    if (noUser) {
        addFavoriteButton.style.visibility = "hidden";
    }

    //Initializes the Add to Favorites button.
    let favoritesCheck = popup._FavoritesList.filter(x => x && x.retailerID === parseInt(retailerid)).length > 0;
    if (!favoritesCheck) {
        //It's removed.
        if (popup._FavoritesList.length < MaxStoresTotal) {
            addFavoriteButton.style.color = "#d0d0d0";
        }
        else addFavoriteButton.style.display = "none";
    }
    else {
        //It's added.
        addFavoriteButton.style.color = "#ed1c24";
    }
    addFavoriteButton.onclick = function (e) {
        FavoriteIt(retailerid, addFavoriteButton);
        e.preventDefault();
        return false;
    };
}

function _LoadRetailerContents(retailerid, cashbackActivated, dbRow, retailer, source) {
    //Variables
    var activateCashbackButton = document.querySelector("#headerRetailerActivateCB");
    var applyButton = document.querySelector("#headerRetailerApplyCoupons");
    var cashbackRateText = document.querySelector("#headerRetailerCashbackRates");
    var noDiscountsText = document.querySelector("#headerRetailerNoCashbackRates");
    var couponsOnlyText = document.querySelector("#headerRetailerCouponsOnly");
    var nonretailerHeader = document.getElementById("nonretailer");
    var retailerHeader = document.getElementById("retailerSpecific");
    var cashbackTermsLink = document.querySelector("#headerRetailerCBTerms");
    var addFavoriteButton = document.getElementById("headerRetailerAddFavorites");
    var headerNameText = document.getElementById("headerRetailerName");
    var sourceRestaurant = (source && source === "Restauarant");

    if (macHide && storeSource === Stores.Mac && (bsGuest || noUser)) {
        document.getElementById("myAccount").style.visibility = "hidden";
    }

    if (shoptoolbar._Browser === Browsers.iOS) {
        let rafClick = function (e) {
            _openLink("https://www.befrugal.com/account/member/refer-a-friend/");
            e.preventDefault();
            return true;
        }
        let headerRAF = document.getElementById('headerRAF');
        headerRAF.addEventListener("click", rafClick);
    }

    //Restaurant flow shows back button instead of favorite icon
    if (sourceRestaurant) {
        document.getElementById('retailerSpecificHeader').style.position = "";
        document.getElementById('headerRetailerTitle').style.backgroundColor = "white";
        let backClone = document.getElementById('backToCategoriesLinkClone');
        if (backClone) {
            backClone.style.display = "inline-block";
        }
        else {
            headerNameText.innerText = "";
            let backButton = document.getElementById('backToCategoriesLink');
            backClone = backButton.cloneNode(true);
            backClone.id = "backToCategoriesLinkClone";
            backClone.addEventListener("click", (event) => {
                let bootstrapRemove = function (elemToRemove) {
                    elemToRemove.classList.remove("active");
                    elemToRemove.classList.remove("show");
                };
                let bootstrapAdd = function (elemToAdd) {
                    if (!elemToAdd.classList.contains("active")) {
                        elemToAdd.classList.add("active");
                    }
                    if (!elemToAdd.classList.contains("show")) {
                        elemToAdd.classList.add("show");
                    }
                };
                bootstrapAdd(document.getElementById('homeContent'));
                if (shoptoolbar._Browser !== Browsers.iOS) {
                    bootstrapAdd(document.getElementById('nonretailer'));
                }
                bootstrapRemove(document.getElementById('retailerContent'));
                bootstrapRemove(document.getElementById('retailerSpecific'));
                if (!document.querySelector("#restaurantsBrowse[style*='block'], #restaurantsByLetter[style*='block']")) {
                    document.getElementById("restaurantsBrowse").style.display = "block";
                }
                popup._ResetRestaurantFavorited();
                document.getElementById('retailerSpecificHeader').style.position = "absolute";
            });
            headerNameText.appendChild(backClone);
        }
    }

    //Initializes the specific parts.
    if (shoptoolbar._Browser !== Browsers.iOS) {
        nonretailerHeader.style.display = "block";
    }
    retailerHeader.style.display = "block";

    //Initializes the cashback terms
    //rid = Retailer ID.
    cashbackTermsLink.setAttribute("rid", retailerid);

    //Set the flag for popup to mark that we're showing a retailer specific layout to the user.
    popup._CurrentPopupContent = _PopupContentEnum.Retailer;

    //...And show the retailer specific offerings.
    popup._EnableContent();

    //This is where we show the store coupons for that specific store in the popup
    //https://basecamp.com/2956257/projects/9528213/todos/348902010
    //When this occurs, all parameters are guaranteed to not be undefined, and they
    //have the data you need to fill in the missing parts to display in the menu.

    //Controls what specific parts of the header should be displayed.
    if (shoptoolbar._Browser !== Browsers.iOS) {
        nonretailerHeader.classList.remove("show");
    }
    retailerHeader.classList.add("show");
    _ToggleHeaderForIOS(true);

    let bfLogo = document.getElementById("bf_logo_onRetailerView");
    if (!macHide || storeSource !== Stores.Mac || (!bsGuest && !noUser)) {
        bfLogo.addEventListener("click", (e) => {
            _openLink("https://" + bfSite);
        });
    }
    else {
        bfLogo.style.cursor = "initial";
    }

    // //We turn these off by default, and enable them when required.
    // applyButton.style.display = "none";
    // cashbackRateText.style.display = "none";
    // activateCashbackButton.style.display = "none";

    //Variables need to be set
    if (!sourceRestaurant) headerNameText.innerText = dbRow.RetailerName;
    document.getElementById("headerRetailerImage").src = "https:" + dbRow.ImgUrl;

    let findSpecialOffersElem = document.getElementById("findSpecialOffers");
    if (findSpecialOffersElem) {
        const findSpecialOffersUrl = "https://" + dbRow.BackupDigestRule.Domain;
        findSpecialOffersElem.href = findSpecialOffersUrl;
        findSpecialOffersElem.addEventListener("click", () => {
            window.open(findSpecialOffersUrl, "_blank");
        });
    }

    let shopNowButtonElem = document.getElementById("shopNowButton");
    const shopNowButtonUrl = "https://" + dbRow.BackupDigestRule.Domain;
    shopNowButtonElem.href = shopNowButtonUrl
    shopNowButtonElem.addEventListener("click", () => {
        window.open(shopNowButtonUrl, "_blank");
    });

    let setCateogoryRates = function () {
        if (dbRow && dbRow.CategoryRates && dbRow.CategoryRates.length > 0) {
            let addBeforeOffers = document.getElementById("dealsOrOffersDiv");
            var itemContainers = addBeforeOffers.parentElement.getElementsByClassName("itemContainer");
            for (var i = 0; i < itemContainers.length; i++) {
                if (itemContainers[i].nodeName == "DIV")
                    itemContainers[i].style.display = "none";
            }

            let categoryRatesArea = document.createElement("div");
            categoryRatesArea.classList = "itemContainer";
            categoryRatesArea.style.margin = "10px";
            let categoryRatesTitle = document.createElement("div");
            categoryRatesTitle.innerText = "Cash Back Categories & Exclusions:";
            categoryRatesTitle.classList = "itemTitle";
            categoryRatesTitle.style.marginBottom = "5px";
            categoryRatesTitle.style.fontSize = "17px";
            categoryRatesTitle.style.textDecoration = "none";
            categoryRatesArea.appendChild(categoryRatesTitle);
            let categoryRatesTable = document.createElement("table");
            categoryRatesTable.style.width = "100%";

            for (let dr = 0; dr < dbRow.CategoryRates.length; dr++) {
                let categoryRatesRow = document.createElement("tr");
                if (dr >= 3) {
                    categoryRatesRow.classList = "dealCatOverflow";
                    categoryRatesRow.style.display = "none";
                }
                let categoryrate = document.createElement("td");
                categoryrate.innerText = dbRow.CategoryRates[dr].Rate;
                categoryrate.style.width = "20%";
                categoryrate.style.padding = "5px";
                categoryrate.style.textAlign = "right";
                categoryrate.style.fontSize = "15px";
                categoryrate.style.fontWeight = "600";
                categoryrate.style.color = "#199402";
                let categoryName = document.createElement("td");
                categoryName.innerText = dbRow.CategoryRates[dr].CategoryName;
                categoryName.style.width = "80%";
                categoryName.style.padding = "5px 10px";
                categoryName.style.textAlign = "left";
                categoryName.style.fontSize = "15px";
                categoryRatesRow.appendChild(categoryrate);
                categoryRatesRow.appendChild(categoryName);
                categoryRatesTable.appendChild(categoryRatesRow);
            }
            categoryRatesArea.appendChild(categoryRatesTable);

            if (dbRow.CategoryRates.length > 3) {
                let categoryRatesMore = document.createElement("div");
                categoryRatesMore.classList = "moreLessDiv";
                categoryRatesMore.style.margin = "5px 0px 6px 0";
                categoryRatesMore.style.textAlign  = "center";
                let categoryRatesMoreText = document.createElement("span");
                categoryRatesMoreText.innerText = "More";
                categoryRatesMoreText.classList = "moreLessRates";
                let categoryRatesMoreChevron = document.createElement("span");
                categoryRatesMoreChevron.classList = "icon-chevron-down";
                categoryRatesMore.appendChild(categoryRatesMoreText);
                categoryRatesMore.appendChild(categoryRatesMoreChevron);
                categoryRatesArea.appendChild(categoryRatesMore);
                let collapsed = true;
                categoryRatesMore.addEventListener("click", function () {
                    if (collapsed) {
                        categoryRatesMoreText.innerText = "Less";
                        categoryRatesMoreChevron.classList = "icon-chevron-up";
                        document.querySelectorAll(".dealCatOverflow").forEach(s => s.style.display = "");
                    }
                    else {
                        categoryRatesMoreText.innerText = "More";
                        categoryRatesMoreChevron.classList = "icon-chevron-down";
                        document.querySelectorAll(".dealCatOverflow").forEach(s => s.style.display = "none");
                    }
                    collapsed = !collapsed;
                });
            }

            addBeforeOffers.parentElement.insertBefore(categoryRatesArea, addBeforeOffers);
        }
    };

    if (noUser) {
        addFavoriteButton.style.visibility = "hidden";
    }

    if (nocashback && !isButton) {
        addFavoriteButton.style.display = "none";
        document.getElementById("headerActionButtonsContainer").style.display = "none";
        document.getElementById("retailerSpecificHeader").style.textAlign = "center";
        document.getElementById("retailerSpecificLogo").style.float = "initial";
        let backClone = document.getElementById('backToCategoriesLinkClone');
        if (!backClone && !document.getElementById("backfromNoCBRetailer")) {
            let backButton = document.getElementById('backToCategoriesLink');
            backClone = backButton.cloneNode(true);
            backClone.id = "backfromNoCBRetailer";
            backClone.style.display = "inline-block";
            backClone.style.float = "left";
            backClone.style.marginTop = "10px";
            backClone.addEventListener("click", (event) => {
                headerNameText.innerText = "";
                var nonretailerHeader = document.getElementById("nonretailer");
                var retailerHeader = document.getElementById("retailerSpecific");
                backClone.style.display = "none";
                //Header display
                if (shoptoolbar._Browser !== Browsers.iOS) {
                    nonretailerHeader.classList.add("show");
                    retailerHeader.classList.remove("show");
                }
                else {
                    retailerHeader.classList.add("show");
                    _ToggleHeaderForIOS(false);
                }

                // //Buttons
                _LoadNonRetailerContents();
            });
            document.getElementById("headerRetailerTitle").appendChild(backClone);
            headerNameText.style.float = "right";
            headerNameText.style.marginRight = "15px";
        }
        else {
            headerNameText.style.float = "";
            headerNameText.style.marginRight = "";
        }
    }
    else {
        let cssBrowser = isChrome ? "chrome" : shoptoolbar._Browser === Browsers.Firefox ? "firefox" : "edge";;
       
        //Button actions
        //"No Discounts" situation don't have button actions.
        let spanCBText = cashbackRateText.querySelector("#headerRetailerCBRateText");

        let activateButtonShown = false;

        if (sourceRestaurant) {
            let textArea = couponsOnlyText.querySelector(".headerRetailerSmallText");
            textArea.innerText = "";
            let favoriteClone = addFavoriteButton.cloneNode(true);
            let results = popup._FavoritesList.filter(x => x && x.retailerID === parseInt(retailerid)).length > 0;
            favoriteClone.onclick = function (e) {
                FavoriteIt(retailerid, favoriteClone);
                e.preventDefault();
                return false;
            }
            favoriteClone.style.color = results ? "#ed1c24" : "#d0d0d0";
            favoriteClone.style.marginRight = "6px";
            favoriteClone.style.position = "relative";
            favoriteClone.style.top = "-1px";

            textArea.style.marginRight = "18px";
            textArea.style.fontStyle = "normal";
            textArea.appendChild(favoriteClone);
            textArea.appendChild(document.createTextNode(dbRow.RetailerName));
            favoriteClone.style.display = "inline-block";
            addFavoriteButton.style.display = "none";
        }
        else if (dbRow._Rule === "ContinueOnBeFrugal") {
            _sendMessage({
                action: "sptool",
                targetScript: "shoptoolbar.js",
                data: { function: "_GetRetailerCouponURL", args: [dbRow.InternalName, false] }
            }, function (redirectUrl) {
                _preRedirectMessaging(redirectUrl, dbRow);
            });
        }
        else if (dbRow.CashbackRate != null && dbRow.CouponCount > 0) {

            spanCBText.innerText = dbRow.CashbackRate;

            let spnActionButtonText = document.createElement("span");
            spnActionButtonText.classList = "actionButtonText_" + cssBrowser;
            spnActionButtonText.innerText = ((!autoApplyData || !autoApplyData.ShowCouponsApp) || autoApplyData.ShowCouponsApp.IsShowingCoupons ? "Show" : "Apply") + " Coupons";

            let spnActionButtonTextTwo = document.createElement("span");
            spnActionButtonTextTwo.classList = "actionButtonText_" + cssBrowser;
            spnActionButtonTextTwo.innerText = ("Activate " + dbRow.CashbackRate);

            activateCashbackButton.innerText = "";
            activateCashbackButton.appendChild(spnActionButtonTextTwo);
            activateCashbackButton.style.fontSize = dbRow.CashbackRate.toLowerCase().indexOf("up to") > -1 ? "14px" : "16px";

            applyButton.innerText = "";
            applyButton.appendChild(spnActionButtonText);
            applyButton.addEventListener("click", _applyCouponsHandler);
            if (!activateCashbackButton.hasAttribute("bfclick")) {
                activateButtonShown = true;
                activateCashbackButton.setAttribute("bfclick", "true");
                activateCashbackButton.onclick = function (event) {
                    let emailCollection = function () {
                        _sendMessage({
                            action: "sendEmailCollection",
                            targetScript: "autoApplyApp.js",
                            data: { activeTab: activeTab, from: "popup" }
                        });
                    };
                    let activateCashback = function () {
                        _sendMessage({
                            action: "activateCashBack",
                            targetScript: "buttonApp.js",
                            data: { retailerId: dbRow.RetailerID, tabId: activeTab.id, deeplink: true, HideButton: true }
                        }, function (activated) {
                            if (activated) {
                                _UpdateActionButton(true, activateCashbackButton, applyButton, cashbackTermsLink, cashbackRateText, noDiscountsText, couponsOnlyText, (dbRow.CashbackRate != null), (dbRow.CouponCount > 0));
                            }
                        });
                    };
                    _sendMessage({
                        action: "ShouldCollectEmail",
                        targetScript: "shoptoolbar.js"
                    }, function (shouldCollect) {
                        GetAnonymity(function (notallowed) {
                            if (notallowed && !recentDeclined) {
                                privacyDialog(true, function (allowed) {
                                    //if (allowed || recentDeclined)
                                    shouldCollect ? emailCollection() : activateCashback();
                                });
                            }
                            else {
                                shouldCollect ? emailCollection() : activateCashback();
                            }
                        });
                    });
                };
            }
            if (shoptoolbar._Browser !== Browsers.iOS) {
                setCateogoryRates();
            }
        }
        else if (dbRow.CouponCount > 0) {
            //Coupons Only
            let spnActionButtonText = document.createElement("span");
            spnActionButtonText.classList = "actionButtonText_" + cssBrowser;
            spnActionButtonText.innerText = (autoApplyData && autoApplyData.ShowCouponsApp && autoApplyData.ShowCouponsApp.IsShowingCoupons ? "Show" : "Apply") + " Coupons";
            applyButton.innerText = "";
            applyButton.appendChild(spnActionButtonText);
            applyButton.addEventListener("click", _applyCouponsHandler);
        }
        else if (dbRow.CashbackRate != null) {
            //Only Cashback Rates
            document.getElementById("noCouponsCashbackContent").style.display = "block";

            spanCBText.innerText = dbRow.CashbackRate;

            let spnActionButtonTextTwo = document.createElement("span");
            spnActionButtonTextTwo.classList = "actionButtonText_" + cssBrowser;
            spnActionButtonTextTwo.innerText = ("Activate " + dbRow.CashbackRate);

            activateCashbackButton.innerText = "";
            activateCashbackButton.appendChild(spnActionButtonTextTwo);
            activateCashbackButton.style.fontSize = dbRow.CashbackRate.toLowerCase().indexOf("up to") > -1 ? "14px" : "16px";

            if (!activateCashbackButton.hasAttribute("bfclick")) {
                activateButtonShown = true;
                activateCashbackButton.setAttribute("bfclick", "true");
                activateCashbackButton.addEventListener("click", (event) => {
                    let emailCollection = () => {
                        _sendMessage({
                            action: "sendEmailCollection",
                            targetScript: "autoApplyApp.js",
                            data: { activeTab: activeTab, from: "popup" }
                        });
                    };
                    let activateCashback = function () {
                        _sendMessage({
                            action: "activateCashBack",
                            targetScript: "buttonApp.js",
                            data: { retailerId: dbRow.RetailerID, tabId: activeTab.id, deeplink: true, HideButton: true }
                        }, function (activated) {
                            if (activated) {
                                _UpdateActionButton(true, activateCashbackButton, applyButton, cashbackTermsLink, cashbackRateText, noDiscountsText, couponsOnlyText, (dbRow.CashbackRate != null), (dbRow.CouponCount > 0));
                            }
                        });
                    };
                    _sendMessage({
                        action: "ShouldCollectEmail",
                        targetScript: "shoptoolbar.js"
                    }, function (shouldCollect) {
                        GetAnonymity(function (notallowed) {
                            if (notallowed && !recentDeclined) {
                                privacyDialog(true, function (allowed) {
                                    //if (allowed || recentDeclined)
                                    shouldCollect ? emailCollection() : activateCashback();
                                });
                            }
                            else {
                                shouldCollect ? emailCollection() : activateCashback();
                            }
                        });
                    });
                });
            }
            if (shoptoolbar._Browser !== Browsers.iOS) {
                setCateogoryRates();
            }
        }
        else {
            // No cashback rates and no coupons
            document.getElementById("noCouponsCashbackContent").style.display = "block";
        }

        if (activateButtonShown) {
            _sendMessage({
                action: "ActivateShownPopup",
                targetScript: "shoptoolbar.js"
            }, null);
        }
    }

    //Before we provide retailer specific offerings, it's a good idea to display a loading icon/screen first, because there may be times where
    //the server is just spinning up and a significant delay incurs.
    //Variables need to be "var" defined, so asynchronous function calls can access them.
    var retailerOfferContainer = document.querySelector("#retailerOffersContainer");
    var retailerDealContainer = document.querySelector("#retailerDealsContainer");
    let cssBrowser = isChrome ? "chrome" : shoptoolbar._Browser === Browsers.Firefox ? "firefox" : "edge";;
    if (!retailerOfferContainer || !retailerDealContainer) {
        //This shouldn't happen.
        return;
    }
    while (retailerOfferContainer.firstChild)
        retailerOfferContainer.removeChild(retailerOfferContainer.firstChild);
    while (retailerDealContainer.firstChild)
        retailerDealContainer.removeChild(retailerDealContainer.firstChild);
    var loadingIcon = document.createElement("div");
    loadingIcon.classList.add("loading");
    loadingIcon.innerText = "";
    retailerOfferContainer.appendChild(loadingIcon);


    let showingRetailerStuff = function (retailerObject) {
        //Remove the loading icon, before appending the fetched data, or if the data is empty, do something about it.
        retailerOfferContainer.removeChild(loadingIcon);
        PopulateOffers(retailerObject, retailerOfferContainer, retailerDealContainer, activateCashbackButton, applyButton, cashbackTermsLink, cashbackRateText, noDiscountsText, couponsOnlyText, dbRow);
        if (autoApplyData && autoApplyData.CheckoutPageReady && autoApplyData.AllCouponCodes) {
            var tmpCount = autoApplyData.AllCouponCodes.length;

            // if there's no cashback (unlikely), we replace the apply button text
            if (tmpCount > 0 && dbRow.CashbackRate == null) {
                let spnActionButtonText = document.createElement("span");
                spnActionButtonText.classList = "actionButtonText_" + cssBrowser;
                spnActionButtonText.innerText = (autoApplyData.ShowCouponsApp.IsShowingCoupons ? "Show" : "Apply") + ' ' + tmpCount + " Coupon" + (tmpCount > 1 ? 's' : '');
                applyButton.innerText = "";
                applyButton.appendChild(spnActionButtonText);
            }
        }
        //Update the buttons based on the current state.
        _UpdateActionButton(cashbackActivated, activateCashbackButton, applyButton, cashbackTermsLink, cashbackRateText, noDiscountsText, couponsOnlyText, (dbRow.CashbackRate != null), (dbRow.CouponCount > 0));
    };

    //Retailer is toolbar disabled
    if (dbRow._Rule === "ContinueOnBeFrugal") {
        return;
    }
    //Retailer specific offerings
	else if (retailer) {
	    showingRetailerStuff(retailer);
    }
    else {
        _sendMessage({
            action: "sptool",
            targetScript: "shoptoolbar.js",
            data: { function: "_RetailerInfoScan", args: [retailerid] }
        }, function (aBrowser) {
            if (!aBrowser) {
                _sendMessage({
                    action: "sptool",
                    targetScript: "shoptoolbar.js",
                    data: { function: "_ReadOrGetRetailerInfo", args: [retailerid, activeTab.id, null] }
                }, function (retailerInfo) {
                    _sendMessage({
                        action: "sptool",
                        targetScript: "shoptoolbar.js",
                        data: { function: "_RetailerInfoScan", args: [retailerid] }
                    }, function (aBrowser) {
                        if (!aBrowser) {
                            showingRetailerStuff(aBrowser);
                        }
                    });
                });
            }
            else {
                let aBrowserRetailer = {};
                aBrowserRetailer.Offers = aBrowser._Offers;
                aBrowserRetailer.CouponBlob = aBrowser._CouponBlob;
                aBrowserRetailer.RetailerInfo = aBrowser._RetailerInfo;
                showingRetailerStuff(aBrowserRetailer);
            }
        });
    }
}

function _LoadDealsContents(deals, searchTerm) {
    let nonretailerHeader = document.getElementById("nonretailer");
    let retailerHeader = document.getElementById("retailerSpecific");
    let searchEngineDealsWrapper = document.getElementById("searchEngineDealsWrapper");
    let searchEngineDealsContent = document.getElementById("searchEngineDealsContent");

    if (shoptoolbar._Browser !== Browsers.iOS) {
        nonretailerHeader.style.display = "block";
    }
    retailerHeader.style.display = "block";

    //Controls what specific parts of the header should be displayed.
    if (shoptoolbar._Browser !== Browsers.iOS) {
        nonretailerHeader.classList.add("show");
        retailerHeader.classList.remove("show");
    }
    else {
        retailerHeader.classList.add("show");
        _ToggleHeaderForIOS(false);
    }

    // Setup
    let dealsFoundTitle = document.createElement("div");
    dealsFoundTitle.style.textAlign = "center";
    dealsFoundTitle.style.paddingTop = "15px";

    let dealsFoundSize = "16px";
    searchEngineDealsWrapper.appendChild(dealsFoundTitle);
    searchEngineDealsContent.classList.add("show");

    /**
     * 
     * `<span style="font-weight: bold; font-size: ${dealsFoundSize};">${deals.length}</span>
     * <span style="font-size: ${dealsFoundSize};"> deals for </span>
     * <span style="font-weight: bold; font-size: ${dealsFoundSize};">"${searchTerm}"</span>`;
     * 
     * */
    let dealStr = deals.length !== 1 ? "deals" : "deal";

    let dealsFoundTitleDealsFoundLengthSpan = document.createElement("span");
    dealsFoundTitleDealsFoundLengthSpan.style.fontSize = dealsFoundSize;
    dealsFoundTitleDealsFoundLengthSpan.style.fontWeight = "bold";
    dealsFoundTitleDealsFoundLengthSpan.innerText = deals.length;

    let dealsFoundTitleDealsForSpan = document.createElement("span");
    dealsFoundTitleDealsForSpan.style.fontSize = dealsFoundSize;
    dealsFoundTitleDealsForSpan.innerText = ` ${dealStr} for `;

    let dealsFoundTitleSearchTermSpan = document.createElement("span");
    dealsFoundTitleSearchTermSpan.style.fontSize = dealsFoundSize;
    dealsFoundTitleSearchTermSpan.style.fontWeight = "bold";
    dealsFoundTitleSearchTermSpan.innerText = `"${searchTerm}"`;

    dealsFoundTitle.appendChild(dealsFoundTitleDealsFoundLengthSpan);
    dealsFoundTitle.appendChild(dealsFoundTitleDealsForSpan);
    dealsFoundTitle.appendChild(dealsFoundTitleSearchTermSpan);

    const dayLength = 60 * 60 * 24 * 1000;
    let isExpiringWithinTwentyFourHours = function (deal) {
        const now = new Date();
        const expirationDate = new Date(deal.EndDateUTC);

        return expirationDate - now < dayLength;
    }

    for (let i = 0; i < deals.length; i++) {
        let deal = deals[i];

        let dealCard = document.createElement("div");
        dealCard.style.margin = i === deals.length - 1 ? "15px 10px" : "15px 10px 0px 10px";
        dealCard.style.display = "flex";
        dealCard.style.boxShadow = "0px 2px 4px #00000054";
        dealCard.style.borderRadius = "8px";
        dealCard.style.cursor = "pointer";

        dealCard.addEventListener("click", () => {
            window.open(deal.CouponUrl, "_blank");
        });

        let itemContainer = document.createElement("div");
        itemContainer.style.display = "flex";
        itemContainer.style.flexDirection = "column";
        dealCard.appendChild(itemContainer);

        let dealTag = document.createElement("div");
        dealTag.innerText = "Deal";
        dealTag.style.backgroundColor = '#6736a3';
        dealTag.style.fontSize = '13px';
        dealTag.style.color = '#fff';
        dealTag.style.padding = '2px 6px';
        dealTag.style.borderTopLeftRadius = '8px';
        dealTag.style.borderBottomRightRadius = '8px';
        dealTag.style.width = '39px';
        dealTag.style.fontWeight = '600';
        itemContainer.appendChild(dealTag);

        let itemImage = document.createElement("img");
        itemImage.src = deal.LogoURL.startsWith("https:") ? deal.LogoURL : "https:" + deal.LogoURL;
        itemImage.style.width = "64px";
        itemImage.style.padding = "5px";
        itemContainer.appendChild(itemImage);

        let dealCardBody = document.createElement("div");
        dealCardBody.style.padding = "15px";
        dealCardBody.style.flex = "1";
        dealCard.appendChild(dealCardBody);

        let dealInfoContainer = document.createElement("div");
        dealInfoContainer.style.display = "flex";
        dealInfoContainer.style.flexDirection = "column";
        dealInfoContainer.style.justifyContent = "end";
        dealCardBody.appendChild(dealInfoContainer);

        let dealTitle = document.createElement("div");
        dealTitle.innerText = deal.OfferName;
        dealTitle.style.fontWeight = "600";
        dealTitle.style.fontSize = "14px";
        dealInfoContainer.appendChild(dealTitle);

        let dealRetailer = document.createElement("div");
        dealRetailer.innerText = deal.RetailerName;
        dealRetailer.style.fontWeight = "100";
        dealRetailer.style.fontSize = "12px";
        dealRetailer.style.marginTop = "2px";
        dealRetailer.style.flex = "1";
        dealInfoContainer.appendChild(dealRetailer);

        let priceContainer = document.createElement("div");
        priceContainer.style.display = "flex";
        priceContainer.style.alignItems = "flex-end";
        dealInfoContainer.appendChild(priceContainer);

        let newPrice = document.createElement("div");
        newPrice.innerText = deal.OfferPrice
        newPrice.style.fontWeight = "600";
        newPrice.style.marginBottom = "1px";
        priceContainer.appendChild(newPrice);

        let oldPrice = document.createElement("div");
        oldPrice.innerText = deal.OfferOriginalPrice;
        oldPrice.style.textDecoration = "line-through";
        oldPrice.style.marginLeft = "5px";
        oldPrice.style.fontSize = "14px";
        oldPrice.style.color = "#999";
        priceContainer.appendChild(oldPrice);

        if (isExpiringWithinTwentyFourHours(deal)) {
            let expirationDate = document.createElement("div");
            let hoursLeft = (new Date(deal.EndDateUTC) - new Date()) / (dayLength / 24);
            if (hoursLeft < 1) hoursLeft = Math.round(hoursLeft * 10) / 10
            else hoursLeft = Math.floor(hoursLeft);
            let hoursText = hoursLeft === 1 ? "hour" : "hours";

            priceContainer.style.justifyContent = "end";
            expirationDate.innerText = `Expires in ${hoursLeft} ${hoursText}`;
            expirationDate.style.color = "#E20015";
            expirationDate.style.fontSize = "12px";
            expirationDate.style.fontWeight = "600";
            expirationDate.style.textAlign = "end";
            expirationDate.style.flex = "1";
            expirationDate.style.paddingRight = "12px";
            priceContainer.appendChild(expirationDate);
        }

        searchEngineDealsWrapper.appendChild(dealCard);
    }

    
    popup._CurrentPopupContent = _PopupContentEnum.Retailer;
}

function Login(evt) {
    let goToJoin = function () {
        _openLink("https://" + Site + "/account/member/?show=signup", true);
    };
    GetAnonymity(function (isanon) {
        if (isanon) {
            privacyDialog(false, function (allowed) {
                if (allowed && (bsGuest || noUser)) {
                    goToJoin();
                }
                else {
                    document.getElementById("guestLoginPanel").style.display = "none";
                    document.querySelector("#newMemberNeedAccount").style.display = "none";
                }
            });
        }
        else if (bsGuest || noUser) {
            goToJoin();
        }
        else {
            document.getElementById("guestLoginPanel").style.display = "none";
            document.querySelector("#newMemberNeedAccount").style.display = "none";
        }
    });
}

function RoundPriceFromString(str) {
    //Assuming the str value has dollar signs only.
    let price = parseFloat(str.replace(/[\$]/g, ""));
    let dollars = parseInt(price.toFixed(0));
    if (Number.isNaN(price) || Number.isNaN(dollars)) {
        //Deal price is most likely discount percentages.
        return str;
    }
    if (price < 1.0) {
        //Don't round anything if the price is less than 1 dollar.
        return str;
    }
    //Price is always going to be equal to, or be greater than dollars.
    let cents = parseFloat((price - dollars).toFixed(2));
    if (Number.isNaN(cents)) {
        //Extra precaution.
        return str;
    }
    if (cents >= 0.5)
        dollars++;
    //We return string with dollar signs.
    return "$" + dollars.toString();
}

var GetRestaurantLetterJSON = function (letter, callback) {
    let url = CDNSite + '/wssimplenonshopper.asmx/GetRetailersByLetter';
    let params = Format('?startsWith={0}&retailerType=Restaurant&isShopper={1}', letter, isShopper);
    _sendMessage({
        action: "FetchJson",
        targetScript: "shoptoolbar.js",
        data: {
            url: url + params,
        }
    }, function (response) {
        if (response) {
            callback(response);
        }
        else callback(null);
    });
}

var PopulateAndFormatRestaurantCoupons = function () {
    let letterList = document.querySelector('#browseByLetter');
    letterList.appendChild(FormatLetterLink('#'));
    for (let i = 65; i < 91; i++) {
        letterList.appendChild(FormatLetterLink(String.fromCharCode(i)));
        if (String.fromCharCode(i) == "M" || String.fromCharCode(i) == "Z") {
            letterList.appendChild(document.createElement("br"));
        }
    }
}

var FormatLetterLink = function (letter) {
    let span = document.createElement('span');
    let link = document.createElement('a');
    link.href = '#';
    link.innerText = letter;
    link.classList = "restLetter";
    link.addEventListener('click', (e) => {
        PopulateSingleLetter(letter);
    });
    span.appendChild(link);
    return span;
}

var PopulateAndFormatSingleRestaurant = function (restaurantId) {
    //tour logic
    if (isTour) {
        tourInfo.TourRetailer.step = 3;
        _sendMessage({
            action: "Preference Manager",
            targetScript: "shoptoolbar.js",
            data: { pref: "TourInfo", value: tourInfo }
        });
        _sendMessage({
            request: "OpeningCoupons",
            targetScript: "instructionsInject.js"
        }, function () {
            _sendMessage({
                action: "sptool",
                targetScript: "shoptoolbar.js",
                data: { function: "_GetRetailerInfo", args: [restaurantId] }
            }, function (rInfo) {
                _LoadRetailerContents(restaurantId, false, rInfo.RetailerInfo, rInfo, "Restauarant");
                document.querySelector('#restaurantsBrowse').style.display = 'none';
                document.querySelector('#svg_closeiFramePopup').style.display = 'none';
            });
        });
    }
    else {
        _sendMessage({
            action: "sptool",
            targetScript: "shoptoolbar.js",
            data: { function: "_ReadOrGetRetailerInfo", args: [restaurantId, activeTab.id, null] }
        }, function (retailerInfo) {
            _LoadRetailerContents(restaurantId, false, retailerInfo, null, "Restauarant");
            _sendMessage({
                action: "Preference Manager",
                targetScript: "shoptoolbar.js",
                data: { pref: "PrivacyPrompt" }
            }, function (notallowed) {
                let rdso = settings.RetailerDigestStaticSettings;
                let redirectInfo = {
                    retailerId: restaurantId,
                    redirectFormat: rdso.RedirectFormat,
                    userToken: userToken,
                    isAutoRedirect: false,
                    isNotification: false,
                    isNoCashBackExtension: nocashback,
                    notAcceptedPrivacyPrompt: notallowed
                };
                _sendMessage({
                    action: "GetRetailerRedirectURL",
                    targetScript: "shoptoolbar.js",
                    data: redirectInfo
                }, function (redirectUrl) {
                    browserAdapter.UpdateTab(null, redirectUrl);
                });
            });
            document.querySelector('#restaurantsBrowse').style.display = 'none';
        });
    }
}

var PopulateSingleLetter = function (letter,callback) {
    let rbDiv = document.querySelector('#restaurantsBrowse');
    let rblDiv = document.querySelector('#restaurantsByLetter');
    rblDiv.removeChild(rblDiv.lastChild);

    SetCategoryTitle(false, "RESTAURANTS - ", letter);

    let newChild = document.createElement('div');
    GetRestaurantLetterJSON(letter, function (json) {
        if (json.length == 0) {
            let ncEmptySpan = document.createElement('span');
            ncEmptySpan.innerText = "Currently there are no restaurants starting with "+ letter + ".  Please check back soon!";
            ncEmptySpan.style = "font-size: 16px;color: #808080;padding:12px;font-style:italic;font-weight:100;white-space: pre-wrap;";
            newChild.style = "text-align:center; padding-top:15px;width:400px";
            newChild.appendChild(ncEmptySpan);
        } else {
            let ncBody = document.createElement('div');
            ncBody.className = "restaurantGridWrapper";
            for (let iterator in json) {
                ncBody.appendChild(PopulateRestaurantByLetterSegment(json[iterator]));
            }
            newChild.appendChild(ncBody);
        }

        rblDiv.appendChild(newChild);
        rbDiv.style.display = "none";
        rblDiv.style.display = "block";
        if (callback != null) {
            callback();
        }
    });
    rblDiv.appendChild(newChild);
    rbDiv.style.display = "none";
    rblDiv.style.display = "block";

}

var PopulateRestaurantByLetterSegment = function (fragment) {
    let container = document.createElement('div');

    let favoritesCheck = popup._FavoritesList.filter(x => x && x.retailerID === fragment.RetailerID).length > 0;

    let restaurantSquare = popup._CreateStore({
        CashbackRate: fragment.CashbackRate,
        RetailerID: fragment.RetailerID,
        RetailerName: fragment.RetailerName,
        InternalName: fragment.InternalName,
        ImgUrl: fragment.ImgUrl,
        CouponCount: fragment.CouponCount
    }, favoritesCheck, "Restaurant");

    restaurantSquare.addEventListener('click', (e) => {
        PopulateAndFormatSingleRestaurant(fragment.RetailerID);
    });

    container.appendChild(restaurantSquare);

    return container;
}

var ReadyGrocerySection = function () {
    let GCLink = document.querySelector('a#groceryCoupons').parentElement;
    let GCSection = document.querySelector('#groceryCouponsSection');
    let catSection = document.querySelector('#categoriesHome');
    let backButton = document.querySelector('a#backToCategoriesLink');
    let gcsHome = document.querySelector('#gcsHome');
    let gcsCatSec = document.querySelector('#gcsCategories');
    let gcsBrandSec = document.querySelector('#gcsBrands');
    let tabsSelector = document.getElementById('tabs');

    if (settings.RetailerDigestStaticSettings) {
        document.getElementById("gccCount").innerText = settings.RetailerDigestStaticSettings.GroceryCount + " ";
    }

    GCLink.addEventListener('click', (e) => {
        if (isTour) {
            tourInfo.TourRetailer.step = 3;
            _sendMessage({
                action: "Preference Manager",
                targetScript: "shoptoolbar.js",
                data: { pref: "TourInfo", value: tourInfo }
            }, function () {
                _sendMessage({
                    request: "ClickedRestaurants",
                    targetScript: "instructionsInject.js"
                });
            });
        }
        GCSection.style.display = 'block';
        catSection.style.display = 'none';
        backButton.style.display = 'inline-block';
        tabsSelector.style.display = "none";
    });
    GCLink.addEventListener('click', (e) => {
        document.querySelector('#groceryCategoriesLink').addEventListener('click', (e) => {
            SetCategoryTitle(false, "GROCERY COUPONS: ", "CATEGORIES");
            gcsCatSec.style.display = 'block';
            gcsHome.style.display = 'none';
        });
        document.querySelector('#groceryBrandsLink').addEventListener('click', (e) => {
            SetCategoryTitle(false, "GROCERY COUPONS: ", " BRANDS");
            gcsBrandSec.style.display = 'block';
            gcsHome.style.display = 'none';
        });
        _sendMessage({
            action: "sptool",
            targetScript: "shoptoolbar.js",
            data: { function: "GetGroceryInfo" }
        }, function (info) {
            ReadyGCategorySection(info.CouponsByCategory);
            ReadyGBrandSection(info.CouponsByBrand);
        });

        let grocerySearch = function (searchTerm) {
            let grocerySearchPage = "https://www.befrugal.com/printable/grocery/";
            let redirectPage = grocerySearchPage + encodeURIComponent(searchTerm);

            browserAdapter.UpdateTab(null, redirectPage);
        }

        let textBox = document.querySelector('#gcSearchText');
        document.querySelector('#gcSearchButton').addEventListener('click', (e) => {
            grocerySearch(textBox.value);
        });
        document.querySelector('#gcSearchButton').addEventListener('focus', (e) => {
            document.getElementById("gcSearchText").focus();
        });
        document.querySelector('#gcSearchButton').addEventListener('blur', (e) => {
            document.getElementById("gcSearchText").blur();
        });
        textBox.addEventListener('keydown', (e) => {
            if (e.code == "Enter") {
                grocerySearch(textBox.value);
            }
        });
    }, { once: true });
}

var ReadyGCategorySection = function (gCatInfo) {
    let catListSec = document.querySelector('#gcsCatBody');
    let catList = Object.keys(gCatInfo);
    let formatCategoryLink = function (catName, iterator) {
        let linkDiv = document.createElement('div');
        linkDiv.className = "catLink";
        let link = document.createElement('td');
        linkDiv.style = "padding:5px 0px 5px 30px;font-weight:500;";
        if (parseInt(iterator) % 2 !== 0) {
            linkDiv.style.backgroundColor = "#F2F9FF";
        }
        link.innerText = catName;
        link.style = "font-size:14px";
        link.href = '#';
        linkDiv.addEventListener('click', (e) => { ListIndividualCategoryCoupons(gCatInfo, catName); });
        linkDiv.appendChild(link);
        return linkDiv;
    }
    for (let iterator in catList) {
        catListSec.appendChild(formatCategoryLink(catList[iterator], iterator));
    }
    let blankDiv = document.createElement('div');
    if (catList.length%2 !== 0)
        blankDiv.style.backgroundColor = "#F2F9FF";
    catListSec.appendChild(blankDiv);
}

//We keep a breadcrumb of titles
var categoryHistory = [];
var SetCategoryTitle = function(startNav, titleText, noncapsection){
    if(startNav) categoryHistory = [];
    let contentArea = document.getElementById('newContent');
    let categoryHeading = document.getElementById('categoryHeading');
    let headerSection = document.querySelector("#categoryHeading .sectionTitle");

    let addToHeader = function(text, subSection){
        let bcHeader = document.createElement('span');
        bcHeader.innerText = text;
        bcHeader.classList = subSection ? "sectionTitleBold" : "sectionTitleUppercase";
        bcHeader.id = subSection ? "subCategorySection": "categorySection";
        headerSection.appendChild(bcHeader);
    };
    headerSection.textContent = "";
    if (titleText) {

        addToHeader(titleText, false);
        if(noncapsection){
            addToHeader(noncapsection, true);
        }
        contentArea.classList.remove("noHeader");
        headerSection.style.display = "inline";
        categoryHeading.style.display = "block";
    }
    else {
        //if no text show just the line and resize
        contentArea.classList.add("noHeader");
        headerSection.style.display = "none";
        categoryHeading.style.display = "inline";
    }

    categoryHistory.push(headerSection.cloneNode(true));
};
var SetBackCategoryTitle = function(){
    if(categoryHistory.length > 1){
        categoryHistory.pop();
        let headerSection = document.querySelector("#categoryHeading .sectionTitle");
        let oldNode = categoryHistory[categoryHistory.length - 1];
        headerSection.parentElement.replaceChild(oldNode.cloneNode(true), headerSection);
    }
    else if(categoryHistory.length > 0){
        let headerSection = document.querySelector("#categoryHeading .sectionTitle");
        headerSection.parentElement.replaceChild(categoryHistory[0].cloneNode(true), headerSection);
    }
};

var ListIndividualCategoryCoupons = function (gCatInfo, categoryName) {
    let categoryCoupons = gCatInfo[categoryName];
    let couponContainer = document.querySelector('#gcsCoupon');
        
    //clear children by setting content
    couponContainer.textContent = "";

    couponContainer.setAttribute("gtype", "category");

    SetCategoryTitle(false, "Grocery Coupons: ", categoryName.toUpperCase());

    let smHeader = document.createElement('div');
    let smSpanCouponCount = document.createElement('h4');
    smSpanCouponCount.innerText = categoryCoupons.length;
    smHeader.id = "gcsCouponCountHeader";
    smHeader.appendChild(smSpanCouponCount);
    smHeader.appendChild(document.createTextNode(" Grocery Coupons for " + categoryName));
    couponContainer.appendChild(smHeader);

    for (let iterator in categoryCoupons) {
        couponContainer.appendChild(formatCoupon(categoryCoupons[iterator],iterator));
    }

    couponContainer.style.display = 'block';
    document.querySelector('#gcsCategories').style.display = 'none';
}

var ReadyGBrandSection = function (gBrandInfo) {
    let letterList = document.querySelector('#gcsBrandLetters');
    letterList.style="text-align:center; padding-bottom:15px";
    let brandList = document.querySelector('#gcsBrandBody');
    let FormatGLetterLink = function (letter) {
        let linkSpan = document.createElement('span');
        let link = document.createElement('a');
        link.innerText = ' ' + letter + ' ';
        link.href = '#';
        link.className = 'GLetter';
        link.style = "font-size: 20px;display: inline-block;margin: 2px 5px;font-weight:bolder;"
        linkSpan.addEventListener('click', (e) => {
            if (document.querySelector(".currGLetter")) {
            document.querySelector(".currGLetter").className="GLetter";
        }
            link.className= "currGLetter";
            if (brandList.firstChild) brandList.removeChild(brandList.firstChild);
            brandList.appendChild(ListSingleGCLetter(gBrandInfo, letter));
        });
        linkSpan.appendChild(link);
        return linkSpan;
    }
    letterList.appendChild(FormatGLetterLink('#'));
    for (let i = 65; i < 91; i++) {
        letterList.appendChild(FormatGLetterLink(String.fromCharCode(i)));
        if (String.fromCharCode(i) == "M" || String.fromCharCode(i) == "Z") {
            letterList.appendChild(document.createElement("br"));
        }
    }
}

var ListSingleGCLetter = function (gBrandInfo, letter) {
    let listingArea = document.createElement('tbody');
    //listingArea.className = "gcsBrandGridWrapper";
    let formatBrand = function (brandName,iterator) {
        let brandLink = document.createElement('td');
        brandLink.className="brandLink";
        brandLink.href = '#';
        brandLink.innerText = brandName;
        brandLink.style="text-align:left;padding:5px 0px 5px 30px;font-weight:500;width:50%;font-size:14px";
        brandLink.addEventListener('click', (e) => {
            let singleBrand = gBrandInfo[brandName];
            let couponContainer = document.querySelector('#gcsCoupon');
            //clearing children
            couponContainer.textContent = "";

            couponContainer.setAttribute("gtype", "brand");

            SetCategoryTitle(false, "GROCERY COUPONS: ", brandName);

            let smHeader = document.createElement('div');
            let smSpanCouponCount = document.createElement('h4');
            smSpanCouponCount.innerText = singleBrand.length;
            smHeader.id = "gcsBrandCouponCountHeader";
            smHeader.appendChild(smSpanCouponCount);
            smHeader.appendChild(document.createTextNode(" Grocery Coupons for " + brandName));
            couponContainer.appendChild(smHeader);


            for (let iterator in singleBrand) {
                couponContainer.appendChild(formatCoupon(singleBrand[iterator],iterator));
            }
            couponContainer.style.display = 'block';
            document.querySelector('#gcsBrands').style.display = 'none';
        });
        return brandLink;
    }
    let brandList = [];
    if (letter == '#') {
        //get all the brands that don't start with a letter
        let brandRegex = /^[^a-zA-Z]/;
        brandList = Object.keys(gBrandInfo).filter(k => k.match(brandRegex));
    } else {
        brandList = Object.keys(gBrandInfo).filter(k => (k.toUpperCase().indexOf(letter) == 0));
    }
    for (let i=0;i<brandList.length/2;i++) {
        let brandRow = document.createElement('tr');
         if (i % 2==0) {
            brandRow.style.backgroundColor = "#F2F9FF";
        }
        listingArea.appendChild(brandRow);
    }
    for (let i = 0; i < brandList.length / 2; i++) {
        listingArea.childNodes[i].appendChild(formatBrand(brandList[i], i));
        if(formatBrand(brandList[Math.ceil(i+(brandList.length / 2))],Math.ceil(i+(brandList.length / 2))).innerText!=="undefined"){
            listingArea.childNodes[i].appendChild(formatBrand(brandList[Math.ceil(i+(brandList.length / 2))],Math.ceil(i+(brandList.length / 2))));
        } else {
            let blankDiv = document.createElement('div');
            blankDiv.style.backgroundColor = "#F2F9FF";
            listingArea.childNodes[i].appendChild(blankDiv);
}
    }
    return listingArea;
}

var CustomBackButtonFunction = function (fromElementId, toElementId) {
    for (let iterator in fromElementId) {
        document.querySelector(fromElementId).style.display = 'none';
    }
    document.querySelector(toElementId).style.display = 'block';
    SetBackCategoryTitle();
}

var formatCoupon = function (singleBrandCoupon,iterator) {
    let bcCoupon = document.createElement('div');
    bcCoupon.className="bcCoupon";
    let savings = document.createElement('span');
    savings.innerText = singleBrandCoupon.Discount;
    savings.style = "color: #2196f3; font-weight: bolder; text-align:left;padding:7px 0px 6px 10px;font-size:14px;";
    let bNameSpan = document.createElement('span');
    bNameSpan.innerText = singleBrandCoupon.Brand;
    bNameSpan.style = "font-weight: bolder; padding:7px 0px 6px 20px;";
    let name = document.createElement('span');
    name.innerText = singleBrandCoupon.Description;
    name.style = "text-overflow:ellipsis;overflow:hidden;white-space:nowrap; font-weight:500;padding:7px;text-align:left";
    let link = document.createElement('td');
    //link.href = singleBrandCoupon.OfferURL;
    link.classList = "icon-chevron-right singleCouponArrow"; 
   // link.style = "color: #2196f3;";
    bcCoupon.style = "display: grid; grid-template-columns: 95px auto 1fr 0fr;width:400px;"
    if (parseInt(iterator) % 2 !== 0) {
        bcCoupon.style.backgroundColor = "#F2F9FF";
     }
    bcCoupon.appendChild(savings);
    bcCoupon.appendChild(bNameSpan);
    bcCoupon.appendChild(name);
    bcCoupon.appendChild(link);

    bcCoupon.addEventListener('click', (e) => { displaySingleCoupon(singleBrandCoupon); });
    return bcCoupon;
}

var displaySingleCoupon = function (couponDetails) {
    let couponList = document.querySelector('#gcsCoupon');
    let singleCouponContainer = document.querySelector('#gcsSingleCoupon');
    singleCouponContainer.style = "padding:10px;text-align:center;width:400px";

    SetCategoryTitle(false, "GROCERY COUPONS: ", couponDetails.Brand)
    
    //clear children
    singleCouponContainer.textContent = "";

    let cImage;
    if (couponDetails.Class != 's-grocery-db-image') {
        cImage = document.createElement('div');
        cImage.classList.add(couponDetails.Class);
    } else {
        cImage = document.createElement('img');
        cImage.src = "https:" + couponDetails.ImageURL;
    }
    let couponTextBox = document.createElement("div");
    let cSavings = document.createElement('a');
    cSavings.style="font-weight:bolder; font-size:15px";
    cSavings.innerText = couponDetails.Discount;
    cSavings.href = '#';
    let cBrand = document.createElement('div');
    cBrand.style= "font-weight:bolder";
    cBrand.innerText = couponDetails.Brand;
    let cDesc = document.createElement('div');
    cDesc.innerText = couponDetails.Description;
    let cGetThis = document.createElement('span');
    cGetThis.innerText = "Get Coupon";
    cGetThis.style="text-align:center;padding:10px 50px; color: white;cursor: pointer; border-radius: 8px;";
    let sCCWrapper = document.createElement('div');
    let imgContainer=document.createElement('div');
    sCCWrapper.style = "text-align:center;padding-bottom:25px;background-color: #F2F9FF; border: 1px solid #ddd; width: 100% !important; cursor: pointer;";
    sCCWrapper.className = "globalBoxShadow";
    couponTextBox.style = "padding:10px 15px 30px 10px;text-align:left;";
    imgContainer.appendChild(cImage);
    imgContainer.style="background-color:white; padding:10px;text-align:center;"
    sCCWrapper.appendChild(imgContainer);
    sCCWrapper.appendChild(couponTextBox);
    couponTextBox.appendChild(cSavings);
    couponTextBox.appendChild(cBrand);
    couponTextBox.appendChild(cDesc);
    sCCWrapper.appendChild(cGetThis);
    singleCouponContainer.appendChild(sCCWrapper);
    sCCWrapper.addEventListener('click', (e) => {
        let urlToRedirect = /^[a-zA-z]/.test(couponDetails.OfferURL) ? couponDetails.OfferURL : "https://www.befrugal.com" + couponDetails.OfferURL;
        browserAdapter.UpdateTab(null, urlToRedirect);
    });
    couponList.style.display = 'none';
    singleCouponContainer.style.display = 'block';
}

var DisplayOnlineCouponsSection = function () {
    let backButton = document.querySelector('#backToCategoriesLink');
    let ocSection = document.querySelector('#onlineCouponSection');

    let allCouponsHeaderLink = document.querySelector('#seeAllLink2');
    if (popup._OnlineCouponsLoaded) {
        backButton.style.display = 'inline-block';
        ocSection.style.display = 'block';
        document.querySelector('#categoriesHome').style.display = 'none';
        allCouponsHeaderLink.style.display = 'block';
    } else {
        _sendMessage({
            action: "sptool",
            targetScript: "shoptoolbar.js",
            data: { function: "GetCVOnlineCoupons" }
        }, function (cvocData) {
            // Move us into online coupons, activate the back button
            backButton.style.display = 'inline-block';
            let formatCoupon = function (couponData) {
                let couponContainer = document.createElement('table');
                couponContainer.cellPadding = 0;
                couponContainer.cellSpacing = 0;
                couponContainer.border = 0; 
                couponContainer.width = "99%";
                couponContainer.classList.add('popupTopOC');
                couponContainer.classList.add('globalBoxShadow');
                let cctbody = document.createElement('tbody');
                cctbody.className="singleOnlineCoupon";
                let cctrleft = document.createElement('td');
                cctrleft.classList.add('cc_tr_left');
                let cctrright = document.createElement('td');
                cctrright.classList.add('cc_tr_right');
                let cImage = document.createElement('img');
                cImage.src = 'https:' + couponData.ImgUrl;
                let cExpires = document.createElement('span');
                let expDate = new Date(couponData.EndDate);
                cExpires.style.fontWeight = 500;
                cExpires.style.color = "#B5B5B5";
                let now = new Date();
                if (!expDate || expDate.getFullYear() > 3000) {
                    cExpires.innerText = 'Expires Soon';
                } else if (expDate.getDate() == now.getDate() && now.getYear() == expDate.getYear() && now.getMonth() == expDate.getMonth()) {
                    cExpires.innerText = "Expires Today";
                    cExpires.style.color = "#D6522A";
                } else {
                    let monthString = expDate.toDateString().substring(4, 7);
                    cExpires.innerText = 'Expires ' + monthString + '-' + expDate.getDate();
                }
                let cType = couponData.Classification.Name;
                let cDirectionWrapper = document.createElement('div');
                let cDirection = document.createElement('span');
                cDirectionWrapper.appendChild(cDirection);
                cDirection.style.fontWeight = 600;
                cDirection.style.fontSize = '16px';
                if (cType == 'Printable') {
                    cDirection.innerText = "Get Offer >";
                    cDirection.style.color = '#3293F3';
                } else if (couponData.OfferCode == '') {
                    cDirection.style.color = '#3293F3';
                    cDirection.innerText = "Get Offer >";
                } else {
                    let innerAnchor = document.createElement('a');
                    innerAnchor.classList = "copyOfferCode";
                    innerAnchor.setAttribute("code", couponData.OfferCode);
                    let innerDiv = document.createElement('span');
                    innerDiv.classList = "itemPromoCode itemCursor";
                    innerDiv.setAttribute("offerId", couponData.OfferId);
                    innerDiv.innerText = couponData.OfferCode;
                    let copiedDiv = document.createElement('span');
                    copiedDiv.classList = "itemCopied bfslider_clearFix";
                    copiedDiv.style = "display: none;text-decoration:none;line-height:18px;padding-left:10px";
                    let copiedSpan = document.createElement('span');
                    copiedSpan.classList = "icon-checkmark-full-small";
                    copiedDiv.appendChild(copiedSpan);
                    copiedDiv.appendChild(document.createTextNode("Copied"));
                    innerDiv.appendChild(copiedDiv);
                    innerAnchor.appendChild(innerDiv);
                    innerAnchor.appendChild(copiedDiv);
                    cDirection.appendChild(innerAnchor);


                    let copyCode = cDirection.querySelector("a.copyOfferCode[code]");
                    if (copyCode != null) {

                        //Click event for copying the promo code, if code exists.
                        let onCopyHandler = function (e) {
                            e.preventDefault();
                            e.stopPropagation();
                            let copyFrom = document.createElement("textarea");
                            let copyCode = e.target.parentNode.querySelector("a.copyOfferCode[code]");
                            if (!copyCode) {
                                copyCode = e.target.parentNode;
                            }
                            //copy text
                            copyFrom.textContent = (copyCode && copyCode.getAttribute("code")) || e.target.innerText;
                            document.body.appendChild(copyFrom);
                            copyFrom.select();
                            document.execCommand('copy');
                            copyFrom.blur();
                            document.body.removeChild(copyFrom);

                            //show copied text for some time
                            copyCode.querySelector("span.itemCopied").style.display = "inline-block";
                            setTimeout(() => {
                                copyCode.querySelector("span.itemCopied").style.display = "none";
                            }, 2000);
                            return false;
                        };

                        copyCode.addEventListener("click", onCopyHandler);
                    }

                    

                }
                let cName = document.createElement('div');
                cName.innerText = couponData.OfferName;
                couponContainer.appendChild(cctbody);
                cctbody.appendChild(cctrleft);
                cctbody.appendChild(cctrright);
                cctrleft.appendChild(cExpires);
                cctrleft.appendChild(cImage);
                cctrright.appendChild(cName);
                cctrright.appendChild(cDirection);
                couponContainer.addEventListener('click', (e) => {
                    RedirectPopupAndPage(couponData.RedirectUrl + (noCookCheck() ? "&nocook=true" : ""), couponData.RetailerId);
                });
                return couponContainer;
            }
            for (iterator in cvocData) {
                let tmpCoupon = formatCoupon(cvocData[iterator]);
                tmpCoupon.addEventListener('click', function () {
                    let tp = document.querySelector("#Tooltip");
                    if (tp)
                        tp.parentNode.removeChild(tp);
                });
                ocSection.appendChild(tmpCoupon);
            }
            popup._OnlineCouponsLoaded = true;

            allCouponsHeaderLink.addEventListener('click', (e) => {
                browserAdapter.UpdateTab(null, 'https://www.befrugal.com/coupons/stores/');
            });
            allCouponsHeaderLink.style.display = 'block';
            ocSection.style.display = 'block';
            document.querySelector('#categoriesHome').style.display = 'none';
        });
    }
}

var RedirectPopupAndPage = function (pageURL, popupRetailerId) {
    _sendMessage({
        action: "sptool",
        targetScript: "shoptoolbar.js",
        data: { function: "_ReadOrGetRetailerInfo", args: [popupRetailerId, activeTab.id, null] }
    }, function (retailerInfo) {
        _LoadRetailerContents(popupRetailerId, false, retailerInfo);
        browserAdapter.UpdateTab(null, pageURL);
        document.querySelector('#restaurantsBrowse').style.display = 'none';
    });
}

var popup = function () {
    return {
        CashbackTerms: new Map(),
        _CurrentPopupContent: _PopupContentEnum.Homepage,
        _SearchListeners: {},
        _EndTextListeners: {},
        _EndTextOutListeners: {},
        _FavoritesList: [],
        _DealsInit: false,
        _WeeklyAdsInit: false,
        _OnlineCouponsLoaded: false,
        banners: [],
        bannerIndex: 0,
        bannerTimeoutHandle: 0,
        bannerTimeoutDuration: 5 * 1000,
        scrollTopValue: 0,
        toastHandle: 0,
        _TabPanes: {
            tabs: [],
            _AnimationCount: 2,
            _CurrentAnimationCount: 0,
            _Init: function () {
                //Need to remove whichever tab we're not using to prevent errors.
                popup._RemoveUnusedTab();
                _sendMessage({
                    action: "Preference Manager",
                    targetScript: "shoptoolbar.js",
                    data: { pref: "PopupPaneAnimationHistory" }
                }, function (popupAnimationHistory) {
                    let preOccupiedArray = popupAnimationHistory && popupAnimationHistory.TabPanes ? popupAnimationHistory.TabPanes : null;
                    let tabPanes = document.querySelectorAll("div#homeContent ul.newNavigationTabClass_bf div.newNavigationTabOption_bf");
                    let hasPreviousData = (Array.isArray(preOccupiedArray) && preOccupiedArray.length > 0);

                    //the tabs are only present on cash back extensions
                    if (nocashback) {
                        document.getElementById('newSearchBar').setAttribute("placeholder", "Search stores, coupons & deals");
                        document.getElementById('tabs').style.display = "none";
                        document.getElementById("newFooter").style.display = "none";
                        document.getElementById('cvEarnCashBack').style.display = "block";
                        document.getElementById('cvEarnCashBack').addEventListener('click', (e) => {
                            if (!settings.Config.IsButtonInstalled) {
                                document.getElementById('installButtonDialog').style.display = "block";
                            }
                            else {
                                _openLinkInCurrentTab("https://www.befrugal.com/home/");
                            }
                        });
                        document.getElementById('spanAddButtonPrivacyPolicy').onclick = function () {
                            _openLinkInCurrentTab("https://www.befrugal.com/help/privacypolicy/");
                        };
                        document.getElementById('spanAddButtonTerms').onclick = function () {
                            _openLinkInCurrentTab("https://www.befrugal.com/termsandconditions/");
                        };
                        document.getElementById('installButtonDialogClose').onclick = function () {
                            document.getElementById('installButtonDialog').style.display = "none";
                        };
                        document.getElementById('addButtonButton').onclick = function () {
                            _openLink(((settings.Config.UpdateUrl && settings.Config.UpdateUrl.length > 0) ? settings.Config.UpdateUrl : "https://chromewebstore.google.com/detail/logldmlncddmdfcjaaljjjkajcnacigc?hl=en-US"));
                        };
                    }
                    else {
                        //we shake again after 1 week. Store date of the next shake and store when the second click is comepleted
                        let weekLaterDone = popupAnimationHistory && popupAnimationHistory.WeekReShakeComplete ? true : false;
                        let weekReShakeDate = popupAnimationHistory && popupAnimationHistory.WeekReShakeDate ? popupAnimationHistory.WeekReShakeDate : null;
                        let nextWeek = new Date(Date.now()); nextWeek.setDate(nextWeek.getDate() + 7);
                        let resetWeekCheck = !weekLaterDone && weekReShakeDate && weekReShakeDate > nextWeek.getTime();

                        for (let i = 0; i < tabPanes.length; i++) {
                            let currentDom = tabPanes[i];
                            let tab = popup._TabPanes.tabs[i];

                            currentDom.setAttribute("tabPaneNumber", i);

                            if (!tab) {
                                popup._TabPanes.tabs.push({
                                    hasActiveShow: currentDom.classList.contains("active") || currentDom.classList.contains("show"),
                                    hasClicked: (hasPreviousData && !resetWeekCheck ? preOccupiedArray[i].hasClicked : false),
                                    playCount: 0
                                });
                            }
                            else {
                                tab.hasActiveShow = currentDom.classList.contains("active") || currentDom.classList.contains("show");
                                tab.hasClicked = (hasPreviousData && !resetWeekCheck ? preOccupiedArray[i].hasClicked : false);
                                tab.playCount = 0;
                            }
                            currentDom.addEventListener("mouseup", (e) => {
                                popup._TabPanes._StopAllAnimations();
                                let tabPaneNumber = parseInt(currentDom.getAttribute("tabPaneNumber"));
                                let tab = popup._TabPanes.tabs[tabPaneNumber];
                                if (tab) {
                                    tab.hasClicked = true;
                                    tab.playCount = popup._TabPanes._AnimationCount;
                                }
                                if (resetWeekCheck) {
                                    weekLaterDone = true;
                                }

                                //We populate the Deals section.
                                if (tabPaneNumber === 1 && !popup._DealsInit && isButton) {
                                    popup._DealsInit = true;
                                    popup._GetDeals();
                                }

                                //refer a friend not available if anon
                                if (tabPaneNumber === 2) {
                                    GetAnonymity(function (isanon) {
                                        if (isanon) {
                                            privacyDialog(false, function (allowed) {
                                                if (!allowed) {
                                                    tabPanes[0].click();
                                                }
                                                else {
                                                    popup._GetFavoriteStores();
                                                }
                                            });
                                        }
                                    });
                                }
                                _sendMessage({
                                    action: "Preference Manager",
                                    targetScript: "shoptoolbar.js",
                                    data: { pref: "PopupPaneAnimationHistory", value: { TabPanes: popup._TabPanes.tabs, WeekReShakeDate: nextWeek.getTime(), WeekReShakeComplete: weekLaterDone } }
                                });
                            });
                        }

                        if (!weekLaterDone) {
                            popup._TabPanes._PlayFromBeginning();
                        }


                        // Making it seem scary that there could be conflicts
                        if (isChrome && !isTour) {
                            _sendMessage({
                                action: "Preference Manager",
                                targetScript: "shoptoolbar.js",
                                data: { pref: "ConflictAlert" }
                            }, function (cAlert) {
                                if (cAlert) {
                                    if (shoptoolbar._Browser !== Browsers.iOS) {
                                        let settingsSec = document.querySelector('div#settingsTab');
                                        let settingsIcon = document.querySelector('div#settingsTab div');
                                        settingsSec.style.color = "#E65049";
                                        settingsIcon.classList.remove('icon-gear');
                                        settingsIcon.classList.add('icon-warning-filled');
                                    }
                                    let innerGrayout = document.querySelector('#innerGrayout');
                                    innerGrayout.style.display = 'inherit';

                                    //create the settings page div that pops over everything
                                    let disablePopceptionLink = document.querySelector('#fixedConflictAlert a');
                                    let disablePopception = document.querySelector('#fixedConflictAlert');
                                    disablePopception.style.display = 'block';
                                    disablePopceptionLink.addEventListener('click', function (event) {
                                        _sendMessage({
                                            action: "popupWorkaround",
                                            targetScript: "disableBackgroundApp.js",
                                        });
                                    });

                                    let hiddenMessage = document.querySelector('#disableDisclaimerInfo');
                                    let moreInfoSpan = document.querySelector('#disableDisclaimerInfoText');
                                    hiddenMessage.addEventListener('click', function (event) {
                                        moreInfoSpan.style.display = 'block';
                                    });
                                    document.querySelector('#disableDisclaimerCloseButton').addEventListener('click', function (event) {
                                        moreInfoSpan.style.display = 'none';

                                    });

                                    let overallClose = document.querySelector('#conflictAlertCloseButton');
                                    overallClose.addEventListener('click', function (event) {
                                        _sendMessage({
                                            action: "Preference Manager",
                                            targetScript: "shoptoolbar.js",
                                            data: { pref: "ConflictAlert", value: false }
                                        });
                                        disablePopception.style.display = 'none';
                                        innerGrayout.style.display = 'none';
                                        popup._TabPanes._PlayFromBeginning();
                                    });
                                }
                            });
                        }
                    }

                    //ReadyCategoryContents
                    if (!isButton) {
                        PopulateAndFormatRestaurantCoupons();
                        let tdLink = document.getElementById('atodaysDeals');
                        let rcLink = document.getElementById('restaurantCoupons');
                        let gcLink = document.getElementById('groceryCoupons');
                        let acLink = document.getElementById('adCirculars');
                        let ocLink = document.getElementById('onlineCoupons');
                        let catHome = document.getElementById('categoriesHome');
                        let backToCatButton = document.getElementById('backToCategoriesLink');
                        let seeAllLink = document.getElementById('seeAllLink');
                        let seeAllLink2 = document.getElementById('seeAllLink2');
                        let tabsSelector = document.getElementById('tabs');
                        let categoryHeading = document.getElementById('categoryHeading');
                        let footerHomeNav = document.getElementById('footerHomeNav');
                        let headerChange = document.getElementById("header");
                        let contentArea = document.getElementById('newContent');

                        let clearHomeSelected = function () {
                            footerHomeNav.classList.remove("active");
                            footerHomeNav.classList.remove("show");
                        };

                        let hideHomeCategoryLinks = function (title) {
                            catHome.style.display = 'none';
                            tabsSelector.style.display = "none";
                            backToCatButton.style.display = 'inline-block';
                            SetCategoryTitle(true, title);
                        };

                        //block off areas during the tour
                        if (isTour) {
                            let isRestaurantTour = tourInfo.TourRetailer.pageType === "Restaurant";
                            let isWeeklyTour = tourInfo.TourRetailer.pageType === "WeeklyAd";
                            let restaurantCoupons = document.getElementById("restaurantCoupons");
                            let groceryCoupons = document.getElementById("groceryCoupons");
                            let adCirculars = document.getElementById("adCirculars");
                            let tourCouponEle = (isRestaurantTour ? restaurantCoupons : (isWeeklyTour ? adCirculars : groceryCoupons));
                            tourCouponEle.parentElement.classList.add('tourHighlight');
                            document.addEventListener("click", function (e) {
                                //only block while tour mode is on
                                if (isTour && tourInfo && (tourInfo.TourRetailer.step !== 3 || tourInfo.OneStepRST) && !e.target.closest("#svg_closeiFramePopup")) {
                                    if (e.target == tourCouponEle || e.target == tourCouponEle.parentElement || e.target.closest(".tourHighlight")) {
                                        return;
                                    }
                                    let restaurantSqaure = document.querySelector("#restaurantsByLetter #Restaurant" + tourInfo.TourRetailer.retailerId);
                                    if (restaurantSqaure && e.target && (e.target == restaurantSqaure || restaurantSqaure.contains(e.target))) {
                                        return;
                                    }
                                    let retailerOffers = document.querySelector("#retailerOffersContainer");
                                    if (retailerOffers && e.target && (e.target == retailerOffers || retailerOffers.contains(e.target))) {
                                        return;
                                    }
                                    e.stopPropagation();
                                    e.preventDefault();
                                }
                                else if (isTour) {
                                    _sendMessage({
                                        request: "TourFinished",
                                        targetScript: "instructionsInject.js"
                                    }, function () {
                                        isTour = false;
                                    });
                                }
                            }, true);
                        }

                        seeAllLink.addEventListener('click', (e) => {
                            _openLink("https://www.befrugal.com/weeklyads/");
                        });

                        tdLink.parentElement.addEventListener('click', (e) => {
                            hideHomeCategoryLinks("TODAY'S DEALS");
                            let dealsCatArea = document.getElementById('todaysDealsSection');
                            //We populate the Deals section.
                            if (!popup._DealsInit) {
                                let dealsTabArea = document.querySelector('#todaysDeals .ss-content');
                                dealsTabArea.classList = "";
                                dealsCatArea.appendChild(dealsTabArea);
                                popup._GetDeals(function () {
                                    popup._DealsInit = true;
                                    dealsCatArea.style.display = "block";
                                });
                            }
                            else {
                                dealsCatArea.style.display = "block";
                            }
                            clearHomeSelected();
                        });

                        rcLink.parentElement.addEventListener('click', (e) => {
                            hideHomeCategoryLinks("POPULAR RESTAURANTS");

                            //tour logic
                            if (isTour){
                                _sendMessage({
                                    request: "ClickedRestaurants",
                                    targetScript: "instructionsInject.js"
                                }, function () {
                                    //we start with the letter of the restaurant preselected
                                    var startLetter = tourInfo.TourRetailer.retailerName[0];
                                    if (!startLetter) return;// if the tour somehow got aborted
                                    var letterCode = startLetter.charCodeAt(0);
                                    var position = 0;
                                    if (letterCode > 64 && letterCode < 91)
                                        position = letterCode - 64;
                                    else startLetter = "#";

                                    PopulateSingleLetter(startLetter, function () {
                                        let rId = tourInfo.TourRetailer.retailerId;
                                        let trDiv = document.querySelector('div#restaurantsByLetter div#Restaurant' + rId);
                                        trDiv.scrollIntoView({ block: "center" });
                                        trDiv.classList.add('tourHighlight');
                                    });
                                });
                            }

                            document.getElementById('restaurantsSection').style.display = 'block';
                            _sendMessage({
                                action: "sptool",
                                targetScript: "shoptoolbar.js",
                                data: { function: "_GetPopularRestaurants" }
                            }, function (popularRestaurants) {
                                if (!document.getElementById("popularRestaurants").hasChildNodes()) {
                                    let container = document.createElement('div');
                                    container.className = "storeGridWrapper";
                                    for (let i = 0; i < 6; i++) {
                                        let currRestaurant = popularRestaurants["PopularRestaurants"][i];
                                        let favoritesCheck = popup._FavoritesList.filter(x => x && x.retailerID === currRestaurant.RetailerID).length > 0;
                                        let restaurantSquare = popup._CreateStore({
                                            CashbackRate: currRestaurant.CashbackRate,
                                            RetailerID: currRestaurant.RetailerID,
                                            RetailerName: currRestaurant.RetailerName,
                                            InternalName: currRestaurant.InternalName,
                                            ImgUrl: currRestaurant.ImgUrl,
                                            CouponCount: currRestaurant.CouponCount
                                        }, favoritesCheck, "Restaurant");

                                        restaurantSquare.addEventListener('click', (e) => {
                                            PopulateAndFormatSingleRestaurant(currRestaurant.RetailerID);
                                        });

                                        container.appendChild(restaurantSquare);

                                    }
                                    document.getElementById("popularRestaurants").appendChild(container);
                                }
                                else {
                                    popup._ResetRestaurantFavorited();
                                }
                            });
                            clearHomeSelected();
                        });
                        acLink.parentElement.addEventListener('click', (e) => {
                            hideHomeCategoryLinks("WEEKLY AD CIRCULARS");
                            seeAllLink.style.display = 'inline-block';
                            popup._ShowWeeklyAds();
                            clearHomeSelected();
                            backToCatButton.style.display = 'inline-block';
                        });
                        backToCatButton.addEventListener('click', (e) => {
                            if (!popup._ResetRestaurantCategories()) {
                                if (!popup._ResetGroceryCategories(false)) {
                                    let currentSection = document.querySelector('div.categorySection[style*="display: block"]');
                                    if (currentSection) currentSection.style.display = 'none';
                                    backToCatButton.style.display = 'none';
                                    categoryHeading.style.display = "none";
                                    seeAllLink.style.display = 'none';
                                    seeAllLink2.style.display = 'none';
                                    catHome.style.display = 'block';
                                    if (!nocashback) tabsSelector.style.display = "inline-flex";
                                    contentArea.classList.remove("grocery");
                                    document.getElementById("myCategoriesLink").click();
                                    SetBackCategoryTitle();
                                }
                            }
                            else hideHomeCategoryLinks("POPULAR RESTAURANTS");
                        });
                        gcLink.parentElement.addEventListener('click', (e) => {
                            hideHomeCategoryLinks("PRINTABLE GROCERY COUPONS");
                            headerChange.classList = "grocery";
                            contentArea.classList.add("grocery");
                            clearHomeSelected();
                        });
                        ReadyGrocerySection();
                        ocLink.parentElement.addEventListener('click', (e) => {
                            catHome.style.display = 'none';
                            tabsSelector.style.display = "none";
                            DisplayOnlineCouponsSection();
                            clearHomeSelected();
                            SetCategoryTitle(true, "Top Online Coupons");
                        });
                    }
                });
            },
            _PlayFromBeginning: function () {
                popup._TabPanes._ResetEverything(false);
                var callback = function (currentIndex) {
                    popup._TabPanes._Play(currentIndex, callback);
                };
                _sendMessage({
                    action: "Preference Manager",
                    targetScript: "shoptoolbar.js",
                    data: { pref: "ConflictAlert" }
                }, function (cAlert) {
                    if (!cAlert) {
                        callback(0);
                    }
                });
            },
            _ResetEverything: function (isDeepReset) {
                let tabPanes = popup._TabPanes.tabs;
                let doms = document.querySelectorAll("div#homeContent ul.newNavigationTabClass_bf div.newNavigationTabOption_bf");
                for (let i = 0; i < doms.length; i++) {
                    let obj = tabPanes[i];
                    if (!obj) {
                        popup._TabPanes.tabs.push({
                            hasActiveShow: doms[i].classList.contains("active") || doms[i].classList.contains("show"),
                            hasClicked: (isDeepReset ? false : (obj.hasClicked || false)),
                            playCount: 0
                        });
                    }
                    else {
                        obj.hasActiveShow = doms[i].classList.contains("active") || doms[i].classList.contains("show");
                        obj.hasClicked = (isDeepReset ? false : (obj.hasClicked || false));
                        obj.playCount = 0;
                    }
                }
            },
            _ResetPlayCount: function () {
                let tabPanes = popup._TabPanes.tabs;
                for (let i = 0; i < tabPanes.length; i++) {
                    let obj = tabPanes[i];
                    obj.playCount = 0;
                }
            },
            _Play: function (tabPaneNumber, callback) {
                //"callback" is a sequential callback function. When Play animation has finished, it will be invoked.
                if (!callback)
                    callback = function () { };

                if (tabPaneNumber >= popup._TabPanes.tabs.length) {
                    if (popup._TabPanes._CurrentAnimationCount < popup._TabPanes._AnimationCount - 1) {
                        tabPaneNumber = tabPaneNumber % popup._TabPanes.tabs.length;
                        popup._TabPanes._CurrentAnimationCount++;
                        popup._TabPanes._ResetPlayCount();
                    }
                    else {
                        popup._TabPanes._CurrentAnimationCount = 0;
                        return;
                    }
                }

                var flipFlop = function (tabPane, dom) {
                    if (tabPane.playCount < popup._TabPanes._AnimationCount) {
                        dom.classList.add("vibrateText");
                        setTimeout(() => {
                            dom.classList.remove("vibrateText");
                            setTimeout(() => {
                                ++tabPane.playCount;
                                flipFlop(tabPane, dom);
                            }, 250);
                        }, 400);
                    }
                    else {
                        dom.classList.remove("vibrateText");
                        callback(tabPaneNumber + 1);
                    }
                };

                var tabPane = popup._TabPanes.tabs[tabPaneNumber];
                var dom = document.querySelector("[tabPaneNumber='" + tabPaneNumber + "']");
                if (!tabPane.hasClicked && !tabPane.hasActiveShow) {
                    setTimeout(() => {
                        flipFlop(tabPane, dom);
                    }, 1000);
                }
                else {
                    dom.classList.remove("vibrateText");
                    callback(tabPaneNumber + 1);
                }
            },
            _StopAllAnimations: function () {
                let tabPanes = popup._TabPanes.tabs;
                let doms = document.querySelectorAll("[tabPaneNumber]");
                for (let i = 0; i < tabPanes.length; i++) {
                    doms[i].classList.remove("vibrateText");
                    let obj = tabPanes[i];
                    obj.playCount = popup._TabPanes._AnimationCount;
                }
                popup._TabPanes._CurrentAnimationCount = popup._TabPanes._AnimationCount;
            }
        },
        _ShowWeeklyAds: function () {
            if (!popup._WeeklyAdsInit) {
                popup._WeeklyAdsInit = true;
                let adSection = document.getElementById('adCircularSection');
                _sendMessage({
                    action: "sptool",
                    targetScript: "shoptoolbar.js",
                    data: { function: "_GetWeeklyAds" }
                }, function (weeklyAds) {
                    for (let ad = 0; ad < weeklyAds.Ads.length; ad++) {
                        let _ad = weeklyAds.Ads[ad];
                        let adDiv = document.createElement("div");
                        let adImg = document.createElement("img");
                        let adTitle = document.createElement("div");
                        let adDescription = document.createElement("div");
                        let adTextContainer = document.createElement("div");
                        adDiv.className = "adCircularGrid globalBoxShadow";
                        adDiv.id = "adcircular" + _ad.RetailerID;
                        adImg.className = "column";
                        adTitle.className = "weeklyAdTitle";
                        adTextContainer.className = "column";
                        adImg.style = "width : 35%; padding-left : 10px; padding-top: 8px; padding-bottom: 6px;";
                        adTextContainer.style = "width : -webkit-fill-available; padding : 12px; text-align:left";

                        adImg.src = "https:" + _ad.ImgUrl;
                        adTitle.innerText = _ad.RetailerName;
                        adDescription.innerText = weeklyAds.StartDate + " - " + weeklyAds.EndDate;

                        adDiv.addEventListener('click', (e) => {
                            browserAdapter.UpdateTab(null, _ad.AdUrl + (noCookCheck() ? "&nocook=true" : ""));
                        });

                        adDiv.appendChild(adImg);
                        adDiv.appendChild(adTextContainer);
                        adTextContainer.appendChild(adTitle);
                        adTextContainer.appendChild(adDescription);
                        adSection.appendChild(adDiv);
                    }
                    adSection.style.display = 'block';

                    if (isTour) {
                        tourInfo.TourRetailer.step = 3;
                        _sendMessage({
                            action: "Preference Manager",
                            targetScript: "shoptoolbar.js",
                            data: { pref: "TourInfo", value: tourInfo }
                        }, function () {
                            _sendMessage({
                                request: "ClickedRestaurants",
                                targetScript: "instructionsInject.js"
                            }, function () {
                                let trDiv = document.querySelector('div#adcircular' + tourInfo.TourRetailer.retailerId);
                                trDiv.scrollIntoView({ block: "center" });
                                trDiv.classList.add('tourHighlight');
                            });
                        });
                    }
                });
            }
            else {
                document.getElementById('adCircularSection').style.display = 'block';
            }
        },
        _ResetRestaurantCategories: function () {
            let isRBL = document.querySelectorAll('#restaurantsSection[style*="display: block"] #restaurantsBrowse[style*="display: none"]');
            if (isRBL.length > 0) {
                popup._ResetRestaurantFavorited();
                document.querySelector('#restaurantsByLetter').style.display = 'none';
                document.querySelector('#restaurantsBrowse').style.display = 'block';
                SetBackCategoryTitle();
                return true;
            }
            else return false;
        },
        _ResetGroceryCategories: function (resetAll) {
            /*  Flow goes
                Grocery Home -> Categories -> Coupons Listed in that Category -> Single Coupon
                Grocery Home -> Brands -> Coupons Listed in that Brand -> Single Coupon */

            /* Both Flows */
            //If Single Grocery Coupon go back to Coupon List
            let isGCSingle = document.querySelectorAll('#groceryCouponsSection[style*="display: block"] #gcsSingleCoupon[style*="display: block"]');
            if (isGCSingle.length > 0) {
                CustomBackButtonFunction(['#gcsSingleCoupon'], '#gcsCoupon');
                if (!resetAll) return true;
            }

            /* Category Brand Flow */
            //Else if Category Coupon List go to Groceries Home
            let isGCCat = document.querySelectorAll('#groceryCouponsSection[style*="display: block"] #gcsCoupon[gtype="category"][style*="display: block"]');
            if (isGCCat.length > 0) {
                CustomBackButtonFunction(['#gcsCoupon'], '#gcsCategories');
                if (!resetAll) return true;
            }

            /* Grocery Brand Flow */
            //Else if Brand Coupon List go to Groceries Home
            let isGBrand = document.querySelectorAll('#groceryCouponsSection[style*="display: block"] #gcsCoupon[gtype="brand"][style*="display: block"]');
            if (isGBrand.length > 0) {
                CustomBackButtonFunction(['#gcsCoupon'], '#gcsBrands');
                if (!resetAll) return true;
            }

            /*Not in a flow */
            //Else if Groceries Home, go to Categories Home
            let isGCL = document.querySelectorAll('#groceryCouponsSection[style*="display: block"] #gcsHome[style*="display: none"]');
            if (isGCL.length > 0) {
                document.querySelector('#gcsHome').style.display = 'block';
                document.querySelector('#gcsCategories').style.display = 'none';
                document.querySelector('#gcsBrands').style.display = 'none';
                document.querySelector('#gcsCoupon').style.display = 'none';
                document.querySelector('#gcsSingleCoupon').style.display = 'none';
                SetBackCategoryTitle();
                if (!resetAll) return true;
            }
            return false;
        },
        _ResetRestaurantFavorited: function () {
            let allRestaurants = document.querySelectorAll("span[isfavoritestore]");
            for (let i = 0; i < allRestaurants.length; i++) {
                let currRestaurant = allRestaurants[i];
                let favoritesCheck = popup._FavoritesList.filter(x => x && x.retailerID === parseInt(currRestaurant.getAttribute("retailerid"))).length > 0;
                if (favoritesCheck) {
                    currRestaurant.setAttribute("isfavoritestore", "true");
                    currRestaurant.style.color = "rgb(237, 28, 36)";
                }
                else {
                    currRestaurant.setAttribute("isfavoritestore", "false");
                    currRestaurant.style.color = "rgb(208, 208, 208)";
                }
            }
        },
        _ChangeNextBanner: function(button, bannerImagePrevious, bannerImageNow, bannerImageNext) {
            popup.bannerIndex = ++popup.bannerIndex % popup.banners.length;
            button.setAttribute("stop", "true");
            bannerImageNext.src = popup.banners[popup.bannerIndex].ImgUrl;
            bannerImageNext.classList.add("slideLeft");
            bannerImageNow.classList.add("slideLeft");
            bannerImagePrevious.classList.add("slideLeft");
            setTimeout(() => {
                button.removeAttribute("stop");
                bannerImagePrevious.src = bannerImageNow.src;
                bannerImageNow.src = bannerImageNext.src;
                bannerImageNext.classList.remove("slideLeft");
                bannerImageNow.classList.remove("slideLeft");
                bannerImagePrevious.classList.remove("slideLeft");
            }, 1000);
        },
        _ChangePreviousBanner: function(button, bannerImagePrevious, bannerImageNow, bannerImageNext) {
            popup.bannerIndex = (popup.bannerIndex + (popup.banners.length - 1)) % popup.banners.length;
            button.setAttribute("stop", "true");
            bannerImagePrevious.src = popup.banners[popup.bannerIndex].ImgUrl;
            bannerImageNext.classList.add("slideRight");
            bannerImageNow.classList.add("slideRight");
            bannerImagePrevious.classList.add("slideRight");
            setTimeout(() => {
                button.removeAttribute("stop");
                bannerImageNext.src = bannerImageNow.src;
                bannerImageNow.src = bannerImagePrevious.src;
                bannerImageNext.classList.remove("slideRight");
                bannerImageNow.classList.remove("slideRight");
                bannerImagePrevious.classList.remove("slideRight");
            }, 1000);
        },
        _CreateStore: function(item, isFavoriteStore, flow) {
            let rate = item.CashbackRate;
            let hasUpTo = false;
            if (typeof rate === "string" && rate.length > 0) {
                rate = rate.slice(0, " Cash Back".length * -1);
                hasUpTo = /up\ to/i.test(rate);
            }

            //We add in the max count of stores per section in total, for now.
            let div = document.createElement("div");
            div.classList.add("storeGrid");
            div.classList.add("globalBoxShadow");
            div.classList.add("fade");
            div.classList.add("in");
            div.classList.add("show");
            div.classList.add("restaurantGrid");
            div.id = (flow ? flow : "") + item.RetailerID.toString();

            //Check if the cashback rate is null or not, and apply CSS and text accordingly.
            let cashbackTextDisplaySpan = document.createElement("span");
            let cashbackRateTextContainer = document.createElement("div");;
            let offerCount = item.CouponCount;
            if (rate != null) {
                if (hasUpTo) {
                    let rateText = rate.slice("up to".length).trim();
                    cashbackTextDisplaySpan.classList = "storeGridCashbackText";
                    let spnInner = document.createElement("span");
                    spnInner.style = "color: #199402;font-weight: 400; font-size: 11px;";
                    spnInner.innerText = "up to ";
                    let spnInnerTwo = document.createTextNode(rateText);
                    let spnInnerThree = document.createElement("span");
                    spnInnerThree.style = "color: #199402;font-weight: 400; font-size: 11px;";
                    spnInnerThree.innerText = " Back";

                    cashbackTextDisplaySpan.appendChild(spnInner);
                    cashbackTextDisplaySpan.appendChild(spnInnerTwo);
                    cashbackTextDisplaySpan.appendChild(spnInnerThree);
                }
                else {
                    cashbackTextDisplaySpan.style = "color: #199402;";
                    cashbackTextDisplaySpan.classList = "storeGridCashbackText";
                    let spnInner = document.createTextNode(rate);
                    let spnInnerTwo = document.createElement("span");
                    spnInnerTwo.style = "color: #199402;font-weight: 400; font-size: 11px;";
                    spnInnerTwo.innerText = " Back";

                    cashbackTextDisplaySpan.appendChild(spnInner);
                    cashbackTextDisplaySpan.appendChild(spnInnerTwo);
                }
                cashbackRateTextContainer.style = "background-color: #f5fbe8; height: 31%; width: 100%; display: table; border-bottom-left-radius: 10px; border-bottom-right-radius: 10px;";
                cashbackRateTextContainer.appendChild(cashbackTextDisplaySpan);
            }
            else if (offerCount) {
                cashbackTextDisplaySpan.classList = "storeGridOfferText";
                let spnInnerOne = document.createElement("span");
                spnInnerOne.innerText = offerCount;
                spnInnerOne.style.fontSize='17px'
                let spnInnerTwo = document.createElement("span");
                spnInnerTwo.style = "font-weight:400; font-size: 11px;";
                spnInnerTwo.innerText = " Offers";
                cashbackTextDisplaySpan.appendChild(spnInnerOne);
                cashbackTextDisplaySpan.appendChild(spnInnerTwo);
                cashbackRateTextContainer.style = "background-color: #FEF4F2; height: 31%; width: 100%; display: table; border-bottom-left-radius: 10px; border-bottom-right-radius: 10px;";
                cashbackRateTextContainer.appendChild(cashbackTextDisplaySpan);
            }
            else {
                cashbackTextDisplaySpan.classList = "storeGridNoCashbackText";
                cashbackTextDisplaySpan.innerText = "No Offers at this time";
                cashbackRateTextContainer.style = "background-color: #f0f0f0; height: 31%; width: 100%; display: table; border-bottom-left-radius: 10px; border-bottom-right-radius: 10px;";
                cashbackRateTextContainer.appendChild(cashbackTextDisplaySpan);
            }
            //Set up the store grid HTML and CSS styles.
            let spanHeartInner = document.createElement("span");
            spanHeartInner.classList = "icon-heart";
            let favoriteHeartInner = document.createElement("span");
            favoriteHeartInner.id = "favoriteHeart" + item.RetailerID.toString();
            favoriteHeartInner.style = "position: absolute; right: 2px; top: 2px; padding: 3px 4px 0px 4px; color:" + (isFavoriteStore ? "#ed1c24;" : "#d0d0d0;") + (noUser ? "visibility:hidden;" : "");
            favoriteHeartInner.appendChild(spanHeartInner);

            let dvFavoritemOuter = document.createElement("div");
            dvFavoritemOuter.style = "width: 100%; height: 100%;";

            let dvFavoritemInner = document.createElement("div");
            dvFavoritemInner.style = "position: relative;";

            dvFavoritemInner.appendChild(favoriteHeartInner);

            let dvitemInner = document.createElement("div");
            dvitemInner.style = "height: 70%; padding: 5px; width: 100%; display: table;";
            let dvitemInnerTwo = document.createElement("div");
            dvitemInnerTwo.style = "display: table-cell; width: 100%; vertical-align: middle; margin: 0 auto; text-align: center;";
            let imgStore = document.createElement("img");
            imgStore.setAttribute("storeid", item.RetailerID.toString());
            imgStore.src = ("https:" + item.ImgUrl);
            imgStore.style = "width: 80%; margin: 0 auto; text-align: center; margin-top:5px;";
            dvitemInnerTwo.appendChild(imgStore);

            dvitemInner.appendChild(dvitemInnerTwo);

            //add hearts, cv does not have favoriting
            if (!nocashback) {
                dvFavoritemOuter.appendChild(dvFavoritemInner);
            }
            dvFavoritemOuter.appendChild(dvitemInner);
            dvFavoritemOuter.appendChild(cashbackRateTextContainer);

            div.appendChild(dvFavoritemOuter);

            if (!nocashback) {
                //Adding attributes to Favorite Hearts, for the listener below.
                //Adding Favorite Hearts listener
                var favoriteHeartHandler = function (event) {
                    event.stopPropagation();
                    let span = event.target;

                    //If the click event's target is on the favorite heart icon, we would need the parent node of this heart icon.
                    if (span.classList.contains("icon-heart")) {
                        span = span.parentNode;
                    }

                    let flag = span.getAttribute("isFavoriteStore") === "true";
                    let retailerId = span.getAttribute("retailerId");
                    let favoritesContainer = document.getElementById("favoriteStores");
                    let recommendedContainer = document.getElementById("recommendedStores");
                    let mainElement = document.querySelector("div[id='" + retailerId.toString() + "']");

                    //Had to code it like to resolve some UX issues.
                    if (flag) {
                        span.style.color = flag ? "#d0d0d0" : "#ed1c24";
                        popup._RemoveFavoriteStore(retailerId, mainElement, flow);
                        span.setAttribute("isFavoriteStore", !flag);
                    }
                    else {
                        if (favoritesContainer.childElementCount < MaxStoresTotal) {
                            FavoriteIt(retailerId, span, function (success) {
                                if (success) {
                                    span.style.color = flag ? "#d0d0d0" : "#ed1c24";
                                    span.setAttribute("isFavoriteStore", !flag);
                                }
                            });
                        }
                        else {
                            popup._ShowToast("You may add up to 15 Favorite stores. Please remove some stores to add new.");
                        }
                    }
                };
                let spanHeart = div.querySelector("span#favoriteHeart" + item.RetailerID.toString());
                spanHeart.setAttribute("isFavoriteStore", isFavoriteStore);
                spanHeart.setAttribute("retailerId", item.RetailerID);
                spanHeart.addEventListener("click", favoriteHeartHandler);
            }

            let storeImage = div.querySelector("img[storeid]");
            let cashbackArea = div.querySelector(".storeGridCashbackText") || div.querySelector(".storeGridNoCashbackText") || div.querySelector(".storeGridOfferText");
            let goToRetailer = function (e) {
                e.preventDefault();

                //close join/login tooltip if present
                let closeButton = document.querySelector("#tooltipClose");
                if (closeButton) {
                    closeButton.click();
                }

                let activateRedirect = function () {
                    _sendMessage({
                        action: "GetSearchRetailerRedirectURL",
                        targetScript: "shoptoolbar.js",
                        data: { internalId: item.RetailerID, internalName: item.InternalName }
                    }, function (results) {
                        let redirectUrl = results[0];
                        let exists = results[1];
                        if (exists) {
                            _sendMessage({
                                action: "AddMetricData",
                                targetScript: "shoptoolbar.js",
                                data: { Metric: "PopupClickout", Value: item.RetailerID }
                            });
                            _openLink(redirectUrl);
                            //Edge will receive a "Permission denied" error message in background script if popup is closed too fast.
                            //Verified Chrome and Firefox are unaffected. 
                            _closeBrowserActionPopups();
                        } else {
                            _preRedirectMessaging(redirectUrl, item);
                        }
                    });
                };
                GetAnonymity(function (notallowed) {
                    if (notallowed && !recentDeclined) {
                        privacyDialog(true, function (accepted) {
                            //if (accepted || recentDeclined)
                            activateRedirect();
                        });
                    }
                    else {
                        activateRedirect();
                    }
                });
                return false;
            };

            if (!flow || flow !== "Restaurant") {
                storeImage.addEventListener("click", goToRetailer);
                cashbackArea.addEventListener("click", goToRetailer);
            }

            return div;
        },

        _MoveStore: function (container, item, isFavoriteStore) {
            var storeItem = popup._CreateStore(item, isFavoriteStore);
            container.appendChild(storeItem);
        },


        /**
         * Shows the corresponding tab content based on the given enumeration value, and disables the rest.
         * 
         * The tab content to display is determined by popup._CurrentPopupContent.
         */
        _EnableContent: function () {
            let disableContent = document.querySelector('div[id*="Content"].tab-pane.show');
            if (disableContent) {
                disableContent.classList.remove("active");
                disableContent.classList.remove("show");
            }
            if (popup._CurrentPopupContent === _PopupContentEnum.Retailer) {
                let disableTab = document.querySelector('div[class*="SectionTabOption"].show');
                if (disableTab) {
                    disableTab.classList.remove("active");
                    disableTab.classList.remove("show");
                }
            }
            let content = document.querySelector('div[id="' + popup._CurrentPopupContent + '"].tab-pane:not(.show)');
            content.classList.add("active");
            content.classList.add("show");
            //close popup if opened
            let retailerCBTerms = document.querySelector("#retailerCBTerms.cbTerms_show");
            if (retailerCBTerms) {
                retailerCBTerms.classList.add("cbTerms_hide");
                retailerCBTerms.classList.remove("cbTerms_show");
            }
            //disable deals if shown
            if (document.querySelector('#dealsOrOffersDiv'))
                document.querySelector('#dealsOrOffersDiv').style.display = 'none';

            let ocWrapper = document.querySelector('#retailerDealsContainer');
            if (ocWrapper) {
                ocWrapper.classList.remove("active");
                ocWrapper.classList.remove("show");
            }
            //display offers on start
            ocWrapper = document.querySelector("#retailerOffersContainer");
            if (ocWrapper) {
                ocWrapper.classList.add("active");
                ocWrapper.classList.add("show");
            }

            // Timer for flash BCB
            let initBonusCashbackTimer = function () {

                // return EST/EDT time for the given date in the form of a number
                let getEasternTime = function (date) {
                    let dateString = date.getTime().toLocaleString("en-US", { timeZone: "America/New_York" });
                    while (dateString.indexOf(",") > 0) {
                        dateString = dateString.replace(",", "");
                    }
                    return parseInt(dateString);
                }

                // only works for non-negative integers
                let formatTime = function (timeUnit) {
                    return ("0" + timeUnit).slice(-2);
                }

                let countDownDate = new Date();
                countDownDate.setHours(24, 0, 0, 0); // Midnight tonight
                countDownDate = getEasternTime(countDownDate);



                let setTimerText = function () {
                    // Get today's date and time
                    let now = new Date();
                    now = getEasternTime(now);

                    // Find the distance between now and the count down date
                    let distance = countDownDate - now;
                    // Time calculations for days, hours, minutes and seconds
                    let hours = formatTime(Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60)));
                    let minutes = formatTime(Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60)));
                    let seconds = formatTime(Math.floor((distance % (1000 * 60)) / 1000));

                    // If the count down is finished, show expired
                    if (distance < 0) {
                        clearInterval(countdownInterval);
                        document.getElementById("flashCountdownTimer").innerText = "EXPIRED";
                    } else {
                        document.getElementById("flashCountdownTimer").innerText = `Ends In: ${hours}:${minutes}:${seconds}`;
                    }
                }

                // Update the count down every 1 second
                setTimerText();
                let countdownInterval = setInterval(setTimerText, 1000);
            }

            if (!isTour) {
                // CONSIDER: moving all this code to a separate function
                // Get flash cashback info
                let featureBCBUrl = Format("{0}/wssimplenonshopper.asmx/GetFeaturedBonusCashBackInfo", CDNSite);
                let params = Format('?isShopper={0}', isShopper);
                _sendMessage({
                    action: "FetchJson",
                    targetScript: "shoptoolbar.js",
                    data: {
                        url: featureBCBUrl + params,
                    }
                }, function (json) {
                    // set cb activation
                    _sendMessage({
                        action: "Preference Manager",
                        targetScript: "shoptoolbar.js",
                        data: { prefs: ["Guest"] }
                    }, function ([isGuest]) {
                        if (shoptoolbar._Browser !== Browsers.iOS) {
                            popup._ShowPromotions();

                            if (json.IsCashbackEventRunning && json.BannerUrl) {
                                document.getElementById("bcbBannerImage").src = json.BannerUrl.replace(/^(https?:)?\/\//i, "https://");
                                document.getElementById("bcbBannerImage").addEventListener("click", function () {
                                    chrome.tabs.create({ url: "https://www.befrugal.com/cashback/bonuscashback/" });
                                });
                            } else {
                                let bcbBannerWrapper = document.querySelector("#bcbBannerWrapper");
                                if (bcbBannerWrapper) bcbBannerWrapper.style.display = "none";
                            }

                            if (json.FeaturedRetailer) {
                                const bonusCashbackRetailer = json.FeaturedRetailer;
                                const featuredCBImage = bonusCashbackRetailer.ImgUrl.replace("//", "https://");

                                document.getElementById("bcbRetailerImage").src = featuredCBImage;
                                var flashbcb = bonusCashbackRetailer.CurrentCashbackRate;
                                if (flashbcb.toLowerCase().includes("up to"))
                                    flashbcb = flashbcb.replace("Cash", "");
                                document.getElementById("bonusCashbackRateText").innerText = flashbcb;
                                document.getElementById("oldCashbackRateText").innerText = "Was " + bonusCashbackRetailer.WasCashbackRate;

                                document.getElementById("FlashBonusCashback").addEventListener("click", function () {
                                    _sendMessage({
                                        action: "AddMetricData",
                                        targetScript: "shoptoolbar.js",
                                        data: { Metric: "PopupClickout", Value: bonusCashbackRetailer.RetailerID }
                                    });
                                    let cbUrl = isGuest ?
                                        "https://www.befrugal.com/store/" + bonusCashbackRetailer.InternalName + "/" :
                                        "https://www.befrugal.com/coupons/cashbacksignuppopup/nu/?rtr=" + bonusCashbackRetailer.RetailerID;
                                    chrome.tabs.create({ url: cbUrl });
                                });

                                initBonusCashbackTimer();
                            } else {
                                document.getElementById("FlashBonusCashback").style.display = "none";
                            }
                        }
                    });
                });
            }

        },

        _ShowPromotions: function () {
            var container = document.getElementById('FlashBonusCashback');
            container.style.display = "grid";
        },

        _SetFavoriteStores: function (favorites, recommendedFavorites) {
            var favoritesSection = document.getElementById("favoriteStoresSection");
            var recommendedSection = document.getElementById("recommendedStoresSection");
            var favoritesContainer = favoritesSection.querySelector("#favoriteStores");
            var recommendedContainer = recommendedSection.querySelector("#recommendedStores");

            //We clear the favorites in Shoptoolbar so we can refresh it upon load.
            popup._FavoritesList = [];

            if (favorites && favorites.length > 0) {
                favoritesSection.style.display = "block";
                favoritesContainer.style.display = "grid";

                //Empty out the favorites section
                while (favoritesContainer.firstChild)
                    favoritesContainer.removeChild(favoritesContainer.firstChild);

                for (let i = 0; i < favorites.length; i++) {
                    popup._MoveStore(favoritesContainer, favorites[i], true);

                    //We store the favorites in Shoptoolbar
                    popup._FavoritesList.push({
                        retailerID: parseInt(favorites[i].RetailerID),
                        internalName: favorites[i].InternalName,
                        cashbackRate: favorites[i].CashbackRate
                    });
                }
            }
            else {
                favoritesSection.style.display = "none";
            }

            if (recommendedFavorites && recommendedFavorites.length > 0) {
                recommendedSection.style.display = "block";

                //This will always get (number of MaxStoresTotal) recommended favorite stores. Refreshing the popup will repopulate up to (MaxStoresTotal) stores.
                recommendedContainer.style.display = "grid";

                //Empty out the recommended container
                while (recommendedContainer.firstChild)
                    recommendedContainer.removeChild(recommendedContainer.firstChild);

                for (let i = 0; i < recommendedFavorites.length; i++) {
                    popup._MoveStore(recommendedContainer, recommendedFavorites[i], false);
                }
            }
            else {
                recommendedSection.style.display = "none";
            }
        },

        /**
		 * Fetches the favorite stores for the user, and fills in both Favorite Stores and Recommended Stores.
		 * 
		 * NOTE: Recommended Stores is actually Recommended Favorites. Favorite Stores and Recommended Stores all must be handled in this function.
		 *
		 * @param {HTMLElement} favoritesSection - The HTML element section that holds the Favorite Stores section (including the container).
		 * @param {HTMLElement} recommendedSection - The HTML element section that holds the Recommended Stores section (including the container).
		 * @param {function} callback - Calls once everything is initialized.
		 */
        _GetFavoriteStores: function (callback) {
            if (!callback)
                callback = function () { };
            _FetchJsonPost(Format("{0}/wssimple.asmx/GetFavoriteRetailers", APISite), function (json) {
                if (!json) {
                    //Server down, redirect to website
                    _openLink("https://" + bfSite);
                    return;
                }
                popup._SetFavoriteStores(json.Favorites, json.RecommendedFavorites);
                callback(json);
            });
        },
        /**
		 * Adds a favorited store to the Favorites section.
		 * @param {string} retailerId - Retailer ID. Can also be a number.
		 * @param {HTMLElement} elem - The element instance that is being added to the Favorites section.
		 */
        _AddFavoriteStore: function (retailerId, elem, flow) {
            var url = Format("{0}/wssimple.asmx/AddFavoriteRetailer", APISite);
            _FetchJsonPostCustom(Format("{0}/wssimple.asmx/AddFavoriteRetailer", APISite), Format("retailerID={0}&UserToken={1}&toolbarversion={2}", retailerId, encodeURIComponent(userToken), toolbarVersion), function (json) {
                let favoritesContainer = document.querySelector("#favoriteStores");
                if (json) {
                    if (json.Success && favoritesContainer.childElementCount < MaxStoresTotal) {

                        //add to popup cache
                        popup._FavoritesList.push({
                            retailerID: parseInt(retailerId)
                        });

                        let storeDetails = json.AddedStoreDetails;
                        let isRestaurant = flow && flow === "Restaurant";

                        if (!elem)
                            elem = document.querySelector("#myStores div[id*='" + storeDetails.RetailerID + "']");

                        if (elem && !isRestaurant) {
                            elem.classList.remove("show");
                        }
                        else {
                            let preexisting = document.querySelector("#myStores div[id*='" + storeDetails.RetailerID + "']");
                            if (preexisting) {
                                preexisting.classList.remove("show");
                                elem = preexisting;
                            }
                            else
                                elem = popup._CreateStore(json.AddedStoreDetails, true);
                        }

                        setTimeout(() => {
                            if (elem.parentNode)
                                elem.parentNode.removeChild(elem);

                            //Preserve scroll top position
                            let parentContainer = document.querySelector("#myStores");
                            popup.scrollTopValue = parentContainer.scrollTop;

                            favoritesContainer.appendChild(elem);

                            let favoritesSection = document.querySelector("#favoriteStoresSection");

                            //Show the Favorites section if it was empty before appending child, and trigger the action to display the section.
                            //This is the only time we guarantee child count is 1.
                            if (favoritesContainer.childElementCount === 1) {
                                favoritesSection.style.display = "block";
                            }

                            elem.classList.add("show");

                            let span = elem.querySelector("span[id*='" + retailerId + "']");
                            span.style.color = "#ed1c24";
                            span.setAttribute("isFavoriteStore", true);

                            /*
							//Old method of fetching preserved scroll top position
								
							//If the Favorites section was previously hidden, we also need to take account the additional section height that appeared magically.
							if (favoritesContainer.childElementCount === 1) {
								//Compute the entire section's visible height, and add to the scrolltop position.
								popup.scrollTopValue += parseInt(window.getComputedStyle(favoritesSection).height.slice(0, -2));
							}
							else if (favoritesContainer.childElementCount % 3 === 1) {
								//Since scrolltop value is of type "number", we need to convert them into integers for pixel count.
								let computedHeight = parseInt(window.getComputedStyle(elem).height.slice(0, -2));

								//The padding gap between grids is 10px, so we need to take that into account when adding scrolltop position. Any CSS changes will have
								//to adjust this number.
								popup.scrollTopValue += computedHeight + 10;
							}
							parentContainer.scrollTop = popup.scrollTopValue;
							*/

                            //Forces custom scrollbar to jump to the Favorite Stores section after a new favorited store has been added, taking into account the placement banner's height if it's displayed.
                            let placementBannerContainer = document.querySelector("#placementBanner");
                            let placementBannerClientRect = placementBannerContainer.getBoundingClientRect();
                            let favoritesContainerClientRect = favoritesContainer.getBoundingClientRect();
                            let newTop = ((placementBannerContainer.style.display !== "none" ? placementBannerClientRect.top : 0) + favoritesContainerClientRect.top) + "px";
                            document.querySelector("div#myStores div.ss-content").scrollTo({ top: newTop });

                            if (favoritesContainer.childElementCount > 0) {
                                favoritesSection.style.display = "block";
                            }
                            else {
                                favoritesSection.style.display = "none";
                            }

                            setTimeout(() => {
                                let parent = document.querySelector("#recommendedStores");
                                if (parent.children.length <= 0) {
                                    popup._RepopulateRecommendedStores(parent);
                                }
                            }, 400);
                        }, 400);
                    }
                    else {
                        if (elem)
                            elem.removeAttribute("isFavoriteStore");
                        if (json.message != null)
                            popup._ShowToast(json.message);
                        else
                            popup._ShowToast("You may add up to 15 Favorite stores. Please remove some stores to add new.");
                    }
                }
                else {
                    popup._ShowToast("You may add up to 15 Favorite stores. Please remove some stores to add new.");
                }
            });
        },
        /**
		 * Removes 1 instance of the store matching the given retailer object from the list of favorite stores.
		 * @param {string} retailerId - Retailer ID of the store.
		 * @param {HTMLElement} elem - The HTML element of the removed store.
		 */
        _RemoveFavoriteStore: function (retailerId, elem, flow) {
            _FetchJsonPostCustom(Format("{0}/wssimple.asmx/RemoveFavoriteRetailer", APISite), Format("retailerID={0}&UserToken={1}&toolbarversion={2}", retailerId, encodeURIComponent(userToken), toolbarVersion), function (json) {
                if (json) {
                    let isRestaurant = flow && flow === "Restaurant";

                    //Preserve scroll top position
                    let parentContainer = document.querySelector("#myStores");
                    popup.scrollTopValue = parentContainer.scrollTop;

                    let favoritesContainer = document.querySelector("#favoriteStores");

                    if (json.Success) {
                        popup._FavoritesList = popup._FavoritesList.filter(x => x.retailerID !== parseInt(retailerId));
                    }

                    if (json.Success && favoritesContainer.childElementCount > 0) {
                        if (!elem || isRestaurant)
                            elem = document.querySelector("#myStores div[id*='" + retailerId + "']");

                        if (!elem) return;

                        elem.classList.remove("show");

                        setTimeout(() => {
                            if (favoritesContainer.contains(elem))
                                favoritesContainer.removeChild(elem);
                            else {
                                elem = document.querySelector("#favoriteStores div[id*='" + retailerId + "']");
                                if (favoritesContainer.contains(elem)) {
                                    favoritesContainer.removeChild(elem);
                                }
                            }

                            //Hide the favorites section if no favorite stores are available
                            if (favoritesContainer.childElementCount <= 0) {
                                document.querySelector("#favoriteStoresSection").style.display = "none";
                            }

                            //Fetching preserved scroll top position
                            parentContainer.scrollTop = popup.scrollTopValue;

                            var recycleHandler = function () {
                                let node = recommendedContainer.firstChild;
                                while (node.nextSibling)
                                    node = node.nextSibling;
                                recommendedContainer.insertBefore(elem, recommendedContainer.firstChild);
                                elem.classList.add("show");

                                let span = elem.querySelector("span[id*='" + retailerId + "']");
                                span.style.color = "#d0d0d0";
                                span.setAttribute("isFavoriteStore", false);
                            };

                            let recommendedContainer = document.querySelector("#recommendedStores");
                            if (recommendedContainer.childElementCount < MaxStoresTotal) {
                                recycleHandler();
                            }
                            else {
                                recommendedContainer.removeChild(recommendedContainer.lastChild);
                                recycleHandler();
                            }
                        }, 400);
                    }
                }
            });
        },
        _InitializeBanners: function (bannerContainer) {
            popup.banners = [];
            popup.bannerIndex = 0;
            _sendMessage({
                action: "sptool",
                targetScript: "shoptoolbar.js",
                data: { function: "FetchBanners" }
            }, function (jsonArray) {
                //NOTE(Thompson): The response value is an array of JSON objects.
                var placementBanner = document.querySelector("#placementBanner");

                if (!jsonArray || !Array.isArray(jsonArray) || (Array.isArray(jsonArray) && jsonArray.length === 0)) {
                    //We need to disable popup banners from being displayed because either the server went down, no banner title is detected,
                    //or unexpected events happened, or we really don't have banners available.
                    placementBanner.style.display = "none";
                    return;
                }

                var bannerImage0 = bannerContainer.querySelector("img#imagePrev");
                var bannerImage1 = bannerContainer.querySelector("img#imageNow");
                var bannerImage2 = bannerContainer.querySelector("img#imageNext");
                var bannerButtons = bannerContainer.querySelector("#bannerButtons");
                var bannerNextButton = bannerContainer.querySelector("img#nextBanner");
                var bannerPrevButton = bannerContainer.querySelector("img#previousBanner");
                var bannerTitle = placementBanner.querySelector("#bannerTitle");
                var bannerHeader = placementBanner.querySelector(".sectionHeader");

                var makeValidUrl = function (banner) {
                    if (banner.ImgUrl.indexOf("https://") === -1)
                        banner.ImgUrl = "https:" + banner.ImgUrl;
                    return banner;
                };

                var adjustBannerLines = function (title) {
                    const AverageCharacterPixelWidth = 8;
                    const bannerLinesArray = bannerContainer.querySelectorAll(".bannerLine");
                    const bannerWidth = parseInt((window.getComputedStyle(bannerContainer).width).slice(0, -"px".length));
                    let titleWidth = (title.length * AverageCharacterPixelWidth);
                    if (titleWidth >= bannerWidth)
                        titleWidth = 0;
                    else {
                        titleWidth = (((bannerWidth - titleWidth) / 2) - 10.0);
                        if (titleWidth < 0)
                            titleWidth = 0;
                    }
                    for (let i = 0; i < bannerLinesArray.length; i++) {
                        let line = bannerLinesArray[i];
                        line.style.width = titleWidth.toString() + "px";
                        line.style.minWidth = 0;
                    }
                };

                //Set the banner image urls.
                for (let i = 0; i < jsonArray.length; i++) {
                    popup.banners.push(makeValidUrl(jsonArray[i]));
                }

                //Setup the event listeners
                if (popup.banners.length > 1 && ENABLE_BANNER_SCROLL) {
                    bannerNextButton.addEventListener("click", (e) => {
                        if (popup.bannerTimeoutHandle)
                            clearTimeout(popup.bannerTimeoutHandle);
                        if (bannerNextButton.getAttribute("stop") === null) {
                            popup._ChangeNextBanner(bannerNextButton, bannerImage0, bannerImage1, bannerImage2);
                            if (ENABLE_BANNER_TITLE) {
                                bannerHeader.style.display = "block";
                                bannerTitle.innerText = popup.banners[popup.bannerIndex].BannerTitle || "";
                                adjustBannerLines(bannerTitle.innerText);
                            }
                            else
                                bannerHeader.style.display = "none";
                        }
                        popup.bannerTimeoutHandle = setTimeout(() => {
                            bannerNextButton.click();
                        }, popup.bannerTimeoutDuration);
                    });
                    bannerPrevButton.addEventListener("click", (e) => {
                        if (popup.bannerTimeoutHandle)
                            clearTimeout(popup.bannerTimeoutHandle);
                        if (bannerPrevButton.getAttribute("stop") === null) {
                            popup._ChangePreviousBanner(bannerPrevButton, bannerImage0, bannerImage1, bannerImage2);
                            if (ENABLE_BANNER_TITLE) {
                                bannerHeader.style.display = "block";
                                bannerTitle.innerText = popup.banners[popup.bannerIndex].BannerTitle || "";
                                adjustBannerLines(bannerTitle.innerText);
                            }
                            else
                                bannerHeader.style.display = "none";
                        }
                        popup.bannerTimeoutHandle = setTimeout(() => {
                            bannerNextButton.click();
                        }, popup.bannerTimeoutDuration);
                    });
                }
                else {
                    bannerButtons.style.display = "none";
                }

                bannerContainer.addEventListener("click", (e) => {
                    if (e.button === MOUSE_BUTTON_MAIN) {
                        let nextButton = bannerContainer.querySelector("img#nextBanner");
                        let prevButton = bannerContainer.querySelector("img#previousBanner");
                        if (Boolean(nextButton.getAttribute("stop")) || Boolean(prevButton.getAttribute("stop"))) {
                            return true;
                        }
                        e.preventDefault();
                        let link = popup.banners[popup.bannerIndex].Href;
                        if (link.indexOf("//") > -1 && link.indexOf("https") === -1) {
                            link = "https:" + link;
                        }
                        else if (link.indexOf("https") === -1) {
                            link = "https://" + Site + link;
                        }
                        _openLink(link);
                        return false;
                    }
                    else {
                        return true;
                    }
                });

                //Fixes the banners ordering based on how many banners are put in (0 ~ 3 banners). Don't change the indices.
                switch (popup.banners.length) {
                    case 0:
                        break;
                    case 1:
                        bannerImage0.src = popup.banners[0].ImgUrl;
                        bannerImage1.src = popup.banners[0].ImgUrl;
                        bannerImage2.src = popup.banners[0].ImgUrl;
                        break;
                    case 2:
                        bannerImage0.src = popup.banners[1].ImgUrl;
                        bannerImage1.src = popup.banners[0].ImgUrl;
                        bannerImage2.src = popup.banners[1].ImgUrl;
                        break;
                    case 3:
                    default:
                        bannerImage0.src = popup.banners[1].ImgUrl;
                        bannerImage1.src = popup.banners[0].ImgUrl;
                        bannerImage2.src = popup.banners[2].ImgUrl;
                        break;
                }

                //Do this to initialize the banners properly.
                if (popup.banners.length > 0) {
                    bannerContainer.style.display = "block";
                    popup.bannerIndex = 0;

                    if (ENABLE_BANNER_TITLE) {
                        bannerHeader.style.display = "block";
                        bannerTitle.innerText = popup.banners[popup.bannerIndex].BannerTitle || "";
                        adjustBannerLines(bannerTitle.innerText);
                    }
                    else
                        bannerHeader.style.display = "none";

                    if (jsonArray.length > 1 && ENABLE_BANNER_SCROLL) {
                        popup.bannerTimeoutHandle = setTimeout(() => {
                            let bannerNextButton = bannerContainer.querySelector("img#nextBanner");
                            bannerNextButton.click();
                        }, popup.bannerTimeoutDuration);
                    }
                }
                else {
                    //In case there are no banners.
                    bannerContainer.style.display = "none";
                    popup.bannerIndex = 0;
                }
            });
        },
        _RepopulateRecommendedStores: function (container) {
            _FetchJsonPost(Format("{0}/wssimple.asmx/GetFavoriteRetailers", APISite), function (json) {
                if (json) {
                    var recommendedSection = document.querySelector("#recommendedStoresSection");
                    if (json.RecommendedFavorites && json.RecommendedFavorites.length > 0) {
                        recommendedSection.style.display = "block";

                        //This will always get (number of MaxStoresTotal) recommended favorite stores. Refreshing the popup will repopulate up to (MaxStoresTotal) stores.
                        container.style.display = "grid";

                        //Empty out the recommended container
                        while (container.firstChild)
                            container.removeChild(container.firstChild);

                        for (let i = container.children.length; i < json.RecommendedFavorites.length; i++) {
                            popup._MoveStore(container, json.RecommendedFavorites[i], false);
                        }
                    }
                    else {
                        recommendedSection.style.display = "none";
                    }
                }
            });
        },
        _ShowToast: function (msg, durationInSeconds) {
            //Warn the user they can't add anymore favorite stores.
            let duration = Number.isFinite(durationInSeconds) ? durationInSeconds : 1;
            let toast = document.createElement("div");
            toast.id = "Warning";

            let fadeInPortion = document.createElement("div");
            fadeInPortion.classList = "fade in show";
            fadeInPortion.style = "position: fixed; z-index: 2147453178; bottom: 40px; font-family: Roboto, Arial, Verdana; font-size: 13px; width: 100%; padding: 0;";

            let fadeInChild = document.createElement("div");
            fadeInChild.style = "position: relative; padding: 10px 20px; background-image: linear-gradient(0deg, #05508B, #2094EF); background-color: transparent; color: #fff; text-align: left; margin: 0 auto; width: 94%;";

            let fadeInSpanOne = document.createElement("span");
            fadeInSpanOne.id = "toastClose";
            fadeInSpanOne.style = "position: absolute; top: 5px; right: 10px; cursor: pointer; font-size: 14px; color: #7DBEF2;";

            let fadeInSpanTwo = document.createElement("span");
            fadeInSpanTwo.style = "line-height: 15px; vertical-align: middle; text-align: center; margin: 0 auto; font-size: 109%;";
            fadeInSpanTwo.innerText = msg;

            let svgClose = document.createElementNS("http://www.w3.org/2000/svg", 'svg');
            svgClose.setAttribute("viewBox", "0 0 25 25");
            svgClose.setAttribute("style", "fill: #7DBEF2;width:12px;");

            let svgPath = document.createElementNS("http://www.w3.org/2000/svg", 'path');
            svgPath.setAttribute("d", "M23.954 21.03l-9.184-9.095 9.092-9.174-2.832-2.807-9.09 9.179-9.176-9.088-2.81 2.81 9.186 9.105-9.095 9.184 2.81 2.81 9.112-9.192 9.18 9.1z");

            svgClose.appendChild(svgPath);
            fadeInSpanOne.appendChild(svgClose);
            fadeInChild.appendChild(fadeInSpanOne);
            fadeInChild.appendChild(fadeInSpanTwo);
            fadeInPortion.appendChild(fadeInChild);
            toast.appendChild(fadeInPortion);

            var iterator = document.body.firstChild;
            while (iterator.nextSibling && (iterator.nextSibling !== document.body && iterator.parentNode !== document.body)) {
                if (!iterator.nextSibling)
                    iterator = iterator.nextSibling;
                else
                    iterator = iterator.parentNode;
            }

            var toastFunction = function () {
                let parent = iterator.parentNode;
                let oldToast = document.querySelector("#" + toast.id);
                if (oldToast) {
                    parent.removeChild(oldToast);
                    clearTimeout(popup.toastHandle);
                }
                parent.appendChild(toast);
                toast.querySelector("#toastClose").addEventListener("click", (e) => {
                    if (popup.toastHandle)
                        clearTimeout(popup.toastHandle);
                    parent.removeChild(toast);
                });

                popup.toastHandle = setTimeout(() => {
                    toast.classList.remove("show");
                    if (popup.toastHandle)
                        clearTimeout(popup.toastHandle);
                    popup.toastHandle = setTimeout(() => {
                        parent.removeChild(toast);
                        if (popup.toastHandle)
                            clearTimeout(popup.toastHandle);
                    }, 1000);
                }, 1000 * duration);
            };

            try {
                toastFunction();
            }
            catch (e) { }
        },
        _GetPrettyDateDifferences: function (diff) {
            let result = "Just now";
            let stop = false;
            let roundedNumber = 0;

            //Seconds
            diff = diff / 1000;
            if (diff < 60 && diff > 0 && !stop) {
                roundedNumber = Math.floor(diff);
                result = roundedNumber + (roundedNumber === 1 ? " second ago" : " seconds ago");
                stop = true;
            }

            //Minutes
            diff = diff / 60;
            if (diff < 60 && diff > 0 && !stop) {
                roundedNumber = Math.floor(diff);
                result = roundedNumber + (roundedNumber === 1 ? " minute ago" : " minutes ago");
                stop = true;
            }

            //Hours
            diff = diff / 60;
            if (diff < 24 && diff > 0 && !stop) {
                roundedNumber = Math.floor(diff);
                result = roundedNumber + (roundedNumber === 1 ? " hour ago" : " hours ago");
                stop = true;
            }

            //Days and weeks
            diff = diff / 24;
            if (diff < 30 && diff > 0 && !stop) {
                roundedNumber = Math.floor(diff);
                let weeks = Math.floor(roundedNumber / 7);
                if (weeks >= 1) {
                    result = weeks + (weeks === 1 ? " week ago" : " weeks ago");
                }
                else {
                    result = roundedNumber + (roundedNumber === 1 ? " day ago" : " days ago");
                }
                stop = true;
            }

            //Months
            diff = diff / 30;
            if (diff < 12 && diff > 0 && !stop) {
                roundedNumber = Math.floor(diff);
                result = roundedNumber + (roundedNumber === 1 ? " month ago" : " months ago");
                stop = true;
            }

            //Years
            diff = diff / 12;
            if (diff > 0 && !stop) {
                roundedNumber = Math.floor(diff);
                result = roundedNumber + (roundedNumber === 1 ? " year ago" : " years ago");
            }

            return result;
        },
        _GetDeals: function (callback) {
            let url = CDNSite + '/wssimplenonshopper.asmx/GetTodaysDeals';
            let params = Format('?isShopper={0}', isShopper);

            //button gets recent deals
            if (isButton) {
                url = CDNSite + '/wssimplenonshopper.asmx/GetAllDeals';
                params = Format('?isShopper={0}&max=10&sortBy=1', isShopper);
            }
            //new couponviewer gets more deals
            else if (!isButton && !isBF) {
                params = params + "&count=16";
            }

            _sendMessage({
                action: "FetchJson",
                targetScript: "shoptoolbar.js",
                data: {
                    url: url + params,
                }
            }, function (json) {
                if (!json)
                    return;

                //We load the deals and offers for today.
                let deals = document.querySelector("#homeContent .dealsGridWrapper");

                //Override the default rows count, in case we want to show more deals/offers in the future.
                deals.style.gridTemplateRows = "repeat(" + (json.length / 2) + ", 1fr)";

                //Clear up any leftover residues.
                while (deals.firstChild)
                    deals.removeChild(deals.firstChild);

                //Start populating the deals.
                for (let i = 0; i < json.length; i++) {
                    //put all formatting in a seperate function so that retailer deals can be shown the same way.
                    let div = popup._FormatDealLink(json[i], i);

                    deals.appendChild(div);
                }

                if (callback) callback();
            });
        },
        _GetDealsByName: function (searchTerm, callback) {

        }, 
        _FormatDealLink: function (dealJSON, idNumber) {
            let div = document.createElement("div");
            div.id = "deal" + idNumber;
            div.classList.add("dealsGrid");

            //Disable adding global box shadow for now.
            div.classList.add("globalBoxShadow");

            //We would need some web request calls to fetch retailers here. For now, we just display placeholders.
            let firstDiv = document.createElement("div");
            firstDiv.style.width = "100%";
            let firstChildDiv = document.createElement("div");
            firstChildDiv.classList = "bfslider_clearFix";
            firstChildDiv.style.color = '#696969';
            let firstChildFirstSpan = document.createElement("span");
            firstChildFirstSpan.classList = "dealTag";
            firstChildFirstSpan.innerText = "Deal";
            let firstChildSecondSpan = document.createElement("span");
            firstChildSecondSpan.classList = "bfslider_clearFix dealTime";
            let firstChildImg = document.createElement("img");
            firstChildImg.classList = "bfslider_clearFix dealTimeImg";
            firstChildImg.src = "../../today_only.png";

            //Deal time and Deal time banner image
            if (dealJSON.TodayOnly) {
                firstChildSecondSpan.style.display = "none";
                firstChildImg.style.display = "inline-block";
            }
            else {
                if (dealJSON.CreatedDateUTC) {
                    let createdDate = new Date(dealJSON.CreatedDateUTC);
                    let currentDate = new Date();
                    let diff = currentDate - createdDate;
                    firstChildSecondSpan.innerText = popup._GetPrettyDateDifferences(diff);
                    firstChildSecondSpan.style.display = "inline-block";
                    firstChildImg.style.display = "none";
                }
                else {
                    firstChildImg.style.display = "none";
                    firstChildSecondSpan.style.display = "none";
                }
            }

            firstChildDiv.appendChild(firstChildFirstSpan);
            firstChildDiv.appendChild(firstChildSecondSpan);
            firstChildDiv.appendChild(firstChildImg);
            firstDiv.appendChild(firstChildDiv);
            div.appendChild(firstDiv);

            let secondDiv = document.createElement("div");
            let secondDivImg = document.createElement("img");
            secondDivImg.classList = "dealImage";
            secondDivImg.src = "https:" + dealJSON.ImageUrl; //deal image
            secondDiv.appendChild(secondDivImg);
            div.appendChild(secondDiv);

            let thirdDiv = document.createElement("div");
            thirdDiv.style = "padding-left: 10px; padding-right: 10px; padding-bottom: 10px;";
            let thirdDivAnchor = document.createElement("a");
            thirdDivAnchor.classList = "dealURL";
            thirdDivAnchor.setAttribute("redirectURL", dealJSON.RedirectUrl); //Deal URL redirect
            let thirdDivAnchorSpan = document.createElement("span");
            thirdDivAnchorSpan.classList = "dealTitle";
            thirdDivAnchorSpan.innerText = dealJSON.OfferName; //Deal title.
            if (thirdDivAnchorSpan.innerText.length > 40) //Truncate the Deal title
                thirdDivAnchorSpan.innerText = (thirdDivAnchorSpan.innerText.substr(0, 37)) + "...";
            let thirdDivFirstDiv = document.createElement("div");
            let thirdDivFirstDivSpan = document.createElement("span");
            thirdDivFirstDivSpan.classList = "dealCompany";
            if (dealJSON.RetailerName) {
                thirdDivFirstDivSpan.innerText = dealJSON.RetailerName; //Company 
                div.classList.remove("dealsGrid");
                div.classList.add("dealsGridTall");
            }
            let thirdDivSecondDiv = document.createElement("div");
            let thirdDivSecondDivFirstSpan = document.createElement("span");
            thirdDivSecondDivFirstSpan.classList = "dealPrice";
            thirdDivSecondDivFirstSpan.innerText = RoundPriceFromString(dealJSON.OfferPrice); //Rounded Deal price
            let thirdDivSecondDivSecondSpan = document.createElement("span");
            thirdDivSecondDivSecondSpan.classList = "dealOriginalPrice";

            //Original Deal Price.
            if (dealJSON.OfferOriginalPrice && dealJSON.OfferOriginalPrice.length > 0) {
                thirdDivSecondDivSecondSpan.innerText = RoundPriceFromString(dealJSON.OfferOriginalPrice);
            }

            thirdDivAnchor.appendChild(thirdDivAnchorSpan);
            thirdDiv.appendChild(thirdDivAnchor);
            thirdDivFirstDiv.appendChild(thirdDivFirstDivSpan);
            thirdDiv.appendChild(thirdDivFirstDiv);
            thirdDivSecondDiv.appendChild(thirdDivSecondDivFirstSpan);
            thirdDivSecondDiv.appendChild(thirdDivSecondDivSecondSpan);
            thirdDiv.appendChild(thirdDivSecondDiv);
            div.appendChild(thirdDiv);
            div.setAttribute("retailerid", dealJSON.RetailerID);

            //Adding a click event handler.
            div.addEventListener("click", popup._DealsOnClickHandler);

            return div;
        },

        _FormatOfferLink: function (offerJSON, offerCodes, activateCashbackButton, applyButton, cashbackTermsLink, cashbackRateText, noDiscountsText, couponsOnlyText, isRestaurant, dbRow) {
            //Initial setups
            //Date format received is based on Gregorian Calendar, in 24-hour time format, with no time zones.
            //We need to display relevant information when the end date time is coming up.

            //Truthy or falsy based on string length.

            let showExpireTime = "";

            let currentDate = new Date();
            let offerEndDate = new Date(offerJSON.EndDateUTC.toString());

            //Date() - Date() returns total milliseconds. Converting milliseconds to days.
            let dateDifference = Math.floor((offerEndDate - currentDate) / (1000 * 60 * 60 * 24));
            if (offerEndDate.getFullYear() - currentDate.getFullYear() >= 1) {
                //It's an ongoing promotion event.
                showExpireTime = "";
            }
            else {
                switch (dateDifference) {
                    case 2:
                        //Shows expiring in 2 days
                        showExpireTime = "2 Days Left";
                        break;
                    case 1:
                        //Shows expiring in 1 day
                        showExpireTime = "1 Day Left";
                        break;
                    case 0:
                        //Shows expiring today
                        if (currentDate.getDay() !== offerEndDate.getDay())
                            showExpireTime = "1 Day Left";
                        else
                            showExpireTime = "Expires Today";
                        break;
                    default:
                        showExpireTime = "";
                        break;
                }
            }

            let classEndDate = "itemEndDateNow";
            if (showExpireTime.length > 0 && showExpireTime.indexOf("Day") > -1) {
                classEndDate = "itemEndDateDaysLeft";
            }

            let anchor = document.createElement("a");
            anchor.id = offerJSON.OfferId;
            anchor.classList.add("itemContainer");
            anchor.classList.add("itemCursor"); 

            //Disables right-clicking in the browser popup and hides the option to open things we never intended to be opened in a new tab.
            anchor.removeAttribute("href");

            let offerType = offerJSON.MobileClassification.Name;
            let isPrintable = (offerType === "Printable");
            let hasOfferCode = (typeof offerJSON.OfferCode === "string" && offerJSON.OfferCode.length > 0);
            let offerHTML = document.createElement('div');
            if (hasOfferCode) {
                offerHTML.classList = "itemTextContent itemCursor";
                let innerAnchor = document.createElement('a');
                offerCodes.push(offerJSON.OfferCode);
                innerAnchor.classList = "copyOfferCode";
                innerAnchor.setAttribute("code", offerJSON.OfferCode);
                let innerDiv = document.createElement('div');
                innerDiv.classList = "itemPromoCode itemCursor";
                innerDiv.setAttribute("offerId", offerJSON.OfferId);
                innerDiv.innerText = offerJSON.OfferCode;
                let copiedDiv = document.createElement('div');
                copiedDiv.classList = "itemCopied bfslider_clearFix";
                copiedDiv.style = "display: none;";
                let copiedSpan = document.createElement('span');
                copiedSpan.classList = "icon-checkmark-full-small";
                copiedDiv.appendChild(copiedSpan);
                copiedDiv.appendChild(document.createTextNode("Copied"));
                innerDiv.appendChild(copiedDiv);
                innerAnchor.appendChild(innerDiv);
                innerAnchor.appendChild(copiedDiv);
                offerHTML.appendChild(innerAnchor);
            }
            else {
                anchor.classList.add("itemGetOffer");
                offerHTML.classList = "itemOfferLink";
                offerHTML.setAttribute("offerId", offerJSON.OfferId);
                let innerSpanOne = document.createElement('span');
                innerSpanOne.style = "font-size: 16px; font-weight: 600;";
                innerSpanOne.innerText = (isPrintable ? "Get Offer " : "Get Offer ");
                if (offerJSON.Classification == 77) {
                    innerSpanOne.innerText = "View Menu ";
                } else if (offerJSON.Classification == 78) {
                    innerSpanOne.innerText = "Find Locations ";
                }
                let innerSpanTwo = document.createElement('span');
                innerSpanTwo.style = "position: relative; top: 1px; font-size: 14px;";
                innerSpanTwo.classList = "icon-chevron-right";
                offerHTML.appendChild(innerSpanOne);
                offerHTML.appendChild(innerSpanTwo);
            }
            if (showExpireTime.length > 0) {
                let anchorDivOne = document.createElement('div');
                anchorDivOne.style = "position: relative; height: 0; line-height: 0; top: -3px; left: -17px;margin-bottom: 12px;";
                let anchorDivTwo = document.createElement('div');
                anchorDivTwo.classList = classEndDate;
                anchorDivTwo.innerText = showExpireTime.toUpperCase();
                anchorDivOne.appendChild(anchorDivTwo);
                anchor.appendChild(anchorDivOne);
            }
            let anchorDivitemTitle = document.createElement('span');
            anchorDivitemTitle.classList = "itemTitle";
            anchorDivitemTitle.innerText = offerJSON.OfferName;
            anchor.appendChild(anchorDivitemTitle);
            if (offerJSON.matchingOffers) {
                anchorDivitemTitle.classList.add("itemCursor");
                anchor.classList.remove("itemCursor");
                let moreCouponsSpan = document.createElement('span');
                let numExtraCoupons = offerJSON.matchingOffers.length - 1;
                let addScrollbar = numExtraCoupons >= 4;
                let moreCoupons = "\n  +"+numExtraCoupons + " more...";
                moreCouponsSpan.innerText += moreCoupons;
                moreCouponsSpan.classList = "moreCouponsLink itemCursor";
                let moreCouponsModal = document.createElement('div')
                moreCouponsModal.classList = "modal moreCouponsModal";
                moreCouponsModal.style = "display:none; overflow: hidden;";
                let moreCouponsModalContent = document.createElement('div');
                moreCouponsModalContent.classList = "moreCoupons-modal-content " + (addScrollbar ? " custom-scrollable" : "");
                if (addScrollbar) {
                    moreCouponsModalContent.style = "height:72%; ";
                }
                let closeButton = document.getElementById('conflictAlertClose').cloneNode(true);
                closeButton.removeAttribute('id');
                closeButton.classList.add("modal-close");
                closeButton.childNodes[1].style.width="14px";
                let moreCouponsTitle = document.createElement('div');
                let numExtraCouponsSpan = document.createElement('span');
                numExtraCouponsSpan.innerText = numExtraCoupons
                let titleText = document.createElement('span');
                if (numExtraCoupons == 1) {
                    numExtraCouponsSpan.innerText = numExtraCoupons + " more offer";
                    titleText.innerText = " that works with the same code:";
                } else {
                    numExtraCouponsSpan.innerText = numExtraCoupons + " more offers";
                    titleText.innerText = " that work with the same code:";
                }
                numExtraCouponsSpan.style = "font-size:15px;font-weight:500";
                titleText.style = "font-size:15px";
                moreCouponsTitle.appendChild(numExtraCouponsSpan);
                moreCouponsTitle.appendChild(titleText);
                moreCouponsTitle.style = "margin:8px 0px 10px 0px;text-align:center;"
                let topOfPage = document.getElementById('retailerOffersContainer');

                topOfPage.appendChild(moreCouponsModal);
                moreCouponsModal.appendChild(moreCouponsModalContent);
                moreCouponsModalContent.appendChild(moreCouponsTitle);
                moreCouponsTitle.appendChild(closeButton);

                let moreCouponsContainer = document.createElement("div");
                moreCouponsContainer.id = "moreCouponsContainer";
                moreCouponsModalContent.appendChild(moreCouponsContainer);

                for (let k = 1; k < offerJSON.matchingOffers.length; k++) {
                    let moreCouponsHTML = popup._FormatOfferLink(offerJSON.matchingOffers[k], [], activateCashbackButton, applyButton, cashbackTermsLink, cashbackRateText, noDiscountsText, couponsOnlyText, isRestaurant, dbRow);
                    moreCouponsHTML.style = "margin-bottom:10px";
                    moreCouponsContainer.appendChild(moreCouponsHTML);
                }
                
                closeButton.onclick = function () {
                    moreCouponsModal.style.display = "none";
                }
                window.onclick = function (event) {
                    if (event.target.className == "modal moreCouponsModal") {
                        event.target.style.display = "none";
                    }
                }
                moreCouponsSpan.onclick = function () {
                    moreCouponsModal.style.display = "block";
                }
                anchor.appendChild(moreCouponsSpan);
                if (addScrollbar) {
                    window.SimpleScrollbar.initEl(moreCouponsModalContent);
                }
            }
            if (isRestaurant) {
                let offDesc = document.createElement('div');
                offDesc.classList.add('offerDescription');
                offDesc.innerText = offerJSON.OfferDescription;
                anchor.appendChild(offDesc);
            }
            anchor.appendChild(offerHTML);

            let itemTitle = anchor.querySelector("span.itemTitle");
            let itemTextContent = anchor.querySelector("div.itemTextContent");
            let copyCode = anchor.querySelector("a.copyOfferCode[code]");

            //This is split into upper section and lower section, if there exists promo codes.
            //This has to be added after the anchor element holds the offerHTML.
            if (hasOfferCode) {
                //Upper section
                itemTitle.classList.add("itemGetOffer");

                //Lower section
                itemTextContent.classList.add("itemCursor");
            }

            if (copyCode != null) {

                //Click event for copying the promo code, if code exists.
                let onCopyHandler = function (e) {
                    e.preventDefault();
                    e.stopPropagation();
                    let copyFrom = document.createElement("textarea");
                    let copyCode = e.target.querySelector("a.copyOfferCode[code]");
                    if (!copyCode) {
                        copyCode = e.target.parentNode;
                    }
                    //copy text
                    copyFrom.textContent = (copyCode && copyCode.getAttribute("code")) || e.target.innerText;
                    document.body.appendChild(copyFrom);
                    copyFrom.select();
                    document.execCommand('copy');
                    copyFrom.blur();
                    document.body.removeChild(copyFrom);

                    //Activate cashback
                    _sendMessage({
                        action: "activateCashBack",
                        targetScript: "buttonApp.js",
                        data: { retailerId: dbRow.RetailerID, tabId: activeTab.id, deeplink: false, HideButton: true }
                    }, function (activated) {
                        if (activated) {
                            _UpdateActionButton(true, activateCashbackButton, applyButton, cashbackTermsLink, cashbackRateText, noDiscountsText, couponsOnlyText, (dbRow.CashbackRate != null), (dbRow.CouponCount > 0));
                        }
                    });

                    //show copied text for some time
                    copyCode.querySelector("div.itemCopied").style.display = "inline-block";
                    setTimeout(() => {
                        copyCode.querySelector("div.itemCopied").style.display = "none";
                    }, 2000);
                    return false;
                };

                copyCode.addEventListener("click", onCopyHandler);
                itemTextContent.addEventListener("click", onCopyHandler);
            }

            //Clicking on the main anchor should redirect you to the offer link redirect URL.
            if (!offerJSON.matchingOffers) {
                anchor.addEventListener("click", (e) => {
                    e.preventDefault();

                    let offerCodeText = anchor.querySelector("div.itemPromoCode");
                    if (e.target === offerCodeText && e.target.getAttribute("offerId") === offerCodeText.getAttribute("offerId")) {
                        return false;
                    }

                    offerCodeText = anchor.querySelector("div.itemTextContent");
                    if (e.target === offerCodeText) {
                        return false;
                    }

                    if (isPrintable) {
                        _sendMessage({
                            action: "activateCashBack",
                            targetScript: "buttonApp.js",
                            data: { retailerId: dbRow.RetailerID, tabId: activeTab.id, deeplink: false, HideButton: false }
                        }, function (activated) {
                            _openLink(offerJSON.RedirectUrl);
                        });
                    }
                    else {
                        _sendMessage({
                            action: "hideDialogs",
                            targetScript: "buttonApp.js",
                            data: { tabId: activeTab.id }
                        });
                        _openLink(offerJSON.RedirectUrl + (noCookCheck() ? "&nocook=true" : ""));
                        _UpdateActionButton(true, activateCashbackButton, applyButton, cashbackTermsLink, cashbackRateText, noDiscountsText, couponsOnlyText, (dbRow.CashbackRate != null), (dbRow.CouponCount > 0));
                    }

                    return false;
                });
            }
            else {
                anchorDivitemTitle.addEventListener("click", (e) => {
                    e.preventDefault();

                    let offerCodeText = anchor.querySelector("div.itemPromoCode");
                    if (e.target === offerCodeText && e.target.getAttribute("offerId") === offerCodeText.getAttribute("offerId")) {
                        return false;
                    }

                    offerCodeText = anchor.querySelector("div.itemTextContent");
                    if (e.target === offerCodeText) {
                        return false;
                    }

                    if (isPrintable) {
                        _sendMessage({
                            action: "activateCashBack",
                            targetScript: "buttonApp.js",
                            data: { retailerId: dbRow.RetailerID, tabId: activeTab.id, deeplink: false, HideButton: false }
                        }, function (activated) {
                            _openLink(offerJSON.RedirectUrl);
                        });
                    }
                    else {
                        _sendMessage({
                            action: "hideDialogs",
                            targetScript: "buttonApp.js",
                            data: { tabId: activeTab.id }
                        });
                        _openLink(offerJSON.RedirectUrl + (noCookCheck ? "&nocook=true" : ""));
                        _UpdateActionButton(true, activateCashbackButton, applyButton, cashbackTermsLink, cashbackRateText, noDiscountsText, couponsOnlyText, (dbRow.CashbackRate != null), (dbRow.CouponCount > 0));
                    }

                    return false;
                });
            }
            return anchor;
        },

        _DealsOnClickHandler: function (e) {
            if (e.button === MOUSE_BUTTON_MAIN) {
                e.preventDefault();
                let newTarget = e.target;
                let link = newTarget.querySelector(".dealURL");
                while (!link && !newTarget.classList.contains("dealsGrid")) {
                    newTarget = newTarget.parentNode;
                    link = newTarget.querySelector(".dealURL");
                }
                if (link) {
                    _openLinkInCurrentTab(link.getAttribute("redirectURL"));
                    return false;
                }
                else {
                    return true;
                }
            }
            else {
                return true;
            }
        },

        _GetAccountBalance: function (wasAnon, callbackTop) {
            let showMyAccount = function () {
                let balanceArea = document.querySelector("#newMemberBalanceContainer_bf");
                balanceArea.querySelector("#newMemberNeedAccount").style.display = "block";
                balanceArea.querySelector("#newMemberLogin").innerText = "My Account";
                balanceArea.querySelector("#newMemberJoin").style.display = "none";
                balanceArea.querySelector("#newMemberSpacer").style.display = "none";
                balanceArea.querySelector("#newMemberLogin").addEventListener("click", (e) => {
                    _openLink("https://" + Site + "/account/member/");
                });
            };

            let privacyPromptRedirect = function (navurl, callback) {
                if (isAnonymous) {
                    privacyDialog(false, function (accepted) {
                        if (accepted) {
                            _openLink(navurl, true);
                            callback(true);
                        }
                        else callback(false);
                    });
                }
                else {
                    _openLink(navurl, true);
                    callback(true)
                }
            };

            let showLoginOrJoin = function () {
                let balanceArea = document.querySelector("#newMemberBalanceContainer_bf");
                balanceArea.querySelector("#newMemberNeedAccount").style.display = "block";
                balanceArea.querySelector("#newMemberJoin").addEventListener("click", (e) => {
                    privacyPromptRedirect("https://" + Site + "/account/member/?show=signup", function (allowed) {
                        //if (allowed) _closePopup();
                    });
                });
                balanceArea.querySelector("#newMemberLogin").addEventListener("click", (e) => {
                    privacyPromptRedirect("https://" + Site + "/account/member/?show=login", function (allowed) {
                        //if (allowed) _closePopup();
                    });
                });
            };

            let loggedInUserArea = function () {
                _sendMessage({
                    action: "Preference Manager",
                    targetScript: "shoptoolbar.js",
                    data: { prefs: ["Guest", "UserName"]}
                }, function ([Guest, currentEmailAddress]) {
                    //We load up the Settings page.
                    let settingsContent = document.querySelector("#settingsContent");
                    let emailAddress = settingsContent.querySelector("#newEmailAddress");
                    let wrongUserCreate = settingsContent.querySelector("#wrongUserCreate");
                    let settingsPopupUsername = document.getElementById("settingsPopupUsername");

                    settingsPopupUsername.onclick = function () {
                        _openLink("https://www.befrugal.com/account");
                    };

                    if (shoptoolbar._Browser === Browsers.Firefox && !isButton) {
                        document.getElementById("rateUsAction").style.display = "none";
                    }

                    //if the user logged out check to see if they have since logged back in
                    if (isAnonymous || noUser || (typeof currentEmailAddress === "string" && currentEmailAddress.length === 0) || (currentEmailAddress.indexOf("tbguest") > -1 && currentEmailAddress.indexOf("invalid") > -1) || Guest) {
                        emailAddress.innerText = "";
                        wrongUserCreate.innerText = "Create an account";
                        settingsPopupUsername.innerText = "Create an account";
                        document.getElementById("settingsPopupHi").style.display = "none";
                        settingsContent.querySelector("#wrongUserOr").style.display = "inline";
                        wrongUserCreate.addEventListener("click", (e) => {
                            privacyPromptRedirect("https://" + Site + "/account/member/?show=signup", function (allowed) {
                                if (allowed) _closeBrowserActionPopups();
                            });
                        });
                        let wrongUserLogin = settingsContent.querySelector("#wrongUserLogin");
                        wrongUserLogin.innerText = "Login";
                        wrongUserLogin.addEventListener("click", (e) => {
                            privacyPromptRedirect("https://" + Site + "/account/member/?show=login", function (allowed) {
                                if (allowed) _closeBrowserActionPopups();
                            });
                        });
                    }
                    else {
                        emailAddress.innerText = currentEmailAddress;
                        settingsPopupUsername.innerText = currentEmailAddress;
                        emailAddress.addEventListener("click", (e) => {
                            _openLink("https://" + Site + "/account/member/profile/", true);
                        });
                        wrongUserCreate.innerText = "Not You?";
                        wrongUserCreate.addEventListener("click", (e) => {
                            _sendMessage({
                                action: "logout",
                                targetScript: "buttonApp.js",
                            }, function () {
                                _openLink("https://" + Site + "/account/member/?show=login", true);
                                _closeBrowserActionPopups();
                            });
                        });
                    }
                });
            };

            let populateSettingsFromPrefs = function () {
                _sendMessage({
                    action: "Preference Manager",
                    targetScript: "shoptoolbar.js",
                    data: { prefs: ["AutomaticActivation", "AllowCashbackInjection", "AllowSubmissions", "TurnOffNotifications"] }
                }, function ([autoactivation, cbinjection, allowed, disablednotifications]) {
                    let autoActivateCBCheckbox = document.getElementById("flagAutoActivateCB");
                    autoActivateCBCheckbox.checked = autoactivation;
                    autoActivateCBCheckbox.addEventListener("change", (e) => {
                        _sendMessage({
                            action: "Preference Manager",
                            targetScript: "shoptoolbar.js",
                            data: { pref: "AutomaticActivation", value: autoActivateCBCheckbox.checked }
                        });
                    });

                    let allowCBInjectionCheckbox = document.getElementById("flagCBInjection");
                    allowCBInjectionCheckbox.checked = cbinjection;
                    allowCBInjectionCheckbox.addEventListener("change", (e) => {
                        if (allowCBInjectionCheckbox.checked) {
                            _sendMessage({
                                action: "cashbackInject_setSetting",
                                targetScript: "shoptoolbar.js",
                                cbSettingValue: "0"
                            }, () => { });
                        } else {
                            _sendMessage({
                                action: "cashbackInject_setSetting",
                                targetScript: "shoptoolbar.js",
                                cbSettingValue: "2"
                            }, () => { });
                        }
                    });

                    let allowSharingCheckbox = document.getElementById("flagSharing");
                    allowSharingCheckbox.checked = allowed;
                    allowSharingCheckbox.addEventListener("change", (e) => {
                        _sendMessage({
                            action: "Preference Manager",
                            targetScript: "shoptoolbar.js",
                            data: { pref: "AllowSubmissions", value: allowSharingCheckbox.checked }
                        });
                    });

                    let neverShowSettings = document.getElementById("neverShowSettings");
                    disablednotifications = disablednotifications || {};

                    let updateDisableList = function () {
                        _sendMessage({
                            action: "Preference Manager",
                            targetScript: "shoptoolbar.js",
                            data: { pref: "TurnOffNotifications", value: disablednotifications }
                        });
                    };

                    _sendMessage({
                        action: "GetIsRetailer",
                        targetScript: "shoptoolbar.js",
                    }, function (results) {
                        if (results[0]) {
                            for (let key in disablednotifications) {
                                if (key.toString() === results[1].toString()) {
                                    neverShowSettings.innerText = "Site Muted";
                                    break;
                                }
                            }
                            neverShowSettings.addEventListener("click", function () {
                                if (neverShowSettings.innerText == "Site Muted") {
                                    delete disablednotifications[results[1]];
                                    neverShowSettings.innerText = "Turn off Cash Back Alerts on this page";
                                    updateDisableList();
                                }
                                else {
                                    _sendMessage({ action: "NeverShowAgain", targetScript: "shoptoolbar.js", retailerid: results[1] }, function () {
                                        neverShowSettings.innerText = "Site Muted";
                                    });
                                }
                            });
                        }
                    });

                    updateDisableList();
                });
            };

            let guestSignup = function () {
                if (!isTour && (storeSource != Stores.Mac || !macHide)) {
                    //Classic needs height to scroll when we enable Signin Panel
                    let guestPanel = document.getElementById("guestLoginPanel");
                    guestPanel.style.display = "block";
                    let needAccountArea = document.querySelector("#newMemberNeedAccount");
                    needAccountArea.style.display = "none";

                    //Login Or Signup Panel display
                    guestPanel.querySelector("#guestLoginPanelAlreadyMember").addEventListener("click", function () {
                        GetAnonymity(function (isanon) {
                            if (isanon) {
                                privacyDialog(false, function (accepted) {
                                    if (accepted && (bsGuest || noUser)) {
                                        _openLink("https://" + Site + "/addon/installationcomplete-nonmember/?signup=1&show=login", true);
                                    }
                                    else if (accepted && !bsGuest && !noUser) {
                                        guestPanel.style.display = "none";
                                        needAccountArea.style.display = "none";
                                    }
                                });
                            }
                            else {
                                _openLink("https://" + Site + "/addon/installationcomplete-nonmember/?signup=1&show=login", true);
                            }
                        });
                    });

                    //Join clicked
                    let joinButton = guestPanel.querySelector(".orangeApplyButton");
                    joinButton.addEventListener("click", Login);

                    //Collapse Clicked
                    guestPanel.querySelector("#svg_closeGuestLogin").addEventListener("click", function () {
                        guestPanel.classList.add("hide");
                        joinButton.innerText = "Join for free to earn Cash Back";
                    });

                    //expand clicked
                    guestPanel.querySelector(".icon-chevron-down").addEventListener("click", function () {
                        guestPanel.classList.remove("hide");
                        joinButton.innerText = "Join for free";
                    });
                }
            };

            GetAnonymity(function (isanon) {
                if (!isanon) {
                    _FetchJsonPost(Format("{0}/wssimple.asmx/GetAccountInfo", APISite), function (json) {
                        let myBalance = document.querySelector("#myBalance");
                        let memberBalance = myBalance.querySelector("#newBalance");
                        if (json) {
                            _sendMessage({
                                action: "Preference Manager",
                                targetScript: "shoptoolbar.js",
                                data: { pref: "UserName"}
                            }, function (userName) {
                                let isGuest = false;
                                if (!json.UserName || json.UserName === "null") {
                                    isGuest = true;
                                } else {
                                    isGuest = json.UserName.toLowerCase().indexOf('invalid', json.UserName.length - 'invalid'.length) !== -1;
                                }
                                _sendMessage({
                                    action: "Preference Manager",
                                    targetScript: "shoptoolbar.js",
                                    data: { prefs: ["UserName", "UserToken", "IsShopper", "Guest"], values: [json.UserName, json.UserToken, !json.IsNonShopper, isGuest] }
                                });
                                if (!isGuest && json.AccountBalance) {
                                    myBalance.style.display = "block";
                                    document.querySelector("#newMemberBalanceContainer_bf #newMemberLogin").style.display = "none";
                                    let fixedNum = (Number.isInteger(json.AccountBalance.TotalBalance) ? json.AccountBalance.TotalBalance : json.AccountBalance.TotalBalance.toFixed(2));
                                    memberBalance.innerText = "$" + fixedNum.toString();
                                    if (json.AccountBalance.SignupBonusAsTotalBalance) {
                                        _sendMessage({
                                            action: "Preference Manager",
                                            targetScript: "shoptoolbar.js",
                                            data: { pref: "SignUpBalance", value: fixedNum }
                                        });
                                    }
                                }
                                else if (!isGuest) {
                                    showMyAccount();
                                }
                                else {
                                    _sendMessage({
                                        action: "sptool",
                                        targetScript: "shoptoolbar.js",
                                        data: { function: "GetReferralLinks" }
                                    }, function (refLinks) {
                                        //Show Welcome Bonus
                                        myBalance.style.display = "block";
                                        document.querySelector("#newMemberBalanceContainer_bf #newMemberLogin").style.display = "none";
                                        memberBalance.innerText = refLinks.SignupBonus + ".00";
                                        _sendMessage({
                                            action: "Preference Manager",
                                            targetScript: "shoptoolbar.js",
                                            data: { pref: "BonusEligibility" }
                                        }, function (eligibleRetailerID) {
                                            myBalance.querySelector("#newUserStatusMessage").innerText = eligibleRetailerID && eligibleRetailerID > 0 ? "Restaurant Bonus" : "Welcome Bonus";
                                        });
                                        //sign in panel
                                        guestSignup();
                                    });
                                }
                                loggedInUserArea();

                                //converted during this popup session
                                if (wasAnon) {
                                    _sendMessage({
                                        action: "sptool",
                                        targetScript: "shoptoolbar.js",
                                        data: { function: "_SetDefaultPreferences", args: [true], NoResponse: true }
                                    });
                                }
                                //set defaults, we've never seen this user before
                                else if (json.UserName !== userName) {
                                    _sendMessage({
                                        action: "Preference Manager",
                                        targetScript: "shoptoolbar.js",
                                        data: { pref: "AnonymousConversion" }
                                    }, function (_AnonymousConversionInfo) {
                                        _sendMessage({
                                            action: "sptool",
                                            targetScript: "shoptoolbar.js",
                                            data: { function: "_SetDefaultPreferences", args: [true], NoResponse: true }
                                        });
                                        if (_AnonymousConversionInfo) {
                                            _sendMessage({
                                                action: "Preference Manager",
                                                targetScript: "shoptoolbar.js",
                                                data: { pref: "AnonymousConversion", value: false }
                                            });
                                            populateSettingsFromPrefs();
                                        }
                                        else {
                                            let allowCBInjectionCheckbox = document.getElementById("flagCBInjection");
                                            if (allowCBInjectionCheckbox) {
                                                allowCBInjectionCheckbox.checked = defaultPreferences.AllowCashbackInjection;
                                            }
                                            let autoActivateCBCheckbox = document.getElementById("flagAutoActivateCB");
                                            if (autoActivateCBCheckbox) {
                                                autoActivateCBCheckbox.checked = defaultPreferences.AutomaticActivation;
                                            }
                                            let allowSharingCheckbox = document.getElementById("flagSharing");
                                            if (allowSharingCheckbox) {
                                                allowSharingCheckbox.checked = defaultPreferences.AllowSubmissions;
                                            }
                                        }
                                    });
                                }
                                //update prefs with new user data
                                else {
                                    populateSettingsFromPrefs();
                                }
                                if (callbackTop) callbackTop();
                            });
                        }
                        else {
                            noUser = true;
                            guestSignup();
                            loggedInUserArea();
                            showLoginOrJoin();
                            if (callbackTop) callbackTop();
                        }
                    });
                }
                //is anonymous
                else {
                    guestSignup();
                    showLoginOrJoin();
                    loggedInUserArea();
                    populateSettingsFromPrefs();
                    if (callbackTop) callbackTop();
                }
            });
        },
        _RemoveUnusedTab: function () {
            let unwantedTab;
            let unwantedContent;
            if (isButton) {
                document.getElementById("myStores").classList += " active show";
                document.getElementById("myStoresLink").classList += " active show";
                unwantedTab = document.querySelector('#catLI');
                unwantedContent = document.querySelector('#categories');
            } else {
                document.body.classList = "bfclassic";
                document.getElementById("categories").classList += " active show";
                document.getElementById("myCategoriesLink").classList += " active show";
                let rdso = settings.RetailerDigestStaticSettings;
                if (settings.RetailerDigestStaticSettings) {
                    document.getElementById("catRestaurantCount").innerText = rdso.RestaurantCount + " ";
                    document.getElementById("catGroceryCount").innerText = rdso.GroceryCount + " ";
                    document.getElementById("catWeeklyAdCount").innerText = rdso.WeeklyAdCount + " ";
                }
                unwantedTab = document.querySelector('#todaysDealsLI');
                unwantedContent = document.querySelector('div#todaysDeals');
            }
            unwantedTab.parentNode.removeChild(unwantedTab);
            unwantedContent.style.display = "none";
        }
    };
}();

function setReferralLinks() {
    _sendMessage({
        action: "sptool",
        targetScript: "shoptoolbar.js",
        data: { function: "GetReferralLinks" }
    }, function (refLinks) {
        let rafAnchorLink = document.querySelector("#rafLink");
        rafAnchorLink.innerText = "Invite a Friend and Earn " + (refLinks.BonusAmount ? refLinks.BonusAmount : "$$");

        let rafTabLabel = document.getElementById('spnAddTen');
        if (!refLinks || !refLinks.ReferralToken) {
            rafTabLabel.innerText = "Refer & Earn";
            rafTabLabel.onclick = function (e) {
                e.preventDefault();
                e.stopImmediatePropagation();
                _openLink("https://" + Site + "/account/member/refer-a-friend/");
                return true;
            };
        }
        else {
            rafTabLabel.innerText = "Get " + refLinks.BonusAmount;
            if (shoptoolbar._Browser === Browsers.iOS) {
                let refBanner = document.getElementById('ref_span_header');
                refBanner.innerText = "Refer & Get " + refLinks.BonusAmount;
            }

            let bonusAmount = parseInt(refLinks.BonusAmount.substring(1));
            if (bonusAmount > 10) {
                let refBonusAmountDiv = document.getElementById("refBonusAmountDiv");
                refBonusAmountDiv.classList.add("bounce_bf");
                refBonusAmountDiv.addEventListener("click", () => {
                    if (refBonusAmountDiv.classList.contains("bounce_bf")) refBonusAmountDiv.classList.remove("bounce_bf");
                })
            }

            let spnRAFBonus = document.getElementById('spnRAFBonus');
            spnRAFBonus.innerText = refLinks.BonusAmount;

            let spnSignupBonus = document.getElementById('spnSignupBonus');
            if (refLinks.RefSignupBonus) spnSignupBonus.innerText = refLinks.RefSignupBonus;

            let spnGuestSignupBonus = document.getElementById('spGuestSignUpBonusAmount');
            if (refLinks.SignupBonus) spnGuestSignupBonus.innerText = refLinks.SignupBonus;

            let txtRAFCopy = document.getElementById('txtCopyRAF');
            txtRAFCopy.value = (refLinks.Copy || "").replace("https://www.", "");

            var copyLinkButton = document.getElementById('copyRAFLink');
            copyLinkButton.addEventListener('click', function () {
                document.getElementById('txtCopyRAF').select();
                document.execCommand("copy", false, null);

                let spnCheckmark = document.createElement("span");
                spnCheckmark.classList = "icon-checkmark-full-small";
                spnCheckmark.style = "color: #007bdc; font-size: 12px;";
                let spnCopied = document.createElement("span");
                spnCopied.innerText = "Copied";
                spnCopied.style = "font-size: 16px; color: #007bdc";

                copyLinkButton.innerText = "";
                copyLinkButton.insertAdjacentElement('beforeend', spnCheckmark);
                copyLinkButton.appendChild(document.createTextNode("Copied"));

                setTimeout(() => {
                    copyLinkButton.innerText = "Copy";
                }, 2000);
            });
            document.getElementById('facebookLink').addEventListener('click', function () {
                window.open(refLinks.Facebook, 'targetWindow', 'toolbar=no,location=0,status=no,menubar=no,scrollbars=yes,resizable=yes,width=600,height=400');
            });
            document.getElementById('twitterLink').addEventListener('click', function () {
                window.open(refLinks.Twitter, 'targetWindow', 'toolbar=no,location=0,status=no,menubar=no,scrollbars=yes,resizable=yes,width=600,height=400');
            });
        }
    });
}
                                                                        
function _ToggleHeaderForIOS(isRetailer) {
    if (shoptoolbar._Browser === Browsers.iOS) {
        let header = document.getElementById("header");
        let retailerSpecificHeader = document.getElementById("retailerSpecificHeader");
        let neverShowWrapper = document.getElementById("neverShowWrapper");
        if (isRetailer) {
            header.style.height = "120px";
            retailerSpecificHeader.style.display = "block";
            neverShowWrapper.style.display = "block";
        }
        else {
            header.style.height = "min-content";
            retailerSpecificHeader.style.display = "none";
            neverShowWrapper.style.display = "none";
        }
    }
}

function _onDOMContentLoaded() {
    if (skin == 2) {
        document.body.classList.add("isUnionPlus");
    }

    // #region Initialization Stage.

    //Setting the current year.
    document.querySelector("#currentYear").innerText = new Date().getFullYear();

    //force badge to highlight
    //No longer need to pass in the new icon badge state.
    _sendMessage({
        action: "sptool",
        targetScript: "shoptoolbar.js",
        data: { function: "SetBadgeIcon", NoResponse: true }
    });

    //BeFrugal Buttons for Firefox now has "management" as one of the required permissions, but we don't have the disable list XML for Firefox yet.
    //Microsoft Edge currently doesn't have "management" as one of the supported permissions.
    if (isChrome) {
        document.querySelector(".retailerCBTermsCloseButtonContainer").style.top = "8px";
        // Look before we leap is it open, if so refresh, otherwise.
        document.getElementById("aIncompatibleAddons").addEventListener('click', function () {
            _sendMessage({
                action: "popupWorkaround",
                targetScript: "disableBackgroundApp.js",
            });
        });
    }
    else {
        //We hide the link for Edge and Firefox.
        let edgeObjects = document.querySelectorAll(".hideForEdge");
        for (let i = 0; i < edgeObjects.length; i++) {
            edgeObjects[i].style.display = "none";
        }

        // Fix positioning of 'x' on Firefox
        if (!isChrome) {
            document.getElementById("retailerCBTermsClose").style.position = "absolute";
        }
    }
                
    if (shoptoolbar._Browser === Browsers.Mac){
        let newTabOptions = document.querySelectorAll(".newSectionTabOption");
        for (let i = 0; i < newTabOptions.length; i++) {
            newTabOptions[i].style.color = "#aaa";
        }
    }
    
    if (nocashback) {
        if (shoptoolbar._Browser !== Browsers.iOS) {
            document.getElementById("newLogoContainer").style = "float: initial; margin: auto; padding: 10px 0 10px 0;";
            document.getElementById("newMemberBalanceContainer_bf").style.display = "none";
        }
    }
    else {
        //Retrieving the current member's balance, if any
        popup._GetAccountBalance(false);

        //Setting up listeners
        document.getElementById("myAccount").addEventListener("click", (e) => {
            let goToAccount = function () {
                if (bsGuest)
                    _openLink("https://" + Site + "/account/member/?show=signup", true);
                else
                    _openLink("https://" + Site + "/account/member/cash-back-and-bonuses/");
            };
            GetAnonymity(function (isanon) {
                if (isanon) {
                    privacyDialog(false, function (allowed) {
                        if (allowed) {
                            goToAccount();
                        }
                    });
                }
                else {
                    goToAccount();
                }
            });
        });
        document.getElementById("myBalance").addEventListener("click", (e) => {
            if (storeSource === Stores.Mac && bsGuest && macHide) return;
            else if (bsGuest)
                _openLink("https://" + Site + "/account/member/?show=signup");
            else
                _openLink("https://" + Site + "/account/member/cash-back-and-bonuses/");
        });

        document.getElementById("rafLink").addEventListener("click", (e) => {
            _openLink("https://" + Site + "/account/member/refer-a-friend/");
        });
        if (shoptoolbar._Browser !== Browsers.iOS) {
            document.getElementById("newFooter").addEventListener("click", (e) => {

                //reset couponviewer/cassic homepage
                if (!isButton && e && e.target && e.target.id === "footerHomeNav") {
                    popup._ResetRestaurantCategories();
                    popup._ResetGroceryCategories(true);
                    document.getElementById('backToCategoriesLink').click();
                }

                //We need to check if we're on a retailer specific layout, before reverting it back to the default layout if the user navigates away.
                //Then we let the navigation tab handle displaying the corresponding tab content.
                if (popup._CurrentPopupContent === _PopupContentEnum.Retailer || popup._CurrentPopupContent === _PopupContentEnum.SearchDeals) {
                    var nonretailerHeader = document.getElementById("nonretailer");
                    var retailerHeader = document.getElementById("retailerSpecific");
           
                    //Header display
                    if (shoptoolbar._Browser !== Browsers.iOS) {
                        nonretailerHeader.classList.add("show");
                        retailerHeader.classList.remove("show");
                    }
                    else {
                        retailerHeader.classList.add("show");
                        _ToggleHeaderForIOS(false);
                    }

                    // //Buttons
                    _LoadNonRetailerContents();
                }

                //if the footer is clicked removed the tooltip
                let tp = document.querySelector("#Tooltip");
                if (tp) tp.parentNode.removeChild(tp);
            });
        }

        document.getElementById('aQuickGuide').addEventListener('click', function () {
            _openLink(guidePage);
        });
        document.getElementById('aLoadLicense').addEventListener('click', function () {
            _sendMessage({
                action: "sptool",
                targetScript: "shoptoolbar.js",
                data: { function: "IncrementUsageMetrics", args: ['license'], NoResponse: true }
            });
            let eulaURL = 'https://' + Site + '/toolbar/eula.txt?bf_src=3&bfuser=' + encodeURIComponent(userToken) + '&toolbarversion=' + toolbarVersion;
            _openLink(eulaURL);
        });
        document.getElementById("tooltip_autoCB").addEventListener("click", function () {
            popup._ShowToast("While you are shopping in your browser, BeFrugal will activate Cash Back automatically for eligible stores. Your Cash Back earnings will be added to your BeFrugal account.", 7);
        });

        if (shoptoolbar._Browser === Browsers.Mac) {
            document.getElementById("bfrl_rateUsLink").addEventListener("click", (e) => {
                e.stopPropagation();
                e.preventDefault();
                e.stopImmediatePropagation();
                _openLinkInCurrentTab("macappstore://itunes.apple.com/app/id1591505828?action=write-review");
            });
        }
        else if (shoptoolbar._Browser === Browsers.Chrome) {
            document.getElementById("bfrl_rateUsLink").addEventListener("click", (e) => {
                if (storeSource === Stores.Microsoft)
                    _openLink("https://microsoftedge.microsoft.com/addons/detail/" + runTimeId);
                else
                    _openLink("https://chromewebstore.google.com/detail/befrugal-automatic-coupon/" + runTimeId + "/reviews");
            });
        }
        else if (shoptoolbar._Browser === Browsers.Firefox) {
            document.getElementById("bfrl_rateUsLink").addEventListener("click", (e) => {
                _openLink("https://addons.mozilla.org/en-US/firefox/addon/befrugal-automatic-coupons/");
            });
        }
        else {
            document.getElementById("rateUsAction").style.display = "none";
        }
    }

    document.querySelector("div[id*='viewAllDealsButton']").addEventListener("click", (e) => {
        _openLink("https://" + Site + "/deals/");
    });

    document.querySelector("#retailerCBTermsCloseButton").addEventListener("click", function () {
        let retailerCBTerms = document.querySelector("#retailerCBTerms");
        retailerCBTerms.classList.add("cbTerms_hide");
        retailerCBTerms.classList.remove("cbTerms_show");
    });

    //Once all the default data is populated and initialized, we then move on to checking if the popup is opened while the user is on a retailer or not.
    _sendMessage({
        action: "GetIsRetailer",
        targetScript: "shoptoolbar.js",
    }, function (results) {
        let isRetailer = results[0];
        let retailerId;
        let isCashbackActivated;
        let dbRow;
        if (isRetailer) {
            retailerId = results[1];
            isCashbackActivated = results[2];
            dbRow = results[3];
            if (shoptoolbar._Browser === Browsers.iOS) {
                document.getElementById('header').style.display = "block";
            }
            _LoadRetailerContents(retailerId, isCashbackActivated, dbRow);
        }
        else {
            _sendMessage({
                action: "_GetDealsFromSearch",
                targetScript: "shoptoolbar.js"
            }, function (response) {
                let deals = response.deals;
                let searchTerm = response.searchTerm;

                if (deals && deals.length > 0) {
                    _LoadDealsContents(deals, searchTerm);
                } else {
                    _LoadNonRetailerContents();
                }
            })
        }

        GetAnonymity(function (isanon) {
            if (!isanon && !noUser) {
                popup._GetFavoriteStores(() => {
                    if (isRetailer) {
                        _SetRetailerFavoriteIcon(retailerId);
                    }
                });
            } else {
                _SetRetailerFavoriteIcon(retailerId);
            }
        });
    });

    //We load the banners.
    var bannerContainer = document.getElementById("placementBanner");
    bannerContainer.style.display = "none";
    //popup._InitializeBanners(bannerContainer);


    // #endregion

    // Handles notifications that will be toggled whenever the user wants it or not.
    let turnOffSites = document.getElementById('aTurnOffNotifications');
    turnOffSites.addEventListener('click', function () {
        if (isChrome) {
            _openLink(chrome.runtime.getURL("settings/searchSites.html"));
        }
        else {
            _openLink(browser.runtime.getURL("settings/searchSites.html"));
        }
    });

    //Referral setup
    GetAnonymity(function (isanon) {
        if (!isanon) {
            setReferralLinks();
        }
        else {
            _sendMessage({
                action: "sptool",
                targetScript: "shoptoolbar.js",
                data: { function: "GetReferralLinks" }
            }, function (refLinks) {
                let setBonusAmount = function () {
                    let rafTabLabel = document.getElementById('spnAddTen');
                    rafTabLabel.innerText = "Add " + refLinks.BonusAmount;
                    if (shoptoolbar._Browser === Browsers.iOS) {
                        let refBanner = document.getElementById('ref_span_header');
                        refBanner.innerText = "Refer & Earn " + refLinks.BonusAmount;
                        document.getElementById("cbBalanceLinkSettings").innerText = "Cash Back Balance: " + refLinks.BonusAmount;
                    }
                };
                let hasBonusAlready = (refLinks && refLinks.BonusAmount && refLinks.BonusAmount.length > 0);
                if (hasBonusAlready) {
                    setBonusAmount();
                }
                else {
                    _sendMessage({
                        action: "sptool",
                        targetScript: "shoptoolbar.js",
                        data: { function: "GetReferralBonus" }
                    }, function (newLinks) {
                        refLinks = newLinks;
                        setBonusAmount();
                    });
                }
            });
        }
    });

    //Using keyboard keys to navigate up/down the search suggestion list.
    if (shoptoolbar._Browser !== Browsers.iOS) {
        document.querySelector("#newSearchBar").addEventListener("keydown", searchSuggestionOnNavigateHandler);
    }

    //Hide autoredirection if setting says to
    if (settings.AutoRedirectSettings && settings.AutoRedirectSettings.HideToolbarSetting) {
        let arElem = document.getElementById('rwAutoRedirection');
        if (arElem) arElem.style.display = "none";
    }
            
    if(shoptoolbar._Browser === Browsers.iOS) {
        let settingsIconHeader = document.getElementById("settingsIconHeader");
        if(settingsIconHeader != null) {
            settingsIconHeader.onclick = function () {
                let settingsPopupContainer = document.getElementById("settingsPopupContainer");
                if(settingsPopupContainer.style.display != "block")
                    settingsPopupContainer.style.display = "block";
                else
                    settingsPopupContainer.style.display = "none";
            };
        }
        
        let cbBalanceLinkSettings = document.getElementById("cbBalanceLinkSettings");
        if(cbBalanceLinkSettings != null) {
            cbBalanceLinkSettings.onclick = function () {
                _openLink("https://www.befrugal.com/account/member/cash-back-and-bonuses/");
            };
        }
        
        let manageCBAlertsSettings = document.getElementById("manageCBAlertsSettings");
        if(manageCBAlertsSettings != null) {
            manageCBAlertsSettings.onclick = function () {
                if (isChrome) {
                    _openLink(chrome.runtime.getURL("settings/searchSites.html"));
                }
                else {
                    _openLink(browser.runtime.getURL("settings/searchSites.html"));
                }
            };
        }
    }              
}
                                                                    
function privacyDialog(cashback, callback) {
    let requiresConfirmation = cashback;

    let policyDialog = document.createElement('div');
    policyDialog.style = "text-align:center; width:335px;display:block;z-index:9999999999;background:white;";
    policyDialog.id = "policyDialogDisplay";

    let policyDialogLogo = document.createElement('div');
    policyDialogLogo.style = "font-size:50px; position: relative; top: 18px;text-align:center;display: none;";
    policyDialogLogo.innerText = "\u26A0";

    let policyHeader = document.createElement('div');
    policyHeader.style = "font-size: 20px; margin: 30px 15px 15px 15px; text-align:center;font-weight:bold;";
    policyHeader.innerText = cashback ? "Allow Cookies to enable your Cash Back earnings" : "Allow Cookies to enable this feature";

    let policyBodyOne = document.createElement('div');
    policyBodyOne.style = "margin: 15px; text-align:center;";
    let policyBodyOneSpan = document.createElement('span');
    policyBodyOneSpan.style = "font-size: 15px;";
    policyBodyOneSpan.innerText = cashback ? "Without Cookies we don't know which account to send your Cash Back to." : "Without cookies we can't associate this feature to your account.";
    policyBodyOne.appendChild(policyBodyOneSpan);

    let gotIt = document.createElement('div');
    gotIt.style = "display: inline-block; width: 270px; background-color: #2196f3; color: white; padding: 10px; font-size: 20px; font-weight:bold; margin-top:15px; cursor:pointer; text-align:center;";
    gotIt.innerText = "Allow Cookies";

    let cancel = document.createElement('div');
    cancel.style = "font-size: 15px;color:#2196f3;margin: 10px; cursor:pointer; width: 50px; display: inline-block; text-align:center;";
    cancel.innerText = "Block";

    policyDialog.appendChild(policyDialogLogo);
    policyDialog.appendChild(policyHeader);
    policyDialog.appendChild(policyBodyOne);
    policyDialog.appendChild(gotIt);
    policyDialog.appendChild(cancel);

    if (document.body.parentNode) {
        document.body.parentNode.style.width = "335px"
        document.body.style.width = "335px";
    }

    document.body.appendChild(policyDialog);

    let header = document.getElementById("header");
    let newContent = document.getElementById("newContent");
    let newFooter = document.getElementById("newFooter");
    header.style.display = "none";
    newContent.style.display = "none";
    newFooter.style.display = "none";

    gotIt.onmouseover = function () { gotIt.style.backgroundColor = "rgb(12,123,214)"; };
    gotIt.onmouseout = function () { gotIt.style.backgroundColor = "#2196f3"; };

    let dismissIt = function () {
        header.style.display = "block";
        newContent.style.display = "block";
        newFooter.style.display = "block";
        policyDialog.style.display = "none";
        if (document.body.parentNode) {
            document.body.parentNode.style.width = "";
            document.body.style.width = "";
        }
    };

    gotIt.addEventListener("click", function (event) {
        dismissIt();
        isAnonymous = false;

        _sendMessage({
            action: "privacyAccepted",
            targetScript: "disableBackgroundApp.js"
        }, function () {
            setReferralLinks();
            popup._GetAccountBalance(true, function () {
                callback(true);
            });
        });
    });

    cancel.addEventListener("click", function (event) {
        if (!requiresConfirmation) {
            dismissIt();
            if (cashback) {
                if (settings.Config.PrivacyPrompt.CounterEnabled) {
                    recentDeclined = true;
                }
                _sendMessage({
                    action: "Preference Manager",
                    targetScript: "shoptoolbar.js",
                    data: { pref: PrivacyDeclinedDate, value: Date.now() }
                });
            }
            callback(false);
        }
        else {
            requiresConfirmation = false;
            policyHeader.innerText = "";
            policyHeader.style.fontSize = "18px";
            policyDialogLogo.style.display = "block";
            policyHeader.appendChild(document.createTextNode("Are You Sure You Want to Miss Out"));
            policyHeader.appendChild(document.createElement('br'));
            policyHeader.appendChild(document.createTextNode("on Cash Back?"));
            policyBodyOneSpan.innerText = "Allow Cookies to earn Cash Back. The extension uses cookies to award Cash Back.";
            policyHeader.style.textAlign = policyBodyOne.style.textAlign = "left";
            policyHeader.style.padding = policyBodyOne.style.padding = "0 25px";
            policyDialog.style.width = "370px";
            if (document.body.parentNode) {
                document.body.parentNode.style.width = "370px";
                document.body.style.width = "370px";
            }
            gotIt.style.margin = "15px 35px 0 35px";
        }
    });
}

function UpdateRequired() {
    let policyDialog = document.createElement('div');
    policyDialog.style = "text-align:center; margin-left: 35px; margin-right: 35px;";

    let policyHeader = document.createElement('div');
    policyHeader.style = "font-size: 26px; margin: 35px 15px 15px 15px; text-align:center;";
    policyHeader.innerText = "Update Required";

    let policyDialogLogo = document.createElement('img');
    policyDialogLogo.style = "height:185px; margin-top: 15px;";
    policyDialogLogo.src = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAANwAAADcCAYAAAAbWs+BAAAACXBIWXMAAAsTAAALEwEAmpwYAAAKT2lDQ1BQaG90b3Nob3AgSUNDIHByb2ZpbGUAAHjanVNnVFPpFj333vRCS4iAlEtvUhUIIFJCi4AUkSYqIQkQSoghodkVUcERRUUEG8igiAOOjoCMFVEsDIoK2AfkIaKOg6OIisr74Xuja9a89+bN/rXXPues852zzwfACAyWSDNRNYAMqUIeEeCDx8TG4eQuQIEKJHAAEAizZCFz/SMBAPh+PDwrIsAHvgABeNMLCADATZvAMByH/w/qQplcAYCEAcB0kThLCIAUAEB6jkKmAEBGAYCdmCZTAKAEAGDLY2LjAFAtAGAnf+bTAICd+Jl7AQBblCEVAaCRACATZYhEAGg7AKzPVopFAFgwABRmS8Q5ANgtADBJV2ZIALC3AMDOEAuyAAgMADBRiIUpAAR7AGDIIyN4AISZABRG8lc88SuuEOcqAAB4mbI8uSQ5RYFbCC1xB1dXLh4ozkkXKxQ2YQJhmkAuwnmZGTKBNA/g88wAAKCRFRHgg/P9eM4Ors7ONo62Dl8t6r8G/yJiYuP+5c+rcEAAAOF0ftH+LC+zGoA7BoBt/qIl7gRoXgugdfeLZrIPQLUAoOnaV/Nw+H48PEWhkLnZ2eXk5NhKxEJbYcpXff5nwl/AV/1s+X48/Pf14L7iJIEyXYFHBPjgwsz0TKUcz5IJhGLc5o9H/LcL//wd0yLESWK5WCoU41EScY5EmozzMqUiiUKSKcUl0v9k4t8s+wM+3zUAsGo+AXuRLahdYwP2SycQWHTA4vcAAPK7b8HUKAgDgGiD4c93/+8//UegJQCAZkmScQAAXkQkLlTKsz/HCAAARKCBKrBBG/TBGCzABhzBBdzBC/xgNoRCJMTCQhBCCmSAHHJgKayCQiiGzbAdKmAv1EAdNMBRaIaTcA4uwlW4Dj1wD/phCJ7BKLyBCQRByAgTYSHaiAFiilgjjggXmYX4IcFIBBKLJCDJiBRRIkuRNUgxUopUIFVIHfI9cgI5h1xGupE7yAAygvyGvEcxlIGyUT3UDLVDuag3GoRGogvQZHQxmo8WoJvQcrQaPYw2oefQq2gP2o8+Q8cwwOgYBzPEbDAuxsNCsTgsCZNjy7EirAyrxhqwVqwDu4n1Y8+xdwQSgUXACTYEd0IgYR5BSFhMWE7YSKggHCQ0EdoJNwkDhFHCJyKTqEu0JroR+cQYYjIxh1hILCPWEo8TLxB7iEPENyQSiUMyJ7mQAkmxpFTSEtJG0m5SI+ksqZs0SBojk8naZGuyBzmULCAryIXkneTD5DPkG+Qh8lsKnWJAcaT4U+IoUspqShnlEOU05QZlmDJBVaOaUt2ooVQRNY9aQq2htlKvUYeoEzR1mjnNgxZJS6WtopXTGmgXaPdpr+h0uhHdlR5Ol9BX0svpR+iX6AP0dwwNhhWDx4hnKBmbGAcYZxl3GK+YTKYZ04sZx1QwNzHrmOeZD5lvVVgqtip8FZHKCpVKlSaVGyovVKmqpqreqgtV81XLVI+pXlN9rkZVM1PjqQnUlqtVqp1Q61MbU2epO6iHqmeob1Q/pH5Z/YkGWcNMw09DpFGgsV/jvMYgC2MZs3gsIWsNq4Z1gTXEJrHN2Xx2KruY/R27iz2qqaE5QzNKM1ezUvOUZj8H45hx+Jx0TgnnKKeX836K3hTvKeIpG6Y0TLkxZVxrqpaXllirSKtRq0frvTau7aedpr1Fu1n7gQ5Bx0onXCdHZ4/OBZ3nU9lT3acKpxZNPTr1ri6qa6UbobtEd79up+6Ynr5egJ5Mb6feeb3n+hx9L/1U/W36p/VHDFgGswwkBtsMzhg8xTVxbzwdL8fb8VFDXcNAQ6VhlWGX4YSRudE8o9VGjUYPjGnGXOMk423GbcajJgYmISZLTepN7ppSTbmmKaY7TDtMx83MzaLN1pk1mz0x1zLnm+eb15vft2BaeFostqi2uGVJsuRaplnutrxuhVo5WaVYVVpds0atna0l1rutu6cRp7lOk06rntZnw7Dxtsm2qbcZsOXYBtuutm22fWFnYhdnt8Wuw+6TvZN9un2N/T0HDYfZDqsdWh1+c7RyFDpWOt6azpzuP33F9JbpL2dYzxDP2DPjthPLKcRpnVOb00dnF2e5c4PziIuJS4LLLpc+Lpsbxt3IveRKdPVxXeF60vWdm7Obwu2o26/uNu5p7ofcn8w0nymeWTNz0MPIQ+BR5dE/C5+VMGvfrH5PQ0+BZ7XnIy9jL5FXrdewt6V3qvdh7xc+9j5yn+M+4zw33jLeWV/MN8C3yLfLT8Nvnl+F30N/I/9k/3r/0QCngCUBZwOJgUGBWwL7+Hp8Ib+OPzrbZfay2e1BjKC5QRVBj4KtguXBrSFoyOyQrSH355jOkc5pDoVQfujW0Adh5mGLw34MJ4WHhVeGP45wiFga0TGXNXfR3ENz30T6RJZE3ptnMU85ry1KNSo+qi5qPNo3ujS6P8YuZlnM1VidWElsSxw5LiquNm5svt/87fOH4p3iC+N7F5gvyF1weaHOwvSFpxapLhIsOpZATIhOOJTwQRAqqBaMJfITdyWOCnnCHcJnIi/RNtGI2ENcKh5O8kgqTXqS7JG8NXkkxTOlLOW5hCepkLxMDUzdmzqeFpp2IG0yPTq9MYOSkZBxQqohTZO2Z+pn5mZ2y6xlhbL+xW6Lty8elQfJa7OQrAVZLQq2QqboVFoo1yoHsmdlV2a/zYnKOZarnivN7cyzytuQN5zvn//tEsIS4ZK2pYZLVy0dWOa9rGo5sjxxedsK4xUFK4ZWBqw8uIq2Km3VT6vtV5eufr0mek1rgV7ByoLBtQFr6wtVCuWFfevc1+1dT1gvWd+1YfqGnRs+FYmKrhTbF5cVf9go3HjlG4dvyr+Z3JS0qavEuWTPZtJm6ebeLZ5bDpaql+aXDm4N2dq0Dd9WtO319kXbL5fNKNu7g7ZDuaO/PLi8ZafJzs07P1SkVPRU+lQ27tLdtWHX+G7R7ht7vPY07NXbW7z3/T7JvttVAVVN1WbVZftJ+7P3P66Jqun4lvttXa1ObXHtxwPSA/0HIw6217nU1R3SPVRSj9Yr60cOxx++/p3vdy0NNg1VjZzG4iNwRHnk6fcJ3/ceDTradox7rOEH0x92HWcdL2pCmvKaRptTmvtbYlu6T8w+0dbq3nr8R9sfD5w0PFl5SvNUyWna6YLTk2fyz4ydlZ19fi753GDborZ752PO32oPb++6EHTh0kX/i+c7vDvOXPK4dPKy2+UTV7hXmq86X23qdOo8/pPTT8e7nLuarrlca7nuer21e2b36RueN87d9L158Rb/1tWeOT3dvfN6b/fF9/XfFt1+cif9zsu72Xcn7q28T7xf9EDtQdlD3YfVP1v+3Njv3H9qwHeg89HcR/cGhYPP/pH1jw9DBY+Zj8uGDYbrnjg+OTniP3L96fynQ89kzyaeF/6i/suuFxYvfvjV69fO0ZjRoZfyl5O/bXyl/erA6xmv28bCxh6+yXgzMV70VvvtwXfcdx3vo98PT+R8IH8o/2j5sfVT0Kf7kxmTk/8EA5jz/GMzLdsAAAAgY0hSTQAAeiUAAICDAAD5/wAAgOkAAHUwAADqYAAAOpgAABdvkl/FRgAAJP9JREFUeNrsnXtwXNd93z93X3gR4PL9lhYRpbUtR1zJkmM5UgimbKbj1BY5Tep64kSg60mstBMTmbpNM9Mx2aZtknYCacaNnKoNqdrupOkkgpNp7EaKCfrtamSCli17LZNcSZRI8QEuCGCB3b2P/nHOxd59ANjF3rt778X5zewsdnFxsXvu+dzf9/c753eO9vzFMsp8YxkgKX9Oycdydifw2jK/y8kHQB6YUk3rjR0ejrV0fEw1WUctKaGywToo3x/p0P+flM9nHSBOyZ+VdcAUcN5ZygHXwRrv1S0bWQZwJ3znJZg5dQkVcH6XgyMOuFIB87wjNSDmJXhn5bOSpQq4rnfSIxKwkYAB1sr3O1ID4BeBiZDL0JRXHl5TSZOWL4QN2ZF13hZTwLMSvjDJz1Hg08BwMwerpIl3d/pPSqmorCKhM8B4iOAbBU55+Q8iqt8sa0eA54Bb8iIo2FaGbxy4BJyRHTfosI0o4DojGU/IjvOcko1rshHZcW9JCFMBhA2vbrAKuOpOcknq95RqElek+HGH1zsSINgADijgvJGNZwIsg4J0Q3tOwjcaANjw6qa7XoEbdcjGEcVDRyX7KZ+AtxJsKoZzGbRTSjaua/BWg82zOG69ADcCnFOgKfBoLfWvgFvDBbVjtIzq374H74zHEr8V2DyJ48IKXJLKuJCK0YKlRM54pERahQ0q1RwKuCbitOOq/wb6Gp5z8RquBTYlKZuUj6fofhmMMvdUyrk2O/5aYbM/g6ueNixzKY8jBqyDDFpOPvKImjTne63eeOxOcsDRaVIBbZeMhO4kYhZQp2BztmdOAVcdbAcpTpuSF9Au9MzTuVozG7wRxBINGYKTTPo08BhwrMn2cgM2O66cVMCJBh33uVfLy4tlwzXZ5c9je8zJBp0qQ6W2z69tanu7MeDJDsBmqwTXLIj1cEnZmEd87MHsIs0pgmkZCd5jPlYPk8BR6gth3YTNvkktWxvXaj1c0IDLIKZj+S0emSC8ldBJeXN7zIfeLy+hm/QItiVO1iNwfpOQk1SKLsMGWTPw+UlhjMlr4FXx6KHlwoGwVnyfwh+zzHMSstOsz1Wt8vK7n5bwjSIq4butOMY7oKxcib/9Pg6XlEFyt2GbRGTHhhGp6fUIWyP4npRtckh6+rCaa4kTPwOXof1Bz3btNHC/7FCnFWOrJjCGQ9pOqbADl0HMGkl1EbRhmh/zUVaR3LYSOBmi2HYkzMCNSs+W7DJoSja2B94J2ZZPhuQ7ZcII3CgeL1O2giRSoHkT542FRGqGDrjjXYAtJ+OzQwq0jkjNZdPr6yWO8wtwp/A+tVt75z0p77yTioeOKolDEr6gxXcHwwJcp8fYJhGZxxOq/3fN7Fh5QknK8MKWR6SulXz0T3x3lMbzIf1oSTdkZTeBO95B2CYDeEddLzYRoGsTWOBGOxizjUmvlld92/fezu+x3UgQgRulM9nInIzVnlT9OVCxnZ8l/4GgAZfpEGwTErYp1YcDZxn8uxxEJkjAZRDTtby2kwEKxJV1R/2EPoZLIgpHkx2IA06ofqtg82sc1yngvJ6InCf8JSIKthDIyk4A5/XuoVOItLKK1xRsnbADfgZuFG/H2qZQKX8FW4DiOC+By3jcmAo2BZuK4aQlEUkSr+w0Iu2vYFOwBSqO8wo4L/dhO42YkaBMwaaAkw16xEMZqWBTsAU2jot48EHGPYTtkOqzCjYf2EG/AOfVVlE2bCpmU7ApSSntON6sQ59XsCnYfGbJtcpKt4BLIbYTUrApCztsbcVxbgHnlZRU60Iq2PxqI90CbtQjKXkSNTdSweZfO9AN4JJ4k5WcQM36V7D52zLdAM6LfbVzqLE2BZuK4Rr+w+MefBFVPKpgC20c1w5wXjTuGCpJomALsayMtEH2iMsffhK14I+CLVh2oFPAuT3mlpdSUpmCLdRxXGSNjey2dwviWvMKtvUNW8diOLe92yRqvE3BFlB74ZKe8RK4Udytc8ujhgCCZkcUbFXWEnCxLnu3p1AbawTNJhCLNmXk4wD+XrzVV3FcK8AdcblRc6jZJEG1nHw4Q4FkAwgz66AtDnoF3Cdd/qBKSobL8jIen2wguWohTK5XSak9f7HczHEjuLtM+SSqens9WypkknT48HCsqdCoWQ/3uPJuypQkXfEG4hpwKdxdzPU0KlGiLFySdIQm94pvBrhRlz/cSdW3lLVgU9TPr/WbJG16ilczwLkpJ5V3UxZGSZpxC7gjLt85lHdTFkZJmnILOOXdlClJ2oS9cEkfOTwcm2wHuCTurqD8lLr2ykIsSTM0kTiJrSIn3bJJVGGpsnBL0qYSJysB5+bMkmfV9VybpcfSQ8A+4B3AHcBeYA+wDdgAROWhBrAATANXgTeAN4EscCE7nr2hWrP7knS5mSYp4JKL7ntYXbemARsEHgIeRRTlHnDp1D8C/hr4OvC17Hj2lmrt9u3wcGvz/2MdkJPKu60O2X7gMPAbeJfKfod8fEr+z+8BzwBfyY5nX1FXoTO2nIc7g3tV3cMENDuZHkvfIT3NTmAReBV4OTueveLS+X8NeAJ4X5e/6neBp4H/lR3PziosvPNwjYBLAm7JjUkCOEm5CRB+Ir3D17Lj2W+t4fyfkOe/b9ULFO8hNjBELLmN2MBGogNDRPuHiPQOEIknQNPEgZaFpZcxiwsYC3MY8zMYhduUZ26iz05jLhaa+WhXJXifz45nLyqcOgPcKO5V9B5DjL8FDbZWZPA3gKez49kvNHHufyZBu3d5wBIkNu+iZ9cwPdv3Ed+8k+iGIYjGBFyaBpbV+GHDZx8nzVyYR5+5QfHKJRYuv0r5xluY5eJKH3UesaL2H7vlzRVwywN3CvfmT24iYIsDpcfS31qjxPsv2fHsP1/mnL8qQXu44V9GIvTu3k9/6l307N1PbOMWiETANKFUgvl5mJmBQgHm58TrUgksUxwDENEgGoV4vPLo6YGBAejrh94+8ZxIYBTmWHzzVRYu/YDFty5g6cuWaN0A/iA7nv3PCi3vgLuEO9O5JgjY0nfpsXQcKDlB6H/HQ0S37sQqLqLfvEL56usYc8veQ14GnsiOZ78hz9cL/CegIYiReA99w+9mwzseIrF1t3hzbh7r5g24ehXrylWYnoZCAa1YFE4rGhGPWAxiUQFZNCp+tqFbei8iIYxBNA79/TA4CBs3wY49EIuh375J4eL3mX/1u+i3p5f7Xl8BPpkdz35fIeYucBng3DqWk/cCS50q3jPAznsPwYOPwP53QrmIOTtD8dIrzJ87y8KPzwFW7Wl06c2KwL8B7q4DraePgXvew4Z3PERscFPlF7EY1vPPY545C5qUhtEYWjyOloij9SSgrxf6+sRzTw/09opHTy/0JKR3i0EkKrykpolzWYChQ7kIiwuwdQfs3rfkIS29ROHCy8z+4JuU89cbNY8lbyZ/ojBzD7jjuLcbThDl5FHgL+3XfRt3sPXODJgGvOt+uO8h0MviYZoUcz9kZvIvKL7VZH5Bi7Ah/SCD9z1CbEOyobSkWMR8/gXQddg4hLZxI9rQkICsp0eAFk8IDxeJVKBqhEf1D/JHS0Cm68L71f6ZUWYu+xKz3/saRqFhwvK2TKx8KTuePauAaw+453BnDG4KuD9ojZceS/8r4Pft14Pbf4rk7rRISJRLMHwPPPAwmJaAzjCw9BK3v/HX3H7x+RXPndi+j+RDv0DPjjtXuSKa8FBoVRnIpYdpimf7/TWb1sg7L5lRmGXmu3/H/I+/u9JJTgH/LjuevaSAa85q16XMuPQ5vhjQ9tvtfBGN91QgSPTAaxfgxa+DUZad30ADNj78ATYf/ghaJNrQq228/xDbP/Cx1WGzISqVRVKkWBSPUgnKZeGVbODago0VYQOI9g+y+ZEjbDn4S2jR2Ephw/fSY+mPK3HZOnAp3Kt9mwhoewxUK7yojIEiIi3f2wdvvwkvvyRkpmWKZ8Nk4O772fzzH66CLjowxLZf+FWG7j/UGMYAWP9d97H9Fz/O4IFHiW/Z1eiQDcAz6bH0HyqcWgPOLe+WJyyVAVpEJB+i0Uq81NMLb1+BCz+S2suGzqA/9S4G73tUSMhte9n+ix+nd89d3n0+U/5v06iWmi5bYutuku/5++z4pd9i25FP0HtHutFhn0qPpZ9RSK1sMQ+Amwxwe1SNBluaJYDTNJFy12SCoicGb78lxrU2bxXZP8MEy2TovkdE/Hfvw0R6+rz7pJYl0vsJKXv1MiwsQHFB/C4Scf/+Uy7Tu3s/vXf9NHMvf5P8mf+NVS45D/l4eix9Ljue/WOF1uoe7qBL5zwf4PZ4qypxUC5Vxric41vRGMTicOUy3M7LmEqk17VYgo0P/Lw3sFkWGIaAq7ggPsPWHbBpK2zbBftSsOdOGNwoEjte2GIBFhfYcODn2P6Rf0F86+7aI343PZberNDqnKQMsof7ofNFeXFOyskoRGI1g8pSHFy7KiDw0ixLJEzKckiiLDKkvPkaFOaEh7UTKn39sHMPbN6ydBNw3QpzsDBPYs9+tv7ybxHp7Xf+dg/w6wqtlYFL4t7CKkEGLlfl4UoFLM0xeyMSdcR0UeFhDENMt/JAwokPYUjAdPkw5MOEhQLcuAZoS3HkUjYzuRV6+72BTovA/CwszBPbtpuhRx+rPeJjCq2VgXPLuwU9WfJqlYdbmEUvLTSALVI9pWphvjKn0U0rl+th06U3M3QB042rYvaIDZxpymdDxHeWh611+xYUiww8dJjoho3O39wta/yUeQxcLsiNIWvBlm4alqFTnrtVmSYVjVTgc8ZzpiXGyhrN+FgzbCXQS2DaoBkV0Oz3TBNmb4sHVIYp7OdY3LvG0jTxf27dIJLopfeeunkOjyq8VpaU6z1hYlvVXMGFW29Vx26RGnlpw+iadNNEnFYqLg+aYVQ8XqkI+WnhyUzT4eHMujIdT6RlqQgz0yTuuKf2t+9TeNWbPSzgVoZyMgRt8nXni+L0FSzTRLOLPSMRlqZdReRzNC7lmxv6zZLDDxEpFU2W5j+aMhtqyZ/t8bf8Tdi1t1rWWlZnWisSgZlpYoNban9zt8JreQ/nluWD3iCyBOXCUs6iWGDx1pWKV9Mi1d5Oi4rMoJtJk1gMBjaIh6ZVspJ18lLGaoU5cYzlANKyJLya941mWURLdQWth9Jj6fcqxBoDN6KSJlX2p84X85ez1aA5JWVPDyQS7noUe65kogc2bYG+AVml4EiY2A9TZisXFyqTm83KlLOOmBYh1ruBnh131P7mAwox7zxcLkTt8hXni8Vrr6Mv3K6O2Wzwenq9k2+WJeRrchNs3ibLasqOOE4+SiUoFirJEtMR53VIWmrRGIPv/tnat389PZZOKMyqgcso4Opk5beBF5f6vWkwe/G8rLR2DA3EE96NvzljOtMU8nLnXvH/SsXKYLc986RUkgkT6eFs+DpovXvvJjZYNclkF/ARhVk1cEkVvzW0p6tk5WuvOIYI5EyTeE3avben/j23zDRFZffelIgZSyUJnV2245jEbD/0ckcbTIvG6L+rbiGyTyjMvJGU58PUMNnx7Ckcy01YeplbL73gGPCOO1bJAkPT+PwLX+PvXv4hVrTFUhytBejiCUjtF+uT2J7O9mTO6gFDh7LemaSJw/rvuq/W679PrhWjTAKXUs3QnJcrXnud+YvfF4Pdzk4VjXH52g1++3/+Jf/tmy+xuLjYfEePx8UYWrPHW3J8bc+d4tkwZEwZd8w0sWTW0ux4g8WHNhPfuLX27bTqSu4Dlwtb42THs88A/9X53uwr36yHwzDYvW0LvznyMI/s2kpff39TyQorFuM//PkX+bd/8xUKegveyDRhYBDu3F/xevF4ZZaJZXRcTla8dYTEtr217/6MQk1YzMVz5ULaRn+GY/Z7pG9DPRiWRVzTOPH4hwUAxVITHVPDMAz+/FsvUiDKxx5+gP5tW8QYWzNm6LBtJ8xMQ1F6VEN3SEuze51qSA2CdwK4sNpPV0mmTTuWcVcWLBaXYFrVw1kWsViUP33iGJdvTLN3awuwLXk6A/akxMz9pUFvq6uwAUT7NtS+tUN1IwVcs7ajujMNVHmpuuXG7SSI5ljCbrlFf3SDB9J38cA7767A2opZlhh47+kVEnLlhbg6pypjdUNvG1Q3UsCtaumx9L8Efrcq6LVX8jLlFCtDpuUNGTsZcu4jct5lIiGASPQI+Gq9T6nNWMuewoU/YAPQ6rO0Pao3KeBWg+0Y8AcN5VKpJBeDNWomFVuO1Lx8XZgTz/EeGBwSA9j2vgEhtQbL6vWqHqWAWwm2X6FmPqUWjZJ88B/Qt+unZK1ZDOJ9YojAHiZYWk68JKrAC3MioWFZsDgvYq3eXtiyXYBnGCElri7bGgn4N0qyzIysFy7prZwnFwNOyIeyij1Re8fecvCX6duzX8rEHjHw7VxqfOlZTvvaHhEFpDO3xLJ6szPiZAsFeOMSbN0uwHNlUVdlHlsGsUlpu3ZSebh67/ZRwDELV2PTz3yAvn33yB1rYqIkxxlDaTiWHzfBlPf0eI+Y/7htF1y7Ihb9mZ8VYF59U6yqvHNPc1nNIJnVxDvr1CKqCVb2bv3D9zKQfo8YWLZXT3YqJs35hkZlTwCZMjR0kbHck4IHfxZ23yEzihG48Ta8fjF03dHS68Yh51S3UsA18m5R4P3OWGRD+sFKlbeTtkhEVHw739eWa2IJXjQK994vZojoZRH73boJN6813MkmqGbWF6PeVr1LAdfIqtYljw1uJrFtT/1WvlpELMRaKFRWY3Z6PHtPNk3CpkXEa3tZhHdlhJTUywLc6euhSqAYhZnaty6rrqWAa2R7nC+iA0Nozh10HJ6P/C0Rh2m10tKGMyKyldmXRTV2JOKI9TS494HKMuXzc2IF50gIvJxlUb55tfbd86prKeBWbQ9tCbQa2ExTDHjbKf+l2M1xTCQilq+7dRPmZhwwyUVbh5Jwx13Cy1kW3JpuvkzHZ4AtrRSm61jFAsW3X6s96msB7xcpBZw3VhXcm3pNiYstKU1TzDKpK3+p2UTRXvbALtdxPkxT7AUQiwvQCnPBkJXOjSFrl3owDYpXX8dYqGrGC9nx7BUFHAA5BVy1VW1ubS7OY9q7w9hxGXIBVEN3jMNVq8mlY8rlyjJ3UJ2NNE3YMAT9A3JHVVnBrWn+B6xqISPDsaKYTuHSy7VneFZ1KwXccvaG84U+P4M+c8MBgcN76XrN8nhaAy+oV1bfciZU7CGDWFzMszTNWmL9IxMbAWYaNQvSiveN+VkWLr9ae7avh6BfHFCS0gPLjmfLwLedXqhw6ZVqWGz4DF3EYUtS0gmd7LR2fVpvH0sTmp0JFnu1ZEsWkcZi3RkAXwLMrF7V2YbLCZjp9GzOPQ8M5n9yDrNcNSTw/ex49kwIukbSpfPkFXD1Vr140I9fwijMVnufaBQ2bobkFsfajzVeUEN0xEQPbBh0lO44xvHKRRG7gTimU1lKWyYatXHYMjA5AdTtKolqOWkWZpm9MFX7n/57SPqEKzHc4eHYlAKu3sv9Dxz7xJnFAvnvfMnhlaQU3HunWDKvijVHpjIqlzzYvFV4OKtmFeRYDG5eh8K8+HnLdm/XIGkkE03ngrI1exc417bUjZrFZ2sg1XVuZ/8fZnHB+R9/Qs0+DSppoqoFlrM/AZ60XxR+MkUk0cOmg/9IDmZTSYI4paZWMw6Xulvs0WaX4ti/j0bFils/+K7o+Lv2CQ/nVpbSOSF6qRKcSu1cXdFs7Xs0Pq7qnJW/Xbh6kdn6ZMnT2fHsQgj6Qsal80yqGG55L/cU8DfO9+Ze+Q43//bzmKXFmtxGo0SHTIoMbRIV2ZYjfotGhHQ8922xT/imLbDnjvbq45xLnBt6nfdZ+tlssFS6fYxe77UaZiONaq9ozM0wff5srXd+MTue/aOQdIekmydTHm55ewL4PI59zgoXvkc5f53kzx2l9457qpMlWs3gt0y6iB125PSveEJ04pe+Chd+JKZ37RsWcypblZPWch5oudescCyVAtql9xt4RCy5d3jl9/rbb2CWF2s/3WdC1A9GXDrPWeXhVvZyryNWDf6q8/3yzStcf+5pbn75c5SuXGrg5Gzw5OTmaAzi8r725mtw9ktw5TLsfycM3y3kZTOw1czoqPJA9sKvplE/GN0wtV97bNmxcrNR7RGrzlHzPHcbq1gH25dlHBwWc2tIIK883OrQvZIeS38YeAb4h87grZB9iUL2JRI7U/QO30vP3ruIbdlZWSLOMKBsiulft/NigvLiopCQqf0CtJVitobeyBGTLeflqrzQCvEYTXhB+1yNvF6pBKUihlFXinMtZN3ArYTJlAKuOeiuAh9Mj6X/I/A7tb8vXc1RupoTvi2WoO+ud7P5fR9Es9eJNAzh9DZtFZLS7sS1sNkJCdOsh4DVkhw1CY9lpSWryM4mkifIige9DGgYpToPF7bKgIybwClJ2Tx4/xr4KPCNZZ2SXqKQPYcxN1NZiqGvX2Qqo9HK4kLOTlw3o8Mh68yaJEXtWJjeSD7qKwxcO5IkzjE23Zlccf5dgwSLaXtQ6cj1OuCuhOiyuxW/5Q8Px5SkXAN0XwC+kB5Lfwj4ezKxUrVRhRZPoGkRMY+ydied1ZIctodzHmv/3ikToUbqtSIVzdVlZu1ntfcLjycqS0jYX6leFs8p4Bp7NwXc2sH7K+Cv5LqVjwAvLAFnl+aYBizqopMuLQZrNh9XtTouRs35lz0fgFmdmbQBbnS8aYq1NXv7xMwUvUKbZRqUFuqKuc+phEnjDKUCrn3wiumxdHVxZSSCZlcQlHWRXIjHK6n/Zb1PMzDSRPp/9YHqlT2tIyNqyYqGvn4hOal4M1MvcfMn36FcDdzt7Hg2TMWmysP50KoWOdUijq2sNDkAXpgXA95xufqyZVY8irmarDQbQ2M6PdVqknK1cTjHz4ZcyLanF5LbRBxaKuKsLSoXZpjOfpvSfL62LZ4OWbIkqYDzn1Ut461FYwI6asbWikW51ILcOXVp9eX6weRlIbNWSN87Y7NG8nC1GNIwxPOGQRjcKBeqNcUyEbZXKy0y+/orzL2Zxaxfmev/ZsezvxOi63rEpfPkDg/Hcgo492ywLmkSiVZl8pa8nWGIsTjLErFdokd4Puf2Ui3JxGbnSC4jRe1l2S3QYxrRPSm0jZvFee09w6V8LFzOcvvieYzF+UZt8EXgH4fsuj7mtndTwLljN5wvzMUCZnGBSMO9vuUMFFOHORn7xGVCwvZ4jbwZq0w0diY/VoLO6f1MA9AoWiXmb71F4c1X6bv1TgbuvJdY/xCYBvrMNMXrb1C4/CP0wuxy3/+z2fHsEyG7pkncG387W9UDnr9YVsi0aemx9EVgeEljbt/H5vd/kFjPBrnXQFmOd5VFIsV+Ty9DuURh5m0WF2cY2LWfnuQOWbjq8JDNykJzFVjlsaX5WywU8izM3qA8c73+tiDr8ixzxeqFLPCZ7Hj2MyG8pKPAKZfOdf/h4ZiK4Vy2p4E/XArXrr3BtS8/y4Z7HqR/793E4n2N/0oOIVilBebf/DHFmWvseuw3RZJlYV4kK3S9kjFcAmi5TGZjD2eUFikX5yjO3mTx9nVKC7OstNzzKqDNAL8P/FF2PFsK6fV0S07mnLApD+eul3uuUaCtxeIkhraSSG4n1juARlQkL8s6ll7ELBVZzF9hcW6a+Oad7PzQJyoTiktlAV2pKJIXzhkiNoR27GeIMTGjvIBZKmKUBWT64jx6aQHTaPs6vylvLJ+TE7vDaknglkvnOn14OHZMxXAeWHY8ezQ9ln4W+LUqb6GXKU5foTi9+oynSDzhGAOTFeLxeOVZr5mapZeXpmeZeonrr357LWDlJUiTwHuBDwEPyd+9CPwfxEJAX5VrvoTdjrh4rrO1byjg3IXu8fRY+hzw28C+Vv8+kmiwb+FyWUoa52RasG9K0P4sO561Nzn7W+D30mPpXvl9FtfhZXzcxXNNKOC8h+7J9Fj6NPBPgN9oJdsV6Wt3K+wVifsB8BfSW30lO541VvgOi+v08qVwb3bJhD1hWQHnPXR54LPAZ9Nj6UHEnLz3IjYLGQT6AB2YB/7pUrLlyiUW37pA7/Y7W0ct2vBS/grwIyCXHc9Oqyuzqo16KSdV0sQfyZbL1Gwi0j/8bgbveQ+JoW2VmM00GpTViBiuPDvN3NuXmL/5Ola15Eysk7jLLbuEewWnw84ZJq16uDPyg0whdkKZko+cukZt29PA7znfKFz6PoXcD+jZupfebfuI9g4QicbRLDFgbek6ZrGAXpihmL9GcW66UWz3HQVby97NLdimGsHWCnA5qW1TVGdx8g74nCAqa15+/vv0WJpa6LAsitffoHj9jXZAVtadZMlTy0r/JiXlcWC8FcIbQJhX13RFaTkCfAr4QJun+g5iTUi1iUbzlsHdOr5NjRImrQA3ImVlO5ZTkrQp8D6KqCR/f4t/+i0J2udUK7Zsp1xMmEwcHo4dbdfDgTdbvytJujx4GxDV5I8CdwCbqCznUEZsrXURsdnh1x1jacpas5RMlrhlRw8PxybcAM7NDI6SpMrC6N1yh4djwysdEGsRgk4Bl6F+wFhJUmVeeLdRF8+3atzcCnDncXee2VoaJ4XKkipzzz7t8vlOr3ZAK5JyhPYTJ50yJUmVdTp2q6sMaNfDBUm+KUmqrJnYzU1rahim1aldt3B5+54um5Kk69PcVmuTh4djh5o5sNXJy1O4N5vaD5aU32dESVLl3dqwp5o9sFXgzoYMOCVJ15+dwN1se26lcbd2gVvPHSxFfZb0KA2KDJX5+hp+0uVznmzl4FZ3z1HxTcWOKdgCKSWTLnu30wq4zsB2WjVDoOyIB+HQyVb/YC37w00q2BRsAbMk7idKJtfSD9YCXE7Bpixg9hzuD2edXMsfrQW48wo2ZQGy4x5Iycm1Kr21ADelYFMWEMvQWuF0K/2BTgE3qWBTFpC47TkPzvtkO2FVZI1/l1OwKfO5ncL9crL8WmO3doGbUrAp87GdwJtSsmO0OcVvrcCdV7Ap86kdwf06NzuUmmj3JJE2/rmCTZnfLIP74222lDzmxolUDKdgC4slESU3SQ/OfdKtPt8OcHkFm7J1ANskIjNJN4GDcCVOFGzBhy3jZynpBnBnFWzKfGBewQYw5nb41A5wOQWbsi7bKQ9hm/Cib6xnSalgCz5sox6dO+e2lLQttk6BU7CpmG2luO0oHiUFI23+/aSCTVmIYLPjNs+cSbvA5RRsykIE22mv+0e7wJ1XsCnrgGUQqyR7CduUV3Gbm8BNKdiUeWxH8G5Q26nUDnXiy6yHGE7BFlw7gTfLIzgtj4dJEreB83scp2ALbrz2HN7M+q+1Q51Uam4A51dZmUMt6xfUeO0cndka7Vin+4gbwPk1cZKS2n9U9eHA2HEJWyqs6scN4PwcxyURMxK8jgOUtX+dzuDNgj++CjXCHsPZdgSRVj6i+rZvr81Ih/7f6W7G9W4Blw9QIK68nb8kfyevx2k6MNbmNXAQrOSEfUc9rvp81+yEjNVGOvg/uw6bm8AFrTYuKeOFTl/09W4j8mb36Q6rjGN+gM1N4HIB7QAZh6xJKR48l49nutDOvhqLXY+SciWZeUqB5zpop+hsUsS3sCng6m1Ugec6aKNd+P954H58OMso4uK5JkPUYRR4a5fo3QTNDm86Ol2rW8DlQtiBbPDOoMbwVmunM4gk1GgXP8eU9Gy+VVwxF88V5uXPR+QjBzwrpUpunUOWknA97hMVcBqfZCI75eG8vKv4Ja2bQqS0ba83yvoaRE86vJmd3u82bHkf9Y9VTXv+YtnN81kewXbaESP4MYU/AXxRPudDCNkR4DEfyuocopataxLy8HCsq8BdchmGRmndpAzM/RpTTTngmwooZBkHZBmffsYJXNg+KujAPeciCKuNoYwiZov4WdLlEdnb87SxL3QHY9QD8tnvbTqGT1L+3QbuBO5U6TY7YJmS3m4kQN5jSkohG8J8Bz1hRsJkw5XysQdrZJOyb+T88oG6DdyIDKg7AZvTjtP5+XlexCM5CeD5mvdasZRD1h+QbZIi2OOJecSWUU/67YN1G7iUjOM6CVuQvZ2yAHq1doCLuPz/c20Ese3Oe8shZhh0PZBW5ppXOyavaS4sXyriwTmnugCb004Dw36UH8qatiflNTwdti/mBXBnuwib8+44Ji/apOq/gZKPw/LahVKleAFcrsuwNZKZhxR4vgftUNjko98kZSdrlSYd8V1O9W/fWM4Rp62LG2K3gOtWYaAd3ynw/AFaKOO0TgPHKncrP1Th2uAdVVKz49Lx6HoEzWvgcj6GzWkTjtjhtOLB0xuc3c4T67khvALufABgq73z2hLnpJKbrt10TzokvFISHgI3FSDYajvJCYfcnFBdZE2qwZaNJ9TNq9rcntrlNCtgsC1nSUQFxOOoaWMr3WCfIpz1gCtaq1O7Yh5+FltSBD02ylNZjz4lofNjMWY3PNlZ+ay8mA88XCrkFyLpgG+E8K/ulZNx2Nn16MmC4uHCbHnZ8SYcN5gR4GBIAMxJqXhWgjal8PK3h1vvlkIUd2YkhBn8W6+Xd8A1RaVIVlmAPNx6t5x8TNTI0IwDvoPy/ZEOfaZJ+XzWAdmUkoedMwVc5z3JJMuPSaUcUjTVhizNOTxUTnkr/9j/HwB/WHFzIVTVDwAAAABJRU5ErkJggg==";

    let policyBodyOne = document.createElement('div');
    policyBodyOne.style = "margin: 40px 40px 10px 40px; text-align:center;";
    let policyBodyOneSpan = document.createElement('span');
    policyBodyOneSpan.style = "font-size: 16px; color:grey";
    policyBodyOneSpan.innerText = "Please update to the latest version to continue saving with BeFrugal";
    policyBodyOne.appendChild(policyBodyOneSpan);

    let gotIt = document.createElement('div');
    gotIt.style = "display: inline-block; width: 300px; padding: 10px; font-size: 22px; margin:15px 0 30px 0; cursor:pointer; text-align:center;color:white; border-radius: 6px; box-shadow: -3px 4px 5px 0px rgba(0, 0, 0, 0.50); border-bottom: none;";
    gotIt.innerText = "Update BeFrugal";
    gotIt.classList = "disableTextSelect orangeApplyButton";
    let spnViewTwo = document.createElement('img');
    spnViewTwo.style = "margin-left: 10px; vertical-align: middle;height: 21px;position: relative;top: -1px;";
    spnViewTwo.src = "data:image/png; base64, iVBORw0KGgoAAAANSUhEUgAAAQAAAAEABAMAAACuXLVVAAAALVBMVEUAAAD///////////////////////////////////////////////////////+hSKubAAAADnRSTlMAAQIKZGVplZaZmpu8/XqoetgAAAABYktHRA5vvTBPAAABs0lEQVR42u3duw3CQBCE4ZOAnBJcACXQAgUQENMXJVAIJThGIF0NyLIsv+7OJJ6RpX8b2NG3m2y0IfxX1ypY61A/vQFu8Vt5AWJ8egGilaABsBI0AE6CFsBI0AL4CDoAG0EH4CLoAUwEPYCHYAhgIRgCOAjGAAaCMYCeYAogJ5gCqAnmAGKCOYCWIAUgJUgBKAnSAEKCNICOIAcgI8gBqAjyACKCPICGoAQgITiV+sf3cfUAu1c0E5yLAQRbAAEEEEAAAQQQQAABBBBAAAEEEEAAAQQQQAABBBBAAAEEEEAAAQQQQAABBBBAAAEEEEAAAQQQQAABBBBsjWAhwMM8gk8FAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAGwPwP5CYl97AUK4WDdggUABUCKQAJQINAB5AhFAnkAFkCOQAeQIdABpAiFAmkAJkCKQAqQItABzAjHAnEANMCWQA0wJ9ABjAgPAmMABMCSwAAwJPAA9gQmgJ3ABdAQ2gI7AB9ASGAFaAidAQ2AFaAi8ACHc1zqHf6Q+/FDBuZ4QAAAAAElFTkSuQmCC";
    gotIt.appendChild(spnViewTwo);

    let termsDiv = document.createElement('div');
    termsDiv.style = "margin: 0 30px 20px 30px;";
    let termsTextOne = document.createElement("span");
    termsTextOne.innerText = "By downloading, users accepts ";
    termsTextOne.style = "font-size: 14px; color:grey";
    let termLink = document.createElement('span');
    termLink.innerText = "Terms";
    termLink.style = "font-size: 14px; color:grey;cursor:pointer;";
    let privacyLink = document.createElement('span');
    privacyLink.innerText = "Privacy Policy";
    privacyLink.style = "font-size: 14px; color:grey;cursor:pointer;";
    let eulaLink = document.createElement('span');
    eulaLink.innerText = "EULA";
    eulaLink.style = "font-size: 14px; color:grey;cursor:pointer;";

    termsTextOne.appendChild(termLink);
    termsTextOne.appendChild(document.createTextNode(", "));
    termsTextOne.appendChild(privacyLink);
    termsTextOne.appendChild(document.createTextNode(", "));
    termsTextOne.appendChild(eulaLink);
    termsDiv.appendChild(termsTextOne);

    policyDialog.appendChild(policyHeader);
    policyDialog.appendChild(policyDialogLogo);
    policyDialog.appendChild(policyBodyOne);
    policyDialog.appendChild(gotIt);
    policyDialog.appendChild(termsDiv);

    document.body.appendChild(policyDialog);

    let header = document.getElementById("header");
    let newContent = document.getElementById("newContent");
    let newFooter = document.getElementById("newFooter");
    header.style.display = "none";
    newContent.style.display = "none";
    newFooter.style.display = "none";

    gotIt.onclick = function () {
        _openLink(settings.Config.UpdateUrl);
    };
    privacyLink.onclick = function () {
        _openLink("https://www.befrugal.com/help/privacypolicy/");
    };
    termLink.onclick = function () {
        _openLink("https://www.befrugal.com/termsandconditions/");
    };
    eulaLink.onclick = function () {
        let eulaURL = 'https://' + Site + '/toolbar/eula.txt?bf_src=3&bfuser=' + encodeURIComponent(userToken) + '&toolbarversion=' + toolbarVersion;
        _openLink(eulaURL);
    };
}

function UpdateReminder(secureUser) {

    let moneyImage = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAIcAAABlCAYAAABna/CDAAAACXBIWXMAAAsTAAALEwEAmpwYAAAKT2lDQ1BQaG90b3Nob3AgSUNDIHByb2ZpbGUAAHjanVNnVFPpFj333vRCS4iAlEtvUhUIIFJCi4AUkSYqIQkQSoghodkVUcERRUUEG8igiAOOjoCMFVEsDIoK2AfkIaKOg6OIisr74Xuja9a89+bN/rXXPues852zzwfACAyWSDNRNYAMqUIeEeCDx8TG4eQuQIEKJHAAEAizZCFz/SMBAPh+PDwrIsAHvgABeNMLCADATZvAMByH/w/qQplcAYCEAcB0kThLCIAUAEB6jkKmAEBGAYCdmCZTAKAEAGDLY2LjAFAtAGAnf+bTAICd+Jl7AQBblCEVAaCRACATZYhEAGg7AKzPVopFAFgwABRmS8Q5ANgtADBJV2ZIALC3AMDOEAuyAAgMADBRiIUpAAR7AGDIIyN4AISZABRG8lc88SuuEOcqAAB4mbI8uSQ5RYFbCC1xB1dXLh4ozkkXKxQ2YQJhmkAuwnmZGTKBNA/g88wAAKCRFRHgg/P9eM4Ors7ONo62Dl8t6r8G/yJiYuP+5c+rcEAAAOF0ftH+LC+zGoA7BoBt/qIl7gRoXgugdfeLZrIPQLUAoOnaV/Nw+H48PEWhkLnZ2eXk5NhKxEJbYcpXff5nwl/AV/1s+X48/Pf14L7iJIEyXYFHBPjgwsz0TKUcz5IJhGLc5o9H/LcL//wd0yLESWK5WCoU41EScY5EmozzMqUiiUKSKcUl0v9k4t8s+wM+3zUAsGo+AXuRLahdYwP2SycQWHTA4vcAAPK7b8HUKAgDgGiD4c93/+8//UegJQCAZkmScQAAXkQkLlTKsz/HCAAARKCBKrBBG/TBGCzABhzBBdzBC/xgNoRCJMTCQhBCCmSAHHJgKayCQiiGzbAdKmAv1EAdNMBRaIaTcA4uwlW4Dj1wD/phCJ7BKLyBCQRByAgTYSHaiAFiilgjjggXmYX4IcFIBBKLJCDJiBRRIkuRNUgxUopUIFVIHfI9cgI5h1xGupE7yAAygvyGvEcxlIGyUT3UDLVDuag3GoRGogvQZHQxmo8WoJvQcrQaPYw2oefQq2gP2o8+Q8cwwOgYBzPEbDAuxsNCsTgsCZNjy7EirAyrxhqwVqwDu4n1Y8+xdwQSgUXACTYEd0IgYR5BSFhMWE7YSKggHCQ0EdoJNwkDhFHCJyKTqEu0JroR+cQYYjIxh1hILCPWEo8TLxB7iEPENyQSiUMyJ7mQAkmxpFTSEtJG0m5SI+ksqZs0SBojk8naZGuyBzmULCAryIXkneTD5DPkG+Qh8lsKnWJAcaT4U+IoUspqShnlEOU05QZlmDJBVaOaUt2ooVQRNY9aQq2htlKvUYeoEzR1mjnNgxZJS6WtopXTGmgXaPdpr+h0uhHdlR5Ol9BX0svpR+iX6AP0dwwNhhWDx4hnKBmbGAcYZxl3GK+YTKYZ04sZx1QwNzHrmOeZD5lvVVgqtip8FZHKCpVKlSaVGyovVKmqpqreqgtV81XLVI+pXlN9rkZVM1PjqQnUlqtVqp1Q61MbU2epO6iHqmeob1Q/pH5Z/YkGWcNMw09DpFGgsV/jvMYgC2MZs3gsIWsNq4Z1gTXEJrHN2Xx2KruY/R27iz2qqaE5QzNKM1ezUvOUZj8H45hx+Jx0TgnnKKeX836K3hTvKeIpG6Y0TLkxZVxrqpaXllirSKtRq0frvTau7aedpr1Fu1n7gQ5Bx0onXCdHZ4/OBZ3nU9lT3acKpxZNPTr1ri6qa6UbobtEd79up+6Ynr5egJ5Mb6feeb3n+hx9L/1U/W36p/VHDFgGswwkBtsMzhg8xTVxbzwdL8fb8VFDXcNAQ6VhlWGX4YSRudE8o9VGjUYPjGnGXOMk423GbcajJgYmISZLTepN7ppSTbmmKaY7TDtMx83MzaLN1pk1mz0x1zLnm+eb15vft2BaeFostqi2uGVJsuRaplnutrxuhVo5WaVYVVpds0atna0l1rutu6cRp7lOk06rntZnw7Dxtsm2qbcZsOXYBtuutm22fWFnYhdnt8Wuw+6TvZN9un2N/T0HDYfZDqsdWh1+c7RyFDpWOt6azpzuP33F9JbpL2dYzxDP2DPjthPLKcRpnVOb00dnF2e5c4PziIuJS4LLLpc+Lpsbxt3IveRKdPVxXeF60vWdm7Obwu2o26/uNu5p7ofcn8w0nymeWTNz0MPIQ+BR5dE/C5+VMGvfrH5PQ0+BZ7XnIy9jL5FXrdewt6V3qvdh7xc+9j5yn+M+4zw33jLeWV/MN8C3yLfLT8Nvnl+F30N/I/9k/3r/0QCngCUBZwOJgUGBWwL7+Hp8Ib+OPzrbZfay2e1BjKC5QRVBj4KtguXBrSFoyOyQrSH355jOkc5pDoVQfujW0Adh5mGLw34MJ4WHhVeGP45wiFga0TGXNXfR3ENz30T6RJZE3ptnMU85ry1KNSo+qi5qPNo3ujS6P8YuZlnM1VidWElsSxw5LiquNm5svt/87fOH4p3iC+N7F5gvyF1weaHOwvSFpxapLhIsOpZATIhOOJTwQRAqqBaMJfITdyWOCnnCHcJnIi/RNtGI2ENcKh5O8kgqTXqS7JG8NXkkxTOlLOW5hCepkLxMDUzdmzqeFpp2IG0yPTq9MYOSkZBxQqohTZO2Z+pn5mZ2y6xlhbL+xW6Lty8elQfJa7OQrAVZLQq2QqboVFoo1yoHsmdlV2a/zYnKOZarnivN7cyzytuQN5zvn//tEsIS4ZK2pYZLVy0dWOa9rGo5sjxxedsK4xUFK4ZWBqw8uIq2Km3VT6vtV5eufr0mek1rgV7ByoLBtQFr6wtVCuWFfevc1+1dT1gvWd+1YfqGnRs+FYmKrhTbF5cVf9go3HjlG4dvyr+Z3JS0qavEuWTPZtJm6ebeLZ5bDpaql+aXDm4N2dq0Dd9WtO319kXbL5fNKNu7g7ZDuaO/PLi8ZafJzs07P1SkVPRU+lQ27tLdtWHX+G7R7ht7vPY07NXbW7z3/T7JvttVAVVN1WbVZftJ+7P3P66Jqun4lvttXa1ObXHtxwPSA/0HIw6217nU1R3SPVRSj9Yr60cOxx++/p3vdy0NNg1VjZzG4iNwRHnk6fcJ3/ceDTradox7rOEH0x92HWcdL2pCmvKaRptTmvtbYlu6T8w+0dbq3nr8R9sfD5w0PFl5SvNUyWna6YLTk2fyz4ydlZ19fi753GDborZ752PO32oPb++6EHTh0kX/i+c7vDvOXPK4dPKy2+UTV7hXmq86X23qdOo8/pPTT8e7nLuarrlca7nuer21e2b36RueN87d9L158Rb/1tWeOT3dvfN6b/fF9/XfFt1+cif9zsu72Xcn7q28T7xf9EDtQdlD3YfVP1v+3Njv3H9qwHeg89HcR/cGhYPP/pH1jw9DBY+Zj8uGDYbrnjg+OTniP3L96fynQ89kzyaeF/6i/suuFxYvfvjV69fO0ZjRoZfyl5O/bXyl/erA6xmv28bCxh6+yXgzMV70VvvtwXfcdx3vo98PT+R8IH8o/2j5sfVT0Kf7kxmTk/8EA5jz/GMzLdsAAAAgY0hSTQAAeiUAAICDAAD5/wAAgOkAAHUwAADqYAAAOpgAABdvkl/FRgAAFDRJREFUeNrsXV1sE1mW/pxy4sR2bOzYzg8JMUkgCzTdYZbubTVo1ey2NDtSdy9SPzBvy6B5mx1tr6JZDdoHduYlPQ9RC7Ej9RM0b/RTQw9vg0RGCq1uYImB5ifkz4khdmynHDuxSSV2sg9xOXbVLde95bIThxyp1aESl6vqfvec73zn3FuG9fV1iGYwGFApGxjuvwLgQwAXAVw/f3LQj13bVmbYQnDEAOzJOzQE4GoWKAu7Q/OGgmNguP8sgCtF/uQ6gKvnTw5e3x2iNw8c3wI4TfGnC1mgXDx/ctC3O1w7HBwDw/17AMQ0fNSfDTtf7/KTnQsOYkjJrKXB1RhpT+PLA8ouP9lB4BgB0Ccb7Yn74DgObnsz3HYPC1CuA7hx/uTg17vDWcXgGBju9wKYkh6PLc3jxctnBcccjU1wWJvgbHTSAmUhj8gO7Q5t9YHjfwBckB6fDI4hEp8jfobjjHBam+BodMJhbWLhJyJQdolslYBjCoBXyjVGJu4jk0mrft5UWw9HoxNuezPMJgsrP9kV2rYrOAaG+/sAjEiPR+JhTAZfMJ/PXG+B294Mh7UJploTEz/BrtC27cBxBcBZ6fEXr54htjhf0rltZjtc9mYt/OTGrtC2PcAhlcshrArwTdyTcYxOTxdCsVdILSeZv8dtb97lJ9UEjoHh/tMAvpUeD8VmMT03KRvcrtYDOfBE43OIxMMQVpeZvpPjjHDbPaz8xI/dQmDFwUGUyx/7R2Te4dC+o7CZ7bJzpIQkQvws+KV5KvIqJbItzjZWfjKEN7wQWHZwKMnlKSGJx1MjskHs6z6ues7Y0jxii7xi+qtGZFsce1n4CQB8/Sbyk0qA4ywIcvl0eBIhfrbgWIuzDZ2eLupzZ9bS4Bd5RONzSKTizNfmaGyC2+5h4ScikX0jCoGVAIeiXC7lEX3d77K4fUjJbWxpHiF+VhM/cVqb0OJsY+UnO7oQWFZwKMnliVQcz2Yey9z9Ue8xXb43JSQRic8htsgzA0UU2loce1mA6ssjsgu74KADx+cAvpQeJ8nlnc1daHG06X6DIj/RQmRFoU1DIXBHNCqVGxwyuRwA7o/9IBuo4wffZxkAZhP5yQZY2EU3sRDotntY+UnVFgLLBg4WudzR2ISDew9V7KZFfhKJzzELbSI/cdk9xJS7CD8Riax/FxzD/V8C+Fx6nCSXd7UeZJmRupoe/ERjIXDbNyqVExwyuTyzlsb9Fz/IZuKx7uNlDSm0lkjFEY2HS+InO6kQWBZwaJXLt4PxCR58nEc0HgZq1mGoWdfMT6q9EFgucBArsCS5/GD7IRYRqjwcZEVAYC6AWCKGNMFjGLgsSAxsQKn2RiXdwaEkl5MqsLRyebksnUnDP+tHJBahfFqAoWYdhpo1gPFRaSwEivxkSwqB5QDHWZRJLtc7fEwEJoiegvLJbXoURtNYCKw4PykHOG5jYw1s4RQgyOVH9x9jmUW6mX/Wj2A0qN9DrFnXzE80NCoBFSoE6gqOcsjlwooA/6wffIIHABg5I1pdrWhvbtd0jeOBcfowohEoBo6dn4jknJGfLGSBUhZ+ojc4PoeOcrmwIuDR2COi63c73Ojp6NlWwNCTn2gsBOraqKQ3OKjlcpoKrNpgvn3gbVga6B6e3qHEXGdBaiVJ+5Q3PYoGfuK2e+CyN1e8EKgbOJTkcqUFSzRy+YPnDyCsCIq/72juoAovfILHqH9UV8dw4ZNBmOssGJm5i2v3LlN9xmlzwuNyVbpRSUyLmfmJnrLkv5EORuJhuUhEGVMzmYxu6aqe5rJ60OHcDwBostLL/nyCh9vpRlfrAXQ272cuBKaWk5gMvsBkkKkQeBrA6YHhflFoo25U0hMcp2WDu5aW3TjHGeFsdNIxeYstR0SJM6nBrHqOUDRU1PuohY6PDn+MYx3v5cAAAPNLm4D3BX5kzpScto2Zv6F7eDQVAmOLG6CaDk/SFgL3YEOYPDsw3O8HRaOSLmFFSS4nVWBZ5PJEMoEnE0+Iv7M0WPD2gbdVvcbI8xFNWkaHcz9+9/M/wlxXnNPML4Xx12c38f34bWoO0tPRA7fDTfYOW9OoRCwE6gWOssnlkVgE/ll/wQDbrDb0dvbCyBV3fC/nXiIwF9DkMS58MsgUMlIrSXz38BvcenpTfRDrTPjZ3/1M3TtsTaNSbseCksGRlcunQLlg6fiB9zXxhtRyauMcNRx1hqJGaJXsRM8p/OrEb2WD//34bXQ496O35YjiZ289vUlFUHu9vXDanPSTJB4uuVGJsRD4nzU6cY090oNRAhvX2rNh5IywWWywWWzUwEi+TmrmGiSP8efbf8K1e5dhrtvkOd+P35b9XSA2RRcylxKMApkHB/cewvGD76OzuQvmenplObY4j8ngC4xM3MdkcAyxJVWA7QGwoAch/VfaLMVtb0alLJaI6Xq+AD9VkKWMzNzF5TuX8NdnN3HuxL8XHKfNXLxtXubr4GqMaHG0ocXRBmFVQCj2ipqfZDJpROJziMTn1PiJ//zJweslgSMrl58mkSrpxZpq6ytaR0m+Tmr+LIlYfnT444LjYpYS4Kfwh7/049yJ36KBQRgTVgSkM2lV3lScgJrQ6elCp6eLuVFJWF1GiJ+FzWwngeO6HqnsaWL6KKm+AhsV2EqasCpo/uz347fx6TtnCjKVT985UzDwUg9x+c4luKxsYTO1nILNYtPlfm1mO2xmO7pwIJsWh1X5CccZlZKDqwBQKucgCl88IaZVuqGnVM/xDYFUimAZmblL9BDRpTAz0S6HOaxNOX7S1XpQkZ84yWPiE0UyzeDIyuV9pPRL6tYUXNe2tjvjt3HlziXi7/Y5vQWimGYQvk6V9R5Eoe2o9xg6m7tovflV8Ycavb0GiYi6KkhE9QbIn29/IfMSTVYPfvfzP+JEz6mquRfpWuIiHPB6LkukIJwipf4w+3971mPIvAZJLs9PaxkLRtvCNrjFJfzm1O9lIUbUQu4QUtrtZMKqIBsXBVmhoNxvlIDhyywI+rRcBL/IK6I2kYpjMqipoaVi9st3zxEFrGJK6Zl3z2GG9yPATzF/H01tSJe0nsABFbz5jfx/SMNKn1ZgKAlf8rAzhxcvn+H+2A+YDk8iJSTL8kBoxTLRju17Dx8d/hjnJMooAJzo3gwfUvCY6yz49J0zmq6xlDSWxaTtAeZ6C4kDLuSHFD2yFdmXcpQ3nMmkEeJn8XhqBL6J+3gVnSkp/SRpAEzg6PgHAMAHPadw4ZPBXFoqFb5uPb0pS2OP7XtP4/Mqv+dICUlZfavFsVcppCwUgFeaxoDQHJwfHky19YoPXhRkWHfeEVaX8TI6g5fRGa0NLfK831q83C+1vrwB7nDuxxeffYXvHn5T+HCywtc8Y8pKBG+dqSKegzQGCi0TN2SeTfJv4vY4Pz4fzv18sP2Q6qx0WDcKPXo0tDDuvLMJDkZxyTdzFx9Isg9puEitJHGi55Ts76jbBfMHiKHoVhLfkPBAR2MTadL5SZ1iRkLcIbjo+pwcPhEcg9PKU5FKvRpatKxstzRYYKozURffLt+5hJnYlEwZzTdpxpIPLGZw2OnBkc6kEUvEcvfidrhhqlMPm7GleVkZQylLIXIiQlghxm/xS0jFG5pVXKZaU65gxNrQwlAwKjCPw8PUz3Hr6U34Zu7i03fOoG/fe6qNPqLXkIYfmpBC69mSr5MYnR4tAHlgLoBWV6tq4U7qNdTkcjVwMObPG8WbED/LtIrLbLLI+AlrwSjEz6o2tLS4WhCMBplk6uhSGJfvXIL5nnrDz2joCa7cucQsm3c0d1D/rRQYogWjQVgaLIodZZm1tKyMoSCX+5V6SqVP1E+M32a7TGEz11tgM9thzA5KY9bdZ9bSAOgzBZGfdOEAc0NLajmJ6eVJTM9NEhtuxQVQWrvBRGCMzNzFdw+/KfAk80thZlCIXkNpQGW6UYIvGhaD0aDiufhFXjbZXOSQclEx1c7/x/mTg/6B4X6qC+/0dLHsbENlIj/JrKURiYdLargVOVGLqwXhWJi58Sc/e/EFftQkcpGMpYdDrfZSrLgoFb5MtfVK43WdChyKxJKrrOStd0NLq7sV/ld+5uxF1D9GNBBOpQyFJUvhOE6TiEaSyx3k9HWoWPc56ew+qUpKIpuLqbjunkOJyJba0AIANbUGrK9t/AeKhWfRpTBuPb1J1TBMmz11d3Qzg6nYmhuHzUHlNYoIX1eLgo9wbAHb1LQ0tORM3DKBwwZARKBUwIycEd3t3cyil6nOhJ6OHowHxolgUwpRlHJ50ZBCHVZMtfXy3HstvaVAEYmsuIUkyys4clsmoPxAMXJGHO46zFzryfEwhxscxyEYDSKxlICpzgSnzYn25nYi2EhyuULvruqGdSRw/A0SCZ2EOi3vQikXP8kX2lhfwVEAlIwYdvQBiqXBgt7OXirBSi+uEqHv+r+hCmxUiQkrgupDNtWasNe1D3td+3JCWyQepl4QtBF21oF1YH2thpqfkEzcQ8RYYTJPKZcv0CysJl05kQGZ6y0F3iIpVM5zpDNpPHj+ICf6uB1u1YdOEtqoV7YbAAO3BgMHYN2w6VFoeJHVho7mDt0ah1kskYrLPKaCIvo1VUikBYdRgr5MpnKcI5FM5PL65OtkbjGy0+6Ew+ZQBYq0EMj0Cg7DOgxGdX6ylaDIZViSFk1xkzrWLIU5rFRa61ATg/gEDz7Bw8gZ4bA54LSrx+VSC4FSImviGtDS1AqnzVkyr9DDSpXLaXUOObkyWWRpY6JCWkcxJTCdSSMSiyASi+SYvNvhVs0OSikEikBZWU9hLv4Ka1hl3XlHdyNxK1a5XGqyTrBybmOYzqSRSCaY15TQps3CioBgNIhHY4/waOwRgtEgrHXq4BX5SV/3cRxsPwS3vZnaU4qNSr6Je3jsH0EoNputL1XW9JDLNYeVOoLWQfsQSJvBmupM8LZ5y9b0IvIT05oV//zWv2ApHcd0fAwrGYGOn6xpa1QqVggsl5G6/rXI5bTgGKLVOmi6tEanR2WryoUVAaP+UaZN37TYaOgnjIZ+QodzP050n0KNGVirSWM6PlZWfqJh552SQopc22jWTEQrpnMkXyeLbjfwcu4ler29ZZ9dAX4K17KV1d6Wt/AfH/03xvif8DD4I15nktT8pIwr20sAh1wuV1uwpIlziCKJjJAS1lvSdIurbYVA0wRcDqJXx5lwxP33sK434cHzB7AZm6j4iVgI7Os+jkP7jjLzkxA/W8BPSu24F1YFWrmcedtJpbt6CMkKelKnFeueVVqtvq5e91CTm2W1FggrAsLRMH5z6veYfx3Gk/D/UfGT/EKgHo1KWjruQ7FXRN5UakipSFhx2BxFO7FoCKnNagPmtH2/y+op2rElrkn5oPufAABNDR78Y+cvAPwC//Xtr+F2uqmuMb9RibUQuMlP2F/BQZLLSQuW9NyH1Kc0U/KVRRqV0dJggdPmVAwfNJvMlrL454vPvkKAn8Jo6AkCsSlElyI5DtLh3A+X1Y0/ffaVrFd0NPREJrS1ulpVyXMphUDW5m0Gufy6lmdnpOUcpVh3RzdMc6aC7aXFXgWaTMXIGYsCrJjNL4XR4dyvuGUCqYE4tZIs2H5BKrR5HB6q5QHSQmCIn9XUSK3UvE2SyxUWLF3UExwKN1sP6bqnzFpaNU4aOSO8bV5427xIJBMw1ZqY5WanXRs4oksRpi0j1TrKxbc6BeYCzIXArtYDmhqVhNVlTM9t8JP8V3CQ5HKFBUs+3cBx/uTgEKnRmJQ1JJeTTPm71sKU2+GW7UdKm8IW2xpS9C6joSe4M3G7gKzSpOnpTBqtrlY2HiZpVGIpBObvWCA7L9lrXIVGq6rNMrQsM7h27zKu3buM3pa3YK4z58JLaiWJX757DgBw+c7/MoGigNAyrEGhEdpC/KymLNBUW19SeZ4VHAuQ7C9q1qh16GXtze2alhnkp69iJ3lvy1u53/W2HNEEDpY1KDT6ibQQyNKopOA1fKW8e6XYFgw+EtKltlIhrUM01hfwFAsl2+VaSPyk09OF4wfepy4EKghfF0u5juragynLWVpdrSW/WCe6FMYf/tKvebFSpRp7aAqBesnlLODwk3QOGSkTKt9o7G3zIrmcZN4imkRWtZjY/V1JK1YI1EsuZwHHNM0JKtkumG+9nb14Ovm0pP1GtZiWxUmZtTSSWbVUWBVyoVjMUNJraWQyGc07FijUnq6Weq/MYYXjjAWA2Kr1K+J6EFI7QLnM7XDD2+bNaRri4GbW0jmpPCkkc8+Huk81a1p3LCAlE3q8VrQYOIYAXJDNHJOl4Ka3cv2KkTPiSNcRfV/uZ1hH7s0ihsJjq+uv4Zu8X3ZvqSR6MRTlfLo8X+wA87Z54bQ7MR4YJ6e5BsAgvuc11zi+DkPN5s80r/dk9QR62FZu06mmc8jdWL1F9pCEVaHizbXCqpATi1JZV97scuFlJFDgBarROM4ISzZc5G/QZ663gKsxIiUk1XhJX1nBcf7koI8koRsV+jr0AIcScWOK44btO+hitpc/+HV5g2/JDr4OtqdqwgqJuOXP/PzBrzYz11tyEyZ/8M2EmV9tpgYOPyRvmG4kaB2h2CwWU3GkFQa/2kzqyqVbW1XDgA8M9394/uTgUEXBQTKxk6ma47gxb7ZXgfnyOOHf8jiimKX49Fh/xBxWjNz2SnDU4nglVuTpZH5sqtI+bDTO5A+4v5QiWjnA4YNk/UolZhcpjpeJuJXbCgYXm6rzUJ5Y5duuF6/2hHVL7ElxvIqJ21De4D+UuvpSY321gGNBaaCF1eUCV04iblUax/MHvMDVl3MdcTWCg+jy+rqPV2McJxG3isfxnQSOaiFuVRPHd5rOsZXEbcfF8Woyw/r6Zv3BYDCQxJRSChQk4vZGx/GdHlZ8qIAAs2vVAY5Tu8TtzbT/HwCIGfb/wxMbcwAAAABJRU5ErkJggg==";

    let policyDialog = document.createElement('div');
    policyDialog.style = "text-align:center; margin-left: 35px; margin-right: 35px;";

    let policyHeader = document.createElement('div');
    if (secureUser) {
        let policyDialogLogo = document.createElement('img');
        policyDialogLogo.style = "height:55px; margin-top: 30px;margin-bottom:10px;width: auto;";
        policyDialogLogo.src = moneyImage;
        policyHeader.appendChild(policyDialogLogo);
        let policyDialogLogoText = document.createElement('div');
        policyDialogLogoText.innerText = "Don't Forget to Claim Your Cash Back Rewards";
        policyDialogLogoText.style = "color: forestgreen; margin: 15px 40px 0 40px; font-size: 22px;line-height: 25px;font-weight:500;";
        policyHeader.appendChild(policyDialogLogoText);
    }
    else {
        policyHeader.style = "font-size: 21px; margin: 35px 35px 15px 35px; text-align:center;font-weight: 500;line-height: 28px;";
        policyHeader.appendChild(document.createTextNode("Earn "));
        let policyHeader2 = document.createElement('span');
        policyHeader2.style = "color:green;font-size: 21px;";
        policyHeader2.innerText = "Cash Back";
        policyHeader.appendChild(policyHeader2);
        policyHeader.appendChild(document.createTextNode(" for shopping and automatically apply Coupons!"));
    }

    let dvPolicyDialogLogo = document.createElement('div');
    if (secureUser) {
        dvPolicyDialogLogo.style = "margin-top:20px";

        let policyDialogTables = document.createElement('table');
        policyDialogTables.style = "margin: auto;";

        //row 1
        let policyDialogRow1 = document.createElement('tr');

        //row 1 column 1
        let policyDialogRow1Column1 = document.createElement('td');
        policyDialogRow1Column1.innerText = "$" + secureUser[0].amount.toString().replace("$", "");
        policyDialogRow1Column1.style = "padding: 10px 10px 2px 10px;text-align: right;font-size:18px;width: 100px;";
        policyDialogRow1.appendChild(policyDialogRow1Column1)

        //row 1 column 2
        let policyDialogRow1Column2 = document.createElement('td');
        policyDialogRow1Column2.style = "padding: 10px 50px 2px 10px;text-align: left;font-size:18px;width: 100px;max-width: 200px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;";
        let policyDialogRow1Column2Text = document.createElement('span');
        policyDialogRow1Column2Text.style.fontSize = "18px";
        let isBonus = /bonus/i.test(secureUser[0].retailerName);
        if (!isBonus) {
            policyDialogRow1Column2Text.style.fontWeight = "bold";
            policyDialogRow1Column2.appendChild(document.createTextNode(secureUser[0].preposition + " "))
        }
        policyDialogRow1Column2Text.innerText = secureUser[0].retailerName;
        policyDialogRow1Column2.appendChild(policyDialogRow1Column2Text);
        policyDialogRow1.appendChild(policyDialogRow1Column2);

        policyDialogTables.appendChild(policyDialogRow1);

        //row 2
        if (secureUser.length >= 2) {
            let policyDialogRow2 = document.createElement('tr');

            //row 2 column 1
            let policyDialogRow2Column1 = document.createElement('td');
            policyDialogRow2Column1.innerText = "$" + secureUser[1].amount.toString().replace("$", "");
            policyDialogRow2Column1.style = "padding: 10px 10px 2px 10px;text-align: right;font-size:18px;width: 100px;";
            policyDialogRow2.appendChild(policyDialogRow2Column1)

            //row 2 column 2
            let policyDialogRow2Column2 = document.createElement('td');
            policyDialogRow2Column2.style = "padding: 10px 50px 2px 10px;text-align: left;font-size:18px;width: 100px;max-width: 200px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;";
            let policyDialogRow2Column2Text = document.createElement('span');
            policyDialogRow2Column2Text.style.fontSize = "18px";
            let isBonus = /bonus/i.test(secureUser[1].retailerName);
            if (!isBonus) {
                policyDialogRow2Column2Text.style.fontWeight = "bold";
                policyDialogRow2Column2.appendChild(document.createTextNode(secureUser[1].preposition + " "))
            }
            policyDialogRow2Column2Text.innerText = secureUser[1].retailerName;
            policyDialogRow2Column2.appendChild(policyDialogRow2Column2Text);
            policyDialogRow2.appendChild(policyDialogRow2Column2);

            policyDialogTables.appendChild(policyDialogRow2);
        }

        //row 3
        if (secureUser.length >= 3) {
            let policyDialogRow3 = document.createElement('tr');

            //row 3 column 1
            let policyDialogRow3Column1 = document.createElement('td');
            policyDialogRow3Column1.innerText = "$" + secureUser[2].amount.toString().replace("$", "");
            policyDialogRow3Column1.style = "padding: 10px 10px 2px 10px;text-align: right;font-size:18px;width: 100px;";
            policyDialogRow3.appendChild(policyDialogRow3Column1)

            //row 3 column 2
            let policyDialogRow3Column2 = document.createElement('td');
            policyDialogRow3Column2.style = "padding: 10px 50px 2px 10px;text-align: left;font-size:18px;width: 100px;max-width: 200px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;";
            let policyDialogRow3Column2Text = document.createElement('span');
            policyDialogRow3Column2Text.style.fontSize = "18px";
            let isBonus = /bonus/i.test(secureUser[2].retailerName);
            if (!isBonus) {
                policyDialogRow3Column2Text.style.fontWeight = "bold";
                policyDialogRow3Column2.appendChild(document.createTextNode(secureUser[2].preposition + " "))
            }
            policyDialogRow3Column2Text.innerText = secureUser[2].retailerName;            
            policyDialogRow3Column2.appendChild(policyDialogRow3Column2Text);
            policyDialogRow3.appendChild(policyDialogRow3Column2);

            policyDialogTables.appendChild(policyDialogRow3);
        }

        dvPolicyDialogLogo.appendChild(policyDialogTables);
    }
    else {
        let policyDialogLogo = document.createElement('img');
        policyDialogLogo.style = "height:95px; margin-top: 15px;width: auto;";
        policyDialogLogo.src = moneyImage;
        dvPolicyDialogLogo.appendChild(policyDialogLogo);
    }

    let policyBodyOne = document.createElement('div');
    policyBodyOne.style = "margin: 35px 45px 10px 45px; text-align:center;";
    let policyBodyOneSpan = document.createElement('span');
    policyBodyOneSpan.style = "font-size: 15px; line-height:20px;";
    policyBodyOneSpan.innerText = secureUser ? "Add to Chrome to update BeFrugal and claim your rewards" : "Add to Chrome to update BeFrugal and claim your Cash Back";
    policyBodyOne.appendChild(policyBodyOneSpan);

    let gotIt = document.createElement('div');
    gotIt.style = "display: inline-block; width: 250px; padding: 10px; font-size: 20px; margin:15px 0 21px 0; cursor:pointer; text-align:center;color:white; border-radius: 6px; box-shadow: -3px 4px 5px 0px rgba(0, 0, 0, 0.50); cursor: pointer; background-color: #ff6630; line-height: 30px; user-select: none;";
    gotIt.innerText = "Add to Chrome";

    let spnViewTwo = document.createElement('img');
    spnViewTwo.style = "vertical-align: middle;height: 19px;position: relative;top: -1px;left:35px;width: auto;";
    spnViewTwo.src = "data:image/png; base64, iVBORw0KGgoAAAANSUhEUgAAAQAAAAEABAMAAACuXLVVAAAALVBMVEUAAAD///////////////////////////////////////////////////////+hSKubAAAADnRSTlMAAQIKZGVplZaZmpu8/XqoetgAAAABYktHRA5vvTBPAAABs0lEQVR42u3duw3CQBCE4ZOAnBJcACXQAgUQENMXJVAIJThGIF0NyLIsv+7OJJ6RpX8b2NG3m2y0IfxX1ypY61A/vQFu8Vt5AWJ8egGilaABsBI0AE6CFsBI0AL4CDoAG0EH4CLoAUwEPYCHYAhgIRgCOAjGAAaCMYCeYAogJ5gCqAnmAGKCOYCWIAUgJUgBKAnSAEKCNICOIAcgI8gBqAjyACKCPICGoAQgITiV+sf3cfUAu1c0E5yLAQRbAAEEEEAAAQQQQAABBBBAAAEEEEAAAQQQQAABBBBAAAEEEEAAAQQQQAABBBBAAAEEEEAAAQQQQAABBBBsjWAhwMM8gk8FAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAGwPwP5CYl97AUK4WDdggUABUCKQAJQINAB5AhFAnkAFkCOQAeQIdABpAiFAmkAJkCKQAqQItABzAjHAnEANMCWQA0wJ9ABjAgPAmMABMCSwAAwJPAA9gQmgJ3ABdAQ2gI7AB9ASGAFaAidAQ2AFaAi8ACHc1zqHf6Q+/FDBuZ4QAAAAAElFTkSuQmCC";

    gotIt.appendChild(spnViewTwo);

    gotIt.onmouseover = function () { gotIt.style.backgroundColor = "#e3582b"; };
    gotIt.onmouseout = function () { gotIt.style.backgroundColor = "#ff6630"; };

    let termsDiv = document.createElement('div');
    termsDiv.style = "margin: 0 80px 6px 80px;";
    let termsTextOne = document.createElement("span");
    termsTextOne.innerText = "By downloading, users accepts ";
    termsTextOne.style = "font-size: 12px; color: grey;";
    let termLink = document.createElement('span');
    termLink.innerText = "Terms";
    termLink.style = "font-size: 12px; color:grey;cursor:pointer;";
    let privacyLink = document.createElement('span');
    privacyLink.innerText = "Privacy Policy";
    privacyLink.style = "font-size: 12px; color:grey;cursor:pointer;";
    let eulaLink = document.createElement('span');
    eulaLink.innerText = "EULA";
    eulaLink.style = "font-size: 12px; color:grey;cursor:pointer;";

    termsTextOne.appendChild(termLink);
    termsTextOne.appendChild(document.createTextNode(", "));
    termsTextOne.appendChild(privacyLink);
    termsTextOne.appendChild(document.createTextNode(", "));
    termsTextOne.appendChild(eulaLink);
    termsDiv.appendChild(termsTextOne);

    policyDialog.appendChild(policyHeader);
    policyDialog.appendChild(dvPolicyDialogLogo);
    policyDialog.appendChild(policyBodyOne);
    policyDialog.appendChild(gotIt);
    policyDialog.appendChild(termsDiv);

    document.body.appendChild(policyDialog);

    let header = document.getElementById("header");
    let newContent = document.getElementById("newContent");
    let newFooter = document.getElementById("newFooter");
    header.style.display = "none";
    newContent.style.display = "none";
    newFooter.style.display = "none";

    gotIt.onclick = function () {
        _openLink(settings.Config.UpdateUrl);
    };
    privacyLink.onclick = function () {
        _openLink("https://www.befrugal.com/help/privacypolicy/");
    };
    termLink.onclick = function () {
        _openLink("https://www.befrugal.com/termsandconditions/");
    };
    eulaLink.onclick = function () {
        let eulaURL = 'https://' + Site + '/toolbar/eula.txt?bf_src=3&bfuser=' + encodeURIComponent(userToken) + '&toolbarversion=' + toolbarVersion;
        _openLink(eulaURL);
    };
}

var tourPort;
function popupOpened() {
    _sendMessage({
        request: "PopupOpened"
    }, function (response) {
        Site = response.data.site;
        CDNSite = response.data.cdnSite;
        APISite = response.data.apiSite;
        settings = response.data.settings;
        isButton = response.data.isButton;
        tourInfo = response.data.tourInfo;
        isTour = tourInfo && tourInfo.TourMode;
        userToken = response.data.userToken;
        isShopper = response.data.isShopper;
        notallowed = response.data.notallowed;
        declinedDate = response.data.declinedDate;
        autoApplyData = response.data.autoApplyData;
        activeTab = response.data.activeTab;
        nocashback = response.data.nocashback;
        runTimeId = response.data.runTimeId;
        toolbarVersion = response.data.toolbarVersion;
        defaultPreferences = response.data.defaultPreferences;
        storeSource = response.data.storeSource;
        skin = response.data.skin;
        isSuppressed = response.isSuppressed;
        BfrlTool.BrowserStorage.LocalCache.MacInstalling = response.data.macInstalling;
        bsGuest = response.data.guest;
        noUser = response.data.noUser;

        if (isTour && tourPort == null) {
            tourPort = chrome.runtime.connect();
        }

        if (response.data.isTour) {
            //this is the embedded tour
            if (tourInfo && tourInfo.TourRetailer.retailerId && tourInfo.OneStepRST) {
                document.body.style.border = "2px solid lightgrey";
                document.getElementById("bf_logo_onRetailerView").style.display = "none";
                document.getElementById("svg_closeiFramePopup").style.display = "inline-block";
                document.getElementById("svg_closeiFramePopup").addEventListener("click", function () {
                    _sendMessage({
                        request: "TourFinished",
                        targetScript: "instructionsInject.js"
                    }, function () {
                        isTour = false;
                    });
                });
                document.getElementById("newFooter").style.display = "none";
                //document.querySelector("#headerRetailerNoCashbackRates #headerRetailerAddFavorites").style.display = "none";
                PopulateAndFormatSingleRestaurant(tourInfo.TourRetailer.retailerId);
            }
            else {
                _sendMessage({
                    request: "PopupOpened",
                    targetScript: "instructionsInject.js"
                });
            }
        }

        if (settings && settings.Config && settings.Config.UpdateRequired) {
            //TODO: update for MV3
            //browserAdapter.GetActiveTab(true, (tab) => {
            //    if (tab && tab.url && _openLinkUrlMatch(tab.url.toLowerCase(), sptool.Config.UpdateUrl.toLowerCase()))
            //        window.close();
            //    else {
            //        sptool.requiresUpdateReminder(function (secureUserData) {
            //            UpdateReminder(secureUserData);
            //        });
            //    }
            //});
        }
        else if (settings) {
            _onDOMContentLoaded();
            popup._TabPanes._Init();
        }
        else {
            _sendMessage({
                action: "sptool",
                targetScript: "shoptoolbar.js",
                data: { function: "_GetApplicationSettings", args: [true, false] }
            }, function () {
                popupOpened()
            });
        }
    });
};
popupOpened();


window.onunload = function(){
    _sendMessage({
        request: "popupClosed"
    });
};

