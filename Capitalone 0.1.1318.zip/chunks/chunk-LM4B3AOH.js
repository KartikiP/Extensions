import{v as e}from"./chunk-5YNZAJCO.js";var t=()=>e("getUser");export{t as a};
