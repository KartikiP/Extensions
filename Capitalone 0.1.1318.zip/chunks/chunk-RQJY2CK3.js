import{v as e}from"./chunk-5YNZAJCO.js";var r=t=>e("getLifetimeSavingsData",t);export{r as a};
