import{h as o}from"./chunk-5YNZAJCO.js";function s(){let e=o.get(["session"]);return e&&e.roles&&e.roles.indexOf("shadow")===-1}export{s as a};
