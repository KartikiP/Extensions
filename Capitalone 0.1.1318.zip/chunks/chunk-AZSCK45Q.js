import{v as t}from"./chunk-5YNZAJCO.js";var o=()=>t("getDomainLists");var m=e=>t("getElasticityUserDomainData",e);export{o as a,m as b};
