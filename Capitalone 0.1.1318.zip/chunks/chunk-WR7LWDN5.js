import{v as e}from"./chunk-5YNZAJCO.js";var o=async n=>e("pinnedTab",n);export{o as a};
