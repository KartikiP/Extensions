import{d as t}from"./chunk-PRIU7BYU.js";import{e as r}from"./chunk-3GYLW4KZ.js";var e=r(t());function u(){return e.default.v4().replace(/-/g,"")}export{u as a};
