import{v as e}from"./chunk-5YNZAJCO.js";var i=t=>e("getRelevantSites",t);export{i as a};
