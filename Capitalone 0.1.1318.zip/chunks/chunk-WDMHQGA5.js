import{v as e}from"./chunk-5YNZAJCO.js";var r=t=>e("compStateCache",t);export{r as a};
