import{h as s}from"./chunk-5YNZAJCO.js";function n(){let e=s.get(["session"]);return e&&e.roles&&e.roles.indexOf("suspended")>-1}export{n as a};
